# 新機器環境設定指南

本文說明如何在新機器上 clone 本 repo 並完成完整工作環境設定。

> **目標環境：macOS**（Windows 不支援）

---

## 前置需求

| 工具 | 版本 | 用途 |
|------|------|------|
| macOS | 任意 | 唯一支援的 OS |
| Node.js | 18+ | codebase-memory-mcp、UA Dashboard |
| .NET SDK | 8.0+ | 執行教學範例程式碼 |
| Claude Code | 最新版 | 工作區操作入口 |
| pnpm | 任意 | UA Dashboard 依賴管理 |

```bash
# 確認版本
node --version    # >= 18
dotnet --version  # >= 8.0
claude --version

# 安裝 pnpm（若未安裝）
npm install -g pnpm
```

---

## 步驟一：Clone 本 repo

```bash
git clone https://github.com/kevintsengtw/microsoft-agent-framework-tutorial.git
cd microsoft-agent-framework-tutorial
```

---

## 步驟二：Clone 上游 SDK（agent-framework/）

`agent-framework/` 不包含在本 repo 中，需在 **同一父目錄**下另行 clone，並對齊至目前知識庫對應的 commit：

```bash
# 在 microsoft-agent-framework-tutorial/ 的父目錄執行
cd ..
git clone https://github.com/microsoft/agent-framework.git

# 對齊至目前知識庫基準版本（v1.6.1，2026-05-25）
cd agent-framework
git checkout 08541ee5a9912b2d9b6b95b63ae3ea4ffea05cc1
```

完成後目錄結構應為：

```text
<父目錄>/
├── microsoft-agent-framework-tutorial/   ← 本 repo
└── agent-framework/                      ← 上游 SDK（自行 clone）
```

> 最新基準 commit 見 [`agent-framework-kb/UPSTREAM-REF.md`](./agent-framework-kb/UPSTREAM-REF.md)。

---

## 步驟三：安裝 codebase-memory-mcp

```bash
npm install -g codebase-memory-mcp
which codebase-memory-mcp   # 確認安裝成功
```

---

## 步驟四：安裝 Understand-Anything Plugin（Claude Code）

在 Claude Code 中執行：

```
/plugin marketplace add Lum1104/Understand-Anything
/plugin install understand-anything
```

安裝完成後**重啟 Claude Code**，讓工作區的 `.mcp.json` 設定生效。

---

## 步驟五：首次索引 agent-framework/

在 Claude Code 中，對上游 SDK 建立 codebase-memory-mcp 索引（首次需要幾分鐘）：

```
mcp__codebase-memory-mcp__index_repository
  repo_path: "<絕對路徑>/agent-framework"
```

完成後確認 project 名稱：

```
mcp__codebase-memory-mcp__list_projects
```

> 索引存於 `~/.codebase-memory-mcp/`（全域目錄），**不在本 repo 內**，**不跨機共享**，每台機器需獨立建立。之後 `git pull agent-framework` 時，file watcher 會自動增量更新，無需重新索引。

---

## 步驟六：驗證（建議）

跑 7 項探測查詢，確認 codebase-memory-mcp 在此機器上的 C# 解析準度達標（≥ 6/7）：

詳見 [`agent-framework-kb/raw/facts/codebase-memory-mcp-validation.md`](./agent-framework-kb/raw/facts/codebase-memory-mcp-validation.md)。

---

## 完成

從 Claude Code 開啟工作區根目錄，即可使用所有 slash commands：

```bash
claude   # 在 microsoft-agent-framework-tutorial/ 目錄啟動
```

常用指令快速參考見 [`agent-framework-kb/QuickStart.md`](./agent-framework-kb/QuickStart.md)。

---

## 選用：啟動知識圖譜 Dashboard

若不使用 Claude Code，也可直接開啟 Understand-Anything dashboard 瀏覽知識圖譜：

```bash
# 首次需 build core 套件
cd ~/.claude/plugins/cache/understand-anything/understand-anything/2.7.5/packages/core
npx tsc

# 安裝 dashboard 依賴
cd ~/.claude/plugins/cache/understand-anything/understand-anything/2.7.5/packages/dashboard
pnpm install

# 啟動（GRAPH_DIR 指向 wiki 目錄）
GRAPH_DIR=<絕對路徑>/microsoft-agent-framework-tutorial/agent-framework-kb/wiki \
  npx vite --host 127.0.0.1
```

開啟終端機輸出的 `http://127.0.0.1:5173/?token=<TOKEN>` 即可。

> 知識圖譜為靜態 JSON（`agent-framework-kb/wiki/.understand-anything/knowledge-graph.json`），Codex 等非 Claude 工具也可直接讀取使用。
