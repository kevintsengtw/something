---
updated: 2026-05-06
---

# Wiki 編譯規則（SCHEMA）

> 此檔案定義 `/compile` 指令在產生或更新 `wiki/concepts/` 條目時必須遵循的規則。

## 1. 條目檔案命名

- 使用小寫 kebab-case：`ai-agent.md`、`agent-session.md`
- 一個概念一個檔案，不合併
- 檔名即為 wiki-link 識別名稱：`[[ai-agent]]`

## 2. YAML Frontmatter 必填欄位

```yaml
---
title: <繁體中文概念名稱>          # 必填
api_name: <C# 類別/介面名稱>      # 必填，若無 API 則填 "N/A (描述)"
namespace: <命名空間>              # 必填，若無則填 "N/A"
since: <首次出現版本>              # 如 1.0.0-preview, 1.0.0, 1.1.0
current_version: <目前版本>        # 與 raw/release-notes/ 最新版本一致
updated: <YYYY-MM-DD>             # 最後更新日期
tags: [tag1, tag2]                # 至少 1 個 tag
tutorial_chapters: [ch02, ch04]   # 教學章節代號列表
sources:                          # 引用的 raw/ 素材路徑
  - raw/adrs/0001-xxx.md
---
```

## 3. 正文必備區段

每個條目**必須**包含以下區段，順序固定：

| 順序 | 區段標題 | 規則 |
|------|----------|------|
| 1 | `## 概述` | 1–3 句，用繁體中文說明概念用途 |
| 2 | `## 目前 API 簽名` | C# 程式碼區塊，標註 `csharp`；DevOps/遷移類條目可寫 "N/A" |
| 3 | `## 變更歷史` | Markdown 表格：版本 / 日期 / 變更內容 |
| 4 | `## 教學章節對應` | 條列式，指出每個章節中的使用情境 |
| 5 | `## 相關概念` | 使用 `[[concept-name]]` wiki-link 格式 |

## 4. 語言規則

- 所有散文使用**繁體中文**
- API 名稱、C# 類別名稱、方法簽名、NuGet 套件名稱保持**英文原名**
- 程式碼區塊中的註解使用**繁體中文**

## 5. 來源追溯

- `sources` 欄位列出的路徑必須實際存在於 `raw/` 目錄中
- 若 raw/ 中無對應素材，`sources` 填空陣列 `[]`
- `/lint` 指令會驗證 sources 路徑的有效性

## 6. 版本對齊

- `current_version` 必須與 `raw/release-notes/` 中最新穩定版一致
- 當上游發佈新版本時，`/compile` 需更新所有條目的 `current_version`
- `since` 欄位記錄該概念首次出現的版本，一旦設定後不再變更

## 7. 交叉引用

- 相關概念使用雙括號語法：`[[concept-name]]`
- `concept-name` 必須與 `wiki/concepts/` 中的檔名（去掉 `.md`）完全一致
- `/lint` 指令會驗證所有 wiki-link 指向有效的條目

## 8. 索引同步

- 每次 `/compile` 執行後，必須同步更新 `wiki/INDEX.md`
- INDEX.md 的分類結構在 INDEX.md 自身中定義
- 新增條目時，根據 tags 決定歸入哪個分類

## 9. 變更日誌

- 每次 `/compile` 執行後，必須同步更新 `wiki/api-changelog.md`
- 以版本為主軸記錄 API 層面的變更
- 格式見 `wiki/api-changelog.md`

## 10. 非 API 概念條目豁免規則

部分條目描述的是**架構指引、遷移策略或套件清單**，而非特定 C# API，這類條目**不要求** `## 目前 API 簽名` 區段，可改用更貼近內容性質的替代標題。

| 條目 | 替代區段標題 | 說明 |
|------|------------|------|
| `docker-deployment.md` | `## 關鍵設定` | 容器化部署設定指引，無對應 C# API |
| `testing-strategy.md` | `## 關鍵技巧` | 測試策略與模式，無單一 API 對應 |
| `nuget-packages.md` | `## 套件清單` + `## 安裝` | 套件清單條目，API 散佈於各套件 |
| `migration-from-sk-autogen.md` | `## 概念對照` | 遷移指引，對照兩個框架的概念對應 |

**識別方式**：`api_name` 欄位填入 `"N/A (描述)"` 格式的條目，視為非 API 概念條目，適用本豁免規則。

`/lint` 指令在驗證必備區段時，應對 `api_name` 含 `"N/A"` 的條目跳過 `## 目前 API 簽名` 的存在性檢查。

---

## 11. drift-check 整合

條目中的以下資訊供 `/drift-check` 比對使用：

- `api_name`：確認教學中使用的類別名稱是否與最新 API 一致
- `namespace`：確認教學中的 `using` 語句是否正確
- `tutorial_chapters`：識別哪些教學章節需要被檢查
- `## 目前 API 簽名`：做為比對教學範例程式碼的基準
