---
generated: 2026-06-06（re-run 驗證版）
indexed_commit: afa7834e2ec8a93b2224fe7ab184b97fbcaa8c9a
baseline: wiki/concepts/ (41 條目, v1.9.0) vs tutorial/ (29 章 + 9 附錄)
versions_covered: dotnet-1.7.0, dotnet-1.8.0, dotnet-1.9.0
---

# 偏移報告

## 摘要

| 等級 | 數量 | 說明 |
|------|------|------|
| 🔴 Breaking | 0 | 三版（1.7/1.8/1.9）累積 breaking 經 codebase-memory-mcp 驗證後，皆不影響教學程式碼 |
| 🟡 Outdated | 0 | O-101、O-102 已由 /update-tutorial 修正並關閉 |
| 🟢 Enhancement | 1 | E-101（Magentic 專章）仍延後；其餘已補（見下） |

> **Re-run 驗證（2026-06-06）**：補做的教學新小節（ch11 session 隔離、ch18 高階編排 Builder、ch19 Magentic/Workflow Outputs、ch29 MCP skills）所用 API 全部重新查驗存在於 1.9.0 圖譜 — `SequentialWorkflowBuilder`、`ConcurrentWorkflowBuilder`、`MagenticWorkflowBuilder`、`AgentWorkflowBuilder`、`UseMcpSkills`、`UseClaimsBasedSessionIsolation`、`WithAggregator`、`WithOutputFrom`、`WithIntermediateOutputFrom` 皆 ✅。🔴 維持 0。

---

## 🔴 Breaking（0 項）

三版的關鍵 breaking change 皆經 codebase-memory-mcp ground truth 驗證，確認**不影響教學程式碼**：

| PR | 變更 | 驗證結論 |
|----|------|---------|
| #6030 | base `AgentSkill` 消費端改非同步（`GetContentAsync`/`GetResourceAsync`/`GetScriptAsync`） | ch29 僅用撰寫端 API（`AgentClassSkill<T>` 的 `override Frontmatter`/`Instructions` + `[AgentSkillResource]`/`[AgentSkillScript]`、`AgentInlineSkill.AddResource(object\|Delegate)`、`AgentSkillsProvider` 四種建構子），全部仍編譯。**E-002 對教學為 false positive，正式關閉** |
| #6109 | `AgentFileSkillsSource` 改 depth-based discovery + 述詞過濾 | 教學未使用被移除的 `ResourceDirectories`/`ScriptDirectories`（grep 確認 0 處）；`new AgentSkillsProvider(path, runner)` 預設深度 2，涵蓋 ch29 目錄結構 |
| #6095 | 移除 Declarative Workflows code-gen | 教學未示範 code-gen（grep 確認 0 處） |
| #6121 | 移除 FoundryAgent responses experimental flag | ch17 未使用該 flag（grep 確認 0 處） |

---

## 🟡 Outdated（0 項 — 已全數修正）

> 以下兩項已由 `/update-tutorial` 修正並關閉，保留記錄供追溯。

### O-101 ✅ 已修正: appendix-a 版本說明落後三版
- **影響檔案**：`appendix-a-nuget-packages.md` L98–L120、L122 起的版本變更段落
- **現況**：「目前版本：`1.6.1`」、版本變更段落最新為 v1.6.1
- **正確**：目前版本應為 `1.9.0`（2026-06-03）；需補 v1.7.0/v1.8.0/v1.9.0 三段變更說明
- **來源 wiki**：[[api-changelog]] 已含 v1.7/1.8/1.9 段落
- **建議修正**：更新「目前版本」與發佈日期清單；新增三版變更表（重點：AgentSkill async #6030、AgentFileSkillsSource depth-based #6109、Declarative code-gen 移除 #6095、Orchestrations 移除 [Experimental] #6164、Workflows.Declarative 轉 stable #6254）

### O-102 ✅ 已修正: Magentic「實驗性」措辭需更新（v1.9.0 已轉正式）
- **影響檔案**：`appendix-a-nuget-packages.md` L140（v1.5.0 變更列標「標注 Experimental」）
- **現況**：「多代理 LLM 驅動任務分解編排（`MagenticOrchestrator`、`MagenticWorkflowBuilder`），標注 Experimental」
- **正確**：v1.9.0（PR #6164）已移除 .NET Orchestrations 的 `[Experimental]`；公開入口為 `MagenticWorkflowBuilder`（穩定），`MagenticOrchestrator` 已改 `internal`
- **圖譜證據**：`public class MagenticWorkflowBuilder(AIAgent managerAgent)` 無 `[Experimental]` attribute（get_code_snippet 確認）；`internal class MagenticOrchestrator`
- **來源 wiki**：[[magentic-orchestration]]（已更新）
- **建議修正**：v1.5.0 歷史列為當時狀態，保留即可；於 v1.9.0 新段落補註「Orchestrations 移除 [Experimental]、Magentic 轉正式」。可選：`MagenticOrchestrator` 已 internal，措辭改以 `MagenticWorkflowBuilder` 為主

---

## 🟢 Enhancement（0 項待辦 — 已全數處理）

### E-101 ✅ 已完成: Magentic Orchestration 教學專章
- 已建立 **第 30 章：Magentic Orchestration**（`/draft-chapter` → 人工 review → 落地 → /regenerate-toc → /lint）
- wiki [[magentic-orchestration]]、[[orchestration-builders]] 的 tutorial_chapters 已加 ch30
- E-004 backlog 項目同步關閉

### E-102 ✅ 已補: 01 時間軸補 v1.7/1.8/1.9 列

### E-103 ✅ 已補: 三版新功能已寫入教學
- 高階編排 Builder（Sequential/Concurrent）→ ch18；Magentic/GroupChat + Workflow Outputs Overhaul → ch19
- MCP-based skills（第 4 來源）→ ch29；ClaimsIdentity session 隔離 → ch11
- 對應 wiki：新建 [[orchestration-builders]]、[[agent-skills]] 補 MCP、[[aspnet-core-hosting]] 補 session 隔離

---

## 處理建議

- `/update-tutorial outdated` 處理 O-101、O-102（appendix-a 版本表 + Magentic 措辭）
- 🔴 = 0，無需 `/update-tutorial breaking`
- E-101/E-102/E-103 為可選，本輪不自動處理
