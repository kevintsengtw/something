---
updated: 2026-06-06
---

# API 變更日誌

---

## post-1.9.0（下一個 .NET 版本，預計中）

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| 新增 `HostedSessionContext`：Foundry 託管代理的每用戶 Session 隔離 | [[hosted-session-context]] | ADR 0026 Accepted（2026-05-07）；`GetHostedContext()` 供 AIContextProvider 讀取；`SetHostedContext()` 為 internal；Session 恢復時身份不符回傳 403 |
| 新增 `HostedSessionIsolationKeyProvider` 抽象類別 | [[hosted-session-context]] | 可替換 DI 工廠；`DevTemporaryLocalSessionIsolationKeyProvider` 供本機開發使用 |

---

## v1.9.0（2026-06-03）

**分類：API 狀態變更（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| **移除 .NET Orchestrations 的 `[Experimental]` 標記**（PR #6164） | [[magentic-orchestration]], [[workflows]] | `MagenticWorkflowBuilder` 轉穩定公開 API；`MagenticOrchestrator`/`MagenticManager` 改為 `internal`。Magentic/Handoff/GroupChat 皆轉正式 |
| **`Microsoft.Agents.AI.Workflows.Declarative` 套件轉 stable**（PR #6254） | [[declarative-workflow]] | 安裝不再需要 `--prerelease` |

**分類：增強（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| Workflow Outputs Overhaul：支援 tagging/filtering agent 輸出（PR #6045） | [[workflows]] | `WithOutputFrom`/`WithIntermediateOutputFrom` |
| `GroupChatManager` 語意對齊 Orchestration patterns（PR #6140） | [[workflows]], [[magentic-orchestration]] | — |
| `HarnessAgent` 建構子加入 `ILoggerFactory`/`IServiceProvider`（PR #6273） | — | 皆為可選參數，擴充 DI 整合 |
| 跨工作流程保留並傳遞 `CreatedAt`（PR #3930） | [[workflows]] | — |

**分類：Bug 修復（.NET）**：Foundry Hosting `function_call_output` 缺 id（#6246）、宣告式工作流程 `InvokeMcpTool` 核准路徑（#6177）、AGUI hosting 與 workflows（#6311）。

> 多數 v1.9.0 變更為 Python-only（`McpSkillsSource`、progressive tool exposure、`AgentFileStore`/`FileAccessProvider`、Bedrock structured output、Mistral embedding 等），不影響 .NET 教學。

---

## v1.8.0（2026-05-28）

**分類：Breaking Changes（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| **[Breaking]** 移除 Declarative Workflows 的 code-gen 支援（PR #6095） | [[declarative-workflow]] | 改為純執行期解譯；教學未使用 code-gen，無影響 |
| **[Breaking]** 重構 `AgentFileSkillsSource` 為 depth-based discovery + 述詞過濾（PR #6109） | [[agent-skills]] | `AgentFileSkillsSourceOptions` 改用 `SearchDepth`/`ResourceFilter`/`ScriptFilter`；未自訂 `fileOptions` 的呼叫不受影響 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| MCP-based skills（skill-md 類型，`AgentMcpSkill`/`AgentMcpSkillsSource`，PR #6108） | [[agent-skills]], [[mcp-integration]] | — |
| `ForeachExecutor` 迭代狀態跨 checkpoint 持久化（PR #6051） | [[declarative-workflow]], [[workflows]] | — |
| `ClaimsIdentity`-based agent session scoping（PR #5696） | [[agent-session]] | hosting 場景；教學未涵蓋 |
| Handoff Orchestration 與 Python 對齊（PR #6138） | [[workflows]] | — |
| 移除 FoundryAgent 等的 responses experimental flag（PR #6121） | [[llm-providers]] | — |

---

## v1.7.0（2026-05-26）

**分類：Breaking Changes（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| **[Breaking]** base `AgentSkill` 消費端 API 改為非同步（`GetContentAsync`/`GetResourceAsync(name)`/`GetScriptAsync(name)`，PR #6030） | [[agent-skills]] | 撰寫端 `AgentClassSkill<T>`/`AgentInlineSkill`/`AgentSkillsProvider` 保留；ch29 教學程式碼**不受影響**（修正先前 E-002 預測） |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| MCP 長時間任務支援（MCP client tools，PR #5994） | [[mcp-integration]] | — |
| Magentic Orchestration 範例（PR #5823） | [[magentic-orchestration]] | `dotnet/samples/03-workflows/Orchestration/Magentic` |
| Hosted-AgentSkills（Foundry Skills）範例（PR #6013） | [[agent-skills]] | — |

---

## v1.6.1（2026-05-14）

> 注意：本版本從 v1.5.0 直接跳至 v1.6.1（無 v1.6.0 公開發佈）。

**分類：Breaking Changes（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| **[Breaking]** `OpenTelemetryAgent` 自動包裝 `ChatClient` 為 `OpenTelemetryChatClient` | [[opentelemetry]] | 手動雙重包裝將造成重複儀器化；移除既有手動 `.WithOpenTelemetry()` 呼叫 |
| **[Breaking]** Foundry Toolbox server-side tools 完整移除（`GetToolboxAsync()` 不再可用） | [[foundry-toolbox]], [[tools-ai-function]] | 改用 `AIFunctionFactory.Create()` client-side 工具定義 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| 新增 `MessageInjectingChatClient`（sealed class，`[Experimental]`）：函數迴圈期間動態注入訊息 | [[chat-message-injector]] | 透過 `ChatClientAgentOptions.EnableMessageInjection = true` 啟用；適用稽核日誌、動態約束、注意力刷新 |
| 新增 Shell Tool（`LocalShellExecutor`、`DockerShellExecutor`）：允許代理執行本地或 Docker shell 命令 | [[shell-tool]] | 預設啟用 `ApprovalRequiredAIFunction` 安全審批；僅限受控環境 |
| 新增 `AgentSessionFiles` SDK：工作階段檔案管理 | [[agent-session-files]] | 支援上傳文件給代理即時處理 |
| A2A 協定新增 `input-request` 內容類型支援（human-in-the-loop） | [[a2a-protocol]], [[human-in-the-loop]] | 多代理工作流程可在執行期暫停等待人工輸入 |
| 新增 Harness Agent 套件 | — | Managed Agent 測試與封裝工具鏈 |
| Hyperlight 加入 release solution filter | [[codeact-integration]] | 改善建置整合 |

**分類：改進（.NET）**

| 變更 | 影響的概念 |
|------|-----------|
| FoundryAgent 嚴格 URL 路由處理修正 | [[llm-providers]] |
| `ClientHeadersScope` 使用 `AsyncLocal` 還原機制簡化 | — |
| DevUI HTTP 介面新增可配置存取控制選項 | [[opentelemetry]] |
| Anthropic Extensions AI 版本對齊更新 | [[llm-providers]] |

**分類：Bug 修復（.NET）**

| 變更 | 影響的概念 |
|------|-----------|
| 修正 handoff `FunctionResult` 無法正確傳遞至代理 | [[workflows]] |
| 修正 `OpenAIResponsesAgentClient` endpoint path 錯誤 | [[llm-providers]] |
| 防止 handoff 過程中訊息 role 被意外修改 | [[a2a-protocol]], [[workflows]] |

**分類：Breaking Changes（Python 僅）**

| 變更 | 說明 |
|------|------|
| DevUI 存取控制與 CORS 政策收緊 | 預設不再允許跨來源請求 |
| File skill 資料夾探索對齊 agentskills.io 規範 | 影響 file-based skills 目錄結構 |

---

## v1.5.0（2026-05-08）

**分類：實驗性新功能（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| **[Experimental]** Magentic Orchestration：`MagenticOrchestrator`、`MagenticManager`、`MagenticProgressLedger`、`MagenticTaskContext`、`MagenticWorkflowBuilder`（命名空間：`Microsoft.Agents.AI.Workflows.Specialized.Magentic`） | [[magentic-orchestration]] | #5595, #5704 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| AG-UI 新增推理事件（Reasoning Events）串流支援 | [[ag-ui-protocol]] | #4953 |
| 訊息過濾：排除不可攜帶的內容類型（non-portable content types） | [[agent-response]] | #5410 |
| `WebBrowsingTool` 新增 allow listing（限制可瀏覽網域） | [[tools-ai-function]] | #5605 |
| Todo 多執行緒支援與注入訊息列表 | — | #5655 |

**分類：Bug 修復（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| **[Bug Fix]** `SKILL.md` frontmatter YAML block scalar（`\|` / `>`）解析修正 | [[agent-skills]] | #5610 |
| MultiPartyConversation JSON 序列化修正 | — | #5653 |
| QuestionExecutor GotoAction 重新進入無限迴圈修正 | — | #5635 |
| 序列號生成執行緒安全修正（防止重複/亂序 ID） | — | #5320 |
| `function_call_output.output` 改為 JSON 字串格式 | — | #5705 |
| Workflows 缺少 Shared 來源檔案修正 | [[workflows]] | #5656 |

**分類：相依更新（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| MEAI 10.5.1 | 新增 Foundry 每次呼叫 x-client 標頭 | #5652 |
| GitHub Copilot SDK 1.0.0-beta.2 | 版本更新 | #5699 |

**本版本無 Breaking Changes。**

---

## v1.4.0（2026-05-05）

**分類：Breaking Changes（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| **[Breaking]** file-based skill scripts 引數型別改為 `string[]`（原為單一字串） | [[agent-skills]] | #5475 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| 新套件 `Microsoft.Agents.AI.Hyperlight`：CodeAct .NET 整合 GA | [[codeact-integration]], [[nuget-packages]] | #5329 |
| 宣告式工作流程新增 `HttpRequestAction` 步驟型別 | [[declarative-workflow]] | #5474 |
| Durable Workflow HTTP trigger endpoint 支援回傳執行結果（不再只回傳 202） | [[durable-agents]] | #5321 |
| Hosted-agent 對外 HTTP 請求自動附加 User-Agent 標頭 | [[aspnet-core-hosting]] | #5453 |
| Harness 功能合併進主線（agent 測試輔助機制） | [[testing-strategy]] | #5310 |
| Hosting 層更新：整合 HttpRequestAction 與回傳結果機制 | [[declarative-workflow]] | #5589 |

**分類：相依更新（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| OpenTelemetry packages | 升級至 1.15.3 | #5478 |

**分類：ADR 新增**

| ADR | 概念 | 狀態 |
|-----|------|------|
| 0024-prompt-injection-defense | [[prompt-injection-defense]] — FIDES 確定性 Prompt Injection 防禦 | Proposed |

---

## v1.3.0（2026-04-24）

**分類：Breaking Changes（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| **[Breaking]** A2A SDK 0.3.4-preview → 1.0.0-preview2：`EndpointRouteBuilderExtensions` 移除（→ `A2AEndpointRouteBuilderExtensions`）、`AIAgentExtensions` 移除（→ `A2AServerServiceCollectionExtensions`）| [[a2a-protocol]], [[aspnet-core-hosting]] | #5423 |
| **[Breaking]** Azure.AI.AgentServer.Responses SDK beta.3→beta.4：`FunctionToolCallOutputResource` → `OutputItemFunctionToolCallOutput`，`AzureAIAgentServerResponsesModelFactory` 改為 internal | [[llm-providers]] | #5450 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| A2A SSE stream reconnection（continuation token 機制） | [[a2a-protocol]] | #5423 |
| `A2AAgentHandler` 新增 streaming 支援（`RunStreamingAsync` 路徑） | [[a2a-protocol]], [[run-async]] | #5427 |
| Server-side Foundry Toolbox（`FoundryToolbox` + `AIProjectClientToolboxExtensions`） | [[llm-providers]], [[tools-ai-function]] | #5450 |
| 新增型別：`A2AAgentHandler`, `A2AServerRegistrationOptions`, `A2AServerServiceCollectionExtensions`, `A2AEndpointRouteBuilderExtensions` | [[a2a-protocol]] | #5423 |
| A2A samples 重新分類：`04-hosting/A2A/` → `02-agents/A2A/` | [[a2a-protocol]] | #5423 |

**分類：Bug 修復（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| 修正 `StreamingRunEventStream.RunLoopAsync` 中 RunStatus off-thread race（`GetStatusAsync` 在 halt 後誤回傳 Running） | [[durable-agents]], [[long-running-operations]] | #5412 |

**分類：相依更新（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| `Microsoft.ML.Tokenizers` | 新增依賴 ≥ 2.0.0 | — |
| `Microsoft.Agents.AI.Hosting.Aspire` | 改為 preview 套件 | #5444 |

---

## v1.2.0（2026-04-21）

**分類：重大新功能（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Foundry Hosted Agents Support（13 PR 合併） | [[llm-providers]], [[ai-agent]] | #5312 |
| Foundry Evals Integration for .NET（已 GA） | [[agent-evaluation]] | #4914, #5269 |
| Handoff Orchestration 重構 + HITL 支援 | [[workflows]], [[human-in-the-loop]] | #5174 |
| DevUI Aspire Integration | [[opentelemetry]] | #3771 |
| AGUI service 支援 session storage | [[ag-ui-protocol]], [[agent-session]] | #5193 |

**分類：Bug 修復（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Duplicate CallIds 導致 Handoff Message Filtering 失敗 | [[workflows]] | #5359 |
| 修正 Declarative resume edge predicates（checkpoint 還原後）| [[declarative-workflow]] | #5323 |
| Declarative workflows — 代理無回應時的優雅處理 | [[declarative-workflow]] | #5376 |
| Handoff-hosted Agents session 支援 | [[llm-providers]], [[agent-session]] | #5280 |
| Foundry Agents 無 description 時 Handoff 崩潰 | [[llm-providers]] | #5311 |
| In-process workflow checkpoint-restore race condition | [[durable-agents]] | #5134 |
| A2A metadata 使用 namespaced key 傳播 | [[a2a-protocol]] | #5256 |

**分類：相依更新（.NET）**

| 套件 | 新版 | PR |
|------|------|----|
| Microsoft.Extensions.AI | 10.5.0 | #5269 |
| OpenAI | 2.10.0 | #5269 |
| Anthropic SDK | 12.13.0 | #5279 |
| Anthropic.Foundry | 0.5.0 | #5279 |

**分類：Python 重點（僅供參考）**

| 變更 | PR |
|------|-----|
| Foundry hosted agent V2 | #5379 |
| Foundry Toolboxes 支援 | #5346 |
| GeminiChatClient（Gemini API + Vertex AI）| #5258, #4847 |
| finish_reason 支援 AgentResponse/AgentResponseUpdate | #5211 |
| Hyperlight CodeAct 套件與文件 | #5185 |

---

---

## python-1.0.1（2026-04-09）

**分類：Breaking Changes**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| `FileCheckpointStorage` 預設使用受限 unpickler（需透過 `allowed_checkpoint_types` 明確允許自訂型別） | [[durable-agents]] | #4941 |
| Handoff workflow 上下文管理修復（breaking） | [[workflows]] | #5136 |

**分類：新增**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Cosmos DB NoSQL checkpoint storage（`agent-framework-azure-cosmos`） | [[durable-agents]] | #4916 |

**分類：Bug 修復**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| `response_format` 背景輪詢空文字崩潰 | [[structured-output]] | #5146 |
| `FoundryAgent` 傳入 `agent_reference` 時多餘的 tools 剝除 | [[llm-providers]] | #5101 |

---

> 以版本為主軸，記錄 Microsoft Agent Framework .NET SDK 的 API 層面變更。
> 供 `/drift-check` 與 `/compile` 交叉參考。

---

## v1.1.0（2026-04-10）

**分類：新功能**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| 新增 `AgentClassSkill<T>` 泛型基底類別（⚠️ 非 `AgentClassSkill`） | [[agent-skills]] | #5027 |
| 新增 `AgentInlineSkill`（Code-Defined Skills，GA） | [[agent-skills]] | — |
| 新增 `AgentSkillsProviderBuilder`（混合多來源） | [[agent-skills]] | — |
| 新增 `AgentFileSkillsSourceOptions`（自訂資源/腳本探索規則） | [[agent-skills]] | — |
| 新增 `AgentSkillsProviderOptions`（ScriptApproval / DisableCaching） | [[agent-skills]] | — |
| 反射式資源/腳本探索（`[AgentSkillResource]` / `[AgentSkillScript]` 屬性） | [[agent-skills]] | #5183 |
| 技能函式支援自訂型別 | [[agent-skills]] | #5152 |
| 檔案技能資料夾探索對齊 | [[agent-skills]] | #5078 |
| 目錄術語標準化 | [[agent-skills]] | #5205 |
| ADR 0017 Accepted：`AgentWithMetadata` 外部包裝器模式 | [[agent-additional-properties]] | — |

**分類：Bug 修復**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Message Delivery Callback | [[workflows]] | #5081 |
| Handoff 上下文修復 | [[workflows]] | #5136 |
| Checkpoint 修復 | [[durable-agents]] | #5085 |
| Chat Completion 空 content 處理 | [[agent-response]] | #5139 |
| Session 壓縮邏輯修復 | [[durable-agents]] | #5094 |
| Chat history compaction 重複修復 | [[chat-history-persistence]] | #5149 |
| Entity key 驗證修復 | [[durable-agents]] | #5179 |

**分類：相依更新**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Anthropic SDK 12.8.0 → 12.11.0 | [[llm-providers]] | #5055 |
| 新增 gpt-5.4-mini 模型對應 | [[llm-providers]] | — |

**分類：標準化**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Entity key 格式統一 | [[durable-agents]] | #5088 |
| FoundryAgent session ID 統一 | [[durable-agents]] | #5120 |
| FoundryAgent.CreateSessionAsync(conversationId) 新多載 | [[agent-session]] | #5144 |

---

## v1.0.0 GA（2026-04-02）

**分類：正式釋出**

| 變更 | 影響的概念 |
|------|-----------|
| 首個穩定版釋出 | 所有概念 |
| `AIAgent` 正式 API 定案 | [[ai-agent]], [[run-async]] |
| `AgentSession`（原 `AgentThread`）正式命名 | [[agent-session]], [[provider-session-state]] |
| `AgentResponse` / `AgentResponseUpdate` 定案 | [[agent-response]] |
| `AgentMiddlewareContext` / `AgentMiddlewareDelegate` 定案 | [[middleware-pipeline]] |
| AG-UI Protocol 支援（ADR 0010） | [[ag-ui-protocol]], [[aspnet-core-hosting]] |
| Chat History Persistence 一致性（ADR 0022） | [[chat-history-persistence]] |
| Feature Collections（ADR 0014） | [[feature-collections]] |
| AgentSession Serialization — StateBag 設計（ADR 0018） | [[agent-session]] |

---

## v1.0.0-preview 系列（2025-11 ~ 2026-03）

**分類：預覽里程碑**

| 變更 | 影響的概念 |
|------|-----------|
| 初始 `AIAgent` 抽象設計 | [[ai-agent]] |
| `AgentThread` → `AgentSession` 重新命名（ADR 0018） | [[agent-session]] |
| 基於裝飾器模式的 Middleware 管線（ADR 0007） | [[middleware-pipeline]] |
| Unified Tools Abstraction 討論啟動（ADR 0002） | [[tools-ai-function]] |
| A2A / MCP 協定初始支援 | [[a2a-protocol]], [[mcp-integration]] |

---

## 待追蹤（Proposed ADRs，尚未釋出）

| ADR | 概念 | 狀態 |
|-----|------|------|
| 0002 | [[tools-ai-function]] — Unified Abstraction | Proposed |
| 0007 | [[middleware-pipeline]] — Filtering Middleware | Proposed |
| 0021 | [[agent-skills]] — Aggregating / Caching / Deduplicating Sources | 仍為 Proposed（v1.1.0 已實作三種 authoring 方式） |
| 0025 | Foundry Toolbox Support (`get_toolbox`) | Python: v1.2.0 已實作；.NET: v1.3.0 已實作，**v1.6.1 已移除**（見 [[foundry-toolbox]]） |
