---
title: Orchestration Builders — 高階編排建構器家族
api_name: SequentialWorkflowBuilder / ConcurrentWorkflowBuilder / GroupChatWorkflowBuilder / OrchestrationBuilderBase
namespace: Microsoft.Agents.AI.Workflows
since: 1.8.0
current_version: 1.9.0
updated: 2026-06-06
tags: [workflow, orchestration, builder, sequential, concurrent, group-chat, magentic, v1.8.0, v1.9.0]
tutorial_chapters: [ch18, ch19, ch30]
sources:
  - raw/release-notes/dotnet-1.8.0.md
  - raw/release-notes/dotnet-1.9.0.md
  - raw/facts/dotnet-1.9.0-verified-changes.json
---

## 概述

v1.8.0 起，框架在低階 `WorkflowBuilder`（手動 `AddEdge` 連接 Executor，見 [[workflows]]）之上，新增一組**高階編排建構器**，把常見的多代理協作模式收斂成一行式的流暢 API。它們都繼承共同基底 `OrchestrationBuilderBase<TBuilder>`，回傳標準的 `Workflow`，可用 `InProcessExecution.RunAsync` 執行。

| 建構器 | 模式 | 建立方式 | 自 |
|--------|------|---------|----|
| `SequentialWorkflowBuilder` | 代理依序接力 | `new(params AIAgent[])` | 1.8.0 |
| `ConcurrentWorkflowBuilder` | Fan-out/Fan-in 並行 | `new(params AIAgent[])` | 1.8.0 |
| `GroupChatWorkflowBuilder` | 群聊（manager 選下一位發言者） | 由 group chat manager 工廠建立 | 既有，1.8/1.9 對齊 |
| [[magentic-orchestration]] `MagenticWorkflowBuilder` | manager 驅動規劃迴圈 | `new(AIAgent managerAgent)` | 1.5.0 |

> v1.9.0（PR #6164）移除這些 Orchestration 的 `[Experimental]` 標記，全部轉穩定。

## 目前 API 簽名

### 共同基底 `OrchestrationBuilderBase<TBuilder>`

```csharp
public abstract class OrchestrationBuilderBase<TBuilder>
    where TBuilder : OrchestrationBuilderBase<TBuilder>
{
    public TBuilder WithName(string name);
    public TBuilder WithDescription(string description);

    // Workflow Outputs Overhaul（PR #6045）：覆寫各 orchestration 的預設輸出來源
    public TBuilder WithOutputFrom(params IEnumerable<AIAgent> agents);            // 終端輸出
    public TBuilder WithIntermediateOutputFrom(IEnumerable<AIAgent> agents);       // 中間輸出（標 OutputTag.Intermediate）
}
```

> 一旦呼叫任一輸出指定方法，就會**取代**該 orchestration 的預設輸出設定，只重播你指定的來源。未呼叫則套用各模式預設（例如 sequential 預設輸出最後一個代理 + 其餘為中間輸出）。

### Sequential（依序接力）

```csharp
using Microsoft.Agents.AI.Workflows;

Workflow workflow = new SequentialWorkflowBuilder(frontDesk, concierge, summarizer)
    .WithName("travel-pipeline")
    .Build();

await using Run run = await InProcessExecution.RunAsync(workflow, "幫我規劃東京三日遊");
```

### Concurrent（並行 Fan-out/Fan-in）

```csharp
Workflow workflow = new ConcurrentWorkflowBuilder(researcher, planner, critic)
    // 可選：自訂彙整函式（預設取每個代理最後一則訊息）
    .WithAggregator(perAgentMessages =>
        perAgentMessages.Where(m => m.Count > 0).Select(m => m[^1]).ToList())
    .Build();

await using Run run = await InProcessExecution.RunAsync(workflow, "評估這份提案");
```

### Group Chat（manager 選下一位發言者）

```csharp
// GroupChatWorkflowBuilder 由 group chat manager 工廠建立（建構子為 internal），
// manager 決定下一位發言者；GroupChatManager 語意於 v1.9.0（PR #6140）對齊 Orchestration patterns
GroupChatWorkflowBuilder builder = /* 由 manager 工廠取得 */;
Workflow workflow = builder
    .AddParticipants(writer, editor, factChecker)
    .Build();
```

### Magentic（manager 驅動規劃）

見 [[magentic-orchestration]]（`MagenticWorkflowBuilder`）。

## Workflow Outputs Overhaul（PR #6045）

`OutputTag`（readonly struct）讓工作流程的輸出可標註與過濾：

```csharp
public readonly struct OutputTag
{
    public string? Value { get; }
    public static OutputTag Intermediate { get; }   // "intermediate"；終端輸出不帶 tag
}
```

- 終端輸出：`WithOutputFrom(agent)`（不帶 tag）
- 中間輸出：`WithIntermediateOutputFrom(agents)`（帶 `OutputTag.Intermediate`）
- 消費端可用 `WorkflowOutputEventExtensions` 依 tag 過濾事件，區分「最終結果」與「中間過程」。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.5.0 | 2026-05-08 | `MagenticWorkflowBuilder`（Experimental） |
| 1.8.0 | 2026-05-28 | 新增 `SequentialWorkflowBuilder`、`ConcurrentWorkflowBuilder` 與共同基底 `OrchestrationBuilderBase`；Handoff orchestration 與 Python 對齊（PR #6138） |
| 1.9.0 | 2026-06-03 | **移除 Orchestrations 的 `[Experimental]`**（PR #6164）；Workflow Outputs Overhaul（PR #6045，`OutputTag`/`WithOutputFrom`/`WithIntermediateOutputFrom`）；`GroupChatManager` 語意對齊（PR #6140） |

## 教學章節對應

- 第 18 章：Workflows 基礎 — Sequential / Concurrent 模式（高階 builder 對照低階 `WorkflowBuilder.AddEdge`）
- 第 19 章：Workflows 進階 — Group Chat / Magentic 編排、輸出標註與過濾

## 相關概念

- [[workflows]]（低階 `WorkflowBuilder`）
- [[magentic-orchestration]]
- [[human-in-the-loop]]
- [[durable-agents]]
