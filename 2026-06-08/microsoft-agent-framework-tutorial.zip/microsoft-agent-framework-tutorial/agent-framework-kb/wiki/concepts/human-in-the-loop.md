---
title: Human-in-the-Loop — 人工介入確認
api_name: ToolApprovalAgent / ToolApprovalRequestContentExtensions
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [safety, approval, hitl]
tutorial_chapters: [ch16, ch19, ch21]
sources:
  - raw/adrs/0006-userapproval.md
  - raw/release-notes/dotnet-1.2.0.md
  - raw/release-notes/dotnet-1.6.1.md
---

## 概述

Human-in-the-Loop（HITL）讓代理在執行敏感操作前暫停等待人工確認。ADR 0006（Accepted）定義了標準的 `UserInputRequestContent` / `UserInputResponseContent` 型別體系，取代舊版 `IsApproved` 原地修改模式。`FunctionInvokingChatClient` 攔截需要確認的函式呼叫並自動產生 `FunctionApprovalRequestContent`，代理以 `AgentResponse.UserInputRequests` 聚合屬性回傳給呼叫端。

## 目前 API 簽名

```csharp
// 1. 標記需要確認的工具（工具層）
var tool = AIFunctionFactory.Create(TransferMoney);
var approvalTool = new ApprovalRequiredAIFunction(tool);

var agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Tools = [approvalTool],
});

// 2. 執行迴圈（ADR 0006 模式）
var response = await agent.RunAsync("將 $500 轉給 Alice", thread);

while (response.UserInputRequests.Any())
{
    var messages = new List<ChatMessage>();
    foreach (var req in response.UserInputRequests)
    {
        if (req is FunctionApprovalRequestContent approval)
        {
            // 向使用者顯示 approval.FunctionCall?.Arguments
            bool userApproved = AskUserForApproval(approval);

            messages.Add(new ChatMessage(ChatRole.User,
                userApproved
                    ? approval.CreateApproval()
                    : approval.CreateRejection()));
        }
    }
    // 傳入確認結果繼續執行
    response = await agent.RunAsync(messages, thread);
}

Console.WriteLine(response.Text);
```

### 核心型別（ADR 0006）

```csharp
// 基底型別
class UserInputRequestContent : AIContent { public string Id { get; set; } }
class UserInputResponseContent : AIContent { public string Id { get; set; } }

// 函式呼叫確認（最常用）
class FunctionApprovalRequestContent : UserInputRequestContent
{
    public FunctionCallContent FunctionCall { get; set; }
    public FunctionApprovalResponseContent CreateApproval() => ...;
    public FunctionApprovalResponseContent CreateRejection() => ...;
}

// AgentResponse 聚合屬性
class AgentResponse
{
    public IEnumerable<UserInputRequestContent> UserInputRequests { get; set; }
}
```

### Handoff HITL（v1.2.0 新增）

v1.2.0 引入 Handoff 型 HITL：工作流程中的代理可在特定條件下暫停並移交控制權給人工，人工審核後再繼續。與 `ApprovalRequiredAIFunction` 不同，Handoff 模式適合整個工作流程節點的暫停，而非單一工具呼叫的確認。

```csharp
// Workflow 中的 Handoff HITL（Durable 模式）
// 代理回傳 HandoffContent 時，框架暫停執行並等待外部事件
var response = await agent.RunAsync(messages, session);

if (response.FinishReason == ChatFinishReason.Handoff)
{
    // 通知人工審核（e.g., 發送 email 或 Slack 通知）
    await NotifyHumanReviewerAsync(response);

    // 等待人工繼續（可等待數小時）
    await session.WaitForResumeAsync();
}
```

### A2A input-request（v1.6.1 新增）

v1.6.1 A2A Protocol 新增 `input-request` 內容型別，讓代理在 A2A 對話中請求人工輸入：

```csharp
// A2A 代理回傳 input-request（v1.6.1）
// A2AAgentHandler 自動將 UserInputRequestContent 轉換為 A2A input-request 訊息
// 呼叫端 A2A Client 收到後需回傳 input-response 繼續執行
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025 Q3 | 初始設計：`ApprovalRequiredAIFunction` + `IsApproved` 模式 |
| 1.0.0 | 2026-04-02 | ADR 0006 Accepted：`UserInputRequestContent` / `FunctionApprovalRequestContent` 型別體系 |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.2.0 | 2026-04-21 | 新增 Handoff HITL Orchestration 支援：工作流程節點層級的人工介入移交 |
| 1.3.0 | 2026-04-24 | 無變更 |
| 1.4.0 | 2026-05-05 | 無變更 |
| 1.5.0 | 2026-05-08 | 無變更 |
| 1.6.1 | 2026-05-20 | A2A Protocol 新增 `input-request` 內容型別，HITL 流程可跨 A2A 邊界傳遞 |

## 教學章節對應

- 第 16 章：HITL 完整教學（Console、Web API、AG-UI 三種確認模式）
- 第 19 章：Workflow 版 HITL（`WaitForExternalEventAsync`）
- 第 21 章：Durable HITL 持久化

## 相關概念

- [[tools-ai-function]]
- [[middleware-pipeline]]
- [[ag-ui-protocol]]
- [[agent-response]]
