---
title: Agent 附加屬性（AdditionalProperties）
api_name: AdditionalPropertiesDictionary  # AgentWithMetadata 為 ADR-0017 提案，v1.6.1 尚未實作
namespace: Microsoft.Agents.AI / Microsoft.Extensions.AI
since: 1.0.0
current_version: 1.6.1
updated: 2026-05-20
tags: [metadata, extensibility, additional-properties, hosting]
tutorial_chapters: []
sources:
  - raw/adrs/0017-agent-additional-properties.md
---

## 概述

ADR 0017（Accepted，2026-02-24）定義了在 `AIAgent` 與 `AgentSession` 上附加任意 metadata 的機制。採用**外部容器/包裝物件**模式，而非修改核心框架類別，維持 metadata 的「非傳播語義」（執行期間不透傳）。

其他框架類型（`AgentRunOptions`、`AgentResponse`、`AgentResponseUpdate`）已使用 `Microsoft.Extensions.AI` 的 `AdditionalPropertiesDictionary`，此設計填補 `AIAgent`／`AgentSession` 的一致性缺口。

## 目前 API 簽名

```csharp
// 外部包裝器模式（ADR 0017 決策）
public class AgentWithMetadata
{
    public required AIAgent Agent { get; init; }
    public AdditionalPropertiesDictionary? AdditionalProperties { get; set; }
}

// 使用範例
var agentWithMeta = new AgentWithMetadata
{
    Agent = myAgent,
    AdditionalProperties = new AdditionalPropertiesDictionary
    {
        ["environment"] = "production",
        ["region"] = "eastus",
        ["protocol-version"] = "2.1",
    }
};
```

## 設計決策

- **不修改核心類別**：`AIAgent` 和 `AgentSession` 本身不加 `AdditionalProperties`
- **外部容器**：metadata 明確為附加層，避免傳播歧義
- **按需分配**：不需要 metadata 時不分配記憶體

## AgentSession 序列化備注

`AgentSession` 序列化使用預設 JSON 往返（複雜物件成為 `JsonElement`）。自訂 `JsonSerializerOptions` 搭配型別解析器可在需要時實現強型別反序列化。

## 教學章節對應

目前無對應章節（ADR 0017 為框架內部設計，教學中未有獨立說明）。使用情境見 [[feature-collections]] 和 [[agent-session]]。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| — | 2026-02-24 | ADR 0017 Accepted，定義外部容器模式 |
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |

## 相關概念

- [[feature-collections]]
- [[agent-session]]
- [[ai-agent]]
