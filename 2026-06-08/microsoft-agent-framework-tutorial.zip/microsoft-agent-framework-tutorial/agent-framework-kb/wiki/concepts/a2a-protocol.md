---
title: A2A Protocol — 代理間通訊協定
api_name: A2AServerServiceCollectionExtensions / A2AEndpointRouteBuilderExtensions / AgentCard
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-14
tags: [protocol, interop, cross-framework, human-in-the-loop]
tutorial_chapters: [ch23]
sources:
  - raw/samples/README.md
  - raw/release-notes/dotnet-1.3.0.md
  - raw/release-notes/dotnet-1.6.1.md
---

## 概述

A2A（Agent-to-Agent）Protocol 是 Google 主導的開放標準，讓不同框架的代理互相通訊。Agent Framework 透過 `A2AServerServiceCollectionExtensions`（v1.3.0 起）將代理註冊為 A2A 伺服端，並透過 `AgentCard` 描述代理能力。**v1.3.0 為 breaking 版本**：A2A SDK 由 0.3.4-preview 升至 1.0.0-preview2，hosting API 全面重構。

## ⚠️ v1.3.0 Breaking Change 摘要

| 移除項目 | 替代項目 |
|---------|---------|
| `EndpointRouteBuilderExtensions`（A2A 相關） | `A2AEndpointRouteBuilderExtensions` |
| `AIAgentExtensions`（A2A 部分） | `A2AServerServiceCollectionExtensions` |
| 具體 `A2AClient` 操作 | `IA2AClient` 介面操作 |
| `new A2AClient(uri)` 直接建構 | `A2AClientFactory.Create(...)` |

## 目前 API 簽名（v1.3.0）

```csharp
// 伺服端：v1.3.0 新 API
builder.Services.AddA2AServer(options =>
{
    options.AgentCard = new AgentCard
    {
        Name = "WeatherAgent",
        Description = "提供天氣查詢服務",
        Url = "https://myagent.example.com/a2a"
    };
    options.AgentFactory = sp => sp.GetRequiredService<AIAgent>();
});

// v1.3.0：改用 A2AEndpointRouteBuilderExtensions
app.MapA2AServer();   // 底層改由 A2AEndpointRouteBuilderExtensions 提供

// 客戶端：v1.3.0 改用工廠方法 + IA2AClient 介面
IA2AClient client = A2AClientFactory.Create(
    new Uri("https://remote-agent/a2a"),
    new A2AClientOptions { /* 協定偏好 */ });
var response = await client.SendMessageAsync("東京天氣如何？");
```

### Streaming 支援（v1.3.0 新增）

`A2AAgentHandler` 會依 `context.StreamingResponse` 自動路由：

```csharp
// streaming request → 自動呼叫 RunStreamingAsync（無需額外設定）
// non-streaming request → 原有 RunAsync 路徑
```

### input-request 內容支援（v1.6.1）

A2A 協定新增 `input-request` 內容類型，代理可在執行期間暫停並請求人工輸入（human-in-the-loop）。這讓多代理工作流程可以在關鍵決策點等待人工確認後再繼續。

```csharp
// 代理回傳 input-request 型別的訊息請求人工輸入
// 客戶端偵測到 input-request 後提示使用者輸入，再以 send-input 訊息繼續
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | 無 .NET A2A 變更 |
| 1.3.0 | 2026-04-24 | **[Breaking]** A2A SDK 0.3.4-preview → 1.0.0-preview2；新增 A2AAgentHandler、A2AServerServiceCollectionExtensions、A2AEndpointRouteBuilderExtensions；SSE reconnection；Streaming 支援 |
| 1.6.1 | 2026-05-14 | 新增 `input-request` 內容類型支援，實現 A2A human-in-the-loop 工作流程 |

## 教學章節對應

- 第 23 章：A2A Protocol 完整教學（Agent Card、跨框架整合、Continuation Token）
- 官方範例：`Agent-Framework-Samples/05.Providers` — A2A communication 通訊實例

## 相關概念

- [[ag-ui-protocol]]
- [[mcp-integration]]
- [[aspnet-core-hosting]]
