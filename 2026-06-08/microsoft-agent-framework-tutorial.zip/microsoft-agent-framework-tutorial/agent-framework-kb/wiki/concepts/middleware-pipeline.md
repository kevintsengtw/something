---
title: Middleware Pipeline — 中介軟體管線
api_name: WithDefaultAgentMiddleware
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [core, middleware, interceptor, decorator]
tutorial_chapters: [ch06, ch11, ch12]
sources:
  - raw/adrs/0007-agent-filtering-middleware.md
  - brainstorming/qa-sessions/2026-04-17-middleware-prompt-interception.md
---

## 概述

Middleware 是 Agent Framework 的攔截機制，讓開發者在代理執行前後插入自訂邏輯（日誌、安全檢查、Prompt 改寫、內容過濾等）。採用 Decorator Pattern 設計，透過 `AgentMiddlewareContext` + `AgentMiddlewareDelegate` 實現三層攔截：Agent 層、Tool 層、Provider 層。`context.Messages` 型別為 `IList<ChatMessage>`，**完全可讀可寫**，可在傳遞給 LLM 前對訊息進行任意增刪改。

## 目前 API 簽名

```csharp
// Builder Pattern 註冊 middleware
var agent = chatClient
    .AsAIAgent(options)
    .AsBuilder()
    .Use(async (context, next) =>
    {
        // 前處理
        Console.WriteLine($"收到：{context.Messages.Last().Text}");
        await next(context);  // 呼叫下一層
        // 後處理
        Console.WriteLine($"回應：{context.Response?.Text}");
    })
    .Build();

// AgentMiddlewareContext 核心屬性
public class AgentMiddlewareContext
{
    public AIAgent Agent { get; }
    public IList<ChatMessage> Messages { get; set; }
    public AgentRunOptions? Options { get; set; }
    public AgentResponse? Response { get; set; }
}

// AgentMiddlewareDelegate 委派
public delegate Task AgentMiddlewareDelegate(AgentMiddlewareContext context);

// Prompt Rewriting 模式（節省 Token）
// context.Messages 為可變 IList<ChatMessage>，可在傳給 LLM 前替換
.Use(async (context, next) =>
{
    // 找到最後一則 user 訊息
    int idx = -1;
    for (int i = context.Messages.Count - 1; i >= 0; i--)
        if (context.Messages[i].Role == ChatRole.User) { idx = i; break; }

    if (idx >= 0)
    {
        var original = context.Messages[idx].Text;
        var simplified = PreprocessAndSimplify(original); // 自訂預處理邏輯

        // 直接替換（A）、先移除再插入（B）或重建整個 list（C）
        context.Messages[idx] = new ChatMessage(ChatRole.User, simplified);
    }

    await next(context); // LLM 只看到精簡後的訊息
})
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025-09 | ADR 0007 Decorator Pattern 設計 |
| 1.0.0 | 2026-04-02 | GA，定型為 AgentMiddlewareContext + AgentMiddlewareDelegate |
| 1.1.0 | 2026-04-10 | 無 breaking changes |
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |

## 教學章節對應

- 第 06 章：Middleware 與 Context 基礎（三層架構完整教學）
- 第 11 章：ASP.NET Core 中的 middleware 整合
- 第 12 章：測試中 mock middleware 的做法

## 相關概念

- [[ai-agent]]
- [[context-providers]]
- [[human-in-the-loop]]
