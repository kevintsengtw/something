---
title: Agent Evaluation — 代理評估框架
api_name: IAgentEvaluator / FoundryEvals / agent.EvaluateAsync
namespace: Microsoft.Agents.AI
since: 1.0.0
current_version: 1.2.0
updated: 2026-04-23
tags: [quality, testing, evaluation, ci-cd, foundry]
tutorial_chapters: [ch28]
sources:
  - raw/adrs/0023-foundry-evals-integration.md
  - raw/release-notes/dotnet-1.2.0.md
  - raw/samples/README.md
---

## 概述

Agent Evaluation 框架以零摩擦的方式評估代理品質（ADR 0023，Accepted）。核心是 `IAgentEvaluator` 協定介面，讓 Azure Foundry 評估服務、本地自訂評估器、第三方函式庫（DeepEval、RAGAS、Promptfoo）統一接入。`agent.EvaluateAsync(queries, evaluators)` 是進入點，支援單代理與多代理工作流程、單輪與多輪對話評估。

## 目前 API 簽名

```csharp
// Azure AI Foundry 評估（雲端，結果可在 Foundry 入口查看）
var evals = new FoundryEvals(
    chatConfiguration,
    FoundryEvals.Relevance,
    FoundryEvals.Coherence,
    FoundryEvals.TaskAdherence,
    FoundryEvals.ToolCallAccuracy);

AgentEvaluationResults results = await agent.EvaluateAsync(
    new[]
    {
        "What's the weather in Seattle?",
        "Plan a weekend trip to Portland",
        "What restaurants are near Pike Place?",
    },
    evals);

results.AssertAllPassed();

// 自訂評估器（本地）
public class ResponseLengthEvaluator : IAgentEvaluator
{
    public Task<EvaluationResults> EvaluateAsync(
        IEnumerable<(string query, string response)> samples,
        EvaluationContext? context = null)
    {
        // 自訂評估邏輯
        return Task.FromResult(new EvaluationResults());
    }
}

var customEvals = new IAgentEvaluator[] { new ResponseLengthEvaluator() };
results = await agent.EvaluateAsync(queries, customEvals);
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA，IAgentEvaluator 協定、FoundryEvals 整合 |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.2.0 | 2026-04-21 | Foundry Evals Integration .NET GA（PR #4914, #5269） |

## 教學章節對應

- 第 28 章：Agent Evaluation 框架完整教學
- 官方範例：`Agent-Framework-Samples/08.EvaluationAndTracing` — DevUI visualization、evaluation metrics 實作

## 相關概念

- [[ai-agent]]
- [[opentelemetry]]
- [[llm-providers]]