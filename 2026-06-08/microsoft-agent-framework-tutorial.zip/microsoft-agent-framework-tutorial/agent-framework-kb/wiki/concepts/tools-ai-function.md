---
title: Tools / AIFunction — 代理工具系統
api_name: AIFunctionFactory
namespace: Microsoft.Extensions.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-14
tags: [core, tools, function-calling, shell-tool]
tutorial_chapters: [ch02, ch05, ch07, ch08, ch09, ch10]
sources:
  - raw/adrs/0002-agent-tools.md
  - raw/adrs/0021-agent-skills-design.md
  - raw/adrs/0025-foundry-toolbox-support.md
  - raw/samples/README.md
  - raw/samples/dotnet-sdk-samples.md
  - raw/release-notes/dotnet-1.3.0.md
  - raw/release-notes/dotnet-1.6.1.md
---

## 概述

工具（Tools）讓代理能夠「做事」。`AIFunctionFactory.Create()` 將 C# 方法轉換為 `AIFunction`，代理在對話中由 LLM 自動判斷何時呼叫工具。自 v1.1.0 起，多個相關工具可透過 `AgentClassSkill<T>` 打包為技能（Skill）。**v1.3.0 新增：** Foundry Toolbox 支援，可從 Azure AI Foundry 直接取得 server-side tools（`FoundryToolbox`）。

## 目前 API 簽名

```csharp
// 建立工具
AIFunction tool = AIFunctionFactory.Create(GetWeather);

// 註冊到代理
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Tools = [AIFunctionFactory.Create(GetWeather)],
});

// 工具方法定義
[Description("取得指定城市的天氣資訊")]
static string GetWeather([Description("城市名稱")] string city)
    => $"{city} 目前天氣晴朗";

// 支援的方法類型
// - 靜態方法、實例方法、Lambda、區域函式
// - 非同步方法（Task<T> / ValueTask<T>）
```

### ~~Foundry Toolbox~~（v1.3.0 新增；**v1.6.1 已移除**）

> ⚠️ **此 API 已於 v1.6.1 中移除（Breaking Change）。**
> `AIProjectClient.GetToolboxAsync()` 不再可用。詳見 [[foundry-toolbox]]（廢棄記錄）。
> 請改用 client-side 工具定義方式：`AIFunctionFactory.Create()`。

### Shell Tool（v1.6.1 新增）

允許代理執行本地 shell 命令作為工具呼叫：

```csharp
// 範例：加入 ShellTool（允許代理執行 shell 命令）
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Tools = [new ShellTool()],
});
```

> ⚠️ **安全注意：** 僅在受控環境（如 Hyperlight 沙盒、受信任部署）中啟用 Shell Tool，避免任意命令執行風險。

### Dynamic Function Tools（動態工具擴展）

透過 ambient `FunctionInvocationContext` 在函數迴圈執行中動態擴充工具清單（`Agent_Step20_DynamicFunctionTools`）：

```csharp
// 在工具執行回呼中取得目前呼叫上下文並擴充工具
// FunctionInvocationContext.Current 為 ambient 屬性
// 可在工具執行時動態加入更多 AIFunction
```

### Deep Research Tool

內建 `DeepResearchTool` 支援多步驟深度研究（`Agent_Step15_DeepResearch`）：

```csharp
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Tools = [new DeepResearchTool(...)],
});
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025 Q3 | AIFunctionFactory 設計 |
| 1.0.0 | 2026-04-02 | GA 釋出 |
| 1.1.0 | 2026-04-10 | 新增 Skill as class (PR #5027)，可將多個工具組織為類別 |
| 1.3.0 | 2026-04-24 | 新增 `FoundryToolbox` + `AIProjectClientToolboxExtensions`（Foundry Toolbox server-side tools，PR #5450） |
| 1.6.1 | 2026-05-14 | **[Breaking]** 移除 Foundry Toolbox server-side tools（`GetToolboxAsync()` 不再可用）；新增 Shell Tool |

## 教學章節對應

- 第 02 章：核心概念中的 Tools 說明
- 第 05 章：工具基礎完整教學
- 第 07-10 章：各範例皆使用工具
- 官方範例：`Agent-Framework-Samples/04.Tools` — Vision、Code Interpreter、Bing Search、File Search 工具實作

## 相關概念

- [[ai-agent]]
- [[agent-skills]]
- [[human-in-the-loop]]
