---
title: Prompt Injection 防禦 — FIDES
api_name: LabelTrackingFunctionMiddleware / PolicyEnforcementFunctionMiddleware / ContentVariableStore / VariableReferenceContent
namespace: Microsoft.Agents.AI
since: Proposed
current_version: Proposed
updated: 2026-05-06
tags: [security, prompt-injection, middleware, fides, information-flow, proposed]
tutorial_chapters: []
sources:
  - raw/adrs/0024-prompt-injection-defense.md
---

## 概述

FIDES（Flow Integrity Deterministic Enforcement System）是 ADR-0024 提出的確定性 Prompt Injection 防禦機制，基於資訊流控制（Information-Flow Control）理論。透過標籤式中介軟體，從源頭標記不信任內容，並在工具執行前強制執行安全政策，提供可驗證的安全保證（非啟發式）。系統為完全 opt-in，向後相容。

## 四個核心元件

| 元件 | 型別 | 功能 |
|------|------|------|
| 內容標籤系統 | `IntegrityLabel` / `ConfidentialityLabel` | 標記信任程度（TRUSTED/UNTRUSTED）與機密程度（PUBLIC/PRIVATE/USER_IDENTITY） |
| 中介軟體執行 | `LabelTrackingFunctionMiddleware` / `PolicyEnforcementFunctionMiddleware` | 自動傳播標籤；工具執行前執行政策檢查 |
| 變數間接層 | `ContentVariableStore` / `VariableReferenceContent` | 將不信任內容與 LLM context 物理隔離 |
| 隔離執行 | `quarantined_llm` / `inspect_variable` | 在隔離環境處理不信任資料，含稽核記錄 |

## 目前 API 簽名（Proposed）

```csharp
// 一行啟用安全代理配置（SecureAgentConfig）
var agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Middleware = SecureAgentConfig.DefaultMiddleware()
});

// 手動配置
var labelTracking = new LabelTrackingFunctionMiddleware(
    defaultLabel: IntegrityLabel.UNTRUSTED // 未標記內容預設為 UNTRUSTED
);
var policyEnforcement = new PolicyEnforcementFunctionMiddleware(
    policy: tool => tool.IsTrustedTool ? IntegrityLabel.TRUSTED : IntegrityLabel.UNTRUSTED
);

// 將不信任外部內容存入變數儲存（不直接注入 LLM context）
var store = new ContentVariableStore();
var varRef = store.Store("external-api-response", untrustedContent);
// 傳入 VariableReferenceContent 而非原始內容
```

## 標籤組合規則

採用「最嚴格優先（most-restrictive-wins）」政策：

| 輸入 A | 輸入 B | 結果 |
|--------|--------|------|
| TRUSTED | TRUSTED | TRUSTED |
| TRUSTED | UNTRUSTED | UNTRUSTED |
| UNTRUSTED | UNTRUSTED | UNTRUSTED |

## 與現有中介軟體的關係

FIDES 建立在現有 `FunctionMiddleware` 基底類別之上（ADR-0007），透過 `additional_properties` 附加標籤，不需修改核心內容型別。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| — | 2026-01-14 | ADR-0024 Proposed（contact: shruti） |
| — | — | 尚未 GA |

## 教學章節對應

- 目前無對應教學章節（功能尚 Proposed）
- 建議未來納入安全性進階章節

## 相關概念

- [[middleware-pipeline]]（建立在 FunctionMiddleware 之上）
- [[human-in-the-loop]]（ADR-0006，人工介入模式）
- [[tools-ai-function]]（工具政策配置對象）
