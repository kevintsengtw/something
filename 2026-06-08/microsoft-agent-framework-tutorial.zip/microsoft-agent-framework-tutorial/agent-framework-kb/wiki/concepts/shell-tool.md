---
title: Shell 工具
api_name: ShellExecutor / LocalShellExecutor / DockerShellExecutor
namespace: Microsoft.Agents.AI.Tools.Shell
since: 1.6.1
current_version: 1.6.1
updated: 2026-05-26
tags: [tools, shell, security, experimental]
tutorial_chapters: [ch05]
sources:
  - raw/release-notes/dotnet-1.6.1.md
  - raw/facts/dotnet-1.6.1-verified-changes.json
  - agent-framework/dotnet/src/Microsoft.Agents.AI.Tools.Shell/ShellExecutor.cs
  - agent-framework/dotnet/src/Microsoft.Agents.AI.Tools.Shell/LocalShellExecutor.cs
  - agent-framework/dotnet/src/Microsoft.Agents.AI.Tools.Shell/DockerShellExecutor.cs
  - agent-framework/dotnet/tests/Microsoft.Agents.AI.Tools.Shell.UnitTests/LocalShellExecutorTests.cs
---

## 概述

Shell Tool 功能讓代理能夠透過 `AIFunction` 介面將本地 shell 命令或 Docker 容器命令作為工具呼叫執行。核心抽象為 `ShellExecutor`（抽象基底類別），具體實作有 `LocalShellExecutor`（本機行程）與 `DockerShellExecutor`（Docker 容器沙箱）。預設啟用使用者審批機制（`ApprovalRequiredAIFunction`），是安全邊界的關鍵設計。

NuGet 套件：`Microsoft.Agents.AI.Tools.Shell`（自 v1.6.1 起）。

## 目前 API 簽名

```csharp
// 基底抽象類別
public abstract class ShellExecutor : IAsyncDisposable
{
    public virtual Task InitializeAsync(CancellationToken cancellationToken = default);
    public abstract Task<ShellResult> RunAsync(string command, CancellationToken cancellationToken = default);
    public abstract AIFunction AsAIFunction(string name = "run_shell", string? description = null, bool requireApproval = true);
    public abstract ValueTask DisposeAsync();
}

// 本機行程實作（預設 30 秒 timeout）
public sealed class LocalShellExecutor : ShellExecutor
{
    public static readonly TimeSpan DefaultTimeout = TimeSpan.FromSeconds(30);
    public LocalShellExecutor();
    public LocalShellExecutor(LocalShellExecutorOptions options);
    public string ResolvedShellBinary { get; }
    public override async Task<ShellResult> RunAsync(string command, CancellationToken cancellationToken = default);
    public override AIFunction AsAIFunction(string name = "run_shell", string? description = null, bool requireApproval = true);
}

// Docker 容器沙箱實作
public sealed class DockerShellExecutor : ShellExecutor
{
    // 繼承自 ShellExecutor，提供容器隔離執行環境
}
```

## 使用範例

```csharp
// 基本用法（預設 stateless 模式，啟用使用者審批）
var shell = new LocalShellExecutor(new LocalShellExecutorOptions
{
    Timeout = LocalShellExecutor.DefaultTimeout,
    MaxOutputBytes = 8192,
});
var shellFn = shell.AsAIFunction(requireApproval: true);

// 加入代理工具清單
var agent = new AIAgentBuilder()
    .WithChatClient(chatClient)
    .WithTool(shellFn)
    .Build();
```

## ShellMode（執行模式）

| 模式 | 說明 |
|------|------|
| `Stateless`（預設） | 每次命令啟動獨立子行程；工作目錄與環境變數不跨呼叫保留 |
| `Persistent` | 維護長生命週期的 shell 行程（`ShellSession`）；`cd`、環境變數跨呼叫保留；**不支援 cmd.exe** |

## 安全設計

- **`requireApproval: true`（預設）**：回傳的 `AIFunction` 被包裝為 `ApprovalRequiredAIFunction`；任何使用 `UseToolApproval()` 的代理在執行命令前會觸發 `ToolApprovalRequestContent`，供人工審批。
- **`requireApproval: false`**：需同時在 `LocalShellExecutorOptions` 設定 `AcknowledgeUnsafe = true`，否則 `AsAIFunction` 會拋出 `InvalidOperationException`。
- **`ShellPolicy`**：可自訂指令白名單/黑名單，在命令執行前由 `Evaluate(ShellRequest)` 決策；被拒絕命令拋出 `ShellCommandRejectedException`。
- **DockerShellExecutor**：透過 Docker 容器提供更強的隔離，適用於不信任命令的場景。

## 回傳結果（ShellResult）

```csharp
public record ShellResult(
    string Stdout,
    string Stderr,
    int ExitCode,
    TimeSpan Duration,
    bool Truncated,     // 輸出超過 MaxOutputBytes 時為 true
    bool TimedOut       // 超時時 ExitCode = 124
);
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.6.1 | 2026-05-14 | 首次引入 `ShellExecutor`、`LocalShellExecutor`、`DockerShellExecutor`（NuGet：`Microsoft.Agents.AI.Tools.Shell`） |

## 注意事項

- Shell Tool 應**僅限受控環境或有明確審批流程**的代理使用
- `Persistent` 模式不支援 `cmd.exe`；Windows 環境請改用 PowerShell（`pwsh`）
- 輸出預設截斷為 `MaxOutputBytes`（head + tail 保留策略），確認 `ShellResult.Truncated` 判斷是否完整

## 教學章節對應

- 第 05 章：工具基礎（Shell Tool 整合，`LocalShellExecutor` 與 `DockerShellExecutor` 使用方式）

## 相關概念

- [[tools-ai-function]]
- [[human-in-the-loop]]
- [[codeact-integration]]
