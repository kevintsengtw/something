---
title: Workflows — 工作流程編排
api_name: WorkflowBuilder / Executor
namespace: Microsoft.Agents.AI.Workflows
since: 1.0.0-preview
current_version: 1.9.0
updated: 2026-06-06
tags: [workflow, orchestration, executor, graph, handoff, hitl, concurrent, checkpoint]
tutorial_chapters: [ch18, ch19]
sources:
  - raw/release-notes/dotnet-1.1.0.md
  - raw/release-notes/dotnet-1.2.0.md
  - raw/samples/README.md
  - raw/samples/dotnet-sdk-samples.md
---

## 概述

Workflows 讓多個 Agent 或函式以 Graph-based 資料流連結。核心類別 `WorkflowBuilder` 建構有向圖，`Executor` 是圖中的執行節點。支援 Sequential、Concurrent（Fan-Out/Fan-In）、Conditional Edges、Sub-Workflows、Handoffs、HITL 六種以上模式，以及 Checkpointing、Shared States、Streaming 進階功能。

## 目前 API 簽名

```csharp
// 基本 WorkflowBuilder（Sequential）
Func<string, string> uppercaseFunc = s => s.ToUpperInvariant();
var uppercase = uppercaseFunc.BindAsExecutor("UppercaseExecutor");  // Lambda → Executor
var reverse = new ReverseTextExecutor();                            // 自訂 Executor

WorkflowBuilder builder = new(uppercase);  // 第一個節點
builder.AddEdge(uppercase, reverse)        // 連接 Executor
       .WithOutputFrom(reverse);           // 宣告輸出來源
var workflow = builder.Build();

// 進程內執行
await using Run run = await InProcessExecution.RunAsync(workflow, "Hello, World!");
foreach (WorkflowEvent evt in run.NewEvents)
{
    if (evt is ExecutorCompletedEvent executorComplete)
        Console.WriteLine($"{executorComplete.ExecutorId}: {executorComplete.Data}");
}

// AgentWorkflowBuilder（快速多代理模式）
var workflow = AgentWorkflowBuilder
    .CreateSequentialBuilder([agent1, agent2])
    .Build();

// 自訂 Executor
sealed class ReverseTextExecutor() : Executor<string, string>("ReverseTextExecutor")
{
    public override ValueTask<string> HandleAsync(
        string message, IWorkflowContext context, CancellationToken ct = default)
        => ValueTask.FromResult(string.Concat(message.Reverse()));
}
```

### 串流事件（03-workflows _StartHere/01_Streaming）

```csharp
await using Run run = await InProcessExecution.RunAsync(workflow, input);
await foreach (WorkflowEvent evt in run.NewEventsAsync(ct))
{
    // RunStartedEvent, ExecutorStartedEvent, ExecutorCompletedEvent,
    // RunCompletedEvent, RunErrorEvent 等
}
```

### 並行執行（Fan-Out/Fan-In）

```csharp
// Fan-Out：一個節點觸發多個下游
builder.AddEdge(source, branch1);
builder.AddEdge(source, branch2);
// Fan-In：多個節點合併到一個下游
builder.AddEdge(branch1, merge);
builder.AddEdge(branch2, merge);
```

### 條件邊（ConditionalEdges）

```csharp
builder.AddConditionalEdge(
    source: evaluator,
    condition: output => output.Score >= 0.8,
    target: publisher,
    fallback: reviser);
```

### Sub-Workflows

```csharp
// 子工作流程本身作為一個 Executor 嵌入
var subWorkflow = BuildSubWorkflow();
var subExecutor = subWorkflow.AsExecutor("SubWorkflow");
builder.AddEdge(parent, subExecutor);
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA，Handoff Orchestrations 標記 experimental |
| 1.1.0 | 2026-04-10 | Message Delivery Callback Overloads (PR #5081)；Handoff context 修復 (PR #5136)；Checkpoint 還原修復 (PR #5085) |
| 1.2.0 | 2026-04-21 | in-process workflow checkpoint-restore race condition 修復 (PR #5134) |
| 1.6.1 | 2026-05-14 | Workflow State 序列化修復（複雜型別 Checkpointing） |
| 1.8.0 | 2026-05-28 | Handoff Orchestration 與 Python 對齊（PR #6138）；`ForeachExecutor` 迭代狀態跨 checkpoint 持久化（PR #6051） |
| 1.9.0 | 2026-06-03 | **移除 Orchestrations 的 `[Experimental]` 標記**（PR #6164，含 Magentic/Handoff/GroupChat）；**Workflow Outputs Overhaul**（PR #6045）：支援以 `WithOutputFrom`/`WithIntermediateOutputFrom` 標註與過濾 agent 輸出；`GroupChatManager` 語意對齊 Orchestration patterns（PR #6140）；跨工作流程保留 `CreatedAt`（PR #3930） |

## 教學章節對應

- 第 18 章：Workflows 基礎（WorkflowBuilder、Executor、4 種模式）
- 第 19 章：Workflows 進階（Shared States、Checkpointing、Fan-Out/Fan-In、Declarative YAML）
- SDK 範例（`dotnet/samples/03-workflows`）：
  - `_StartHere/01_Streaming`：WorkflowEvent 串流
  - `_StartHere/02_AgentsInWorkflows`：AIAgent 作為 Executor
  - `_StartHere/03_AgentWorkflowPatterns`：Reflection、自我批評模式
  - `_StartHere/05_SubWorkflows`：子工作流程
  - `Concurrent/`：Fan-Out/Fan-In 並行
  - `ConditionalEdges/`：條件路由（Switch-Case、Multi-Selection）
  - `Orchestration/Handoff`：Handoff 交接模式
  - `Checkpoint/`：工作流程持久化
  - `HumanInTheLoop/`：HITL 工作流程
- 官方範例：`Agent-Framework-Samples/07.Workflow` — Basic、Sequential、Concurrent、Conditional 四種模式

## 相關概念

- [[orchestration-builders]]（v1.8.0+ 高階編排建構器：Sequential/Concurrent/GroupChat/Magentic）
- [[magentic-orchestration]]
- [[ai-agent]]
- [[durable-agents]]
- [[human-in-the-loop]]
