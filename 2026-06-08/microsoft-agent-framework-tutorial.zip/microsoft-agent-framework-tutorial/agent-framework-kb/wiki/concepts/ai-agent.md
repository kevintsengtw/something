---
title: AIAgent — 代理核心類別
api_name: AIAgent
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [core, agent, foundation]
tutorial_chapters: [ch01, ch02, ch04, ch07, ch08, ch09, ch10]
sources:
  - raw/adrs/0001-agent-run-response.md
  - raw/adrs/0011-create-get-agent-api.md
  - raw/release-notes/dotnet-1.0.0.md
  - raw/samples/README.md
---

## 概述

`AIAgent` 是 Microsoft Agent Framework 的核心代理類別，代表一個具有指令（instructions）、工具（tools）與 LLM 連線能力的 AI 代理。所有代理的建立最終都透過 `AsAIAgent()` 擴充方法或 `ChatClientAgentOptions` 設定產生。

**建立方式說明（ADR 0011）：** `.AsAIAgent()` 是唯一的正式建立方式。`CreateAIAgentAsync()` 與 `GetAIAgentAsync()` 已標記為過時（obsolete shims），僅保留向後相容，不應用於新程式碼。

## 目前 API 簽名

```csharp
// 建立代理（最常見模式）
AIAgent agent = chatClient.AsAIAgent(
    name: "MyAgent",
    instructions: "你是一個有幫助的助理");

// 帶工具的代理
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Name = "ToolAgent",
    Instructions = "...",
    Tools = [AIFunctionFactory.Create(MyMethod)],
});

// 核心方法
Task<AgentResponse> RunAsync(
    IEnumerable<ChatMessage> messages,
    AgentSession? session = null,
    AgentRunOptions? options = null,
    CancellationToken cancellationToken = default);

IAsyncEnumerable<AgentResponseUpdate> RunStreamingAsync(
    IEnumerable<ChatMessage> messages,
    AgentSession? session = null,
    AgentRunOptions? options = null,
    CancellationToken cancellationToken = default);
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025 Q3 | 初始設計 |
| 1.0.0-rc5 | 2026-03 | API 穩定化 |
| 1.0.0 | 2026-04-02 | GA 釋出，無 breaking changes |
| 1.1.0 | 2026-04-10 | 非破壞性更新 |
| 1.2.0 | 2026-04-21 | Foundry Hosted Agents 支援：`AIProjectClient` 可直接建立 Foundry 管理代理 |
| 1.3.0 | 2026-04-24 | 無變更 |
| 1.4.0 | 2026-05-05 | 無變更 |
| 1.5.0 | 2026-05-08 | 無變更 |
| 1.6.1 | 2026-05-20 | OpenTelemetryAgent 改為自動包裝（原需手動；breaking change 影響 OpenTelemetry 整合層，AIAgent 核心 API 未變更） |

## 教學章節對應

- 第 01 章：框架定位與 AIAgent 概念介紹
- 第 02 章：核心概念總覽，AIAgent 在架構中的角色
- 第 04 章：建立第一個 Agent（完整範例）
- 第 07-10 章：各種範例實作皆使用 AIAgent
- 官方範例：`Agent-Framework-Samples/02.CreateYourFirstAgent` — Travel Agent 完整實作、`Agent-Framework-Samples/03.ExploerAgentFramework` — 多提供者支援

## 相關概念

- [[agent-session]]
- [[agent-response]]
- [[chat-client]]
- [[tools-ai-function]]
