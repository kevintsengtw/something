---
title: ChatOptions — LLM 請求選項
api_name: ChatOptions
namespace: Microsoft.Extensions.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [core, llm, configuration, temperature, sampling]
tutorial_chapters: [ch03, ch04, ch06, ch17]
sources:
  - brainstorming/qa-sessions/2026-04-23-chatoptions-temperature.md
  - https://learn.microsoft.com/dotnet/api/microsoft.extensions.ai.chatoptions?view=net-10.0-pp
---

## 概述

`ChatOptions` 是 `Microsoft.Extensions.AI.Abstractions`（MEAI）定義的 LLM 請求選項型別，代表向底層 `IChatClient` 發出一次請求的所有可調整參數。Agent Framework 的代理在每次呼叫 LLM 時都在此層傳入設定。`ChatOptions` 屬於 **IChatClient 層**，與 Agent Framework 的 `AgentRunOptions`（AIAgent 層）平行——前者控制「如何呼叫 LLM」，後者控制「如何執行代理邏輯」。

## 目前 API 簽名

```csharp
// 命名空間：Microsoft.Extensions.AI
// Package：Microsoft.Extensions.AI.Abstractions v10.4.1

public class ChatOptions
{
    // === 採樣控制 ===
    public float?  Temperature { get; set; }   // 隨機性（0.0=確定性，2.0=高隨機）
    public float?  TopP        { get; set; }   // Nucleus sampling（勿與 Temperature 同時調整）
    public int?    TopK        { get; set; }   // 考慮的最高機率 token 數量

    // === 輸出控制 ===
    public int?    MaxOutputTokens { get; set; }
    public IList<string>? StopSequences { get; set; }
    public ChatResponseFormat? ResponseFormat { get; set; }   // 含 JSON Schema 支援

    // === 懲罰項 ===
    public float? FrequencyPenalty { get; set; }  // 重複懲罰（基於頻率）
    public float? PresencePenalty  { get; set; }  // 重複懲罰（基於存在）

    // === 模型 / 對話 ===
    public string? ModelId        { get; set; }   // 覆寫請求使用的模型
    public string? ConversationId { get; set; }   // 關聯現有對話
    public string? Instructions   { get; set; }   // per-request 額外指令

    // === 工具 ===
    public IList<AITool>?   Tools    { get; set; }
    public ChatToolMode?    ToolMode { get; set; }
    public bool?            AllowMultipleToolCalls { get; set; }

    // === 進階 ===
    public long?                     Seed                    { get; set; }   // 可重現性
    public ChatReasoningOptions?     Reasoning               { get; set; }   // CoT 推論
    public object?                   ContinuationToken       { get; set; }   // 非同步接續
    public bool?                     AllowBackgroundResponses { get; set; }  // 背景執行
    public AdditionalPropertiesDictionary? AdditionalProperties { get; set; }

    // === 方法 ===
    public ChatOptions Clone();  // 淺複製
}
```

### Temperature 詳解

```csharp
// 公式：P(token_i) = exp(logit_i / T) / Σ exp(logit_j / T)
//
// T → 0   : 幾乎確定選最高分 token（Greedy）
// T = 1.0 : 保持模型原始訓練分布（預設）
// T > 1.0 : 分布趨平，低機率 token 被選中機會增加

// 各場景建議值
var evalOptions     = new ChatOptions { Temperature = 0.0f };   // Evaluation（可重現）
var structuredOut   = new ChatOptions { Temperature = 0.2f };   // 結構化輸出 / 程式碼
var generalChat     = new ChatOptions { Temperature = 0.7f };   // 一般問答 / 客服
var creative        = new ChatOptions { Temperature = 1.0f };   // 創意寫作
// > 1.2 → 實驗性用途，生產環境不建議
// 1.6 以上 → 輸出高度隨機，常見於測試遺留或設定錯誤
```

### 在 Agent Framework 中設定 ChatOptions

`ChatOptions` 屬於 IChatClient 層，有兩種常見設定方式：

```csharp
// 方式 A：Chat Middleware 固定覆寫（per-run）
var client = chatClient
    .AsBuilder()
    .Use(async (messages, options, next, ct) =>
    {
        options ??= new ChatOptions();
        options.Temperature = 0.2f;
        return await next(messages, options, ct);
    })
    .Build();

var agent = client.AsAIAgent(name: "MyAgent", instructions: "...");

// 方式 B：建立 IChatClient 時固定（所有 run 共用）
// 通常透過提供者 SDK 的 ChatClientOptions 設定，各提供者做法不同
```

> ⚠️ `AgentRunOptions`（Agent Framework 層）**沒有** `Temperature` 屬性。需要 per-call 控制 Temperature 時，必須在 IChatClient 層透過 Middleware 注入。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| MEAI preview | 2024 | `ChatOptions` 定義於 Microsoft.Extensions.AI.Abstractions |
| 1.0.0 | 2026-04-02 | Agent Framework GA，`ChatOptions` 作為底層 LLM 選項型別 |
| MEAI v10.4.1 | 2026 | 新增 `AllowBackgroundResponses`、`ContinuationToken`、`Reasoning` 等屬性 |
| 1.6.1 | 2026-05-20 | 驗證相容性：`ChatOptions` 屬 MEAI 層，API 未變更，相容 v1.6.1 |

## 教學章節對應

- 第 03 章：NuGet 套件（Microsoft.Extensions.AI.Abstractions 作為底層依賴）
- 第 04 章：第一個代理（ChatClient 的選項傳遞）
- 第 06 章：Middleware（透過 Chat Middleware 注入 ChatOptions）
- 第 17 章：多 LLM 提供者（各提供者共用 ChatOptions 介面）

## 相關概念

- [[chat-client]]
- [[middleware-pipeline]]
- [[structured-output]]
- [[run-async]]
- [[long-running-operations]]
