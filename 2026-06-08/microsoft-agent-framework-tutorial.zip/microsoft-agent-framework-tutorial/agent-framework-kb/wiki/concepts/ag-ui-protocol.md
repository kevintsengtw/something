---
title: AG-UI Protocol — 代理使用者互動協定
api_name: AGUIAgent / MapAGUI
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [protocol, streaming, sse, frontend]
tutorial_chapters: [ch11, ch24]
sources:
  - raw/adrs/0010-ag-ui-support.md
  - raw/release-notes/dotnet-1.5.0.md
---

## 概述

AG-UI（Agent-User Interaction）Protocol 是代理與前端應用之間的標準化串流協定，基於 SSE（Server-Sent Events）。框架提供 `AGUIAgent`（客戶端）與 `MapAGUI`（ASP.NET Core 伺服端），事件類型包含 RunStarted、TextMessageStart、ToolCallStart 等。注意：`thread_id` 是 AG-UI 協定層級欄位，與 AgentSession 的命名無關。

## 目前 API 簽名

```csharp
// ASP.NET Core 伺服端
app.MapAGUI("/api/agent", agent);

// 或搭配 Agent Factory（多租戶）
app.MapAGUI("/api/agent", async (context) =>
{
    var userId = context.User.Identity?.Name;
    return chatClient.AsAIAgent(...);
});

// AG-UI 客戶端
var agentClient = new AGUIAgent(new Uri("http://localhost:5000/api/agent"));
var response = await agentClient.RunAsync("你好");

// SSE 事件類型
// RunStarted, RunFinished, RunError
// TextMessageStart, TextMessageContent, TextMessageEnd
// ToolCallStart, ToolCallEnd
// StateSnapshotStart, StateSnapshotContent, StateSnapshotEnd
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025-10 | ADR 0010 定義 |
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.5.0 | 2026-05-08 | 新增推理事件（Reasoning Events）串流支援（PR #4953）|
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |

## 教學章節對應

- 第 11 章：ASP.NET Core WebAPI 整合（MapAGUI 用法）
- 第 24 章：AG-UI Protocol 深度（事件類型、State Management、前後端工具）

## 相關概念

- [[aspnet-core-hosting]]
- [[structured-output]]
- [[a2a-protocol]]
