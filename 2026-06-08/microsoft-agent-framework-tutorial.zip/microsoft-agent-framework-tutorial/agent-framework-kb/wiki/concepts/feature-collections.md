---
title: Feature Collections — 執行期功能注入
api_name: AgentRunOptions.Features / AdditionalProperties
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [advanced, per-run, di, extensibility]
tutorial_chapters: [ch27]
sources:
  - raw/adrs/0014-feature-collections.md
---

## 概述

Feature Collections 讓開發者在每次代理執行時注入任意服務或資料。透過 `AgentRunOptions` 的 `AdditionalProperties` 字典搭配型別安全擴充方法實現。適用於：per-run ChatMessageStore 覆寫、結構化輸出配置、自訂 Decorator 狀態傳遞等。

## 目前 API 簽名

```csharp
// 設定 Feature
var response = await agent.RunAsync(userInput, session,
    new AgentRunOptions
    {
        Features = new AgentFeatureCollection()
            .WithFeature<ChatMessageStore>(messageStore)
    });

// 擴充方法語法
options.AdditionalProperties.WithFeature(new MyFeature());

// 取出 Feature
if (options.AdditionalProperties.TryGetFeature<MyFeature>(out var feature))
{
    // 使用 feature
}
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| — | 2025-01 | ADR 0014 定義 |
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |

## 教學章節對應

- 第 27 章：Feature Collections 完整教學

## 相關概念

- [[structured-output]]
- [[middleware-pipeline]]
