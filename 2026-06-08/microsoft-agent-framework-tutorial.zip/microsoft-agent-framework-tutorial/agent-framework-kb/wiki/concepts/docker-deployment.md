---
title: Docker 部署
api_name: N/A (DevOps)
namespace: N/A
since: N/A
current_version: 1.6.1
updated: 2026-05-20
tags: [deployment, docker, ci-cd, devops]
tutorial_chapters: [ch13]
sources: []
---

## 概述

Docker 部署教學涵蓋多階段 Dockerfile、docker-compose 編排、Secret 管理（user-secrets → 環境變數）、CI/CD 整合（GitHub Actions）。適用於將 Agent Framework WebAPI 應用容器化部署。

## 關鍵設定

```dockerfile
# 多階段 Dockerfile
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build
WORKDIR /src
COPY *.csproj .
RUN dotnet restore
COPY . .
RUN dotnet publish -c Release -o /app

FROM mcr.microsoft.com/dotnet/aspnet:8.0
WORKDIR /app
COPY --from=build /app .
EXPOSE 8080
ENTRYPOINT ["dotnet", "MyAgent.dll"]
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA 釋出，部署模式文件定稿 |
| 1.6.1 | 2026-05-20 | 驗證相容性：Dockerfile 模式未變更，相容 v1.6.1 |

## 教學章節對應

- 第 13 章：Docker 部署完整教學

## 相關概念

- [[aspnet-core-hosting]]
