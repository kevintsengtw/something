---
title: AgentSession — 對話會話管理
api_name: AgentSession
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.1.0
updated: 2026-04-17
tags: [core, session, state, persistence]
tutorial_chapters: [ch02, ch04, ch14, ch20, ch21]
sources:
  - raw/adrs/0018-agentthread-serialization.md
  - raw/release-notes/dotnet-1.0.0.md
  - raw/release-notes/dotnet-1.1.0.md
  - raw/samples/dotnet-sdk-samples.md
---

## 概述

`AgentSession` 管理代理的對話狀態，包含聊天歷史與 Context Provider 狀態。原名 `AgentThread`，根據 ADR 0018 重新命名為 `AgentSession`，以更準確地反映有狀態對話的概念。支援 `System.Text.Json` 標準序列化。

## 目前 API 簽名

```csharp
// 建立新 session
AgentSession session = await agent.CreateSessionAsync();

// 多輪對話
var response1 = await agent.RunAsync("你好", session);
var response2 = await agent.RunAsync("謝謝", session);

// 序列化 / 反序列化（含 Context Provider 狀態）
JsonElement element = await agent.SerializeSessionAsync(session);
AgentSession restored = await agent.DeserializeSessionAsync(element);

// 跨 session 共享記憶體狀態
var newSession = await agent.CreateSessionAsync();
if (agent.GetService<UserInfoMemory>() is UserInfoMemory memory)
    memory.SetUserInfo(newSession, memory.GetUserInfo(oldSession));

// 搭配 FoundryAgent（v1.1.0 新增多載）
AgentSession session = await foundryAgent.CreateSessionAsync(conversationId);
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025 Q3 | 初始設計為 `AgentThread` |
| 1.0.0-rc | 2026-02 | ADR 0018：重新命名為 `AgentSession`，StateBag 設計 |
| 1.0.0 | 2026-04-02 | GA 釋出 |
| 1.1.0 | 2026-04-10 | FoundryAgent.CreateSessionAsync(conversationId) 新增多載 (PR #5144) |

## 教學章節對應

- 第 02 章：核心概念中的 AgentSession 說明
- 第 04 章：多輪對話範例
- 第 14 章：Context Providers 與 ProviderSessionState
- 第 20-21 章：Durable Agents 持久化 session

## 相關概念

- [[ai-agent]]
- [[context-providers]]
- [[provider-session-state]]
- [[chat-history-persistence]]
