---
title: ChatClient — LLM 通訊介面抽象
api_name: IChatClient
namespace: Microsoft.Extensions.AI
since: 1.0.0-preview
current_version: 1.1.0
updated: 2026-04-17
tags: [core, llm, provider, abstraction]
tutorial_chapters: [ch02, ch03, ch04, ch17]
sources:
  - raw/devblogs/github-readme-overview.md
  - raw/samples/README.md
---

## 概述

`IChatClient` 是 `Microsoft.Extensions.AI` 定義的標準介面，作為框架與 LLM 提供者之間的通訊橋樑。Agent Framework 透過此介面實現提供者無關的設計，支援 OpenAI、Azure OpenAI、Anthropic、Ollama、Gemini 等。

## 目前 API 簽名

```csharp
// OpenAI
IChatClient client = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o-mini")
    .AsAIChatClient();

// Azure OpenAI
IChatClient client = new AzureOpenAIClient(endpoint, credential)
    .GetChatClient(deployment)
    .AsAIChatClient();

// Anthropic
IChatClient client = new AnthropicClient() { ApiKey = key };

// Ollama
IChatClient client = new OllamaApiClient(new Uri("http://localhost:11434"), "llama3");

// 轉換為代理
AIAgent agent = client.AsAIAgent(name: "MyAgent", instructions: "...");
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | Anthropic SDK 12.8.0 → 12.11.0; 新增 gpt-5.4-mini 支援 |

## 教學章節對應

- 第 02 章：ChatClient 概念與支援的提供者
- 第 03 章：開發環境設定（安裝 NuGet 套件）
- 第 04 章：建立代理時使用 ChatClient
- 第 17 章：7 種 LLM 提供者的完整整合教學
- 官方範例：`Agent-Framework-Samples/03.ExploerAgentFramework` — AzureOpenAIClient、OpenAIClient、PersistentAgentsClient 使用範例

## 相關概念

- [[ai-agent]]
- [[llm-providers]]
- [[middleware-pipeline]]
