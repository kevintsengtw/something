---
title: NuGet 套件總覽
api_name: Microsoft.Agents.AI (及相關套件)
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-14
tags: [packages, installation, setup]
tutorial_chapters: [ch03, appendix-a]
sources:
  - raw/release-notes/dotnet-1.0.0.md
  - raw/release-notes/dotnet-1.1.0.md
  - raw/release-notes/dotnet-1.2.0.md
  - raw/release-notes/dotnet-1.3.0.md
  - raw/release-notes/dotnet-1.4.0.md
  - raw/release-notes/dotnet-1.5.0.md
  - raw/release-notes/dotnet-1.6.1.md
---

## 概述

Agent Framework 的 .NET 實作分為多個 NuGet 套件，核心為 `Microsoft.Agents.AI`。自 v1.0.0 GA 起不需要 `--prerelease` 旗標。目前最新穩定版為 **1.6.1（2026-05-14）**。

## 套件清單

| 套件 | 用途 |
|------|------|
| `Microsoft.Agents.AI` | 核心抽象（AIAgent、AgentSession、Middleware） |
| `Microsoft.Agents.AI.OpenAI` | OpenAI / Azure OpenAI 整合 |
| `Microsoft.Agents.AI.Workflows` | 工作流程編排（WorkflowBuilder、Executor） |
| `Microsoft.Agents.AI.Workflows.Declarative` | 宣告式 YAML 工作流程 |
| `Microsoft.Agents.AI.Hosting` | ASP.NET Core 託管（MapAGUI） |
| `Microsoft.Agents.AI.Hosting.A2A` | A2A server hosting（v1.3.0：A2AAgentHandler、A2AServerServiceCollectionExtensions） |
| `Microsoft.Agents.AI.A2A` | A2A client（v1.3.0：升級至 A2A SDK 1.0.0-preview2） |
| `Microsoft.Agents.AI.Foundry` | Azure AI Foundry 整合（v1.0.0 起由 AzureAI 改名） |
| `Microsoft.Agents.AI.Foundry.Hosting` | Foundry Hosted Agent 支援（v1.3.0：新增 FoundryToolbox） |
| `Microsoft.Agents.AI.Anthropic` | Anthropic Claude 整合（prerelease） |
| `Microsoft.Agents.AI.Hosting.Aspire` | .NET Aspire 整合（v1.3.0：preview 狀態） |
| `Microsoft.Agents.AI.Hyperlight` | CodeAct 整合（v1.4.0 GA，Hyperlight 沙盒） |

## 安裝

```bash
dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.OpenAI
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

## 目前 API 簽名

不適用（本條目為套件參考表，無單一核心 API 簽名；各套件的 API 定義見對應的 wiki 條目）。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-rc5 | 2026-03 | AzureAI → Foundry 改名 |
| 1.0.0 | 2026-04-02 | GA；移除 `OpenAIAssistantClientExtensions` 類別 (PR #5058) |
| 1.1.0 | 2026-04-10 | Anthropic SDK 12.8.0 → 12.11.0；新增 gpt-5.4-mini |
| 1.2.0 | 2026-04-21 | Foundry Hosted Agents、Foundry Evals、Handoff 重構 |
| 1.3.0 | 2026-04-24 | **[Breaking]** A2A SDK v1 遷移；A2A streaming；Foundry Toolbox（.NET）；新增 `Microsoft.ML.Tokenizers` 依賴 |
| 1.4.0 | 2026-05-05 | **[Breaking]** file-based skill scripts 參數改為 `string[]`；新增 `Microsoft.Agents.AI.Hyperlight`（CodeAct GA）；OpenTelemetry 升級至 1.15.3 |
| 1.5.0 | 2026-05-08 | 新增 Magentic Orchestration（Experimental）；AG-UI Reasoning Events；WebBrowsingTool allow listing；MEAI 10.5.1；**本版本無 Breaking Changes** |
| 1.6.1 | 2026-05-14 | **[Breaking]** `OpenTelemetryAgent` 自動包裝 `ChatClient`；Foundry Toolbox server-side tools 移除；新增 `IChatMessageInjector`、Shell Tool、`AgentSessionFiles`；A2A input-request 支援；跳過 1.6.0（patch 直發） |

## 教學章節對應

- 第 03 章：開發環境準備（安裝套件）
- 附錄 A：NuGet 套件參考表

## 相關概念

- [[chat-client]]
- [[llm-providers]]
