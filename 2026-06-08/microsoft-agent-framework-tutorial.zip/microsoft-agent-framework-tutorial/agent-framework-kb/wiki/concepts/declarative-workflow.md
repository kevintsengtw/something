---
title: Declarative Workflow — 宣告式工作流程
api_name: DeclarativeWorkflow
namespace: Microsoft.Agents.AI.Workflows.Declarative
since: 1.0.0-preview
current_version: 1.9.0
updated: 2026-06-06
tags: [workflow, yaml, declarative, no-code, v1.9.0-stable]
tutorial_chapters: [ch19]
sources:
  - raw/release-notes/dotnet-1.2.0.md
  - raw/release-notes/dotnet-1.4.0.md
  - raw/release-notes/dotnet-1.8.0.md
  - raw/release-notes/dotnet-1.9.0.md
  - raw/facts/dotnet-1.9.0-verified-changes.json
---

## 概述

Declarative Workflow 讓非開發者透過 YAML 檔案定義工作流程，無需撰寫 C# 程式碼。框架在執行時解析 YAML 並建構對應的 WorkflowBuilder 圖。支援 Sequential、Concurrent、Handoff 等模式，可搭配 Azure Foundry 部署。

## 目前 API 簽名

```yaml
# Marketing.yaml
name: MarketingWorkflow
steps:
  - name: research
    agent: ResearchAgent
    input: $input
  - name: draft
    agent: WriterAgent
    input: $research.output
  - name: review
    agent: ReviewerAgent
    input: $draft.output
```

```csharp
// C# 載入
var workflow = await DeclarativeWorkflow.LoadAsync("Marketing.yaml");
var result = await workflow.RunAsync("請撰寫 Q2 行銷計畫");
```

### HttpRequestAction（v1.4.0 新增，PR #5474）

在 YAML 定義中直接配置 HTTP 呼叫步驟，無需撰寫 C# 工具程式碼：

```yaml
# 宣告式 HTTP 呼叫
steps:
  - name: fetch-weather
    type: HttpRequestAction
    url: https://api.example.com/weather
    method: GET
    headers:
      Authorization: Bearer $token
    output: $weatherData
  - name: summarize
    agent: SummaryAgent
    input: $weatherData
```

對應範例：`dotnet/samples/03-workflows/Declarative/InvokeHttpRequest`

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025-11 | 初始 YAML 宣告式工作流程設計 |
| 1.0.0 | 2026-04-02 | GA 釋出 |
| 1.4.0 | 2026-05-05 | 新增 `HttpRequestAction` 步驟型別（PR #5474）；Hosting 層更新整合（PR #5589） |
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |
| 1.8.0 | 2026-05-28 | **[Breaking]** 移除宣告式工作流程的 code-gen 支援（PR #6095），改為純執行期解譯；`ForeachExecutor` 迭代狀態可跨 checkpoint 持久化（PR #6051） |
| 1.9.0 | 2026-06-03 | **`Microsoft.Agents.AI.Workflows.Declarative` 套件轉 stable**（PR #6254）：安裝不再需要 `--prerelease`；修正 `InvokeMcpTool` 在宣告式工作流程的核准路徑（PR #6177） |

## 教學章節對應

- 第 19 章：Workflows 進階（Declarative Workflow 段落）

## 相關概念

- [[workflows]]
