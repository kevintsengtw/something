---
title: Durable Agents — 持久化代理
api_name: ConfigureDurableAgents / DurableTaskScheduler
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [durable, persistence, orchestration, azure-functions]
tutorial_chapters: [ch20, ch21]
sources:
  - raw/release-notes/dotnet-1.1.0.md
  - raw/release-notes/dotnet-1.2.0.md
  - raw/release-notes/dotnet-1.3.0.md
  - raw/release-notes/dotnet-1.4.0.md
  - raw/samples/dotnet-sdk-samples.md
---

## 概述

Durable Agents 讓代理對話與工作流程在 process restart 後仍能恢復。基於 Azure Durable Task Framework，使用 Durable Entity 持久化 Agent Session，支援長時間等待人工審批（數小時至數天）。提供 Azure Functions 與 Console App 兩種部署模式。

## 目前 API 簽名

```csharp
// Azure Functions 模式（簡化版，dotnet/samples/01-get-started/06_host_your_agent）
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(instructions: "You are a helpful assistant.", name: "HostedAgent");

using IHost app = FunctionsApplication.CreateBuilder(args)
    .ConfigureFunctionsWebApplication()
    .ConfigureDurableAgents(options => options.AddAIAgent(agent, timeToLive: TimeSpan.FromHours(1)))
    .Build();
app.Run();
// → 自動產生 POST /api/agents/HostedAgent/run 端點
// NuGet: Microsoft.Agents.AI.Hosting.AzureFunctions

// Azure Functions 模式（DI 版）
var builder = FunctionsApplication.CreateBuilder(args);
builder.ConfigureDurableAgents(agents =>
{
    agents.AddChatCompletionAgent("MyAgent", sp =>
        sp.GetRequiredService<IChatClient>()
          .AsAIAgent(name: "MyAgent", instructions: "..."));
});

// Console 模式 + Durable Orchestration
await using var host = DurableTaskScheduler.CreateEmulatorBuilder()
    .AddDurableAgent(chatClient.AsAIAgent(...))
    .Build();
await host.StartAsync();

// Session TTL
agents.AddChatCompletionAgent("MyAgent", agentFactory,
    options: new() { TimeToLive = TimeSpan.FromHours(2) });
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | Checkpoint 還原修復 (PR #5085)；Entity key validation (PR #5179)；Compaction 重複修復 (PR #5149) |
| 1.2.0 | 2026-04-21 | 修正 in-process workflow checkpoint-restore race condition (PR #5134) |
| 1.3.0 | 2026-04-24 | 修正 `StreamingRunEventStream.RunLoopAsync` RunStatus off-thread race：`GetStatusAsync` 在 `ResumeAsync` halt 後誤回傳 Running（PR #5412，Closes #5411）；`LockstepRunEventStream` 不受影響 |
| 1.4.0 | 2026-05-05 | HTTP trigger endpoint 支援回傳 durable workflow 執行結果（PR #5321）；不再只回傳 202 Accepted |
| 1.6.1 | 2026-05-14 | 修復 Durable Agent Session TTL 過期計時邏輯 |

## 教學章節對應

- 第 20 章：Durable Agents 概念與架構
- 第 21 章：實作（Azure Functions、Console、多代理、HITL 持久化）

## 相關概念

- [[workflows]]
- [[agent-session]]
- [[chat-history-persistence]]
