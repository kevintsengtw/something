---
title: Agent Skills — 技能系統
api_name: AgentClassSkill<T> / AgentInlineSkill / AgentSkillsProvider / AgentSkillsProviderBuilder
namespace: Microsoft.Agents.AI
since: 1.1.0
current_version: 1.9.0
updated: 2026-06-06
tags: [skills, class-based, inline-skill, file-based, provider-builder, v1.1.0, v1.4.0-breaking, v1.7.0-async, v1.8.0-breaking]
tutorial_chapters: [ch05, ch29, appendix-d]
sources:
  - raw/adrs/0021-agent-skills-design.md
  - raw/release-notes/dotnet-1.1.0.md
  - raw/release-notes/dotnet-1.4.0.md
  - raw/release-notes/dotnet-1.5.0.md
  - raw/release-notes/dotnet-1.7.0.md
  - raw/release-notes/dotnet-1.8.0.md
  - raw/devblogs/agent-skills-three-ways.md
  - raw/learn/agent-skills.md
  - raw/samples/README.md
  - raw/facts/dotnet-1.7.0-verified-changes.json
  - raw/facts/dotnet-1.8.0-verified-changes.json
---

## 概述

Agent Skills 是 v1.1.0 GA 的技能系統，讓開發者將相關工具、資源（Resources）與腳本（Scripts）打包為可攜式、可重用的套件。代理透過漸進式揭露（Progressive Disclosure）只在需要時載入技能內容，保持 context window 精簡。

支援四種技能來源：
1. **File-Based** — `SKILL.md` 檔案目錄（含資源、腳本）（v1.1.0）
2. **Class-Based** — 繼承 `AgentClassSkill<T>` 的 C# 類別（v1.1.0）
3. **Code-Defined（Inline）** — `AgentInlineSkill` 在程式碼中定義（v1.1.0）
4. **MCP-Based** — 透過 MCP 伺服器探索技能（skill-md 類型，`AgentMcpSkillsSource`）（v1.8.0，PR #6108）

> **⚠️ 教學 drift 警告**：ch05（第597行）與 appendix-d（第132行）使用舊版 `AgentClassSkill`（非泛型），正式 API 為 `AgentClassSkill<T>`。`AgentInlineSkill` 在教學中仍標記為 Proposed，但已於 v1.1.0 GA 發布。

## 漸進式揭露（四階段）

| 階段 | 工具 | Token 成本 |
|------|------|-----------|
| Advertise | system prompt 注入技能名稱/描述 | ~100 tokens/技能 |
| Load | `load_skill` | 建議 < 5000 tokens |
| Read | `read_skill_resource` | 按需 |
| Run | `run_skill_script` | 按需 |

## 目前 API 簽名

### 1. Class-Based Skills (`AgentClassSkill<T>`)

```csharp
using System.ComponentModel;
using System.Text.Json;
using Microsoft.Agents.AI;

// 繼承 AgentClassSkill<T>（泛型，T = 自身類別）
internal sealed class UnitConverterSkill : AgentClassSkill<UnitConverterSkill>
{
    public override AgentSkillFrontmatter Frontmatter { get; } = new(
        "unit-converter",
        "Convert between common units using a multiplication factor.");

    protected override string Instructions => """
        Use this skill when the user asks to convert between units.
        1. Review the conversion-table resource to find the correct factor.
        2. Use the convert script, passing the value and factor from the table.
        """;

    // 屬性 → Resource（[AgentSkillResource] + [Description]）
    [AgentSkillResource("conversion-table")]
    [Description("Lookup table of multiplication factors for common unit conversions.")]
    public string ConversionTable => """
        | From       | To         | Factor   |
        |------------|------------|----------|
        | miles      | kilometers | 1.60934  |
        | kilometers | miles      | 0.621371 |
        """;

    // 靜態方法 → Script（[AgentSkillScript] + [Description]）
    [AgentSkillScript("convert")]
    [Description("Multiplies a value by a conversion factor and returns the result as JSON.")]
    private static string ConvertUnits(double value, double factor)
    {
        double result = Math.Round(value * factor, 4);
        return JsonSerializer.Serialize(new { value, factor, result });
    }
}

// 註冊
var skill = new UnitConverterSkill();
var skillsProvider = new AgentSkillsProvider(skill);

// 透過 DI 注入（需在 ServiceCollection 中先註冊）
services.AddSingleton<UnitConverterSkill>();
var skill = serviceProvider.GetRequiredService<UnitConverterSkill>();
```

### 2. Code-Defined Skills (`AgentInlineSkill`)

```csharp
// 靜態資源 + 內聯腳本（in-process，不需 script runner）
var unitConverterSkill = new AgentInlineSkill(
    name: "unit-converter",
    description: "Convert between common units using a conversion factor",
    instructions: """
        1. Review the conversion-table resource to find the correct factor.
        2. Use the convert script, passing the value and factor.
        """)
    .AddResource(
        "conversion-table",
        """
        | From  | To   | Factor  |
        | miles | km   | 1.60934 |
        """)
    .AddScript("convert", (double value, double factor) =>
    {
        double result = Math.Round(value * factor, 4);
        return JsonSerializer.Serialize(new { value, factor, result });
    });

// 動態資源（每次讀取時執行 factory）
var projectInfoSkill = new AgentInlineSkill(
    name: "project-info",
    description: "Current project configuration",
    instructions: "Use this skill for project questions.")
    .AddResource("environment", () =>
    {
        string env = Environment.GetEnvironmentVariable("APP_ENV") ?? "development";
        return $"Environment: {env}";
    });

var skillsProvider = new AgentSkillsProvider(unitConverterSkill);
```

### 3. File-Based Skills

```
skills/
└── expense-report/
    ├── SKILL.md       # 必要：YAML frontmatter + 指令
    ├── scripts/
    │   └── validate.py
    └── references/
        └── POLICY_FAQ.md
```

```csharp
// 單一目錄（自動探索兩層深度）
var skillsProvider = new AgentSkillsProvider(
    Path.Combine(AppContext.BaseDirectory, "skills"),
    SubprocessScriptRunner.RunAsync);  // 啟用腳本執行

// 自訂資源/腳本探索規則（v1.8.0 PR #6109：改為 depth-based discovery + 述詞過濾）
var fileOptions = new AgentFileSkillsSourceOptions
{
    AllowedResourceExtensions = [".md", ".txt"],
    AllowedScriptExtensions = [".py"],
    SearchDepth = 2,   // 每個技能目錄向下搜尋的層數（預設 2；1 = 僅技能根目錄）
    // 以述詞過濾要納入的檔案（取代舊版的 ResourceDirectories/ScriptDirectories 目錄白名單）
    ResourceFilter = ctx => ctx.RelativePath.StartsWith("references/"),
    ScriptFilter   = ctx => ctx.RelativePath.StartsWith("scripts/"),
};
var skillsProvider = new AgentSkillsProvider(
    Path.Combine(AppContext.BaseDirectory, "skills"),
    fileOptions: fileOptions);
```

> **⚠️ v1.8.0 Breaking（PR #6109）**：`AgentFileSkillsSourceOptions` 由「目錄白名單」（`ResourceDirectories`/`ScriptDirectories`）重構為「深度探索 + 述詞過濾」（`SearchDepth`、`ResourceFilter`、`ScriptFilter`，述詞收到含 `SkillName` 與 `RelativePath` 的 `AgentFileSkillFilterContext`）。未自訂 `fileOptions` 的呼叫（如 `new AgentSkillsProvider(path, runner)`）不受影響，預設深度 2。

> **⚠️ v1.4.0 Breaking Change（PR #5475）**：file-based skill scripts 的引數型別由單一字串改為 `string[]`。若原本的腳本呼叫以單一字串傳入，需改為傳入字串陣列。

```python
# Before（v1.3.0 及以前）
run_skill_script("validate", "some-argument")

# After（v1.4.0+）
run_skill_script("validate", ["some-argument"])
```

### 4. 混合多來源：`AgentSkillsProviderBuilder`

```csharp
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "skills"))  // file-based
    .UseSkill(volumeConverterSkill)                                  // AgentInlineSkill
    .UseSkill(temperatureConverter)                                  // AgentClassSkill<T>
    .UseFileScriptRunner(SubprocessScriptRunner.RunAsync)
    .UseFilter(skill => approvedSkills.Contains(skill.Frontmatter.Name))  // 技能過濾
    .Build();
```

### 4b. MCP-Based Skills（v1.8.0，PR #6108）

透過 MCP（Model Context Protocol）伺服器動態探索技能，技能內容以 `skill-md` 資源型別提供。適合技能由外部 MCP 服務集中維護的場景。

```csharp
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Mcp;          // UseMcpSkills 擴充方法
using ModelContextProtocol.Client;       // McpClient

McpClient mcpClient = /* 連線到提供 Agent Skills 資源的 MCP 伺服器 */;

// 透過 Builder 加入 MCP 技能來源
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseMcpSkills(mcpClient)             // 對應 AgentMcpSkillsSource
    .Build();
```

對應型別：`AgentMcpSkill`、`AgentMcpSkillResource`、`AgentMcpSkillsSource`（命名空間 `Microsoft.Agents.AI.Mcp.Skills`）；`UseMcpSkills(this AgentSkillsProviderBuilder, McpClient)` 為擴充方法。

### 5. `AgentSkillsProviderOptions`（進階選項）

```csharp
var skillsProvider = new AgentSkillsProvider(
    skillPath: Path.Combine(AppContext.BaseDirectory, "skills"),
    options: new AgentSkillsProviderOptions
    {
        ScriptApproval = true,          // 腳本執行需人工審批
        DisableCaching = true,          // 停用快取（開發期間）
        SkillsInstructionPrompt = """   // 自訂 system prompt
            You have skills available: {skills}
            {resource_instructions}
            {script_instructions}
            """,
    });
```

### 6. DI 整合

```csharp
// 服務註冊
ServiceCollection services = new();
services.AddSingleton<ConversionService>();
IServiceProvider serviceProvider = services.BuildServiceProvider();

// 傳入 agent
AIAgent agent = chatClient.AsAIAgent(
    options: new ChatClientAgentOptions { AIContextProviders = [skillsProvider] },
    model: deploymentName,
    services: serviceProvider);

// AgentInlineSkill 接收 IServiceProvider
var skill = new AgentInlineSkill(...)
    .AddResource("table", (IServiceProvider sp) =>
        sp.GetRequiredService<ConversionService>().GetTable())
    .AddScript("convert", (double value, double factor, IServiceProvider sp) =>
        sp.GetRequiredService<ConversionService>().Convert(value, factor));

// AgentClassSkill<T> 方法參數接收 IServiceProvider
[AgentSkillResource("weight-table")]
private static string GetWeightTable(IServiceProvider serviceProvider)
    => serviceProvider.GetRequiredService<ConversionService>().GetWeightTable();
```

## 四個抽象基底型別

> **⚠️ v1.7.0 Breaking（PR #6030）— 消費端 API 改為非同步**：base `AgentSkill` 由同步成員（`string Content` getter、`Resources`/`Scripts` 列表屬性）重構為非同步查找方法。**此變更只影響直接讀取 skill 內容的消費端程式碼**（如自訂 `AgentSkillsSource` 或手動讀資源）；撰寫端 `AgentClassSkill<T>`、`AgentInlineSkill`、`AgentSkillsProvider` 的公開 API 維持不變，本章前述範例不受影響。

```csharp
public abstract class AgentSkill
{
    public abstract AgentSkillFrontmatter Frontmatter { get; }   // 仍為同步屬性

    // v1.7.0：以下三者由同步屬性改為非同步查找方法
    public abstract ValueTask<string> GetContentAsync(CancellationToken cancellationToken = default);
    public virtual ValueTask<AgentSkillResource?> GetResourceAsync(string name, CancellationToken cancellationToken = default);
    public virtual ValueTask<AgentSkillScript?> GetScriptAsync(string name, CancellationToken cancellationToken = default);
}

// AgentClassSkill<TSelf>：撰寫端不變——仍保留 virtual Resources/Scripts 屬性供
// 反射式 [AgentSkillResource]/[AgentSkillScript] 探索，並 seal 上述非同步覆寫。
public abstract class AgentClassSkill<TSelf> : AgentSkill where TSelf : AgentClassSkill<TSelf>
{
    protected abstract string Instructions { get; }
    public virtual IReadOnlyList<AgentSkillResource>? Resources { get; }
    public virtual IReadOnlyList<AgentSkillScript>? Scripts { get; }
}

public abstract class AgentSkillResource
{
    public string Name { get; }
    public string? Description { get; }
    public abstract Task<object?> ReadAsync(IServiceProvider? serviceProvider, CancellationToken cancellationToken);
}

public abstract class AgentSkillScript
{
    public string Name { get; }
    public string? Description { get; }
    public abstract Task<object?> RunAsync(AgentSkill skill, JsonElement? arguments, IServiceProvider? serviceProvider, CancellationToken cancellationToken);
}

public abstract class AgentSkillsSource
{
    public abstract Task<IList<AgentSkill>> GetSkillsAsync(CancellationToken cancellationToken);
}
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| — | 2026-03-23 | ADR 0021 提出完整設計（三種來源 + 四個抽象基底） |
| 1.1.0 | 2026-04-10 | `AgentClassSkill<T>` 實作（PR #5027）；反射式資源/腳本探索（PR #5183）；自訂型別支援（PR #5152）；目錄術語標準化（PR #5205） |
| 1.1.0 | 2026-04-10 | `AgentInlineSkill`、`AgentSkillsProviderBuilder`、`AgentFileSkillsSourceOptions`、`AgentSkillsProviderOptions` GA |
| — | 2026-04-13 | DevBlog 發布（Sergey Menshykh）介紹三種 authoring 方式 |
| — | 2026-04-22 | Microsoft Learn 官方文件發布（含 DI、腳本審批、快取選項） |
| 1.4.0 | 2026-05-05 | **[Breaking]** file-based skill scripts 參數型別改為 `string[]`（PR #5475）|
| 1.5.0 | 2026-05-08 | **[Bug Fix]** YAML block scalar 解析修正（PR #5610）：`SKILL.md` frontmatter 中 `\|`（literal）與 `>`（folded）多行值現可正確解析；單行 `description: "..."` 格式不受影響 |
| 1.6.1 | 2026-05-20 | Python SDK 新增 Shell Tool 技能支援；.NET API 未變更，相容 v1.6.1 |
| 1.7.0 | 2026-05-26 | **[Breaking]** base `AgentSkill` 消費端 API 改為非同步（`GetContentAsync`/`GetResourceAsync(name)`/`GetScriptAsync(name)`，PR #6030）；撰寫端 `AgentClassSkill<T>`/`AgentInlineSkill`/`AgentSkillsProvider` 保留，教學程式碼不受影響。新增 Hosted-AgentSkills（Foundry Skills）範例（PR #6013） |
| 1.8.0 | 2026-05-28 | **[Breaking]** `AgentFileSkillsSource` 改為 depth-based discovery + 述詞過濾（`SearchDepth`/`ResourceFilter`/`ScriptFilter`，PR #6109）；新增 MCP-based skills（skill-md 類型，`AgentMcpSkill`/`AgentMcpSkillsSource`，PR #6108） |
| 1.9.0 | 2026-06-03 | 相容性驗證：撰寫端 API 未再變更，相容 v1.9.0（Skills 仍標 `[Experimental]`） |

## 教學章節對應

- **第 05 章**（延伸閱讀）：Agent Skills 簡介，指向 ch29 完整說明
- **第 29 章**：Agent Skills 完整教學（三種 Skill 類型、`AgentSkillsProviderBuilder`、DI 整合、`AgentSkillsProviderOptions`、v1.4.0 Breaking Change）
- **附錄 D**（ADR 0021）：三種來源架構設計，並附 ch29 完整教學連結

## 官方範例（GitHub Samples `02-agents/AgentSkills`）

| 步驟 | 目錄 | 重點 |
|------|------|------|
| 1 | `Agent_Step01_FileBasedSkills` | SKILL.md 檔案式 |
| 2 | `Agent_Step02_CodeDefinedSkills` | AgentInlineSkill |
| 3 | `Agent_Step03_ClassBasedSkills` | AgentClassSkill<T> |
| 4 | `Agent_Step04_MixedSkills` | AgentSkillsProviderBuilder |
| 5 | `Agent_Step05_SkillsWithDI` | DI 整合 |

## Skills vs. Workflows 選擇

| | Agent Skills | Workflows |
|--|-------------|-----------|
| 控制 | AI 決定執行方式 | 明確定義步驟 |
| 韌性 | 單 turn，失敗需整個重試 | 支援 checkpointing |
| 副作用 | 適合冪等操作 | 適合有副作用步驟 |
| 複雜度 | 單一領域聚焦任務 | 多步驟、多代理協調 |

## 相關概念

- [[tools-ai-function]]
- [[context-providers]]
- [[human-in-the-loop]]（ScriptApproval 審批機制）
- [[workflows]]
