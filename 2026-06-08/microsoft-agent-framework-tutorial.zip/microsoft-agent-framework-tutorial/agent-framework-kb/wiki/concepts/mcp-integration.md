---
title: MCP 整合 — Model Context Protocol
api_name: McpServerTool  # 待驗證：MapMcpServer 圖譜查無；MCP 整合可能透過外部套件（model-context-protocol NuGet）
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [protocol, mcp, tools, interop]
tutorial_chapters: [ch25]
sources:
  - raw/samples/README.md
---

## 概述

MCP（Model Context Protocol）讓代理連接外部工具與資料源。Agent Framework 支援三種傳輸模式：Stdio、HTTP+OAuth、Foundry Hosted。代理可以作為 MCP Client（使用外部 MCP 工具）或 MCP Server（將自身工具暴露給其他客戶端）。

## 目前 API 簽名

```csharp
// 作為 MCP Client：使用外部 MCP Server 的工具
var mcpTools = await McpServerTool.CreateFromStdioAsync(
    command: "npx",
    arguments: ["-y", "@anthropic/mcp-server-filesystem"]);

var agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Tools = mcpTools.ToList<AITool>(),
});

// 作為 MCP Server：暴露代理工具
app.MapMcpServer("/mcp", options =>
{
    options.Tools = [AIFunctionFactory.Create(GetWeather)];
});

// HTTP+OAuth 傳輸
var mcpTools = await McpServerTool.CreateFromHttpAsync(
    new Uri("https://mcp-server.example.com"),
    authToken: "...");
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |

## 教學章節對應

- 第 25 章：MCP 整合完整教學（Stdio/HTTP/Foundry Hosted、Agent as MCP Server）
- 官方範例：`Agent-Framework-Samples/05.Providers` — MCP with Microsoft Learn 整合範例

## 相關概念

- [[tools-ai-function]]
- [[a2a-protocol]]
- [[ag-ui-protocol]]
