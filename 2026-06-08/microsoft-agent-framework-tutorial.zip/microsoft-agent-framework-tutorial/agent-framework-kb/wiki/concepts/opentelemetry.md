---
title: OpenTelemetry 可觀測性
api_name: OpenTelemetryAgent / UseOpenTelemetry
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-14
tags: [observability, tracing, metrics, logs, aspire]
tutorial_chapters: [ch22]
sources:
  - raw/adrs/0003-agent-opentelemetry-instrumentation.md
  - raw/release-notes/dotnet-1.2.0.md
  - raw/release-notes/dotnet-1.6.1.md
  - raw/samples/README.md
---

## 概述

Agent Framework 內建 OpenTelemetry 整合，提供 Traces、Metrics、Logs 三種可觀測性信號。支援兩種使用方式：（1）全域透過 `AddAgentFrameworkInstrumentation()` 自動涵蓋所有代理；（2）個別代理使用 `OpenTelemetryAgent` wrapper（`.WithOpenTelemetry()`），精確控制 agent-level telemetry 範圍，遵循 ADR 0003 的 Wrapper Pattern 設計。

## 目前 API 簽名

```csharp
// 方式一：全域 DI 註冊（涵蓋所有代理）
builder.Services.AddOpenTelemetry()
    .WithTracing(tracing =>
    {
        tracing.AddAgentFrameworkInstrumentation();
        tracing.AddAspNetCoreInstrumentation();
        tracing.AddOtlpExporter();
    })
    .WithMetrics(metrics =>
    {
        metrics.AddAgentFrameworkInstrumentation();
        metrics.AddOtlpExporter();
    });

builder.Logging.AddOpenTelemetry(logging =>
{
    logging.AddOtlpExporter();
});

// 方式二：OpenTelemetryAgent Wrapper（ADR 0003，個別代理）
using var tracerProvider = Sdk.CreateTracerProviderBuilder()
    .AddAgentFrameworkInstrumentation()
    .AddConsoleExporter()
    .Build();

var otelAgent = agent.WithOpenTelemetry(tracerProvider);
```

## ⚠️ v1.6.1 Breaking Change — ChatClient 自動包裝

`OpenTelemetryAgent` 現在會自動將 `ChatClient` 以 `OpenTelemetryChatClient` 包裝。若既有程式碼已手動加入 `OpenTelemetryChatClient`，可能導致**雙重儀器化（double instrumentation）**，造成重複的 Span / Metric 紀錄。

**修正方式：** 移除手動的 `.WithOpenTelemetry(tracerProvider)` 呼叫，改由 `AddAgentFrameworkInstrumentation()` 全域處理；或確認程式碼中不重複包裝。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.6.1 | 2026-05-14 | **[Breaking]** `OpenTelemetryAgent` 自動包裝 `ChatClient` 為 `OpenTelemetryChatClient`；手動雙重包裝將造成重複儀器化 |

## 教學章節對應

- 第 22 章：OpenTelemetry 可觀測性完整教學
- 官方範例：`Agent-Framework-Samples/08.EvaluationAndTracing` — DevUI、Aspire Tracer 可觀測性實作

## 相關概念

- [[ai-agent]]
- [[agent-evaluation]]
- [[aspnet-core-hosting]]