---
title: 測試策略 — 單元測試與整合測試
api_name: IChatClient / AgentSession
namespace: Microsoft.Extensions.AI / Microsoft.Agents.AI
since: 1.0.0
current_version: 1.6.1
updated: 2026-05-20
tags: [testing, unit-test, integration-test, mock, fake, IChatClient, testing-pattern]
tutorial_chapters: [ch12]
sources:
  - raw/release-notes/dotnet-1.0.0.md
  - raw/release-notes/dotnet-1.1.0.md
---

## 概述

Agent Framework 的測試策略分三層：工具方法單元測試（純 C# 測試）、以自訂 `IChatClient` 替身測試代理行為、WebApplicationFactory 整合測試。核心挑戰是製造可控制的假 LLM 回應並驗證工具呼叫。

## 重要說明：關於 Microsoft.Extensions.AI.Testing

**`Microsoft.Extensions.AI.Testing` 並不存在**（截至 2026-05-20）。常見混淆來源：

| 套件 | 說明 | 是否適用 |
|------|------|---------|
| `Microsoft.Extensions.AI.Testing` | **不存在**，無此 NuGet 套件 | ❌ |
| `Microsoft.Agents.Builder.Testing` | Microsoft **365** Agents SDK（訊息型對話代理）的測試套件 | ⚠️ 不同產品 |
| `Microsoft.Extensions.AI.Evaluation` | AI 回應品質評估框架 | ✅ 評估用 |
| 自訂 `IChatClient` 實作 | 官方建議的測試替身方式 | ✅ 推薦 |

## 推薦做法：自訂 FakeChatClient

官方建議實作 `IChatClient` 介面作為測試替身，優於使用 Moq：

```csharp
using System.Runtime.CompilerServices;
using Microsoft.Extensions.AI;

/// <summary>
/// 測試用假 ChatClient，回傳固定回應並記錄收到的訊息。
/// </summary>
public sealed class FakeChatClient : IChatClient
{
    private readonly string _fixedResponse;
    private readonly AIFunction? _expectedToolCall;

    public List<IEnumerable<ChatMessage>> ReceivedMessages { get; } = [];
    public int CallCount => ReceivedMessages.Count;
    public ChatClientMetadata Metadata { get; } = new("FakeChatClient", null, null);

    public FakeChatClient(string fixedResponse = "Mock 回應", AIFunction? expectedToolCall = null)
    {
        _fixedResponse = fixedResponse;
        _expectedToolCall = expectedToolCall;
    }

    public Task<ChatResponse> GetResponseAsync(
        IEnumerable<ChatMessage> messages,
        ChatOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        ReceivedMessages.Add(messages);

        if (_expectedToolCall is not null)
        {
            // 模擬 LLM 請求工具呼叫
            var toolCall = new FunctionCallContent(
                callId: Guid.NewGuid().ToString(),
                name: _expectedToolCall.Metadata.Name,
                arguments: new Dictionary<string, object?>());

            return Task.FromResult(new ChatResponse(
                new ChatMessage(ChatRole.Assistant, [toolCall])));
        }

        return Task.FromResult(new ChatResponse(
            new ChatMessage(ChatRole.Assistant, _fixedResponse)));
    }

    public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
        IEnumerable<ChatMessage> messages,
        ChatOptions? options = null,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        ReceivedMessages.Add(messages);
        yield return new ChatResponseUpdate(ChatRole.Assistant, _fixedResponse);
    }

    public object? GetService(Type serviceType, object? serviceKey) => this;
    public TService? GetService<TService>(object? key = null) where TService : class => this as TService;
    void IDisposable.Dispose() { }
}
```

## 三層測試架構

### 第一層：工具方法單元測試（無需 LLM）

```csharp
// 純 C# 測試，測試業務邏輯
[Fact]
public async Task GetWeatherTool_ReturnsFormattedString()
{
    var tool = new WeatherTools();
    var result = await tool.GetWeatherAsync("Seattle");
    Assert.Contains("Seattle", result);
}
```

### 第二層：代理行為測試（FakeChatClient）

```csharp
[Fact]
public async Task Agent_UsesToolResult_InResponse()
{
    var fakeClient = new FakeChatClient("Seattle 天氣晴朗，18°C");

    var agent = new ChatClientBuilder(fakeClient)
        .UseFunctionInvocation()
        .Build()
        .AsAIAgent("WeatherAgent");

    var session = new AgentSession();
    var response = await agent.RunAsync("Seattle 的天氣如何？", session);

    Assert.Equal(1, fakeClient.CallCount);
    Assert.Contains("18", response.Text);
}
```

### 第三層：整合測試（WebApplicationFactory）

```csharp
public class AgentApiTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public AgentApiTests(WebApplicationFactory<Program> factory)
    {
        // 替換 IChatClient 為假實作
        _factory = factory.WithWebHostBuilder(builder =>
            builder.ConfigureServices(services =>
                services.AddSingleton<IChatClient>(new FakeChatClient("測試回應"))));
    }

    [Fact]
    public async Task Agent_Endpoint_Returns_OK()
    {
        var client = _factory.CreateClient();
        var response = await client.PostAsync("/api/agent",
            new StringContent("{\"message\":\"hello\"}", Encoding.UTF8, "application/json"));
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }
}
```

## Moq 快速 Mock（替代方案）

```csharp
// 適合簡單場景，但自訂 FakeChatClient 更可控
var mockClient = new Mock<IChatClient>();
mockClient
    .Setup(c => c.GetResponseAsync(
        It.IsAny<IEnumerable<ChatMessage>>(),
        It.IsAny<ChatOptions?>(),
        It.IsAny<CancellationToken>()))
    .ReturnsAsync(new ChatResponse(
        new ChatMessage(ChatRole.Assistant, "Mock 回應")));
```

## Microsoft.Extensions.AI.Evaluation（AI 品質評估）

評估套件用於**量化評估 AI 模型回應品質**，補充但不取代單元測試：

```csharp
// NuGet: Microsoft.Extensions.AI.Evaluation v10.6.0
// 用途：評估代理回應的相關性、流暢度等品質指標
// 適合場景：CI 中的回歸評估、模型升版品質比較
using Microsoft.Extensions.AI.Evaluation;
```

## 參考：Microsoft.Agents.Builder.Testing（365 Agents SDK）

> **注意：** 此套件屬於 **Microsoft 365 Agents SDK**（訊息型對話代理），與本知識庫的 `microsoft/agent-framework`（AI Agent Framework）是**不同產品**。

| 類別 | 說明 |
|------|------|
| `AgentTestHost` | 包裝 IHost，預先配置 TestAdapter |
| `TestAdapter` | 取代真實 channel adapter |
| `TestFlow` | Fluent API（Send/AssertReply/StartTestAsync） |
| `SemanticValidator` | 使用 AI judge 做語意驗證 |

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA 釋出，測試模式文件定稿 |
| 1.6.1 | 2026-05-20 | 更新測試策略：釐清 Microsoft.Extensions.AI.Testing 不存在，補充自訂 FakeChatClient 推薦做法、三層測試架構與 Evaluation 套件說明 |

## 教學章節對應

- 第 12 章：測試策略完整教學

## 相關概念

- [[ai-agent]]
- [[aspnet-core-hosting]]
- [[agent-evaluation]]
- [[chat-client]]
- [[middleware-pipeline]]
