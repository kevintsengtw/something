---
date: 2026-04-17
topic: Middleware 攔截與改寫 ChatMessage
related_concepts: [middleware-pipeline, context-providers, ag-ui-protocol, a2a-protocol, agent-run-context]
related_chapters: [ch06, ch11, ch23, ch24]
session_type: qa
---

# Q&A 記錄：透過 Middleware 攔截與改寫 ChatMessage

## 背景

使用者連續提問三個問題，圍繞同一個核心需求：
**在 HTTP 請求進入後、抵達 ChatClientAgent 前，如何讀取、處理並改寫使用者輸入的 prompt 內容。**

最終目的是透過預處理減少傳給 LLM 的 token 量，提升效率。

---

## 問題一：AG-UI / MapAGUIAgent 情境

**問：** 透過 HTTP request 接收到 prompt 並傳給 ChatClientAgent 前，可以抓出 request 所輸入的 prompt 內容嗎？

**答：可以，有三種方式：**

### 方式一：Middleware Pipeline（推薦）

```csharp
var agent = chatClient
    .AsAIAgent(options)
    .AsBuilder()
    .Use(async (context, next) =>
    {
        var userPrompt = context.Messages
            .LastOrDefault(m => m.Role == ChatRole.User)?.Text;
        Console.WriteLine($"收到的 prompt：{userPrompt}");
        await next(context);
    })
    .Build();

app.MapAGUIAgent("/api/agent", agent);
```

- `context.Messages` 是 `IList<ChatMessage>`，可讀可寫
- `context.Response` 在 `next()` 之後可讀取代理的回應

### 方式二：AIContextProvider

適合「讀取 prompt 同時注入額外 system context」的情境。透過 `AgentContextProviderRequest.Messages` 讀取輸入，並可插入 system message。

### 方式三：AgentRunContext（ADR 0015，Proposed）

```csharp
// 在工具函式或深層呼叫鏈中
var prompt = AIAgent.CurrentRunContext?.RequestMessages
    ?.LastOrDefault(m => m.Role == ChatRole.User)?.Text;
```

`AIAgent.CurrentRunContext` 使用 `AsyncLocal<T>`，自動沿 async/await 鏈流動，無需逐層傳參。

---

## 問題二：A2A Protocol / MapA2AServer 情境

**問：** 如果是使用 `MapA2A()`（即 `MapA2AServer()`）呢？

**核心差異對照：**

| | AG-UI | A2A |
|---|---|---|
| 呼叫者 | 前端使用者 | 另一個代理（跨框架） |
| 傳輸格式 | SSE 串流 | JSON（A2A Task / Message 結構） |
| Middleware 有效？ | ✅ | ✅（框架轉換後） |

**關鍵認知：** A2A 的 `Message` 物件在呼叫 `RunAsync` 之前就已被框架轉換為標準 `ChatMessage`，因此 Agent Middleware 的攔截方式完全相同。

```csharp
builder.Services.AddA2AServer(options =>
{
    options.AgentCard = new AgentCard { Name = "MyAgent", ... };
    options.AgentFactory = sp => agent;  // 傳入帶 middleware 的 agent
});
app.MapA2AServer();
```

**若需要原始 A2A 協定元資料**（`task_id`、`artifact` 等），需改在 ASP.NET Core middleware 層（框架轉換之前）攔截 HTTP request body。

**選擇指引：**

| 需求 | 方式 |
|------|------|
| 讀取 / 記錄 prompt 文字 | Agent Middleware |
| 根據 prompt 修改、過濾 | Agent Middleware |
| 讀取 A2A task_id、artifact 等元資料 | ASP.NET Core Middleware |
| 工具函式深層存取 | `AIAgent.CurrentRunContext`（ADR 0015） |

---

## 問題三：實際應用 — 預處理 JSON 資料節省 Token

**問：** 如何在 middleware 中解析 user message 的 JSON 資料，做完預處理後，以精簡後的 prompt 取代原始大 payload，再傳給 LLM？

**情境說明：**
- 前端送來：「指令 + 大量新聞資料 JSON」
- 目標：在 middleware 中找出最高頻 tag 的最新新聞，重組成只含單則新聞的精簡 prompt
- 效益：大幅減少 LLM 收到的 token 數

### 完整 Middleware 實作模式

```csharp
.Use(async (context, next) =>
{
    // 1. 定位最後一則 user message
    int idx = -1;
    for (int i = context.Messages.Count - 1; i >= 0; i--)
        if (context.Messages[i].Role == ChatRole.User) { idx = i; break; }

    if (idx >= 0)
    {
        var payload = TryParseNewsPayload(context.Messages[idx].Text);
        if (payload != null)
        {
            // 2. 找出最高頻 tag
            var topTag = payload.News
                .SelectMany(n => n.Tags)
                .GroupBy(t => t)
                .OrderByDescending(g => g.Count())
                .First().Key;

            // 3. 篩選 + 取最新一則
            var article = payload.News
                .Where(n => n.Tags.Contains(topTag))
                .OrderByDescending(n => n.PublishedAt)
                .First();

            // 4. 重組精簡 prompt
            var newPrompt = $"""
                {payload.Instruction}
                新聞標題：{article.Title}
                發布時間：{article.PublishedAt:yyyy-MM-dd HH:mm}
                內文：{article.Content}
                """;

            // 5. 取代原始 user message（關鍵操作）
            context.Messages[idx] = new ChatMessage(ChatRole.User, newPrompt);
        }
    }

    await next(context);  // 精簡後的 prompt 才傳給 LLM
})
```

### 三種替換方式

```csharp
// A：直接 index 替換（最簡單，推薦）
context.Messages[idx] = new ChatMessage(ChatRole.User, newPrompt);

// B：先移除再插入（需要控制位置時）
context.Messages.RemoveAt(idx);
context.Messages.Insert(idx, new ChatMessage(ChatRole.User, newPrompt));

// C：完全重建列表（需大幅重組時）
var rebuilt = context.Messages.Select(m =>
    m.Role == ChatRole.User
        ? new ChatMessage(ChatRole.User, newPrompt)
        : m).ToList();
context.Messages.Clear();
foreach (var m in rebuilt) context.Messages.Add(m);
```

### Middleware vs AIContextProvider 選擇

| 需求 | 推薦方式 |
|------|---------|
| 取代大 payload，LLM 只看精簡內容 | ✅ Middleware（覆寫 `Messages[i]`） |
| 保留原始訊息，另外注入處理結果 | ✅ AIContextProvider（`Insert` system message） |
| 需要跨輪狀態（記憶上一輪處理結果） | ✅ AIContextProvider + `ProviderSessionState<T>` |

---

## 教學補充建議

這三個問題揭示了一個現有教學中可能不夠明確的使用模式：

### 建議補充至第 06 章（Middleware 與 Context）

1. **Middleware 的 Messages 可變性**：明確說明 `IList<ChatMessage>` 是可以增刪改的，不只是用來「讀取」
2. **Pre-processing 模式**：加入「在 middleware 中轉換 / 精簡 prompt」的範例，說明這是節省 token 的標準做法
3. **Prompt Rewriting 章節**：可新增一節「Prompt 改寫模式（Prompt Rewriting）」，與 RAG 的「補充上下文」模式並列

### 建議補充至第 11 章（ASP.NET Core WebAPI 整合）

1. **AG-UI vs A2A 的 middleware 差異**：特別說明兩者雖然協定不同，但 Agent Middleware 層的行為完全一致
2. **A2A 原始元資料存取**：說明何時需要下沉到 ASP.NET Core middleware 層

### 未來章節機會

- **「Token 最佳化」專題章節**：結合 Middleware prompt rewriting + Structured Output + Chat History Compaction，形成完整的 token 節省策略文件

---

## 涉及的 Wiki 概念

- `wiki/concepts/middleware-pipeline.md` — 核心，`AgentMiddlewareContext.Messages` 可變性
- `wiki/concepts/context-providers.md` — 替代方案，適合注入而非替換
- `wiki/concepts/ag-ui-protocol.md` — HTTP→ChatMessage 轉換流程
- `wiki/concepts/a2a-protocol.md` — A2A 協定層次，sources 目前為空需補強
- `raw/adrs/0015-agent-run-context.md` — `AIAgent.CurrentRunContext`（Proposed，未 GA）
