# Microsoft Agent Framework 版本更新 Playbook

> 當 Microsoft Agent Framework 發佈新版本時，依照本文件步驟執行教學同步更新。
> 對應 [`./WORKFLOW-DESIGN-v2.md`](./WORKFLOW-DESIGN-v2.md) 的 Pipeline A。

## 前置條件

- Claude Code CLI 已安裝（macOS）
- 工作區根：`agent-framework-tutorial/`（slash commands 入口點）
- 三子目錄存在：`agent-framework/`、`agent-framework-kb/`、`microsoft-agent-framework-tutorial/`
- `codebase-memory-mcp` 已安裝且通過 macOS 驗證（見 [`./raw/facts/codebase-memory-mcp-validation.md`](./raw/facts/codebase-memory-mcp-validation.md)）
- Understand-Anything plugin 已安裝
- `agent-framework/` 已索引（首次需 `mcp__codebase-memory-mcp__index_repository`）

---

## Step 1：同步上游素材

```
/sync-upstream
```

確認事項：
- `raw/release-notes/` 中出現新版本檔案（如 `dotnet-1.7.0.md`）
- `raw/adrs/` 中有新增或狀態變更的 ADR
- 若有新的 DevBlog 或 Learn 文件，確認已存入對應目錄
- `raw/samples/README.md` 已更新
- 終端顯示 codebase-memory-mcp 索引狀態（file watcher 自動同步或重跑 index_repository）

**codebase-memory-mcp 查驗**（已整合進指令）：

```
mcp__codebase-memory-mcp__search_graph
  project: "agent-framework"
  name_pattern: "<release notes 中提到的新 API>"
```

→ 確認新 API 已存在於上游原始碼，作為 `/extract-facts` 與 `/compile` 的線索。

預估時間：3–5 分鐘

---

## Step 2：建立事實清單

```
/extract-facts <new-version>
```

例：`/extract-facts 1.7.0`

確認事項：
- `raw/facts/dotnet-<version>-verified-changes.json` 已產出
- 終端顯示「已驗證 X 個 API / 未驗證 Y 個」
- 若有未驗證項目（圖譜查無），人工檢查原因

**這是事實層的源頭**——所有 API 名稱、簽名、namespace 都從此 JSON 取得，後續 `/compile` 編譯時必須引用。

預估時間：5–10 分鐘

---

## Step 3：編譯知識庫

```
/compile
```

確認事項：
- 終端顯示新增或更新的 `wiki/concepts/` 條目清單
- `wiki/INDEX.md` 已同步更新
- `wiki/api-changelog.md` 已新增該版本的變更區段
- 所有條目的 `current_version` 已更新為新版本號
- frontmatter 結構欄位（api_name、namespace、since、current_version）來自 `raw/facts/` JSON

**codebase-memory-mcp 查驗**（已整合進指令，針對新增或改名的 API）：

```
mcp__codebase-memory-mcp__search_graph
  project: "agent-framework"
  name_pattern: "<新 API 名稱>"

mcp__codebase-memory-mcp__get_code_snippet
  project: "agent-framework"
  qualified_name: "<完整 qualified name>"

mcp__codebase-memory-mcp__search_code
  project: "agent-framework"
  pattern: "<新 API 名稱>"
```

→ 從原始碼圖譜取得正確的 namespace、method signatures、上游使用範例，確保 wiki/concepts 條目與上游一致。

廢棄確認：
```
mcp__codebase-memory-mcp__trace_path
  project: "agent-framework"
  function_name: "<舊 API 名稱>"
  direction: "inbound"
  depth: 1
```

→ 結果為空 → 廢棄徹底，wiki 條目可安全標記 `Deprecated`。

預估時間：5–10 分鐘

---

## Step 4：知識圖譜快照（NEW）

```
/snapshot-knowledge
```

確認事項：
- `.understand-anything/knowledge-graph.json` 已產出或更新
- 終端顯示節點數、邊數、cluster 數
- 提示 dashboard 開啟方式：`/understand-dashboard`

**用途**：產生 wiki/ 的視覺化快照，發現概念間的隱性關係。這是新增階段，每次版本更新後執行一次。

預估時間：3–5 分鐘

---

## Step 5：執行偏移檢查

```
/drift-check
```

確認事項：
- `wiki/drift-report.md` 已重新產生
- 檢視報告中的三級偏移分類

偏移等級與對應行動：

| 等級 | 意義 | 行動 |
|------|------|------|
| 🔴 Breaking | 教學程式碼會編譯失敗 | **必須立即修復** |
| 🟡 Outdated | 內容過時但不影響編譯 | **建議修復** |
| 🟢 Enhancement | 可選的新功能補充 | **評估後決定** |

**codebase-memory-mcp 查驗**（已整合進指令）：

```
mcp__codebase-memory-mcp__query_graph
  project: "agent-framework"
  query: "MATCH (n {name: '<API 名稱>'}) RETURN n.name, n.filePath, labels(n)"
```

→ 若圖譜查無此節點，即為確認的 🔴 Breaking。

預估時間：5–10 分鐘

---

## Step 6：規劃修改範圍

根據 drift-report 決定本次要修改的檔案。建議優先順序：

1. 先處理所有 🔴 Breaking
2. 再處理 🟡 Outdated
3. 最後評估 🟢 Enhancement

如果修改檔案多（>5 個），分批進行：
- 第一批：🔴 Breaking 全部 + 版本號相關（README.md、appendix-a）
- 第二批：🟡 Outdated 逐章修改
- 第三批：🟢 Enhancement 選擇性補充

---

## Step 7：執行教學修改

```
/update-tutorial breaking
```

執行完成後，再處理 Outdated：

```
/update-tutorial outdated
```

確認事項：
- 終端顯示修正摘要，列出已修正與跳過項目
- 標記 `⚠️ 需人工確認` 的項目需手動審閱

**codebase-memory-mcp 替換方向確認**（已整合進指令，**硬性規定**）：

```
mcp__codebase-memory-mcp__search_graph
  project: "agent-framework"
  name_pattern: "<新 API 名稱>"

mcp__codebase-memory-mcp__trace_path
  project: "agent-framework"
  function_name: "<新 API 名稱>"
  direction: "outbound"
  depth: 1
```

→ 替換前必須確認新名稱存在於圖譜，否則標記人工確認、不自動替換。

預估時間：10–20 分鐘（視 Breaking 數量）

> **手動修改原則**（適用於需人工確認的項目）：
>
> - 程式碼範例確保可編譯
> - NuGet 套件版本號更新為新版
> - 移除已不適用的 `--prerelease` 旗標
> - 「規劃中」或「未來版本」等描述若已實現，更新為正式說明
> - 維持章節間的敘事連貫性

---

## Step 8：驗證修改結果

```
/drift-check
```

確認事項：
- 先前的 🔴 Breaking 項目已全部消除
- 🟡 Outdated 項目已減少或消除
- 沒有因修改而引入新的偏移

接著：

```
/lint
```

確認事項：
- wiki 條目格式無誤
- INDEX 與實際條目一致
- wiki-link 全部指向有效條目
- sources 路徑全部存在
- tutorial 內部連結、code block 語言標籤、API 抽樣查驗都正確

---

## Step 9：更新版本記錄

在教學目錄的以下檔案中更新版本資訊：

- `microsoft-agent-framework-tutorial/README.md` — 版本資訊表格
- `microsoft-agent-framework-tutorial/appendix-a-nuget-packages.md` — NuGet 版本號與變更記錄
- `microsoft-agent-framework-tutorial/PLAN-beginner-tutorial.md` — 框架版本與最後更新日期

---

## 完整流程圖

```
上游發佈新版本
       │
       ▼
  /sync-upstream                ← 抓取 raw/ 素材 + 索引同步
  + search_graph                ← 確認新 API 存在性
       │
       ▼
  /extract-facts <version>      ← 抽事實清單 → raw/facts/<version>.json
  + search_graph                ← 存在性驗證
  + get_code_snippet            ← 取簽名 + namespace
  + trace_path inbound 2        ← 取依賴鏈與測試覆蓋
       │
       ▼
  /compile                      ← 更新 wiki/concepts/
  + search_graph + snippet      ← 簽名 + namespace 二次查驗
  + search_code                 ← 取上游使用範例（sources）
  + trace_path inbound 1        ← 廢棄 API 確認
       │
       ▼
  /snapshot-knowledge           ← UA 知識圖譜視覺化
                                ← .understand-anything/knowledge-graph.json
       │
       ▼
  /drift-check                  ← 產出偏移報告
  + query_graph                 ← API 存在性 + namespace 核對
  + search_code                 ← 對比上游 usage（Outdated 偵測）
       │
       ▼
  閱讀 drift-report             ← 決定修改範圍
       │
       ▼
  /update-tutorial              ← 自動修正教學
  + search_graph                ← 替換方向確認（硬性規定）
  + trace_path outbound 1       ← 新 API 依賴結構確認
       │
       ▼
  /drift-check                  ← 驗證偏移已消除（🔴 = 0）
       │
       ▼
  /lint                         ← wiki + tutorial 雙側一致性
  + search_graph                ← api_name 圖譜查驗
       │
       ▼
  更新版本記錄                   ← README、appendix-a、PLAN
       │
       ▼
  完成 ✅
```

## 預估總時間

| 步驟 | 時間 |
|------|------|
| Step 1–5（自動化） | 25–40 分鐘 |
| Step 6（規劃） | 5–10 分鐘 |
| Step 7（修改，視檔案數量） | 30–60 分鐘 |
| Step 8–9（驗證與記錄） | 10–15 分鐘 |
| **合計** | **約 1–2 小時** |

相比 v1.1.0 更新時的全手動流程，自動化後預估可節省 50% 以上時間。

---

## 歷次執行記錄

| 版本 | 執行日期 | drift 結果 | 修改檔案數 | 備註 |
|------|----------|-----------|-----------|------|
| v1.1.0 | 2026-04-17 | 🔴 0 / 🟡 4 / 🟢 5 | 9 + 知識庫建置 | 首次建置，手動流程 |
| v1.2.0 | 2026-04-21 | — | — | sync + compile 完成，教學更新與 v1.3.0 合併處理 |
| v1.3.0 | 2026-04-24 | — | — | 🔴 2 Breaking（A2A SDK 1.0、Azure.AI.AgentServer beta.4）；教學已更新 |
| v1.4.0 | 2026-05-06 | 🔴 0 / 🟡 1 / 🟢 0 | 8（via `/update-tutorial all`） | CodeAct GA、HttpRequestAction、FIDES ADR |
| v1.5.0 | 2026-05-06 | — | — | sync + compile 完成；Magentic Orchestration、WebBrowsingTool Allow Listing |
| v1.6.0 | — | — | — | 無公開發佈（直接跳至 v1.6.1） |
| v1.6.1 | 2026-05-24 | 🔴 2 / 🟡 0 / 🟢 5 | 2（appendix-f、appendix-i） | MessageInjectingChatClient、AgentSessionFiles、A2A HITL；Breaking：MapAGUI → MapAGUIAgent；首次整合 codebase-memory-mcp 查驗 |
| v1.6.1 | 2026-05-25 | 🔴 0 / 🟡 0 / 🟢 4 | 1（25-mcp-integration.md） | 補充執行：B-001 修正（ch25 改用 `McpServerTool.Create` + stdio）；agent-session-files namespace 修正（Azure.AI.Projects） |
| v1.6.1 | 2026-05-25 | 🔴 0 / 🟡 0 / 🟢 2 | 10（6 教學 + 4 wiki） | 驗證執行：修正 B-001 MapAGUIAgent → MapAGUI（命名慣例誤判反向修正）；E-002/E-004 確認已實現 |
| v1.6.1 | 2026-05-26 | — | — | 工作區重組為 v2 架構（入口點上移、新增 Pipeline D、保留 codebase-memory-mcp）；無新版本偏移檢查，純架構升級 |
