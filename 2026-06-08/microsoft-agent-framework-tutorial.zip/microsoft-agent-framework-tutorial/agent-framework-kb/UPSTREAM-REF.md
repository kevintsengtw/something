# 上游原始碼對齊記錄

MacBook / 跨機環境下，每台機器需獨立 clone `agent-framework`（不從其他機器複製索引），對齊到此處記錄的 commit，再在 Claude Code 中執行 `mcp__codebase-memory-mcp__index_repository` 重建索引。`agent-framework-kb/` 與 `microsoft-agent-framework-tutorial/` 則可直接從其他機器複製過去。

---

## 目前對齊版本

| 項目 | 值 |
|------|-----|
| **Commit Hash** | `afa7834e2ec8a93b2224fe7ab184b97fbcaa8c9a` |
| **日期** | 2026-06-03 |
| **訊息** | `Updating dotnet package versions for 1.9 release (#6314)`（dotnet-1.9.0 tag） |
| **知識庫基準版本** | v1.9.0（2026-06-03） |
| **最後更新** | 2026-06-06 |
| **索引規模** | 53,875 nodes / 224,834 edges |

---

## 切換機器時的對齊指令

```bash
cd agent-framework
git fetch
git checkout dotnet-1.9.0   # = afa7834e2ec8a93b2224fe7ab184b97fbcaa8c9a

# 重建 codebase-memory-mcp 索引（不從另一台機器搬移，各機獨立重建）
# 在 Claude Code 中執行：
#   mcp__codebase-memory-mcp__index_repository
#     repo_path: "<絕對路徑>/agent-framework"
# project 名稱自動從路徑產生，完成後用 list_projects 確認
```

---

## codebase-memory-mcp 索引同步策略

| 場景 | 動作 |
|------|------|
| 同機 `git pull` 後 | 無需動作。codebase-memory-mcp 的 file watcher 會自動偵測檔案變更並增量更新索引 |
| 跨機初次設定 | 對該機器執行 `index_repository` 重建索引（索引存於 `~/.codebase-memory-mcp/`，**不跨機共享**） |
| 工具版本升級後 | 視情況可選擇重跑 `index_repository`，若 schema 有變化更需要 |
| 索引疑似失準 | 重跑 `index_repository`；不影響 wiki/、tutorial/ 等其他資料 |

**為何索引不 commit**：
- 體積大（agent-framework 索引曾達 70K+ 節點 / 150K+ 邊）
- 路徑為機器絕對路徑，跨機不可移植
- 可隨時從 source 重建，且重建成本低（首次幾分鐘到十幾分鐘）

---

## 歷史記錄

| 日期 | Commit | 說明 |
|------|--------|------|
| 2026-05-24 | `793403f` | 初始建立此記錄，macOS 遷移前的 Windows 基準 |
| 2026-05-25 | `793403f` | 執行完整版本更新流程（sync/compile/drift-check/update-tutorial/lint），確認仍為最新（無新 .NET 版本） |
| 2026-05-26 | `793403f` | 工作流重組為 v2（入口點上移、新增 Pipeline D、保留 codebase-memory-mcp）；本檔對齊新流程描述 |
| 2026-05-26 | `793403f` | ✅ **codebase-memory-mcp macOS 驗證通過（6/7）**：macOS 26.5、Node.js v24.15.0、codebase-memory-mcp v0.6.1；索引 44,650 nodes / 180,686 edges。詳見 [`./raw/facts/codebase-memory-mcp-validation.md`](./raw/facts/codebase-memory-mcp-validation.md) |
| 2026-05-26 | `08541ee` | git pull 成功（修復 index.lock + staged deletions）；4 個新 commit 含 **[Breaking] AgentSkill API async 重構**（PR #6030）；重新索引 44,788 nodes / 181,851 edges |
| 2026-06-06 | `afa7834` | **三版同步 dotnet-1.7.0→1.9.0**：checkout dotnet-1.9.0 tag（清理 LFS dirty tree 後），重新索引 53,875 nodes / 224,834 edges。完整 Pipeline A：extract-facts ×3、compile（magentic-orchestration/agent-skills/declarative-workflow/workflows）、snapshot-knowledge（121 nodes / 328 edges）、drift-check（🔴=0）、update-tutorial（appendix-a + ch01）、lint。**關鍵發現：#6030 等 breaking 經 codebase-memory-mcp 驗證後皆不影響教學程式碼，E-002 為 false positive 正式關閉** |
