# Agent Framework 教學知識庫：搭建指南

> ⚠️ **[ARCHIVED 2026-05-26]** 本文件已封存。指令名稱（`/wiki-compile` → `/compile`、`/wiki-lint` → `/lint`）
> 和入口點路徑（`agent-framework-kb/.claude/commands/` → 工作區根 `.claude/commands/`）均已在 v2 更新。
> 本文作為 v1 設定歷史保留，操作請改用 QuickStart.md 與 WORKFLOW-DESIGN-v2.md。

> 目標：建立一套 LLM Wiki 系統，自動追蹤 Microsoft Agent Framework 上游變更，主動偵測教學內容過時問題。

---

## 一、系統全貌

```
┌─────────────────────────────────────────────────────────┐
│                     你的日常工作流                         │
│                                                         │
│  ① 上游有新 ADR / Release / Breaking Change             │
│           ↓                                             │
│  ② /sync-upstream  ──→  raw/ 更新                       │
│           ↓                                             │
│  ③ /wiki-compile   ──→  wiki/ 概念條目更新               │
│           ↓                                             │
│  ④ /drift-check    ──→  drift-report.md 產出偏移清單     │
│           ↓                                             │
│  ⑤ 你決定要修 → Claude Code 執行修正                     │
│           ↓                                             │
│  ⑥ /wiki-lint      ──→  確認一致性                       │
└─────────────────────────────────────────────────────────┘
```

**核心概念**：把「人工逐章比對 ADR 和教學程式碼」這件事，轉變為「LLM 編譯上游素材 → 自動產出偏移報告」。你只需要決定哪些偏移要修、怎麼修。

---

## 二、需要安裝的工具

### 必要工具

| 工具 | 用途 | 安裝方式 |
|------|------|---------|
| **Claude Code** | 核心引擎，執行所有 LLM 編譯與偵測 | `npm install -g @anthropic-ai/claude-code` |
| **Git** | 同步上游 agent-framework repo | 已安裝 |
| **Node.js 18+** | Claude Code 執行環境 | 已安裝 |

### 建議工具（非必要但大幅提升體驗）

| 工具 | 用途 | 安裝方式 |
|------|------|---------|
| **Obsidian** | 瀏覽 wiki/ 的雙向連結、知識圖譜 | [obsidian.md](https://obsidian.md) 下載 |
| **llm-wiki-compiler plugin** | 提供 compile / lint / visualize 指令 | Claude Code plugin 安裝（見下方） |

### 為什麼不需要 RAG / Vector DB / Embedding Server？

你的知識庫規模（~40 萬字元、36 個教學檔 + 預估 50-80 個 raw 檔）完全在 Claude 的 context window 能力範圍內。LLM Wiki 模式的核心優勢就是：**在編譯階段完成理解，查詢時直接使用結構化摘要，不需要向量檢索**。

等未來素材超過 200 個檔案，再考慮引入 vault-search（Obsidian 語意搜尋外掛）作為互補。

---

## 三、目錄結構設計

```
agent-framework-kb/                    ← 新建的知識庫根目錄
│
├── CLAUDE.md                          ← Claude Code 專案指令（schema）
├── .claude/
│   └── commands/                      ← 自訂 slash commands
│       ├── sync-upstream.md
│       ├── compile.md
│       ├── drift-check.md
│       └── lint.md
│
├── raw/                               ← 上游素材（唯讀）
│   ├── adrs/                          ← git subtree 或手動同步
│   │   ├── 0018-agentthread-serialization.md
│   │   ├── 0019-middleware-redesign.md
│   │   └── ...
│   ├── samples/                       ← 官方範例關鍵片段
│   │   ├── ForBeginners/
│   │   └── DurableAgents/
│   ├── api-surface/                   ← public API 摘要
│   │   ├── Microsoft.Agents.AI.md
│   │   └── Microsoft.Agents.AI.OpenAI.md
│   ├── release-notes/                 ← 版本發行說明
│   │   └── v1.0.0-ga.md
│   └── devblogs/                      ← Microsoft DevBlog 文章
│       └── introducing-agent-framework.md
│
├── wiki/                              ← LLM 編譯產出
│   ├── INDEX.md                       ← 主索引（自動生成）
│   ├── SCHEMA.md                      ← 編譯規則（首次 compile 產生，可手動調整）
│   ├── concepts/                      ← 概念條目
│   │   ├── agent-session.md
│   │   ├── middleware-pipeline.md
│   │   ├── run-async-vs-streaming.md
│   │   ├── ag-ui-protocol.md
│   │   └── ...
│   ├── api-changelog.md               ← API 變更時間線
│   └── drift-report.md                ← 教學偏移報告
│
├── brainstorming/                     ← 探索與稽核記錄
│   ├── quality-reviews/
│   └── chapter-planning/
│
└── tutorial/                          ← symlink → 現有教學目錄
    → ../microsoft-agent-framework-tutorial/
```

### 為什麼用 symlink 而不是搬移教學？

你的教學目錄已經有自己的 git repo 和結構。用 symlink 讓知識庫可以「看到」教學內容做比對，但不改變教學的原有工作流。

---

## 四、運作形式：三種使用情境

### 情境 A：例行巡檢（每週或每次上游發版）

```bash
# 1. 同步上游素材
cd agent-framework-kb
claude /sync-upstream

# 2. 編譯新素材為 wiki 條目
claude /compile

# 3. 偵測教學偏移
claude /drift-check
```

產出 `wiki/drift-report.md`，內容類似：

```markdown
## 偏移報告 2026-04-12

### 🔴 Breaking（教學範例會編譯失敗）
- **ch11, ch12**: `AgentInvocationContext` 已移除，需改用 `AgentMiddlewareContext`
  - 來源：ADR 0022（2026-03-15 Accepted）
  - 影響檔案：11-aspnetcore-webapi.md L329, 12-testing-strategy.md L445

### 🟡 Outdated（內容不反映最新實作）
- **ch01**: 「進階篇（未來製作）」描述過時，進階篇已完成
  - 影響檔案：01-what-is-agent-framework.md L138-158

### 🟢 Enhancement（可選的新功能補充）
- wiki/concepts/agent-evaluation.md 提到新的 `FoundryEvals` 整合
  - 建議補充至 ch28
```

你看完報告後決定要修哪些，用 Claude Code 在教學目錄裡執行修正。

### 情境 B：排程自動偵測（Cowork Scheduled Task）

設定一個每週執行的排程任務，自動跑 sync → compile → drift-check → 有 🔴 Breaking 時寄 Gmail 通知：

```
排程：每週一 09:00
動作：
  1. git pull raw/adrs/
  2. /compile（只處理新/修改的檔案）
  3. /drift-check
  4. 若有 🔴 Breaking → Gmail 通知
```

這可以用你現有的 `dotnet-testing-monitor` skill 的 Gmail 通知機制來做。

### 情境 C：寫新章節時查詢知識庫

```bash
# 用 wiki 裡的結構化知識輔助寫作
claude /wiki-query "Durable Agents 的 Session TTL 機制是什麼？"

# 或用 thinking-partner 模式探索
claude /thinking-partner "ch29 應該寫什麼主題？"
```

---

## 五、搭建步驟

### Step 1：建立目錄結構（5 分鐘）

```bash
# 在教學 repo 的同層建立知識庫
mkdir -p agent-framework-kb/{raw/{adrs,samples,api-surface,release-notes,devblogs},wiki/{concepts},brainstorming/{quality-reviews,chapter-planning}}

# 建立 symlink 到現有教學
cd agent-framework-kb
ln -s ../microsoft-agent-framework-tutorial tutorial
```

### Step 2：同步上游 ADR 素材（10 分鐘）

```bash
# 方法 A：git sparse-checkout（推薦）
cd raw
git clone --filter=blob:none --sparse \
  https://github.com/microsoft/agent-framework.git \
  _upstream
cd _upstream
git sparse-checkout set docs/decisions
# 之後定期 git pull 即可

# 方法 B：手動下載
# 直接將 ADR markdown 檔放入 raw/adrs/
```

### Step 3：安裝 llm-wiki-compiler plugin（2 分鐘）

```bash
# 在 Claude Code 中執行
claude /install-plugin ussumant/llm-wiki-compiler

# 或手動安裝
git clone https://github.com/ussumant/llm-wiki-compiler.git
claude --plugin-dir ./llm-wiki-compiler/plugin
```

### Step 4：撰寫 CLAUDE.md（核心設定）

這是整套系統的靈魂。在 `agent-framework-kb/CLAUDE.md` 中定義編譯規則：

```markdown
# Agent Framework 知識庫

## 專案概述
這是 Microsoft Agent Framework 繁體中文教學的知識管理系統。
wiki/ 由 LLM 編譯 raw/ 素材產生，用於追蹤上游 API 變更並偵測教學內容偏移。

## 目錄角色
- raw/：上游素材（ADR、範例、Release Notes），唯讀不修改
- wiki/：LLM 編譯的結構化知識，由 /compile 指令產生
- tutorial/：現有 28 章教學，由人工決定是否修改
- brainstorming/：品質稽核記錄

## 編譯規則
- 語言：繁體中文
- 每個 wiki/concepts/ 條目必須包含：
  - YAML frontmatter（title, updated, tags, sources）
  - 目前的 API 簽名（C# 程式碼）
  - 變更歷史（從哪個版本改成現在的樣子）
  - 教學章節對應（哪些章節使用了這個概念）
- wiki/api-changelog.md 記錄所有 breaking change 的時間線
- wiki/drift-report.md 比對 wiki/concepts/ 與 tutorial/ 的差異

## drift-check 偵測規則
以下情況標記為 🔴 Breaking：
- tutorial/ 中的 C# 類別名稱在最新 API 中已不存在
- 方法簽名（參數型別、回傳型別）不匹配
- using namespace 已變更

以下情況標記為 🟡 Outdated：
- 描述文字使用舊名稱（如 AgentThread 而非 AgentSession）
- 章節提及「未來製作」但內容已完成
- NuGet 套件版本過時

以下情況標記為 🟢 Enhancement：
- 上游新增了教學未涵蓋的功能
- 有新的官方範例可參考
```

### Step 5：初始編譯（15-30 分鐘）

```bash
cd agent-framework-kb
claude

# 在 Claude Code 中執行
> /compile
```

首次編譯會：
1. 讀取 raw/ 中所有 ADR 文件
2. 為每個核心概念建立 wiki/concepts/ 條目
3. 建立 wiki/INDEX.md 主索引
4. 建立 wiki/api-changelog.md
5. 執行初次 drift-check

### Step 6：驗證（5 分鐘）

```bash
# 用 Obsidian 開啟 wiki/ 目錄，確認：
# - concepts/ 條目是否涵蓋所有核心 API
# - INDEX.md 索引是否完整
# - drift-report.md 是否正確偵測到已知問題

# 或直接在 Claude Code 中查詢
> /wiki-query "AgentSession 的建立方式"
> /wiki-lint
```

---

## 六、兩種建置路線比較

如果你不想裝 plugin，也可以純手動用 Claude Code 的自訂 commands 實現相同效果：

| 面向 | Plugin 路線（llm-wiki-compiler） | 純 Claude Code Commands 路線 |
|------|----------------------------------|------------------------------|
| 安裝複雜度 | `claude /install-plugin` 一行 | 自己寫 `.claude/commands/*.md` |
| 開箱即用的功能 | compile, lint, query, visualize | 只有你自己定義的 |
| 客製化程度 | 中（透過 SCHEMA.md 調整） | 高（完全自訂） |
| 維護成本 | 跟隨 plugin 更新 | 自己維護 commands |
| 適合場景 | 快速起步、標準 wiki 需求 | 深度客製化、特殊偏移偵測邏輯 |

**我的建議**：先用 Plugin 路線快速起步，等遇到 plugin 不夠用的地方再寫自訂 commands 擴充。兩者可以共存。

---

## 七、與現有工具的整合

### 整合 dotnet-testing-monitor skill

你已有的 `dotnet-testing-monitor` skill 會監控 NuGet 套件版本更新並寄 Gmail 通知。可以擴展它：

```
dotnet-testing-monitor 偵測到套件版本更新
        ↓
觸發 /sync-upstream + /compile + /drift-check
        ↓
drift-report 有 🔴 Breaking
        ↓
Gmail 通知（附上偏移摘要）
```

### 整合 Cowork Scheduled Task

```
每週一 09:00 排程：
  1. git pull raw/_upstream
  2. /compile（增量）
  3. /drift-check
  4. 有 🔴 → Gmail 通知
```

---

## 八、預期效果

| 現在（手動） | 導入後 |
|-------------|-------|
| 上游改 API → 你不知道 → 讀者回報 → 逐章找問題 | 上游改 API → 自動偵測 → drift-report 列出影響範圍 |
| 品質檢查耗時 2+ 小時逐章比對 | /drift-check 幾分鐘產出完整報告 |
| 容易漏改（如 ch12 的 ThreadId 有兩處沒改到） | 偏移報告列出所有出現位置 |
| 新章節需要從頭研究上游文件 | wiki/concepts/ 已有結構化摘要可直接查詢 |

---

## 九、注意事項與限制

1. **LLM 編譯不等於 dotnet build**：drift-check 是基於文字比對與語意理解，不能取代實際的程式碼編譯。建議搭配 CI 中的 `dotnet build` 做雙重驗證。

2. **首次編譯需要時間**：第一次 /compile 會處理所有 raw/ 素材，預估 15-30 分鐘。之後增量編譯只處理新增/修改的檔案。

3. **raw/ 同步需要紀律**：系統的偵測品質取決於 raw/ 素材的時效性。建議設排程自動同步，或至少每次上游發版後手動更新。

4. **wiki/ 是可重建的**：如果 wiki/ 內容品質不好，刪掉重新 /compile 就好。真正有價值的是 raw/ 和 tutorial/。
