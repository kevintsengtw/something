# Ch29 — Agent Skills 技能系統：設計規格

> 建立日期：2026-05-08
> 狀態：已核准，待實作

---

## 目標

在現有教學（ch01–ch28）之後新增第 29 章，完整介紹 Microsoft Agent Framework v1.1.0 GA 的 Agent Skills 技能系統。讀者完成本章後，能夠使用三種方式定義 Skill、混合多來源、整合 DI，並了解 v1.4.0 的 Breaking Change。

---

## 章節基本資訊

| 項目 | 內容 |
|------|------|
| 檔案名稱 | `29-agent-skills.md` |
| 位置 | `microsoft-agent-framework-tutorial/` |
| 章節號 | 29（ch28 之後） |
| 目標讀者 | 已完成 ch01–ch28 的 C# 開發者 |
| API 版本 | v1.1.0 GA（部分內容涉及 v1.4.0） |
| 對應 wiki | `wiki/concepts/agent-skills.md` |

---

## 貫穿情境

**公司政策問答代理（HR Policy Agent）**

一個員工自助服務代理，需要回答三類問題：

| 知識領域 | 維護方式 | 使用的 Skill 類型 |
|----------|---------|-----------------|
| 請假規定 | 非技術人員維護的 Markdown 文件 | File-Based |
| 費用報銷 | 需要匯率計算等程式邏輯 | Class-Based（`AgentClassSkill<T>`） |
| IT 設備申請 | 庫存是動態資料（每次讀取時取得） | Inline（`AgentInlineSkill`） |

同一情境貫穿全章，讓讀者清楚看出三種類型的差異與適用時機。

---

## 章節結構

### 第一節：概念說明

1. **Agent Skills 解決什麼問題**
   - 傳統做法（把所有知識塞入 System Prompt）的 token 成本問題
   - Skills 的核心設計：打包工具 + 資源 + 腳本為可攜式套件

2. **情境介紹**：公司政策問答代理需求說明

3. **漸進式揭露（Progressive Disclosure）四階段**

   ```
   ① Advertise — system prompt 只注入技能名稱/描述（~100 tokens/技能）
   ② Load      — 代理決定需要某技能時才載入完整指令（建議 < 5000 tokens）
   ③ Read      — 按需讀取技能內的資源（文件、表格）
   ④ Run       — 執行技能內的腳本（計算、查詢外部資料）
   ```

4. **NuGet 套件**：`Microsoft.Agents.AI`（Skills 屬於核心套件，無需額外安裝）

---

### 第二節：三種 Skill 實作方式

#### 2-A. File-Based Skills（檔案式）

**適用情境**：請假規定由 HR 人員維護，存放在資料夾中是最自然的方式。

**目錄結構**：
```
skills/
└── hr-policy/
    ├── SKILL.md
    ├── references/
    │   └── leave-policy.md
    └── scripts/
        └── check-quota.py
```

**SKILL.md 格式**（YAML frontmatter + 指令）完整範例。

**程式碼**：
- 建立 `AgentSkillsProvider`（傳入目錄路徑 + `SubprocessScriptRunner.RunAsync`）
- 使用 `AgentFileSkillsSourceOptions` 自訂探索規則

**⚠️ v1.4.0 Breaking Change（PR #5475）**：
- File-based script 引數型別由單一字串改為 `string[]`
- Before/After 對比（Python 腳本接收引數的方式）

#### 2-B. Class-Based Skills（類別式）

**適用情境**：費用報銷需要匯率換算、金額上限判斷等 C# 邏輯。

**完整實作**：`ExpenseSkill : AgentClassSkill<ExpenseSkill>`
- `override AgentSkillFrontmatter Frontmatter`
- `override string Instructions`
- `[AgentSkillResource]` + `[Description]` 屬性標記資源屬性
- `[AgentSkillScript]` + `[Description]` 屬性標記靜態腳本方法

**程式碼**：建立 `AgentSkillsProvider(new ExpenseSkill())` 並傳入代理。

#### 2-C. Inline Skills（內聯式）

**適用情境**：IT 設備庫存是動態資料，每次讀取時才從記憶體 / 環境變數取得。

**兩種資源寫法對比**：
- 靜態資源：`.AddResource("name", "靜態字串")`
- 動態資源：`.AddResource("name", () => /* factory lambda */)`

**程式碼**：完整 `AgentInlineSkill` 建立 + 加入代理。

**節尾過渡**：三種方式各自可獨立使用，現實專案通常混用 → 引出 Builder。

---

### 第三節：進階組合與設定

#### 3-A. AgentSkillsProviderBuilder（混合多來源）

把第二節三個 Skill 組合為一個 Provider：

```csharp
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(...)
    .UseSkill(new ExpenseSkill())
    .UseSkill(itEquipmentSkill)
    .UseFileScriptRunner(SubprocessScriptRunner.RunAsync)
    .UseFilter(skill => approvedSkills.Contains(skill.Frontmatter.Name))
    .Build();
```

說明 `.UseFilter()` 用途：管理員可動態控制哪些 Skill 對外開放。

#### 3-B. DI 整合（`IServiceProvider`）

**適用情境**：`ExpenseSkill` 需要讀取資料庫中的最新匯率。

**兩種注入方式**：
- `AgentClassSkill<T>` 方法參數直接接收 `IServiceProvider`
- `AgentInlineSkill` 的 `.AddResource()` / `.AddScript()` lambda 接收 `IServiceProvider`

**完整接線程式碼**：`services.AddSingleton<>()` + `chatClient.AsAIAgent(..., services: serviceProvider)`

#### 3-C. AgentSkillsProviderOptions（進階控制）

| 選項 | 用途 | 適用場景 |
|------|------|---------|
| `ScriptApproval = true` | 腳本執行需人工確認 | 生產環境安全管控（呼應 ch16 Human-in-the-Loop） |
| `DisableCaching = true` | 停用技能快取 | 開發期間確保每次讀到最新內容 |
| `SkillsInstructionPrompt` | 自訂注入 System Prompt 的格式 | 多語言環境或特定 LLM 指令格式 |

---

### 第四節：選擇指引與小結

**Skills vs. Tools vs. Workflows 選擇表**：

| 情境 | 建議機制 |
|------|---------|
| 一次性計算 / 外部 API 呼叫 | Tools（`AIFunctionFactory`） |
| 可重用的知識領域（文件 + 邏輯 + 腳本） | Agent Skills |
| 多步驟、有副作用、需要 Checkpointing | Workflows |

**小結條列**：
- 漸進式揭露機制與 token 節省原理
- 三種類型的適用情境對照
- `AgentSkillsProviderBuilder` 混合來源
- DI 整合
- `ScriptApproval` 生產環境安全控制
- v1.4.0 `string[]` Breaking Change

**章節連結**：
- ch05（Tools 基礎）延伸閱讀中的舊版寫法指向本章
- 附錄 D ADR 0021 中的 Proposed 狀態說明更新指向本章
- 下一步：ch12（測試策略）、ch11（ASP.NET Core 託管）、ch16（Human-in-the-Loop）

---

## 範例程式碼完整度要求

每個 Skill 類型提供**可獨立編譯執行**的完整範例，包含：
- 所有必要的 `using` 陳述式
- NuGet 套件引用（`dotnet add package`）
- 環境變數設定說明
- 預期輸出說明

---

## 知識庫對應

| 項目 | 路徑 |
|------|------|
| Wiki 條目 | `wiki/concepts/agent-skills.md` |
| 原始素材 | `raw/adrs/0021-agent-skills-design.md` |
| 官方範例 | `raw/samples/README.md`（`02-agents/AgentSkills` 五步驟） |
| DevBlog | `raw/devblogs/agent-skills-three-ways.md` |
| Learn 文件 | `raw/learn/agent-skills.md` |
