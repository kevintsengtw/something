---
source: https://github.com/microsoft/agent-framework/releases/tag/python-1.6.0
fetched: 2026-05-25
type: release-notes
version: 1.6.0
platform: python
---

# python-1.6.0

**Release Date:** 2026-05-20

## Breaking Changes

- **Instrumentation 預設啟用**（[#5612](https://github.com/microsoft/agent-framework/pull/5612)）：
  OpenTelemetry 追蹤功能現在預設啟用（之前需手動開啟）。若環境中無 OpenTelemetry collector，需主動停用以避免連線錯誤。

## Added

- **Shell Tool**（[#5589](https://github.com/microsoft/agent-framework/pull/5589)）：
  新增 shell 執行工具，讓代理可在受控環境中執行 shell 指令（Python SDK parity）。

- **Monty / CodeAct provider**（[#5598](https://github.com/microsoft/agent-framework/pull/5598)）：
  新增 Monty 與 CodeAct 整合的 Python provider，與 .NET 的 CodeAct GA（v1.4.0）對應。

## Fixed

- 多項錯誤修正與效能改善
