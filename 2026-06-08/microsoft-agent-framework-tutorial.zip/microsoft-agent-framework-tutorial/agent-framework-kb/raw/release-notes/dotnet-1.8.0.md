---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.8.0
fetched: 2026-06-06
release_date: 2026-05-28
version: 1.8.0
---

# .NET Agent Framework v1.8.0（2026-05-28）

## 重大變更（Breaking Changes）

### 1. 移除 Declarative Workflows 的 Code-Gen 支援

**PR：** [#6095](https://github.com/microsoft/agent-framework/pull/6095)（@peibekwe）

宣告式工作流程（Declarative Workflows）不再支援 code-gen。原本依賴程式碼產生路徑的宣告式工作流程需改用執行期解譯（runtime interpretation）方式。

**影響範圍：** 使用 Declarative Workflows 且依賴 code-gen 的 .NET 專案。

---

### 2. 重構 AgentFileSkillsSource — depth-based discovery 與 predicate filter

**PR：** [#6109](https://github.com/microsoft/agent-framework/pull/6109)（@semenshi）

`AgentFileSkillsSource` 的檔案探索機制改為以 **depth-based discovery**（依目錄深度探索）搭配 **predicate filters**（述詞過濾）。原本的目錄掃描行為與設定方式改變。

**影響範圍：** 使用檔案式 skills（`AgentFileSkillsSource` / `AgentFileSkill`）並自訂探索目錄結構的 .NET 專案。

---

## 新功能

### ForeachExecutor 迭代狀態跨 checkpoint 持久化

**PR：** [#6051](https://github.com/microsoft/agent-framework/pull/6051)（@peibekwe）

`ForeachExecutor` 的迭代狀態現在會跨 checkpoint 持久化，使工作流程在中斷後可正確還原迴圈進度。

### MCP-based skills 支援（skill-md type）

**PR：** [#6108](https://github.com/microsoft/agent-framework/pull/6108)（@semenshi）

新增以 MCP 為基礎的 skills 支援，引入 `skill-md` 類型。

### ClaimsIdentity-based session scoping

**PR：** [#5696](https://github.com/microsoft/agent-framework/pull/5696)（@lokitoth）

支援以 `ClaimsIdentity` 對 agent sessions 進行 scoping，便於多租戶/多使用者場景隔離工作階段。

### Handoff Orchestration 與 Python 對齊

**PR：** [#6138](https://github.com/microsoft/agent-framework/pull/6138)（@lokitoth）

.NET 的 Handoff Orchestration 行為與 Python 版本對齊，達成跨語言一致性。

---

## API 變更 / 移除

### 移除 FoundryAgent 等的 responses experimental flag

**PR：** [#6121](https://github.com/microsoft/agent-framework/pull/6121)（@westey-m）

移除 `FoundryAgent` 等型別上的 responses experimental flag。對應功能脫離實驗階段。

---

## Bug 修復

| 問題 | PR | 說明 |
|------|-----|------|
| 渲染重複與文字輸入清除 | [#6136](https://github.com/microsoft/agent-framework/pull/6136) | 修正 render dupe 與 text input clear bug，並改善 guardrail 錯誤訊息 |

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 | 嚴重性 |
|------|---------------|--------|
| 移除 Declarative Workflows code-gen | `workflows`、`declarative-workflows` | 🔴 Breaking |
| AgentFileSkillsSource depth-based discovery | `agent-skills`、`agent-file-skill` | 🔴 Breaking |
| ForeachExecutor 狀態持久化 | `workflows`、`durable-agents` | 🟢 新功能 |
| MCP-based skills（skill-md） | `agent-skills`、`mcp-integration` | 🟢 新功能 |
| ClaimsIdentity session scoping | `agent-session` | 🟢 新功能 |
| Handoff Orchestration 對齊 | `magentic-orchestration`、`workflows` | 🟢 Enhancement |
| FoundryAgent responses flag 移除 | `llm-providers` | 🟡 API 變更 |
