---
source: https://github.com/microsoft/agent-framework/releases/tag/python-1.5.0
fetched: 2026-05-25
type: release-notes
version: 1.5.0
platform: python
---

# python-1.5.0

**Release Date:** 2026-05-13

## Added

- **Foundry hosted agents 範例**（[#5521](https://github.com/microsoft/agent-framework/pull/5521)）：
  新增使用 Azure AI Foundry hosted agents 的 Python 範例，展示雲端託管代理的整合模式。

## Changed

- **`durabletask` 最低版本要求提升至 1.4.0+**：
  Python workflow 相依的 `durabletask` 套件需升級至 1.4.0 或以上版本。

## Fixed

- 多項錯誤修正與依賴項更新
