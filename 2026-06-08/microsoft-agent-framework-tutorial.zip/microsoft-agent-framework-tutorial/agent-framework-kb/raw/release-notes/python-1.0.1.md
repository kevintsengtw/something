---
source: https://github.com/microsoft/agent-framework/releases/tag/python-1.0.1
fetched: 2026-04-17
type: release-notes
version: 1.0.1
platform: python
---

# python-1.0.1

**Release Date:** 2026-04-09

## Breaking Changes

- **`FileCheckpointStorage` security hardening** ([#4941](https://github.com/microsoft/agent-framework/pull/4941)):
  Checkpoint deserialization now uses a restricted unpickler by default. Only built-in safe Python types
  and all `agent_framework` types are permitted. Custom types must be explicitly allowed via the new
  `allowed_checkpoint_types` constructor parameter (format: `"module:qualname"`).

## Added

- **Cosmos DB NoSQL checkpoint storage** ([#4916](https://github.com/microsoft/agent-framework/pull/4916)):
  New `agent-framework-azure-cosmos` package with Cosmos DB checkpoint storage for Python workflows
- **Neo4j GraphRAG samples** ([#4010](https://github.com/microsoft/agent-framework/pull/4010))

## Changed

- Handoff workflow context management fix — breaking ([#5136](https://github.com/microsoft/agent-framework/pull/5136))
- Removed pre-release flag from installation instructions ([#5082](https://github.com/microsoft/agent-framework/pull/5082))
- MCP dependency: 1.26.0 → 1.27.0

## Fixed

- `response_format` crash on background polling with empty text ([#5146](https://github.com/microsoft/agent-framework/pull/5146))
- Strip tools from `FoundryAgent` request when `agent_reference` present ([#5101](https://github.com/microsoft/agent-framework/pull/5101))
- TypeVar annotation handler registration error ([#4944](https://github.com/microsoft/agent-framework/pull/4944))
- Entity key validation ([#5179](https://github.com/microsoft/agent-framework/pull/5179))
