---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.3.0
fetched: 2026-04-24
date: 2026-04-24
nuget: https://www.nuget.org/packages/Microsoft.Agents.AI/1.3.0
---

# .NET Agent Framework v1.3.0（2026-04-24）

## 重大變更（Breaking Changes）

### [Breaking] A2A SDK v1 遷移（PR #5423）

**套件：** `Microsoft.Agents.AI.A2A`、`Microsoft.Agents.AI.Hosting.A2A`、`Microsoft.Agents.AI.AspNetCore`

A2A SDK 從 `0.3.4-preview` 升級至 `1.0.0-preview2`，API 層全面重構。

#### 移除的型別／擴充方法

| 移除項目 | 替代項目 |
|---------|---------|
| `EndpointRouteBuilderExtensions` | `A2AEndpointRouteBuilderExtensions` |
| `AIAgentExtensions`（A2A 相關） | `A2AServerServiceCollectionExtensions` |

#### 新增的型別

| 型別 | 套件 | 說明 |
|------|------|------|
| `A2AAgentHandler` | Hosting.A2A | v1 SDK 對應的 handler，取代舊有處理邏輯 |
| `A2AServerRegistrationOptions` | Hosting.A2A | A2A server 註冊設定物件 |
| `A2AServerServiceCollectionExtensions` | Hosting.A2A | DI 註冊的統一入口 |
| `A2AEndpointRouteBuilderExtensions` | AspNetCore | 協定專屬的 endpoint 對應方法 |

#### API 行為變更

- `A2AAgentCardExtensions` / `A2ACardResolverExtensions`：改用 `A2AClientFactory.Create()` 建立 client，接受可選的 `A2AClientOptions`
- `A2AClientExtensions`：操作對象由具體 `A2AClient` 改為 `IA2AClient` 介面
- 新增 SSE stream reconnection 支援（continuation token 機制），串流中斷可自動恢復

### Azure.AI.AgentServer.Responses SDK beta.3 → beta.4 破壞性變更（PR #5450）

| 舊名稱 | 新名稱 / 變更 |
|-------|--------------|
| `FunctionToolCallOutputResource` | `OutputItemFunctionToolCallOutput` |
| `AzureAIAgentServerResponsesModelFactory`（public） | 已設為 internal，改用直接建構子 |
| `ResponseUsage` 建構子 | 現在要求 token details 參數必須非 null |

---

## 新功能

### Server-side Foundry Toolbox 支援（PR #5450）

**套件：** `Microsoft.Agents.AI.Foundry.Hosting`

對應 Python `FoundryChatClient.get_toolbox()` 的 .NET 伺服器端實作。從 Foundry project SDK 取得 toolbox 工具，作為 server-side tools 傳入 Responses API 請求。

新增類別：
- `FoundryToolbox` — 核心實作，使用 `AgentAdministrationClient` SDK
- `AIProjectClientToolboxExtensions` — `AIProjectClient` 的擴充方法

新增 Sample：`Agent_Step25_ToolboxServerSideTools`

### A2A Streaming Support（PR #5427）

**套件：** `Microsoft.Agents.AI.Hosting.A2A`

`A2AAgentHandler.ExecuteAsync` 現在依 `context.StreamingResponse` 路由至：
- `true` → `HandleNewMessageStreamingAsync`（使用 `RunStreamingAsync`）
- `false` → 原有非串流路徑（使用 `RunAsync`）

新增輔助方法：
- `CreateMessageFromUpdate` — 將 `AgentResponseUpdate` 轉換為 A2A `Message`
- `MessageConverter.ToParts(AgentResponseUpdate)` — 轉換串流更新內容為 A2A `Part` 物件（不支援的內容型別會被過濾）

### Dynamic Tool Expansion Sample（PR #5425）

新增範例：示範如何透過另一個工具呼叫動態擴展可用工具清單（`samples/` 中）。

---

## Bug 修復

| PR | 說明 | 影響概念 |
|----|------|---------|
| #5412 | 修正 `StreamingRunEventStream.RunLoopAsync` 中 `RunStatus` 的 off-thread race condition：`GetStatusAsync` 在 `ResumeAsync` halt 後可能誤回傳 Running | durable-agents, long-running-operations |

---

## 套件更新

| 套件 | 舊版 | 新版 |
|------|------|------|
| `Microsoft.Agents.AI.Hosting.Aspire` | stable | preview（PR #5444） |
| `Microsoft.ML.Tokenizers` | — | ≥ 2.0.0（新增依賴） |

---

## Samples 異動

| 樣本路徑 | 變更 |
|---------|------|
| `samples/04-hosting/A2A/` → `samples/02-agents/A2A/` | A2A 範例重新分類 |
| `A2AAgent_ProtocolSelection`（新增） | 示範協定選擇 |
| `A2AAgent_StreamReconnection`（新增） | 示範 SSE 串流重連 |
| `Agent_Step25_ToolboxServerSideTools`（新增） | Foundry Toolbox server-side 範例 |
| `A2AClientServer`、`AgentWebChat`、`A2AAgent_PollingForTaskCompletion` | 更新為新 A2A v1 API |

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 |
|------|---------------|
| A2A SDK v1 遷移（Breaking） | `a2a-protocol` |
| A2A Streaming | `a2a-protocol`, `run-async` |
| Foundry Toolbox（Server-side） | `llm-providers`, `tools-ai-function` |
| RunStatus race fix | `durable-agents`, `long-running-operations` |
