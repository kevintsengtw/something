---
source: https://devblogs.microsoft.com/agent-framework/agent-skills-in-net-three-ways-to-author-one-provider-to-run-them/
fetched: 2026-04-23
author: Sergey Menshykh (Principal Software Engineer)
date: 2026-04-13
---

# Agent Skills in .NET: Three Ways to Author, One Provider to Run Them

**Author:** Sergey Menshykh, Principal Software Engineer
**Date:** April 13, 2026

## The Three Skill Authoring Methods

### 1. File-Based Skills

File-based skills live as directories containing skill metadata and supporting resources:

```
skills/
└── onboarding-guide/
    ├── SKILL.md
    ├── scripts/
    │   └── check-provisioning.py
    └── references/
        └── onboarding-checklist.md
```

Setup requires specifying the skills directory and providing a script runner:

```csharp
var skillsProvider = new AgentSkillsProvider(
    Path.Combine(AppContext.BaseDirectory, "skills"),
    SubprocessScriptRunner.RunAsync);
```

### 2. Class-Based Skills (from NuGet Packages)

Class-based skills derive from `AgentClassSkill<T>` and use reflection-based discovery through attributes:

```csharp
public sealed class BenefitsEnrollmentSkill : AgentClassSkill<BenefitsEnrollmentSkill>
{
    public override AgentSkillFrontmatter Frontmatter { get; } = new(
        "benefits-enrollment",
        "Enroll an employee in health, dental, or vision plans.");

    protected override string Instructions => """
        Use this skill when an employee asks about enrolling in or changing their benefits.
        """;

    [AgentSkillResource("available-plans")]
    [Description("Health, dental, and vision plan options with monthly pricing.")]
    public string AvailablePlans => """
        ## Available Plans (2026)
        - Health: Basic HMO ($0/month), Premium PPO ($45/month)
        - Dental: Standard ($12/month), Enhanced ($25/month)
        - Vision: Basic ($8/month)
        """;

    [AgentSkillScript("enroll")]
    [Description("Enrolls an employee in the specified benefit plan.")]
    private static string Enroll(string employeeId, string planCode)
    {
        bool success = HrClient.EnrollInPlan(employeeId, planCode);
        return JsonSerializer.Serialize(new { success, employeeId, planCode });
    }
}
```

Key attributes:
- **`[AgentSkillResource]`**: Applied to properties or methods; methods support `IServiceProvider` for dependency resolution
- **`[AgentSkillScript]`**: Applied only to methods; supports `IServiceProvider` injection

### 3. Inline/Code-Defined Skills

`AgentInlineSkill` allows skill definitions directly within application code using a fluent builder pattern:

```csharp
var timeOffSkill = new AgentInlineSkill(
    name: "time-off-balance",
    description: "Calculate an employee's remaining vacation and sick days.",
    instructions: """
        Use this skill when an employee asks how many vacation or sick days they have left.
        1. Ask for the employee ID if not already provided.
        2. Use the calculate-balance script to get the remaining balance.
        3. Present the result clearly, showing both used and remaining days.
        """)
    .AddScript("calculate-balance", (string employeeId, string leaveType) =>
    {
        int totalDays = HrDatabase.GetAnnualAllowance(employeeId, leaveType);
        int daysUsed = HrDatabase.GetDaysUsed(employeeId, leaveType);
        int remaining = totalDays - daysUsed;
        return JsonSerializer.Serialize(new { employeeId, leaveType, totalDays, daysUsed, remaining });
    });
```

Inline skills support dynamic resources via factory delegates (invoked each time agent reads the resource):

```csharp
var hrPoliciesSkill = new AgentInlineSkill(
    name: "hr-policies",
    description: "Current HR policies on leave, remote work, and conduct.",
    instructions: "Read the policies resource and answer the employee's question.")
    .AddResource("policies", () =>
    {
        return PolicyRepository.GetActivePolicies();
    });
```

## Unified Provider: AgentSkillsProviderBuilder

`AgentSkillsProviderBuilder` composes all three approaches:

```csharp
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "skills"))
    .UseSkill(new BenefitsEnrollmentSkill())
    .UseSkill(timeOffSkill)
    .UseFileScriptRunner(SubprocessScriptRunner.RunAsync)
    .Build();
```

## Advanced Features

**Script Approval Mechanism:**

```csharp
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "skills"))
    .UseSkill(new BenefitsEnrollmentSkill())
    .UseFileScriptRunner(SubprocessScriptRunner.RunAsync)
    .UseScriptApproval(true)
    .Build();
```

**Filtering from Shared Repositories:**

```csharp
var approvedSkills = new HashSet<string> { "onboarding-guide", "benefits-enrollment" };

var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "all-skills"))
    .UseFilter(skill => approvedSkills.Contains(skill.Frontmatter.Name))
    .Build();
```

## Key Design Insights

- Teams can author and ship skills independently as file directories in a shared repository or as NuGet packages
- Compose multiple teams' skills via `AgentSkillsProviderBuilder` without inter-team coordination
- Inline skills serve as temporary bridges when third-party packages aren't ready, with seamless replacement once official versions ship
