---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0006-userapproval.md
fetched: 2026-04-17
status: Accepted
date: 2025-09-12
contact: westey-m
---

# ADR 0006: Agent User Approvals — Content Types and FunctionCall Approvals Design

**Status:** Accepted
**Date:** 2025-09-12
**Contact:** westey-m

## Context

When agents operate on behalf of users, some operations require explicit user approval before proceeding —
especially for remote agents where the user isn't immediately available. Also covers service-side MCP
invocation approval.

## Decision

**Option 5** — Base `UserInputRequestContent` / `UserInputResponseContent` types with subclasses per scenario.

### Key Types

```csharp
// Base types
class UserInputRequestContent : AIContent { public string Id { get; set; } }
class UserInputResponseContent : AIContent { public string Id { get; set; } }

// For approving a function call
class FunctionApprovalRequestContent : UserInputRequestContent
{
    public FunctionCallContent FunctionCall { get; set; }
    public FunctionApprovalResponseContent CreateApproval() => ...;
    public FunctionApprovalResponseContent CreateRejection() => ...;
}
class FunctionApprovalResponseContent : UserInputResponseContent
{
    public bool Approved { get; set; }
    public FunctionCallContent FunctionCall { get; set; }
}

// For text-described approval
class TextApprovalRequestContent : UserInputRequestContent { public string Text { get; set; } }
class TextApprovalResponseContent : UserInputResponseContent { public bool Approved { get; set; } }

// AgentResponse gains aggregation property
class AgentResponse
{
    public IEnumerable<UserInputRequestContent> UserInputRequests { get; set; }
}
```

### Usage Pattern

```csharp
var response = await agent.RunAsync("Book me a flight for Friday to Paris.", thread);
while (response.UserInputRequests.Any())
{
    List<ChatMessage> messages = new();
    foreach (var req in response.UserInputRequests)
    {
        if (req is FunctionApprovalRequestContent approvalReq)
        {
            // Show user the FunctionCall details, get approval
            messages.Add(new ChatMessage(ChatRole.User, approvalReq.CreateApproval()));
        }
    }
    response = await agent.RunAsync(messages, thread);
}
```

## Note

`FunctionInvokingChatClient` (FIC) intercepts function calls requiring approval and converts them to
`FunctionApprovalRequestContent`. Rejected approvals produce a `FunctionResultContent` with "denied" message.
This replaces the previous `ApprovalRequiredAIFunction` pattern.
