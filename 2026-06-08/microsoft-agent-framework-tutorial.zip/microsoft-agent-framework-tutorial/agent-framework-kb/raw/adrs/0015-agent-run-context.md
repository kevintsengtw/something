---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0015-agent-run-context.md
fetched: 2026-04-17
status: Proposed
date: 2026-01-27
contact: westey-m
---

# ADR 0015: AgentRunContext for Agent Run

**Status:** Proposed
**Date:** 2026-01-27
**Contact:** westey-m

## Context

During an agent run, components like middleware, tools, and nested agents need access to contextual
information (the running agent, session, request messages, run options) without explicit parameter
passing through every layer. A standardized mechanism is needed for ambient access.

## Decision

**Option 3** — Combination of explicit parameters to `RunCoreAsync` + `AsyncLocal<T>` ambient access.

### API

```csharp
public class AgentRunContext
{
    public AgentRunContext(
        AIAgent agent,
        AgentSession? session,
        IReadOnlyCollection<ChatMessage> requestMessages,
        AgentRunOptions? agentRunOptions);

    public AIAgent Agent { get; }
    public AgentSession? Session { get; }
    public IReadOnlyCollection<ChatMessage> RequestMessages { get; }
    public AgentRunOptions? RunOptions { get; }
}

// Static ambient access on AIAgent
public static AgentRunContext? CurrentRunContext
{
    get => s_currentContext.Value;    // AsyncLocal — flows across async/await
    protected set => s_currentContext.Value = value;
}
```

### Usage in tools / middleware

```csharp
// Access parent agent context from deeply nested tool call
var session = AIAgent.CurrentRunContext?.Session;
var parentAgent = AIAgent.CurrentRunContext?.Agent;

// Example: pass parent session to sub-agent
var response = await subAgent.RunAsync(query, session: session);
```

## Consequences

- All properties are read-only to discourage in-flight mutation
- `AsyncLocal<T>` automatically flows across async/await boundaries
- Internal components receive parameters explicitly via `RunCoreAsync`; external code uses `CurrentRunContext`
