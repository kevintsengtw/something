---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0016-structured-output.md
fetched: 2026-04-17
status: Proposed
date: 2026-01-22
contact: sergeymenshykh
---

# ADR 0016: Structured Output

**Status:** Proposed
**Date:** 2026-01-22
**Contact:** sergeymenshykh
**Deciders:** rbarreto, westey-m, stephentoub

## Context

Structured output is supported by `ChatClientAgent` via two approaches:
1. `ResponseFormat` property + `JsonSerializer.Deserialize<T>` — flexible but cumbersome for primitives/arrays
2. Generic `RunAsync<T>` returning `AgentResponse<T>` — convenient but limited to `ChatClientAgent` (not base `AIAgent`)

Problem: applying `OpenTelemetryAgent` decorator over `ChatClientAgent` hides `RunAsync<T>` since it's not on `AIAgent`.

## Decision

Two complementary approaches remain, with improvements to each:

### Approach 1: ResponseFormat + Deserialize (existing, enhanced)

```csharp
// At agent creation time
ChatClientAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions()
{
    ChatOptions = new() { ResponseFormat = ChatResponseFormat.ForJsonSchema<PersonInfo>() }
});

AgentResponse response = await agent.RunAsync("Extract person info from this text.");
PersonInfo info = response.Deserialize<PersonInfo>(JsonSerializerOptions.Web);
```

Use when: SO type unknown at compile time, streaming, declarative agents, `AIProjectClient`.
Limitation: primitives and arrays not directly supported (root must be JSON object).

### Approach 2: Generic RunAsync\<T\> (improved — move to AIAgent base)

```csharp
// Move RunAsync<T> to AIAgent base class so decorators don't hide it
AgentResponse<PersonInfo> response = await agent.RunAsync<PersonInfo>("Extract...");
Console.WriteLine($"Name: {response.Result.Name}");

// Works with primitives and collections (framework handles JSON wrapping internally)
AgentResponse<List<string>> items = await agent.RunAsync<List<string>>("List ingredients.");
```

## Consequences

- `RunAsync<T>` moved to `AIAgent` base class enables structured output through decorator chains
- Framework handles schema wrapping/unwrapping for primitives and collections
- Both approaches co-exist; use `ResponseFormat` for non-`AIAgent` scenarios
