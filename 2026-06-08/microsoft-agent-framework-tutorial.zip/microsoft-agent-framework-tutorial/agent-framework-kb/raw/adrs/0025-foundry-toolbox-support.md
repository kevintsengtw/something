---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0025-foundry-toolbox-support.md
fetched: 2026-04-23
status: Proposed
date: 2026-04-10
contact: evmattso
language: Python
---

# ADR 0025: Foundry Toolbox Support in FoundryChatClient

**Status:** Proposed
**Date:** 2026-04-10
**Contact:** evmattso
**語言：** Python

## Context

Azure AI Foundry 在 `azure-ai-projects==2.1.0a20260409002` 引入 `BetaToolboxesOperations`，讓團隊可以「將相關的 hosted tools 分組到具名的 toolbox 中，不可變版本化 toolbox，並在多個代理間共享 toolbox」。

目前消費 toolbox 需要三個手動步驟；其他 Foundry 工具已在 `FoundryChatClient` 上有工廠方法（code interpreter、file search、web search）。

## 決策

在 `FoundryChatClient` 上新增 `get_toolbox(name, version=None)` 實例方法：

```python
async def get_toolbox(
    self,
    name: str,
    *,
    version: str | None = None,
) -> ToolboxVersionObject:
    """Fetch a Foundry toolbox by name, optionally pinning to a specific version."""
```

## 使用範例

```python
# 基本使用
toolbox = await client.get_toolbox("research_tools")
agent = Agent(client=client, instructions="...", tools=toolbox)

# 版本固定
toolbox = await client.get_toolbox("research_tools", version="v3")

# 多個 toolbox
toolbox_a = await client.get_toolbox("research_tools")
toolbox_b = await client.get_toolbox("other_tools", version="v3")
agent = Agent(client=client, instructions="...", tools=[toolbox_a, toolbox_b])

# 選擇性工具包含
from agent_framework.foundry import select_toolbox_tools
toolbox = await client.get_toolbox("research_tools")
selected = select_toolbox_tools(
    toolbox,
    include_names=["githubmcp", "code_interpreter"],
)
```

## 範圍外
- CRUD 操作（建立、更新、刪除）
- 伺服器端代理使用 toolbox 撰寫
- OAuth 同意流程執行期處理
