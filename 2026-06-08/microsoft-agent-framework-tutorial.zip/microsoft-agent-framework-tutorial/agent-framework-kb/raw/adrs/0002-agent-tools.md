---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0002-agent-tools.md
fetched: 2026-04-17
status: Proposed
date: 2025-06-23
contact: dmytrostruk
---

# ADR 0002: Agent Tools Unified Abstraction

**Status:** Proposed (TBD)
**Date:** 2025-06-23

## Context

AI agents depend on diverse tools (function calling, file search, computer use). Each requires custom implementations. Need unified abstraction.

## Considered Options

1. `ChatOptions.RawRepresentationFactory` — leverage existing, but inconsistent with AITool
2. Provider-Specific `AITool` types — type safety but fragmentation
3. Generic `AITool` abstractions in M.E.AI.Abstractions — standardized but complex mapping
4. **Hybrid Approach (Recommended)** — combine all three

## Tool Support Matrix

- **Universal**: Function Calling (all providers)
- **Wide**: Code Interpreter (6 providers), Search/Retrieval (5-6 providers)
- **Platform-specific**: Computer Use (3), Text Editor (Anthropic only), Fabric (Azure only)

## Decision

TBD — ongoing discussion. Current framework uses `AIFunctionFactory.Create()` for function-calling tools.
