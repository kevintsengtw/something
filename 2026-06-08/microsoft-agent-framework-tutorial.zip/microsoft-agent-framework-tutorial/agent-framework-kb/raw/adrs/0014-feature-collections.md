---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0014-feature-collections.md
fetched: 2026-04-17
status: Accepted
date: 2025-01-21
contact: westey-m
---

# ADR 0014: Feature Collections

**Status:** Accepted
**Date:** 2025-01-21
**Contact:** westey-m

## Context

Need to pass arbitrary services/data to agents at runtime, unknown at compile time. Certain capabilities aren't universal — flexible container needed.

## Decision

Use `AdditionalProperties` as the feature container with extension methods:

```csharp
// Setting a feature
options.AdditionalProperties.WithFeature(new MyFeature());

// Retrieving
if (options.AdditionalProperties.TryGetFeature<MyFeature>(out var feature))
{
    // Use feature
}
```

### Scenario: Per-Run ChatMessageStore Override

```csharp
var response = await agent.RunAsync(
    userInput,
    thread,
    options: new AgentRunOptions()
    {
        Features = new AgentFeatureCollection()
            .WithFeature<ChatMessageStore>(messageStore)
    });
```

### Scenario: Structured Output Feature

```csharp
internal class StructuredOutputAgentFeature
{
    public Type? OutputType { get; set; }
    public JsonSerializerOptions? SerializerOptions { get; set; }
    public bool? UseJsonSchemaResponseFormat { get; set; }
}
```

## Extension Points

- AIAgent: GetNewThread, DeserializeThread, Run/RunStreaming
- ChatClient: GetResponse/GetStreamingResponse
