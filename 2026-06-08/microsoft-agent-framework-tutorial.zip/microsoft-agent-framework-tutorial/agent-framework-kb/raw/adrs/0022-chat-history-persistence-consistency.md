---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0022-chat-history-persistence-consistency.md
fetched: 2026-04-17
status: Accepted
date: 2026-03-23
contact: westey-m
---

# ADR 0022: Chat History Persistence Consistency

**Status:** Accepted
**Date:** 2026-03-23
**Contact:** westey-m

## Context

`ChatClientAgent` with tools uses `FunctionInvokingChatClient` (FIC) in iterative loops. Two inconsistencies:
1. **Timing:** Services persist after each call; ChatHistoryProvider only at run completion
2. **Trailing content:** Services never store terminated FunctionResultContent; ChatHistoryProvider stores all

## Decision

Retain per-run persistence as default; offer opt-in per-service-call persistence.

### Configuration Matrix

| UseProvidedChatClientAsIs | RequirePerServiceCallPersistence | Behavior |
|---|---|---|
| false (default) | false (default) | Per-run via ChatHistoryProvider |
| false | true | Per-service-call via PerServiceCallChatHistoryPersistingChatClient |
| true | false | Per-run; no middleware |
| true | true | User responsible; warning if decorator absent |

### Key Class

`PerServiceCallChatHistoryPersistingChatClient` — decorator that manages ConversationId updates after each service call.

## Consequences

- Default per-run is atomic and simple
- Per-service-call aligns with service behavior when opted in
- Intermediate progress preserved
- May increase write frequency on some storage backends
