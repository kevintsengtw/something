---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0009-support-long-running-operations.md
fetched: 2026-04-17
status: Accepted
date: 2025-10-15
contact: sergeymenshykh
---

# ADR 0009: Long-Running Operations Support

**Status:** Accepted
**Date:** 2025-10-15
**Contact:** sergeymenshykh
**Deciders:** markwallace, rbarreto, westey-m, stephentoub

## Context

Agent Framework only supported synchronous request-response patterns. Real-world AI scenarios need
native long-running operations: code generation, complex reasoning, large document processing.
Design must align with OpenAI Responses, Azure AI Foundry Agents, and A2A protocols.

## Decision

**Option 1.1** — New `IAsyncChatClient` interface for all long-running execution operations.

### API

```csharp
public interface IAsyncChatClient
{
    Task<AsyncRunResult> StartAsyncRunAsync(
        IList<ChatMessage> chatMessages,
        RunOptions? options = null,
        CancellationToken ct = default);

    Task<AsyncRunResult> GetAsyncRunStatusAsync(
        string runId, CancellationToken ct = default);

    Task<AsyncRunResult> GetAsyncRunResultAsync(
        string runId, CancellationToken ct = default);

    Task<AsyncRunResult> CancelAsyncRunAsync(
        string runId, CancellationToken ct = default);

    Task<AsyncRunResult> DeleteAsyncRunAsync(
        string runId, CancellationToken ct = default);
}

// Agent integration — via AgentRun property on AgentResponse
class AgentResponse
{
    public AgentRun? AgentRun { get; }  // non-null when ChatFinishReason.LongRunning
}

class AgentRun
{
    public string RunId { get; }
    public AgentRunStatus Status { get; }
    // Polling / cancellation helpers
}
```

### Usage Pattern

```csharp
// Start
AgentResponse response = await agent.RunAsync(messages, session);

if (response.AgentRun != null)
{
    // Poll until complete
    while (!response.AgentRun.IsCompleted)
    {
        await Task.Delay(TimeSpan.FromSeconds(2));
        response = await agent.GetRunResultAsync(response.AgentRun.RunId);
    }
}
Console.WriteLine(response.Text);
```

## Consequences

- Additive — existing `RunAsync` / `RunStreamingAsync` unchanged
- `IAsyncChatClient` is optional; providers implement it when they support long-running ops
- `ChatFinishReason.LongRunning` signals background execution to callers
