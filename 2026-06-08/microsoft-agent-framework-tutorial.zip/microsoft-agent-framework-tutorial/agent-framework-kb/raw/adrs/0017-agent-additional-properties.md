---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0017-agent-additional-properties.md
fetched: 2026-04-23
status: Accepted
date: 2026-02-24
contact: westey-m
---

# ADR 0017: AdditionalProperties for AIAgent and AgentSession

**Status:** Accepted
**Date:** 2026-02-24
**Contact:** westey-m
**Deciders:** sergeymenshykh, markwallace, rbarreto, dmytrostruk, westey-m, eavanvalkenburg, stephentoub, lokitoth, alliscode, taochenosu, moonbox3

## Context

`AIAgent` 基底類別和 `AgentSession` 缺乏附加任意 metadata 的機制（如通訊協定描述符、hosting 屬性、session 標籤或自訂屬性）。其他框架類型（`AgentRunOptions`、`AgentResponse`、`AgentResponseUpdate`）已使用 `Microsoft.Extensions.AI` 的 `AdditionalPropertiesDictionary` 暴露 `AdditionalProperties`，造成不一致。

## 決策結果

**Option D + Option 1**：使用外部容器/包裝物件存放 metadata，維持純 metadata 語義（執行期間不傳播）。

```csharp
public class AgentWithMetadata
{
    public required AIAgent Agent { get; init; }
    public AdditionalPropertiesDictionary? AdditionalProperties { get; set; }
}
```

## 優點
- 不修改核心框架類別
- Metadata 明確為外部的，消除傳播歧義
- 不需要 metadata 時不分配記憶體
- 使用者維持完整生命週期控制

## 缺點
- 需要在代理/session 實例旁管理包裝器
- 可能因多種包裝器慣例而造成生態系碎片化
- 降低 API 可探索性

## AgentSession 序列化備注

`AgentSession` 序列化使用預設 JSON 往返（複雜物件成為 `JsonElement`）。自訂 `JsonSerializerOptions` 搭配型別解析器可在需要時實現強型別反序列化。
