---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0024-codeact-integration.md
fetched: 2026-04-17
status: Proposed
date: 2026-04-07
contact: eavanvalkenburg
---

# ADR 0024: CodeAct Integration via Context Providers

**Status:** Proposed
**Date:** 2026-04-07
**Contact:** eavanvalkenburg

## Context

CodeAct is a pattern where the model writes executable code (instead of flat function-call JSON) to
orchestrate tools inside a single sandbox invocation — reducing latency and token cost for multi-step logic.
Initial backend: Hyperlight sandbox.

## Decision

**Option 1** — Standardize on context provider-based CodeAct with backend-specific public types.

- Python uses `ContextProvider`; .NET uses `AIContextProvider`
- CodeAct ships as an **optional package** (not in core)
- No public abstract `CodeActContextProvider` base class — use concrete backend types directly
- Initial public type: `HyperlightCodeActProvider`

### .NET Usage

```csharp
// Register CodeAct context provider on the agent
var codeActProvider = new HyperlightCodeActProvider(options =>
{
    options.AllowedTools = [searchTool, calculatorTool];
    options.WorkspaceRoot = "/tmp/sandbox";
});

ChatClientAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    AIContextProviders = [codeActProvider],
    Tools = [otherDirectTool],  // direct tools remain separate
});

// The provider contributes an `execute_code` tool to the model
// Model generates code, framework runs it in Hyperlight sandbox
```

### Approval Model

Bundled approval for `execute_code` invocation (initial model):
- `approval_mode = "always_require"` → entire `execute_code` requires approval
- `approval_mode = "never_require"` → derives from provider-owned tool registry (if any tool requires approval, `execute_code` does too)

### Core Hooks (.NET)

CodeAct optional package depends on:
- Existing `AIContextProvider` seam (pre-invocation instruction/tool shaping)
- Agent runtime support for applying providers before model invocation
- Existing function-invocation seam for `execute_code` dispatch

## Consequences

- Each `execute_code` invocation starts from clean state (no cross-call in-memory variable persistence)
- Provider-owned tool registry is snapshotted per run (thread-safe for concurrent runs)
- `execute_code` traced as normal tool invocation in OTel
- CodeAct and direct tools are separate surfaces (configure in both places if needed in both)
