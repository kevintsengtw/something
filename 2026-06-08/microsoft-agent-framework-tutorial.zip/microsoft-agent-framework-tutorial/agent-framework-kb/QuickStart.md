# QuickStart — 快速操作指南

> 詳細說明請見 [`./README.md`](./README.md) 與工作區根 [`../CLAUDE.md`](../CLAUDE.md)
> 完整設計：[`./WORKFLOW-DESIGN-v2.md`](./WORKFLOW-DESIGN-v2.md)
> 目標環境：**macOS 唯一**

---

## 一、首次安裝（macOS）

### 1. 安裝 codebase-memory-mcp

```bash
npm install -g codebase-memory-mcp
which codebase-memory-mcp   # 確認 PATH 上找得到
```

### 2. 安裝 Understand-Anything（Claude Code Plugin）

```
/plugin marketplace add Lum1104/Understand-Anything
/plugin install understand-anything
```

### 3. 啟用工作區根 MCP 設定

工作區根已有 `.mcp.json` 設定 codebase-memory-mcp。**重啟 Claude Code / Cowork** 讓它載入新設定。

### 4. 首次驗證（重要！）

執行 [`raw/facts/codebase-memory-mcp-validation.md`](./raw/facts/codebase-memory-mcp-validation.md) 中的 7 項探測查詢，確認 macOS 上 C# 解析準度達標。

≥ 6/7 通過才能進入下一步。

### 5. 首次索引

```
mcp__codebase-memory-mcp__index_repository
  repo_path: "<工作區絕對路徑>/agent-framework"

mcp__codebase-memory-mcp__list_projects   # 確認 project 名稱
```

完成後 file watcher 會自動同步增量變更，`git pull` 後**無需手動重索引**。

---

## 二、啟動

```bash
cd <工作區根>/agent-framework-tutorial
claude   # 或開啟 Cowork
```

所有 slash commands 都在 `.claude/commands/` 內，從工作區根啟動就能直接用。

---

## 三、上游發佈新版本時（Pipeline A）

依序執行（每步完成後再執行下一步）：

```
/sync-upstream                ← 抓 raw/ 素材 + file watcher 自動同步索引
/extract-facts <version>      ← 抽事實清單，逐筆 codebase-memory-mcp 驗證
/compile                      ← 編譯 wiki/concepts/，frontmatter 引用事實 JSON
/snapshot-knowledge           ← 對 wiki/ 跑 /understand-knowledge 視覺化
/drift-check                  ← 比對 wiki vs tutorial
/update-tutorial breaking     ← 自動修正 🔴 Breaking
/drift-check                  ← 驗證 🔴 = 0
/lint                         ← wiki + tutorial 雙側一致性
```

若還有 🟡 Outdated 項目：

```
/update-tutorial outdated
/drift-check
```

完整版見 [`./PLAYBOOK-version-update.md`](./PLAYBOOK-version-update.md)。

---

## 四、教學文件建立（Pipeline D）

新章節：

```
/draft-chapter <wiki-concept> [chapter-no]
# 產出 outputs/draft-<concept>.md
# 人工 review 後移動到 microsoft-agent-framework-tutorial/<NN>-<slug>.md
/regenerate-toc                ← 重建 README 章節索引
/lint                          ← 驗證
```

新附錄：

```
/draft-appendix <topic> [letter]
# 流程同上
```

---

## 五、常用查詢與探索

```
/wiki-query <關鍵字>

範例：
/wiki-query AgentSession 怎麼建立
/wiki-query v1.6.1 breaking change
/wiki-query MapAGUIAgent 的命名空間
```

進階探索（UA 原生指令）：

```
/understand-chat <自然語言問題>   ← 對 wiki 的語意對話
/understand-explain <檔案>        ← 深入解析特定 wiki 或教學檔
/understand-diff                  ← 看大改寫的影響範圍
/understand-onboard               ← 新人導覽
```

---

## 六、定期品質檢查

```
/drift-check
/lint
```

---

## 七、codebase-memory-mcp 手動查驗

> 已整合進各 slash command 的執行流程，一般情況下自動觸發。以下指令用於需要單獨手動查驗的場景。

確認 API 是否存在於上游原始碼：

```
mcp__codebase-memory-mcp__search_graph
  project: "agent-framework"
  name_pattern: "MapAGUIAgent"
```

用 Cypher 查命名空間：

```
mcp__codebase-memory-mcp__query_graph
  project: "agent-framework"
  query: "MATCH (n:Class {name: 'AgentSessionFiles'}) RETURN n.namespace"
```

確認廢棄 API 在上游已無呼叫者（結果應為空）：

```
mcp__codebase-memory-mcp__trace_path
  project: "agent-framework"
  function_name: "GetToolboxAsync"
  direction: "inbound"
  depth: 1
```

取上游使用範例：

```
mcp__codebase-memory-mcp__search_code
  project: "agent-framework"
  pattern: "AIFunctionFactory.Create"
```

---

## 八、偏移等級

| 等級 | 意義 | 處理方式 |
|------|------|---------|
| 🔴 Breaking | 程式碼會編譯失敗 | 立即修正（`/update-tutorial breaking`） |
| 🟡 Outdated | 內容過時但可運作 | 建議修正（`/update-tutorial outdated`） |
| 🟢 Enhancement | 可選新功能補充 | 人工決定是否新增章節 |

---

## 九、注意事項

- `microsoft-agent-framework-tutorial/` 與 `agent-framework/` 兩個兄弟目錄必須存在
- codebase-memory-mcp 首次使用需執行 `index_repository`
- 🟢 Enhancement 項目不自動處理
- 整章大改寫會標記 `⚠️ 需人工確認`，不會自動執行
- `/draft-chapter` 與 `/draft-appendix` 產出永遠進 `outputs/`，**不直接寫入教學目錄**
- Windows 環境不再支援（見 [`./WORKFLOW-DESIGN-v2.md`](./WORKFLOW-DESIGN-v2.md) §0 決策歷程）
