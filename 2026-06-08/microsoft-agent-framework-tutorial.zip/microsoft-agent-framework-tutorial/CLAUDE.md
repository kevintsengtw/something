# Microsoft Agent Framework 繁中教學專案 — Claude 主導指引

> 本檔為**工作區根**的 master orchestration 文件，是 Claude 在本工作區做任何工作的首要指引。
> 設計依據：[`agent-framework-kb/WORKFLOW-DESIGN-v2.md`](./agent-framework-kb/WORKFLOW-DESIGN-v2.md)
> 目標環境：**macOS 唯一**（Windows 已退場）

---

## 1. 工作區角色

這是一個**繁體中文版 Microsoft Agent Framework 教學專案**，三子目錄並列：

| 子目錄 | 角色 | Claude 可否寫入 |
|--------|------|---------------|
| `agent-framework/` | 上游原始碼（Microsoft 官方 SDK 的 git clone） | ❌ 唯讀，僅供 codebase-memory-mcp 索引 |
| `agent-framework-kb/` | LLM Wiki 知識庫（Karpathy pattern）+ raw/ 上游素材鏡像 | ✅ 由 slash commands 自動維護 |
| `microsoft-agent-framework-tutorial/` | 繁中教學文件本體（29 章 + 5 附錄） | ✅ 透過 `/draft-*` 與 `/update-tutorial` 修改 |

**端點目標**：建立、維護、擴充 `microsoft-agent-framework-tutorial/` 的內容。

---

## 2. 工具二分原則（嚴格遵守）

| 層別 | 工具 | 職責 | 性質 |
|------|------|------|------|
| **事實層** | **codebase-memory-mcp** | 原始碼結構性事實的 ground truth | Deterministic（tree-sitter parser） |
| **敘述層** | **Understand-Anything + LLM** | 概念敘述、關係抽取、視覺化、Onboarding、教學撰寫 | LLM-based（語意理解） |

**核心約束**：
1. 事實層與敘述層**不交叉**。LLM 不負責判斷 API 是否存在；codebase-memory-mcp 不負責生成敘述。
2. 任何結構性宣告（API 名稱、簽名、namespace、繼承關係）**必須先經 codebase-memory-mcp 驗證**，再交給 LLM 寫敘述。
3. 若 codebase-memory-mcp 對 C# 的解析在 macOS 上不可用（首次驗證見 §6），整個架構失效，本指引作廢。

---

## 3. 指令入口點

**所有自訂 slash commands 統一住在 `agent-framework-tutorial/.claude/commands/`**（工作區根，本檔同層）。

12 個指令分四條 pipeline：

| Pipeline | 指令 | 用途 |
|---------|------|------|
| A 版本更新 | `/sync-upstream` | 抓 raw/ 素材 + 確認 codebase-memory-mcp 索引同步 |
| A | `/extract-facts <version>` | 從 release-notes 抽事實清單，逐筆 codebase-memory-mcp 驗證 |
| A | `/compile` | 編譯 wiki/concepts/，frontmatter 引用事實清單 |
| A | `/snapshot-knowledge` | 對 wiki/ 跑 `/understand-knowledge --language zh-TW` |
| A | `/drift-check` | 偵測 wiki vs tutorial 偏移，輸出 🔴/🟡/🟢 報告 |
| A | `/update-tutorial [breaking\|outdated\|all]` | 自動修正偏移（替換前 codebase-memory-mcp 驗證） |
| A | `/lint` | wiki + tutorial 雙側一致性檢查 |
| B 探索 | `/wiki-query <關鍵字>` | 在 wiki/ 與 brainstorming/ 查詢 |
| B | `/save-qa` | 把對話中的問答存入 brainstorming/qa-sessions/ |
| D 教學建立 | `/draft-chapter <wiki-concept> [chapter-no]` | 從 wiki 概念草擬新教學章節 |
| D | `/draft-appendix <topic>` | 草擬新附錄 |
| D | `/regenerate-toc` | 重建 README.md 章節索引 |

Pipeline C（Onboarding）直接用 UA plugin 原生指令 `/understand-onboard`，不需自訂。

---

## 4. 標準版本更新流程

Microsoft Agent Framework 發布新版本時，依序執行：

```
/sync-upstream
    ↓
/extract-facts <new-version>      ← codebase-memory-mcp 主導，建立事實 JSON
    ↓
/compile                          ← LLM 編譯敘述，受事實清單約束
    ↓
/snapshot-knowledge               ← UA 產生知識圖譜快照
    ↓
/drift-check                      ← 比對 wiki/ vs tutorial/
    ↓
/update-tutorial breaking         ← 自動修正 🔴
    ↓
/drift-check                      ← 驗證 🔴 = 0
    ↓
/lint                             ← wiki + tutorial 一致性
```

完整版見 [`agent-framework-kb/PLAYBOOK-version-update.md`](./agent-framework-kb/PLAYBOOK-version-update.md)。

---

## 5. 教學文件建立流程（Pipeline D）

新章節 / 附錄 / TOC 重建：

```
（前置：對應 wiki/concepts/ 條目已存在且通過 /lint）
    ↓
/draft-chapter <concept> [chapter-no]
    ↓
（草稿輸出到 outputs/draft-<concept>.md，不直接寫入 tutorial/）
    ↓
（人工 review + 移動至 microsoft-agent-framework-tutorial/<NN>-<slug>.md）
    ↓
/regenerate-toc                   ← 更新 README 章節索引
    ↓
/lint                             ← 驗證
```

**草稿不直接寫入教學目錄**——`/draft-chapter` 永遠輸出到 `outputs/`，由人工確認後手動移動。

---

## 6. codebase-memory-mcp macOS 驗證狀態

> ✅ **已通過 — 2026-05-26（6/7）**
> 環境：macOS 26.5、Node.js v24.15.0、codebase-memory-mcp v0.6.1、agent-framework commit `793403f3`
> 索引規模：44,650 nodes / 180,686 edges
> 詳細結果：[`agent-framework-kb/raw/facts/codebase-memory-mcp-validation.md`](./agent-framework-kb/raw/facts/codebase-memory-mcp-validation.md)

### 工具使用慣例（驗證發現的重點，所有 slash command 都受影響）

1. **外部依賴不索引**：`IChatClient`、`AIFunctionFactory`、`ChatOptions` 等 `Microsoft.Extensions.AI.*` 型別來自外部 NuGet，**不在 agent-framework 圖譜中**。要查詢它們應改用「找使用端」（`search_graph` 後看 in_degree > 0）。
2. **qualified_name 含路徑前綴**：圖譜 qualified_name 格式為 `<repo-path>.dotnet.src.Microsoft.Agents.AI.<...>.<name>`，不是純 C# namespace。呼叫 `get_code_snippet` 必須**先用 `search_graph` 找到正確 qualified_name**。
3. **`trace_path` 短名稱限制**：短名稱對應多個節點時 `trace_path` 回傳空集。優先用 `search_graph` 的 in_degree 欄位，或傳入完整 qualified_name。

### 重跑驗證時機

切換新機器、codebase-memory-mcp 主要版本升級、上游切換 commit 跨越 minor 版本。

完整 7 項探測規格（含修訂建議）見驗證檔 §7。

---

## 7. 子目錄 CLAUDE.md 補充

| 路徑 | 內容 | 與本檔關係 |
|------|------|----------|
| `agent-framework-kb/CLAUDE.md` | kb 維護細節（條目格式、編譯規則） | 補充本檔，不主導 |
| `microsoft-agent-framework-tutorial/CLAUDE.md` | （可選）教學風格指引 | 補充本檔，目前未必需要 |
| `agent-framework/CLAUDE.md` | 不存在（殘留已清除） | — |

---

## 8. 重要禁止事項

- ❌ 不要在 `agent-framework/` 寫入任何檔案——它是上游唯讀基準層
- ❌ 不要假設 GitNexus 可用——本專案已決定不導入 GitNexus
- ❌ 不要把草稿章節直接寫進 `microsoft-agent-framework-tutorial/`，永遠先進 `outputs/`
- ❌ 不要假設 codebase-memory-mcp 在 Windows 與 macOS 行為一致——首次在 macOS 使用需跑 §6 驗證
- ❌ 不要在 `agent-framework-kb/` 內加入 `.claude/` 子目錄——舊入口點已退役

---

## 9. JSON / 索引 commit 策略

| 產物 | commit? | 路徑 |
|------|---------|------|
| codebase-memory-mcp 索引 | ❌ gitignore | 通常存於 `~/.codebase-memory-mcp/` 全域目錄，**不在工作區內** |
| UA 知識圖譜 JSON | ✅ commit | `agent-framework-kb/.understand-anything/knowledge-graph.json` |
| UA 中間檔 | ❌ gitignore | `agent-framework-kb/.understand-anything/intermediate/` |
| UA diff overlay | ❌ gitignore | `agent-framework-kb/.understand-anything/diff-overlay.json` |
| 事實清單 JSON | ✅ commit | `agent-framework-kb/raw/facts/*.json` |

詳見工作區根 `.gitignore`。

---

## 10. 設計文件參考

- 本指引設計依據：[`agent-framework-kb/WORKFLOW-DESIGN-v2.md`](./agent-framework-kb/WORKFLOW-DESIGN-v2.md)
- 版本更新操作手冊：[`agent-framework-kb/PLAYBOOK-version-update.md`](./agent-framework-kb/PLAYBOOK-version-update.md)
- 跨平台策略：已退役（macOS 唯一）
- 工具決策記錄：本專案曾評估 GitNexus + UA 方案，最終決定保留 codebase-memory-mcp（理由：已實戰驗證、使用成本低、ground truth 性質相同）
