# 06 — Middleware 與 Context 基礎

> 本章介紹 Agent Framework 的兩個重要機制：Middleware（中介軟體）讓你攔截與處理代理的行為，Context Providers（上下文提供者）讓你動態注入額外資訊到代理對話中。
>
> 對應官方範例：[Agent-Framework-Samples/00.ForBeginners/DesignPatterns](https://github.com/microsoft/Agent-Framework-Samples/tree/main/00.ForBeginners)

---

## Middleware — 攔截代理行為

如果你有 ASP.NET Core 的開發經驗，Middleware 的概念對你來說一定不陌生。在 ASP.NET Core 中，Middleware 用來處理 HTTP 請求管線；在 Agent Framework 中，Middleware 用來處理**代理的執行管線**。

### 為什麼需要 Middleware

在實際應用中，你經常需要在代理執行的前後加入額外邏輯：

- **日誌記錄**：記錄每次代理被呼叫的輸入與輸出
- **效能監控**：計算代理回應的耗時
- **安全檢查**：在執行工具前驗證使用者權限
- **內容過濾**：在 LLM 回應後過濾敏感內容
- **錯誤處理**：統一捕獲與處理例外

Middleware 讓你在**不修改代理核心邏輯**的情況下，優雅地加入這些橫切關注點（Cross-cutting Concerns）。

---

## 三層 Middleware 架構

Agent Framework 提供三種不同層級的 Middleware，各自作用於代理執行的不同階段：

```mermaid
flowchart TD
    Input["使用者輸入"] --> AM

    subgraph AM["① Agent Middleware — 攔截代理執行"]
        direction TB
        AM_Pre["前置處理：日誌、計時、認證"] --> FM_Layer

        subgraph FM_Layer["② Function Middleware — 攔截工具呼叫"]
            direction TB
            FM_Pre["前置處理：權限檢查、參數驗證"] --> CM_Layer

            subgraph CM_Layer["③ Chat Middleware — 攔截 LLM 請求"]
                direction TB
                LLM["LLM 呼叫"]
            end

            CM_Layer --> FM_Post["後置處理：結果記錄"]
        end

        FM_Layer --> AM_Post["後置處理：計時結束、回應記錄"]
    end

    AM --> Output["代理回應"]

    style AM fill:#E8F0FE,stroke:#4A90D9,color:#333
    style FM_Layer fill:#D4EDDA,stroke:#28A745,color:#333
    style CM_Layer fill:#FFF3CD,stroke:#FFC107,color:#333
```

| 層級 | Middleware 類型 | 攔截對象 | 典型用途 |
|------|----------------|----------|----------|
| 最外層 | **Agent Middleware** | 整個 `RunAsync` 執行 | 日誌、計時、例外處理、認證 |
| 中間層 | **Function Middleware** | 個別工具/函式的呼叫 | 權限檢查、參數驗證、呼叫審計 |
| 最內層 | **Chat Middleware** | 發送至 LLM 的請求 | Token 計量、回應快取、內容過濾 |

---

## Agent Middleware

Agent Middleware 是最外層的攔截器，作用於整個代理的 `RunAsync` 執行週期。

### 實作 IAgentMiddleware

```csharp
using Microsoft.Agents.AI;

public class LoggingMiddleware : IAgentMiddleware
{
    public async Task InvokeAsync(
        AgentMiddlewareContext context,
        AgentMiddlewareDelegate next)
    {
        // ============================
        // 前置處理（代理執行之前）
        // ============================
        Console.WriteLine($"[LOG] 代理開始執行");
        Console.WriteLine($"[LOG] 輸入：{string.Join(", ", context.Input)}");
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();

        // 呼叫下一個 Middleware（或代理本身）
        await next(context);

        // ============================
        // 後置處理（代理執行之後）
        // ============================
        stopwatch.Stop();
        Console.WriteLine($"[LOG] 代理執行完成，耗時 {stopwatch.ElapsedMilliseconds}ms");
    }
}
```

### 關鍵元素

- **`AgentMiddlewareContext`**：包含代理實例、輸入訊息、AgentSession 等執行資訊
- **`AgentMiddlewareDelegate next`**：呼叫管線中的下一個 Middleware。**一定要呼叫 `await next(context)`**，否則代理不會執行
- 前置處理在 `next()` 之前，後置處理在 `next()` 之後

### 錯誤處理 Middleware

```csharp
public class ErrorHandlingMiddleware : IAgentMiddleware
{
    public async Task InvokeAsync(
        AgentMiddlewareContext context,
        AgentMiddlewareDelegate next)
    {
        try
        {
            await next(context);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[ERROR] 代理執行發生錯誤：{ex.Message}");
            // 可以在這裡進行錯誤回報、重試邏輯等
            throw; // 或吞掉例外並提供預設回應
        }
    }
}
```

### 註冊 Agent Middleware

```csharp
var agent = chatClient
    .AsAIAgent(
        name: "MyAgent",
        instructions: "你是一個友善的助理。"
    );

// 透過 Use 方法串接 Middleware
agent.Use(new LoggingMiddleware());
agent.Use(new ErrorHandlingMiddleware());
```

---

## Chat Middleware

Chat Middleware 作用於 LLM 請求層級，攔截每一次發送給 LLM 的請求與回應。

### 使用 IChatClient Builder 模式

Chat Middleware 是透過 `IChatClient` 的 Builder 模式來設定的：

```csharp
using Microsoft.Extensions.AI;

// 在 ChatClient 層級加入 Middleware
var middlewareEnabledClient = chatClient
    .AsBuilder()
    .Use(async (messages, options, next, cancellationToken) =>
    {
        // ============================
        // 前置處理（LLM 請求之前）
        // ============================
        Console.WriteLine($"[CHAT] 發送 {messages.Count} 則訊息給 LLM");

        // 呼叫底層的 ChatClient
        var response = await next(messages, options, cancellationToken);

        // ============================
        // 後置處理（LLM 回應之後）
        // ============================
        Console.WriteLine($"[CHAT] 收到 LLM 回應");

        return response;
    })
    .Build();

// 使用包裝過的 ChatClient 建立代理
var agent = middlewareEnabledClient.AsAIAgent(
    name: "MyAgent",
    instructions: "你是一個友善的助理。"
);
```

### Prompt Rewriting Middleware

Chat Middleware 可以直接修改發送給 LLM 的訊息清單，實現動態的 Prompt 注入或改寫。`messages` 參數是 `IList<ChatMessage>`，可在 `next()` 之前進行 in-place 修改：

```csharp
var safetyClient = chatClient
    .AsBuilder()
    .Use(async (messages, options, next, cancellationToken) =>
    {
        // 在系統訊息中動態注入安全政策（若尚未包含）
        var hasPolicy = messages.Any(m =>
            m.Role == ChatRole.System &&
            (m.Text?.Contains("安全政策") ?? false));

        if (!hasPolicy)
        {
            // 直接修改 IList<ChatMessage>，將政策插入最前面
            messages.Insert(0, new ChatMessage(
                ChatRole.System,
                "安全政策：不得回答涉及個人隱私或法律風險的問題。"));
        }

        return await next(messages, options, cancellationToken);
    })
    .Build();
```

> **注意**：`messages` 是傳入的原始清單的參考。修改後會影響後續 Middleware 看到的訊息，但不會影響代理呼叫端的原始 `session` 歷史（歷史由 `AgentSession` 管理）。

### Token 計量 Middleware

一個實用的範例 — 追蹤 Token 使用量：

```csharp
var totalTokens = 0;

var trackedClient = chatClient
    .AsBuilder()
    .Use(async (messages, options, next, cancellationToken) =>
    {
        var response = await next(messages, options, cancellationToken);

        // 從回應中取得 Token 使用資訊
        if (response.Usage is { } usage)
        {
            totalTokens += usage.TotalTokenCount ?? 0;
            Console.WriteLine(
                $"[TOKEN] 本次：輸入 {usage.InputTokenCount}，" +
                $"輸出 {usage.OutputTokenCount}，" +
                $"累計 {totalTokens}");
        }

        return response;
    })
    .Build();
```

---

## Function Middleware

Function Middleware 攔截個別工具的呼叫，適合在工具執行前後加入邏輯。

### 使用 FunctionInvocationMiddleware

```csharp
var trackedClient = chatClient
    .AsBuilder()
    .Use(async (functionCall, next, cancellationToken) =>
    {
        // ============================
        // 前置處理（工具呼叫之前）
        // ============================
        Console.WriteLine($"[FUNC] 呼叫工具：{functionCall.Function.Name}");
        Console.WriteLine($"[FUNC] 參數：{functionCall.Arguments}");

        // 執行工具
        var result = await next(functionCall, cancellationToken);

        // ============================
        // 後置處理（工具呼叫之後）
        // ============================
        Console.WriteLine($"[FUNC] 工具回傳：{result}");

        return result;
    })
    .Build();
```

### 工具呼叫審計 Middleware

記錄所有工具呼叫以供後續審計：

```csharp
var auditLog = new List<(DateTime Time, string Tool, string Args, string Result)>();

var auditedClient = chatClient
    .AsBuilder()
    .Use(async (functionCall, next, cancellationToken) =>
    {
        var startTime = DateTime.UtcNow;
        var result = await next(functionCall, cancellationToken);

        auditLog.Add((
            startTime,
            functionCall.Function.Name,
            functionCall.Arguments?.ToString() ?? "",
            result?.ToString() ?? ""
        ));

        return result;
    })
    .Build();
```

---

## Middleware 管線的執行順序

當你同時設定多個 Middleware 時，它們會形成一個**洋蔥模型**（Onion Model）：

```mermaid
sequenceDiagram
    participant User as 使用者
    participant MW1 as Middleware A（先註冊）
    participant MW2 as Middleware B（後註冊）
    participant Agent as 代理核心

    User->>MW1: 輸入
    Note over MW1: A 前置處理
    MW1->>MW2: next()
    Note over MW2: B 前置處理
    MW2->>Agent: next()
    Note over Agent: 執行代理邏輯
    Agent-->>MW2: 回應
    Note over MW2: B 後置處理
    MW2-->>MW1: 回傳
    Note over MW1: A 後置處理
    MW1-->>User: 最終回應
```

先註冊的 Middleware 在最外層，後註冊的在最內層。前置處理按註冊順序執行，後置處理按反向順序執行。

---

## Context Providers — 動態注入上下文

Context Providers 是另一個重要機制，讓你在**每次代理執行前自動注入額外的背景資訊**。

### 與 Tools 和 Middleware 的區別

```mermaid
flowchart LR
    subgraph Tools["Tools（工具）"]
        T["LLM 主動呼叫\n代理去「做事」"]
    end

    subgraph MW["Middleware（中介軟體）"]
        M["攔截執行管線\n加入橫切邏輯"]
    end

    subgraph CP["Context Providers"]
        C["自動注入資訊\n代理「知道更多」"]
    end

    style Tools fill:#D4EDDA,stroke:#28A745,color:#333
    style MW fill:#E8F0FE,stroke:#4A90D9,color:#333
    style CP fill:#FFF3CD,stroke:#FFC107,color:#333
```

| 特性 | Tools | Middleware | Context Providers |
|------|-------|-----------|-------------------|
| 觸發方式 | LLM 自行判斷 | 每次執行自動觸發 | 每次執行自動觸發 |
| 目的 | 讓代理執行動作 | 攔截與處理行為 | 注入額外資訊 |
| 範例 | 查天氣、搜資料 | 日誌、認證 | 使用者資訊、系統狀態 |

### 實作 AIContextProvider

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

public class UserInfoProvider : AIContextProvider
{
    private readonly string _userName;
    private readonly string _department;
    private readonly string _preferredLanguage;

    public UserInfoProvider(string userName, string department, string preferredLanguage)
    {
        _userName = userName;
        _department = department;
        _preferredLanguage = preferredLanguage;
    }

    /// <summary>
    /// 在 LLM 呼叫前被呼叫，注入使用者資訊到 System 指令
    /// </summary>
    protected override ValueTask<AIContext> ProvideAIContextAsync(
        InvokingContext context,
        CancellationToken cancellationToken = default)
    {
        var instructions = $"""
            使用者資訊：
            - 姓名：{_userName}
            - 部門：{_department}
            - 偏好語言：{_preferredLanguage}
            請根據以上資訊個人化你的回應。
            """;

        return ValueTask.FromResult(new AIContext { Instructions = instructions });
    }

    /// <summary>
    /// LLM 回應後被呼叫，可用於分析對話並更新狀態
    /// </summary>
    protected override ValueTask StoreAIContextAsync(
        InvokedContext context,
        CancellationToken cancellationToken = default)
    {
        // 可以在這裡分析對話內容，擷取新的資訊
        // 例如：使用者在對話中提到了新的偏好
        return ValueTask.CompletedTask;
    }
}
```

### AIContextProvider 的生命週期

```mermaid
sequenceDiagram
    participant User as 使用者
    participant Agent as AIAgent
    participant CP as Context Provider
    participant LLM as LLM

    User->>Agent: 發送訊息
    Agent->>CP: ProvideAIContextAsync()
    CP-->>Agent: 回傳 AIContext（Instructions 字串）
    Note over Agent: 合併原始訊息 + 額外上下文
    Agent->>LLM: 發送合併後的訊息
    LLM-->>Agent: 回傳回應
    Agent->>CP: StoreAIContextAsync()
    Note over CP: 可更新內部狀態
    Agent-->>User: 回傳回應
```

兩個階段：

- **`ProvideAIContextAsync`**（執行前）：注入額外的上下文資訊，回傳 `AIContext.Instructions` 字串，會被合併到傳給 LLM 的 System 指令中
- **`StoreAIContextAsync`**（執行後）：分析對話結果，可用於更新 Provider 的內部狀態（透過 `ProviderSessionState<T>`）

### 註冊 Context Provider

```csharp
var userInfoProvider = new UserInfoProvider(
    userName: "王小明",
    department: "工程部",
    preferredLanguage: "繁體中文"
);

var agentOptions = new ChatClientAgentOptions
{
    AIContextProviders = [userInfoProvider]
};

var agent = new ChatClientAgent(
    chatClient,
    name: "PersonalAssistant",
    instructions: "你是一個企業內部的個人助理。",
    options: agentOptions
);
```

---

## 實用範例：時間感知的 Context Provider

讓代理自動知道目前的時間，不需要使用者主動問：

```csharp
public class TimeContextProvider : AIContextProvider
{
    protected override ValueTask<AIContext> ProvideAIContextAsync(
        InvokingContext context,
        CancellationToken cancellationToken = default)
    {
        var now = DateTime.Now;
        var instructions = $"""
            目前時間資訊：
            - 日期：{now:yyyy年MM月dd日}（{now:dddd}）
            - 時間：{now:HH:mm}
            - 時區：台灣時間（UTC+8）
            你可以根據時間做適當的問候（例如早安、午安、晚安）。
            """;

        return ValueTask.FromResult(new AIContext { Instructions = instructions });
    }
}
```

---

## 完整範例：整合 Middleware 與 Context Provider

以下範例同時使用 Middleware 和 Context Provider，展示一個具有日誌記錄、Token 追蹤和使用者感知功能的代理：

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using OpenAI;
using System.ComponentModel;

var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY")
    ?? throw new InvalidOperationException("請設定 OPENAI_API_KEY 環境變數");

// ============================================================
// 1. 建立帶有 Chat Middleware 的 ChatClient
// ============================================================

var totalTokens = 0;
var requestCount = 0;

var trackedClient = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o-mini")
    .AsBuilder()
    // Chat Middleware：Token 追蹤
    .Use(async (messages, options, next, cancellationToken) =>
    {
        requestCount++;
        Console.WriteLine($"  [CHAT #{requestCount}] 發送 {messages.Count} 則訊息給 LLM");

        var response = await next(messages, options, cancellationToken);

        if (response.Usage is { } usage)
        {
            totalTokens += usage.TotalTokenCount ?? 0;
            Console.WriteLine($"  [CHAT #{requestCount}] Token：{usage.TotalTokenCount}（累計 {totalTokens}）");
        }

        return response;
    })
    // Function Middleware：工具呼叫追蹤
    .Use(async (functionCall, next, cancellationToken) =>
    {
        Console.WriteLine($"  [FUNC] 呼叫 {functionCall.Function.Name}");
        var result = await next(functionCall, cancellationToken);
        Console.WriteLine($"  [FUNC] 結果：{result}");
        return result;
    })
    .Build();

// ============================================================
// 2. 定義工具
// ============================================================

[Description("搜尋公司內部知識庫")]
static string SearchKnowledgeBase(
    [Description("搜尋關鍵字")] string query)
    => $"找到 3 篇相關文件：1) {query} 操作手冊 2) {query} 常見問題 3) {query} 最佳實踐";

// ============================================================
// 3. 建立 Context Providers
// ============================================================

var userProvider = new UserInfoProvider("王小明", "工程部", "繁體中文");
var timeProvider = new TimeContextProvider();

// ============================================================
// 4. 建立代理（整合所有元件）
// ============================================================

var agentOptions = new ChatClientAgentOptions
{
    AIContextProviders = [userProvider, timeProvider]
};

var agent = new ChatClientAgent(
    trackedClient,
    name: "EnterpriseAssistant",
    instructions: """
        你是一個企業內部助理。
        善用你知道的使用者資訊來個人化回應。
        善用工具來搜尋公司知識庫。
        """,
    tools: [AIFunctionFactory.Create(SearchKnowledgeBase)],
    options: agentOptions
);

// Agent Middleware：整體執行追蹤
agent.Use(new LoggingMiddleware());

// ============================================================
// 5. 對話
// ============================================================

var session = await agent.CreateSessionAsync();

Console.WriteLine("=== 企業助理（含 Middleware + Context） ===\n");

var questions = new[]
{
    "你好！",
    "幫我查一下我們的請假規定",
};

foreach (var question in questions)
{
    Console.WriteLine($"你：{question}");
    var response = await agent.RunAsync(question, session);
    Console.WriteLine($"助理：{response.Text}\n");
}

Console.WriteLine($"\n=== 統計 ===");
Console.WriteLine($"LLM 請求次數：{requestCount}");
Console.WriteLine($"總 Token 使用量：{totalTokens}");
```

---

## 小結

本章你學會了：

- **Agent Middleware**：透過 `IAgentMiddleware` 攔截整個代理執行，適合日誌、計時、錯誤處理
- **Chat Middleware**：透過 `IChatClient` Builder 模式攔截 LLM 請求，適合 Token 計量、內容過濾
- **Function Middleware**：攔截個別工具呼叫，適合權限檢查、呼叫審計
- **Context Providers**：透過 `AIContextProvider` 在每次執行前自動注入上下文，適合使用者資訊、時間感知
- 三層 Middleware 的執行順序與洋蔥模型

到此為止，你已經掌握了 Agent Framework 的所有核心概念。接下來的章節將透過實際範例，把這些概念組合起來解決真實問題。

> ⚠️ **即將推出（ADR 0015 Proposed）**：`AIAgent.CurrentRunContext` 是計畫中的靜態屬性，讓深層巢狀的 Middleware 或工具函式無需層層傳參，即可存取目前的代理執行上下文（Session、RunOptions、Messages）。目前狀態為提案中，詳見[附錄 D — Proposed ADRs](./appendix-d-proposed-adrs.md)。

---

## v1.6.1 新增：MessageInjectingChatClient — 函數迴圈訊息注入

> 🆕 **v1.6.1 新增**（`[Experimental]`）：`MessageInjectingChatClient` 讓工具委派（tool delegates）在代理的函數呼叫迴圈（function loop）期間動態排隊額外訊息，這些訊息會在下一輪迭代前送出給 LLM。

### 與 Context Provider 的差異

| 特性 | Context Provider（本章） | MessageInjectingChatClient |
|------|------------------------|---------------------------|
| 注入時機 | 整個代理執行開始前（一次） | 函數迴圈中任意時機（工具委派內） |
| 適合場景 | 靜態背景資訊（使用者資料、目前時間） | 動態追蹤（稽核、每次工具呼叫的約束刷新） |
| API | 繼承 `AIContextProvider` | 呼叫 `EnqueueMessages()` |

### 啟用與使用 MessageInjectingChatClient

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

// 啟用訊息注入（建立代理時開啟選項）
AIAgent agent = chatClient.AsAIAgent(
    name: "AuditAgent",
    instructions: "你是一個受稽核的助理。",
    tools: [myTool],
    options: new ChatClientAgentOptions { EnableMessageInjection = true });

// 在工具委派中取得注入器並排隊訊息
AIFunction auditedTool = AIFunctionFactory.Create(
    async ([Description("要執行的操作")] string action, AgentSession session) =>
    {
        // 從 ChatClient pipeline 取得 MessageInjectingChatClient
        var injector = agent.GetService<MessageInjectingChatClient>();

        // 注入稽核訊息，讓 LLM 在下次迭代時看到
        injector?.EnqueueMessages(session, [
            new ChatMessage(ChatRole.System,
                $"[稽核] 執行操作 '{action}' 於 {DateTime.UtcNow:u}")
        ]);

        return $"操作 '{action}' 已執行";
    },
    "ExecuteAction", "執行指定操作");

// 也可手動加入 pipeline（搭配自訂 ChatClient 時）
// chatClientBuilder.UseMessageInjection();
```

### 適用場景

| 場景 | 說明 |
|------|------|
| 稽核追蹤 | 工具執行後注入時間戳與操作識別 |
| 動態安全約束 | 根據執行狀態加入額外的限制指令 |
| 注意力刷新 | 長工具鏈中重新強調核心指令，防止 LLM 偏離目標 |

### 適用場景

| 場景 | 說明 |
|------|------|
| 稽核追蹤 | 每次工具呼叫前注入時間戳與操作識別 |
| 動態安全約束 | 根據執行狀態加入額外的限制指令 |
| 注意力刷新 | 長工具鏈中重新強調核心指令，防止 LLM 偏離目標 |

---

> **返回目錄**：[README](README.md) | **上一章**：[05 — 工具（Tools）基礎](./05-tools-basics.md) | **下一章**：[07 — 範例實作：Travel Agent](./07-example-travel-agent.md)
