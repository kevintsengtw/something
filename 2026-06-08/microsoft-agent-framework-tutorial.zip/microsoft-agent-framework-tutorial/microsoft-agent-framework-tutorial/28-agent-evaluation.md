# 28 — Agent Evaluation（代理評估）

> 本章介紹 Agent Framework 與 Azure AI Foundry 的評估整合。評估（Evaluation）是確保代理品質的關鍵環節——你需要系統化地測量代理的回應品質、工具使用正確性、以及對話一致性。
>
> 對應官方決策：[ADR 0023 — Foundry Evals Integration](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0023-foundry-evals-integration.md)（Accepted, 2026-02-27）

---

## 評估 vs 測試

在第 12 章我們介紹了**單元測試與整合測試**，它們驗證的是「程式碼是否正確運作」。評估解決的是不同問題：

| 面向 | 測試（Testing） | 評估（Evaluation） |
|------|----------------|-------------------|
| 問什麼 | 程式碼有 bug 嗎？ | 代理的回應品質好嗎？ |
| 判斷依據 | 確定性（Pass/Fail） | 分數制（0-5 或百分比） |
| 典型指標 | 方法是否回傳正確值 | 相關性、連貫性、流暢度、安全性 |
| 執行頻率 | 每次 CI/CD | 定期或模型切換時 |
| 資料來源 | Mock 資料 | 真實或接近真實的對話資料集 |

---

## 核心架構

```mermaid
flowchart TD
    Queries["查詢字串陣列\n(string[])"] --> AgentEval["agent.EvaluateAsync()\n代理自動執行對話"]
    AgentEval --> Evaluator["IAgentEvaluator\n評分"]
    Evaluator --> Report["AgentEvaluationResults\n評估報告"]

    subgraph evaluators["可用的 Evaluator"]
        Foundry["FoundryEvals\nAzure AI Foundry 評估"]
        Custom["自訂 IAgentEvaluator\n本地評估邏輯"]
    end

    Evaluator --- evaluators

    style AgentEval fill:#4A90D9,color:#fff
    style Evaluator fill:#D4EDDA,stroke:#28A745,color:#333
    style Report fill:#FFF3CD,stroke:#FFC107,color:#333
```

---

## IAgentEvaluator 介面

所有評估器都實作統一的 `IAgentEvaluator` 介面：

```csharp
public interface IAgentEvaluator
{
    /// <summary>
    /// 對一組 (查詢, 回應) 配對進行評分
    /// </summary>
    Task<EvaluationResults> EvaluateAsync(
        IEnumerable<(string query, string response)> samples,
        EvaluationContext? context = null);
}
```

### AgentEvaluationResults — 評估報告

```csharp
public class AgentEvaluationResults
{
    /// <summary>整體評估是否通過</summary>
    public bool Passed { get; }

    /// <summary>各指標的分數明細</summary>
    public IReadOnlyDictionary<string, double> MetricScores { get; }

    /// <summary>斷言所有指標均通過，否則拋出例外（方便在 CI/CD 中使用）</summary>
    public void AssertAllPassed();
}
```

---

## 快速入門：三行評估

ADR 強調的核心設計理念是「漸進式揭露」——最簡單的場景只需要三行程式碼：

```csharp
// 1. 建立 FoundryEvals 評估器（指定要評估的指標）
var evals = new FoundryEvals(
    chatConfiguration,
    FoundryEvals.Relevance,
    FoundryEvals.Coherence);

// 2. 執行評估（agent 自動執行對話並評分）
AgentEvaluationResults results = await agent.EvaluateAsync(
    ["Contoso Travel 的旅遊保險涵蓋哪些項目？"],
    evals);

// 3. 斷言通過（或查看明細）
results.AssertAllPassed();
```

---

## 評估器類型

### FoundryEvals — Azure AI Foundry 雲端評估

使用 Azure AI Foundry 的託管評估服務，結果可在 Azure AI Foundry 入口網站中查看：

```csharp
using Microsoft.Agents.AI;

// 建立 FoundryEvals，傳入聊天設定與要評估的指標
var evals = new FoundryEvals(
    chatConfiguration,           // Azure AI Foundry 的 ChatConfiguration
    FoundryEvals.Relevance,      // 相關性
    FoundryEvals.Coherence,      // 連貫性
    FoundryEvals.TaskAdherence,  // 任務遵從性
    FoundryEvals.ToolCallAccuracy); // 工具呼叫準確性

AgentEvaluationResults results = await agent.EvaluateAsync(
    new[]
    {
        "Contoso 的旅遊保險涵蓋哪些項目？",
        "有哪些熱門目的地？",
        "如何取消訂單？",
    },
    evals);

// 顯示各指標分數
foreach (var (metric, score) in results.MetricScores)
{
    Console.WriteLine($"  {metric}: {score:F2}");
}
// 輸出範例：
//   Relevance: 4.50
//   Coherence: 4.80
//   TaskAdherence: 4.60
//   ToolCallAccuracy: 5.00

// 斷言全部通過（用於 CI/CD 品質門檻）
results.AssertAllPassed();
```

### 自訂 IAgentEvaluator — 本地自訂評分邏輯

當你需要確定性評分（不依賴 LLM 或 Azure 服務）時，實作 `IAgentEvaluator`：

```csharp
// 自訂評估器：檢查回應長度是否合理
public class ResponseLengthEvaluator : IAgentEvaluator
{
    public Task<EvaluationResults> EvaluateAsync(
        IEnumerable<(string query, string response)> samples,
        EvaluationContext? context = null)
    {
        var results = new EvaluationResults();
        foreach (var (query, response) in samples)
        {
            // 回應在 50-500 字之間視為合理
            double score = response.Length is >= 50 and <= 500 ? 1.0 : 0.0;
            results.AddScore("ResponseLength", score);
        }
        return Task.FromResult(results);
    }
}

// 混合使用 Foundry + 自訂評估器
var customEvals = new IAgentEvaluator[] { new ResponseLengthEvaluator() };
AgentEvaluationResults results = await agent.EvaluateAsync(queries, customEvals);
```

---

## 對話分割策略

評估多輪對話時，你可以選擇不同的分割策略：

```mermaid
flowchart LR
    subgraph Full["Full Conversation"]
        F["整段對話作為一個評估項"]
    end

    subgraph PerTurn["Per Turn"]
        T1["第 1 輪"] --> T2["第 2 輪"] --> T3["第 3 輪"]
    end

    subgraph Final["Final Exchange"]
        FE["只評估最後一輪"]
    end

    style Full fill:#E8F0FE,stroke:#4A90D9,color:#333
    style PerTurn fill:#D4EDDA,stroke:#28A745,color:#333
    style Final fill:#FFF3CD,stroke:#FFC107,color:#333
```

| 策略 | 適用場景 | 說明 |
|------|---------|------|
| **Full Conversation** | 整體對話品質 | 將完整多輪對話視為一個評估項 |
| **Per Turn** | 逐輪品質追蹤 | 每一輪獨立評估，適合找出品質下降的轉折點 |
| **Final Exchange** | 最終結果品質 | 只評估最後一輪，適合任務導向的對話 |

---

## 端對端評估流程

`agent.EvaluateAsync()` 是進入點——它自動讓代理執行對話並將回應送入評估器：

```csharp
using Microsoft.Agents.AI;

// ============================================================
// 步驟 1：準備代理
// ============================================================

var agent = chatClient.AsAIAgent(
    name: "ContosoAssistant",
    instructions: "你是 Contoso Travel 的客服助理，僅根據提供的文件回答問題。"
);

// ============================================================
// 步驟 2：設定評估器與指標
// ============================================================

var evals = new FoundryEvals(
    chatConfiguration,
    FoundryEvals.Relevance,
    FoundryEvals.Coherence,
    FoundryEvals.TaskAdherence);

// ============================================================
// 步驟 3：執行評估（agent 自動執行對話 + 評分）
// ============================================================

string[] queries =
[
    "Contoso 的旅遊保險涵蓋哪些？",
    "有哪些熱門目的地？",
    "退費政策是什麼？",
];

AgentEvaluationResults results = await agent.EvaluateAsync(queries, evals);

// ============================================================
// 步驟 4：報告
// ============================================================

Console.WriteLine("=== 評估報告 ===");
foreach (var (metric, score) in results.MetricScores)
{
    Console.WriteLine($"  {metric}: {score:F2}");
}

// CI/CD 品質門檻：全部通過才繼續
results.AssertAllPassed();
Console.WriteLine("✅ 評估通過！");
```

---

## 與 CI/CD 整合

`results.AssertAllPassed()` 是最簡潔的品質門檻——評估未通過時拋出例外，自動讓 CI 管線失敗：

```csharp
// 在 CI/CD 腳本中執行
AgentEvaluationResults results = await agent.EvaluateAsync(queries, evals);

// 方式 A：直接斷言（未通過時拋出例外）
results.AssertAllPassed();

// 方式 B：手動檢查各指標
foreach (var (metric, score) in results.MetricScores)
{
    if (score < 3.5)
    {
        Console.Error.WriteLine($"❌ {metric} 分數 {score:F2} 低於門檻 3.5");
        Environment.Exit(1);
    }
}

Console.WriteLine("✅ 評估通過！");
```

---

## 小結

Agent Evaluation 讓你系統化地衡量代理品質：

1. **統一進入點**：`agent.EvaluateAsync(queries, evals)` — 代理自動執行對話並評分
2. **統一回傳型別**：`AgentEvaluationResults` 含指標分數與 `AssertAllPassed()` 斷言
3. **FoundryEvals**：`new FoundryEvals(chatConfiguration, FoundryEvals.Relevance, ...)` — Azure 雲端評估，結果可在 Foundry 入口查看
4. **自訂評估器**：實作 `IAgentEvaluator`，回傳 `EvaluationResults`
5. **CI/CD 整合**：`results.AssertAllPassed()` 自動讓管線失敗

### 延伸閱讀：官方 ADR 參考

- [ADR 0023 — Foundry Evals Integration](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0023-foundry-evals-integration.md)：完整架構設計，.NET 與 Python 的差異，`IAgentEvaluator` 的 provider-agnostic 設計

---

> **返回目錄**：[README](README.md) | **上一章**：[27 — Feature Collections](./27-feature-collections.md) | **下一章**：[附錄 A — NuGet 套件參考表](./appendix-a-nuget-packages.md)
