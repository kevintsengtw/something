# 03 — 開發環境準備

> 本章將引導你設定 Microsoft Agent Framework 的 C# 開發環境，包含 .NET SDK、NuGet 套件、LLM 提供者和 IDE 設定。完成後你就具備了建立第一個 Agent 的所有條件。

---

## 事前準備

開始之前，請確認你具備以下基礎：

- 熟悉 C# 語法（本教學使用最新的 C# 語法特性，如 top-level statements）
- 已安裝 Git（用於取得範例程式碼）
- 擁有至少一個 LLM 提供者的存取權限（後面會詳細說明）

---

## 安裝 .NET SDK

Microsoft Agent Framework 的 .NET 版本支援以下目標框架：

| 目標框架 | 版本 |
|----------|------|
| .NET | 8.0 以上 |
| .NET Standard | 2.0 |
| .NET Framework | 4.7.2 以上 |

建議使用 **.NET 8.0 或更新版本**。

### 確認已安裝的版本

```bash
dotnet --version
```

如果尚未安裝或版本過舊，請到 [.NET 官方下載頁面](https://dotnet.microsoft.com/download) 下載最新的 SDK。

### 驗證安裝

```bash
dotnet --list-sdks
```

確認輸出中包含 8.0 以上的版本即可。

---

## 建立專案

### 使用 Console 專案範本

對於入門學習，使用最單純的 Console 應用程式即可：

```bash
# 建立專案目錄
mkdir MyFirstAgent
cd MyFirstAgent

# 建立 Console 專案
dotnet new console
```

### 專案檔案結構

建立後的專案結構如下：

```text
MyFirstAgent/
├── MyFirstAgent.csproj    ← 專案設定檔
├── Program.cs             ← 程式進入點
└── obj/
```

---

## 安裝 NuGet 套件

Microsoft Agent Framework 已於 2026 年 4 月 2 日正式發佈 **v1.0.0（GA）**，所有套件皆為正式版本，安裝時**不需要** `--prerelease` 旗標。

### 核心套件

以下兩個是入門必裝的套件：

```bash
# 核心框架 — Agent 抽象、介面定義
dotnet add package Microsoft.Agents.AI

# OpenAI 提供者 — 支援 OpenAI 與 Azure OpenAI
dotnet add package Microsoft.Agents.AI.OpenAI
```

### 依提供者安裝的套件

根據你選擇的 LLM 提供者，可能還需要安裝額外的套件：

**使用 Azure OpenAI：**
```bash
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

**使用 OpenAI：**
```bash
# Microsoft.Agents.AI.OpenAI 已包含 OpenAI 的支援，不需額外安裝
```

**使用 GitHub Models（免費入門選項）：**
```bash
# 同樣使用 Microsoft.Agents.AI.OpenAI 套件，設定不同的 Endpoint
```

### 完整套件說明

| 套件 | 用途 | 入門需要 |
|------|------|----------|
| `Microsoft.Agents.AI` | 核心介面與抽象（AIAgent、AgentSession 等） | ✅ 必裝 |
| `Microsoft.Agents.AI.OpenAI` | OpenAI / Azure OpenAI 提供者支援 | ✅ 必裝 |
| `Azure.AI.OpenAI` | Azure OpenAI 專用客戶端 | 使用 Azure OpenAI 時需要 |
| `Azure.Identity` | Azure 身份驗證（AzureCliCredential 等） | 使用 Azure OpenAI 時需要 |
| `Microsoft.Agents.AI.Workflows` | 工作流程編排（Sequential、Concurrent 等） | 後續章節再安裝 |
| `Microsoft.Agents.AI.Hosting` | ASP.NET Core 託管支援 | 進階篇再安裝 |

### 安裝後確認

檢查 `.csproj` 檔案，確認套件已正確加入：

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net8.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.Agents.AI" Version="1.6.1" />
    <PackageReference Include="Microsoft.Agents.AI.OpenAI" Version="1.6.1" />
    <!-- 使用 Azure OpenAI 時加入以下套件 -->
    <!-- <PackageReference Include="Azure.AI.OpenAI" Version="..." /> -->
    <!-- <PackageReference Include="Azure.Identity" Version="..." /> -->
  </ItemGroup>
</Project>
```

---

## 設定 LLM 提供者

Agent Framework 不綁定特定的 LLM 提供者。以下介紹三種常見的選項，你只需要選擇其中一種即可。

### 選項 A：OpenAI

最直接的方式。你需要一個 OpenAI API Key。

**取得 API Key：**
1. 前往 [OpenAI Platform](https://platform.openai.com/)
2. 登入帳號（需註冊）
3. 前往 API Keys 頁面，建立新的 Key

**設定方式：**

建議使用環境變數或 User Secrets 儲存 API Key，避免將 Key 寫死在程式碼中。

使用環境變數：

```bash
# Windows (PowerShell)
$env:OPENAI_API_KEY = "sk-xxxxxxxxxxxxxxxx"

# macOS / Linux
export OPENAI_API_KEY="sk-xxxxxxxxxxxxxxxx"
```

在程式碼中讀取：

```csharp
var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY")
    ?? throw new InvalidOperationException("請設定 OPENAI_API_KEY 環境變數");
```

**建議模型：** `gpt-4o-mini`（性價比最高的入門選擇）

### 選項 B：Azure OpenAI

如果你的團隊已有 Azure 訂閱，Azure OpenAI 提供企業級的安全性與合規性。

**前置作業：**
1. 在 Azure Portal 建立 Azure OpenAI 資源
2. 部署一個模型（建議 `gpt-4o-mini`）
3. 記下 Endpoint URL 和 Deployment Name

**設定方式：**

```bash
# 設定環境變數
$env:AZURE_OPENAI_ENDPOINT = "https://<your-resource>.openai.azure.com/"
$env:AZURE_OPENAI_DEPLOYMENT = "gpt-4o-mini"
```

Azure OpenAI 支援多種驗證方式：

```csharp
using Azure.AI.OpenAI;
using Azure.Identity;

// 方式 1：Azure CLI 認證（開發環境推薦）
var client = new AzureOpenAIClient(
    new Uri(Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!),
    new AzureCliCredential()
);

// 方式 2：DefaultAzureCredential（會自動嘗試多種認證方式）
var client = new AzureOpenAIClient(
    new Uri(Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!),
    new DefaultAzureCredential()
);
```

使用 Azure CLI 認證前，請先確認已登入：

```bash
az login
```

### 選項 C：GitHub Models（免費入門）

如果你只是想快速試試看，GitHub Models 提供免費的 LLM 存取。

**取得 Token：**
1. 前往 [GitHub](https://github.com/) 並登入
2. 到 Settings → Developer settings → Personal access tokens → Tokens (classic)
3. 建立新的 Token

**設定方式：**

```bash
$env:GITHUB_TOKEN = "ghp_xxxxxxxxxxxxxxxx"
```

GitHub Models 使用 OpenAI 相容的 API，但 Endpoint 不同：

```csharp
using OpenAI;

var client = new OpenAIClient(
    new ApiKeyCredential(Environment.GetEnvironmentVariable("GITHUB_TOKEN")!),
    new OpenAIClientOptions
    {
        Endpoint = new Uri("https://models.inference.ai.azure.com")
    }
);
```

**注意事項：**
- GitHub Models 有速率限制，不適合生產環境
- 可用模型可能與 OpenAI 略有差異
- 適合學習與原型開發

### 三種選項的比較

| 特性 | OpenAI | Azure OpenAI | GitHub Models |
|------|--------|--------------|---------------|
| 費用 | 按用量付費 | 按用量付費 | 免費（有限制） |
| 註冊門檻 | 低 | 需 Azure 訂閱 | GitHub 帳號 |
| 企業安全 | 基本 | 完整 | 基本 |
| 速率限制 | 依方案 | 依配額 | 較嚴格 |
| 適用場景 | 個人開發、小型專案 | 企業生產環境 | 學習、原型 |

---

## 使用 User Secrets 管理敏感設定

對於正式的 .NET 專案，建議使用 **User Secrets** 來管理 API Key 等敏感資訊，而不是使用環境變數或設定檔：

```bash
# 初始化 User Secrets
dotnet user-secrets init

# 儲存 API Key
dotnet user-secrets set "OpenAI:ApiKey" "sk-xxxxxxxxxxxxxxxx"

# 或 Azure OpenAI 設定
dotnet user-secrets set "AzureOpenAI:Endpoint" "https://<resource>.openai.azure.com/"
dotnet user-secrets set "AzureOpenAI:DeploymentName" "gpt-4o-mini"
```

在程式碼中使用 `Microsoft.Extensions.Configuration` 讀取：

```csharp
using Microsoft.Extensions.Configuration;

var config = new ConfigurationBuilder()
    .AddUserSecrets<Program>()
    .Build();

var apiKey = config["OpenAI:ApiKey"]
    ?? throw new InvalidOperationException("請設定 OpenAI:ApiKey");
```

這需要額外安裝套件：

```bash
dotnet add package Microsoft.Extensions.Configuration.UserSecrets
```

---

## IDE 設定建議

### Visual Studio 2022+

如果你習慣使用 Visual Studio：

1. 確認已安裝 **ASP.NET and web development** 工作負載
2. 安裝最新更新，確保支援 .NET 8+
3. 建議安裝 **AI Toolkit for Visual Studio**（如果可用）

### Visual Studio Code

如果你偏好使用 VS Code：

1. 安裝 [C# Dev Kit](https://marketplace.visualstudio.com/items?itemName=ms-dotnettools.csdevkit) 擴充套件
2. 安裝 [AI Toolkit for VS Code](https://marketplace.visualstudio.com/items?itemName=ms-windows-ai-studio.windows-ai-studio)（v0.30.0+）
   - 提供 Tool Catalog、Agent Inspector 與 Agent Builder 功能
   - 支援 F5 偵錯代理應用程式

### JetBrains Rider

Rider 同樣完整支援 .NET 8+ 開發，可直接使用。

---

## 取得官方範例程式碼

本教學的範例實作章節以官方範例為基礎。建議先將範例儲存庫 Clone 到本機：

```bash
git clone https://github.com/microsoft/Agent-Framework-Samples.git
```

Clone 完成後，入門範例位於：

```text
Agent-Framework-Samples/
└── 00.ForBeginners/
    ├── README.md
    ├── BasicAgent/         ← 第 04 章使用
    ├── ToolUse/            ← 第 05 章使用
    ├── DesignPatterns/     ← 第 06 章使用
    ├── TravelAgent/        ← 第 07 章使用
    ├── RAGSearch/          ← 第 08 章使用
    ├── Planning/           ← 第 09 章使用
    └── MultiAgent/         ← 第 10 章使用
```

---

## 驗證環境

一切就緒後，讓我們做一個簡單的驗證，確認環境設定正確。

建立一個測試用的 `Program.cs`：

```csharp
using Microsoft.Agents.AI;
using OpenAI;

// 讀取 API Key（請替換為你的設定方式）
var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY")
    ?? throw new InvalidOperationException("請設定 OPENAI_API_KEY 環境變數");

// 建立代理
var agent = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o-mini")
    .AsAIAgent(
        name: "TestAgent",
        instructions: "請用繁體中文回答。"
    );

// 測試對話
var response = await agent.RunAsync("請說 Hello World");
Console.WriteLine(response.Text);
```

執行：

```bash
dotnet run
```

如果一切正常，你會看到代理用繁體中文回應 Hello World 的訊息。

### 常見問題排除

**問題：`dotnet run` 出現套件版本錯誤**
```text
解決：確認安裝的是 v1.0.0 或更新的正式版本
      dotnet add package Microsoft.Agents.AI
      （v1.0.0 GA 後不再需要 --prerelease 旗標）
```

**問題：API Key 無效或認證失敗**
```text
解決：確認環境變數已正確設定
      PowerShell: echo $env:OPENAI_API_KEY
      Bash: echo $OPENAI_API_KEY
```

**問題：模型名稱找不到**
```text
解決：確認使用正確的模型名稱
      OpenAI: "gpt-4o-mini"
      Azure OpenAI: 使用你部署時設定的 Deployment Name
```

---

## 小結

完成本章後，你應該已經具備：

- ✅ .NET 8.0+ SDK 已安裝
- ✅ 核心 NuGet 套件已安裝（`Microsoft.Agents.AI`、`Microsoft.Agents.AI.OpenAI`）
- ✅ 至少一個 LLM 提供者已設定好（OpenAI / Azure OpenAI / GitHub Models）
- ✅ IDE 已就緒
- ✅ 官方範例已 Clone 到本機
- ✅ 驗證測試通過

下一章我們將正式開始建立你的第一個 Agent，深入探索代理的建立與對話機制。

---

> **返回目錄**：[README](README.md) | **上一章**：[02 — 核心概念總覽](./02-core-concepts.md) | **下一章**：[04 — 建立你的第一個 Agent](./04-first-agent.md)
