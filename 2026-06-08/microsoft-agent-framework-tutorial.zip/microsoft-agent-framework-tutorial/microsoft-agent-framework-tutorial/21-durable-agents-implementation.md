# 21 — Durable Agents 實作

> 本章帶你實作 Durable Agents 的兩種主要模式：**Azure Functions 自動端點**（適合生產 API）與 **Console / Generic Host 手動編排**（適合自訂 Orchestration）。同時示範多代理串聯、並行執行、以及 Human-in-the-Loop 的持久化版本。

---

## 前置作業

### 環境變數

```bash
dotnet user-secrets set "AZURE_OPENAI_ENDPOINT" "https://your-resource.openai.azure.com/"
dotnet user-secrets set "AZURE_OPENAI_DEPLOYMENT_NAME" "gpt-4o-mini"
dotnet user-secrets set "AZURE_OPENAI_API_KEY" "your-key"  # 或使用 Azure Identity
```

### 啟動本機 DTS Emulator（Console 模式需要）

```bash
docker run -d \
    --name dts-emulator \
    -p 8080:8080 \
    -p 8082:8082 \
    mcr.microsoft.com/dts/dts-emulator:latest
```

連線字串預設值：`Endpoint=http://localhost:8080;TaskHub=default;Authentication=None`

---

## 模式一：Azure Functions（自動 HTTP 端點）

### 1. 建立專案

```bash
dotnet new func -n DurableAgentFunctions --worker-runtime dotnet-isolated --framework net9.0
cd DurableAgentFunctions

dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.Hosting.AzureFunctions
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

### 2. Program.cs（單一代理）

```csharp
// Copyright (c) Microsoft. All rights reserved.

using Azure.AI.OpenAI;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Hosting.AzureFunctions;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Hosting;

string endpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")
    ?? throw new InvalidOperationException("AZURE_OPENAI_ENDPOINT is not set.");
string deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME")
    ?? "gpt-4o-mini";

// 建立 AI 代理
AIAgent jokerAgent = new AzureOpenAIClient(
        new Uri(endpoint),
        new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        instructions: "你是一個幽默的笑話達人，請以台灣在地文化說笑話。",
        name: "Joker");

// ConfigureDurableAgents：自動產生 HTTP 端點並管理 Session 生命週期
using IHost app = FunctionsApplication
    .CreateBuilder(args)
    .ConfigureFunctionsWebApplication()
    .ConfigureDurableAgents(options =>
        options.AddAIAgent(jokerAgent, timeToLive: TimeSpan.FromHours(1)))
    .Build();

app.Run();
```

### 3. 本機執行與測試

```bash
func start
```

框架自動產生以下端點：

```http
# 建立新對話（自動產生 sessionId）
POST http://localhost:7071/api/agents/Joker/run
Content-Type: application/json

{"message": "說個笑話"}

# 繼續既有對話
POST http://localhost:7071/api/agents/Joker/run
Content-Type: application/json

{"message": "再說一個！", "thread_id": "abc-123-session-key"}
```

回應格式：

```json
{
  "text": "為什麼工程師都喜歡喝咖啡？因為 Java！",
  "thread_id": "abc-123-session-key"
}
```

> **`thread_id` 的重要性**：這是 Session Key，後續對話必須帶著它才能延續同一段對話。前端需要妥善儲存此值。

### v1.4.0：HTTP trigger 直接回傳執行結果

> 🆕 **v1.4.0 新增**（[PR #5321](https://github.com/microsoft/agent-framework/pull/5321)）：Durable Workflow HTTP trigger endpoint 現在支援直接回傳代理執行結果。

v1.4.0 以前，`POST /api/agents/<name>/run` 固定回傳 `202 Accepted` + polling URL，呼叫端必須輪詢才能取得結果。v1.4.0 起，框架偵測到任務在超時前完成時，會直接以 `200 OK` 回傳最終回應，省去輪詢步驟：

```http
# v1.4.0 以前：固定 202 + Location header（需輪詢）
HTTP/1.1 202 Accepted
Location: http://localhost:7071/runtime/webhooks/durabletask/instances/abc-123

# v1.4.0 以後：任務快速完成時直接 200（不需輪詢）
HTTP/1.1 200 OK
Content-Type: application/json

{"text": "為什麼工程師都喜歡喝咖啡？因為 Java！", "thread_id": "abc-123-session-key"}
```

長時間任務（超過 HTTP 超時閾值）仍會回傳 202 + polling URL，行為與以前相同。這個改進對短問答場景的使用體驗有顯著提升。

---

## 模式二：Console App + Durable Orchestration

Console 模式讓你完整控制 Durable Task 的 Worker 和 Client，適合自訂 Orchestration 邏輯。

### 1. 建立專案

```bash
dotnet new console -n DurableAgentConsole --framework net9.0
cd DurableAgentConsole

dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.DurableTask
dotnet add package Microsoft.DurableTask.Client.AzureManaged
dotnet add package Microsoft.DurableTask.Worker.AzureManaged
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
dotnet add package Microsoft.Extensions.Hosting
```

### 2. 單一代理對話（Program.cs）

```csharp
using Azure;
using Azure.AI.OpenAI;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.DurableTask;
using Microsoft.DurableTask.Client.AzureManaged;
using Microsoft.DurableTask.Worker.AzureManaged;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

// ── 環境設定 ──────────────────────────────────────────────────────
string endpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")
    ?? throw new InvalidOperationException("AZURE_OPENAI_ENDPOINT is not set.");
string deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME")
    ?? "gpt-4o-mini";
string dtsConnectionString = Environment.GetEnvironmentVariable("DURABLE_TASK_SCHEDULER_CONNECTION_STRING")
    ?? "Endpoint=http://localhost:8080;TaskHub=default;Authentication=None";

string? azureKey = Environment.GetEnvironmentVariable("AZURE_OPENAI_API_KEY");
AzureOpenAIClient client = !string.IsNullOrEmpty(azureKey)
    ? new AzureOpenAIClient(new Uri(endpoint), new AzureKeyCredential(azureKey))
    : new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential());

// ── 建立代理 ──────────────────────────────────────────────────────
const string JokerName = "Joker";
AIAgent jokerAgent = client
    .GetChatClient(deploymentName)
    .AsAIAgent("你是笑話達人。", JokerName);

// ── 設定 Durable Agents Host ──────────────────────────────────────
IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureLogging(logging => logging.SetMinimumLevel(LogLevel.Warning))
    .ConfigureServices(services =>
    {
        services.ConfigureDurableAgents(
            options => options.AddAIAgent(jokerAgent, timeToLive: TimeSpan.FromHours(1)),
            workerBuilder: b => b.UseDurableTaskScheduler(dtsConnectionString),
            clientBuilder: b => b.UseDurableTaskScheduler(dtsConnectionString));
    })
    .Build();

await host.StartAsync();

// ── 取得代理 Proxy 並建立 Session ─────────────────────────────────
// 注意：從 DI 取出的是 Proxy 物件，不是直接的 AIAgent
AIAgent agentProxy = host.Services.GetRequiredKeyedService<AIAgent>(JokerName);
AgentSession session = await agentProxy.CreateSessionAsync();

// ── 對話迴圈 ──────────────────────────────────────────────────────
Console.ForegroundColor = ConsoleColor.Cyan;
Console.WriteLine("=== Durable Agent 對話示範 ===");
Console.ResetColor();

while (true)
{
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.Write("你：");
    Console.ResetColor();

    string? input = Console.ReadLine();
    if (string.IsNullOrWhiteSpace(input) || input == "exit") break;

    try
    {
        AgentResponse response = await agentProxy.RunAsync(
            message: input,
            session: session,
            cancellationToken: CancellationToken.None);

        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write($"{JokerName}：");
        Console.ResetColor();
        Console.WriteLine(response.Text);
        Console.WriteLine();
    }
    catch (Exception ex)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Error.WriteLine($"錯誤：{ex.Message}");
        Console.ResetColor();
    }
}

await host.StopAsync();
```

---

## 模式三：多代理串聯 Orchestration

Durable Orchestration 讓你用**確定性重放（Deterministic Replay）**的方式協調多個 Durable Agent Session，適合需要精確控制執行順序的場景。

```csharp
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.DurableTask;
using Microsoft.DurableTask;
using Microsoft.DurableTask.Client;
using Microsoft.DurableTask.Client.AzureManaged;
using Microsoft.DurableTask.Worker;
using Microsoft.DurableTask.Worker.AzureManaged;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

// ── 代理定義 ──────────────────────────────────────────────────────
const string WriterName = "WriterAgent";
AIAgent writerAgent = client.GetChatClient(deploymentName).AsAIAgent(
    """
    你是文案精煉師。
    - 收到初稿時：擴充並改善文字
    - 收到精修稿時：進一步打磨，讓語句更流暢
    """,
    WriterName);

// ── Orchestrator Function ─────────────────────────────────────────
static async Task<string> RunWriterOrchestratorAsync(TaskOrchestrationContext context)
{
    // 取得代理的 Durable 包裝（支援確定性重放）
    DurableAIAgent writer = context.GetAgent(WriterName);

    // 建立持久化 Session（跨 Orchestration 保留對話歷史）
    AgentSession writerSession = await writer.CreateSessionAsync();

    // 第一輪：生成初稿
    AgentResponse<TextResponse> draft = await writer.RunAsync<TextResponse>(
        message: "寫一句關於「持續學習」的激勵語句。",
        session: writerSession);

    // 第二輪：在同一個 Session 中精修（代理記得第一輪的上下文）
    AgentResponse<TextResponse> refined = await writer.RunAsync<TextResponse>(
        message: $"在不超過 20 個字的前提下進一步改善：{draft.Result.Text}",
        session: writerSession);

    return refined.Result.Text;
}

// ── 設定 Host（含 Orchestrator 注冊）─────────────────────────────
IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureLogging(logging => logging.SetMinimumLevel(LogLevel.Warning))
    .ConfigureServices(services =>
    {
        services.ConfigureDurableAgents(
            options => options.AddAIAgent(writerAgent),
            workerBuilder: b =>
            {
                b.UseDurableTaskScheduler(dtsConnectionString);
                // 注冊 Orchestrator
                b.AddTasks(registry =>
                    registry.AddOrchestratorFunc(
                        nameof(RunWriterOrchestratorAsync),
                        RunWriterOrchestratorAsync));
            },
            clientBuilder: b => b.UseDurableTaskScheduler(dtsConnectionString));
    })
    .Build();

await host.StartAsync();

// ── 啟動 Orchestration ──────────────────────────────────────────
DurableTaskClient durableClient = host.Services.GetRequiredService<DurableTaskClient>();

string instanceId = await durableClient.ScheduleNewOrchestrationInstanceAsync(
    orchestratorName: nameof(RunWriterOrchestratorAsync));

Console.WriteLine($"Orchestration 已啟動，ID：{instanceId}");

// 等待完成
OrchestrationMetadata status = await durableClient.WaitForInstanceCompletionAsync(
    instanceId,
    getInputsAndOutputs: true,
    CancellationToken.None);

if (status.RuntimeStatus == OrchestrationRuntimeStatus.Completed)
{
    Console.WriteLine($"✅ 結果：{status.ReadOutputAs<string>()}");
}
else
{
    Console.WriteLine($"❌ 狀態：{status.RuntimeStatus}");
    if (status.FailureDetails is not null)
        Console.WriteLine($"錯誤：{status.FailureDetails.ErrorMessage}");
}

await host.StopAsync();
```

---

## 模式四：多代理並行 Orchestration

多個代理同時執行，全部完成後匯總：

```csharp
static async Task<string[]> RunParallelOrchestratorAsync(TaskOrchestrationContext context)
{
    DurableAIAgent analyzer = context.GetAgent("AnalyzerAgent");
    DurableAIAgent critic = context.GetAgent("CriticAgent");
    DurableAIAgent summarizer = context.GetAgent("SummarizerAgent");

    string document = "AI 代理技術正在快速演進，從單一模型到多代理協作...";

    // 同時為三個代理建立 Session
    AgentSession analyzerSession = await analyzer.CreateSessionAsync();
    AgentSession criticSession = await critic.CreateSessionAsync();
    AgentSession summarizerSession = await summarizer.CreateSessionAsync();

    // 並行執行三個代理（Task.WhenAll 在 Orchestration 中是確定性的）
    var analysisTask = analyzer.RunAsync<TextResponse>(
        $"分析以下文件的核心論點：{document}",
        analyzerSession);
    var criticTask = critic.RunAsync<TextResponse>(
        $"找出以下文件的潛在問題：{document}",
        criticSession);
    var summaryTask = summarizer.RunAsync<TextResponse>(
        $"用三句話總結以下文件：{document}",
        summarizerSession);

    // 等待所有代理完成
    var results = await Task.WhenAll(analysisTask, criticTask, summaryTask);

    return results.Select(r => r.Result.Text).ToArray();
}
```

---

## 模式五：Durable Human-in-the-Loop

Durable Orchestration 讓 Human-in-the-Loop 可以**等待外部事件**，適合需要等幾小時才有人回應的審批流程：

```csharp
const string ApprovalEventName = "ApprovalReceived";

static async Task<string> RunApprovalOrchestratorAsync(TaskOrchestrationContext context)
{
    DurableAIAgent drafter = context.GetAgent("DrafterAgent");
    AgentSession session = await drafter.CreateSessionAsync();

    // 代理生成草稿
    var draft = await drafter.RunAsync<TextResponse>(
        "為我們的新產品生成一份行銷文案草稿",
        session);

    // 傳送通知（透過外部服務）
    context.SendExternalEvent("notify-reviewer",
        new { Message = "有新的草稿待審", Content = draft.Result.Text });

    // ⚠️ 暫停並等待外部審批（可等待幾小時，Orchestration 狀態已持久化）
    bool approved = await context.WaitForExternalEventAsync<bool>(
        eventName: ApprovalEventName,
        timeout: TimeSpan.FromHours(24));  // 24 小時超時

    if (!approved)
        return "草稿已被拒絕，請重新生成";

    // 審批通過後，繼續精修
    var final = await drafter.RunAsync<TextResponse>(
        "審閱者已批准草稿，請做最後潤色並輸出完整版本",
        session);

    return final.Result.Text;
}

// 外部審批端點（例如使用者點擊核准按鈕）
// durableClient.RaiseEventAsync(instanceId, ApprovalEventName, approved: true);
```

---

## Session TTL 實作要點

```csharp
// 不同類型代理設定不同 TTL
services.ConfigureDurableAgents(
    options =>
    {
        // 全域預設（14 天）
        options.DefaultTimeToLive = TimeSpan.FromDays(14);

        // 一次性任務型代理（完成後 1 小時自動清理）
        options.AddAIAgent(taskAgent, timeToLive: TimeSpan.FromHours(1));

        // 長期個人助理（1 年）
        options.AddAIAgent(personalAgent, timeToLive: TimeSpan.FromDays(365));

        // 企業合規歸檔（永久保留，由外部策略管理刪除）
        options.AddAIAgent(complianceAgent, timeToLive: null);
    },
    workerBuilder: b => b.UseDurableTaskScheduler(dtsConnectionString),
    clientBuilder: b => b.UseDurableTaskScheduler(dtsConnectionString));
```

**TTL 的最佳實踐**：

Session 到期後，對話歷史和自訂狀態**永久刪除**，無法恢復。在設定 TTL 前，請考慮：

- 使用者多久會回來繼續未完成的對話？
- 是否需要將對話歷史備份到其他儲存（如資料庫）？
- 對 GDPR / 個資法的合規要求（短 TTL 有助於降低資料保留風險）。

---

## 可觀測性：DTS Dashboard

執行時，開啟 `http://localhost:8082` 查看：

- **Entities 列表**：每個代理 Session 的狀態（活躍/空閒/到期）
- **Orchestrations**：所有 Orchestration 的執行歷史、輸入/輸出
- **Task Hub**：Worker 的健康狀態與處理速率

```bash
# 快速確認所有服務運行中
curl http://localhost:8080/health        # DTS Worker
# 開啟瀏覽器至 http://localhost:8082   # Dashboard
```

---

## 第 20-21 章總結

| 場景 | 推薦方案 |
|------|----------|
| 生產 REST API，需要持久化對話 | Azure Functions + `ConfigureDurableAgents` |
| 批次任務，需要自訂編排邏輯 | Console App + Durable Orchestration |
| 多代理協作，有確定性重放需求 | Durable Orchestration + `context.GetAgent()` |
| 長時間等待人工審批（數小時） | Durable Orchestration + `WaitForExternalEventAsync` |
| 代理 Session 自動清理 | 設定 `timeToLive` 參數 |

---

### 延伸閱讀：官方 ADR 參考

- [ADR 0022 — Chat History Persistence Consistency](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0022-chat-history-persistence-consistency.md)：per-run vs per-service-call 持久化策略，`PerServiceCallChatHistoryPersistingChatClient` middleware 自動注入機制

---

### v1.1.0 升級建議

Microsoft Agent Framework **v1.1.0（2026-04-10）** 針對本章涉及的 Durable 場景修復了多個已知問題，若目前仍使用 v1.0.0，**建議升級至 v1.1.0** 以獲得更穩定的行為：

| 修復項目 | PR | 對本章的影響 |
|---------|-----|-------------|
| **Checkpoint 還原時 input signal 處理** | [#5085](https://github.com/microsoft/agent-framework/pull/5085) | 模式二 ~ 五的 Durable Orchestration 恢復行為更可靠 |
| **Handoff workflow context 傳遞** | [#5136](https://github.com/microsoft/agent-framework/pull/5136) | 模式三 / 四的多代理串聯、並行 Orchestration 更穩定 |
| **Compaction 時 chat history 可能重複** | [#5149](https://github.com/microsoft/agent-framework/pull/5149) | 長對話持久化後的歷史不會出現重複訊息 |
| **Entity key validation** | [#5179](https://github.com/microsoft/agent-framework/pull/5179) | Durable Entity 誤用字元時會更早被拒絕 |
| **FoundryAgent `CreateSessionAsync(conversationId)` 多載** | [#5144](https://github.com/microsoft/agent-framework/pull/5144) | 使用 FoundryAgent 時可透過 `conversationId` 續用既有對話 |

> 💡 v1.1.0 屬**非破壞性更新**，本章所有範例程式碼無需調整即可在 v1.1.0 下運作。完整變更見[附錄 A — v1.1.0 變更摘要](./appendix-a-nuget-packages.md#v110-主要變更從-100-升級)。

---

> **返回目錄**：[README](README.md) | **上一章**：[20 — Durable Agents 概念與架構](./20-durable-agents-concepts.md) | **下一章**：[22 — OpenTelemetry 可觀測性](./22-opentelemetry-observability.md)
