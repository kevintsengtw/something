# 30 — Magentic Orchestration：管理員驅動的多代理協作

> 本章介紹 Microsoft Agent Framework v1.5.0 引入、**v1.9.0 轉穩定（移除 `[Experimental]`）** 的 Magentic Orchestration——由一個管理員代理（manager）自行規劃任務、動態指派給專家代理執行，並在偵測停滯時自動重新規劃的多代理編排模式。

---

## 本章目標

學會用 `MagenticWorkflowBuilder` 建立「任務解決團隊」：由一個**管理員代理（manager）自行規劃**任務、動態指派給專家代理執行，並在偵測停滯時自動重新規劃。你會學到：

- Magentic 與第 18/19 章其他編排（Sequential / Concurrent / GroupChat / Handoff）的差異與取捨
- 管理員驅動的規劃迴圈（Task Ledger、Progress Ledger）
- 串流觀測編排過程的事件
- 用 `RequirePlanSignoff` 在計畫核可加入 Human-in-the-Loop
- 用輪數/停滯/重置上限控制成本與收斂

---

## 為什麼需要 Magentic

第 18 章的 `SequentialWorkflowBuilder`、`ConcurrentWorkflowBuilder` 與第 19 章的 GroupChat、Handoff，**路由邏輯都是開發者預先決定的**：誰接誰、何時分支、何時交接。

但有些任務在開始前**無法預先畫出流程圖**。例如「研究競品定價並產出含圖表的分析報告」——要先查資料還是先定義指標？需要幾輪？要不要回頭補查？這取決於任務本身。

Magentic 的解法：交給一個 **manager 代理**動態規劃。

| 面向 | Graph/Sequential/Concurrent | GroupChat | **Magentic** |
|------|------|------|------|
| 路由決定者 | 開發者（靜態） | manager 選下一位發言者 | **manager 規劃整個計畫並動態指派** |
| 適用 | 確定性流程 | 輪流討論 | **開放性、需規劃與重試的任務** |
| 重新規劃 | 無 | 無 | **偵測停滯自動 replan** |
| 可預測性 | 高 | 中 | 低（AI 決策，需設上限） |

> **取捨**：Magentic 最靈活，但也最不可預測、最耗 token。任務若能畫出固定流程圖，優先用 Sequential/Concurrent；需要開放式探索與自我修正時才用 Magentic。

---

## 核心概念：管理員驅動的規劃迴圈

```text
① Manager 接收任務目標
② Manager 建立 Task Ledger（事實 + 計畫）         → MagenticPlanCreatedEvent
   （若 RequirePlanSignoff(true)，此處暫停等待人工核可）
③ Manager 更新 Progress Ledger（誰該發言、是否完成、是否停滯）→ MagenticProgressLedgerUpdatedEvent
④ 指派下一位專家代理執行，回報結果
⑤ 若停滯（無進展/繞圈），Reset 並重新規劃            → MagenticReplannedEvent
⑥ 任務完成 → 產出最終對話                          → WorkflowOutputEvent
```

- **Task Ledger**：manager 對任務的事實整理與步驟計畫（`MagenticPlanCreatedEvent.FullTaskLedger`）。
- **Progress Ledger**：每一輪 manager 對「是否達成、是否在繞圈、是否有進展、下一位發言者」的判斷（`MagenticProgressLedgerUpdatedEvent.ProgressLedger`）。
- **manager 與 participants 都是一般 `AIAgent`**——manager 負責規劃，participants 是執行專家。manager 靠 participants 的 `description` 來決定指派誰，所以**描述要寫清楚**。
- 內部編排型別 `MagenticOrchestrator` / `MagenticManager` 在 v1.9.0 已改為 `internal`，你只透過 `MagenticWorkflowBuilder` 使用。

---

## 安裝套件

Magentic 屬於 Workflows 套件；本章範例用 Azure AI Foundry 的程式碼直譯工具讓「分析代理」能實際算數：

```bash
dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.Workflows
dotnet add package Microsoft.Agents.AI.Foundry
dotnet add package Azure.Identity
```

> manager 與 participants 可以是**任何** `AIAgent`（Azure OpenAI、OpenAI、Foundry 皆可）。本章用 Foundry 是因為分析代理需要 `HostedCodeInterpreterTool`；若不需執行程式碼，用第 17 章任一提供者即可。

---

## 本章情境：市場分析團隊

目標：「研究三家競品的訂閱定價，計算平均價與中位數，並總結定價策略。」

團隊：
- **ResearcherAgent**：負責找資料（不做計算）
- **AnalystAgent**：負責寫程式做量化計算（用 Code Interpreter）
- **ManagerAgent**：規劃與指派

### 建立代理與工作流程

```csharp
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Extensions.AI;
using Azure.AI.Projects;
using Azure.Identity;

string endpoint = Environment.GetEnvironmentVariable("AZURE_AI_PROJECT_ENDPOINT")!;
string deployment = Environment.GetEnvironmentVariable("AZURE_AI_MODEL_DEPLOYMENT_NAME") ?? "gpt-4o-mini";

var projectClient = new AIProjectClient(new Uri(endpoint), new DefaultAzureCredential());

AIAgent researcher = projectClient.AsAIAgent(
    deployment,
    name: "ResearcherAgent",
    description: "擅長蒐集資料與市場資訊，不做量化計算。",
    instructions: "你是研究員，負責找出相關資訊，不要自行做數值運算。");

AIAgent analyst = projectClient.AsAIAgent(
    deployment,
    name: "AnalystAgent",
    description: "撰寫並執行程式碼進行數據分析的助理。",
    instructions: "你以撰寫並執行程式碼來回答量化問題，清楚展示分析與計算過程。",
    tools: [new HostedCodeInterpreterTool()]);

AIAgent manager = projectClient.AsAIAgent(
    deployment,
    name: "ManagerAgent",
    description: "協調研究與分析工作的編排者。",
    instructions: "你負責協調團隊，有效率地完成複雜任務。");

// 用 MagenticWorkflowBuilder 組裝（manager 傳入建構子，participants 用 AddParticipants）
Workflow workflow = new MagenticWorkflowBuilder(manager)
    .AddParticipants([researcher, analyst])
    .WithName("Market Analysis Workflow")
    .WithDescription("協調研究員與分析師完成競品定價分析。")
    .RequirePlanSignoff(false)   // 先不加人工審批（HITL 見後文）
    .WithMaxRounds(10)           // 協調輪數上限
    .WithMaxStalls(3)            // 連續無進展幾次就重新規劃
    .WithMaxResets(2)            // 最多重新規劃幾次
    .Build();
```

### 執行並觀測編排過程

Magentic 的價值在於「看見它怎麼想」，因此用串流執行，逐一處理事件：

```csharp
const string task = "研究三家競品的訂閱定價，計算平均價與中位數，並總結定價策略。";

await using StreamingRun run = await InProcessExecution.RunStreamingAsync(
    workflow,
    new List<ChatMessage> { new(ChatRole.User, task) });

// 啟動第一輪，並要求發出事件
await run.TrySendMessageAsync(new TurnToken(emitEvents: true));

WorkflowOutputEvent? finalOutput = null;

await foreach (WorkflowEvent evt in run.WatchStreamAsync())
{
    switch (evt)
    {
        case MagenticPlanCreatedEvent planCreated:
            Console.WriteLine($"【初始計畫】\n{planCreated.FullTaskLedger.Text}\n");
            break;

        case MagenticReplannedEvent replanned:
            Console.WriteLine($"【重新規劃】\n{replanned.FullTaskLedger.Text}\n");
            break;

        case MagenticProgressLedgerUpdatedEvent progress:
            Console.WriteLine($"【進度更新】下一位：{progress.ProgressLedger.NextSpeaker}\n");
            break;

        case AgentResponseUpdateEvent update:
            Console.Write(update.Update.Text);   // 代理串流輸出
            break;

        case WorkflowOutputEvent output when output.Is<List<ChatMessage>>():
            finalOutput = output;
            break;

        case WorkflowErrorEvent error:
            Console.Error.WriteLine(error.Exception);
            break;
    }
}

// 取出最終對話 transcript
if (finalOutput?.As<List<ChatMessage>>() is { } transcript)
{
    Console.WriteLine("\n===== 最終結果 =====");
    foreach (ChatMessage m in transcript)
    {
        Console.WriteLine($"{m.AuthorName ?? m.Role.ToString()}: {m.Text}");
    }
}
```

> `TurnToken(emitEvents: true)` 啟動編排並要求發出 `AgentResponseUpdateEvent` 等細粒度事件；若只想看結果，可用非串流的 `InProcessExecution.RunAsync` 並讀 `run.NewEvents`（見第 18 章）。

---

## 參數調校：控制成本與收斂

Magentic 是 AI 決策迴圈，**務必設上限**，否則可能反覆規劃而燒掉大量 token：

| 方法 | 作用 | 預設 |
|------|------|------|
| `WithMaxRounds(int?)` | 協調輪數上限（`null` = 無限） | 無限 |
| `WithMaxStalls(int)` | 連續無進展幾次後觸發重新規劃 | 3 |
| `WithMaxResets(int?)` | 最多重新規劃幾次（`null` = 無限） | 無限 |

達到上限時，工作流程會以「因達到上限而停止」訊息結束，而非無限執行。建議生產環境一律設定明確上限。

---

## 加入 Human-in-the-Loop：計畫審批

把 `RequirePlanSignoff(true)` 打開，manager 產生計畫後會**暫停**，等待人工核可或要求修改才繼續。這是第 16 章 HITL 機制在編排層的應用，透過工作流程的外部請求（`RequestInfoEvent`）實現：

```csharp
Workflow workflow = new MagenticWorkflowBuilder(manager)
    .AddParticipants([researcher, analyst])
    .RequirePlanSignoff(true)   // ← 計畫需人工核可
    .WithMaxRounds(10)
    .Build();

await using StreamingRun run = await InProcessExecution.RunStreamingAsync(
    workflow, new List<ChatMessage> { new(ChatRole.User, task) });
await run.TrySendMessageAsync(new TurnToken(emitEvents: true));

await foreach (WorkflowEvent evt in run.WatchStreamAsync())
{
    // 工作流程要求人工審查計畫
    if (evt is RequestInfoEvent reqEvt &&
        reqEvt.Request.Data.As<MagenticPlanReviewRequest>() is { } review)
    {
        Console.WriteLine($"【待審計畫】\n{review.Plan.Text}");
        Console.Write("核可？(y/n) ");
        bool approved = Console.ReadLine()?.Trim().ToLower() == "y";

        MagenticPlanReviewResponse decision = approved
            ? review.Approve()
            : review.Revise("請在計畫中加入『資料來源可信度查核』步驟。");

        // 建立回應並送回工作流程，編排繼續
        ExternalResponse response = reqEvt.Request.CreateResponse(decision);
        await run.SendResponseAsync(response);
    }
    // ... 其餘事件處理同前 ...
}
```

`MagenticPlanReviewRequest` 是一個 record，提供三種建立回應的便捷方法：

| 方法 | 意義 |
|------|------|
| `review.Approve()` | 核可計畫，直接執行 |
| `review.Revise(string)` | 要求修改，附上文字意見 → manager 會 replan |
| `review.Revise(ChatMessage / IEnumerable<ChatMessage>)` | 同上，可傳結構化訊息 |

它也帶有 `Plan`（計畫內容）、`CurrentProgress`（目前進度，初次為 null）、`IsStalled`（是否因停滯而要求重審）三個欄位，供你決定如何回應。

> **持久化版本**：若要在計畫審批期間關閉程式、之後再恢復（durable），可搭配 `CheckpointManager` 與工作流程的 checkpoint/resume 機制（見第 20–21 章）；此時改用 `WorkflowRunResult.PendingRequests` 取出 `ExternalRequest`、`request.CreateResponse(...)` 後從 checkpoint 恢復。

---

## 標註與過濾輸出（v1.9.0）

預設情況下，Magentic 以 manager 的最終答覆為終端輸出、participants 的訊息為中間輸出。若要自訂，可用共同基底 `OrchestrationBuilderBase` 的輸出指定方法（Workflow Outputs Overhaul，見[第 19 章](./19-workflows-advanced.md)）：

```csharp
Workflow workflow = new MagenticWorkflowBuilder(manager)
    .AddParticipants([researcher, analyst])
    .WithOutputFrom(analyst)                 // 只把分析師結果當最終輸出
    .WithIntermediateOutputFrom([researcher]) // 研究員訊息標為中間輸出
    .Build();
```

消費端可依 `OutputTag.Intermediate` 過濾，例如只把最終結果回傳使用者、中間過程僅供除錯。

---

## 編排模式選擇指引

| 需求 | 建議模式 | 章節 |
|------|---------|------|
| 固定步驟、依序接力 | `SequentialWorkflowBuilder` | ch18 |
| 同一輸入多代理並行、再彙整 | `ConcurrentWorkflowBuilder` | ch18 |
| 多代理輪流討論、manager 選發言者 | `GroupChatWorkflowBuilder` | ch19 |
| 依意圖路由給專家、可交接 | Handoff（`AgentWorkflowBuilder.CreateHandoffBuilderWith`） | ch18 |
| **開放式任務、需 AI 規劃 + 自我修正** | **`MagenticWorkflowBuilder`** | **本章** |
| 需要逐節點精確控制、條件邊、子工作流程 | 低階 `WorkflowBuilder` | ch18/19 |

---

## 常見錯誤

| 症狀 | 原因 | 解法 |
|------|------|------|
| 工作流程跑很久、token 爆量 | 未設上限，manager 反覆規劃 | 設定 `WithMaxRounds`/`WithMaxStalls`/`WithMaxResets` |
| manager 老是指派錯代理 | participants 的 `description` 太模糊 | 把每個 participant 的 `description` 寫清楚職責邊界 |
| 開了 `RequirePlanSignoff(true)` 卻沒反應/卡住 | 未在事件迴圈處理 `RequestInfoEvent` 並 `SendResponseAsync` | 補上計畫審查的請求/回應處理 |
| 看不到中間過程 | 用了非串流 `RunAsync`，或未傳 `TurnToken(emitEvents: true)` | 用 `RunStreamingAsync` + `emitEvents: true` |
| 找不到 `MagenticOrchestrator` 型別 | v1.9.0 起已改為 `internal` | 改用公開入口 `MagenticWorkflowBuilder` |

---

## 小結

本章你學會了：

- **Magentic Orchestration** 適用於無法預先畫出流程圖的開放式任務——由 manager 代理規劃、動態指派、自我修正
- `MagenticWorkflowBuilder`：manager 傳入建構子、`AddParticipants` 加入專家、`Build()` 產出標準 `Workflow`
- 用 `RunStreamingAsync` + `TurnToken(emitEvents: true)` + `WatchStreamAsync` 觀測 `MagenticPlanCreatedEvent` / `MagenticProgressLedgerUpdatedEvent` / `MagenticReplannedEvent`
- `WithMaxRounds` / `WithMaxStalls` / `WithMaxResets` 控制成本與收斂
- `RequirePlanSignoff(true)` 搭配 `RequestInfoEvent` + `MagenticPlanReviewRequest.Approve()/Revise()` 加入計畫審批 HITL
- 用 `WithOutputFrom` / `WithIntermediateOutputFrom` 標註與過濾輸出

---

## 相關章節

- [第 18 章：Workflows 基礎](./18-workflows-basics.md) — Sequential / Concurrent 高階 Builder
- [第 19 章：Workflows 進階](./19-workflows-advanced.md) — GroupChat、Workflow Outputs Overhaul
- [第 16 章：Human-in-the-Loop](./16-human-in-the-loop.md) — 外部請求/回應機制
- [第 20–21 章：Durable Agents](./20-durable-agents-concepts.md) — checkpoint/resume 持久化

## 延伸閱讀

- 官方範例：`dotnet/samples/03-workflows/Orchestration/Magentic`

---

> **返回目錄**：[README](README.md) | **上一章**：[29 — Agent Skills：可攜式技能套件](./29-agent-skills.md)
