# 17 — 多 LLM 提供者整合

> 本章介紹 Agent Framework 支援的各大 LLM 提供者，包含完整的套件安裝、環境設定與程式碼範例。框架的核心設計讓你只需更換 ChatClient，即可在不修改代理邏輯的情況下切換任何提供者。

---

## 提供者無關的代理設計

Agent Framework 的最大優勢之一是**提供者無關性**——所有 LLM 提供者都實作相同的 `IChatClient` 介面，代理邏輯完全不需要知道底層使用哪個模型：

```csharp
// 這個代理定義與提供者無關
static AIAgent CreateAgent(IChatClient chatClient) =>
    chatClient.AsAIAgent(
        name: "UniversalAgent",
        instructions: "你是一個通用助理",
        tools: [/* 你的工具 */]);

// 在 Azure OpenAI、Anthropic、Ollama 上執行同一個代理
var azureAgent = CreateAgent(GetAzureOpenAIClient());
var anthropicAgent = CreateAgent(GetAnthropicClient());
var ollamaAgent = CreateAgent(GetOllamaClient());
```

---

## 提供者比較速覽

| 提供者 | 套件 | 適合場景 | 特色 |
|--------|------|----------|------|
| **Azure AI Foundry** | `Microsoft.Agents.AI.Foundry` | 企業生產環境 | 託管工具、持久儲存、完整 Azure 整合 |
| **Azure OpenAI** | `Azure.AI.OpenAI` | Azure 企業客戶 | 資料駐留、私有端點、合規性 |
| **OpenAI** | `OpenAI` | 快速開發 | 最新模型、Responses API |
| **Anthropic Claude** | `Microsoft.Agents.AI.Anthropic` | 長文本、程式碼分析 | 200K context、強推理 |
| **GitHub Models** | `OpenAI`（相容） | 免費評估 | 免費配額，Azure 托管 |
| **Ollama** | `OllamaSharp` | 本機/私有部署 | 完全離線、資料不外流 |
| **Google Gemini** | `Microsoft.Extensions.AI.Google` | 多模態 | 原生多模態、長上下文 |

---

## 1. Azure AI Foundry（推薦用於生產環境）

Azure AI Foundry 是 Microsoft 的全托管 AI 平台，提供模型端點、工具儲存、向量資料庫等企業功能。

> 🆕 **v1.2.0 新增**：Azure AI Foundry **Hosted Agents** 完整 .NET 支援（[PR #5312](https://github.com/microsoft/agent-framework/pull/5312)）。Hosted Agents 讓你使用 Foundry 平台代管的代理（含持久儲存、向量資料庫、Code Interpreter 等），透過同一個 `Microsoft.Agents.AI.Foundry` 套件存取，不需要額外設定。

```bash
dotnet add package Microsoft.Agents.AI.Foundry
dotnet add package Azure.AI.Projects
dotnet add package Azure.Identity
```

```csharp
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI;

var endpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
var deployment = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-4o-mini";

// AIProjectClient 支援完整的 Foundry 功能（Hosted Tools、Vector Store 等）
AIAgent agent = new AIProjectClient(
        new Uri(endpoint),
        new DefaultAzureCredential())
    .AsAIAgent(
        model: deployment,
        name: "FoundryAgent",
        instructions: "你是一個企業助理");

Console.WriteLine(await agent.RunAsync("你好！"));
```

**環境設定**：

```bash
# 使用 Azure CLI 登入
az login

# User Secrets（開發環境）
dotnet user-secrets set "AZURE_OPENAI_ENDPOINT" "https://your-resource.openai.azure.com/"
dotnet user-secrets set "AZURE_OPENAI_DEPLOYMENT_NAME" "gpt-4o-mini"
```

> ⚠️ 生產環境建議使用 `ManagedIdentityCredential` 取代 `DefaultAzureCredential`，避免憑證探測的延遲與安全風險。

### v1.6.1 新增：FoundryAgent 型別（直接建立）

除了透過 `AIProjectClient.AsAIAgent()` 建立，v1.6.1 新增了 `FoundryAgent` 具體型別，讓語意更清晰、設定更直接：

```csharp
using Azure.Identity;
using Microsoft.Agents.AI.Foundry;

var endpoint = Environment.GetEnvironmentVariable("AZURE_AI_PROJECT_ENDPOINT")!;
var deployment = Environment.GetEnvironmentVariable("AZURE_AI_MODEL_DEPLOYMENT_NAME") ?? "gpt-5.4-mini";

// 直接建立 FoundryAgent（v1.6.1 推薦方式）
FoundryAgent agent = new FoundryAgent(
    new Uri(endpoint),
    new AzureCliCredential(),
    model: deployment,
    instructions: "You are a helpful assistant.",
    name: "MyFoundryAgent");

Console.WriteLine(await agent.RunAsync("你好！"));

// 或透過 AIProjectClient 擴充方法（效果相同）
FoundryAgent agent2 = new AIProjectClient(new Uri(endpoint), new DefaultAzureCredential())
    .AsAIAgent(
        model: deployment,
        instructions: "...",
        name: "MyFoundryAgent");
```

**環境變數**：

```bash
dotnet user-secrets set "AZURE_AI_PROJECT_ENDPOINT" "https://your-foundry-service.services.ai.azure.com/api/projects/your-project"
dotnet user-secrets set "AZURE_AI_MODEL_DEPLOYMENT_NAME" "gpt-5.4-mini"
```

| 方式 | 適用場景 |
|------|---------|
| `new FoundryAgent(endpoint, credential, model, ...)` | 明確使用 Foundry 功能，語意清晰 |
| `AIProjectClient.AsAIAgent(...)` | 需要同時存取 `AIProjectClient` 其他 API |

### ~~v1.3.0：Foundry Toolbox 伺服器端工具~~（⚠️ v1.6.1 Breaking：已移除）

> ⚠️ **此功能已於 v1.6.1 完整移除（Breaking Change）。**
>
> `AIProjectClient.GetToolboxAsync()` 及 `FoundryToolbox` 型別不再存在，使用這些 API 的程式碼**無法編譯**。對應的官方範例 `Agent_Step25_ToolboxServerSideTools` 亦已廢棄。
>
> **遷移方式**：改用 client-side 工具定義（`AIFunctionFactory.Create()`）：

```csharp
// ✅ v1.6.1+ 替代方案：直接在代理端定義工具
[Description("執行任務")]
static string MyTool([Description("任務描述")] string task) => $"已執行：{task}";

AIAgent agent = new AIProjectClient(new Uri(endpoint), new DefaultAzureCredential())
    .AsAIAgent(
        model: deployment,
        name: "FoundryAgent",
        instructions: "你是一個可以使用工具的代理",
        tools: [AIFunctionFactory.Create(MyTool)]);

Console.WriteLine(await agent.RunAsync("使用工具完成任務"));
```

完整的 client-side 工具定義說明請參考 [第 05 章：工具基礎](./05-tools-basics.md)。

---

## 2. Azure OpenAI（ChatCompletion API）

直接使用 Azure OpenAI 的 Chat Completions API，適合已有 Azure OpenAI 資源的場景：

```bash
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
dotnet add package Microsoft.Agents.AI
```

```csharp
using Azure.AI.OpenAI;
using Azure.Identity;
using Microsoft.Agents.AI;

var endpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
var deployment = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-4o-mini";

AIAgent agent = new AzureOpenAIClient(
        new Uri(endpoint),
        new DefaultAzureCredential())
    .GetChatClient(deployment)
    .AsAIAgent(
        name: "AzureAgent",
        instructions: "你是一個有幫助的助理");

Console.WriteLine(await agent.RunAsync("解釋一下量子纏結"));
```

**Azure OpenAI Responses API**（支援更多功能，如 Computer Use）：

```bash
dotnet add package Azure.AI.OpenAI
dotnet add package Microsoft.Agents.AI.OpenAI
```

```csharp
using Azure.AI.OpenAI;
using Azure.Identity;
using Microsoft.Agents.AI.OpenAI;  // 注意：不同的命名空間

AIAgent agent = new AzureOpenAIClient(
        new Uri(endpoint),
        new DefaultAzureCredential())
    .GetOpenAIResponseClient(deployment)  // ← Responses API
    .AsAIAgent(name: "ResponsesAgent", instructions: "...");
```

---

## 3. OpenAI（直接呼叫）

```bash
dotnet add package OpenAI
dotnet add package Microsoft.Extensions.AI.OpenAI
dotnet add package Microsoft.Agents.AI
```

```csharp
using OpenAI;
using OpenAI.Chat;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY")!;
var model = Environment.GetEnvironmentVariable("OPENAI_MODEL_NAME") ?? "gpt-4o-mini";

// ChatCompletion API
AIAgent agent = new OpenAIClient(apiKey)
    .GetChatClient(model)
    .AsAIChatClient()   // 轉換為 IChatClient
    .AsAIAgent(
        name: "OpenAIAgent",
        instructions: "你是一個有幫助的助理");

Console.WriteLine(await agent.RunAsync("今天天氣如何？"));
```

**OpenAI Responses API**：

```csharp
using OpenAI;
using Microsoft.Agents.AI.OpenAI;

AIAgent agent = new OpenAIClient(apiKey)
    .GetOpenAIResponseClient(model)   // Responses API
    .AsAIAgent(name: "ResponsesAgent", instructions: "...");
```

### 常見模型名稱

| 模型 | 用途 | 備註 |
|------|------|------|
| `gpt-4o` | 通用、多模態 | 成本較高 |
| `gpt-4o-mini` | 入門、低成本測試 | 本教學預設 |
| `gpt-5.4-mini` | 高性價比、低延遲 | 🆕 Agent Framework **v1.1.0 起**原生支援（PR [#5080](https://github.com/microsoft/agent-framework/pull/5080)） |

> 💡 Agent Framework 本身透過 `IChatClient` 抽象，只要 OpenAI SDK 能辨識的模型字串即可使用；v1.1.0 針對 `gpt-5.4-mini` 提供了框架層的最佳化支援。

---

## 4. Anthropic Claude

```bash
dotnet add package Microsoft.Agents.AI.Anthropic
```

Anthropic 支援兩種連線方式：直接呼叫公開 API，或透過 Azure Foundry 呼叫。

```csharp
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Anthropic;  // 或對應命名空間

var modelName = Environment.GetEnvironmentVariable("ANTHROPIC_CHAT_MODEL_NAME")
    ?? "claude-haiku-4-5";
var apiKey = Environment.GetEnvironmentVariable("ANTHROPIC_API_KEY");
var resource = Environment.GetEnvironmentVariable("ANTHROPIC_RESOURCE"); // Azure Foundry

IChatClient client;

if (string.IsNullOrEmpty(resource))
{
    // 方式 A：直接呼叫 Anthropic 公開 API
    client = new AnthropicClient() { ApiKey = apiKey! };
}
else if (!string.IsNullOrEmpty(apiKey))
{
    // 方式 B：透過 Azure Foundry + API Key
    client = new AnthropicFoundryClient(
        new AnthropicFoundryApiKeyCredentials(apiKey, resource));
}
else
{
    // 方式 C：透過 Azure Foundry + Azure Identity（建議生產環境）
    client = new AnthropicFoundryClient(resource, new DefaultAzureCredential());
}

AIAgent agent = client.AsAIAgent(
    model: modelName,
    name: "ClaudeAgent",
    instructions: "你是一個擅長分析長文本的助理");

// Claude 的長上下文能力（最高 200K tokens）
var longDocument = /* 長文件內容 */;
Console.WriteLine(await agent.RunAsync($"請摘要以下文件：{longDocument}"));
```

**環境變數設定**：

```bash
# 方式 A：直接 API
dotnet user-secrets set "ANTHROPIC_API_KEY" "sk-ant-..."
dotnet user-secrets set "ANTHROPIC_CHAT_MODEL_NAME" "claude-haiku-4-5"

# 方式 C：Azure Foundry
dotnet user-secrets set "ANTHROPIC_RESOURCE" "your-foundry-resource"
dotnet user-secrets set "ANTHROPIC_CHAT_MODEL_NAME" "claude-haiku-4-5"
```

> 🆕 **v1.1.0 更新**：Anthropic SDK 由 12.8.0 升級至 12.11.0（PR [#5055](https://github.com/microsoft/agent-framework/pull/5055)），使用方式沒有改變。

---

## 5. GitHub Models（免費評估）

GitHub Models 提供免費配額，用於評估與學習，API 與 OpenAI 完全相容：

```bash
dotnet add package OpenAI
dotnet add package Microsoft.Extensions.AI.OpenAI
dotnet add package Microsoft.Agents.AI
```

```csharp
using OpenAI;
using OpenAI.Chat;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

var githubToken = Environment.GetEnvironmentVariable("GITHUB_TOKEN")!;
var model = Environment.GetEnvironmentVariable("GITHUB_MODEL_NAME") ?? "gpt-4o-mini";

// GitHub Models 使用 OpenAI 相容端點
AIAgent agent = new OpenAIClient(
        new System.ClientModel.ApiKeyCredential(githubToken),
        new OpenAIClientOptions
        {
            Endpoint = new Uri("https://models.inference.ai.azure.com")
        })
    .GetChatClient(model)
    .AsAIChatClient()
    .AsAIAgent(
        name: "GitHubAgent",
        instructions: "你是一個有幫助的助理");

Console.WriteLine(await agent.RunAsync("GitHub Actions 怎麼設定？"));
```

**取得 GitHub Token**：GitHub → Settings → Developer settings → Personal access tokens（選擇 `models:read` 權限）

---

## 6. Ollama（本機 / 私有部署）

Ollama 讓你在本機執行開源模型，資料完全不外流，適合高度隱私要求的場景：

```bash
# 安裝 Ollama（macOS/Linux）
brew install ollama
# 或參考 https://ollama.ai

# 下載模型
ollama pull llama3.2
ollama pull phi4-mini

# .NET 套件
dotnet add package OllamaSharp
dotnet add package Microsoft.Agents.AI
```

```csharp
using Microsoft.Agents.AI;
using OllamaSharp;

var endpoint = Environment.GetEnvironmentVariable("OLLAMA_ENDPOINT")
    ?? "http://localhost:11434";
var modelName = Environment.GetEnvironmentVariable("OLLAMA_MODEL_NAME")
    ?? "llama3.2";

AIAgent agent = new OllamaApiClient(
        new Uri(endpoint),
        modelName)
    .AsAIAgent(
        name: "LocalAgent",
        instructions: "你是一個本地部署的助理");

// 完全離線執行
Console.WriteLine(await agent.RunAsync("說個笑話"));
```

> **注意**：Ollama 的工具呼叫支援取決於所使用的模型。`llama3.2`、`qwen2.5` 等支援 function calling；部分模型不支援，使用前請確認。

---

## 7. Google Gemini（多模態）

```bash
dotnet add package Microsoft.Extensions.AI.Google
dotnet add package Microsoft.Agents.AI
```

```csharp
using Google.Cloud.AIPlatform.V1;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

var apiKey = Environment.GetEnvironmentVariable("GOOGLE_API_KEY")!;
var model = "gemini-2.0-flash";

// 使用 Google AI 的 IChatClient 擴充方法
IChatClient chatClient = new GoogleAIClient(apiKey)
    .AsIChatClient(model);

AIAgent agent = chatClient.AsAIAgent(
    name: "GeminiAgent",
    instructions: "你是一個多模態助理，可以分析文字與圖片");
```

---

## 在 ASP.NET Core 中注入多個提供者

在 Web API 中，可以透過 DI 依設定決定使用哪個提供者：

```csharp
// Program.cs
var builder = WebApplication.CreateBuilder(args);
var config = builder.Configuration;

// 依設定選擇提供者
IChatClient chatClient = config["LLMProvider"] switch
{
    "AzureFoundry" => new AIProjectClient(
            new Uri(config["AzureOpenAI:Endpoint"]!),
            new DefaultAzureCredential())
        .GetProjectOpenAIClient()
        .GetProjectResponsesClient()
        .AsIChatClient(config["AzureOpenAI:Deployment"]!),

    "OpenAI" => new OpenAIClient(config["OpenAI:ApiKey"]!)
        .GetChatClient(config["OpenAI:Model"] ?? "gpt-4o-mini")
        .AsAIChatClient(),

    "Ollama" => new OllamaApiClient(
            new Uri(config["Ollama:Endpoint"] ?? "http://localhost:11434"),
            config["Ollama:Model"] ?? "llama3.2"),

    _ => throw new InvalidOperationException($"Unknown provider: {config["LLMProvider"]}")
};

builder.Services.AddSingleton(chatClient);
builder.AddAIAgent("main-agent",
    instructions: "你是企業助理",
    chatClientServiceKey: null); // 使用預設 singleton
```

**appsettings.json**：

```json
{
  "LLMProvider": "AzureFoundry",
  "AzureOpenAI": {
    "Endpoint": "https://your-resource.openai.azure.com/",
    "Deployment": "gpt-4o-mini"
  }
}
```

---

## 提供者選擇決策樹

```text
是否在 Azure 環境中？
├─ 是 → 需要 Foundry 的 Hosted Tools / Persistent Storage？
│        ├─ 是 → Azure AI Foundry（AIProjectClient）
│        └─ 否 → Azure OpenAI（AzureOpenAIClient）
└─ 否 → 需要完全離線 / 資料不外流？
         ├─ 是 → Ollama（本機模型）
         └─ 否 → 只是評估 / 學習？
                  ├─ 是 → GitHub Models（免費）
                  └─ 否 → 需要超長上下文 / 強推理？
                           ├─ 是 → Anthropic Claude
                           └─ 否 → OpenAI（直接 API）
```

---

> **返回目錄**：[README](README.md) | **上一章**：[16 — Human-in-the-Loop](./16-human-in-the-loop.md) | **下一章**：[18 — Workflows 基礎](./18-workflows-basics.md)
