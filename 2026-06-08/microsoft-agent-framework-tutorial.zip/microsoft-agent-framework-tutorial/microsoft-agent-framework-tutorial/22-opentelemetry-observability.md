# 22 — OpenTelemetry 可觀測性

> 本章說明如何將 Agent Framework 接入 OpenTelemetry 生態系，讓代理與 Workflow 的每一個呼叫、工具執行、串流回應都在追蹤（Traces）、指標（Metrics）、日誌（Logs）三個維度上可見。無論後端是 .NET Aspire Dashboard、Azure Application Insights，還是任何 OTLP 相容的收集器，接入方式完全相同。

---

## 為什麼生產環境需要可觀測性

部署到生產之後，你需要回答這些問題：

- 這個代理平均花多長時間回應？
- 哪一次工具呼叫讓延遲暴增？
- 某個使用者的錯誤，到底是 LLM 回傳了什麼？
- 上週的 p99 延遲和上個月相比有沒有退化？

OpenTelemetry 是雲端原生可觀測性的事實標準，Agent Framework 對 Traces 有原生支援，並提供 `WithOpenTelemetry()` 擴充方法快速接入。

---

## 可觀測性的三個支柱

| 支柱 | 說明 | Agent Framework 對應 |
|------|------|----------------------|
| **Traces（分散式追蹤）** | 記錄每個請求的完整呼叫鏈，從 HTTP 入口到 LLM 呼叫 | `AddSource("Microsoft.Agents.AI.*")` |
| **Metrics（指標）** | 計數、直方圖、Gauge 等可聚合的數值 | 自訂 `Meter`、`Counter`、`Histogram` |
| **Logs（結構化日誌）** | 附有 TraceId/SpanId 的結構化事件 | `ILogger` + OTLP Log Exporter |

---

## 代理的 OpenTelemetry 整合

### 1. 安裝套件

```bash
dotnet add package OpenTelemetry
dotnet add package OpenTelemetry.Extensions.Hosting
dotnet add package OpenTelemetry.Instrumentation.Http
dotnet add package OpenTelemetry.Instrumentation.Runtime
dotnet add package OpenTelemetry.Exporter.OpenTelemetryProtocol

# 若使用 Azure Application Insights
dotnet add package Azure.Monitor.OpenTelemetry.Exporter
```

### 2. 設定 TracerProvider

```csharp
using System.Diagnostics;
using OpenTelemetry;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

const string SourceName = "MyAgent.App";
const string ServiceName = "AgentService";

var otlpEndpoint = Environment.GetEnvironmentVariable("OTEL_EXPORTER_OTLP_ENDPOINT")
    ?? "http://localhost:4317";  // Aspire Dashboard 預設 OTLP 端點

var tracerProviderBuilder = Sdk.CreateTracerProviderBuilder()
    .SetResourceBuilder(ResourceBuilder.CreateDefault()
        .AddService(ServiceName, serviceVersion: "1.0.0")
        .AddAttributes(new Dictionary<string, object>
        {
            ["deployment.environment"] = "production",
            ["service.instance.id"]    = Environment.MachineName,
        }))
    // 你的應用程式自訂 Source
    .AddSource(SourceName)
    // ⬇ Agent Framework 內建 Instrumentation（代理、工具、Workflow 全涵蓋）
    .AddAgentFrameworkInstrumentation()
    // 自動擷取 HttpClient 呼叫（包含送往 LLM 的 HTTP 請求）
    .AddHttpClientInstrumentation()
    // 輸出到 OTLP（Aspire Dashboard / Jaeger / Tempo 等）
    .AddOtlpExporter(o => o.Endpoint = new Uri(otlpEndpoint));

// 可同時輸出到 Azure Application Insights
var appInsightsConnStr = Environment.GetEnvironmentVariable("APPLICATIONINSIGHTS_CONNECTION_STRING");
if (!string.IsNullOrWhiteSpace(appInsightsConnStr))
{
    tracerProviderBuilder.AddAzureMonitorTraceExporter(
        o => o.ConnectionString = appInsightsConnStr);
}

using var tracerProvider = tracerProviderBuilder.Build();
```

### 3. 代理啟用 OpenTelemetry（AsBuilder 模式）

```csharp
using System.Diagnostics;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

using var activitySource = new ActivitySource(SourceName);

// ── 建構 IChatClient ─────────────────────────────────────────────
// v1.6.1+：代理層的 .UseOpenTelemetry() 會自動將 ChatClient 包裝為
// OpenTelemetryChatClient，無需在 ChatClient 層手動加入（否則造成雙重儀器化）。
using var chatClient = new AzureOpenAIClient(
        new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsIChatClient()
    .AsBuilder()
    .UseFunctionInvocation()
    .Build();

// ── 建構代理本身，加入 OTel 追蹤（自動涵蓋 ChatClient 層）──────────
var agent = new ChatClientAgent(
        chatClient,
        name:         "TelemetryAgent",
        instructions: "你是一個具有可觀測性的助理。",
        tools:        [AIFunctionFactory.Create(GetWeatherAsync)])
    .AsBuilder()
    .UseOpenTelemetry(
        sourceName: SourceName,
        configure: cfg => cfg.EnableSensitiveData = true)
    .Build();
```

> **`EnableSensitiveData = true`**：會將使用者訊息與代理回應的完整文字記錄到 Span Attribute 中。生產環境請評估個資法（GDPR / 個人資料保護法）合規性後再決定是否開啟。

---

## 自訂指標與追蹤

除了框架內建的追蹤，通常還需要業務層級的自訂指標，例如：對話次數、回應時間直方圖。

```csharp
using System.Diagnostics.Metrics;

using var meter = new Meter(SourceName);

// 計數器：代理互動總次數（含狀態標籤）
var interactionCounter = meter.CreateCounter<int>(
    name:        "agent_interactions_total",
    description: "代理互動總次數");

// 直方圖：回應時間（秒）
var responseTimeHistogram = meter.CreateHistogram<double>(
    name:        "agent_response_time_seconds",
    unit:        "s",
    description: "代理回應時間（秒）");

// ── MeterProvider 設定 ─────────────────────────────────────────
using var meterProvider = Sdk.CreateMeterProviderBuilder()
    .SetResourceBuilder(ResourceBuilder.CreateDefault().AddService(ServiceName))
    .AddMeter(SourceName)
    .AddHttpClientInstrumentation()
    .AddRuntimeInstrumentation()       // GC、執行緒池指標
    .AddOtlpExporter(o => o.Endpoint = new Uri(otlpEndpoint))
    .Build();
```

### 在呼叫代理時記錄指標

```csharp
using var sessionActivity = activitySource.StartActivity("AgentSession");
sessionActivity?.SetTag("agent.name", "TelemetryAgent");

var stopwatch = System.Diagnostics.Stopwatch.StartNew();
try
{
    await foreach (var update in agent.RunStreamingAsync(userInput, session))
        Console.Write(update.Text);

    stopwatch.Stop();

    interactionCounter.Add(1,
        new KeyValuePair<string, object?>("status", "success"),
        new KeyValuePair<string, object?>("agent", "TelemetryAgent"));

    responseTimeHistogram.Record(stopwatch.Elapsed.TotalSeconds,
        new KeyValuePair<string, object?>("status", "success"));
}
catch (Exception ex)
{
    stopwatch.Stop();
    interactionCounter.Add(1,
        new KeyValuePair<string, object?>("status", "error"));
    responseTimeHistogram.Record(stopwatch.Elapsed.TotalSeconds,
        new KeyValuePair<string, object?>("status", "error"));

    sessionActivity?
        .SetStatus(ActivityStatusCode.Error, ex.Message)
        .SetTag("error.message", ex.Message);
}
```

---

## 結構化日誌（OTel Logs）

日誌與 Trace 關聯的關鍵是將同一個 `TraceId` 附加在日誌事件上。`ILogger` + OTLP Log Exporter 可以自動做到這一點：

```csharp
using Microsoft.Extensions.Logging;
using OpenTelemetry.Logs;

var services = new ServiceCollection();
services.AddLogging(logging => logging
    .SetMinimumLevel(LogLevel.Debug)
    .AddOpenTelemetry(otel =>
    {
        otel.SetResourceBuilder(
            ResourceBuilder.CreateDefault().AddService(ServiceName));
        otel.AddOtlpExporter(o => o.Endpoint = new Uri(otlpEndpoint));
        otel.IncludeScopes = true;
        otel.IncludeFormattedMessage = true;
    }));

var sp     = services.BuildServiceProvider();
var logger = sp.GetRequiredService<ILogger<Program>>();

// 在 Activity 啟動後的日誌會自動攜帶 TraceId
using var activity = activitySource.StartActivity("ProcessRequest");
logger.LogInformation("代理開始處理請求，TraceId: {TraceId}",
    Activity.Current?.TraceId);
```

---

## Workflow 的 OpenTelemetry 整合

Workflow 透過 `WorkflowBuilder.WithOpenTelemetry()` 接入 OTel，每個 Executor 的執行都會成為獨立的 Span：

```csharp
using Microsoft.Agents.AI.Workflows;

using var activitySource = new ActivitySource(SourceName);

// 建立 root Span（涵蓋整個 Workflow 執行）
using var activity = activitySource.StartActivity("WorkflowExecution");
Console.WriteLine($"Trace ID: {Activity.Current?.TraceId}");

var workflow = new WorkflowBuilder(uppercaseExecutor)
    .AddEdge(uppercaseExecutor, reverseExecutor)
    .WithOpenTelemetry(
        configure: cfg => cfg.EnableSensitiveData = true,
        activitySource: activitySource)  // 使用同一個 ActivitySource，Span 會掛在同一棵 Trace 樹下
    .Build();

await using Run run = await InProcessExecution.RunAsync(workflow, "Hello, World!");
foreach (WorkflowEvent evt in run.NewEvents)
{
    if (evt is ExecutorCompletedEvent e)
        Console.WriteLine($"{e.ExecutorId}: {e.Data}");
}
```

### 把框架 Instrumentation 加入 TracerProvider

建議使用 `AddAgentFrameworkInstrumentation()` 取代手動 `AddSource`，它會自動涵蓋代理、工具、Workflow 的全部內建 Source：

```csharp
.AddSource(SourceName)              // 你的自訂 Source
.AddAgentFrameworkInstrumentation() // 框架全部內建 Source（代理 + 工具 + Workflow）
```

若在 `WithOpenTelemetry()` 傳入了自訂 `activitySource`，框架 Span 也會使用你傳入的 Source 名稱，兩者都加入即可。

---

## ASP.NET Core 整合（生產模式）

生產用的 ASP.NET Core WebAPI 通常透過 `builder.Services.AddOpenTelemetry()` 統一設定：

```csharp
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using OpenTelemetry.Metrics;
using OpenTelemetry.Logs;

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddOpenTelemetry()
    .ConfigureResource(r => r.AddService("AgentWebApi", serviceVersion: "1.0.0"))
    .WithTracing(tracing => tracing
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddAgentFrameworkInstrumentation()  // ← 自動涵蓋代理、工具、Workflow
        .AddSource("MyAgent.App")
        .AddOtlpExporter())
    .WithMetrics(metrics => metrics
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddRuntimeInstrumentation()
        .AddAgentFrameworkInstrumentation()  // ← 代理指標（呼叫次數、延遲等）
        .AddMeter("MyAgent.App")
        .AddOtlpExporter())
    .WithLogging(logs => logs
        .AddOtlpExporter());

var app = builder.Build();
```

---

## 視覺化工具比較

| 工具 | 使用場景 | 設定難度 |
|------|----------|----------|
| **.NET Aspire Dashboard** | 本機開發、快速診斷 | ⭐ 最簡單（Docker 一行啟動） |
| **Azure Application Insights** | Azure 生產環境、與 Azure Monitor 整合 | ⭐⭐ 需要 Azure 訂閱 |
| **Jaeger / Grafana Tempo** | 自架、開源 | ⭐⭐⭐ 需要 infra 設定 |

### 快速啟動 Aspire Dashboard

```bash
docker run -d \
    --name aspire-dashboard \
    -p 18888:18888 \
    -p 4317:18889 \
    mcr.microsoft.com/dotnet/aspire-dashboard:latest

# 開啟儀表板
# http://localhost:18888
```

將 `OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317` 加入你的環境變數，代理的 Trace 就會自動出現在儀表板。

---

## NuGet 套件整理

```bash
# 核心
dotnet add package OpenTelemetry
dotnet add package OpenTelemetry.Extensions.Hosting

# 工具化
dotnet add package OpenTelemetry.Instrumentation.AspNetCore
dotnet add package OpenTelemetry.Instrumentation.Http
dotnet add package OpenTelemetry.Instrumentation.Runtime

# 輸出端
dotnet add package OpenTelemetry.Exporter.OpenTelemetryProtocol    # OTLP (Aspire/Jaeger/Tempo)
dotnet add package Azure.Monitor.OpenTelemetry.Exporter            # Application Insights
```

---

## v1.2.0：DevUI 與 .NET Aspire 整合

> 🆕 **v1.2.0 新增**（[PR #3771](https://github.com/microsoft/agent-framework/pull/3771)）：DevUI 現在原生整合 .NET Aspire Dashboard。在 Aspire 應用程式中啟動代理服務時，DevUI 的追蹤資料（Spans、Metrics）會自動出現在 Aspire Dashboard 中，無需額外設定 OTLP 端點。
>
> 搭配 `AddAgentFrameworkInstrumentation()` 與 Aspire 的 OTLP 整合，可在一個介面中同時查看代理執行追蹤、工具呼叫時間線、以及應用程式整體健康狀態。
>
> 官方範例：`Agent-Framework-Samples/08.EvaluationAndTracing` — DevUI visualization 完整實作。

---

### 延伸閱讀：官方 ADR 參考

- [ADR 0003 — Agent OpenTelemetry Instrumentation](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0003-agent-opentelemetry-instrumentation.md)：`OpenTelemetryAgent` wrapper 模式設計，`.WithOpenTelemetry()` 擴充方法，Span/Metrics/Error 遙測屬性定義

---

> **返回目錄**：[README](README.md) | **上一章**：[21 — Durable Agents 實作](./21-durable-agents-implementation.md) | **下一章**：[23 — A2A Protocol](./23-a2a-protocol.md)
