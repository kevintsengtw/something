# 20 — Durable Agents 概念與架構

> 本章介紹 Durable Agents（持久性代理）的核心概念。你將了解它與普通代理的本質差異、底層的 Durable Task Framework 架構、以及它如何解決生產環境中代理狀態管理的痛點。

---

## 普通代理的問題

在前面幾章的範例中，我們建立的代理都是**記憶體內（In-Memory）代理**：

```csharp
// 普通代理：狀態存在記憶體中
AIAgent agent = chatClient.AsAIAgent(
    name: "Assistant",
    instructions: "你是助理");

var session = await agent.CreateSessionAsync();   // ← 對話歷史存在記憶體中
await agent.RunAsync("你好！", session);
await agent.RunAsync("你記得我嗎？", session); // 同一個 session，所以「記得」
```

這種方式有以下問題：

**程序重啟後狀態消失**：一旦應用程式重啟（部署新版、崩潰恢復），所有進行中的對話都會遺失。使用者必須重新開始。

**無法橫向擴展**：同一個使用者的對話必須由同一個程序實例處理，因為狀態在記憶體中。這讓負載均衡和彈性伸縮變得複雜。

**長時間任務不可靠**：如果代理需要等待外部確認（Human-in-the-Loop）幾個小時，整個程序必須保持運行。任何中斷都會讓任務消失。

**缺乏可觀測性**：無法從外部查看代理的當前對話歷史、正在等待什麼，或任務進行到哪一步。

---

## Durable Agents 的解法

Durable Agents 將代理的**對話狀態持久化到外部儲存**（如 Azure Table Storage 或 SQL），讓代理在任何時間點都可以被可靠地恢復：

```text
普通代理                    Durable Agents
─────────────────────────────────────────────────
記憶體 AgentSession    →    外部持久化 DurableAgentState
單一程序             →    任意工作節點（Worker）可接手
程序重啟後遺失       →    自動從儲存恢復
無法橫向擴展         →    多個 Worker 並行運作
不可觀測             →    Durable Task Scheduler Dashboard
```

---

## 底層架構：Durable Entities + Durable Task Framework

Durable Agents 建立在 **Microsoft Durable Task Framework**（DTF）之上，核心模型是 **Durable Entity（虛擬 Actor）**：

```text
使用者請求
    ↓
HTTP 端點（Azure Functions / 自訂 Host）
    ↓
Durable Task Scheduler（任務調度器）
    ↓
Entity Instance（以 AgentName + SessionKey 識別）
    ↓
從外部儲存載入 DurableAgentState（含完整對話歷史）
    ↓
AIAgent.RunAsync()（完整上下文）
    ↓
結果追加到狀態，自動持久化
```

### 關鍵概念

**AgentSession**：一個持久化的對話會話，由 `AgentName`（不區分大小寫）+ `SessionKey`（通常是 GUID，區分大小寫）唯一識別。

**DurableAgentState**：儲存在外部的代理狀態，包含完整的對話歷史（`ChatMessage` 列表）和自訂屬性。

**Durable Task Scheduler（DTS）**：任務調度引擎，負責路由訊息、維護 Entity 生命週期、處理重試邏輯。本地開發使用 DTS Emulator（Docker 映像）。

---

## 兩種 Hosting 模式

### 模式一：Azure Functions（推薦用於生產環境）

框架自動產生 HTTP 端點，適合無伺服器（Serverless）部署：

```text
POST /api/agents/{AgentName}/run
→ 建立或加入會話，回傳代理回應

GET  /api/agents/{AgentName}/sessions/{sessionId}
→ 查詢會話狀態
```

**特點**：
- 無需管理 Worker 程序
- 自動擴縮容
- 內建失敗重試
- `timeToLive` 參數管理 Session 生命週期

**使用場景**：REST API 後端、需要高可用性的生產服務、對話歷史需要跨重啟保留。

### 模式二：Console / Generic Host（靈活部署）

使用 .NET 的 `IHost` 建構器，適合需要更細緻控制的場景：

```csharp
// 手動設定 Worker 和 Client
services.ConfigureDurableAgents(
    options => options.AddAIAgent(agent),
    workerBuilder: builder => builder.UseDurableTaskScheduler(connectionString),
    clientBuilder: builder => builder.UseDurableTaskScheduler(connectionString));
```

**特點**：
- 可整合到任何 .NET Host（ASP.NET Core、Worker Service 等）
- 支援自訂 Durable Task 後端（本地模擬器、Azure DTS）
- 可與 Durable Orchestration 深度整合（詳見第 21 章）

**使用場景**：後台批次任務、需要自訂 Orchestration 邏輯、非 HTTP 觸發的工作流程。

---

## Session TTL（生命週期管理）

每個代理 Session 都有一個 **Time-To-Live（TTL）**，控制空閒 Session 的自動刪除時機。這避免舊對話永遠佔用儲存空間。

### 預設值

| 設定 | 預設值 |
|------|--------|
| 全域預設 TTL | 14 天 |
| 最短刪除延遲 | 5 分鐘 |
| 刪除方式 | 基於最後互動時間（掛鐘時間） |

### TTL 運作邏輯

```text
訊息到達
    ↓
重置 Session 的到期時間 = Now + TTL
    ↓
排程到期檢查（在到期時間執行）
    ↓
檢查時：
    ├─ 已過期 → 刪除所有狀態（對話歷史、自訂資料）
    └─ 尚未到期（有新互動）→ 重新排程下次檢查
```

### TTL 設定範例

```csharp
// Azure Functions 版本
FunctionsApplication
    .CreateBuilder(args)
    .ConfigureFunctionsWebApplication()
    .ConfigureDurableAgents(options =>
    {
        // 設定全域預設 TTL（14 天）
        options.DefaultTimeToLive = TimeSpan.FromDays(14);

        // 短期客服對話（1 小時後自動清除）
        options.AddAIAgent(customerServiceAgent, timeToLive: TimeSpan.FromHours(1));

        // 長期個人助理（30 天）
        options.AddAIAgent(personalAssistantAgent, timeToLive: TimeSpan.FromDays(30));

        // 永久保留（不設 TTL）
        options.AddAIAgent(archiveAgent, timeToLive: null);
    })
    .Build();
```

---

## 與 Workflow 的關係

Durable Agents 和 Workflow 是互補的：

| 面向 | Workflow（第 18-19 章） | Durable Agents（第 20-21 章） |
|------|------------------------|-------------------------------|
| 焦點 | 多代理編排邏輯 | 單一代理的狀態持久化 |
| 狀態儲存 | 記憶體（InProcessExecution） | 外部持久化（Durable Task） |
| 容錯 | Checkpoint 手動恢復 | 自動恢復（Durable Entity） |
| 橫向擴展 | 不適合 | 原生支援 |
| 典型場景 | 批次處理管線 | 長時間對話、生產 API |

兩者也可以**結合使用**：在 Durable Orchestration 中呼叫多個 Durable Agent Session，實現有持久化能力的多代理工作流程（詳見第 21 章）。

---

## 環境準備：Durable Task Scheduler Emulator

本地開發時，使用 Docker 啟動 DTS Emulator：

```bash
# 啟動 DTS 模擬器（背景執行）
docker run -d \
    --name dts-emulator \
    -p 8080:8080 \
    -p 8082:8082 \
    mcr.microsoft.com/dts/dts-emulator:latest

# 連線字串（本機開發預設值）
# Endpoint=http://localhost:8080;TaskHub=default;Authentication=None

# 管理儀表板：http://localhost:8082
```

DTS Dashboard（`http://localhost:8082`）提供：
- Entity 列表（每個 Session 的狀態）
- Orchestration 執行歷史
- 效能指標

---

## NuGet 套件

| 套件 | 用途 |
|------|------|
| `Microsoft.Agents.AI.DurableTask` | Durable Agents 核心型別（Console / Generic Host 使用） |
| `Microsoft.Agents.AI.Hosting.AzureFunctions` | Azure Functions 整合（自動產生 HTTP 端點） |
| `Microsoft.DurableTask.Client.AzureManaged` | DTS Client（排程 Orchestration） |
| `Microsoft.DurableTask.Worker.AzureManaged` | DTS Worker（執行 Orchestration）|

```bash
# Console / Generic Host 模式
dotnet add package Microsoft.Agents.AI.DurableTask
dotnet add package Microsoft.DurableTask.Client.AzureManaged
dotnet add package Microsoft.DurableTask.Worker.AzureManaged

# Azure Functions 模式
dotnet add package Microsoft.Agents.AI.Hosting.AzureFunctions
```

---

> **返回目錄**：[README](README.md) | **上一章**：[19 — Workflows 進階](./19-workflows-advanced.md) | **下一章**：[21 — Durable Agents 實作](./21-durable-agents-implementation.md)
