# 附錄 B — 從 Semantic Kernel / AutoGen 遷移

> 如果你之前使用過 Semantic Kernel 或 AutoGen，本附錄幫助你理解 Microsoft Agent Framework 與它們的關係，以及如何將現有知識對應到新框架。

---

## 框架演進關係

```mermaid
flowchart LR
    SK["Semantic Kernel\n（2023）"] --> AF["Microsoft Agent Framework\n（2025-2026）"]
    AG["AutoGen\n（2023）"] --> AF

    style SK fill:#E8F0FE,stroke:#4A90D9,color:#333
    style AG fill:#FFF3CD,stroke:#FFC107,color:#333
    style AF fill:#D4EDDA,stroke:#28A745,color:#333
```

Microsoft Agent Framework 是 Semantic Kernel 與 AutoGen 的**整合繼承者**：

- **Semantic Kernel** 的核心貢獻：Plugin 架構、Prompt 管理、Kernel 抽象
- **AutoGen** 的核心貢獻：多代理協作、對話模式、工作流程編排
- **Agent Framework** 的定位：統一的代理開發框架，整合兩者的優勢

---

## 概念對應表

### Semantic Kernel → Agent Framework

| Semantic Kernel | Agent Framework | 說明 |
|----------------|-----------------|------|
| `Kernel` | `IChatClient` | LLM 互動的核心抽象 |
| `KernelFunction` | `AIFunction` / `AIFunctionFactory` | 可被代理呼叫的函式 |
| `KernelPlugin` | Tools（工具集合） | 一組相關的函式 |
| `ChatCompletionService` | `IChatClient` | 聊天完成服務 |
| `KernelArguments` | `ChatOptions` | 執行時的選項與參數 |
| `ChatHistory` | `AgentSession` | 對話歷史管理 |
| Semantic Kernel Agent | `AIAgent` | 代理抽象 |
| `InvokeAsync()` | `RunAsync()` / `RunStreamingAsync()` | 執行代理 |
| Filter / Middleware | Middleware（三層） | 攔截與擴展管線 |

### AutoGen → Agent Framework

| AutoGen | Agent Framework | 說明 |
|---------|-----------------|------|
| `AssistantAgent` | `AIAgent`（透過 `AsAIAgent()`） | AI 代理 |
| `UserProxyAgent` | 無直接對應（手動管理使用者輸入） | 使用者代理 |
| `GroupChat` | `WorkflowBuilder` + Group Chat 模式 | 多代理群聊 |
| `ConversableAgent` | `AIAgent` | 可對話的代理 |
| `initiate_chat()` | `RunAsync()` | 開始對話 |
| Agent Runtime | `InProcessExecution` | 代理執行環境 |
| Message Protocol | `WorkflowEvent` | 訊息與事件 |

---

## 程式碼對照

### 建立代理

**Semantic Kernel：**

```csharp
var kernel = Kernel.CreateBuilder()
    .AddOpenAIChatCompletion("gpt-4o", apiKey)
    .Build();

var agent = new ChatCompletionAgent
{
    Kernel = kernel,
    Instructions = "你是一位助理",
    Name = "Assistant"
};
```

**Agent Framework：**

```csharp
IChatClient chatClient = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o").AsIChatClient();

var agent = chatClient.AsAIAgent("你是一位助理");
```

### 註冊工具

**Semantic Kernel：**

```csharp
var kernel = Kernel.CreateBuilder()
    .AddOpenAIChatCompletion("gpt-4o", apiKey)
    .Build();

kernel.Plugins.AddFromType<WeatherPlugin>();
// 或
kernel.Plugins.AddFromFunctions("Weather", [
    KernelFunctionFactory.CreateFromMethod(GetWeather, "GetWeather")
]);
```

**Agent Framework：**

```csharp
var weatherTool = AIFunctionFactory.Create(
    GetWeather, "GetWeather", "取得天氣資訊");

var agent = chatClient.AsAIAgent(new AIAgentOptions
{
    Instructions = "你是一位助理",
    Tools = [weatherTool]
});
```

### 多輪對話

**Semantic Kernel：**

```csharp
var history = new ChatHistory();
history.AddUserMessage("你好");
var result = await chatService.GetChatMessageContentAsync(history);
history.AddAssistantMessage(result.Content);
```

**Agent Framework：**

```csharp
var session = await agent.CreateSessionAsync();
var response = await agent.RunAsync(session, "你好");
// AgentSession 自動管理對話歷史
```

---

## 遷移建議

1. **漸進遷移**：Semantic Kernel 仍然被維護，不需要急著全面遷移。可以在新專案中使用 Agent Framework，舊專案維持現狀

2. **概念可轉移**：如果你熟悉 Semantic Kernel 的 Plugin 概念，對應到 Agent Framework 的 Tools 會很自然。核心差異在於 Agent Framework 更加**以代理為中心**而非以 Kernel 為中心

3. **工作流程升級**：如果你在 AutoGen 中使用了多代理對話，Agent Framework 的 `WorkflowBuilder` 提供了更結構化的方式來定義代理間的協作拓撲

4. **統一的 AI 抽象**：Agent Framework 建構於 `Microsoft.Extensions.AI` 之上，這是 .NET 生態系統中統一的 AI 抽象層，長期來看會有更好的生態支援

---

> **返回目錄**：[README](README.md) | **上一篇**：[附錄 A — NuGet 套件參考表](./appendix-a-nuget-packages.md) | **下一篇**：[附錄 C — 學習資源與社群連結](./appendix-c-resources.md)
