# 04 — 建立你的第一個 Agent

> 本章將帶你從零開始建立第一個 AI 代理，從最簡單的單次對話，到多輪對話、串流回應，逐步體驗 Agent Framework 的核心 API。
>
> 對應官方範例：[Agent-Framework-Samples/00.ForBeginners/BasicAgent](https://github.com/microsoft/Agent-Framework-Samples/tree/main/00.ForBeginners)

---

## 最簡範例：三行建立一個代理

讓我們從最精簡的程式碼開始，只需要三個步驟就能讓一個 AI 代理運作起來：

```csharp
using Microsoft.Agents.AI;
using OpenAI;

// 1. 讀取 API Key
var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY")
    ?? throw new InvalidOperationException("請設定 OPENAI_API_KEY 環境變數");

// 2. 建立代理
var agent = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o-mini")
    .AsAIAgent(
        name: "HaikuBot",
        instructions: "你是一個擅長寫俳句的助理，請用繁體中文回答。"
    );

// 3. 與代理對話
var response = await agent.RunAsync("用『程式設計』為主題寫一首俳句。");
Console.WriteLine(response.Text);
```

執行後你會看到類似的輸出：

```text
鍵盤聲清脆
程式碼如詩行般
世界因此亮
```

---

## 理解 AsAIAgent() 擴充方法

上面範例中的 `AsAIAgent()` 是 Agent Framework 提供的擴充方法，它的作用是**將任何 `IChatClient` 包裝成具有代理行為的 `AIAgent`**。

### 方法簽名

```csharp
public static AIAgent AsAIAgent(
    this IChatClient chatClient,
    string? name = null,
    string? instructions = null,
    IEnumerable<AIFunction>? tools = null
);
```

### 參數說明

| 參數 | 型別 | 說明 |
|------|------|------|
| `chatClient` | `IChatClient` | 底層的聊天客戶端（由 `GetChatClient()` 等方法取得） |
| `name` | `string?` | 代理名稱，用於識別與日誌 |
| `instructions` | `string?` | 系統指令，定義代理的行為與個性 |
| `tools` | `IEnumerable<AIFunction>?` | 代理可使用的工具集合 |

### 等效的寫法

`AsAIAgent()` 其實是 `ChatClientAgent` 的便捷寫法。以下兩種方式是等效的：

```csharp
// 方式 1：使用擴充方法（簡潔）
var agent = chatClient.AsAIAgent(
    name: "HaikuBot",
    instructions: "你是一個擅長寫俳句的助理。"
);

// 方式 2：直接建立 ChatClientAgent（明確）
var agent = new ChatClientAgent(
    chatClient,
    name: "HaikuBot",
    instructions: "你是一個擅長寫俳句的助理。"
);
```

當你需要更精細的控制（例如設定 Middleware）時，直接使用 `ChatClientAgent` 會更合適。

---

## 使用不同的 LLM 提供者

同一個代理可以輕鬆切換不同的 LLM 提供者，只需要更換 `ChatClient` 的建立方式即可。

### OpenAI

```csharp
using OpenAI;

var chatClient = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o-mini");

var agent = chatClient.AsAIAgent(
    name: "MyAgent",
    instructions: "你是一個友善的助理。"
);
```

### Azure OpenAI

```csharp
using Azure.AI.OpenAI;
using Azure.Identity;

var chatClient = new AzureOpenAIClient(
    new Uri(Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!),
    new AzureCliCredential())
    .GetChatClient(Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT")!);

var agent = chatClient.AsAIAgent(
    name: "MyAgent",
    instructions: "你是一個友善的助理。"
);
```

### GitHub Models

```csharp
using OpenAI;

var chatClient = new OpenAIClient(
    new ApiKeyCredential(Environment.GetEnvironmentVariable("GITHUB_TOKEN")!),
    new OpenAIClientOptions
    {
        Endpoint = new Uri("https://models.inference.ai.azure.com")
    })
    .GetChatClient("gpt-4o-mini");

var agent = chatClient.AsAIAgent(
    name: "MyAgent",
    instructions: "你是一個友善的助理。"
);
```

注意到重點了嗎？**代理的建立與使用方式完全相同**，差異只在於 `ChatClient` 的建立。這就是 `IChatClient` 抽象的威力。

---

## 多輪對話：使用 AgentSession

到目前為止，每次呼叫 `RunAsync` 都是一次獨立的對話。如果你希望代理能**記住先前的對話內容**，就需要使用 `AgentSession`。

> **注意**：`CreateSessionAsync()` 是非同步方法，回傳 `Task<AgentSession>`。

### 沒有 AgentSession 的情況

```csharp
// 每次對話都是獨立的，代理不會記住上下文
var r1 = await agent.RunAsync("我叫小明。");
Console.WriteLine(r1.Text);
// 輸出：你好小明！有什麼我可以幫你的嗎？

var r2 = await agent.RunAsync("我叫什麼名字？");
Console.WriteLine(r2.Text);
// 輸出：抱歉，我不知道你的名字，你可以告訴我嗎？ ← 忘記了！
```

### 有 AgentSession 的情況

```csharp
// 建立對話 Session
var session = await agent.CreateSessionAsync();

// 第一輪
var r1 = await agent.RunAsync("我叫小明。", session);
Console.WriteLine(r1.Text);
// 輸出：你好小明！有什麼我可以幫你的嗎？

// 第二輪 — 代理記得你是小明
var r2 = await agent.RunAsync("我叫什麼名字？", session);
Console.WriteLine(r2.Text);
// 輸出：你叫小明啊！ ← 記住了！
```

### 完整的多輪對話範例

以下是一個互動式對話迴圈的實作：

```csharp
using Microsoft.Agents.AI;
using OpenAI;

var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY")
    ?? throw new InvalidOperationException("請設定 OPENAI_API_KEY 環境變數");

var agent = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o-mini")
    .AsAIAgent(
        name: "ChatBot",
        instructions: """
            你是一個友善的繁體中文對話助理。
            請記住使用者告訴你的資訊，並在後續對話中使用。
            回答盡量簡潔明瞭。
            """
    );

// 建立對話 Session
var session = await agent.CreateSessionAsync();

Console.WriteLine("=== 多輪對話範例 ===");
Console.WriteLine("輸入 'exit' 結束對話\n");

while (true)
{
    Console.Write("你：");
    var input = Console.ReadLine();

    if (string.IsNullOrWhiteSpace(input) || input.Equals("exit", StringComparison.OrdinalIgnoreCase))
        break;

    // 使用同一個 session 保持對話上下文
    var response = await agent.RunAsync(input, session);
    Console.WriteLine($"代理：{response.Text}\n");
}

Console.WriteLine("對話結束。");
```

---

## 串流回應：即時顯示生成過程

在實際應用中，等待 LLM 生成完整回應再顯示並不是好的使用者體驗。`RunStreamingAsync` 讓你可以**逐段接收**代理的回應。

### 基本串流用法

```csharp
Console.Write("代理：");
await foreach (var update in agent.RunStreamingAsync("講一個關於程式設計師的短故事。"))
{
    Console.Write(update.Text); // 即時輸出每個文字片段
}
Console.WriteLine(); // 最後換行
```

### 串流 + 多輪對話

串流同樣可以搭配 `AgentSession` 使用：

```csharp
var session = await agent.CreateSessionAsync();

// 第一輪對話（串流）
Console.Write("代理：");
await foreach (var update in agent.RunStreamingAsync("介紹一下 C# 語言。", session))
{
    Console.Write(update.Text);
}
Console.WriteLine();

// 第二輪對話（串流）— 代理記得上下文
Console.Write("代理：");
await foreach (var update in agent.RunStreamingAsync("它最新的版本有什麼新功能？", session))
{
    Console.Write(update.Text);
}
Console.WriteLine();
```

### 串流互動式對話迴圈

結合前面所有概念的完整範例：

```csharp
using Microsoft.Agents.AI;
using OpenAI;

var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY")
    ?? throw new InvalidOperationException("請設定 OPENAI_API_KEY 環境變數");

var agent = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o-mini")
    .AsAIAgent(
        name: "StreamBot",
        instructions: "你是一個友善的繁體中文對話助理。回答盡量詳細。"
    );

var session = await agent.CreateSessionAsync();

Console.WriteLine("=== 串流對話範例 ===");
Console.WriteLine("輸入 'exit' 結束對話\n");

while (true)
{
    Console.Write("你：");
    var input = Console.ReadLine();

    if (string.IsNullOrWhiteSpace(input) || input.Equals("exit", StringComparison.OrdinalIgnoreCase))
        break;

    Console.Write("代理：");
    await foreach (var update in agent.RunStreamingAsync(input, session))
    {
        Console.Write(update.Text);
    }
    Console.WriteLine("\n");
}

Console.WriteLine("對話結束。");
```

---

## 設計好的 Instructions

代理的行為很大程度取決於 `instructions` 的撰寫品質。以下是一些撰寫建議：

### 基本原則

- **明確角色定義**：告訴代理它是誰
- **行為規範**：定義它應該怎麼做、不應該怎麼做
- **語言要求**：指定回應語言
- **格式要求**：指定回應的格式與長度

### 範例對比

**模糊的 Instructions：**
```csharp
instructions: "你是一個助理。"
```

**清晰的 Instructions：**
```csharp
instructions: """
    你是一位專業的旅行顧問，專門服務台灣的旅客。

    行為準則：
    - 使用繁體中文回答所有問題
    - 推薦景點時，附上預估費用（以新台幣計）
    - 如果使用者詢問你不確定的資訊，誠實告知而非猜測
    - 回答控制在 200 字以內，除非使用者要求詳細說明

    你擅長的領域：
    - 日本、韓國、東南亞的旅遊規劃
    - 機票與住宿的比價建議
    - 簽證與入境規定
    """
```

### 使用多行字串

C# 的原始字串常值（Raw String Literals，`"""..."""`）很適合撰寫多行 Instructions，不需要處理跳脫字元：

```csharp
var agent = chatClient.AsAIAgent(
    name: "TravelAdvisor",
    instructions: """
        你是一位旅行顧問。
        請用繁體中文回答。
        如果不確定，請誠實告知。
        """
);
```

---

## 查看回應的詳細資訊

除了 `response.Text`，`AgentResponse` 還提供了其他有用的資訊：

```csharp
var response = await agent.RunAsync("你好！", session);

// 回應文字
Console.WriteLine($"回應：{response.Text}");

// 對話訊息數量
Console.WriteLine($"訊息數：{response.Messages.Count}");

// 代理 ID
Console.WriteLine($"代理 ID：{response.AgentId}");

// 回應 ID
Console.WriteLine($"回應 ID：{response.ResponseId}");
```

`Messages` 集合包含了這次對話中的所有訊息（包含使用者訊息和代理回應），對於除錯和日誌記錄很有用。

---

## 完整範例：可切換提供者的對話機器人

以下是一個整合本章所有概念的完整範例，支援切換不同的 LLM 提供者：

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using OpenAI;

// ============================================================
// 設定區 — 根據你的環境選擇一種提供者
// ============================================================

IChatClient chatClient = CreateOpenAIChatClient();
// IChatClient chatClient = CreateAzureOpenAIChatClient();
// IChatClient chatClient = CreateGitHubModelsChatClient();

// ============================================================
// 建立代理
// ============================================================

var agent = chatClient.AsAIAgent(
    name: "MyFirstAgent",
    instructions: """
        你是一個友善的繁體中文對話助理。
        你擅長回答技術問題，特別是 C# 和 .NET 相關的主題。
        回答時盡量附上程式碼範例。
        """
);

var session = await agent.CreateSessionAsync();

// ============================================================
// 互動式對話迴圈（串流模式）
// ============================================================

Console.WriteLine("=== My First Agent ===");
Console.WriteLine($"代理名稱：{agent.Name}");
Console.WriteLine("輸入 'exit' 結束對話\n");

while (true)
{
    Console.Write("你：");
    var input = Console.ReadLine();

    if (string.IsNullOrWhiteSpace(input) || input.Equals("exit", StringComparison.OrdinalIgnoreCase))
        break;

    Console.Write("代理：");
    await foreach (var update in agent.RunStreamingAsync(input, session))
    {
        Console.Write(update.Text);
    }
    Console.WriteLine("\n");
}

Console.WriteLine("對話結束，感謝使用！");

// ============================================================
// 提供者工廠方法
// ============================================================

static IChatClient CreateOpenAIChatClient()
{
    var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY")
        ?? throw new InvalidOperationException("請設定 OPENAI_API_KEY 環境變數");

    return new OpenAIClient(apiKey)
        .GetChatClient("gpt-4o-mini");
}

static IChatClient CreateAzureOpenAIChatClient()
{
    var endpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")
        ?? throw new InvalidOperationException("請設定 AZURE_OPENAI_ENDPOINT 環境變數");
    var deployment = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT")
        ?? throw new InvalidOperationException("請設定 AZURE_OPENAI_DEPLOYMENT 環境變數");

    return new Azure.AI.OpenAI.AzureOpenAIClient(
        new Uri(endpoint),
        new Azure.Identity.AzureCliCredential())
        .GetChatClient(deployment);
}

static IChatClient CreateGitHubModelsChatClient()
{
    var token = Environment.GetEnvironmentVariable("GITHUB_TOKEN")
        ?? throw new InvalidOperationException("請設定 GITHUB_TOKEN 環境變數");

    return new OpenAIClient(
        new ApiKeyCredential(token),
        new OpenAIClientOptions
        {
            Endpoint = new Uri("https://models.inference.ai.azure.com")
        })
        .GetChatClient("gpt-4o-mini");
}
```

### 執行方式

```bash
# 設定環境變數（選擇一種）
$env:OPENAI_API_KEY = "sk-xxxxxxxx"

# 執行
dotnet run
```

---

## 小結

本章你學會了：

- 使用 `AsAIAgent()` 快速建立一個 AI 代理
- 使用 `RunAsync` 與代理進行單次對話
- 使用 `AgentSession`（`CreateSessionAsync`）實現多輪對話（保持上下文）
- 使用 `RunStreamingAsync` 實現串流回應
- 切換不同的 LLM 提供者（OpenAI / Azure OpenAI / GitHub Models）
- 撰寫有效的 Instructions

下一章我們將賦予代理「做事」的能力 — 學習如何定義與使用工具（Tools）。

---

### 延伸閱讀：官方 ADR 參考

- [ADR 0001 — Agent Run Response](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0001-agent-run-response.md)：`RunAsync` 回傳 `AgentResponse`、`RunStreamingAsync` 回傳 `IAsyncEnumerable<AgentResponseUpdate>` 的設計決策與主要/次要內容分離機制

---

> **返回目錄**：[README](README.md) | **上一章**：[03 — 開發環境準備](./03-dev-environment.md) | **下一章**：[05 — 工具（Tools）基礎](./05-tools-basics.md)
