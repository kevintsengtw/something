# 入門篇（01-10 章）vs ADR 文件比對報告

> 比對基準：`agent-framework/docs/decisions/` 中所有 .NET 相關 ADR + GitHub 官方範例程式碼

---

## 🔴 需要修正的重大問題

### 1. `AgentThread` → `AgentSession`（影響：第 02, 04, 06, 07, 08, 09, 10 章）

**問題**：ADR 0018（AgentSession Serialization, Accepted 2026-02-25）將 `AgentThread` 重新設計為 `AgentSession`，且 GitHub 上所有官方範例（DurableAgents、A2A、AgentOpenTelemetry）都使用 `AgentSession`。

**入門篇目前的寫法**：
```csharp
AgentThread thread = agent.GetNewThread();
await agent.RunAsync("Hello", thread);
```

**官方範例的寫法**：
```csharp
AgentSession session = await agent.CreateSessionAsync();
AgentResponse response = await agent.RunAsync(message: "Hello", session: session);
```

**需修正的章節**：02, 04, 06, 07, 08（所有使用 `AgentThread` / `GetNewThread()` 的地方）

---

### 2. LLM 提供者表格過時（影響：第 02 章）

**問題**：第 02 章的提供者表格仍標示「Anthropic Claude — 透過 BaseAgent 實作（RC1+）」、缺少 Ollama、Google Gemini。而 v1.0.0 GA 已有完整的多提供者支援。

**現有表格**：
```text
| Anthropic Claude | — | 透過 BaseAgent 實作（RC1+） |
| GitHub Copilot SDK | — | 透過 BaseAgent 實作（RC1+） |
| AWS Bedrock | — | 支援中 |
| Ollama | — | 本地模型支援 |
```

**應更新為**（參考第 17 章已有的正確內容）：
```text
| Anthropic Claude | AnthropicClient / AnthropicFoundryClient | Claude 模型系列 |
| GitHub Models    | OpenAIClient (替換 Endpoint)             | 免費使用 |
| Ollama           | OllamaApiClient                          | 本地模型 |
| Google Gemini    | GeminiClient                             | Gemini 模型系列 |
```

---

### 3. `AgentResponse` 屬性需驗證（影響：第 02, 04 章）

**問題**：第 02 章表格列出 `AgentId`、`ResponseId`，第 04 章示範存取這些屬性。需確認 v1.0.0 GA 是否仍保留這些屬性，以及是否有新增屬性（如 `ContinuationToken`，參考 ADR 0009）。

**官方範例中看到的屬性**：
- `response.Text` ✅ 確認存在
- `response.ContinuationToken` ✅ A2A 範例中使用
- `response.Result`（泛型版本 `AgentResponse<T>`）✅ Orchestration 範例中使用

---

## 🟡 建議補充的內容

### 4. `AsBuilder()` 模式（影響：第 04, 06 章）

**問題**：ADR 0003（OpenTelemetry）和 ADR 0007（Middleware）定義了 `AsBuilder()` 流暢 API 模式。官方範例中代理建構方式：

```csharp
var agent = new ChatClientAgent(chatClient, name: "Agent", instructions: "...")
    .AsBuilder()
    .UseOpenTelemetry(sourceName: SourceName, configure: cfg => cfg.EnableSensitiveData = true)
    .Build();
```

入門篇第 06 章的 Middleware 教學可考慮補充此模式。

---

### 5. AgentRunContext（影響：第 05, 06 章）

**問題**：ADR 0015（Agent Run Context, Proposed）引入 `AgentRunContext` 類別，讓 Tools 和 Middleware 可以透過 `AIAgent.CurrentRunContext` 存取當前執行上下文：

```csharp
public class AgentRunContext
{
    public AIAgent Agent { get; }
    public AgentSession? Session { get; }
    public IReadOnlyCollection<ChatMessage> RequestMessages { get; }
    public AgentRunOptions? RunOptions { get; }
}
```

入門篇可在第 05 或 06 章提及此存取方式。但注意此 ADR 狀態是 **Proposed**（非 Accepted），需謹慎。

---

### 6. Feature Collections（影響：第 04, 09 章）

**問題**：ADR 0014（Feature Collections, Accepted）引入 `AgentFeatureCollection`，用於 per-run 層級的功能切換。例如結構化輸出可以在 per-run 設定：

```csharp
options.Features = new AgentFeatureCollection()
    .WithFeature<ChatMessageStore>(messageStore);
```

第 09 章（Planning/Structured Output）可補充此模式。

---

### 7. Agent Skills 設計（影響：無現有章節）

**問題**：ADR 0021（Agent Skills, Proposed）定義了 `AgentSkill`、`AgentSkillsSource`、`AgentFileSkillsSource` 等抽象，用於從檔案系統載入代理技能。這是全新功能，入門篇不必涵蓋，但後續進階章節可考慮加入。

---

## 🟢 確認正確的內容

| 入門篇內容 | 對應 ADR | 狀態 |
|-----------|---------|------|
| `AIFunctionFactory.Create()` 工具建立 | ADR 0002 | ✅ 正確 |
| `[Description]` 屬性標記工具與參數 | ADR 0002 | ✅ 正確 |
| 三層 Middleware（Agent / Function / Chat） | ADR 0007 | ✅ 正確 |
| `AsAIAgent()` 擴充方法 | ADR 0011 | ✅ 正確（in-process 場景） |
| `ChatClientAgent` 直接建構 | 官方範例 | ✅ 正確 |
| `RunAsync()` / `RunStreamingAsync()` | ADR 0001 | ✅ 正確 |
| Context Provider 概念 | ADR 0015 | ✅ 正確 |
| WorkflowBuilder + InProcessExecution（第 10 章） | 官方 Workflow 範例 | ✅ 正確 |

---

## 修正優先順序

| 優先級 | 項目 | 影響範圍 |
|--------|------|----------|
| 🔴 P0 | `AgentThread` → `AgentSession` 全面更名 | 02, 04, 06, 07, 08 |
| 🔴 P0 | LLM 提供者表格更新 | 02 |
| 🟡 P1 | `AgentResponse` 屬性驗證與更新 | 02, 04 |
| 🟡 P1 | `AsBuilder()` 模式補充 | 04 或 06 |
| 🟢 P2 | `AgentRunContext` 提及（Proposed 狀態） | 05 或 06 |
| 🟢 P2 | Feature Collections 提及 | 09 |
