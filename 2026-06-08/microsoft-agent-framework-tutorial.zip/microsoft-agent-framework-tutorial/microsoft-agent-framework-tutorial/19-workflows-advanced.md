# 19 — Workflows 進階

> 本章深入介紹 Workflow 的四個進階主題：Shared States（共享狀態）、Fan-Out/Fan-In（扇形展開/匯聚）、Checkpointing（檢查點）、Human-in-the-Loop（人工介入），以及 Declarative Workflow（宣告式工作流程）。掌握這些技術後，你就能設計出生產級別的多代理編排系統。

---

## 1. Shared States：跨執行器共享資料

在分支與匯聚場景中，多個 Executor 需要存取同一份資料（如讀入的檔案內容），但直接傳遞物件有型別不一致的問題。框架提供 **Shared States** 機制，讓 Executor 透過 `IWorkflowContext` 讀寫共享的命名空間資料。

### 核心 API

```csharp
// 寫入共享狀態（非同步佇列更新）
await context.QueueStateUpdateAsync(
    key: "file-001",
    value: fileContent,
    scopeName: "FileContentState",
    cancellationToken);

// 讀取共享狀態
var content = await context.ReadStateAsync<string>(
    key: "file-001",
    scopeName: "FileContentState",
    cancellationToken);
```

### Fan-Out/Fan-In：並行分析後匯聚

以下示範一個典型的並行分析模式：讀取檔案後，同時計算字數與段落數，最後匯聚結果：

```csharp
using Microsoft.Agents.AI.Workflows;

// ── 共享狀態命名空間 ──────────────────────────────────────────────
static class StateScopes
{
    public const string FileContent = "FileContentState";
}

// ── 第一個 Executor：讀取檔案，存入共享狀態 ───────────────────────
sealed class FileReadExecutor() : Executor<string, string>("FileReadExecutor")
{
    public override async ValueTask<string> HandleAsync(
        string filename, IWorkflowContext context, CancellationToken ct)
    {
        string content = await File.ReadAllTextAsync(filename, ct);

        // 使用 GUID 作為此次讀取的唯一 Key
        string fileId = Guid.NewGuid().ToString("N");
        await context.QueueStateUpdateAsync(fileId, content, StateScopes.FileContent, ct);

        return fileId; // 回傳 Key，讓下游 Executor 能找到資料
    }
}

// ── 並行 Executor A：計算字數 ──────────────────────────────────────
sealed class WordCountExecutor() : Executor<string, FileStats>("WordCountExecutor")
{
    public override async ValueTask<FileStats> HandleAsync(
        string fileId, IWorkflowContext context, CancellationToken ct)
    {
        var content = await context.ReadStateAsync<string>(fileId, StateScopes.FileContent, ct)
            ?? throw new InvalidOperationException("找不到共享狀態");

        int count = content.Split([' ', '\n', '\r'], StringSplitOptions.RemoveEmptyEntries).Length;
        return new FileStats { WordCount = count };
    }
}

// ── 並行 Executor B：計算段落數 ─────────────────────────────────────
sealed class ParagraphCountExecutor() : Executor<string, FileStats>("ParagraphCountExecutor")
{
    public override async ValueTask<FileStats> HandleAsync(
        string fileId, IWorkflowContext context, CancellationToken ct)
    {
        var content = await context.ReadStateAsync<string>(fileId, StateScopes.FileContent, ct)
            ?? throw new InvalidOperationException("找不到共享狀態");

        int count = content.Split(['\n', '\r'], StringSplitOptions.RemoveEmptyEntries).Length;
        return new FileStats { ParagraphCount = count };
    }
}

// ── 匯聚 Executor：收集兩個分支的結果 ─────────────────────────────
[YieldsOutput(typeof(string))]    // 宣告此 Executor 會產生最終輸出
sealed class AggregationExecutor() : Executor<FileStats>("AggregationExecutor")
{
    private readonly List<FileStats> _results = [];

    public override async ValueTask HandleAsync(
        FileStats stats, IWorkflowContext context, CancellationToken ct)
    {
        _results.Add(stats);

        // 等待兩個分支都完成
        if (_results.Count == 2)
        {
            int totalWords = _results.Sum(r => r.WordCount);
            int totalParagraphs = _results.Sum(r => r.ParagraphCount);
            await context.YieldOutputAsync($"字數：{totalWords}，段落數：{totalParagraphs}", ct);
        }
    }
}

public record FileStats
{
    public int WordCount { get; init; }
    public int ParagraphCount { get; init; }
}
```

### 建構 Fan-Out/Fan-In Workflow

```csharp
var fileRead = new FileReadExecutor();
var wordCount = new WordCountExecutor();
var paragraphCount = new ParagraphCountExecutor();
var aggregate = new AggregationExecutor();

var workflow = new WorkflowBuilder(fileRead)
    .AddFanOutEdge(fileRead, [wordCount, paragraphCount])   // 一分為二
    .AddFanInBarrierEdge([wordCount, paragraphCount], aggregate) // 等兩個完成再匯聚
    .WithOutputFrom(aggregate)
    .Build();

// 執行（非串流模式，直接取結果）
await using Run run = await InProcessExecution.RunAsync(workflow, "document.txt");
foreach (WorkflowEvent evt in run.NewEvents)
{
    if (evt is WorkflowOutputEvent output)
        Console.WriteLine(output.Data);
}
```

---

## 2. Checkpointing：儲存與恢復執行進度

Workflow 在執行過程中以「超步驟（Super Step）」為單位推進。每個超步驟結束時，框架可以自動儲存一個 **Checkpoint**（檢查點），記錄當前所有 Executor 的狀態。

這讓你可以：
- 從任意歷史檢查點恢復執行（回滾）
- 在長時間工作流程中容錯重試
- 測試特定中間狀態的後續行為

### 基本 Checkpointing 流程

```csharp
using Microsoft.Agents.AI.Workflows;

var workflow = WorkflowFactory.BuildWorkflow(); // 你的工作流程

// 1. 建立 CheckpointManager
var checkpointManager = CheckpointManager.Default;
var checkpoints = new List<CheckpointInfo>();

// 2. 執行並自動收集 Checkpoint
await using StreamingRun run = await InProcessExecution.RunStreamingAsync(
    workflow,
    initialInput,
    checkpointManager);    // ← 傳入 checkpoint manager

await foreach (WorkflowEvent evt in run.WatchStreamAsync())
{
    if (evt is ExecutorCompletedEvent e)
        Console.WriteLine($"✓ {e.ExecutorId} 完成");

    if (evt is SuperStepCompletedEvent superStep)
    {
        // 每個超步驟結束時取得 Checkpoint
        CheckpointInfo? cp = superStep.CompletionInfo?.Checkpoint;
        if (cp is not null)
        {
            checkpoints.Add(cp);
            Console.WriteLine($"📌 Checkpoint #{checkpoints.Count} 已儲存");
        }
    }

    if (evt is WorkflowOutputEvent output)
        Console.WriteLine($"✅ 完成：{output.Data}");
}

Console.WriteLine($"共建立 {checkpoints.Count} 個 Checkpoint");
```

### 從 Checkpoint 恢復

```csharp
// 從第 5 個 Checkpoint 恢復（0-based index）
const int checkpointIndex = 4;
CheckpointInfo savedCheckpoint = checkpoints[checkpointIndex];

Console.WriteLine($"\n從第 {checkpointIndex + 1} 個 Checkpoint 恢復...");

// 直接在同一個 run 實例上還原狀態
await run.RestoreCheckpointAsync(savedCheckpoint, CancellationToken.None);

// 繼續執行
await foreach (WorkflowEvent evt in run.WatchStreamAsync())
{
    if (evt is ExecutorCompletedEvent e)
        Console.WriteLine($"[恢復] ✓ {e.ExecutorId} 完成");

    if (evt is WorkflowOutputEvent output)
        Console.WriteLine($"[恢復] ✅ 完成：{output.Data}");
}
```

### Checkpoint 搭配 Human-in-the-Loop

```csharp
// 標準做法：在人工介入前儲存 Checkpoint，確認後可重試
CheckpointInfo? preApprovalCheckpoint = null;

await foreach (WorkflowEvent evt in run.WatchStreamAsync())
{
    if (evt is SuperStepCompletedEvent superStep)
    {
        var cp = superStep.CompletionInfo?.Checkpoint;
        if (cp is not null)
            preApprovalCheckpoint = cp; // 持續更新最新的 Checkpoint

    }
    else if (evt is HumanInputRequiredEvent humanInput)
    {
        Console.WriteLine($"\n⚠️  需要人工確認：{humanInput.Message}");
        Console.Write("批准？(y/n)：");
        bool approved = Console.ReadLine()?.ToLower() == "y";

        if (!approved && preApprovalCheckpoint is not null)
        {
            // 使用者拒絕，從上一個 Checkpoint 恢復
            Console.WriteLine("已拒絕，從上一個狀態恢復...");
            await run.RestoreCheckpointAsync(preApprovalCheckpoint, CancellationToken.None);
        }
        else
        {
            await run.TrySendMessageAsync(new HumanInputResponse(approved));
        }
    }
}
```

---

## 3. HumanInTheLoop（Workflow 版）

第 16 章介紹的 `ApprovalRequiredAIFunction` 是在代理層面處理人工確認。在 Workflow 中，有另一個獨立的機制讓 **Executor 節點本身暫停並等待人工輸入**。

```csharp
// 需要人工確認的 Executor
sealed class OrderApprovalExecutor() : Executor<Order, ApprovalResult>("OrderApproval")
{
    public override async ValueTask<ApprovalResult> HandleAsync(
        Order order, IWorkflowContext context, CancellationToken ct)
    {
        // 暫停並請求人工輸入
        var response = await context.RequestHumanInputAsync(
            new HumanInputRequest
            {
                Message = $"訂單 {order.Id} 金額 {order.Amount:C}，請確認",
                InputType = HumanInputType.Approval
            }, ct);

        return new ApprovalResult { Approved = response.Approved };
    }
}
```

在 Web API 情境中，Human-in-the-Loop 通常搭配 Checkpoint 一起使用——儲存確認前的狀態，確認後繼續或回滾（詳見上節）。

---

## 4. Declarative Workflow（宣告式）

除了用 C# 程式碼建構 Workflow，框架支援從 **YAML 檔案**載入宣告式工作流程。這讓非開發人員也能定義代理編排邏輯，並在不重新部署程式碼的情況下調整流程。

宣告式 Workflow 依賴 **Azure AI Foundry** 平台——代理定義（指令、工具、模型）儲存在 Foundry Project 中，YAML 只描述編排邏輯。

### 環境需求

```bash
dotnet add package Microsoft.Agents.AI.Workflows.Declarative
```

需設定以下環境變數：

```bash
dotnet user-secrets set "AZURE_AI_PROJECT_ENDPOINT" "https://your-project.api.azureml.ms/"
dotnet user-secrets set "AZURE_AI_MODEL_DEPLOYMENT_NAME" "gpt-4o-mini"
```

### YAML 工作流程定義範例（Marketing.yaml）

```yaml
# Marketing.yaml — 行銷內容生成工作流程
name: MarketingWorkflow
version: "1.0"
description: 分析師 → 撰稿人 → 編輯的行銷內容生成管線

agents:
  - name: AnalystAgent       # 對應 Foundry 中的代理名稱
    role: analyst
  - name: WriterAgent
    role: writer
  - name: EditorAgent
    role: editor

steps:
  - id: analyze
    agent: AnalystAgent
    input: "{{workflow.input}}"

  - id: write
    agent: WriterAgent
    input: "{{steps.analyze.output}}"
    dependsOn: [analyze]

  - id: edit
    agent: EditorAgent
    input: "{{steps.write.output}}"
    dependsOn: [write]

output: "{{steps.edit.output}}"
```

### C# 載入宣告式 Workflow

```csharp
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI.Workflows.Declarative;

// 預先在 Foundry 中建立代理
Uri foundryEndpoint = new(Environment.GetEnvironmentVariable("AZURE_AI_PROJECT_ENDPOINT")!);
AIProjectClient projectClient = new(foundryEndpoint, new DefaultAzureCredential());

// 確保 Foundry 中有代理定義（只需首次執行）
await projectClient.CreateAgentAsync("AnalystAgent", new DeclarativeAgentDefinition(deploymentName)
{
    Instructions = "你是行銷分析師。分析產品特點、目標受眾、獨特賣點。"
});
await projectClient.CreateAgentAsync("WriterAgent", new DeclarativeAgentDefinition(deploymentName)
{
    Instructions = "你是行銷文案撰稿人。根據分析結果撰寫 150 字以內的行銷文案。"
});
await projectClient.CreateAgentAsync("EditorAgent", new DeclarativeAgentDefinition(deploymentName)
{
    Instructions = "你是編輯。校正文法、改善清晰度、確保語調一致，輸出最終版本。"
});

// 從 YAML 建立 WorkflowFactory
WorkflowFactory factory = new("Marketing.yaml", foundryEndpoint);

// 執行（與程式碼建構的 Workflow 相同方式執行）
Workflow workflow = factory.CreateWorkflow();
await using StreamingRun run = await InProcessExecution.RunStreamingAsync(
    workflow,
    "介紹我們的新款智慧手錶，具備健康監測與 72 小時電池續航");

await run.TrySendMessageAsync(new TurnToken(emitEvents: true));
await foreach (WorkflowEvent evt in run.WatchStreamAsync())
{
    if (evt is AgentResponseUpdateEvent e)
        Console.Write(e.Update.Text);
    else if (evt is WorkflowOutputEvent output)
        Console.WriteLine($"\n\n最終輸出：{output.Data}");
}
```

### 宣告式 Workflow 支援的模式

| 模式 | YAML 關鍵字 | 說明 |
|------|-------------|------|
| 循序 | `dependsOn` | 步驟依序執行 |
| 並行 | 無 `dependsOn` | 多步驟同時執行 |
| 條件 | `condition` | 根據前步驟輸出決定是否執行 |
| 工具呼叫 | `tools` | 代理可使用的工具清單（MCP 或 Function） |
| Human-in-the-Loop | `requiresApproval: true` | 步驟執行前需人工確認 |

### 🆕 v1.4.0：HttpRequestAction — 無程式碼 HTTP 呼叫步驟

v1.4.0 新增 `HttpRequestAction` 步驟型別（PR #5474），可在 YAML 工作流程定義中直接設定 HTTP 呼叫，**無需撰寫任何 C# 工具程式碼**。適合需要呼叫外部 REST API 的工作流程。

```yaml
# Marketing.yaml（加入 HTTP 資料擷取步驟）
name: MarketingWorkflow
version: "1.0"
steps:
  - id: fetch-market-data
    type: HttpRequestAction
    url: https://api.example.com/market-trends
    method: GET
    headers:
      Authorization: "Bearer {{env.API_TOKEN}}"

  - id: analyze
    agent: AnalystAgent
    input: "{{steps.fetch-market-data.output}}"
    dependsOn: [fetch-market-data]

  - id: write
    agent: WriterAgent
    input: "{{steps.analyze.output}}"
    dependsOn: [analyze]

output: "{{steps.write.output}}"
```

`HttpRequestAction` 不需要對應的 C# 工具函式，框架在執行時直接發出 HTTP 請求並將回應注入後續步驟的 `input`。官方範例：`dotnet/samples/03-workflows/Declarative/InvokeHttpRequest`。

---

## 進階 Workflow 模式整合

下表整理了各種進階功能的搭配建議：

| 場景 | 建議技術組合 |
|------|-------------|
| 長時間分析任務，需要容錯 | WorkflowBuilder + Checkpointing |
| 財務或法規審核流程 | WorkflowBuilder + Human-in-the-Loop + Checkpoint |
| 並行調查後匯總報告 | Fan-Out/Fan-In + Shared States |
| 非開發者定義的業務流程 | Declarative Workflow（YAML）+ Foundry |
| 企業知識庫查詢分流 | AgentWorkflowBuilder.CreateHandoffBuilderWith |

---

## 延伸閱讀：v1.1.0 對 Workflow 的增強

Microsoft Agent Framework **v1.1.0（2026-04-10）** 針對 Executor 與 Workflow 做了以下強化：

- **Message Delivery Callback Overloads**（PR [#5081](https://github.com/microsoft/agent-framework/pull/5081)）— `Executor` 新增訊息遞送事件的多載，讓 Workflow 作者在訊息投遞到下游 Executor 前後掛勾自訂邏輯（例如：訊息稽核、流量整形、ID 改寫）。既有不使用 callback 的程式碼不受影響。
- **Handoff Workflow Context 修復**（PR [#5136](https://github.com/microsoft/agent-framework/pull/5136)）— 修復 `Handoff` 模式下 context 傳遞可能遺失的問題，本章 Handoff 相關範例在 v1.1.0 可獲得更穩定的 context 行為。
- **Checkpoint 還原修復**（PR [#5085](https://github.com/microsoft/agent-framework/pull/5085)）— 修復 checkpoint 還原時 input signal 處理不正確的邊界條件；本章的 Checkpointing 範例在 v1.1.0 下更可靠。

> 💡 以上皆為**非破壞性改動**，本章範例程式碼在 v1.1.0 無需修改即可運行。完整變更清單請見[附錄 A — v1.1.0 變更摘要](./appendix-a-nuget-packages.md#v110-主要變更從-100-升級)。

## v1.2.0 對 Workflow 的增強

Microsoft Agent Framework **v1.2.0（2026-04-21）** 進一步強化了 Workflow 能力：

- **Handoff Orchestration 重構 + HITL 支援**（PR [#5174](https://github.com/microsoft/agent-framework/pull/5174)）— Handoff 模式現在支援 Human-in-the-Loop，在代理移交控制權時可插入人工確認節點。詳見第 16 章 HITL 整合。
- **Handoff 官方範例**（PR [#5245](https://github.com/microsoft/agent-framework/pull/5245)）— 官方 Samples 新增 Handoff 完整範例。
- **Declarative Workflow 修復**（PR [#5323](https://github.com/microsoft/agent-framework/pull/5323), [#5376](https://github.com/microsoft/agent-framework/pull/5376)）— 修復 Checkpoint 還原後邊緣謂詞處理、代理無回應時的優雅降級。

## v1.8.0–v1.9.0 對 Workflow 的增強

Microsoft Agent Framework **v1.8.0（2026-05-28）～ v1.9.0（2026-06-03）** 對編排與輸出做了重要強化（皆為**非破壞性**，本章範例無需修改）：

### 高階編排 Builder 家族轉正式

v1.8.0 新增 `SequentialWorkflowBuilder`、`ConcurrentWorkflowBuilder` 與共同基底 `OrchestrationBuilderBase`；v1.9.0（PR [#6164](https://github.com/microsoft/agent-framework/pull/6164)）**移除 Orchestrations 的 `[Experimental]` 標記**，Sequential / Concurrent / GroupChat / **Magentic** 編排全部轉穩定 API。

```csharp
using Microsoft.Agents.AI.Workflows;

// Magentic：manager 驅動的規劃迴圈（v1.9.0 起正式）
Workflow magentic = new MagenticWorkflowBuilder(managerAgent)
    .AddParticipants(researchAgent, writerAgent, reviewAgent)
    .WithMaxRounds(20)
    .RequirePlanSignoff(false)   // 設 true：計畫產生時插入人工審批（HITL）
    .Build();

await using Run run = await InProcessExecution.RunAsync(magentic, "研究並撰寫 AI 代理趨勢報告");
```

> `MagenticOrchestrator`/`MagenticManager` 已改為 `internal` 實作型別，公開入口是 `MagenticWorkflowBuilder`。GroupChat 的 `GroupChatManager` 語意也在 v1.9.0（PR [#6140](https://github.com/microsoft/agent-framework/pull/6140)）對齊其他編排模式。

### Workflow Outputs Overhaul（PR [#6045](https://github.com/microsoft/agent-framework/pull/6045)）

工作流程輸出現在可**標註與過濾**，區分「最終結果」與「中間過程」：

```csharp
Workflow workflow = new SequentialWorkflowBuilder(analyst, writer, reviewer)
    .WithOutputFrom(reviewer)                 // 終端輸出：只把 reviewer 的結果當最終輸出
    .WithIntermediateOutputFrom([analyst, writer])  // 中間輸出：標記 OutputTag.Intermediate
    .Build();
```

- 未呼叫輸出指定方法時，套用各編排的預設（例如 Sequential 預設最後一個代理為終端、其餘為中間）。
- 消費端可依 `OutputTag.Intermediate` 過濾事件，例如只把最終結果回傳使用者、中間訊息僅供除錯。

> 完整 API 對照見知識庫 `orchestration-builders` 條目。

---

> **返回目錄**：[README](README.md) | **上一章**：[18 — Workflows 基礎](./18-workflows-basics.md) | **下一章**：[20 — Durable Agents 概念與架構](./20-durable-agents-concepts.md)
