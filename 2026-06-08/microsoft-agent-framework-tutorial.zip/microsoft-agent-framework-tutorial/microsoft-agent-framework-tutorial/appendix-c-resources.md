# 附錄 C — 學習資源與社群

> 整理 Microsoft Agent Framework 的官方資源、社群資源與延伸學習路徑。

---

## 官方資源

### GitHub 儲存庫

| 資源 | 網址 | 說明 |
|------|------|------|
| 主儲存庫 | [microsoft/agent-framework](https://github.com/microsoft/agent-framework) | 框架原始碼、架構設計 |
| 範例儲存庫 | [microsoft/Agent-Framework-Samples](https://github.com/microsoft/Agent-Framework-Samples) | 入門與進階範例（C#） |
| AI Agents for Beginners | [microsoft/ai-agents-for-beginners](https://github.com/microsoft/ai-agents-for-beginners) | 微軟官方初學者教程 |
| 社群彙整 | [webmaxru/awesome-microsoft-agent-framework](https://github.com/webmaxru/awesome-microsoft-agent-framework) | 社群蒐集的資源清單 |

### 官方文件

| 資源 | 網址 |
|------|------|
| Framework Overview | [learn.microsoft.com/en-us/agent-framework/overview](https://learn.microsoft.com/en-us/agent-framework/overview/) |
| Quick Start | [learn.microsoft.com/en-us/agent-framework/tutorials/quick-start](https://learn.microsoft.com/en-us/agent-framework/tutorials/quick-start) |
| Agent Types | [learn.microsoft.com/en-us/agent-framework/agents](https://learn.microsoft.com/en-us/agent-framework/agents/) |
| Workflows | [learn.microsoft.com/en-us/agent-framework/workflows](https://learn.microsoft.com/en-us/agent-framework/workflows/) |
| API Reference | [learn.microsoft.com/en-us/dotnet/api/microsoft.agents.ai](https://learn.microsoft.com/en-us/dotnet/api/microsoft.agents.ai) |

### 官方部落格

| 資源 | 網址 |
|------|------|
| Agent Framework Blog | [devblogs.microsoft.com/agent-framework](https://devblogs.microsoft.com/agent-framework/) |
| .NET Blog | [devblogs.microsoft.com/dotnet](https://devblogs.microsoft.com/dotnet/) |
| Semantic Kernel Blog | [devblogs.microsoft.com/semantic-kernel](https://devblogs.microsoft.com/semantic-kernel/) |

---

## NuGet 套件頁面

| 套件 | NuGet |
|------|-------|
| Microsoft.Agents.AI | [nuget.org/packages/Microsoft.Agents.AI](https://www.nuget.org/packages/Microsoft.Agents.AI) |
| Microsoft.Agents.AI.OpenAI | [nuget.org/packages/Microsoft.Agents.AI.OpenAI](https://www.nuget.org/packages/Microsoft.Agents.AI.OpenAI) |
| Microsoft.Agents.AI.Workflows | [nuget.org/packages/Microsoft.Agents.AI.Workflows](https://www.nuget.org/packages/Microsoft.Agents.AI.Workflows) |
| Microsoft.Extensions.AI | [nuget.org/packages/Microsoft.Extensions.AI](https://www.nuget.org/packages/Microsoft.Extensions.AI) |

---

## 相關技術資源

### Microsoft.Extensions.AI

Agent Framework 建構於此抽象層之上，了解它有助於更深入理解框架設計。

| 資源 | 網址 |
|------|------|
| 官方文件 | [learn.microsoft.com/en-us/dotnet/ai/microsoft-extensions-ai](https://learn.microsoft.com/en-us/dotnet/ai/microsoft-extensions-ai) |
| GitHub | [dotnet/extensions](https://github.com/dotnet/extensions) |

### 開放協定

Agent Framework 支援的開放協定，進階篇會詳細介紹。

| 協定 | 說明 | 資源 |
|------|------|------|
| MCP（Model Context Protocol） | 標準化的外部工具整合協定 | [modelcontextprotocol.io](https://modelcontextprotocol.io) |
| A2A（Agent-to-Agent） | 跨服務的代理間通訊協定 | [google.github.io/A2A](https://google.github.io/A2A/) |
| AG-UI（Agent-User Interaction） | 代理與使用者介面的互動協定 | [docs.ag-ui.com](https://docs.ag-ui.com) |

---

## 延伸學習路徑

完成本入門教學後，建議的學習路徑：

```mermaid
flowchart TD
    A["✅ 入門教學\n（你在這裡）"] --> B["進階篇：MCP 整合"]
    A --> C["進階篇：Multi-Agent\n進階模式"]
    A --> D["進階篇：ASP.NET Core\n託管部署"]

    B --> E["實戰：建立 MCP Server"]
    C --> F["實戰：複雜工作流程"]
    D --> G["實戰：生產環境部署"]

    E --> H["整合專案"]
    F --> H
    G --> H

    style A fill:#D4EDDA,stroke:#28A745,color:#333
    style H fill:#E8F0FE,stroke:#4A90D9,color:#333
```

1. **MCP 整合**：學習如何透過 Model Context Protocol 讓代理存取外部工具與資料來源
2. **Multi-Agent 進階模式**：Concurrent、Handoff、Group Chat、Graph-based 等工作流程模式
3. **ASP.NET Core 託管**：將代理部署為 Web API 服務，支援多用戶存取
4. **可觀測性**：使用 OpenTelemetry 監控代理的行為、效能與成本
5. **A2A 與 AG-UI**：跨服務代理通訊與前端整合

---

## 社群資源

- **GitHub Discussions**：在 [microsoft/agent-framework](https://github.com/microsoft/agent-framework/discussions) 的 Discussions 區提問與交流
- **Stack Overflow**：使用 `microsoft-agent-framework` 標籤搜尋與提問
- **Discord / Teams**：關注官方部落格的社群連結公告

---

> **返回目錄**：[README](README.md) | **上一篇**：[附錄 B — 從 SK / AutoGen 遷移](./appendix-b-migration-guide.md) | **下一篇**：[附錄 D — 提案中的架構決策](./appendix-d-proposed-adrs.md)
