# 附錄 F — SDK 代理功能範例（dotnet/samples/02-agents）

> 來源：[microsoft/agent-framework — dotnet/samples/02-agents](https://github.com/microsoft/agent-framework/tree/main/dotnet/samples/02-agents)
> 版本基準：v1.6.1

`02-agents` 目錄提供 17 個子目錄，涵蓋代理的每一個進階功能面向。本附錄重點介紹其中最具教學價值的模式。

---

## 目錄總覽

| 子目錄 | 主題 |
|--------|------|
| `Agents/` | 20 步驟代理功能系列（工具審核 / 結構化輸出 / 持久化 / 背景回應 / 壓縮 / 動態工具等） |
| `AGUI/` | AG-UI 協定（伺服器 + 客戶端） |
| `A2A/` | A2A 協定（代理作為工具 / 輪詢 / 串流重連 / 協定選擇） |
| `AgentOpenTelemetry/` | OpenTelemetry + .NET Aspire Dashboard |
| `AgentProviders/` | 各 LLM 提供者配置範例 |
| `AgentSkills/` | 五步驟 Skills 系統（見第 29 章） |
| `AgentWithAnthropic/` | Anthropic Claude 整合 |
| `AgentWithCodeAct/` | CodeAct / Hyperlight 沙盒執行 |
| `AgentWithMemory/` | 記憶體元件完整範例 |
| `AgentWithOpenAI/` | OpenAI 原生交換型別 |
| `AgentWithRAG/` | RAG 檢索增強生成 |
| `AgentsWithFoundry/` | FoundryAgent 建立方式 |
| `DeclarativeAgents/` | YAML 宣告式代理 |
| `DevUI/` | 開發者除錯 UI |
| `Evaluation/` | 代理評測 |
| `Harness/` | Managed Agent Harness |
| `ModelContextProtocol/` | MCP 整合（一般 / 認證 / Hosted） |

---

## Agents — 20 步驟功能系列

`02-agents/Agents/` 包含 20 個遞進範例，建議按順序閱讀：

| 步驟 | 目錄 | 核心概念 | 對應章節 |
|------|------|---------|---------|
| Step 01 | `Agent_Step01_UsingFunctionToolsWithApprovals` | HITL 工具審核 | [ch16](./16-human-in-the-loop.md) |
| Step 02 | `Agent_Step02_StructuredOutput` | JSON 結構化輸出 | [ch15](./15-structured-output.md) |
| Step 03 | `Agent_Step03_PersistedConversations` | 對話歷史持久化與重載 | [ch14](./14-context-providers.md) |
| Step 04 | `Agent_Step04_3rdPartyChatHistoryStorage` | Redis / Cosmos DB 儲存後端 | [ch14](./14-context-providers.md) |
| Step 05 | `Agent_Step05_Observability` | 基礎 OTel 儀器化 | [ch22](./22-opentelemetry-observability.md) |
| Step 06 | `Agent_Step06_DependencyInjection` | DI 容器注入與解析 | — |
| Step 07 | `Agent_Step07_AsMcpTool` | **代理公開為 MCP 工具** | [ch25](./25-mcp-integration.md) |
| Step 08 | `Agent_Step08_UsingImages` | 多模態圖片輸入 | — |
| Step 09 | `Agent_Step09_AsFunctionTool` | **代理公開為函式工具** | [ch05](./05-tools-basics.md) |
| Step 10 | `Agent_Step10_BackgroundResponsesWithToolsAndPersistence` | 背景回應 + 工具 + 持久化 | [ch26](./26-long-running-operations.md) |
| Step 11 | `Agent_Step11_Middleware` | Middleware 攔截器 | [ch06](./06-middleware-and-context.md) |
| Step 12 | `Agent_Step12_Plugins` | Plugin 系統整合 | — |
| Step 13 | `Agent_Step13_ChatReduction` | **對話歷史壓縮** | — |
| Step 14 | `Agent_Step14_BackgroundResponses` | 背景長時間回應（輪詢 + 斷點續傳） | [ch26](./26-long-running-operations.md) |
| Step 15 | `Agent_Step15_DeepResearch` | **Deep Research Tool** | — |
| Step 16 | `Agent_Step16_Declarative` | 宣告式代理定義 | — |
| Step 17 | `Agent_Step17_AdditionalAIContext` | 多 AIContextProvider 並行注入 | [ch14](./14-context-providers.md) |
| Step 18 | `Agent_Step18_CompactionPipeline` | **對話壓縮 Pipeline** | — |
| Step 19 | `Agent_Step19_InFunctionLoopCheckpointing` | **函數迴圈內 Checkpointing** | [ch21](./21-durable-agents-implementation.md) |
| Step 20 | `Agent_Step20_DynamicFunctionTools` | **動態函式工具擴展** | [ch05](./05-tools-basics.md) |

### 重點模式：對話歷史壓縮（Step 13 / Step 18）

當 session 持續過長，對話歷史可能超出 LLM token 上限。SDK 提供兩種方案：

**Step 13 — ChatReduction（手動壓縮）**：在本地維護的對話歷史中，移除較舊的訊息或合併為摘要，適合輕量場景。

**Step 18 — CompactionPipeline（Pipeline 式壓縮）**：以 Pipeline 架構組合多個壓縮策略，可選擇「移除最舊的 N 則」、「LLM 生成摘要」、「保留重要的 System 訊息」等策略，適合需要細緻控制的生產系統。

### 重點模式：In-Function-Loop Checkpointing（Step 19）

在工具呼叫迴圈中，每次工具執行後立即持久化對話歷史，即使 Process 崩潰也能從最後一個 Checkpoint 繼續執行：

```csharp
// 設定：在每次工具呼叫後持久化
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    AfterEachFunctionCallPersistence = new InProcessChatHistoryPersistence(),
    Tools = [/* 你的工具 */],
});
```

適用場景：費時的 API 呼叫序列、多步驟資料處理、不允許重複計費的工具操作。

### 重點模式：Dynamic Function Tools（Step 20）

在工具執行期間，透過 `FunctionInvocationContext` 動態擴充可用工具清單：

```csharp
// 在工具的實作中，存取 ambient 上下文並加入新工具
[Description("Search the web and dynamically add more search tools if needed")]
static async Task<string> SearchAndExpand(string query)
{
    var ctx = FunctionInvocationContext.Current;
    if (ctx is not null && needMoreTools)
    {
        // 動態加入新的工具，LLM 在下一輪可立即使用
        ctx.AvailableFunctions.Add(AIFunctionFactory.Create(GetMoreDetails));
    }
    return await DoSearch(query);
}
```

---

## AGUI — AG-UI 協定客戶端

> 對應教學：[第 24 章](./24-agui-protocol-deep-dive.md)

`02-agents/AGUI/` 提供完整的 AG-UI 伺服器與客戶端實作：

**伺服器端**（`Step01_GettingStarted/Server`）：

```csharp
// 在 ASP.NET Core 中設定 AG-UI 端點
app.MapAGUI("/agent", agent);
// 監聽 SSE 連線，串流 AG-UI 事件給客戶端
```

**客戶端**（`Step01_GettingStarted/Client`）：

```csharp
// AGUIChatClient 連接到 AG-UI 伺服器
var aguiClient = new AGUIChatClient(new Uri("http://localhost:8888"));

// 建立或繼續 thread
var threadId = Guid.NewGuid().ToString();

// 串流接收回應（和一般 ChatClient 使用方式相同）
await foreach (var update in aguiClient.RunStreamingAsync(threadId, "你好！"))
    Console.Write(update.Text);
```

**AG-UI 事件類型**：

| 事件 | 說明 |
|------|------|
| `TEXT_MESSAGE_CONTENT` | 代理文字回應片段 |
| `TOOL_CALL_START` | 工具呼叫開始 |
| `TOOL_CALL_END` | 工具呼叫結束（含結果） |
| `REASONING_CHUNK` | 推理過程片段（v1.5.0，支援推理的模型） |
| `STATE_DELTA` | 前端狀態更新 |
| `RUN_FINISHED` | 本輪執行完成 |

---

## A2A — Agent-to-Agent 協定

> 對應教學：[第 23 章](./23-a2a-protocol.md)

`02-agents/A2A/` 提供四種 A2A 整合模式：

### A2A 代理作為函式工具

```csharp
// 將遠端 A2A 代理的 Skill 對應為本地函式工具
var a2aCard = await A2ACardResolver.ResolveAsync("http://remote-agent-server/");

// 每個 Skill → 一個 AIFunction
var tools = a2aCard.Skills
    .Select(skill => A2AClientFunctionFactory.Create(skill, a2aClient))
    .ToList();

AIAgent orchestrator = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Tools = tools  // 直接把遠端代理的 Skill 當成工具
});
```

### 串流中斷重連（StreamReconnection）

```csharp
// A2A 串流支援以 continuation token 恢復中斷的串流
var task = await a2aAgent.SendMessageAsync(message, sessionId);

// 若串流中斷，使用 continuation token 重連
await foreach (var evt in a2aAgent.ResumeStreamingAsync(task.ContinuationToken))
    Console.WriteLine(evt);
```

### 協定選擇（ProtocolSelection）

```csharp
// 明確選擇 A2A 協定綁定方式
var options = new A2AClientOptions
{
    ProtocolBinding = A2AProtocolBinding.HttpJson,  // 或 JsonRpc
};
var agent = a2aAgent.AsAIAgent(options);
```

---

## AgentOpenTelemetry — OTel + .NET Aspire Dashboard

> 對應教學：[第 22 章](./22-opentelemetry-observability.md)

`02-agents/AgentOpenTelemetry/` 展示完整的可觀察性設置：

**架構**：Console App → Agent Framework（OTel） → Azure OpenAI / .NET Aspire Dashboard → [Optional] Application Insights

**快速啟動 Aspire Dashboard**（需要 Docker）：

```bash
docker run --rm -it -p 18888:18888 -p 4317:18889 mcr.microsoft.com/dotnet/aspire-dashboard:latest
```

```csharp
// 代理 OTel 配置（v1.6.1：不需手動包裝 ChatClient，OpenTelemetryAgent 會自動處理）
builder.Services.AddOpenTelemetry()
    .WithTracing(tracing => tracing
        .AddAgentFrameworkInstrumentation()
        .AddOtlpExporter(otlp => otlp.Endpoint = new Uri("http://localhost:4317")));
```

---

## AgentWithCodeAct — CodeAct / Hyperlight 沙盒

> 對應教學：[附錄 D](./appendix-d-proposed-adrs.md)

`02-agents/AgentWithCodeAct/` 展示三種 Hyperlight 沙盒模式：

| 步驟 | 模式 | 說明 |
|------|------|------|
| Step 01 | Interpreter | 純 Python 解譯模式，無主機工具 |
| Step 02 | Tool-Enabled | Guest 程式碼透過 `call_tool(...)` 呼叫主機提供的工具 |
| Step 03 | Manual Wiring | `HyperlightExecuteCodeFunction` 直接作為代理工具 |

```csharp
// Step 01：Hyperlight Python 解譯器
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Tools = [new HyperlightCodeActProvider(guestModulePath)],
});
// 代理可生成並執行 Python 程式碼，在沙盒中安全運行
```

**環境變數**：`HYPERLIGHT_PYTHON_GUEST_PATH`（Hyperlight guest module 路徑）

---

## AgentsWithFoundry — FoundryAgent 建立方式

> 對應教學：[第 17 章](./17-llm-providers.md)

```csharp
// 方式一：FoundryAgent 型別（直接建立，v1.6.1）
FoundryAgent agent = new FoundryAgent(
    new Uri(endpoint),
    new AzureCliCredential(),
    model: "gpt-5.4-mini",
    instructions: "You are a helpful assistant.",
    name: "MyAgent");

// 方式二：透過 AIProjectClient 擴充方法
FoundryAgent agent = new AIProjectClient(new Uri(endpoint), new DefaultAzureCredential())
    .AsAIAgent(model: "gpt-5.4-mini", instructions: "...", name: "MyAgent");

// 使用方式與 AIAgent 完全相同
Console.WriteLine(await agent.RunAsync("Hello!"));
AgentSession session = await agent.CreateSessionAsync();
Console.WriteLine(await agent.RunAsync("繁體中文範例", session));
```

---

## ModelContextProtocol — MCP 整合三種模式

> 對應教學：[第 25 章](./25-mcp-integration.md)

| 範例 | 說明 |
|------|------|
| `Agent_MCP_Server` | 連接一般 MCP 伺服器，使用其工具 |
| `Agent_MCP_Server_Auth` | 連接需要認證的受保護 MCP 伺服器 |
| `ResponseAgent_Hosted_MCP` | **Hosted MCP Tool**：Responses Service 在服務端直接呼叫 MCP 工具（無需客戶端往返） |

`ResponseAgent_Hosted_MCP` 是 v1.6.1 的重要新模式：工具呼叫在 Azure AI Foundry 服務端完成，減少客戶端與服務端的往返次數，適合高延遲環境。

---

> **返回目錄**：[README](README.md) | **上一篇**：[附錄 E — SDK 入門範例](./appendix-e-sdk-samples-get-started.md) | **下一篇**：[附錄 G — SDK 工作流程範例](./appendix-g-sdk-samples-workflows.md)
