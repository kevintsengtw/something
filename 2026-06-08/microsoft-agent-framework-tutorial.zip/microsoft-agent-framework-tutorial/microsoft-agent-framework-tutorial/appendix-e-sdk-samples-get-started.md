# 附錄 E — SDK 入門範例解析（dotnet/samples/01-get-started）

> 來源：[microsoft/agent-framework — dotnet/samples/01-get-started](https://github.com/microsoft/agent-framework/tree/main/dotnet/samples/01-get-started)
> 版本基準：v1.6.1

本附錄逐一解析 `01-get-started` 目錄下的六個漸進式入門範例。每個範例以單一 `Program.cs` 呈現一個核心概念，適合做為快速 「Hello World → 進階功能」的學習路徑。

---

## 學習路徑總覽

```text
01_hello_agent        → 建立代理 + RunAsync / RunStreamingAsync
02_add_tools          → 工具（Function Calling）
03_multi_turn         → 多輪對話 + AgentSession
04_memory             → 記憶體（AIContextProvider + ProviderSessionState<T>）
05_first_workflow     → 工作流程（WorkflowBuilder + Executor）
06_host_your_agent    → Azure Functions 部署（DurableAgents）
```

---

## 01 — Hello Agent：建立你的第一個代理

> 對應教學：[第 04 章](./04-first-agent.md)

```csharp
using Azure.AI.OpenAI;
using Azure.Identity;
using Microsoft.Agents.AI;
using OpenAI.Chat;

var endpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")
    ?? throw new InvalidOperationException("AZURE_OPENAI_ENDPOINT is not set.");
var deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-5.4-mini";

// 最簡代理建立方式：GetChatClient().AsAIAgent(instructions:, name:)
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(instructions: "You are good at telling jokes.", name: "Joker");

// 非串流呼叫（回傳字串）
Console.WriteLine(await agent.RunAsync("Tell me a joke about a pirate."));

// 串流呼叫（IAsyncEnumerable<AgentStreamingUpdate>）
await foreach (var update in agent.RunStreamingAsync("Tell me a joke about a pirate."))
    Console.WriteLine(update);
```

**重點**：
- `AsAIAgent(instructions:, name:)` 是最簡建立方式，適合快速原型
- `RunAsync` 回傳 `string`（完整回應）
- `RunStreamingAsync` 回傳 `IAsyncEnumerable`，即時輸出每個 token

---

## 02 — Add Tools：讓代理呼叫函式工具

> 對應教學：[第 05 章](./05-tools-basics.md)

```csharp
using System.ComponentModel;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

// 1. 定義工具函式（使用 [Description] 屬性提供說明給 LLM）
[Description("Get the weather for a given location.")]
static string GetWeather([Description("The location to get the weather for.")] string location)
    => $"The weather in {location} is cloudy with a high of 15°C.";

// 2. AIFunctionFactory.Create() 包裝靜態函式
AIAgent agent = chatClient.AsAIAgent(
    instructions: "You are a helpful assistant",
    tools: [AIFunctionFactory.Create(GetWeather)]);

// 代理會自動判斷何時呼叫工具
Console.WriteLine(await agent.RunAsync("What is the weather like in Amsterdam?"));
```

**重點**：
- `AIFunctionFactory.Create(method)` 將 C# 方法轉為 LLM 可呼叫的 `AIFunction`
- `[Description]` 屬性為 LLM 提供工具與參數的說明文字，影響呼叫準確度
- 支援靜態方法、Lambda、非同步方法

---

## 03 — Multi-Turn：多輪對話管理

> 對應教學：[第 04 章](./04-first-agent.md)、[第 14 章](./14-context-providers.md)

```csharp
AIAgent agent = chatClient.AsAIAgent(instructions: "You are good at telling jokes.", name: "Joker");

// CreateSessionAsync() 建立帶有對話歷史的 session
AgentSession session = await agent.CreateSessionAsync();

// 在同一個 session 中進行多輪對話，上下文自動保留
Console.WriteLine(await agent.RunAsync("Tell me a joke about a pirate.", session));
Console.WriteLine(await agent.RunAsync("Now add some emojis and tell it as a pirate's parrot.", session));

// 串流多輪對話
session = await agent.CreateSessionAsync();
await foreach (var update in agent.RunStreamingAsync("Tell me a joke.", session))
    Console.WriteLine(update);
await foreach (var update in agent.RunStreamingAsync("Make it funnier.", session))
    Console.WriteLine(update);
```

**重點**：
- `CreateSessionAsync()` 每次呼叫建立一個新的獨立對話
- 將 `session` 傳入 `RunAsync`/`RunStreamingAsync` 可讓代理記住對話歷史
- 不傳 `session` 等同於每次都是全新對話（無記憶）

---

## 04 — Memory：自訂記憶體元件

> 對應教學：[第 14 章](./14-context-providers.md)

這個範例展示如何建立能「學習並記住使用者資訊」的代理。

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

// ── 1. 定義記憶體元件 ──────────────────────────────────────────
public class UserInfoMemory : AIContextProvider
{
    private readonly ProviderSessionState<UserInfo> _sessionState;
    private readonly IChatClient _chatClient;

    public UserInfoMemory(IChatClient chatClient)
    {
        _sessionState = new ProviderSessionState<UserInfo>(
            _ => new UserInfo(),
            this.GetType().Name);
        _chatClient = chatClient;
    }

    public override IReadOnlyList<string> StateKeys => [_sessionState.StateKey];

    // LLM 回應後：用 LLM 從對話中提取使用者資訊
    protected override async ValueTask StoreAIContextAsync(
        InvokedContext context, CancellationToken ct = default)
    {
        var userInfo = _sessionState.GetOrInitializeState(context.Session);
        if ((userInfo.UserName is null || userInfo.UserAge is null)
            && context.RequestMessages.Any(x => x.Role == ChatRole.User))
        {
            var result = await _chatClient.GetResponseAsync<UserInfo>(
                context.RequestMessages,
                new ChatOptions { Instructions = "Extract user's name and age. Return nulls if not found." },
                ct);
            userInfo.UserName ??= result.Result.UserName;
            userInfo.UserAge ??= result.Result.UserAge;
        }
        _sessionState.SaveState(context.Session, userInfo);
    }

    // 每次 LLM 呼叫前：把已知資訊注入到 System 指令
    protected override ValueTask<AIContext> ProvideAIContextAsync(
        InvokingContext context, CancellationToken ct = default)
    {
        var userInfo = _sessionState.GetOrInitializeState(context.Session);
        var sb = new StringBuilder();
        sb.AppendLine(userInfo.UserName is null
            ? "Ask for user's name and decline other questions until provided."
            : $"The user's name is {userInfo.UserName}.");
        sb.AppendLine(userInfo.UserAge is null
            ? "Ask for user's age and decline other questions until provided."
            : $"The user's age is {userInfo.UserAge}.");
        return ValueTask.FromResult(new AIContext { Instructions = sb.ToString() });
    }

    public UserInfo GetUserInfo(AgentSession session) => _sessionState.GetOrInitializeState(session);
    public void SetUserInfo(AgentSession session, UserInfo info) => _sessionState.SaveState(session, info);
}

public sealed class UserInfo
{
    public string? UserName { get; set; }
    public int? UserAge { get; set; }
}
```

```csharp
// ── 2. 建立代理並附加記憶體元件 ───────────────────────────────
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    ChatOptions = new() { Instructions = "You are a friendly assistant. Always address the user by their name." },
    AIContextProviders = [new UserInfoMemory(chatClient.AsIChatClient())]
});

var session = await agent.CreateSessionAsync();
Console.WriteLine(await agent.RunAsync("Hello, what is the square root of 9?", session));
Console.WriteLine(await agent.RunAsync("My name is Alice", session));
Console.WriteLine(await agent.RunAsync("I am 25 years old", session));

// ── 3. Session 序列化（含記憶體狀態）──────────────────────────
JsonElement element = await agent.SerializeSessionAsync(session);

// 還原 session（記憶體狀態一併還原）
var restored = await agent.DeserializeSessionAsync(element);
Console.WriteLine(await agent.RunAsync("What is my name and age?", restored));

// ── 4. 跨 Session 共享記憶體 ──────────────────────────────────
var newSession = await agent.CreateSessionAsync();
if (agent.GetService<UserInfoMemory>() is UserInfoMemory memory)
    memory.SetUserInfo(newSession, memory.GetUserInfo(session));
Console.WriteLine(await agent.RunAsync("Do you know my name?", newSession));
```

**重點**：
- `ProviderSessionState<T>` 將狀態綁定到 session，Provider 本身保持無狀態
- `StoreAIContextAsync`（執行後）：觀察對話並更新狀態
- `ProvideAIContextAsync`（執行前）：把狀態轉為 LLM 指令注入
- `SerializeSessionAsync` / `DeserializeSessionAsync` 含 Provider 狀態的完整序列化
- `agent.GetService<T>()` 取得已附加的 Provider 實例

---

## 05 — First Workflow：建立你的第一個工作流程

> 對應教學：[第 18 章](./18-workflows-basics.md)

```csharp
using Microsoft.Agents.AI.Workflows;

// ── 1. 建立 Executor ──────────────────────────────────────────
// 將 Lambda 包裝為 Executor（最簡方式）
var uppercase = ((Func<string, string>)(s => s.ToUpperInvariant()))
    .BindAsExecutor("UppercaseExecutor");

// 自訂 Executor（繼承 Executor<TInput, TOutput>）
var reverse = new ReverseTextExecutor();

// ── 2. 用 WorkflowBuilder 組裝 Executor + Edge ────────────────
WorkflowBuilder builder = new(uppercase);   // 第一個節點
builder.AddEdge(uppercase, reverse)         // 連接兩個 Executor
       .WithOutputFrom(reverse);            // 宣告輸出來源
var workflow = builder.Build();

// ── 3. 執行工作流程並監聽事件 ─────────────────────────────────
await using Run run = await InProcessExecution.RunAsync(workflow, "Hello, World!");
foreach (WorkflowEvent evt in run.NewEvents)
{
    if (evt is ExecutorCompletedEvent completed)
        Console.WriteLine($"{completed.ExecutorId}: {completed.Data}");
    // 輸出：
    // UppercaseExecutor: HELLO, WORLD!
    // ReverseTextExecutor: !DLROW ,OLLEH
}
```

```csharp
// 自訂 Executor 範例
sealed class ReverseTextExecutor() : Executor<string, string>("ReverseTextExecutor")
{
    public override ValueTask<string> HandleAsync(
        string message, IWorkflowContext context, CancellationToken ct = default)
        => ValueTask.FromResult(string.Concat(message.Reverse()));
}
```

**重點**：
- `WorkflowBuilder(firstExecutor)` 以第一個節點初始化
- `AddEdge(from, to)` 建立資料流連結
- `BindAsExecutor(name)` 將 `Func<T, T>` 快速包裝為執行節點
- `InProcessExecution.RunAsync` 在目前 Process 內執行工作流程
- `WorkflowEvent` / `ExecutorCompletedEvent` 提供執行進度通知

---

## 06 — Host Your Agent：Azure Functions 代理部署

> 對應教學：[第 20 章](./20-durable-agents-concepts.md)、[第 21 章](./21-durable-agents-implementation.md)

```csharp
using Azure.AI.OpenAI;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Hosting.AzureFunctions;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Hosting;

// 1. 建立代理（標準方式）
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        instructions: "You are a helpful assistant hosted in Azure Functions.",
        name: "HostedAgent");

// 2. 將代理加入 Azure Functions 主機（自動產生 REST API 端點）
using IHost app = FunctionsApplication.CreateBuilder(args)
    .ConfigureFunctionsWebApplication()
    .ConfigureDurableAgents(options => options.AddAIAgent(
        agent,
        timeToLive: TimeSpan.FromHours(1)))  // Session 存活時間
    .Build();

app.Run();
// 啟動後自動產生：POST http://localhost:7071/api/agents/HostedAgent/run
```

**環境變數**：

```bash
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-5.4-mini
```

**NuGet 套件**：

```bash
dotnet add package Microsoft.Agents.AI.Hosting.AzureFunctions
```

**自動產生的 API 端點**：

| 方法 | 路徑 | 說明 |
|------|------|------|
| POST | `/api/agents/{agentName}/run` | 建立新 session 並傳送訊息 |
| POST | `/api/agents/{agentName}/sessions/{sessionId}/run` | 在現有 session 中傳送訊息 |
| GET | `/api/agents/{agentName}/sessions/{sessionId}` | 取得 session 狀態 |

**重點**：
- `ConfigureDurableAgents(options => options.AddAIAgent(agent, timeToLive:))` 是最精簡的 Azure Functions 部署方式
- `timeToLive` 控制 session 在無活動後的自動清理時間
- 代理名稱成為 URL 路徑的一部分

---

## 執行範例

```bash
# 1. 進入任意範例目錄
cd dotnet/samples/01-get-started/01_hello_agent

# 2. 設定環境變數
$env:AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
$env:AZURE_OPENAI_DEPLOYMENT_NAME="gpt-5.4-mini"

# 3. 執行
dotnet run
```

**前置需求**：
- .NET 10 SDK 或更新版本
- Azure OpenAI 資源端點
- `az login`（使用 `DefaultAzureCredential`）

---

## 章節對應速查

| 範例 | 核心概念 | 深入閱讀 |
|------|---------|---------|
| 01_hello_agent | `AsAIAgent`, `RunAsync`, `RunStreamingAsync` | [第 04 章](./04-first-agent.md) |
| 02_add_tools | `AIFunctionFactory.Create`, `[Description]` | [第 05 章](./05-tools-basics.md) |
| 03_multi_turn | `CreateSessionAsync`, 多輪對話 | [第 04 章](./04-first-agent.md) |
| 04_memory | `AIContextProvider`, `ProviderSessionState<T>` | [第 14 章](./14-context-providers.md) |
| 05_first_workflow | `WorkflowBuilder`, `Executor`, `InProcessExecution` | [第 18 章](./18-workflows-basics.md) |
| 06_host_your_agent | `ConfigureDurableAgents`, Azure Functions | [第 21 章](./21-durable-agents-implementation.md) |

---

> **返回目錄**：[README](README.md) | **上一篇**：[附錄 D — Proposed ADRs](./appendix-d-proposed-adrs.md) | **下一篇**：[附錄 F — SDK 代理功能範例](./appendix-f-sdk-samples-agents.md)
