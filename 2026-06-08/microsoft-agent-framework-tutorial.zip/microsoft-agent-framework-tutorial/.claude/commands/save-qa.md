# /save-qa — 儲存問答記錄到知識庫

將本次對話中的 `/wiki-query` 問答內容（或任何有價值的技術討論）儲存到 `agent-framework-kb/brainstorming/qa-sessions/`，供後續 `/wiki-query` 查詢與 `/compile` 編譯時參考。

## 使用方式

```
/save-qa
```

也可以指定主題：
```
/save-qa Middleware prompt interception 的用法
```

## 執行步驟

1. **擷取問答內容**
   - 回顧當前對話，找出有價值的技術問答
   - 若使用者指定主題，聚焦於該主題相關問答
   - 若對話中沒有值得保存的技術內容，告知並結束

2. **判斷相關概念**
   - 從問答內容識別涉及的 wiki/concepts/ 條目
   - 記錄對應 concept 檔名

3. **建立 QA 檔案**
   - 確認 `agent-framework-kb/brainstorming/qa-sessions/` 目錄存在
   - 檔名格式：`YYYY-MM-DD-<主題關鍵字>.md`
   - 若同日同主題已存在，append 到既有檔案

4. **寫入內容**

   ```markdown
   ---
   date: YYYY-MM-DD
   topic: <主題摘要>
   related_concepts: [concept-name-1, concept-name-2]
   promoted_to_wiki: false
   ---

   ## 問題

   <使用者的問題>

   ## 回答

   <回答的重點摘要>

   ## 關鍵發現

   - <從這次問答得到的新知識或洞察>
   - <wiki/ 中尚未涵蓋的資訊>

   ## 來源

   - <wiki/concepts/ 條目>
   - <raw/ 素材>
   ```

5. **產出摘要**
   - 顯示已儲存的檔案路徑
   - 列出關聯的 wiki/concepts/ 條目
   - 若發現 wiki/ 有資訊缺漏，建議下次 `/compile` 時補充

## 注意事項

- QA 記錄是探索性內容，不需符合 wiki/SCHEMA.md 嚴格格式
- 一個檔案可包含多組問答（同日同主題時 append）
- `/compile` 會掃描 `promoted_to_wiki: false` 的記錄
- `/wiki-query` 會搜尋此目錄作為補充來源
