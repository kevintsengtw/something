# /draft-appendix — 草擬新附錄

**用法**：`/draft-appendix <topic> [appendix-letter]`

範例：
- `/draft-appendix testing-patterns` — 自動選下一個可用附錄字母
- `/draft-appendix langchain-migration j` — 指定附錄 J

草擬一份新附錄，輸出至 `outputs/draft-appendix-<topic>.md`（**不直接寫入 tutorial/**）。

## 與 /draft-chapter 的差異

| 面向 | /draft-chapter | /draft-appendix |
|------|---------------|----------------|
| 編號 | NN（數字章節） | 英文字母 a–z |
| 內容類型 | 教學主題（學習路徑） | 參考資料、對照表、遷移指南、SDK 範例索引 |
| 來源 | wiki/concepts/ | raw/samples/、raw/adrs/、raw/release-notes/ |
| 風格 | 敘事 + 上手範例 | 索引 + 對照表 + 連結 |

## 適用情境

附錄常見類型：
- **SDK Samples 索引**（appendix-e/f/g/h/i 系列）
- **NuGet 套件對照**（appendix-a）
- **Migration Guide**（appendix-b）
- **Resources**（appendix-c）
- **Proposed ADRs**（appendix-d）

## 執行步驟

1. **判斷附錄類型**
   - 由 `<topic>` 推斷類型
   - 讀取 `microsoft-agent-framework-tutorial/` 既有附錄找最相近作為範本

2. **收集素材**

   依類型不同：

   - **SDK Samples 類**：
     - 讀取 `agent-framework-kb/raw/samples/` 對應子目錄
     - 對每個 sample，呼叫 `search_graph` 驗證用到的 API
     - 列出範例的中文說明 + 連結到 `agent-framework/dotnet/samples/`

   - **NuGet 套件類**：
     - 讀取 `agent-framework-kb/raw/api-surface/`
     - 對每個套件，列出 namespace、主要 class、版本

   - **Migration 類**：
     - 讀取 `agent-framework-kb/wiki/api-changelog.md`
     - 整理 breaking changes 的遷移路徑

3. **codebase-memory-mcp 驗證**

   附錄內提到的每個 API 名稱：
   ```
   mcp__codebase-memory-mcp__search_graph
     project: "agent-framework"
     name_pattern: "<api_name>"
   ```
   - 查無 → 標記 `⚠️ 此 API 待人工驗證`，不寫入

4. **附錄結構生成**

   ```markdown
   # 附錄 <letter>：<繁中標題>

   > 本附錄整理 <用途說明>
   > 對應 wiki 條目：[[xxx]]、[[yyy]]
   > 最後更新：YYYY-MM-DD

   ## <分節>

   | 欄位 1 | 欄位 2 | 對應教學章節 |
   |--------|--------|------------|

   ## 詳細說明
   ## 參考連結
   ```

5. **判斷附錄字母**

   若使用者未指定：
   - 讀取既有附錄字母（a, b, c, d, e, f, g, h, i）
   - 新附錄為下一個未用字母（j 起）

6. **產出草稿**

   寫入 `outputs/draft-appendix-<topic>.md`：
   - 開頭加上元資料區塊
   - 結尾加上人工 review 檢查清單

7. **產出摘要**
   - 草稿路徑
   - 涵蓋的素材數量
   - 建議下一步：人工 review → 移動至 `microsoft-agent-framework-tutorial/appendix-<letter>-<slug>.md` → `/regenerate-toc` → `/lint`

## 注意事項

- 附錄草稿同樣**不直接寫入 tutorial/**
- 附錄通常含大量 hyperlink，產出後需驗證連結存活性
- 對於含上游 sample 路徑的附錄，務必確認該路徑在 `agent-framework/` 目前的 commit 仍存在
