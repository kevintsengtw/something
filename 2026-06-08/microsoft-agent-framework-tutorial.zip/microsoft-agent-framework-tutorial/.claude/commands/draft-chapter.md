# /draft-chapter — 從 wiki 概念草擬新教學章節

**用法**：`/draft-chapter <wiki-concept> [chapter-number]`

範例：
- `/draft-chapter magentic-orchestration` — 自動選下一個可用章節號
- `/draft-chapter agent-skills 29` — 指定章節 29

從 `agent-framework-kb/wiki/concepts/<concept>.md` 草擬一份新教學章節，輸出至 `outputs/draft-<concept>.md`（**不直接寫入 tutorial 目錄**）。

## 設計原則

- **wiki 是 source of truth**：所有 API 名稱、簽名來自 wiki frontmatter（其又來自 raw/facts/）
- **codebase-memory-mcp 是驗證者**：草擬中提到的每個 API 名稱**都必須經圖譜驗證**才能寫入草稿
- **UA 補關係**：UA 知識圖譜提供「相關概念」段落的依據
- **草稿不直接落地**：產出 outputs/，避免污染 tutorial/

## 前置條件

- `agent-framework-kb/wiki/concepts/<concept>.md` 已存在
- 該條目通過 `/lint`（frontmatter 完整、api_name 圖譜可查驗）
- `agent-framework-kb/.understand-anything/knowledge-graph.json` 存在（為了找相關概念）

## 執行步驟

1. **讀取 wiki 條目**
   - 讀取 `agent-framework-kb/wiki/concepts/<concept>.md`
   - 解析 frontmatter：title、api_name、namespace、tags、tutorial_chapters、sources
   - 解析內文段落

2. **codebase-memory-mcp 結構性驗證**

   對 wiki 條目 frontmatter 與內文中的每個 API 名稱：

   **存在性確認**
   ```
   mcp__codebase-memory-mcp__search_graph
     project: "agent-framework"
     name_pattern: "<api_name>"
   ```
   - 查無 → 標記 `⚠️ 此 API 在圖譜未確認，待人工驗證`，**不寫入草稿**

   **取簽名**
   ```
   mcp__codebase-memory-mcp__get_code_snippet
     project: "agent-framework"
     qualified_name: "<qualified_name>"
   ```
   - 取得 signatures、file_path
   - 用於草稿的程式碼範例

   **取上游使用模式**
   ```
   mcp__codebase-memory-mcp__search_code
     project: "agent-framework"
     pattern: "<api_name>"
   ```
   - 從上游 samples/tests 找實際使用範例
   - 作為教學程式碼範例的依據

   **取依賴鏈**
   ```
   mcp__codebase-memory-mcp__trace_path
     project: "agent-framework"
     function_name: "<api_name>"
     direction: "inbound"
     depth: 1
   ```
   - 了解該 API 在上游被誰呼叫，輔助章節情境設計

3. **UA 相關概念查詢**

   讀取 `agent-framework-kb/.understand-anything/knowledge-graph.json`：
   - 找此 concept 節點
   - 取得 strongly-connected 鄰居節點作為「相關概念」段落來源
   - 取得 community cluster 同群其他節點作為「延伸閱讀」

4. **參考既有教學風格**

   讀取以下檔案作為風格基準：
   - `microsoft-agent-framework-tutorial/PLAN-beginner-tutorial.md`（章節規劃原則）
   - `microsoft-agent-framework-tutorial/README.md`（章節編號與分類）
   - 同類別最相近的既有章節（依 wiki tags 判斷）

5. **章節結構生成**

   按以下骨架草擬：

   ```markdown
   # 第 N 章：<繁中標題>

   > 對應 wiki 概念：[[<concept>]]
   > 上游 API：`<api_name>`
   > 引入版本：v<since>

   ## 本章目標
   ## 為什麼需要這個
   ## 核心概念
   ## 上手範例
   ## 進階用法
   ## 常見錯誤
   ## 相關章節
   ## 延伸閱讀
   ```

6. **判斷章節編號**

   若使用者未指定：
   - 讀取 `microsoft-agent-framework-tutorial/` 既有檔名
   - 找出最大編號 NN，新章節編號為 NN+1
   - 在草稿開頭以註解說明建議的編號與插入位置

7. **產出草稿**

   寫入 `outputs/draft-<concept>.md`（**不寫入 tutorial/**）：
   - 開頭加上元資料區塊（待補的位置、檢查清單）
   - 結尾加上「人工 review 檢查清單」

8. **產出摘要**
   - 草稿路徑：`outputs/draft-<concept>.md`
   - 圖譜驗證通過的 API 數
   - 標記為「待人工驗證」的 API 數
   - 建議下一步：
     1. 人工 review 草稿
     2. 滿意後手動移動到 `microsoft-agent-framework-tutorial/<NN>-<slug>.md`
     3. 跑 `/regenerate-toc` 更新 README 章節索引
     4. 跑 `/lint` 驗證

## 注意事項

- **草稿永遠不直接寫入 tutorial/**——這是設計約束
- LLM 在此指令中扮演「寫敘述」角色，但結構性宣告仍受 codebase-memory-mcp 約束
- 若 wiki 條目本身格式不完整（`/lint` 未通過），先修 wiki 再來草擬
- 一個 wiki 概念可以草擬多次，每次覆寫 outputs/draft-<concept>.md
