# 待確認事項與官方依據

## 需求狀態

已確認的環境、n8n、管理介面、按交易日／月底營業日的 POST 取得、10 分鐘等待、三種檔案及 SIT／UAT SFTP 要求列於 README.md。下表是正式開發接入外部資料時的待確認項；本次設計交付不要求現在提供全部資料。

「設計預設」是可用於模擬開發的起點，不是已獲公司核准的政策。正式啟用相關功能前，須把確認結果寫入對應規格與fixtures。

## 待確認清單

| ID | 要確認的資訊 | 設計預設或尚未設定 | 最晚確認階段 |
| --- | --- | --- | --- |
| OQ-01 | API URL、POST body 格式／編碼、Content-Type、query／headers、認證、重新導向、Proxy、TLS、限流、分頁、latest_only／by_date／保留範圍及不可取回證據 | method 已確認為 POST；其餘真實參數未設定，回應 JSON 不代表請求 body 為 JSON；不以暫時錯誤證明歷史已不可取回 | P0 契約，P3 真實 mapping 前 |
| OQ-02 | 各日／月 API 樣本、業務日期／月份及有效期語意、舊資料與未發布狀態 | 日資料核對目標日；月資料核對 target_month，不能由取得日推定 | P3 前 |
| OQ-03 | FXRate.c01、SNTCHR13C.txt 的文字版型／編碼；YYYYMM.xls 的樣板、工作表、型別、公式／格式 | 檔名及文字／XLS 已確認，內容未提供；不把 CSV／XLSX 改名 | P0 格式能力，P3 核定樣本 |
| OQ-04 | SIT 與 UAT 各來源主機、port、帳號、目錄與權限；核定端點身分 | 兩環境均必要，密碼由本機 Credentials 輸入；不是正式 SFTP | P0 能力，P4／P5 參數 |
| OQ-05 | SSH 主機金鑰信任方式；接收方是否忽略暫存檔、允許改名或同名覆寫 | 不自動接受變更或任意 host key；原生能力不足須補設計 | P0 能力與 P5 正式驗證 |
| OQ-06 | 公司交易日／營業日／月底營業日文件位置、版本與查詢契約，目標日／月及作業日對應、時區 | 不自行解釋；未知資格阻擋候選；Asia/Taipei 為設計預設 | P0 契約，P2 介接，真實啟用前 |
| OQ-07 | 各資料種類是否獨立交付，是否要求特定日資料同批到齊，補交順序 | 日／月分開；各種類獨立完成；不提供跨 SFTP 原子批次 | P2 前 |
| OQ-08 | 快照、輸出檔案、完成索引、設定、嘗試與 execution 的保存期、資料分類及容量 | 詳情 90 天、完成索引建議 1 年；未完成關聯不刪；摘要模式不保證保存所有原始 execution | P1／P5 |
| OQ-09 | 遠端會否即時取走正式檔、有無 receipt；不明結果可否自動重傳 | 不能證明結果就人工檢查，不盲目覆寫 | P4 前 |
| OQ-10 | 同日資料更正與重送規則，以及正式檔名可否容納修訂 | 一般排程不重送；更正需新 revision、原因及接收方政策 | P4 前 |
| OQ-11 | SIT／UAT 上傳者是單一開發電腦還是多台；操作者能否接受暫停排程後人工處理 | 單一SIT／UAT 上傳者；人工動作先暫停排空 | P0／P2 |
| OQ-12 | Windows 版號／支援範圍、Docker 核准版本／後端／虛擬化／資源與公司使用授權、n8n／擴充、登入啟動 | 不以 Win10／11 名稱保證相容；固定實測核准版本與 Linux 容器；單一 n8n 優先 | P0／P1 |
| OQ-13 | 每 10 分鐘重試的容許排程誤差 | 不早於 600 秒；閒置時可能晚約一個 60 秒檢查週期，繁忙／停機另計 | P0／P2 |
| OQ-14 | 各資料是否共用 API／同回應，是否必須共用取得時間，以及分頁語意 | 等價同輪合併一次 fetch；每資料種類獨立驗證，非等價請求不合併 | P0／P3 |
| OQ-15 | SFTP 暫時錯誤間隔、上限及核對／解除 BLOCKED 政策 | delivery_retry_minutes=10；暫時錯誤上限 null，永久錯誤需人工；UNKNOWN 不直接重送 | P4 前 |
| OQ-16 | Data tables 實際容量、告警／預留空間、明細歸檔、UI 查歸檔的方式 | P1 量測選定版本；開始紀錄無法保存就不發起外部動作 | P1／P5 |
| OQ-17 | 公司日曆適配器或核定人工匯入、維護責任、臨時異動與版本生效 | calendar_dates 保存公司已解析決策；未知暫停，不推算週末或月底 | P0／P1／P2 |
| OQ-18 | 本工具各來源開始時間、是否限制抓取時窗、延遲／跨日／跨月政策及 SIT／UAT 下游處理時間 | 已知 15:00–15:59／16:30–16:59／17:00–18:59 是上游時段，不當本工具截止；保留 10 分鐘等待要求 | P2 前，真實啟用前 |
| OQ-19 | SIT／UAT 固定日檔名的取走、保留、跨日替換、已知前版核對與補交順序 | 未核定不覆寫；舊週期不能蓋較新已發布檔；與同日更正分開 | P4 前 |
| OQ-20 | 原始檔欄位與正式 API 計算值的可逆性、精度、缺失資訊、核定公式／常數 | 缺資訊不捏造；需核定逆向矩陣與去識別化樣本，不直接讀正式 SFTP | P0 可行性，P3 前 |
| OQ-21 | 月 XLS 格式版本、樣板與資料有效月份、儲存格型別／位置及下游讀取要求 | 真正 .xls，不改名 XLSX；位元組恢復須固定序列化或原檔備份 | P0 能力，P3 前 |
| OQ-22 | 下游 SIT／UAT 讀檔、計算／入庫及 API 對照是否納入完整整合驗收 | 本工具核心完成為檔案交付；下游入庫另存證據，不由 SFTP 成功推定 | P4／P5 |

如果 OQ-07 改為指定來源必須到齊，應增加「指定週期批次準備完成」狀態後才啟動指定來源交付；仍不能承諾不同 SFTP 同時提交。若 OQ-11 改為多台共同處理，必須加入可驗證的跨實例協調與唯一性機制，不能讓相同 Data tables 複製品彼此猜測狀態。

## n8n 能力查證

官方文件描述目前產品能力，選定公司版本仍須實測。以下區分來源事實與本案設計決策。

| 項目 | 官方依據與範圍 | 本案處理 |
| --- | --- | --- |
| 排程 | [Schedule Trigger](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.scheduletrigger/) 支援固定間隔、每日時間與 Cron，且需發布流程 | 固定短週期檢查，流程讀設定再判斷每日開始／next time，不假定表格修改會改變已發布 Cron |
| 設定資料 | [Data tables](https://docs.n8n.io/data/data-tables/) 可由 UI 編輯並用於完成標記 | 保存設定與小型業務帳本；原子鎖及唯一索引沒有文件保證，不在第一版作此承諾 |
| 併行 | [Concurrency control](https://docs.n8n.io/hosting/scaling/concurrency-control/) 與 [執行環境變數](https://docs.n8n.io/hosting/configuration/environment-variables/executions/) | 需以公司版核對生產限制及手動排空，不把 instance-wide 限制當成資料庫交易 |
| 文字／XLS | [Convert to File](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.converttofile/) 提供 Text File 與 XLS 操作 | 只證明可選格式；公司版須驗證文字位元組、XLS 型別／樣板與下游相容，不等於已重建原檔 |
| 本機檔案 | [Read/Write Files](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.readwritefile/) 存取的是容器檔案系統 | 掛載 Windows 專用目錄並顯式允許路徑，寫入後讀回核對 |
| SFTP | [FTP node](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.ftp/) 與 [SFTP Credentials](https://docs.n8n.io/integrations/builtin/credentials/ftp/) 支援相關操作及帳密 | 固定分支選 Credential；下載核對、Rename 與覆寫語意須實測對端 |
| 主機金鑰 | [官方 Credential schema](https://github.com/n8n-io/n8n/blob/master/packages/nodes-base/credentials/Sftp.credentials.ts) 與 [FTP 實作](https://github.com/n8n-io/n8n/blob/master/packages/nodes-base/nodes/Ftp/Ftp.node.ts) 的 master 分支未提供一般 UI 可設定的 host key pinning | 不能把 master 結論當作所有版本；公司版確認後，必要時加核准節點／傳輸服務 |
| 執行查詢 | [View all executions](https://docs.n8n.io/workflows/executions/all-executions/) 提供篩選與 retry | 詳情供診斷；每日交付判定由業務帳本提供 |
| 保存 | [Manage execution data](https://docs.n8n.io/hosting/scaling/execution-data/) 說明自動清理 | 明確配置保存期與筆數上限；保留業務索引，不依 execution 永久存在 |
| 機密與檔案限制 | [Security environment variables](https://docs.n8n.io/hosting/configuration/environment-variables/security/) 與 [Encryption key](https://docs.n8n.io/hosting/configuration/configuration-examples/encryption-key/) | 密碼由 Credentials 保存，備份需保留解密能力，檔案存取限制於專用掛載 |

## Docker 與 Windows 依據

- [Docker Desktop settings](https://docs.docker.com/desktop/settings-and-maintenance/settings/)：可以設定登入時啟動。文件沒有使關機或未啟動 Docker 的電腦仍能執行本地任務。
- [Restart policies](https://docs.docker.com/engine/containers/start-containers-automatically/)：管理容器重啟，不是業務排程。
- [Bind mounts](https://docs.docker.com/engine/storage/bind-mounts/)：可讓容器產生檔案並保存至主機檔案系統。
- [n8n Docker installation](https://docs.n8n.io/hosting/installation/docker/)：資料卷保存 n8n 資料目錄；當前部署文件包含額外工具範例，這些不是本案必要組件。
- [Docker Desktop Windows requirements](https://docs.docker.com/desktop/setup/install/windows-install/)：主機版號、後端、虛擬化、資源及支援週期有條件；P0 依公司選定版本核對，不把文件中 Windows 10／11 範圍當成全部版本均可使用。

Data tables 的共享容量、警告及達限後寫入失敗行為以選定版本 [官方限制](https://docs.n8n.io/data/data-tables/) 為準；不能只量測 Windows 可用磁碟就略過表格限額。

[Docker Compose internal 網路](https://docs.docker.com/reference/compose-file/networks/#internal) 提供對外隔離設定。本案據此設計首次還原前的專用網路；UI 可達性、無額外網路／代理出口及阻斷效果仍須在公司選定版本驗證，不以設定欄位存在代替實測。

## 設計審查決策

本次採用：各來源／目的地獨立狀態、設定快照、業務帳本與 execution 分離、持久化 next time、未知結果先核對、官方版本能力驗證。

本次不採用：無條件 SFTP 節點自動重試；用 Data table Upsert 冒充原子鎖；為每個日常設定變更重建映像；把 PostgreSQL、客製網站、AI sandbox 或雲端當作單一任務的必要條件。

調整的設計：採每分鐘檢查而非固定每 10 分鐘就呼叫 API，確保前次取得完成後至少等 10 分鐘，並讓 UI 開始時間與重試間隔可讀取。採寫入後讀回驗證，不宣稱原生磁碟節點提供原子改名。跨日政策及各來源獨立交付是待確認設計預設，不視為使用者已確認。

## 公司契約依據

docs/08 記錄使用者提供的上游事實。交易日／營業日定義不由外部公開日曆取代，接續開發應讀公司專案文件；未取得文件時以明列的 fixtures 模擬。來源時段與新工具排程分離，新工具開始時間仍屬 OQ-18。
