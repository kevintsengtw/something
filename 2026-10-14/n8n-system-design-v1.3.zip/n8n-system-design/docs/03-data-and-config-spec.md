# n8n 資料與設定規格

## 日期與識別

`source_id` 是穩定的資料種類代碼，不是 API 端點；期交所、複委託及金控各有穩定代碼，可共用 api_id。DAY 使用 `target_date`（YYYY-MM-DD）與 observed_data_date；MONTH 使用 target_month（YYYY-MM）與 observed_data_month。target_period／observed_period 保存相應日或月週期，不能以取得時間互相代替。

事件時間保存 UTC ISO 8601 時間戳，例如 `2026-10-14T01:00:00Z`；UI 顯示時換算設定時區。純日期不做 UTC 轉換。所有下次執行時間以絕對時間保存，不只保存「剩餘 600 秒」。

| 識別 | 組成及用途 |
| --- | --- |
| job_key | `source_id + period_unit + target_period + revision`；初版 revision 為 1，日／月任務均適用 |
| artifact_id | 對應一個不可變輸出檔案的 UUID |
| delivery_key | `job_key + target_key + target_revision`；每個目的地版本獨立追蹤 |
| attempt_id | 每一次 API、產檔或傳輸嘗試的 UUID |
| config_version | 每次成功提交設定的版本識別 |
| api_id、request_key、fetch_id | 端點代碼、等價 POST 請求識別、每次實際 HTTP 取得的 UUID |

識別組合須使用無歧義的序列化或明確限制字元；不可讓分隔符導致不同組合碰撞。這是業務識別設計，Data tables 自動產生的 row ID 不是其唯一性保證。讀取識別若得到多列，就拒絕執行並記錄錯誤，不任意取第一列。

## 邏輯資料表

以下為邏輯 schema，不是已建立的資料庫。n8n 欄位支援與型別於 P0 確認。巢狀設定以 JSON 文字欄保存，流程先解析與驗證；不要假設 Data tables 原生支援 JSON 欄位、外鍵或跨列交易。

### 設定草稿 settings_draft

每個來源保留一份可編輯草稿。密碼不在此表。

| 欄位 | 邏輯型別 | 規則 |
| --- | --- | --- |
| source_id | string | 必填，穩定且不可重複 |
| enabled | boolean | 預設 false；生效後控制新任務及既有任務的暫停，不是全域排程發布狀態 |
| timezone | string | 預設 `Asia/Taipei`；同實例各來源須一致，變更走時區遷移 |
| period_unit | string | DAY 或 MONTH；兩種日匯率為 DAY，金控月匯率為 MONTH |
| schedule_policy | string | COMPANY_TRADING_DAY 或 COMPANY_MONTH_END_BUSINESS_DAY；依公司契約，不自行算日曆 |
| daily_start_time | string | 保留欄位名稱，指合格作業日的新工具開始時間 HH:mm；真實值待確認，不直接套上游時段 |
| acquisition_window_json | JSON text | 新工具抓取時窗／截止處理；預設無當日時窗截止，未確認不以既有服務結束時間填入 |
| upstream_schedule_json | JSON text | docs/08 已知上游時段的非執行中繼資料；不能驅動本工具排程 |
| retry_minutes | integer | 預設 10、最少 10；不得因換版或人工補跑繞過 600 秒及 Retry-After |
| api_id | string | 邏輯 API 代碼；實際是否等價仍由完整 request_key 判斷 |
| api_url | string | 公司確認的 URL；不能含 Token 或帳密 |
| api_method | string | 固定值 `POST`，屬已確認需求；提交非 POST 值時拒絕，不提供切換其他 method 的日常設定 |
| api_params_json | JSON text | 非機密 query／body／headers 及 body_encoding／Content-Type；依 API 契約確認，不因回應為 JSON 就假定 body 為 JSON；機密由 Credential 提供 |
| pagination_rule_json | JSON text | 明定 none 或選定 release 支援的分頁方式、終止條件與筆數限制 |
| api_route_key | string | 對應已配置的 API 節點與 Credential 路由 |
| request_timeout_seconds | integer | 正整數，P0 確認可用範圍；不得讓請求無期限占住唯一執行者 |
| history_rule_json | JSON text | latest_only、by_date、保留範圍與契約明定的不可取回回應 |
| period_rule_json | JSON text | 日或月的欄位路徑、格式、時區／有效期語意及目標週期對應；取代舊 date_rule_json |
| records_rule_json | JSON text | 資料列位置、篩選、筆數及空資料規則 |
| output_format | string | TEXT 或 XLS；不可由副檔名自行推定內部格式 |
| output_rule_json | JSON text | TEXT 引用核定 text_rule_json；XLS 引用核定 xls_rule_json，見 docs/08 |
| filename_pattern | string | FXRate.c01、SNTCHR13C.txt 為固定名；月檔使用目標月份模板，不要求全部含日期 |
| targets_json | JSON text | 已配置目的地 key、啟用及遠端目錄 |
| calendar_policy | string | 固定 COMPANY_PROJECT_RULES；舊 calendar_day 預設不適用此三來源 |
| calendar_id、calendar_version、calendar_contract_ref | string | 必填，公司文件／介面依據及解析決策版本；未知資格阻擋候選外部操作 |
| cross_period_policy | string | 跨日／跨月保留原目標，不自動放棄；取代舊 cross_day_policy |
| draft_note | string | 修改原因，不含機密 |

### 已提交設定 settings_versions

保存 `commit_request_id`、`config_sha256`、`config_version`、`source_id`、`submitted_at`、`submitted_by`、`validation_result`、不含機密的 `config_json`、對應 `workflow_release_id`。已提交版本不可直接修改；修改草稿再提交新版本。

一次提交使用穩定的 commit_request_id 與正規化設定摘要。中斷重試先讀回版本及生效指標；若已有完整且摘要一致的版本並已生效，回報同一次成功，不再新增版本。若只保存版本但未切換指標，驗證後完成原提交；有重複指標、摘要不同或指向不完整版本時停止並交人工核對。所有提交遵守串行管理程序。

commit_request_id 取自提交命令的 request_id。NOT_COMMITTED 表示證明 active 未切換；COMMITTED 表示讀回完整版本與指標一致；不能讀回時是 UNKNOWN，可能已生效，不能宣稱失敗未生效。同 ID 重試使用命令首次處理時保存的草稿快照，不讀後來被修改的草稿。已成功的舊命令再查看只回報歷史結果，不重新啟用其版本；回復舊設定需要新命令。

### 生效版本 settings_active

每來源一列，保存 `source_id`、`active_config_version` 及 `activated_at`。設定版本完整保存與驗證成功後，最後才切換此指標。更新指標失敗時，舊版本繼續生效；恢復時驗證指標確實指向完整可讀的版本。這是單一執行者的提交順序，不是跨表交易承諾。

### 週期任務 job_ledger

| 欄位 | 用途 |
| --- | --- |
| job_key、source_id、period_unit、target_period、revision | 日／月業務識別 |
| target_date、target_month、processing_date | DAY 的 target_date；MONTH 的 target_month；processing_date 為合格作業日，不能代替資料週期 |
| status | 任務狀態，見下節 |
| config_version、config_snapshot_json | 首次真正處理時使用的非機密設定 |
| workflow_release_id | 首次處理的邏輯發布版本；各次實際版本另外存在 attempt |
| processing_release_id | 目前允許接手的流程版本；遷移前與首次版本相同 |
| observed_data_date、observed_data_month、observed_period、record_count | 按 DAY／MONTH 保存回應業務週期與筆數 |
| next_attempt_at | 最早可重試的 UTC 時間 |
| last_fetch_id、last_fetch_completed_at、retry_after_until、recovery_observed_at | 請求關聯與可恢復的重試時計 |
| artifact_id | 已生成檔案參照，未生成時為空 |
| artifact_frozen_at | 曾有 READY artifact 後永久保留；目前缺檔也不能當成尚未凍結 |
| last_execution_id、last_attempt_id | 追查與中斷核對 |
| started_at、updated_at、completed_at | 生命周期時間 |
| error_code、error_summary | 限長且遮蔽機密的診斷 |
| action_reason | 最近人工動作原因 |
| phase、hold_reason | FETCH／GENERATE／DELIVERY；停用或全域維護是覆蓋控制，保留原 status |

### 檔案 artifact_ledger

保存 `artifact_id`、`job_key`、`status`、`filename`、容器內及相對歸檔路徑、預期及實際 `byte_count`、`sha256`、`record_count`、`created_at`、`verified_at`、輸出檔案規則快照。狀態為 `GENERATING`、`READY`、`INVALID` 或 `ARCHIVED`。

另保存 `payload_snapshot_path`、`payload_snapshot_sha256`、`expected_file_sha256`、`expected_byte_count` 及 `serializer_release_id`。快照只包含本來源輸出檔案所需的標準化資料、日期及排序依據，排除無關機密；不將完整 API 回應塞進 Data tables。

生成順序為保存 GENERATING 中繼資料、寫入並核對資料快照、依快照與設定生成輸出檔案、寫入並讀回核對、標 READY。只有 READY 可交付。中斷後以快照和凍結設定恢復，輸出檔案必須符合預期摘要。快照未完整、artifact 從未 READY 且無任何傳輸時，可將舊候選標 INVALID，再按抓取時計重新取得並建立新 artifact；保留舊嘗試。artifact 曾 READY 後，缺檔只能從完整快照重建相同位元組或由備份還原，不能以新 API 回應替代；無法核對就人工處理。不能以存在代表完整。

不承諾原生磁碟節點具有原子檔案改名。若公司有直接讀本機輸出檔案的下游程序，須另定暫存轉正式的可見性規則及所需節點，不能讓下游讀 `GENERATING` 的檔案。

### 目的地交付 delivery_ledger

| 欄位 | 用途 |
| --- | --- |
| delivery_key、job_key、target_key、artifact_id | 不變的交付識別 |
| status | `PENDING`、`UPLOADING`、`RETRY_WAIT`、`UNKNOWN`、`BLOCKED`、`SUCCEEDED`、`MANUAL_REVIEW`、`CANCELLED` |
| credential_route_key | n8n 節點憑證路由，不含密碼 |
| endpoint_identity、target_revision | 主機／port／帳號／命名空間的非機密身分及不可重用版本 |
| remote_directory、final_path、temp_path | 首次交付前凍結的遠端位置 |
| expected_sha256、expected_byte_count | 核對依據 |
| attempt_count、next_attempt_at | 目的地自己的嘗試及重試時間 |
| delivery_retry_minutes、delivery_max_attempts | 從目的地設定凍結；預設間隔 10，次數上限 null 表示不限暫時錯誤嘗試 |
| last_transfer_step、step_started_at | PRECHECK、PUT_REQUESTED、PUT_CONFIRMED、RENAME_REQUESTED、RENAME_CONFIRMED；外部步驟前先保存 |
| last_execution_id、last_attempt_id | 錯誤追查 |
| last_error_code、last_error_summary | 遮蔽機密的錯誤 |
| uploaded_at、verified_at、confirmed_at | 不同階段時間，不混成單一時間 |
| verification_method、confirmation_note | 節點成功、下載摘要核對或人工確認依據 |

### 嘗試紀錄 attempt_log

每次實際嘗試追加 attempt_id、execution_id、scope_type、scope_key、可選 job_key／delivery_key／fetch_id／admin_request_id、關聯 job_keys_json、階段 FETCH/GENERATE/UPLOAD/RECONCILE/ADMIN、起迄時間、結果、觀測日期、錯誤摘要、原因、設定版本、實際 workflow_release_id。共用 fetch 只有一個 FETCH attempt，關聯多個 job；設定提交等非任務管理不強塞 job_key。沒有外部操作的每分鐘檢查不新增 attempt。中斷紀錄保留 INTERRUPTED 或 UNKNOWN，不刪除掩蓋失敗。

### 維護控制 system_control

單一 control_key=main 列，保存 maintenance_mode、restore_reconciliation_required、schedule_was_published、maintenance_request_id、maintenance_started_at、operator_label、capacity_hold，以及 restore_hold_from、restore_hold_through、affected_sources、restore_held_periods_json。缺列或重複時停止自動外部操作。新實例首建預設 maintenance_mode=true；既有實例正常重啟讀取原 flags，不重新暫停已驗證排程。部署／憑證／發布驗證後由管理者解除；還原必須先隔離啟動。

這張表的維護開關允許管理者依操作程序直接編輯，不屬任務帳本狀態修改。所有自動外部操作前檢查門檻；開關不能撤回已開始的傳輸。所有寫入型管理請求只在維護及排空確認後執行。保存原全域發布狀態，處理完成只恢復原狀。

### 管理命令 admin_requests

欄位為 request_id、status、operation、source_id、可選 job_key／delivery_key、reason、operator_label、requested_at、input_snapshot_json、started_at、finished_at、execution_id、outcome、result_json。operation 的完整清單及輸入以本文件「管理命令輸入契約」為準。機密不作命令輸入。

管理者手動執行「建立管理請求」產生 DRAFT 與 UUID，在表格填值後改 SUBMITTED，再執行「處理下一筆管理請求」。處理器只領取最早一筆，先凍結輸入再設 PROCESSING。狀態為 DRAFT／SUBMITTED／PROCESSING／SUCCEEDED／REJECTED／UNKNOWN；outcome 按操作記錄 COMMITTED、NOT_COMMITTED 或核對結果。UNKNOWN 必須以同一 ID 核對；不能越過未解決寫入請求。重新執行已成功 ID 只回報既有結果。

operator_label 由可信任本機管理者填寫；選定版可取得登入身分時可另外記錄，不能把文字標籤冒充已驗證的授權或不可否認稽核。原生表格沒有並行鎖，仍遵守單一操作者、排空及一次一命令的前提。

### 發布日曆 calendar_dates

欄位為 calendar_id、calendar_version、date、expected（可空）、period_unit、target_period、calendar_contract_ref、reason、updated_at、operator_label。此為公司日曆適配器的已解析、版本化決策；可由核定介面匯入或由管理者按公司文件登錄，不重新定義交易日。缺漏或 expected=null 時保留候選，設 CALENDAR_UNRESOLVED 的 hold_reason，不抓取、不上傳，也不標 NOT_EXPECTED。只有依據明確的 expected=false 才可免交付。臨時異動使用新版本，既有未凍結任務受控套用；READY 任務不因換版撤銷。

### 共用取得 fetch_ledger

保存 fetch_id、api_id、request_key、period_unit、target_period、job_keys_json、status、started_at、completed_at、retry_after_until、execution_id、attempt_id 及非機密錯誤。request_key 由完整已解析的 URL、固定 method=POST、參數、API 憑證路由及目標日／月正規化產生，不含秘密；同輪只有完全等價且到期的任務共用。FETCH 成功只表示 HTTP 完整取得，個別 mapping 可各自成功、等待或設定錯誤。

本案所有匯率請求，包括首次取得、重試、歷史查詢及分頁，均使用 POST。body 編碼、Content-Type、日期與分頁參數的位置依公司契約配置；等價比較包含 body 內容與編碼，不合併不同 body 的請求。重新導向必須保持 POST；選定 HTTP Request 節點若會改變 method，須停用該重新導向或另定保留 POST 的核定策略。未確認重新導向契約前不自行改送其他端點。

分頁結果須完整且一致才給 mapping；任何分頁未完成不能產部分輸出檔案。分頁中斷視為該 fetch 尚未完整取得，按時計重試，不把首頁新鮮日期當成整份有效。已完成來源不重新採用後續 fetch；未產檔者若沒有耐久快照，不跨 execution 復用已遺失的 HTTP 記憶體內容。

分頁第一頁及所有後續頁均使用 POST；頁碼／游標依已核定位置填入 body 或 query。分頁規則不得另設其他 method，服務回傳的下一頁參照也不能覆寫固定 POST。分頁失敗後重新取得的各頁同樣適用。

## 輸出檔案與逆向 API 對應契約

`period_rule_json` 與 `records_rule_json` 須由去識別化的真實樣本導出，欄位名稱在取得樣本前保持待定。API 路由、認證方式與分頁策略同樣待定。不得預設 JSON 一定有 `date` 或 `rates`。

輸出分為 TEXT 與 XLS，格式與必要欄位契約見 docs/08。兩種文字檔須確認固定寬度或分隔格式、編碼、BOM、行尾及字面；月檔須確認真正 XLS、工作表、位置、型別、公式／值與樣板。不得使用通用 CSV 寫入再改副檔名。P0 探測 Text／XLS 節點，P3 依核定逆向 mapping 與下游讀檔契約驗證；原生不足才設計 UI 可設定的核准擴充。

路徑與轉換採明確規則：欄位路徑以 path_tokens 陣列保存物件 key 與數字索引，不執行任意運算式；資料列規則指定陣列／單物件與分頁策略。轉換只接受 release 已驗證的 registry ID，至少定義 identity、text、decimal、date、constant 的參數與錯誤行為。未知轉換、日期解析器或編碼 ID 在提交時拒絕。真實樣本若需新增 ROC 日期等解析，透過新 release 的可編輯流程補齊，不猜測格式。

固定日檔名不帶日期；月檔名來自 target_month。本機歸檔使用來源／period_unit／target_period／revision 目錄以避免覆蓋；遠端正式檔名由接收方規則決定，不擅自加入 revision 或 UUID。遠端暫存名稱可含 artifact ID，前提是接收方忽略暫存檔且允許改名。

模板語法由本案固定：允許固定字面檔名及 {source_id}、{target_date:yyyyMMdd}、{target_date:yyyy-MM-dd}、{target_month:yyyyMM}、{revision}；未核准的佔位符拒絕。revision 是否放進正式檔名仍依對端政策。不同來源不得保留同一 endpoint_identity／正式路徑供不同內容交付；提交時檢查模板碰撞，執行前再檢查實際路徑，衝突轉人工處理。

## 任務狀態機

```mermaid
stateDiagram-v2
    [*] --> PENDING
    PENDING --> FETCHING: 到合格作業日的開始時間
    WAITING_DATA --> FETCHING: 重試時間到期
    WAITING_API_RETRY --> FETCHING: 重試時間到期
    FETCHING --> WAITING_DATA: 資料尚未到目標週期
    FETCHING --> WAITING_API_RETRY: 暫時連線錯誤
    FETCHING --> CONFIG_ERROR: 結構或設定錯誤
    FETCHING --> GENERATING: 日期與資料有效
    GENERATING --> ARTIFACT_READY: 快照與輸出檔案核對成功
    GENERATING --> CONFIG_ERROR: 產檔問題
    ARTIFACT_READY --> DELIVERING
    DELIVERING --> DELIVERY_RETRY: 尚有可重試目的地
    DELIVERY_RETRY --> DELIVERING: 目的地到期
    DELIVERING --> MANUAL_REVIEW: 無其他可處理者且有待人工核對
    DELIVERING --> CONFIG_ERROR: 無可處理目的地且只剩 BLOCKED
    DELIVERING --> COMPLETED: 全部目的地成功
```

其他管理狀態為 `MISSED`、`NOT_EXPECTED`、`CANCELLED`。`CONFIG_ERROR` 保留所處階段與 artifact 參照；修正後回到待抓或待交付，不能總是重新生成輸出檔案。`MANUAL_REVIEW` 的恢復必須有核對結果或人工決策記錄。

`COMPLETED` 表示該 job 凍結的所需目的地全部 `SUCCEEDED`。一個目的地成功不代表整個任務成功；另一來源是否完成不影響本來源的完成狀態。`NOT_EXPECTED` 表示經核定日曆免交付，顯示「無需交付」，不顯示成已上傳成功。全來源皆 COMPLETED 或 NOT_EXPECTED 時，日彙總顯示「當日需求已滿足」，另列實際交付數。日彙總是帳本的計算結果，不是跨 SFTP 交易。

無 artifact 的 CONFIG_ERROR 阻擋該資料種類抓取／生成。READY 後 job 狀態是交付集合的彙總：先判全部成功；有可執行或等待到期的 PENDING／RETRY_WAIT，則保持 DELIVERING／DELIVERY_RETRY；其他目的地 BLOCKED／MANUAL_REVIEW 不停止這些候選。沒有可處理者才彙總為 MANUAL_REVIEW、CONFIG_ERROR 或 CANCELLED。UNKNOWN 只允許核對，不直接 put；核對不能進行時改為目的地 MANUAL_REVIEW。至少 SIT、UAT 各一個必要啟用目的地才允許建立真實交付任務，空集合不能因全部成功條件而完成。

## 上傳與不確定結果

傳輸開始前保存 `UPLOADING`、正式及暫存路徑。只有暫存上傳成功後才執行遠端 Rename。Rename 的原子性、覆寫及接收方觸發方式由對端核定；不因同一目錄就假定改名有所有需要的保證。

首次及每次重新傳輸先檢查同名正式檔。存在且內容一致可按核定確認政策補登，不同內容不覆寫。若無讀回權限，只有對端確認的首次傳輸規則可繼續；結果不明或同名狀態不可證明時交人工。PUT_REQUESTED、RENAME_REQUESTED 必須在動作前保存；保存開始紀錄失敗不能執行外部動作。

傳輸或改名後連線中斷時改為 `UNKNOWN`，先檢查正式檔。可以下載且 SHA-256 與大小相符時，補登成功；正式檔不存在時，再檢查暫存檔與未完成步驟；大小相同但不能證明內容相同，不足以自動判定成功。無讀取權限、正式檔已被接收方取走或內容不同，都交 `MANUAL_REVIEW`。沒有接收方 receipt 的情況下，無檔案也不能證明從未交付。

一般成功的證據至少是上傳與改名操作確認；是否必須每次下載比對，依接收方讀取權限與確認政策決定。不確定結果的自動恢復要求比一般成功更強的內容核對。任何結果都不表示下游已完成匯入。

只有證據顯示 Rename 從未被發起、正式檔未交付，且對端忽略暫存檔時，才可核對暫存後重新 put 或執行尚未開始的 Rename。若 Rename 曾被發起，正式檔不存在且沒有 receipt 不能視為沒交付，即使暫存還在也不得盲目重送。

目的地暫時連線錯誤在能證明未發生寫入時，設 RETRY_WAIT，next_attempt_at=失敗完成時間+delivery_retry_minutes。登入或權限問題是 BLOCKED，修正後以 RETRY_DELIVERY 命令解除；UNKNOWN 先 RECONCILE。delivery_max_attempts 是可選目的地政策，達上限改 MANUAL_REVIEW；不將 API 未發布的無任意上限規則混用為登入錯誤無限嘗試。

## 停機與跨日恢復

恢復時先讀業務狀態與對應 execution。只有確認上一執行已終止，才接手 `FETCHING`、`GENERATING` 或 `UPLOADING`；無法確認則人工檢查。單靠經過一段時間不能視為已取得排他鎖。

沒有 artifact 的當日未完成任務，按保存的 `next_attempt_at` 接續；有 `READY` artifact 的任務只接續交付；已成功目的地略過。當天經公司規則判定為交易日且已到本工具開始時間，才建立 DAY 任務；MONTH 依月底營業日與核定目標月份建立。

日資料跨日預設不自動截止：原任務保留原 target_date，若 API 可查原目標日／月則持續取得該日資料；新的日期另外建立任務。只提供最新資料的 API，不能把新日資料塞入舊日檔。證明原日期已無法取得時轉 MANUAL_REVIEW，保存未交付事實，由管理者決定補資料或以原因標 MISSED；未確認前不能以午夜自動放棄。已產檔的前日任務保留並補交。若公司核准明確截止政策，再調整設定及驗收。

交易日／月底營業日依公司契約。資格未知的候選以 hold_reason=CALENDAR_UNRESOLVED 保留且不做外部操作；不自行猜週末、假日或月底。公司依據確定免交付才為 NOT_EXPECTED，保存理由與版本。

不可取回的證據只能是核定 API 契約的 latest_only／歷史保留範圍，或 history_rule_json 明列的確定回應；連線失敗、單次日期不符或 HTTP 5xx 都不是證據。轉 MANUAL_REVIEW 後停止該舊任務自動 API 請求，仍保存未交付狀態並處理新日期。解除須由管理命令補入可驗證資料、啟用已核准歷史查詢，或以原因標 MISSED，不能自動丟掉。

## 抓取與換版時計

一般下次到期取 max(last_fetch_completed_at+600 秒、last_fetch_completed_at+retry_minutes×60 秒、retry_after_until)。首次沒有前次 fetch 才依公司已判定合格的作業日與新工具開始時間。Retry-After 的秒數或日期先解析為絕對時間，無效時至少維持 600 秒。未產檔換版可重算較長門檻，不能早於已保存的 Retry-After 或 600 秒下限；只改設定不立即再抓。

中斷時已保存完成時間就沿用；完成時間未知時，在確認 execution 終止後保存 recovery_observed_at，以此再等至少 600 秒。共用取得的相關等待任務引用同一 completed_at。人工 RETRY_FETCH 同樣遵守下限，不繞過 API 節流。

時計只決定 POST 請求何時可再次發出，不改變 method。重試使用任務已凍結或受控換版後的請求設定；日期未到、暫時錯誤、429、分頁失敗、重啟恢復及人工補抓均不得改用其他 method。

## 保存與設定異動

Executions 預設保留 90 天，且不能因筆數上限更早清除而宣稱保證 90 天。業務完成索引至少覆蓋允許補跑期間，建議保留 1 年；實際保存及清理政策在 OQ-08 確認。未完成／待核對 artifact 不能因年齡自動刪除。恢復備份前，先核對其時間點與遠端現況，避免倒退狀態後直接重送。

已提交的非機密設定版本不可直接修改。Credential 由 UI 更新密碼，後續連線採新值；主機、帳號或路徑異動可能改變目的地身分，不能只以密碼更新規則處理既有交付。此類異動須建立新 Credential／路由及不可重用的 target_revision，供新任務引用。第一版禁止既有 delivery 改送新端點；舊端點不可用時保留 BLOCKED／MANUAL_REVIEW，管理者可有原因地取消，但不能記為已交付。CREATE_CORRECTION 用於資料更正，不代替路由遷移；若業務需要遷移，須先新增命令、交付識別與驗收規格。

## 跨表核對與發布識別

每次恢復或下一輪處理前，驗證下列不變條件：

1. 每個 job_key、artifact_id、delivery_key 讀到的列數符合預期；重複列不自動選擇。
2. READY artifact 必須有一致的 job_key、設定快照、大小及摘要。job 未連結 artifact 時，只能在唯一候選且檔案證據一致時補連結，否則人工核對。
3. 任務所需目的地集合以凍結快照為準。每個必要 delivery_key 恰好一列且 SUCCEEDED，才能補登 job COMPLETED；缺列、額外目標、重複或 UNKNOWN 都不能自動完成。
4. 傳輸狀態與 attempt 若未同步結束，保留中斷事件，核對遠端後補登；不得因 attempt 沒結束就假定遠端沒收件。
5. 設定 active 指標必須指向完整且摘要正確的版本；孤立的未生效版本不被自動流程採用。

恢復流程可在缺失的 delivery 列尚未發生傳輸且證據完整時補建；其他不一致進 MANUAL_REVIEW。上述順序是可恢復的串行操作，不是多表交易。

工作流程版本以選定 n8n 版本可可靠取得的發布識別為優先。若無支援的執行期欄位，使用管理者發布時同步更新的 workflow_release_id，放在流程第一個整理節點並與無機密匯出清單核對。job 保存首次使用的版本，attempt 保存每次實際執行版本；不同版本接手未完成 job 時，先做受控相容性確認與遷移紀錄，不假定舊快照代表實際程式未改。

每次發布產生不可重用的 release ID；後續開發保存 releases/<release_id>/manifest.json，記錄文件基準、n8n 版本、schema 版本、工作流程識別與無機密匯出 SHA-256、支援的轉換 registry、相容性說明及發布時間。此為交付契約，本次不建立實際發布檔。新任務要求生效設定 release 與實際流程一致；舊任務要求 processing_release_id 與當前流程一致，否則停止該任務寫入並要求 MIGRATE_RELEASE，不從不一致版本交付。

發布程序須在維護／排空下同步標記、匯出與提交相容設定，讀回核對後再恢復原排程。遷移保留首次版本、舊設定與 artifact，記錄 from/to、理由及相容性；已 READY 檔案內容不因遷移重新生成。

修訂交付在取得接收方更正政策前不得開始。政策必須選定新版本檔名、同名覆寫與接收方重讀方式，或禁止補送；兩個版本與每個目的地的成功紀錄分開保留。修訂部分成功後重啟，只接續同一修訂未完成者，不重送初版。

一般交付同名不同內容預設阻擋。正常跨週期替換若經 OQ-19 核定，依 docs/08 的具名政策核對本工具已知前版、保存原／新週期與摘要，不能與資料更正混用；較舊週期不得自動覆蓋已發布的新週期。同週期更正有受控例外：CREATE_CORRECTION 已核准同名更正時，保存原 revision／預期原摘要／新摘要及接收方政策，先核對既有內容是指定原版才允許核定替換。內容已被別人改動或無法證明原版時仍交人工檢查。此例外不解除 UNKNOWN 的核對門檻，也不讓一般重試變成強制覆寫。

共用 request_key 的請求定義包含 timeout、history 與分頁策略。api_id 相同但 HTTP 定義或版本不同的任務不合併，提交時提示差異；不要求兩來源設定必須以不存在的跨表交易同時換版。如果 OQ-14 要求同一回應時間，須改為單一共用 HTTP 設定版本再同步引用，列為確認後的設計變更。calendar_version 被引用後不可原地修改，提交設定保存 calendar_sha256；讀回不符就阻擋該來源，不能把資料表被修改當成合法新日曆。

settings_versions.submitted_by 取自 admin_requests.operator_label；沒有可驗證的登入資訊時只是操作者聲明。delivery attempt_count 計入實際傳輸連線嘗試，包含首次，不計純核對與查閱；可選上限須為正整數。到上限後需有原因的管理請求重新開放，保留既有計數與歷史，不把它清零掩蓋失敗。

## 管理命令輸入契約

下列寫入命令一律需要 reason、唯一 request_id、已排空與維護模式。恢復時先讀已凍結的 input_snapshot_json；同 ID 不重新讀取操作者修改後的資料。可在不同階段拒絕不具備條件的動作，不將拒絕當成已完成交付。

| operation | 必要目標與輸入 | 規則與結果 |
| --- | --- | --- |
| COMMIT_CONFIG | source_id、草稿快照 | 驗證與提交版本，以 active 讀回決定三態 |
| RETRY_FETCH | job_key | 只對從未凍結 artifact 的可取回任務排定抓取，仍遵守時計 |
| RETRY_DELIVERY | delivery_key | READY、非成功、已解除 BLOCKED 或到期重試；UNKNOWN 不得直接重送 |
| RECONCILE | delivery_key、可選人工確認依據 | 核對遠端／receipt，不能只寫成功字樣 |
| RECONFIGURE_JOB | job_key、new_config_version | 從未凍結才可換版；保留舊快照事件、重算時計、使舊候選失效 |
| CANCEL | job_key | 取消全部未成功目的地，保存 status_before_cancel；成功者不改動 |
| RESUME | job_key | CANCELLED 恢復原階段及目的地原狀態；MISSED 需確認可取回政策才回待抓。UNKNOWN 不變 PENDING；來源停用仍須先重新啟用 |
| MIGRATE_RELEASE | job_key、from/to、相容性依據 | 更新 processing_release_id 與遷移事件，不改已 READY 內容 |
| CREATE_CORRECTION | 原 job_key、新設定／資料依據、接收方政策 | 分配下一個 revision，保留原版；只有核准規則可替換同名內容 |
| RESOLVE_MISSED | job_key、不可取回／放棄依據 | 保留未交付原因，改 MISSED；不得自動從舊日期偽造今日內容 |
| COMPLETE_RESTORE | backup_id、核對範圍與結果參照 | 確認舊狀態差距已處理或隔離為人工項，再解除全域還原門檻 |
| READ_ARCHIVE | 歸檔識別與查詢范围 | 查已驗證歸檔摘要／明細，不變更交付狀態 |

status_before_cancel 保存於 job 與受取消影響的 delivery。管理結果另有有界的 before／after 快照與原因；不必保存機密。建立新 revision 時若已存在同識別，核對同 request 的結果，不再加一次 revision。

任何 artifact 曾 READY，或存在已驗證的 READY 中間寫入證據，都要保留／補登 artifact_frozen_at；不得以 INVALID、ARCHIVED 或檔案被刪除解除凍結。更換內容只能走 CREATE_CORRECTION。calendar_dates 的 calendar_id＋calendar_version＋date 同樣須檢查重複列，不能任取一筆免交付。

targets_json 每項必須有 target_key、target_revision、environment、required、credential_route_key、endpoint_identity、enabled、remote_directory、delivery_retry_minutes、delivery_max_attempts 及 confirmation_policy。真實任務至少有 SIT、UAT 各一個啟用且必要的路由，不接受 PROD；confirmation_policy 指明一般成功與 UNKNOWN 核對需何種證據。新增 host／port／帳號需新 Credential 路由，第一版不提供原地遷移舊 delivery。

還原核對範圍包含備份後可能已發生、但備份內尚未建立的日期任務與修訂。保存 restore_hold_from、restore_hold_through 與 affected_sources；保存 restore_held_periods_json，明列來源、period_unit 與 target_period；月任務不能只用日期範圍推斷。沒有足夠證據的缺失任務不得自動建立為可交付工作，可建立 MANUAL_REVIEW 佔位，待核對／有原因的人工決定。COMPLETE_RESTORE 可解除全域暫停讓新日期運作，但不自動解除這些逐任務保留。若已由接收方確認交付而明細遺失，記錄人工確認與停止重送原因，不偽造 artifact 摘要。

## 容量與還原控制

P1 量測 Data tables 的實際限額、列寬與每日最壞增長，另量測 execution 與輸出檔案／快照磁碟用量。管理介面警告或保守估算接近上限時先封存；無支援的容量讀取介面時，不宣稱精確自動監控。容量門檻、預留空間及實際讀取方式寫入部署決策，資料寫入被拒絕時停止新外部操作，恢復容量後先核對 UPLOADING。

已結束的舊 attempt 可先寫入／讀回驗證歸檔，再由 maintenance 中清理明細；未完成 job、delivery、設定快照及 UNKNOWN 證據保留。已結束的 API 等待嘗試可封存，不要求整個 job 必須完成。attempt_archive 保存範圍、筆數、路徑、摘要及關聯識別，READ_ARCHIVE 在 UI 提供核准期間內的追查。封存不是刪除成功完成索引，也不能在歸檔寫入失敗時先刪原列。

備份／還原有 backup_id、時間點、版本、檔案摘要清單及加密金鑰存放參照，不含明文秘密。還原先以阻斷真實 API/SFTP 的方式啟動，將全域排程停用並設 restore_reconciliation_required；逐筆核對備份時間點後可能成功的交付。無 receipt 且遠端已取走時保留 MANUAL_REVIEW，不宣稱可自動知道結果。未解除全域門檻前不允許自動抓取或上傳。

還原的隔離先於 n8n 首次啟動：接續開發時提供專用還原 Compose 設定，使 n8n 只連接專用 `internal: true` 網路，不同時連接 default／外部／host 網路，不掛載 Docker socket，也不提供轉送外部請求的代理。本機 UI 綁定 loopback 的可達性及對外阻斷均在 P1 用無機密探測端點驗證，不假定各 Docker 版本相同。隔離設定未驗證時不得啟動含舊排程的還原資料；如公司環境不支援此方式，先設計並驗證主機層的阻斷方式。隔離期間設定全域門檻、停用舊排程並確認排空後，才可恢復網路以執行受控核對；恢復網路不等於解除還原門檻。T54 必須證明啟動前與啟動後隔離有效，以及缺失任務的保留規則。

## v1.3 週期、格式與環境契約

period_unit=DAY 時 target_period=YYYY-MM-DD，target_date 同值且 target_month 為空；MONTH 時 target_period=YYYY-MM，target_month 同值且 target_date 為空。processing_date 是公司規則判定的交易日／月底營業日，不能作月資料的日期替代。observed_period 由回應及核定 period_rule_json 抽取；月資料以目標月份及核定有效期核對，不要求 JSON 日期等於今日。

舊日資料的跨日恢復、人工命令及公平輪替同樣延伸到月資料，按原 target_period 接續；當月只有一個一般 revision=1 任務。只依新開始時間建立已判定合格的週期，未知候選不建立可執行 fetch。company calendar 決策與目標月份對應未確認，真實 enabled 不得提交為 true。

產檔 artifact 保存 output_format、output_rule_json 快照與 expected_file_sha256；原 payload_snapshot／serializer_release／凍結規則皆保留。TEXT 的位元組 fixture 與 XLS 的內容／型別相容分開驗收；已 READY 的 XLS 恢復仍必須同位元組摘要，不以內容看似相同放寬。模板固定日名及月模板由來源契約驗證。job_key 的新組成屬 schema 變更，接續開發不可混用舊鍵；目前尚無實作資料需遷移。

delivery 除 environment=SIT 或 UAT 外，保存 required=true、replace_policy_id、predecessor_artifact_id、predecessor_period 及 predecessor_sha256（尚未核定替換時留空）；env 標籤必須與核定端點身分對照。尚未核定跨週期替換時維持 BLOCKED／MANUAL_REVIEW。同名路徑逐一核對前一未確定傳輸；不能開始新週期覆寫未解 UNKNOWN。READY 任務的必要 SIT／UAT 目的地凍結後，不能刪除失敗環境讓 job 看似完成。

### 日曆未知候選與格式 schema

未知日曆資格先存在 calendar_dates 的 expected=null 決策列，保存 source_id 或 calendar_id 關聯、date、hold_reason=CALENDAR_UNRESOLVED 及解析錯誤；尚未有目標月份時不強造 job_key。UI 可按來源及候選日期查看；取得決策後才建立相應 job 或免交付紀錄。已建立任務重驗資格未知時保存原狀態及 hold_reason，不能直接變成 NOT_EXPECTED。

output_rule_json 是具判別欄位的規則：format=TEXT 時只有 text_rule_json；format=XLS 時只有 xls_rule_json。與 output_format 不符或缺核定 serializer／template 參照則拒絕提交。舊 csv_rule_json、date_rule_json、expected_csv_sha256 不作 v1.3 可執行欄位；本包只有文件，後續初建採新 schema。
