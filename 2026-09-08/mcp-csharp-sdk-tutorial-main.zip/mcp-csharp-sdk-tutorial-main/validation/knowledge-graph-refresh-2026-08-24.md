# Knowledge graph 狀態修正與快照審查記錄

## 結論

- 日期：2026-08-24
- 上游基準：ModelContextProtocol v2.2.0，commit `6fa3825973949a9c4f0cd8af344e15a8db09dc35`
- 結果：✅ 通過；過時狀態文字已修正，正式 knowledge graph 已由最新 wiki 重新產生並安全發布

## 修正範圍

- `mcp-csharp-sdk-kb/UPSTREAM-REF.md`：將「facts/wiki 待更新」改為 source/raw、facts/wiki 與正式 knowledge graph 均已對齊 v2.2.0。
- `mcp-csharp-sdk-kb/wiki/drift-report.md`：將「仍需刷新 knowledge graph」改為已完成刷新與 release lint 的實際狀態。

未修改 guide、raw 素材、facts、graph augmentations 或唯讀的 `csharp-sdk/`。

## Staging 與差異審查

- 在 repository 外的 `/tmp` staging 重建，不直接寫入正式 snapshot。
- 重建結果：35 articles、10 topics、39 entities、25 claims，共 109 nodes、280 edges、10 layers、9 tour steps。
- validator：零 error、warning、orphan node、orphan concept、遺失節點或遺失語意邊。
- 與正式 baseline 比對後，非 `article:drift-report` 的圖譜內容完全一致；預期差異只有該 article 的修正文與重新分析時間。
- Understand-Anything 2.7.5 Dashboard 成功載入 staging JSON，顯示 10 layers 與 9-step tour；瀏覽器 console 無 warning 或 error。

## 發布後驗證

- publisher：以 `--confirm-publish` 完成 rollback-safe 發布。
- post-publish validator：通過，109 nodes／280 edges。
- `node scripts/test-knowledge-graph.mjs`：通過 reproducible build、baseline migration、dangling-edge rejection 與 publisher rollback 測試。
- `node scripts/lint-docs.mjs`：通過 8 組檢查，包含 10 個狀態檔 stale-state phrase 與正式 knowledge graph 驗證。

## 正式產物

- `knowledge-graph.json` SHA-256：`4087d5fd1dba2fbe29830a61cd47c35c3199745693265538b0aba292b508970d`
- `meta.json` SHA-256：`14026b411f13fe3809547002d13ba1b6972bc45177407670b0d0e3c91817442e`
- `lastAnalyzedAt`：`2026-08-24T03:51:54.435Z`
