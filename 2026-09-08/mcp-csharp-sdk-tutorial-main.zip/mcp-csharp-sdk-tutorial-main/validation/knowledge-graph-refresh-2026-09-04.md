# 知識圖譜更新記錄 — 2026-09-04

> 觸發：v2.2.0 codebase-memory-mcp 七項探測重跑（6/7）後，發現 `wiki/` 條目把索引工具產生的 `in_degree` 當成 SDK 事實引用。
> 上游：`csharp-sdk` @ v2.2.0 (`6fa3825973949a9c4f0cd8af344e15a8db09dc35`)，worktree 全程唯讀且 clean。
> 執行者：Claude Code（依 `.agents/skills/snapshot-knowledge/SKILL.md` 流程）。

---

## 1. 變更動機

`raw/facts/codebase-memory-mcp-validation.md` 第 3 節證實：**鏈式 fluent 擴充方法的 CALLS 邊只接到鏈首**，鏈上後續方法的 `in_degree` 一律為 0。實測 v2.2.0：

| API | wiki 原本引用 | v2.2.0 實際 |
|-----|--------------|------------|
| `WithToolsFromAssembly` | 4 | **0** |
| `WithPromptsFromAssembly` | 3 | **0** |
| `WithResourcesFromAssembly` | 3 | **0** |
| `WithStdioServerTransport` | —（未引用） | **0** |
| `WithResources` | 8 | 3 |
| `WithPrompts` | 7 | 3 |
| `MapMcp` | 78 | 32 |
| `AddMcpServer` | 153 | 171 |
| `McpClient.CreateAsync` | 99 | 155 |

四個歸零的 API 正好落在第 04、06、07、08 章的教學主線。若沿用舊慣例（「in_degree 為可靠連結度代理」）執行 `drift-check`，會產出 4 個假的 🔴 Breaking。

## 2. 實際修改

### wiki 內容（9 檔）

| 檔案 | 修改 |
|------|------|
| `concepts/mcp-server-resources.md` | 移除 `WithResourcesFromAssembly` / `WithResources` 的 in_degree |
| `concepts/mcp-server-prompts.md` | 移除 `WithPromptsFromAssembly` / `WithPrompts` 的 in_degree |
| `concepts/mcp-server-tools.md` | `WithToolsFromAssembly in_degree=4` → 改記檔案位置與套件歸屬 |
| `concepts/mcp-client.md` | 移除 `McpClient.CreateAsync` 的 in_degree |
| `concepts/mcp-server-builder.md` | 移除 `AddMcpServer` 的 in_degree |
| `concepts/aspnetcore-hosting.md` | 移除 `MapMcp` / `AddMcpServer` 的 in_degree |
| `concepts/streamable-http-transport.md` | 移除 `MapMcp` 的 in_degree |
| `graph-augmentations.json` | `entity:mapmcp` summary 移除 in_degree |
| `SCHEMA.md` | 新增 §4.5「可引用的證據型別」禁止規則；`package` 列舉移除不存在的 `ModelContextProtocol.Authentication`，補上 `.Extensions.Tasks` / `.Extensions.Apps` / `.Analyzers` |

上述 7 個 concept 的 `updated` 一併改為 `2026-09-04`。原則是**移除**而非更新數字——in_degree 是索引工具的產物，每次重建都會變，不屬於 SDK 事實。保留的是穩定的結構性事實：存在性、簽名、namespace、`src/<Package>/...` 路徑歸屬。

### 圖譜

節點與邊的**數量、集合完全不變**（109 nodes / 280 edges；article 35 / topic 10 / entity 39 / claim 25）。實質變動為 9 個節點的內容：

```
article:SCHEMA
article:concepts/aspnetcore-hosting
article:concepts/mcp-client
article:concepts/mcp-server-builder
article:concepts/mcp-server-prompts
article:concepts/mcp-server-resources
article:concepts/mcp-server-tools
article:concepts/streamable-http-transport
entity:mapmcp
```

## 3. 驗證證據

| 步驟 | 命令 | 結果 |
|------|------|------|
| staging 重建 | `build-knowledge-graph.mjs --output <staging>` | 109/280、`unresolvedWikilinks: []`、sourceCommit `6fa3825` |
| baseline 比對 | `validate-knowledge-graph.mjs --baseline <正式版>` | `ok: true`；errors/warnings 空；orphanNodes / orphanConcepts 空；`lostByType`、`addedByType`、`lostSemanticEdges` 全空 |
| Dashboard smoke | UA 2.7.5 dashboard + vite（`GRAPH_DIR=<staging>`，127.0.0.1:5199） | **由使用者以瀏覽器人工確認畫面可用**。自動化 smoke 未能執行：Claude in Chrome 擴充功能對 `127.0.0.1:5199` 回「Can't interact with browser-internal or unparseable URLs」，三次皆同（站台權限未授予） |
| 發布 | `publish-knowledge-graph.mjs --confirm-publish` | `Published validated knowledge graph: 109 nodes / 280 edges` |
| 發布後 validator | `validate-knowledge-graph.mjs`（對正式版） | `ok: true`，orphan 皆空 |
| 圖譜測試 | `test-knowledge-graph.mjs` | 通過：reproducible build、valid baseline migration、dangling-edge rejection、publisher rollback |
| 文件 lint | `lint-docs.mjs` | 9 組全過，exit 0 |
| 上游 clone | `git -C csharp-sdk status --short` | 空（全程唯讀，未 checkout/fetch/pull） |

發布前的正式快照已備份於本次 session 的 scratchpad（`kg-baseline-backup.json`、`meta-backup.json`）；`publish-knowledge-graph.mjs` 本身亦具 rollback 能力（已由 `test-knowledge-graph.mjs` 覆蓋）。

發布後 `knowledge-graph.json` 仍有 1 處 `in_degree` 字串，位於 `article:SCHEMA` 的內容中——那是新增的禁止規則本文，屬預期。

## 4. 連帶已更新的文件

規則變更同步寫進以下位置，避免其他入口沿用舊慣例：

- `mcp-csharp-sdk-kb/wiki/SCHEMA.md` §4.5 — `/compile` 的證據型別限制
- `mcp-csharp-sdk-kb/CLAUDE.md` — 工具表「廢棄確認」欄與 🔴 Breaking 判定規則
- `CLAUDE.md`（工作區根）§6 — 慣例第 5 條
- `mcp-csharp-sdk-kb/raw/facts/codebase-memory-mcp-validation.md` §3、§4 — 成因分析與新慣例

## 5. 後續

- `drift-check` 若因 in_degree=0 或 `trace_path` 空結果想標 🔴 Breaking，**必須**先以 `search_code` 交叉驗證。
- 「full rebuild 與 incremental 索引對鏈式呼叫的邊解析是否不一致」尚未經隔離實驗證實，記為待查（見 validation 報告 §3）。
