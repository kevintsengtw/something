# 第 10 章：建立 MCP Client

> 對應 wiki 概念：[mcp-client](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client.md)、[mcp-client-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-tools.md)、[mcp-client-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-resources.md)
> 上游 API：`McpClient` / `McpClientTool` / `McpClientResource` / `McpClientPrompt`（`ModelContextProtocol.Client`，套件 `.Core`）
> 基準版本：v2.2.0

## 本章目標

前九章都站在 server 這一側；本章換到對面，用 SDK 寫一個 **MCP client**。讀完本章，你可以：

- 用 `McpClient.CreateAsync(transport)` 連上任何相容的 MCP server（不限本 SDK 寫的）
- 列出與呼叫工具（`ListToolsAsync` / `CallToolAsync`），解讀 `CallToolResult`
- 列出、讀取、訂閱資源（`ListResourcesAsync` / `ReadResourceAsync` / `SubscribeToResourceAsync`）
- 列出與取用 prompts（`ListPromptsAsync` / `GetPromptAsync`）
- 用 `RegisterNotificationHandler` 接住 server 的清單變更等通知

## 為什麼需要這個

MCP 是協定，不是框架——client 端只認協定，**server 是誰寫的無所謂**。你可以用 C# client 連 npm 生態的 server（如 `@modelcontextprotocol/server-everything`）、Python 寫的 server、或前幾章自己寫的 server。會寫 client 也有實際用途：

- **整合**：把任意 MCP server 的工具餵給 LLM（`McpClientTool : AIFunction`，第 16 章）
- **測試**：對自己的 server 做端對端驗證（第 13 章）
- **工具鏈**：寫 CLI/服務去消費既有 MCP server 的能力

## 核心概念

### 一個入口、三步驟

1. **選傳輸**：`StdioClientTransport`（啟動子行程）或 `HttpClientTransport`（連遠端），皆實作 `IClientTransport`（第 08 章）。
2. **建立連線**：`McpClient.CreateAsync(transport)`——建立、初始化握手、能力協商一次完成。
3. **操作 primitives**：`McpClient` 的實例方法對應 server 三種 primitive。

| Server 端（你在 ch04–07 定義的） | Client 端取用方法 | 回傳項目型別 |
|--------------------------------|-----------------|-------------|
| Tools | `ListToolsAsync()` / `CallToolAsync(name, args)` | `McpClientTool` / `CallToolResult` |
| Prompts | `ListPromptsAsync()` / `GetPromptAsync(name, args)` | `McpClientPrompt` / `GetPromptResult` |
| Resources | `ListResourcesAsync()` / `ListResourceTemplatesAsync()` / `ReadResourceAsync(uri)` | `McpClientResource` / `McpClientResourceTemplate` / `ReadResourceResult` |

> 建立入口是 `McpClient.CreateAsync`——**不是** `McpClientFactory.CreateAsync`。舊版的 `McpClientFactory` 已從 SDK 移除，網路上較舊的範例還在用它，照抄會編譯失敗（[附錄 B](./appendix-b-migration.md)）。

驗證過的 `CreateAsync` 簽名：

```csharp
public static Task<McpClient> CreateAsync(
    IClientTransport clientTransport,
    McpClientOptions? clientOptions = null,
    ILoggerFactory? loggerFactory = null,
    CancellationToken cancellationToken = default)
```

## 上手範例

### 連線並列出/呼叫工具

```csharp
using ModelContextProtocol.Client;

var transport = new StdioClientTransport(new StdioClientTransportOptions
{
    Name = "Everything",
    Command = "npx",
    Arguments = ["-y", "@modelcontextprotocol/server-everything"],
});

await using var client = await McpClient.CreateAsync(transport);

// 列出工具
foreach (var tool in await client.ListToolsAsync())
    Console.WriteLine($"{tool.Name}: {tool.Description}");

// 呼叫工具
var result = await client.CallToolAsync(
    "echo",
    new Dictionary<string, object?> { ["message"] = "Hello MCP!" });
```

連 HTTP server 只是換傳輸，其餘完全相同：

```csharp
var transport = new HttpClientTransport(new HttpClientTransportOptions
{
    Endpoint = new Uri("https://my-mcp-server.example.com/mcp"),
    TransportMode = HttpTransportMode.StreamableHttp,
});
await using var client = await McpClient.CreateAsync(transport);
```

### 解讀 `CallToolResult`

工具回傳的是 content block 清單（第 05 章的 server 端視角），client 端逐塊處理：

```csharp
using ModelContextProtocol.Protocol;   // TextContentBlock

foreach (var block in result.Content)
{
    if (block is TextContentBlock text)
        Console.WriteLine(text.Text);
}
```

### 列出與讀取資源

```csharp
using ModelContextProtocol.Protocol;   // ResourceContents / TextResourceContents

// 直接資源在 resources/list
foreach (McpClientResource res in await client.ListResourcesAsync())
    Console.WriteLine($"{res.Uri} — {res.Name}");

// 範本資源在另一個清單（第 07 章的區分，client 端兩邊都要看）
foreach (McpClientResourceTemplate tpl in await client.ListResourceTemplatesAsync())
    Console.WriteLine($"{tpl.UriTemplate} — {tpl.Name}");

// 讀取（範本資源代入實際值後的 URI）
var read = await client.ReadResourceAsync("test://template/resource/1");
foreach (ResourceContents content in read.Contents)
{
    if (content is TextResourceContents text)
        Console.WriteLine(text.Text);
}
```

### 列出與取用 prompts

```csharp
foreach (McpClientPrompt prompt in await client.ListPromptsAsync())
    Console.WriteLine($"{prompt.Name}: {prompt.Description}");

var promptResult = await client.GetPromptAsync(
    "complex_prompt",
    new Dictionary<string, object?> { ["temperature"] = 1, ["style"] = "formal" });
// 注意：complex_prompt 的 temperature 參數在第 06 章定義為 int，傳浮點數會對不上 schema
// promptResult.Messages 即第 06 章 server 端組出的訊息
```

## 進階用法

### 訂閱資源與接收通知

第 07 章 server 端的訂閱機制，client 端這樣消費——`SubscribeToResourceAsync` 的多載可直接帶 handler，回傳 `IAsyncDisposable`，dispose 即退訂：

```csharp
// 取自 docs/concepts/resources/resources.md
IAsyncDisposable subscription = await client.SubscribeToResourceAsync(
    "config://app/settings",
    async (notification, cancellationToken) =>
    {
        Console.WriteLine($"Resource updated: {notification.Uri}");
        var updated = await client.ReadResourceAsync(notification.Uri, cancellationToken: cancellationToken);
        // 處理更新後的內容……
    });

// 不再需要時退訂
await subscription.DisposeAsync();
```

也可以無 handler 訂閱（`SubscribeToResourceAsync(uri)` / `UnsubscribeFromResourceAsync(uri)`），搭配全域通知處理器。

### 全域通知處理器

`RegisterNotificationHandler`（定義在 `McpSession`，client/server 皆可用）按方法名稱掛 handler，配 `NotificationMethods` 常數（第 09 章的表）：

```csharp
// 取自 docs/concepts/resources/resources.md
client.RegisterNotificationHandler(
    NotificationMethods.ResourceListChangedNotification,
    async (notification, cancellationToken) =>
    {
        var updatedResources = await client.ListResourcesAsync(cancellationToken: cancellationToken);
        Console.WriteLine($"Resource list updated. {updatedResources.Count} resources available.");
    });
```

工具/prompt 清單變更（`ToolListChangedNotification` / `PromptListChangedNotification`）同理。

### Discovery-first 握手與結果快取提示

`McpClient.CreateAsync` 在 2026-07-28 協定版本下不是直接送 `initialize`，而是先送 `server/discover` 探測（SEP-2575），拿到 `DiscoverResult` 後再決定怎麼握手。這件事 SDK 自動處理，但知道它的行為才看得懂連線失敗時的錯誤：

```csharp
public sealed class DiscoverResult : Result, ICacheableResult
{
    public required IList<string> SupportedVersions { get; set; }
    public required ServerCapabilities Capabilities { get; set; }
    public string? Instructions { get; set; }
    public TimeSpan? TimeToLive { get; set; }      // JSON: ttlMs
    public CacheScope? CacheScope { get; set; }    // JSON: cacheScope
}
```

注意 `DiscoverResult` **沒有** `ServerInfo` 屬性——server 身分改放在 `_meta` 裡，鍵是 `MetaKeys.ServerInfo`（`"io.modelcontextprotocol/serverInfo"`）。身分是選填的，server 省略時 client 得到 `null`。

**fallback 規則**：探測若被拒，client 會退回舊的 `initialize` 握手。會觸發 fallback 的是「這台 server 不懂 `server/discover`」這類訊號——JSON-RPC 的 method-not-found、invalid-params，HTTP 傳輸下的 400/404（v2.1.0 補上），以及探測逾時無回應。其他 HTTP 錯誤**不會**被吞掉，會直接往上拋。若用 `McpClientOptions.ProtocolVersion` 釘死版本，client 會拒絕 fallback 而不是默默降版：

```csharp
await using var client = await McpClient.CreateAsync(
    transport,
    new McpClientOptions
    {
        ClientInfo = new() { Name = "MyClient", Version = "1.0.0" },
        ProtocolVersion = "2026-07-28",   // 釘死版本；server 不支援就失敗，不降版
    });
```

**快取提示（SEP-2549）**：`ICacheableResult` 帶兩個欄位，是提示不是強制機制：

```csharp
public interface ICacheableResult
{
    TimeSpan? TimeToLive { get; set; }
    CacheScope? CacheScope { get; set; }   // Public 或 Private
}
```

實作它的不只 `DiscoverResult`，還有 `ListToolsResult`、`ListPromptsResult`、`ListResourcesResult`、`ListResourceTemplatesResult` 與 `ReadResourceResult`。`CacheScope.Public` 表示結果可跨使用者重用，`Private` 表示只能綁當前身分快取。

這裡有個容易踩的落差：**本章前面用的便利多載讀不到這些提示**。`ListToolsAsync()` 這種不帶 `requestParams` 的多載會把所有分頁聚合成一個 list，過程中把 per-page 的 `TimeToLive` 與 `CacheScope` 丟掉了。要讀提示得用帶 `requestParams` 的多載，它回傳原始的 `ListToolsResult`：

```csharp
// 便利多載：拿得到工具，拿不到快取提示
IList<McpClientTool> tools = await client.ListToolsAsync();

// 低階多載：回傳單頁原始結果，含快取提示與 NextCursor
ListToolsResult page = await client.ListToolsAsync(new ListToolsRequestParams());
if (page.TimeToLive is { } ttl && page.CacheScope == CacheScope.Public)
{
    // 自行決定要不要快取 page.Tools，以及存活多久
}
```

更要緊的是：**SDK 自己不做任何快取**，每次呼叫都會重新向 server 取全部分頁。想快取就得自己來，而且要用低階多載——因為分頁要自己管，每頁才能各自快取與各自過期。

### 預先登記已知工具（`AddKnownTools`）

有些工具的 schema 會用 `x-mcp-header` 標註，宣告某些參數要以 `Mcp-Param-*` HTTP header 傳送而不是塞進 request body。client 只有「知道」某個工具的 schema 才有辦法產生這些 header——正常情況是 `ListToolsAsync` 探索時知道的。

如果你的工具 schema 來自別的地方（上一個 session 存下來的、寫死在設定檔的、或從其他管道取得的），可以直接登記給 client：

```csharp
public virtual void AddKnownTools(IEnumerable<Tool> tools);
public virtual void RemoveKnownTools(IEnumerable<string> toolNames);
public virtual void ClearKnownTools();
```

```csharp
// 從設定檔還原工具 schema，免去一次 ListToolsAsync round-trip
client.AddKnownTools([savedTool]);

// 之後呼叫該工具會自動帶上 schema 宣告的 Mcp-Param-* header
var result = await client.CallToolAsync("savedTool", new Dictionary<string, object?>
{
    ["input"] = "hello",
});
```

幾個行為值得記住：

- **登記是黏著的**。登記過的工具在 client 生命週期內都留在快取裡，`ListToolsAsync` 只會清掉並重抓 server 探索到的工具，不會動到手動登記的。要拿掉得自己呼叫 `RemoveKnownTools` 或 `ClearKnownTools`。
- **`ListToolsAsync` 不會回傳手動登記的工具**。它只回報 server 回報的東西；登記的工具活在快取裡供 header 產生用。想讓工具出現在清單裡，那是 server 端的事。
- **同名會被 server 覆蓋，但保留 known 狀態**。server 回報同名工具時定義以 server 為準，而該工具仍算 known，撐得過後續的快取清除。
- **驗證是全有全無**。批次中只要有一個工具的 `x-mcp-header` 標註無效，整批都不會進快取，並拋 `ArgumentException`。
- **自訂 client 要自己實作**。這三個方法在基底 `McpClient` 上是 `virtual` 且預設拋 `NotSupportedException`；只有 SDK 的實作支援。

#### header 值的編碼（`McpHeaderEncoder`）

`Mcp-Param-*` header 只能放 ASCII，所以帶非 ASCII 字元或特殊字元的值會被包成 base64 信封——前綴 `=?base64?`、後綴 `?=`（SEP-2243 規定 sentinel 必須全小寫且大小寫敏感）。`McpHeaderEncoder`（ns `ModelContextProtocol.Protocol`、套件 `.Core`）提供對應的 `EncodeValue` / `DecodeValue`：

```csharp
public static string? EncodeValue(string? value);
public static string? DecodeValue(string? headerValue);
```

`DecodeValue` 看到不是 base64 信封的值就原樣回傳；信封內容解碼失敗（`FormatException` 或 `DecoderFallbackException`）回 `null`，不拋例外。

> **v2.2.0 修正**：退化字面值 `"=?base64?="` 現在原樣回傳，不再拋例外。原因是它只有 10 個字元，比前綴（9）加後綴（2）還短——前後綴在此重疊，舊版計算內容長度時會得到負值。除非你要自己實作 MCP 的 HTTP header 互通層，否則不會直接碰到這組 API；SDK 內部已在 `StreamableHttpHandler` 處理好。

### 其他實用方法

- **`CallToolAsync(..., progress: ...)`**：接收工具進度（第 09 章已示範）。
- **`PingAsync()`**：健康檢查。
- **`McpClientOptions`**：設定 `ClientInfo`（名稱/版本）等 client 身分資訊。
- **`McpClientOptions.InitializeMeta`**（`JsonObject?`）：塞進 `initialize` 請求 `_meta` 欄位的自訂資料，供 server 在完成握手**之前**檢查——典型用途是驗證用的 context。設為 `null`（預設）就不送 `_meta`。注意這條路徑只在走 `initialize` 握手時有效。

  ```csharp
  var options = new McpClientOptions
  {
      ClientInfo = new() { Name = "MyClient", Version = "1.0.0" },
      InitializeMeta = new JsonObject { ["tenantId"] = "acme" },
  };
  ```
- **只 catch `ClientTransportClosedException`**：v1.3.0 曾把連線失敗統一成 `IOException` 系；v2.0.0 的 explicit SSE 會保留底層 `HttpRequestException`、`TimeoutException` 或實際 I/O 例外，不再一律包裝。請依 transport mode 處理合理的例外集合，並保留 cancellation 的獨立分支。
- **`McpClientTool : AIFunction`**：工具清單可直接放進 `Microsoft.Extensions.AI` 的 `ChatOptions.Tools` 給 `IChatClient` 做 function calling——這是第 16 章的主題，此處先埋個伏筆。

## 常見錯誤

- **照舊範例用 `McpClientFactory.CreateAsync`**：該型別已移除，入口是 `McpClient.CreateAsync`。這是本教學 drift 檢查的經典案例（[附錄 B](./appendix-b-migration.md)）。
- **忘了 `await using` / dispose client**：stdio 傳輸下 client 管理著子行程，不 dispose 會留下孤兒行程（`ShutdownTimeout` 預設 5 秒，見第 08 章）。
- **只看 `resources/list` 找不到範本資源**：範本資源在 `ListResourceTemplatesAsync()`，兩個清單要分開查（第 07 章的老朋友）。
- **假設 stateless HTTP 的所有訂閱都無效**：一般依 session 的 unsolicited notification 確實無法回送；v2.1.0 server 若實作 `subscriptions/listen`，client 可透過 held-open request-bound stream 接收訂閱通知。是否可用仍以 server capability 與實作為準。
- **工具參數字典的型別對不上 schema**：`CallToolAsync` 的參數是 `Dictionary<string, object?>`，鍵名與型別要符合 `tool.JsonSchema` 宣告，錯了會拿到 `IsError = true` 的 `CallToolResult` 或協定錯誤。
- **以為 `ListToolsAsync()` 會帶快取提示**：不帶 `requestParams` 的便利多載會聚合分頁並丟掉 `TimeToLive` / `CacheScope`。要讀提示請改用回傳原始 `ListToolsResult` 的多載，並自行管理分頁。
- **以為 SDK 會替你快取清單結果**：不會。每次 `ListToolsAsync` / `ListPromptsAsync` 都重新向 server 取全部分頁；`ICacheableResult` 只是 server 給的提示，快取要自己實作。
- **用 `AddKnownTools` 想讓工具出現在清單裡**：登記的工具是給 `Mcp-Param-*` header 產生用的，`ListToolsAsync` 仍只回傳 server 回報的工具。
- **假設 server 一定支援所有 primitive**：`ListPromptsAsync` 對沒有 prompts capability 的 server 會失敗；先看 `CreateAsync` 握手後的 server capabilities 再呼叫。

## 相關章節

- 第 04–05 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) — 這些工具在 server 端怎麼定義
- 第 06 章：[mcp-server-prompts](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-prompts.md) — `GetPromptResult` 的 server 端來源
- 第 07 章：[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md) — 直接/範本資源與訂閱的 server 端
- 第 08 章：[stdio-transport](../mcp-csharp-sdk-kb/wiki/concepts/stdio-transport.md)、[streamable-http-transport](../mcp-csharp-sdk-kb/wiki/concepts/streamable-http-transport.md)、[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md) — client 傳輸選擇
- 第 09 章：[notifications-progress](../mcp-csharp-sdk-kb/wiki/concepts/notifications-progress.md) — 進度接收與通知常數
- 第 13 章：[testing-strategy](../mcp-csharp-sdk-kb/wiki/concepts/testing-strategy.md) — 用 in-memory transport 對自己的 server 做 client 測試
- 第 16 章：[mef-ai-integration](../mcp-csharp-sdk-kb/wiki/concepts/mef-ai-integration.md)、[mcp-client-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-tools.md) — 把工具餵給 `IChatClient`

## 延伸閱讀

- 官方概念文件：Getting Started（`raw/docs-conceptual/getting-started.md`）、Resources（`raw/docs-conceptual/resources.md`，client 訂閱段落）
- 上游 sample：`docs/concepts/progress/samples/client/`（完整可跑的 client 程式）
