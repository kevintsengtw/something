# 教學文件維護指引

本檔補充工作區根 `AGENTS.md`，適用於 `mcp-csharp-sdk-guide/` 全目錄。

## 發布基準

- 第 01–20 章與附錄 A/B/C 已完成第二意見審查、處置並具備發佈條件。
- `reviews/second-opinion-review-2026-07-16.md` 與 `reviews/second-opinion-resolution-2026-07-16.md` 是本輪發布追溯來源。
- 附錄 A–D 為完整清單；附錄 D 已於 2026-09-04 完成，原規劃的附錄 E（資源連結）同日決議取消（理由見 `PLAN-beginner-tutorial.md`）。
- 沒有明確任務、已驗證 drift 或可重現錯誤時，不主動改寫已結案正文。

## 語言與連結

- 敘述與程式碼註解使用自然的繁體中文。
- API、型別、方法、namespace、NuGet 套件與協定欄位保留英文原名。
- guide 一律使用一般 Markdown 相對連結；不新增 `[[wiki-style]]` 連結。
- 指向 kb concept 的連結使用 `../mcp-csharp-sdk-kb/wiki/concepts/<slug>.md`。
- inline code 中描述 `[[wiki-style]]` 這個字面語法名稱不算未轉換連結。

## 章節結構

新章節原則上包含：本章目標、為什麼需要、核心概念、上手範例、進階用法、常見錯誤、相關章節、延伸閱讀。

- 目標讀者熟悉 C#/.NET 與 ASP.NET Core，但初次接觸 MCP。
- 概念先說明用途與控制權，再進入 API 與完整程式碼。
- 安裝命令 pin 教學基準套件版本；實驗性 API 標示診斷 ID 與風險。
- 程式碼區塊必須有語言標籤；不可把散文標點正規化套用到 code block。

## 寫入流程

- 新章節或附錄先由 `$draft-chapter` / `$draft-appendix` 寫入 `outputs/`。
- 人工 review 通過後才移入 guide，再執行 `$regenerate-toc` 與 `$lint-tutorial`。
- 直接修正文時只修改報告或任務指出的範圍，避免順手重構其他章節。
- 結構性 API 修正必須附上 MCP、上游原始碼或官方文件證據。
- review 結果留在 `reviews/`，並引用章節路徑與小節/行號。

## 驗證

- 每次變更執行 `node ../scripts/lint-docs.mjs`。
- 程式碼變更依章節 review 文件所列方式執行 build/test。
- ch19 相關變更跑 Docker release profile；ch20 相關變更跑對應 RID 的 AOT release profile。
- 完成前確認 README TOC、相對連結、章節數量與 reviews 追溯仍一致。
