# 附錄 B：API 變更與 Migration

> 本附錄整理 MCP C# SDK 的 API 變更時間線、常見過時寫法的遷移路徑、與診斷代碼速查。
> 網路上的舊教學／範例照抄會編譯失敗或行為錯誤時，先來這裡對表。
> 基準版本：**v2.2.0** ｜ 最後更新：2026-08-15

## 變更時間線

| 版本 | 日期 | 類型 | 變更摘要 |
|------|------|------|---------|
| 2.2.0 | 2026-08-13 | ✨＋🐛 | 新增 `HttpServerSessionMode` 與 hybrid HTTP session mode；修正退化 base64 header wrapper 解碼 |
| 2.1.0 | 2026-08-05 | ✨＋🐛 | 公開 `subscriptions/listen` handler；修正 AutoDetect shared channel、HTTP status 與 discovery fallback |
| 2.0.0 | 2026-07-28 | 🔴 行為 breaking | Stateless 預設 true；Tasks 改為 extension；explicit SSE 保留底層連線例外 |
| 1.4.1 | 2026-07-09 | 🐛 Fix | SSE 記憶體洩漏修正；無 API 變更 |
| 1.4.0 | 2026-06-04 | ✨＋🔒 | ID-JAG 企業授權、`InheritEnvironmentVariables`、session DELETE 使用者綁定（403）、stdio 不再 log 環境變數 |
| 1.3.0 | 2026-05-08 | ✨ | `ClientTransportClosedException`（`: IOException`）；連線失敗自 `InvalidOperationException` 改為 `IOException` 系 |
| 1.2.0 | 2026-03-27 | 🔴 行為 breaking | legacy SSE 端點預設不再掛載；`RequestContext` 2-arg ctor 標 Obsolete（MCP9003）；新增 `OutputSchemaType` |
| 1.1.0 | 2026-03-06 | ✨ | `AllowedValuesAttribute` 自動補全、client completion details |
| 1.0.0 | 2026-02-25 | 🎉 | 首個穩定版（2025-11-25 規格）；`RunSessionHandler` 標 Experimental |

## 過時寫法遷移對照

以下是「舊範例照抄會踩」的具體遷移，每條都經本教學製作過程以圖譜或編譯實證：

### 1. `McpClientFactory` → `McpClient.CreateAsync`

```csharp
// ❌ 舊（已自 SDK 移除，照抄編譯失敗）
var client = await McpClientFactory.CreateAsync(transport);

// ✅ v1.4.0
var client = await McpClient.CreateAsync(transport);
```

repo 已無 `McpClientFactory` 型別（圖譜驗證）。見[第 10 章](./10-mcp-client.md)。

### 2. Sampling／Elicitation handler 掛載位置

```csharp
// ❌ 舊：掛在 capability 上（v1.4.0 的 SamplingCapability 無 SamplingHandler 屬性，CS0117）
Capabilities = new() { Sampling = new SamplingCapability { SamplingHandler = ... } }

// ✅ v1.4.0：掛在 Handlers，capability 由 SDK 自動宣告
var client = await McpClient.CreateAsync(transport, new McpClientOptions
{
    Handlers = new McpClientHandlers
    {
        SamplingHandler = chatClient.CreateSamplingHandler(),
        ElicitationHandler = (request, ct) => ...,
    },
});
```

見[第 14 章](./14-sampling.md)、[第 15 章](./15-elicitation.md)。

### 3. 沒有 `IMcpServer` 介面

工具／prompt／resource 方法要拿 server，注入的是**具體類別 `McpServer`**（`ModelContextProtocol.Server`）。舊文件或早期規劃中的 `IMcpServer` 不存在。見[第 05 章](./05-mcp-server-tools-advanced.md)。

### 4. Legacy SSE（1.2.0 起）

`MapMcp()` 不再自動掛 `/sse`、`/message`。過渡期兼容：

```csharp
.WithHttpTransport(o => o.EnableLegacySse = true)   // [Obsolete]，診斷 MCP9004
```

注意與 `SessionMode = HttpServerSessionMode.Stateless` 互斥（舊寫法 `Stateless = true` 亦同；啟動丟 `InvalidOperationException`）。新專案一律 Streamable HTTP。見[第 08 章](./08-transports-and-sessions.md)。

### 5. `RequestContext` 建構子（1.2.0 起）

2-arg `RequestContext(server, request)` 標 `[Obsolete]`（MCP9003），改用 3-arg `RequestContext(server, request, parameters)`；`Params` 型別由 `TParams?` 改為 `TParams`。一般 attribute 式工具不受影響（context 由 SDK 建立），自建 context 的低階／測試程式碼才需要改。

### 6. 連線失敗的例外型別（1.3.0 起）

v1.3.0 將 `McpClient.CreateAsync` 的 HTTP/SSE 連線失敗從 `InvalidOperationException` 改為 `IOException` 系（具體型別 `ClientTransportClosedException : IOException`）。

v2.0.0 再調整 explicit SSE：`SseClientSessionTransport.ConnectAsync` 記錄並關閉 transport 後直接 rethrow 底層例外，不再一律包成 `IOException`。因此呼叫端可能收到 `HttpRequestException`、`TimeoutException` 或實際 I/O 例外；不要只 catch `ClientTransportClosedException`。使用 `AutoDetect` 時，外層與 inner exception 結構也可能不同，應保留原始例外供診斷。

### 7. namespace 容易寫錯的型別（不是變更，是常年陷阱）

| 型別 | 實際 namespace | 直覺但錯誤的猜測 |
|------|---------------|----------------|
| `StreamClientTransport` | `ModelContextProtocol.Protocol` | `.Client`（檔案在 Client/ 目錄） |
| `IMcpTaskStore`／`InMemoryMcpTaskStore` | `ModelContextProtocol`（根） | `.Server`（檔案在 Server/ 目錄） |
| `CreateSamplingHandler`（`AIContentExtensions`） | `ModelContextProtocol`（根） | `.Client` |
| `AddMcpServer` 等 DI 擴充 | `Microsoft.Extensions.DependencyInjection` | `ModelContextProtocol.*` |
| `McpException`／`McpProtocolException` | `ModelContextProtocol`（根） | `.Protocol` |

## 診斷代碼速查

| 代碼 | 性質 | 含意 | 處理 |
|------|------|------|------|
| `MCPEXP001` | Experimental（**編譯錯誤**） | MCP 規格層實驗功能 | 只在實際使用帶此 attribute 的 API 時，於最小範圍知情抑制；v2 Tasks normal path 不需要此診斷 |
| `MCPEXP002` | Experimental（編譯錯誤） | SDK 層實驗 API（subclassing、`RunSessionHandler`） | 同上；`RunSessionHandler` 建議優先用 `ConfigureSessionOptions` |
| `MCP9003` | Obsolete 警告 | `RequestContext` 2-arg ctor | 改 3-arg |
| `MCP9004` | Obsolete 警告 | `EnableLegacySse` | 僅過渡期使用，盡快遷移 Streamable HTTP |
| `MCP9005` | Obsolete 警告 | 舊 Sampling／Logging／Roots stable surface | 不作新專案入口；依功能改用 current handler／直接呼叫路徑 |
| `MCP9007` | Obsolete 警告 | `AuthorizationRedirectDelegate` 無法驗證 state／issuer | 改用 `AuthorizationCallbackHandler`，回傳 `AuthorizationResult` |
| `IL2026`／`IL3xxx` | Trim/AOT 警告 | `RequiresUnreferencedCode` API（`With*FromAssembly` 等） | AOT 場景改泛型註冊（[第 20 章](./20-native-aot.md)） |

## v2 stable 遷移重點

current baseline 是 v2.2.0／MCP 2026-07-28。升級時至少檢查：`SessionMode`、`Stateless` compatibility proxy、Tasks extension 套件與 wire format、explicit SSE 例外、MCP9005/MCP9007，以及 OAuth 的 PKCE S256 與 scope step-up 行為。

v2.1.0 另新增 `WithSubscriptionsListenHandler`。它讓 stateless Streamable HTTP 可沿 client 建立的 held-open POST 提供 request-bound 訂閱通知，但不代表 stateless 可進行任意 unsolicited server push。

v2.2.0 以 `HttpServerSessionMode` 取代布林值作為 session 設定主線：`Stateless`、`Stateful` 與 `StatefulForInitializeClients`。最後一個是 hybrid 模式，讓 initialize-handshake client 使用 session，同一 endpoint 的 2026-07-28 client 保持 stateless。舊的 `Stateless` 屬性仍可編譯：設 `true` 等同 `SessionMode = Stateless`，設 `false` 等同 `SessionMode = Stateful`；它無法選擇 hybrid，而且與 `SessionMode` 混用時以最後一次指定為準。

## 參考連結

- 知識庫完整時間線：`mcp-csharp-sdk-kb/wiki/api-changelog.md`（含 PR 編號與驗證出處）
- [上游 versioning 政策](https://modelcontextprotocol.github.io/csharp-sdk/versioning.html)
- [上游 list-of-diagnostics](https://github.com/modelcontextprotocol/csharp-sdk/blob/main/docs/list-of-diagnostics.md)
