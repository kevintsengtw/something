# 第 03 章：第一個 MCP Server（Hosting / DI 架構）

> 對應 wiki 概念：[mcp-server-builder](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-builder.md)
> 上游 API：`AddMcpServer`（`ModelContextProtocol`）、`McpServer.Create`（`ModelContextProtocol.Core`）
> 基準版本：v2.2.0

## 本章目標

讀完本章，你可以：

- 用 `Host.CreateApplicationBuilder` + `AddMcpServer()` 搭出一個可執行的 MCP server 骨架
- 理解 `AddMcpServer → WithXxxTransport → WithTools` 的鏈式設定流程
- 分辨「高階（DI / hosting）」與「低階（`McpServer.Create`）」兩條建立路徑，知道何時用哪個
- 看懂 `AddMcpServer` 與相關擴充方法為何在 `Microsoft.Extensions.DependencyInjection` namespace

## 為什麼需要這個

第 04 章開始你會寫工具、跑 server。但工具掛在哪、server 怎麼啟動、log 怎麼設、依賴怎麼注入——這些都由「建立 server」這一步決定。MCP C# SDK 刻意沿用 .NET 開發者熟悉的 **Generic Host + DI** 模型，所以如果你寫過 ASP.NET Core 或 worker service，這一章會非常眼熟。

## 核心概念

### 兩條建立路徑

| 路徑 | 入口 | 適用 |
|------|------|------|
| **高階（DI / hosting）** | `builder.Services.AddMcpServer()` | 多數情境；要 DI、attribute 工具探索、生命週期託管 |
| **低階** | `McpServer.Create(transport, options)` | 完全掌控、不想用 DI 容器、嵌入既有流程 |

### 高階路徑的鏈式設定

`AddMcpServer()` 回傳 `IMcpServerBuilder`，之後鏈式呼叫：

```text
AddMcpServer()                     // 註冊 server 到 IServiceCollection
   └─ WithStdioServerTransport()   // 選傳輸層（或 WithHttpTransport，第 12 章）
        └─ WithTools<T>()          // 掛 primitive（工具/prompt/resource）
```

> 📌 套件 / namespace 對照（已用 codebase-memory-mcp 驗證）：
> - `AddMcpServer`、`WithStdioServerTransport`、`WithTools<T>` 都在 namespace **`Microsoft.Extensions.DependencyInjection`**，屬 **`ModelContextProtocol`** 套件——這是 .NET 擴充方法的慣例（放在被擴充型別的 namespace），所以你的 `using` 是 `Microsoft.Extensions.DependencyInjection`，不是 `ModelContextProtocol.Server`。
> - 低階的 `McpServer`、`McpServerOptions` 才在 namespace `ModelContextProtocol.Server`，屬 `ModelContextProtocol.Core` 套件。

## 上手範例

### 最小可執行 server（取自 QuickstartWeatherServer）

```csharp
// Program.cs
using Microsoft.Extensions.DependencyInjection;   // AddMcpServer / WithStdioServerTransport / WithTools
using Microsoft.Extensions.Hosting;               // Host.CreateApplicationBuilder
using Microsoft.Extensions.Logging;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithTools<WeatherTools>();        // WeatherTools 在第 04 章定義

builder.Logging.AddConsole(o =>
{
    o.LogToStandardErrorThreshold = LogLevel.Trace;   // ⚠️ log 走 stderr（stdio server 必做）
});

await builder.Build().RunAsync();
```

因為走 DI，工具方法可以直接「要」服務。下例把一個 `HttpClient` 註冊成 singleton，工具方法的 `HttpClient` 參數就會被自動注入（第 05 章詳談）：

```csharp
using var httpClient = new HttpClient { BaseAddress = new Uri("https://api.weather.gov") };
builder.Services.AddSingleton(httpClient);
```

### 多組工具 + 自訂 log（取自 TestServerWithHosting）

`WithTools<T>` 可以鏈很多次，各掛一個工具類別：

```csharp
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = Host.CreateApplicationBuilder(args);
builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithTools<EchoTool>()
    .WithTools<SampleLlmTool>();

var app = builder.Build();
await app.RunAsync();
```

## 進階用法

### 低階路徑：`McpServer.Create`

不想用 Generic Host 時，可直接建立 server。驗證過的簽名：

```csharp
// 簽名（src/ModelContextProtocol.Core/Server/McpServer.Methods.cs）
public static McpServer Create(
    ITransport transport,
    McpServerOptions serverOptions,
    ILoggerFactory? loggerFactory = null,
    IServiceProvider? serviceProvider = null);
```

用法骨架：

```csharp
using ModelContextProtocol.Server;     // McpServer / McpServerOptions
using ModelContextProtocol.Protocol;   // Implementation / ServerCapabilities

var options = new McpServerOptions
{
    ServerInfo = new Implementation { Name = "MyServer", Version = "1.0.0" },
    Capabilities = new ServerCapabilities { /* 視需要宣告 tools/resources/prompts 能力 */ },
};

await using McpServer server = McpServer.Create(transport, options);
_ = server.RunAsync();   // Create 只是建立物件——要開始收訊息必須呼叫 RunAsync（完整示範見第 13 章）
```

`McpServerOptions`（`sealed class`，ns `ModelContextProtocol.Server`）的常用屬性：

| 屬性 | 型別 | 用途 |
|------|------|------|
| `ServerInfo` | `Implementation?` | server 名稱與版本（握手時回報給 client）|
| `Capabilities` | `ServerCapabilities?` | 宣告支援哪些能力 |
| `ProtocolVersion` | `string?` | 指定協定版本（預設由 SDK 決定）|
| `ServerInstructions` | `string?` | 給 client/模型的使用說明 |
| `ToolCollection` / `ResourceCollection` / `PromptCollection` | 各 primitive 集合 | 不走 attribute 探索時手動提供 |

> `Implementation` 與 `ServerCapabilities` 都在 namespace `ModelContextProtocol.Protocol`（套件 `.Core`）。

### 何時選低階？

- 你在嵌入式或非 host 環境（例如已有自己的生命週期管理）
- 你要完全程式化地組裝 primitive（不靠 attribute 掃描）
- 你在寫測試，想精準控制 transport 兩端（第 13 章會用到）

多數教學章節都走高階路徑，低階作為「需要時的逃生門」。

## 常見錯誤

- **`using` 寫錯 namespace**：`AddMcpServer` 找不到，通常是少了 `using Microsoft.Extensions.DependencyInjection;`（它不在 `ModelContextProtocol.Server`）。
- **stdio server 把 log 寫到 stdout**：忘了 `LogToStandardErrorThreshold`，協定流被污染。
- **只裝 `.Core` 卻呼叫 `AddMcpServer`**：該擴充方法在 `ModelContextProtocol` 套件（見第 02 章）。
- **低階路徑忘了傳 transport / options**：`McpServer.Create` 對 `transport`、`serverOptions` 為 null 會丟 `ArgumentNullException`。
- **以為 `WithTools<T>` 只能呼叫一次**：可以鏈多次，各掛一個工具類別；或用 `WithToolsFromAssembly()` 一次掃整個組件（第 04 章）。

## 相關章節

- 第 02 章：[nuget-packages](../mcp-csharp-sdk-kb/wiki/concepts/nuget-packages.md) — 為什麼用 `ModelContextProtocol` 套件
- 第 04 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) — 定義 `WeatherTools` / `EchoTool` 並用 stdio 跑起來
- 第 08 章：[stdio-transport](../mcp-csharp-sdk-kb/wiki/concepts/stdio-transport.md)、[streamable-http-transport](../mcp-csharp-sdk-kb/wiki/concepts/streamable-http-transport.md) — 傳輸層選擇
- 第 12 章：[aspnetcore-hosting](../mcp-csharp-sdk-kb/wiki/concepts/aspnetcore-hosting.md) — 改用 ASP.NET Core 託管（`WithHttpTransport` + `MapMcp`）

## 延伸閱讀

- 上游 sample：`samples/QuickstartWeatherServer`、`samples/TestServerWithHosting`
- [Getting Started（官方）](https://csharp.sdk.modelcontextprotocol.io/concepts/getting-started.html)
