# 第 17 章：Tasks——長時間執行的持久任務

> 對應 wiki 概念：[tasks](../mcp-csharp-sdk-kb/wiki/concepts/tasks.md)
> 上游 API：`WithTasks`、`IMcpTaskStore`、`CallToolWithPollingAsync`、`CallToolAsTaskAsync`（套件 `ModelContextProtocol.Extensions.Tasks`）
> 基準版本：v2.2.0（MCP 2026-07-28 Tasks extension）

## 本章目標

- 理解 task-backed 工具呼叫：server 先回 task，client 之後輪詢、取得結果或取消
- 以 `WithTasks` 與 `IMcpTaskStore` 啟用 server 端 Tasks extension
- 用 `CallToolWithPollingAsync` 自動跑完整生命週期
- 在需要自行控制 UI 或狀態時，改用 `CallToolAsTaskAsync` 與 `GetTaskAsync`
- 理解 v2 Tasks 與 v1.4.x experimental Tasks 完全不相容

## 為什麼需要這個

一般 `tools/call` 會等工具跑完才回覆。工作若要跑幾分鐘，HTTP 逾時、client 中斷、使用者無法得知進度等問題就會一起出現。

Tasks extension 改用「收據模式」：

```text
client                                  server
  │ tools/call + Tasks extension          │
  │◀── CreateTaskResult { taskId, ... } ──┤  ← 先建立 task
  │                                       │
  │ tasks/get { taskId }                  │
  │◀── WorkingTaskResult ─────────────────┤
  │              …工具完成…               │
  │ tasks/get { taskId }                  │
  │◀── CompletedTaskResult { result } ────┤
```

v2.0.0 的 Tasks 是 extension，extension ID 為 `io.modelcontextprotocol/tasks`。只有雙方協商到 2026-07-28 或更新版本時才會啟用；對 2025-11-25 peer，呼叫會退回一般同步工具結果，不會橋接舊 experimental Tasks wire format。

> ⚠️ v1.4.x 的 Core Tasks 與 v2 extension 在 API、套件和協定層都不相容。舊的 `McpServerOptions.TaskStore`、`PollTaskUntilCompleteAsync`、`GetTaskResultAsync`、`ListTasksAsync` 與 `TaskStatusHandler` 不能沿用。

## 核心概念

### 獨立 extension package

Tasks 不再放在 `ModelContextProtocol.Core`。server 與 client 都要安裝：

```bash
dotnet add package ModelContextProtocol.Extensions.Tasks --version 2.2.0
```

公開型別與擴充方法共用 namespace：

```csharp
using ModelContextProtocol.Extensions.Tasks;
```

雖然原始檔分散在 `Client/`、`Server/`、`Protocol/` 目錄，namespace 並沒有再加 `.Client`、`.Server` 或 `.Protocol`。

### Task 狀態

建立 task 時，client 先拿到 `CreateTaskResult`。後續 `GetTaskAsync` 回傳 `GetTaskResult` 的具體子型別：

| 型別 | `Status` | 意義 |
|------|----------|------|
| `WorkingTaskResult` | `Working` | 背景工作仍在執行 |
| `InputRequiredTaskResult` | `InputRequired` | 等待 elicitation 或 sampling 等輸入 |
| `CompletedTaskResult` | `Completed` | `Result` 包含原始 request 的最終 JSON 結果 |
| `FailedTaskResult` | `Failed` | 協定層或未處理錯誤 |
| `CancelledTaskResult` | `Cancelled` | task 已取消 |

工具回傳 `CallToolResult { IsError = true }` 仍屬正常工具結果，所以 task 終態是 `Completed`，不是 `Failed`。

### 執行模式

`WithTasks` 的預設 `ExecutionModeSelector` 會把每個工具視為 `Optional`：client 宣告 Tasks extension 時建立 task，普通 `CallToolAsync` 則照常同步執行。可選值如下：

| `McpTaskExecutionMode` | 行為 |
|------------------------|------|
| `Synchronous` | 永遠走一般同步工具結果 |
| `Optional` | client 宣告 Tasks extension 時建立 task |
| `Required` | client 必須宣告 Tasks extension |

這和 v1.4.x「async 工具自動 Optional」的規則不同。

## 上手範例

### 步驟 1：server 啟用 Tasks

```csharp
using ModelContextProtocol.Extensions.Tasks;
using ModelContextProtocol.Server;
using ModelContextProtocol.AspNetCore;
using System.ComponentModel;

var builder = WebApplication.CreateBuilder(args);
var taskStore = new InMemoryMcpTaskStore();

builder.Services.AddMcpServer()
    .WithHttpTransport(options =>
        options.SessionMode = HttpServerSessionMode.Stateless)
    .WithTools<CrunchTools>()
    .WithTasks(taskStore);

var app = builder.Build();
app.MapMcp();
app.Run();

[McpServerToolType]
public sealed class CrunchTools
{
    [McpServerTool, Description("Crunches numbers and returns a report.")]
    public static async Task<string> Crunch(
        [Description("Job label.")] string label,
        CancellationToken cancellationToken)
    {
        await Task.Delay(TimeSpan.FromSeconds(10), cancellationToken);
        return $"報告完成：{label}";
    }
}
```

`WithTasks` 會註冊 `tasks/get`、`tasks/update`、`tasks/cancel` handlers，公告 extension capability，並在 task-backed 呼叫時建立背景 DI scope。`InMemoryMcpTaskStore` 適合開發與測試；production 應換成 durable、可共享的 `IMcpTaskStore`。

### 步驟 2：client 自動輪詢

多數 client 直接用 `CallToolWithPollingAsync`。它會自動加入 extension meta、依 server 建議的 `pollIntervalMs` 輪詢、處理已註冊的 elicitation/sampling handlers，最後回傳一般 `CallToolResult`：

```csharp
using ModelContextProtocol;
using ModelContextProtocol.Extensions.Tasks;
using ModelContextProtocol.Protocol;
using System.Text.Json;

var request = new CallToolRequestParams
{
    Name = "crunch",
    Arguments = new Dictionary<string, JsonElement>
    {
        ["label"] = JsonSerializer.SerializeToElement("Q3"),
    },
};

CallToolResult result = await client.CallToolWithPollingAsync(
    request,
    cancellationToken: cancellationToken);
```

task 若進入 `Failed` 或 `Cancelled`，這個 helper 會丟 `McpException`。若 server 長時間停在 `InputRequired` 卻沒有新的 input request，helper 也會取消並停止輪詢，避免無限迴圈。

### 步驟 3：需要時自行控制生命週期

若 UI 要顯示每次狀態變化，可改用低階方法：

```csharp
var raw = await client.CallToolAsTaskAsync(request, cancellationToken);

if (!raw.IsTask)
{
    CallToolResult immediate = raw.Result!;
    // Server 退回一般結果，例如協商到舊版 peer。
}
else
{
    CreateTaskResult created = raw.TaskCreated!;

    while (true)
    {
        await Task.Delay(
            TimeSpan.FromMilliseconds(created.PollIntervalMs ?? 1000),
            cancellationToken);

        GetTaskResult state = await client.GetTaskAsync(
            created.TaskId,
            cancellationToken);

        if (state is CompletedTaskResult completed)
        {
            CallToolResult? finalResult = completed.Result.Deserialize<CallToolResult>();
            break;
        }

        if (state is FailedTaskResult or CancelledTaskResult)
            throw new McpException($"Task ended with {state.Status}.");

        // InputRequiredTaskResult 需以 UpdateTaskAsync 回送 input responses。
    }
}
```

取消 task：

```csharp
CancelTaskResult acknowledgement = await client.CancelTaskAsync(
    created.TaskId,
    cancellationToken);
```

`tasks/cancel` 是合作式、最終一致的取消要求。工具必須觀察注入的 `CancellationToken`，server 才能及時停止工作。

## 進階用法

### MRTR：task 需要額外輸入

task 內呼叫 `server.ElicitAsync` 或 `server.SampleAsync` 時，SDK 會把請求放進 `InputRequiredTaskResult.InputRequests`。client 以相同 key 回傳 `InputResponse`，再透過 `UpdateTaskAsync` 送回 server。

`CallToolWithPollingAsync` 會把 input requests 分派給 `McpClientHandlers.ElicitationHandler`／`SamplingHandler`，並自動去除已處理過的 key。手動輪詢時，應自行實作相同的去重與 `UpdateTaskAsync` 流程。

server 端由 `IMcpTaskStore.ResolveInputRequestsAsync(taskId, inputResponses, ct)` 收下回應並喚醒等待中的工具。

> 這是 **task 層**的 MRTR。工具本身不走 task 時也能用 MRTR——丟 `InputRequiredException` 讓 client 重試 `tools/call`，那條路徑在[第 15 章](./15-elicitation.md)。兩者的 `InputRequest` / `InputResponse` 型別相同，差別在誰負責保存中間狀態：task 走 store，純 MRTR 走 `requestState` 字串。

### 替代結果（`ResultOrAlternate<TResult>`）

Tasks 之所以能讓 `tools/call` 回傳一個 task 而不是 `CallToolResult`，靠的是 SDK 的 extensibility 型別 `ResultOrAlternate<TResult>`——handler 可以回標準結果，也可以回 extension 定義的另一種結果形狀：

```csharp
[Experimental("MCPEXP002")]   // Extensibility_DiagnosticId
public class ResultOrAlternate<TResult> where TResult : Result
{
    public ResultOrAlternate(TResult result);
    public static ResultOrAlternate<TResult> FromAlternate<TAlternate>(
        TAlternate alternate, JsonTypeInfo<TAlternate> alternateTypeInfo)
        where TAlternate : Result;

    public bool IsAlternate { get; }
    public TResult? Result { get; }
    public Result? Alternate { get; }
    public JsonTypeInfo? AlternateTypeInfo { get; }

    public static implicit operator ResultOrAlternate<TResult>(TResult result);
}
```

有隱式轉換，所以回標準結果時直接 `return result;` 即可，不必手動包裝。

**這是 experimental API**，診斷 ID `MCPEXP002`。用它要抑制警告，而且抑制範圍應該壓到最小：

```csharp
#pragma warning disable MCPEXP002   // extensibility API 仍可能變動
var alternate = ResultOrAlternate<CallToolResult>.FromAlternate(myTaskResult, MyJsonContext.Default.CreateTaskResult);
#pragma warning restore MCPEXP002
```

一般寫 Tasks 的應用程式碼碰不到它——`WithTasks` 已經把這層包好了。會直接面對 `ResultOrAlternate` 的是**自己寫 MCP extension** 的人。別把目前的形狀當成長期穩定契約。

> SDK 目前的三個 experimental 診斷 ID：`MCPEXP001`（規格層 feature）、`MCPEXP002`（extensibility 與 `RunSessionHandler`）、`MCPEXP003`（MCP Apps extension）。

### 自訂 durable store

production `IMcpTaskStore` 至少要符合這些要求：

- thread-safe，所有方法可能並行呼叫
- terminal transition 必須 idempotent，較晚的取消不得覆蓋完成結果
- `CreateTaskAsync` 回傳前，其他 process/node 已能讀到新 task
- 解決 input request 後觸發 `InputResponseReceived`，喚醒等待中的工具
- stateless HTTP 下，所有 request 共用同一 store 或同一外部儲存

`InMemoryMcpTaskStore` 不跨行程，也不適合多副本 production 部署。

### 已知限制

- v2.0.0 尚未實作 server-push task status notifications，client 依賴 polling
- 沒有 `ListTasksAsync`；extension method 集中在 call/get/update/cancel
- 舊 2025-11-25 Tasks 無相容橋接，必須同時升級 client 與 server
- Tasks filter 與 low-level `CallToolWithAlternateHandler` 不可同時為同一次呼叫回傳 alternate result

## 常見錯誤

**1. 只升級 `ModelContextProtocol`，沒裝 Tasks extension**

`WithTasks` 與 client task methods 都在 `ModelContextProtocol.Extensions.Tasks`，需另外加入套件參考。

**2. 沿用 v1.4.x 的 `McpServerOptions.TaskStore`**

v2 改用 `.WithTasks(store)`；舊設定入口不存在。

**3. 沿用根 namespace 或自行加 `.Server`**

正確是 `using ModelContextProtocol.Extensions.Tasks;`。套件內各子目錄不等於 namespace。

**4. 把 `CallToolAsTaskAsync` 當作一定回 task**

回傳型別是 `ResultOrCreatedTask<CallToolResult>`。協商到舊 peer 或 server 選擇同步執行時，`IsTask` 為 `false`，應讀取 `Result`。

**5. production 使用 process-local store**

stateless HTTP 的後續 poll 可能落到另一個 instance。store 必須是 singleton 或由所有 instance 共用的外部儲存。

## 相關章節

- [第 5 章：工具進階](./05-mcp-server-tools-advanced.md)——`CancellationToken` 與工具錯誤
- [第 9 章：通知、進度、Logging 與 Completion](./09-notifications-logging-completion.md)——短時間回饋用 progress，長時間脫鉤用 Tasks
- [第 12 章：ASP.NET Core 託管 MCP Server](./12-aspnetcore-hosting.md)——stateless 與多副本部署
- [第 14 章：Sampling](./14-sampling.md)／[第 15 章：Elicitation](./15-elicitation.md)——`InputRequired` 的輸入來源
- [第 13 章：測試策略](./13-testing-strategy.md)——端對端測試基礎

## 延伸閱讀

- 上游 conceptual docs：`docs/concepts/tasks/tasks.md`
- 上游 tests：`McpClientTaskMethodsTests`、`McpTaskStoreTests`、`TaskProtocolGatingTests`
- wiki：[tasks](../mcp-csharp-sdk-kb/wiki/concepts/tasks.md)、[MRTR](../mcp-csharp-sdk-kb/wiki/concepts/multi-round-trip-requests.md)
