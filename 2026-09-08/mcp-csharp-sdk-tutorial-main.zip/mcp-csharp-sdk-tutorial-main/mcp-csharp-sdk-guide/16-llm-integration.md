# 第 16 章：與 LLM 整合——把 MCP 工具餵給 IChatClient

> 對應 wiki 概念：[mef-ai-integration](../mcp-csharp-sdk-kb/wiki/concepts/mef-ai-integration.md)、[mcp-client-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-tools.md)
> 上游 API：`McpClientTool`（`ModelContextProtocol.Core`）；`IChatClient` 等來自外部 NuGet `Microsoft.Extensions.AI`
> 引入版本：v1.0.0
> 教學基準：v2.2.0

## 本章目標

- 認識 Microsoft.Extensions.AI（M.E.AI）的核心抽象：`IChatClient`、`AIFunction`、middleware pipeline
- 理解關鍵橋接 **`McpClientTool : AIFunction`**——MCP 工具天生就是 LLM 可呼叫的函式
- 用 `UseFunctionInvocation()` 讓模型自動呼叫 MCP 工具，組出完整的對話迴圈
- 用 `WithName`／`WithDescription` 裝飾工具，處理多 server 的名稱衝突
- 用「有劇本的假 LLM」實測整條 function calling 迴圈，不花一毛推論費

## 為什麼需要這個

第 10 章裡是**你**在呼叫工具：程式寫死 `CallToolAsync("get_alerts", ...)`。但 LLM 應用要的是反過來——把工具清單交給模型，**模型自己決定**什麼時候呼叫哪個工具、帶什麼參數。這就是 function calling。

第 1 章說 MCP 解決 M×N 整合問題，本章就是拼圖的最後一塊：host 應用只要會「MCP client + `IChatClient`」這一套，就能把**任何** MCP server 的工具接給**任何** LLM 供應商。SDK 讓這件事幾乎零成本——因為 `McpClientTool` 直接繼承了 M.E.AI 的 `AIFunction`，`ListToolsAsync()` 拿回來的工具**本來就是**模型可呼叫的函式，不需要任何轉接程式碼。

## 核心概念

### 三分鐘認識 Microsoft.Extensions.AI

M.E.AI 是 .NET 的 LLM 抽象層，角色類似 `ILogger` 之於日誌：

| 抽象 | 意義 |
|------|------|
| `IChatClient` | 聊天式 LLM 的統一介面；OpenAI、Azure OpenAI、Anthropic、Ollama 都有對應實作 |
| `ChatMessage`／`ChatRole` | 對話訊息與角色（User／Assistant／System／Tool） |
| `AIFunction` | 「模型可呼叫的函式」：名稱＋描述＋JSON schema＋`InvokeAsync` |
| `ChatOptions.Tools` | 這次請求開放給模型的工具清單（`IList<AITool>`） |
| `AsBuilder()` + middleware | 用管線包裝 client,如 `UseFunctionInvocation()`、`UseOpenTelemetry()` |

第 14 章其實已經用過它——`CreateSamplingHandler(IChatClient)` 是 client 端橋接；`AsSamplingChatClient()` 則是 v2 已標 MCP9005 的 legacy server adapter。

### 橋接：McpClientTool 就是 AIFunction

```csharp
IList<McpClientTool> tools = await mcpClient.ListToolsAsync();
// McpClientTool : AIFunction —— 可以直接：
var options = new ChatOptions { Tools = [.. tools] };
```

`AIFunction` 要求的一切，`McpClientTool` 都從 server 的工具定義帶來了：`Name`／`Description` 來自 attribute（第 4 章），JSON schema 來自參數簽名（第 5 章），而 `InvokeAsync` 在底層就是 `CallToolAsync`。第 13 章低階範例裡的 `tool.InvokeAsync(...)` 走的正是這條 `AIFunction` 路徑。

### UseFunctionInvocation：自動迴圈

模型「呼叫工具」實際上是回一則帶 `FunctionCallContent` 的訊息。沒有人執行它的話，對話就停在那裡。`UseFunctionInvocation()` 掛上的 middleware（`FunctionInvokingChatClient`）把迴圈自動化：

```text
你的訊息 ──▶ 模型
              │ 回 FunctionCallContent("get_alerts", {state:"KY"})
              ▼
   middleware 找到同名 AIFunction → InvokeAsync（= CallToolAsync）
              │ 把 FunctionResultContent 塞回對話
              ▼
            模型（帶著工具結果）──▶ 最終文字回答
```

一次 `GetResponseAsync` 呼叫，中間可能發生多輪工具往返，你拿到的是最終答案。

## 上手範例

以下改寫自官方 `samples/ChatWithTools`（原 sample 連 everything server＋OpenTelemetry,這裡精簡為連第 11 章的天氣 server）：

```csharp
using Microsoft.Extensions.AI;
using ModelContextProtocol.Client;
using OpenAI;

// 1. LLM 端：任何 IChatClient 皆可（此處用 OpenAI，金鑰來自環境變數）
var openAIClient = new OpenAIClient(Environment.GetEnvironmentVariable("OPENAI_API_KEY"))
    .GetChatClient("gpt-4o-mini");

using IChatClient chatClient = openAIClient.AsIChatClient()
    .AsBuilder()
    .UseFunctionInvocation()      // ← 自動工具迴圈，別漏掉
    .Build();

// 2. MCP 端：連到第 11 章的天氣 server（stdio）
await using var mcpClient = await McpClient.CreateAsync(
    new StdioClientTransport(new()
    {
        Command = "dotnet",
        Arguments = ["run", "--project", "path/to/WeatherServer"],
        Name = "Weather",
    }));

var tools = await mcpClient.ListToolsAsync();

// 3. 對話迴圈：工具全數開放給模型
List<ChatMessage> messages = [];
while (true)
{
    Console.Write("Q: ");
    messages.Add(new(ChatRole.User, Console.ReadLine()));

    var response = await chatClient.GetResponseAsync(
        messages, new ChatOptions { Tools = [.. tools] });

    Console.WriteLine(response.Text);
    messages.AddMessages(response);   // 把這輪（含工具往返）併回歷史
}
```

問「KY 有什麼天氣警報？」，模型會自己呼叫 `get_alerts`（帶 `state: "KY"`），拿到 NWS 資料後用自然語言回答。你的程式碼裡**沒有任何一行**提到工具名稱——這就是 function calling 與第 10 章手動呼叫的差別。

需要 NuGet：`ModelContextProtocol`、`Microsoft.Extensions.AI`（middleware 所在的完整套件），以及你選的供應商套件（如 `Microsoft.Extensions.AI.OpenAI`）。既有實測組合是 M.E.AI 10.8.0 + SDK 1.4.0；升到本教學 v2.2.0 baseline 後仍須由專案鎖定並重驗實際版本組合。

## 進階用法

### 串流輸出

官方 sample 用的是串流版本，逐 token 印出、結尾統一併回歷史：

```csharp
List<ChatResponseUpdate> updates = [];
await foreach (var update in chatClient.GetStreamingResponseAsync(
    messages, new ChatOptions { Tools = [.. tools] }))
{
    Console.Write(update);
    updates.Add(update);
}
Console.WriteLine();

messages.AddMessages(updates);   // 串流版的歷史回填
```

### 工具的裝飾：改名、加說明、掛進度

`McpClientTool` 提供不可變的 with-風格裝飾方法，回傳新實例：

```csharp
var renamed = tools
    .Select(t => t.WithName($"weather_{t.Name}")           // 多 server 時避免同名工具互撞
                  .WithDescription($"[天氣服務] {t.Description}"))
    .ToList();

// 長時間工具可掛進度回報（第 9 章的機制）
var withProgress = tool.WithProgress(new Progress<ProgressNotificationValue>(
    p => Console.WriteLine($"進度：{p.Progress}/{p.Total}")));
```

同時連多個 MCP server 時，把各自的 `ListToolsAsync` 結果加上前綴再合併，是避免名稱衝突的標準做法。

### 雙向整合的全貌

把本章與第 14 章拼起來，`IChatClient` 在兩個方向都是橋：

| 方向 | 橋 | 章節 |
|------|----|------|
| MCP 工具 → LLM | `McpClientTool : AIFunction` + `ChatOptions.Tools` | 本章 |
| LLM → MCP server | `CreateSamplingHandler(IChatClient)` | 第 14 章 |

官方 `ChatWithTools` sample 兩者都掛——同一個 OpenAI client 既回答對話、也代打 server 的 sampling 請求。

### 用「有劇本的假 LLM」測試迴圈

Function calling 迴圈也能用第 13 章的方法驗證：自己寫一個 `IChatClient`，第一輪固定回 `FunctionCallContent`、第二輪讀工具結果作答。以下實測通過（連 in-memory 天氣 server,`HttpMessageHandler` 也是假的——全程無網路、無金鑰）：

```csharp
public sealed class ScriptedChatClient : IChatClient
{
    private int _turn;
    public string? ObservedToolResult { get; private set; }

    public Task<ChatResponse> GetResponseAsync(
        IEnumerable<ChatMessage> messages,
        ChatOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        if (++_turn == 1)
        {
            // 第一輪：宣告要呼叫 get_alerts
            return Task.FromResult(new ChatResponse(new ChatMessage(ChatRole.Assistant,
            [
                new FunctionCallContent("call-1", "get_alerts",
                    new Dictionary<string, object?> { ["state"] = "KY" }),
            ])));
        }

        // 第二輪：留存 middleware 塞回來的工具結果，再給最終回答
        ObservedToolResult = string.Join("\n",
            messages.SelectMany(m => m.Contents)
                    .OfType<FunctionResultContent>()
                    .Select(r => r.Result?.ToString()));

        return Task.FromResult(new ChatResponse(
            new ChatMessage(ChatRole.Assistant, "KY 目前有雷雨警報。")));
    }

    public IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
        IEnumerable<ChatMessage> messages, ChatOptions? options = null,
        CancellationToken cancellationToken = default)
        => throw new NotSupportedException();

    public object? GetService(Type serviceType, object? serviceKey = null) => null;
    public void Dispose() { }
}

[Fact]
public async Task 假LLM_經UseFunctionInvocation_自動呼叫MCP工具()
{
    await using var client = await CreateClientAsync();
    var tools = await client.ListToolsAsync();

    var scripted = new ScriptedChatClient();
    using IChatClient chatClient = scripted.AsBuilder().UseFunctionInvocation().Build();

    var response = await chatClient.GetResponseAsync(
        "KY 有什麼天氣警報？", new ChatOptions { Tools = [.. tools] });

    Assert.Contains("雷雨警報", response.Text);
    Assert.Contains("Severe Thunderstorm Warning", scripted.ObservedToolResult);
}
```

第二個斷言證明了 middleware 真的呼叫了 MCP 工具——`FunctionResultContent` 裡是 stub 出來的 NWS 資料。整條「模型宣告 → middleware 執行 → 結果回填 → 模型作答」的鏈路，毫秒級驗證完畢。

## 常見錯誤

**1. 忘了 `UseFunctionInvocation()`**

模型照樣會回 `FunctionCallContent`，但沒有人執行它——你拿到的「回答」是一坨未執行的工具呼叫描述。工具沒被呼叫時，先檢查 builder 管線。

**2. `Tools = tools` 型別不符**

`ChatOptions.Tools` 是 `IList<AITool>`，直接指派 `IList<McpClientTool>` 過不了編譯。慣用寫法是 collection expression 展開：`Tools = [.. tools]`。

**3. 多 server 工具同名互撞**

兩個 server 都有 `search` 工具時，模型只看得到名稱。用 `WithName` 加前綴（如 `github_search`／`jira_search`），`Description` 也順手標明來源。

**4. M.E.AI 套件版本混亂**

SDK 只帶 `Microsoft.Extensions.AI.Abstractions`（抽象）；`UseFunctionInvocation` 等 middleware 在完整的 `Microsoft.Extensions.AI` 套件，要自己加。不要把舊的 SDK 1.4.0 + M.E.AI 10.8.0 實測結果直接當成 v2.2.0 的 release 證據；升級後要重新 restore、build 與測試。

**5. 串流模式忘了 `AddMessages(updates)`**

串流拿到的是 `ChatResponseUpdate` 片段，不自動進歷史。漏了回填，下一輪對話模型就失憶——工具往返的紀錄也一併消失。

## 相關章節

- [第 1 章：什麼是 MCP](./01-what-is-mcp.md)——M×N 問題，本章是它的解答落地
- [第 10 章：建立 MCP Client](./10-mcp-client.md)——手動呼叫工具，與本章的自動呼叫對照
- [第 11 章：實作範例——組裝一個完整的天氣 Server](./11-complete-weather-server.md)——本章對話迴圈連的 server
- [第 13 章：測試策略](./13-testing-strategy.md)——假 LLM 測試法的基礎
- [第 14 章：Sampling](./14-sampling.md)——`IChatClient` 的反向用法

## 延伸閱讀

- 上游 `samples/ChatWithTools`——OpenAI + everything server + OpenTelemetry 的完整版
- [Microsoft.Extensions.AI 官方文件](https://learn.microsoft.com/dotnet/ai/microsoft-extensions-ai)
- wiki 條目：[mef-ai-integration](../mcp-csharp-sdk-kb/wiki/concepts/mef-ai-integration.md)、[mcp-client-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-tools.md)
