# 第 18 章：Authorization 與傳輸安全

> 對應 wiki 概念：[authorization](../mcp-csharp-sdk-kb/wiki/concepts/authorization.md)、[transport-security](../mcp-csharp-sdk-kb/wiki/concepts/transport-security.md)
> 上游 API：`AddMcp`／`McpAuthenticationOptions`（`ModelContextProtocol.AspNetCore`）、`ClientOAuthOptions`／`IdentityAssertionGrantProvider`（`ModelContextProtocol.Core`）
> 引入版本：OAuth 2.1 支援 v1.0.0；ID-JAG v1.4.0
> 教學基準：v2.2.0

## 本章目標

- 理解 MCP 的授權模型：server 是 OAuth 2.1 的 **resource server**,client 自動發現並走完 OAuth flow
- Server 端：JwtBearer 驗證 + `.AddMcp()` 資源中繼資料 + `RequireAuthorization()` 三件套
- Client 端：`HttpClientTransportOptions.OAuth` 一個屬性啟用完整 OAuth（含動態註冊與 PKCE）
- 傳輸層的另外三道鎖：`AllowedHosts`（防 DNS rebinding）、最小化 CORS、session 使用者綁定
- 認識 v1.4.0 的 ID-JAG（企業 SSO 一次驗證、多 server 通行）

## 為什麼需要這個

stdio server 的安全邊界就是行程本身——能啟動它的人就能用它。第 12 章把 server 搬上 HTTP 後，邊界消失了：任何能連到那個 port 的人都能呼叫你的工具。授權因此是 HTTP 部署的必修課，而 MCP 規格直接選用了業界標準答案：**OAuth 2.1**。

MCP 授權的巧妙之處在「自動發現」。client 不需要事先知道你用哪家授權伺服器：

```text
client ── 未帶 token 的請求 ──▶ server
       ◀─ 401 + WWW-Authenticate（指向資源中繼資料）──
client ── 讀 /.well-known/oauth-protected-resource ──▶ 得知授權伺服器、scopes
client ── （必要時動態註冊）→ 導使用者去授權 → code + PKCE 換 token ──▶
client ── Authorization: Bearer <token> ──▶ server ✓
```

SDK 把這整條流程做進了兩端：server 端負責回出正確的 401 與中繼資料，client 端負責發現、註冊、取 token、重試。你要寫的只有「用什麼驗 token」與「使用者怎麼看到授權頁」。

授權之外，HTTP 還有傳輸層本身的攻擊面——DNS rebinding、惡意瀏覽器來源、session 劫持。本章後半處理這三道鎖。

## 核心概念

### 角色分工：SDK 只做 MCP 特有的部分

| 職責 | 誰負責 |
|------|-------|
| 驗證 Bearer token（簽章、效期、audience） | ASP.NET Core 標準 `JwtBearer`——不是 SDK |
| 401 時回 `WWW-Authenticate` 指向資源中繼資料、服務 `/.well-known/oauth-protected-resource` | SDK 的 `.AddMcp()`（`McpAuthenticationHandler`） |
| 端點強制授權 | ASP.NET Core 標準 `RequireAuthorization()` |
| client 端完整 OAuth flow（發現→註冊→授權→token→快取） | SDK 的 `ClientOAuthOptions` |

這個設計讓你能沿用整個 ASP.NET Core 安全生態——Entra ID、Auth0、Keycloak,任何能發 JWT 的授權伺服器都能接。

### 兩層安全，別混為一談

- **Authorization**（本章前半）：「這個請求的**持有者**是誰、有沒有權限」——OAuth token 解決
- **Transport security**（本章後半）：「這個連線**從哪裡來**、該不該被受理」——`AllowedHosts`、CORS 解決

官方文件特別強調：**CORS 不是 host 驗證的替代品**,兩者防的是不同的攻擊。

## 上手範例

### Server 端：三件套佈線

以下為完整可編譯的骨架（對照官方 `samples/ProtectedMcpServer` 精簡，ModelContextProtocol.AspNetCore 1.4.0 + Microsoft.AspNetCore.Authentication.JwtBearer 9.0.6 實測編譯通過）。

> ⚠️ 誠實聲明：本章的佈線經編譯驗證，但 OAuth **完整流程**（401 → 發現 → 授權 → token → 重試）需要授權伺服器與瀏覽器互動，教學製作時未端對端實測。要在本機跑通全流程，請照「本機開發：TestOAuthServer」一節使用官方三件套 samples。

```csharp
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using ModelContextProtocol.AspNetCore;
using ModelContextProtocol.AspNetCore.Authentication;

var builder = WebApplication.CreateBuilder(args);

var serverUrl = "http://localhost:7071/";          // 本機開發用；production 應為 HTTPS 的正式資源 URL
var oauthServerUrl = "https://auth.example.com";   // 你的授權伺服器

// (1) 驗證：JwtBearer 驗 token；挑戰交給 MCP scheme（它會回出正確的 401 中繼資料指引）
builder.Services.AddAuthentication(options =>
{
    options.DefaultChallengeScheme = McpAuthenticationDefaults.AuthenticationScheme;
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.Authority = oauthServerUrl;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,          // RFC 8707：token 必須是「發給這個 server」的
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidAudience = serverUrl,
        ValidIssuer = oauthServerUrl,
    };
})
// (2) MCP 資源中繼資料：401 指引與 /.well-known/oauth-protected-resource 的內容
.AddMcp(options =>
{
    options.ResourceMetadata = new()
    {
        ResourceDocumentation = "https://docs.example.com/api",
        AuthorizationServers = { oauthServerUrl },
        ScopesSupported = ["mcp:tools"],
    };
});

builder.Services.AddAuthorization();

builder.Services.AddMcpServer()
    .WithHttpTransport(o =>
        o.SessionMode = HttpServerSessionMode.Stateless)
    .WithTools<SecureTools>();

var app = builder.Build();

app.UseAuthentication();      // 順序：先驗證
app.UseAuthorization();       //      再授權

// (3) 端點強制授權——漏了這行，前面都是裝飾
app.MapMcp().RequireAuthorization();

app.Run(serverUrl);
```

工具程式碼完全不變——授權在管線層完成，工具方法看到的已經是通過驗證的請求（需要使用者身分時，注入 `IHttpContextAccessor` 讀 `HttpContext.User`）。

### Client 端：一個 OAuth 屬性

```csharp
using ModelContextProtocol.Authentication;
using ModelContextProtocol.Client;

var transport = new HttpClientTransport(new HttpClientTransportOptions
{
    Endpoint = new Uri("http://localhost:7071/"),
    Name = "Secure Client",
    OAuth = new()
    {
        RedirectUri = new Uri("http://localhost:1179/callback"),   // required
        AuthorizationCallbackHandler = HandleAuthorizationAsync,
        DynamicClientRegistration = new()
        {
            ClientName = "MyProtectedClient",
        },
    },
});

var client = await McpClient.CreateAsync(transport);
// 之後照常 ListToolsAsync / CallToolAsync——OAuth 往返都在底層自動發生
```

`AuthorizationCallbackHandler` 是應用程式接管授權互動的入口。它收到 `AuthorizationCallbackContext.AuthorizationUri` 與 `RedirectUri`；開啟瀏覽器並接到 redirect 後，必須回傳 callback query 中的 `code` 與 `state`，有 `iss` 時也一併回傳：

```csharp
static async Task<AuthorizationResult?> HandleAuthorizationAsync(
    AuthorizationCallbackContext context,
    CancellationToken cancellationToken)
{
    Uri callbackUri = await OpenBrowserAndWaitForCallbackAsync(
        context.AuthorizationUri, context.RedirectUri, cancellationToken);
    var query = System.Web.HttpUtility.ParseQueryString(callbackUri.Query);

    return new AuthorizationResult
    {
        Code = query["code"],
        State = query["state"],
        Iss = query["iss"],
    };
}
```

SDK 會要求 `state` 與原始請求完全相符；回傳 `iss` 則會啟用 RFC 9207 issuer validation。舊 `AuthorizationRedirectDelegate` 只能回傳 code，無法提供 state 與 issuer，v2 已以 MCP9007 標記 obsolete，只保留 source／binary compatibility。官方 `ProtectedMcpClient` sample 用 `HttpListener` 接本機 callback，可作完整實作參考。

`ClientOAuthOptions` 其餘可用的旋鈕（原始檔逐一確認）：預註冊時給 `ClientId`／`ClientSecret`、`Scopes` 限定範圍、`ScopeSelector` 控制每次請求的 scope、`TokenCache` 自訂 token 保存、`AuthServerSelector` 在多個授權伺服器中挑選、`AdditionalAuthorizationParameters` 傳額外參數。Dynamic registration 的 `ApplicationType` 可明確指定；未指定時 SDK 會依 redirect URI 推導。

v2 的 client 採 fail-closed：authorization server metadata 必須明確在 `code_challenge_methods_supported` 宣告 `S256`；若同一流程再次收到 `insufficient_scope`，卻沒有增加任何 scope，SDK 會停止重試並回報失敗，避免無進展的授權迴圈。

### 本機開發：TestOAuthServer

沒有現成授權伺服器也能開發——上游 `tests/ModelContextProtocol.TestOAuthServer` 是一個 in-memory OAuth 伺服器，`ProtectedMcpServer` sample 就是配它跑的。三個專案（TestOAuthServer → ProtectedMcpServer → ProtectedMcpClient）依序啟動，即可在本機走完完整 flow。

## 進階用法

### ID-JAG：企業 SSO 一次驗證（v1.4.0）

員工要用十個 MCP server,難道要授權十次？v1.4.0 新增的 **Identity Assertion Authorization Grant**（SEP-990）解決這件事：使用者在企業 IdP 驗證**一次**,client 之後用 token exchange（RFC 8693）把 ID Token 換成各 server 的 JAG,再以 JWT bearer grant（RFC 7523）換 access token——全程不再打擾使用者。

```csharp
using ModelContextProtocol.Authentication;   // .Core

var provider = new IdentityAssertionGrantProvider(
    new IdentityAssertionGrantProviderOptions
    {
        ClientId = "mcp-client-id",
        IdpClientId = "enterprise-idp-client-id",
        IdpUrl = "https://idp.example.com",
        IdTokenCallback = async (ctx, ct) => await GetEnterpriseIdTokenAsync(ctx, ct),
    },
    httpClient);

TokenContainer tokens = await provider.GetAccessTokenAsync(
    resourceUrl: new Uri("https://mcp.example.com/"),
    authorizationServerUrl: new Uri("https://auth.example.com/"));
```

適用場景是企業內部的多 server 部署；公開服務仍走標準 OAuth flow。

### 傳輸安全三道鎖

**鎖一：`AllowedHosts`——防 DNS rebinding**

Kestrel 預設**不驗證** `Host` 標頭。攻擊者可以讓受害者瀏覽器透過攻擊者控制的 DNS 名稱連到你的本機 server。官方指引：本機開發鎖 loopback,production 鎖確切網域，**永遠不要 `"*"`**（偏偏 `"*"` 就是範本預設值）：

```json
{
  "AllowedHosts": "localhost;127.0.0.1;[::1]"
}
```

（在反向代理後面時，host 驗證要做在「接收原始 `Host` 標頭的那一層」。）

**鎖二：最小化 CORS——且只在需要時開**

不打算讓瀏覽器跨源呼叫，就**不要開 CORS**。要開，就開到最小（`ProtectedMcpServer` sample 的政策）：

```csharp
builder.Services.AddCors(options =>
{
    options.AddPolicy("McpBrowserClient", policy =>
    {
        policy.WithOrigins(allowedOrigins)          // 明確列舉，不用 AllowAnyOrigin
            .WithMethods("POST")
            .WithHeaders(HeaderNames.ContentType, HeaderNames.Authorization, "MCP-Protocol-Version")
            .WithExposedHeaders(HeaderNames.WWWAuthenticate);
    });
});
// ...
app.UseCors();
app.MapMcp().RequireAuthorization().RequireCors("McpBrowserClient");
```

（stateful 模式的 server 記得再加 `Mcp-Session-Id` 到允許與暴露清單——第 12 章講過。）

**鎖三：session 使用者綁定（v1.4.0）**

啟用驗證的 stateful server 上，SDK 自動把 session 綁定到建立它的使用者：之後的 GET／POST／DELETE 請求若帶著同一個 session ID 但**不同的已驗證使用者**,一律 `403 Forbidden`。這防的是 session ID 洩漏後被第三者接管或惡意終止。你不用寫任何程式碼，但要知道它存在——測試多使用者場景時 403 不是 bug,是設計。

## 常見錯誤

**1. 忘了 `RequireAuthorization()`**

`AddAuthentication` 只是「會驗」，不是「必須通過」。沒有這行，匿名請求照樣打進工具。佈線完成後，先拿沒帶 token 的請求打一發，確認拿到 401。

**2. `UseAuthentication`／`UseAuthorization` 缺席或順序顛倒**

沒有這兩行 middleware,`RequireAuthorization()` 會在執行期丟例外或全部拒絕。順序固定：先 Authentication 後 Authorization,且都在 `MapMcp` 之前。

**3. `DefaultChallengeScheme` 沒指到 MCP scheme**

401 照樣會回，但少了指向資源中繼資料的 `WWW-Authenticate` 指引——client 的自動 OAuth 發現流程斷在第一步，只能報「未授權」。挑戰 scheme 必須是 `McpAuthenticationDefaults.AuthenticationScheme`。

**4. `AllowedHosts` 留著範本預設的 `"*"`**

等於放棄 host 驗證。本機開發也要鎖 loopback——DNS rebinding 攻擊的目標正是「跑在開發者本機的服務」。

**5. 用 `AllowAnyOrigin()` 打發 CORS**

對帶授權的 API 這幾乎注定出事（而且 ASP.NET Core 本身禁止 `AllowAnyOrigin` + `AllowCredentials` 並用）。列舉確切來源，或干脆不開。

**6. 不驗 audience**

`ValidateAudience = false` 意味著「發給別的服務的 token 也能用在我這」。RFC 8707 的資源指示就是為此存在——`ValidAudience` 設成自己的資源 URL。

**7. authorization server metadata 沒宣告 PKCE `S256`**

v2 client 不會猜測 server 支援 S256；`code_challenge_methods_supported` 缺席或不含 `S256` 都會直接失敗。請修正 authorization server metadata，不要繞過檢查。

**8. `insufficient_scope` 一直回同一組 scope**

step-up challenge 必須帶來新的 scope。若重試後沒有任何進展，v2 client 會停止流程；檢查 resource server 的 `WWW-Authenticate` challenge 與 `ScopeSelector`。

## 相關章節

- [第 8 章：傳輸層總覽與 Sessions](./08-transports-and-sessions.md)——session 機制
- [第 12 章：ASP.NET Core 託管 MCP Server](./12-aspnetcore-hosting.md)——本章安全設定的宿主；CORS 與 session 標頭細節
- [第 19 章：Docker 部署](./19-docker-deployment.md)——容器化後的網路邊界

## 延伸閱讀

- 上游 `samples/ProtectedMcpServer`／`samples/ProtectedMcpClient`——本章範例的完整版
- 上游 `tests/ModelContextProtocol.TestOAuthServer`——本機開發用 OAuth 伺服器
- [MCP 授權規格](https://modelcontextprotocol.io/specification/)、RFC 8707（Resource Indicators）、RFC 8693／7523（ID-JAG 的底層）
- [ASP.NET Core Host Filtering](https://learn.microsoft.com/aspnet/core/fundamentals/servers/kestrel/host-filtering)
- wiki 條目：[authorization](../mcp-csharp-sdk-kb/wiki/concepts/authorization.md)、[transport-security](../mcp-csharp-sdk-kb/wiki/concepts/transport-security.md)
