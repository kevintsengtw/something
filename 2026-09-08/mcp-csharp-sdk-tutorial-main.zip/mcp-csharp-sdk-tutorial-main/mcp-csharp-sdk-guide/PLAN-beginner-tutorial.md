# MCP C# SDK 繁中教學 — 章節規劃（PLAN）

> 框架版本：**ModelContextProtocol v1.4.0**
> 最後更新：2026-06-30
> 狀態：📐 規劃完成，章節內容待 `/draft-chapter` 逐章草擬（產出 → outputs/ → 人工 review → 移入本目錄）

本規劃定義教學章節的範圍、順序、撰寫風格。章節編號與 `mcp-csharp-sdk-kb/wiki/INDEX.md` 的「章節反查表」對齊。

---

## 撰寫風格規約

- **語言**：繁體中文散文；API 名稱、C# 型別、attribute、NuGet 套件名稱保持英文原名；程式碼註解用繁中
- **每章骨架**：本章目標 → 為什麼需要 → 核心概念 → 上手範例 → 進階用法 → 常見錯誤 → 相關章節 → 延伸閱讀
- **程式碼**：所有 C# 範例需可對應上游 samples/tests；結構性宣告必須經 codebase-memory-mcp 驗證（透過 `/draft-chapter`）
- **目標讀者**：熟悉 C#/.NET 與 ASP.NET Core Web API、初次接觸 MCP 的開發者
- **執行環境**：.NET 9.0+

---

## 章節規劃

### 第一部分：認識 MCP 與 SDK

| 章節 | 標題 | 對應 wiki 概念 |
|------|------|---------------|
| 01 | 什麼是 MCP（Model Context Protocol） | [what-is-mcp](../mcp-csharp-sdk-kb/wiki/concepts/what-is-mcp.md) |
| 02 | SDK 三套件選擇與安裝 | [nuget-packages](../mcp-csharp-sdk-kb/wiki/concepts/nuget-packages.md) |

### 第二部分：建立 MCP Server

| 章節 | 標題 | 對應 wiki 概念 |
|------|------|---------------|
| 03 | 第一個 MCP Server（Hosting / DI 架構） | [mcp-server-builder](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-builder.md) |
| 04 | 第一個工具，用 stdio 跑起來 | [mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md), [stdio-transport](../mcp-csharp-sdk-kb/wiki/concepts/stdio-transport.md) |
| 05 | 工具進階（DI 注入、McpServer、Schema、錯誤處理） | [mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) |
| 06 | Prompts（可重用提示範本） | [mcp-server-prompts](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-prompts.md) |
| 07 | Resources（資源、URI Template、訂閱與通知） | [mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md) |

### 第三部分：傳輸與通訊

| 章節 | 標題 | 對應 wiki 概念 |
|------|------|---------------|
| 08 | 傳輸層總覽與 Sessions（Stdio / Streamable HTTP / In-memory、stateless vs stateful） | [stdio-transport](../mcp-csharp-sdk-kb/wiki/concepts/stdio-transport.md), [streamable-http-transport](../mcp-csharp-sdk-kb/wiki/concepts/streamable-http-transport.md), [sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md) |
| 09 | 通知、進度、Logging 與 Completion | [notifications-progress](../mcp-csharp-sdk-kb/wiki/concepts/notifications-progress.md), [logging-and-completion](../mcp-csharp-sdk-kb/wiki/concepts/logging-and-completion.md) |

### 第四部分：MCP Client 與整合實作

| 章節 | 標題 | 對應 wiki 概念 |
|------|------|---------------|
| 10 | 建立 MCP Client（列出/呼叫工具、讀取資源） | [mcp-client](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client.md), [mcp-client-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-tools.md), [mcp-client-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-resources.md) |
| 11 | 實作範例：組裝一個完整 Server（如天氣 / 檔案系統 server） | [mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md), [mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md) |

### 第五部分：ASP.NET Core 與正式環境

| 章節 | 標題 | 對應 wiki 概念 |
|------|------|---------------|
| 12 | ASP.NET Core 託管 MCP Server（MapMcp、HTTP transport、stateless/stateful） | [aspnetcore-hosting](../mcp-csharp-sdk-kb/wiki/concepts/aspnetcore-hosting.md), [streamable-http-transport](../mcp-csharp-sdk-kb/wiki/concepts/streamable-http-transport.md), [sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md) |
| 13 | 測試策略（In-memory transport、單元/整合測試） | [testing-strategy](../mcp-csharp-sdk-kb/wiki/concepts/testing-strategy.md), [in-memory-transport](../mcp-csharp-sdk-kb/wiki/concepts/in-memory-transport.md) |

### 第六部分：伺服器↔客戶端進階

| 章節 | 標題 | 對應 wiki 概念 |
|------|------|---------------|
| 14 | Sampling（伺服器向客戶端請求 LLM 補全） | [sampling](../mcp-csharp-sdk-kb/wiki/concepts/sampling.md) |
| 15 | Elicitation（伺服器向使用者徵詢輸入） | [elicitation](../mcp-csharp-sdk-kb/wiki/concepts/elicitation.md) |
| 16 | 與 LLM 整合（Microsoft.Extensions.AI、IChatClient、把工具餵給 chat client） | [mef-ai-integration](../mcp-csharp-sdk-kb/wiki/concepts/mef-ai-integration.md), [mcp-client-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-tools.md) |
| 17 | Tasks（durable 長時間請求，2025-11-25 spec） | [tasks](../mcp-csharp-sdk-kb/wiki/concepts/tasks.md) |

### 第七部分：安全與部署

| 章節 | 標題 | 對應 wiki 概念 |
|------|------|---------------|
| 18 | Authorization 與傳輸安全（OAuth 2.1、host validation、CORS、DNS rebinding） | [authorization](../mcp-csharp-sdk-kb/wiki/concepts/authorization.md), [transport-security](../mcp-csharp-sdk-kb/wiki/concepts/transport-security.md) |
| 19 | Docker 部署 | [docker-deployment](../mcp-csharp-sdk-kb/wiki/concepts/docker-deployment.md) |
| 20 | Native AOT 相容 | [aot-compatibility](../mcp-csharp-sdk-kb/wiki/concepts/aot-compatibility.md) |

### 第八部分：Extension 生態

| 章節 | 標題 | 對應 wiki 概念 |
|------|------|---------------|
| 21 | MCP Apps——讓工具帶著互動式 UI（experimental，`MCPEXP003`） | [mcp-apps](../mcp-csharp-sdk-kb/wiki/concepts/mcp-apps.md) |

### 附錄

| 附錄 | 標題 | 對應 wiki 概念 |
|------|------|---------------|
| A | NuGet 套件清單與版本記錄 | [nuget-packages](../mcp-csharp-sdk-kb/wiki/concepts/nuget-packages.md) |
| B | API 變更與 Migration（如 `McpClientFactory` → `McpClient`） | — |
| C | MCP 規格映射（2026-07-28 primitive ↔ C# 型別） | [what-is-mcp](../mcp-csharp-sdk-kb/wiki/concepts/what-is-mcp.md) |
| D | 官方 Samples 導覽 ✅ 已完成（2026-09-04） | — |

**附錄 E（資源連結）已取消（2026-09-04）。** 原規劃於 2026-06-30，當時章節尚未撰寫。實際完稿後盤點：權威來源（SDK repo、conceptual docs、API 文件、MCP 規格）已列於工作區根 README 的「參考資料」，各章「延伸閱讀」另有 14 條情境相關連結，去重後真正的外部網域只有 5 個。再做一份集中列表只會重複既有內容，並讓每個 URL 都成為未來的維護負債。附錄清單以 A–D 為完整。

---

## 撰寫順序建議

1. 先寫第一、二部分（01–07）建立 server 基礎
2. 第三、四部分（08–11）補齊傳輸與 client
3. 第五部分（12–13）銜接讀者既有的 ASP.NET Core / 測試背景
4. 第六、七部分（14–20）進階主題
5. 附錄隨章節成熟度補充

每章透過 `/draft-chapter <concept> <NN>` 草擬，人工 review 後移入本目錄，再 `/regenerate-toc` + `/lint`。
