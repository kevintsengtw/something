# 第二意見審查——第一方處置記錄（第 21 章與附錄 D，2026-09-04）

> 對應審查報告：[second-opinion-review-ch21-appendix-d-2026-09-04.md](./second-opinion-review-ch21-appendix-d-2026-09-04.md)
> 處置原則：每項發現先獨立查證（原始碼／實測），再修正；查證結果與報告不符時如實記載。
>
> **第一輪（2026-09-04 上午）**：P1×4、P2×5、P3×2 全部查證成立並處置，另處理報告未列的一項附帶發現。
> 審查方推翻了第一方自評的兩項風險（項 4、項 8），已據實更新自評文件。
>
> ⚠️ **該輪的「全部處置完畢」宣告不成立**——審查方覆核後指出 P1-01、P2-02、P2-03、P2-05、P3-02
> 均有未清乾淨的殘留，並新增 P2-06、P3-03、P3-04。**第二輪處置記錄見本檔末尾。**

## 總表

| # | 級別 | 發現 | 查證結果 | 處置 |
|---|------|------|---------|------|
| P1-01 | P1 | `Visibility` 表格寫成排他呼叫權，與同頁警告矛盾 | ✅ 成立。表格「只有 LLM 能呼叫／只有 app UI 能呼叫」確實會先建立錯誤心智模型 | 小節改名「工具的預期受眾」；**把「SDK 不執行、須自行授權」移到表格之前**；表格語意改為「host 應…」；實測佐證改述為「同一 client 可直接 `tools/call` 成功」 |
| P1-02 | P1 | 降級只檢查 extension 存在，未檢查 MIME type | ✅ 成立。`McpApps.GetUiCapability` 只做解析（object → `McpUiClientCapabilities`），**完全不碰 `MimeTypes`**；而 `McpUiClientCapabilities.MimeTypes` 的 XML doc 明載「支援 MCP Apps 的 client **必須**包含 `text/html;profile=mcp-app`」 | 判斷改為 `uiCapability?.MimeTypes?.Contains(McpApps.HtmlMimeType) != true`；正文補說明 `GetUiCapability` 的職責邊界。**修正後重新建置通過** |
| P1-03 | P1 | display mode 的協商層級說錯 | ✅ 成立。C# 端 `McpUiClientCapabilities` 只有 `MimeTypes`，沒有任何 display-mode 成員——原文說「在能力交換階段由 client 與 server 協商」無從成立 | 改寫為 app view ↔ host 在 `ui/initialize` 交換（`appCapabilities.availableDisplayModes` / host context），view 可再送 `ui/request-display-mode`；並標明規格仍為 draft、wire shape 可能變動 |
| P1-04 | P1 | `Permissions.Allow` 誤用 `sandbox` token 當 `allow` 值 | ✅ 成立，**且是第一方違反專案 ground truth 規則的直接後果** | 值域改為 `camera`／`microphone`／`geolocation`／`clipboard-read`／`clipboard-write`；加註別與 `sandbox` token 混淆、並點名 conceptual doc 此處措辭易誤導；補「這只是請求，核准與否由 host policy 決定」 |
| P2-01 | P2 | experimental 警告密度夠，但缺 production 決策防線 | ✅ 成立 | pragma 段後新增 production gate：釘死 SDK 版本、隔離成 adapter／feature flag、針對實際 host 做相容性測試、升級後重驗 wire shape；並明說「抑制診斷不等於 API 變穩定」 |
| P2-02 | P2 | 上手範例缺 UI HTML 與輸出複製設定，無法照抄跑通 | ✅ 成立。上游 `WeatherAppServer.csproj` 確有 `<Content Include="ui\*.html" CopyToOutputDirectory="PreserveNewest" />`，本章漏了 | 步驟 2 補 `.csproj` 的 `Content` 項目與一份最小 `weather-forecast.html`（CSS 變數含 fallback），並說明漏了會在 `resources/read` 丟 `FileNotFoundException` |
| P2-03 | P2 | host-dependent 行為寫得過度確定 | ✅ 成立。主題那句「完全不用 server 操心：host **會**把一組標準 CSS 變數傳進 iframe」確實高於規格保證 | 改為「遵循草案的 host **可**提供，且允許只傳子集或完全不傳」，並補一段必須寫 fallback 的 CSS 範例；CSP 加註「依規格對 host 的要求，本教學未觀測實際 enforcement」；`Domain` 標為 host-dependent |
| P2-04 | P2 | 附錄 D 的 AI 段落缺驗證揭露；第 19 章映射不成立 | ✅ 成立。實測 `grep -ci 'telemetry\|OpenTelemetry\|Application Insights'`：ch19 = **0**、ch12 = **3** | 訊號表前加「取自上游 README，本教學未連線 Azure 驗證」；總表章節映射 `08、12、19` → `08、12`；正文「第 19 章的遙測範例」改為第 12 章；相關章節拆成兩條並註明 ch19 不涉及遙測 |
| P2-05 | P2 | 第一方 review 的 build claim 過寬、風險 8 已不成立、編號缺 3 | ✅ 全部成立 | build claim 限縮為「測試 harness 涵蓋 API 形狀」並列明替身；風險 8 改記為已解決；編號重排並補回缺項 |
| P3-01 | P3 | 開場把前章工具輸出概括得過窄 | ✅ 成立 | 改為「非互動式內容——文字、結構化資料，或圖片／音訊／內嵌資源這類 content block（第 05 章）」 |
| P3-02 | P3 | 附錄 D 的特殊 TFM 可直接展開 | ✅ 建議合理（原盤點本身成立） | `FileBasedMcpServer` → 「.NET 10 file-based（無 csproj／TFM）」；`TestServerWithHosting` → `$(DefaultTestTargetFrameworks)`（net10.0/net9.0/net8.0） |
| 附帶 | P2 | **報告未列**：附錄 A 仍把 `.Extensions.Apps` 標為「第二輪」 | ✅ 自行發現。第 21 章已存在，該標記過時 | 附錄 A 的套件表與安裝指令兩處「第二輪」改為「第 21 章」 |

## 逐項查證細節

### P1-04：這是本輪最該記取的一項

審查報告點出 `Allow` 的示例值錯誤，查證後成立，而且成因值得記錄。

- **官方 conceptual doc**（`raw/docs-conceptual/apps.md:125`）：
  > **Permissions** — Sandbox permissions (scripts, forms, popups, etc.)
- **上游原始碼**（`McpUiResourcePermissions.cs` 的 XML doc）：
  > This maps to the `allow` attribute on the iframe sandbox in the MCP host.
  > …for example `"camera"`, `"microphone"`, `"geolocation"`, `"clipboard-read"`, or `"clipboard-write"`.

`scripts` / `forms` / `popups` 是 iframe **`sandbox`** attribute 的 token，`allow` 吃的是 Permissions Policy 名稱——兩者不通用，照 conceptual doc 填不會生效。

第一方撰稿時直接轉述了 conceptual doc，**沒有回頭讀 `McpUiResourcePermissions.cs`**。工作區根 `CLAUDE.md` §2 與 `AGENTS.md` 的 Ground Truth 都要求結構性宣告以原始碼為準，這一項是明確違反。列在此處作為往後 `/draft-chapter` 的警示：**conceptual doc 是敘述素材，不是事實層**。

### P1-02：`GetUiCapability` 的職責邊界

逐行讀過 `McpApps.GetUiCapability`：它只做四件事——取 `Extensions`、找 `io.modelcontextprotocol/ui` key、處理已是 `McpUiClientCapabilities` 物件的情形、把 `JsonElement` 反序列化（非物件一律回 `null`）。**沒有任何一行檢查 `MimeTypes`**。

因此 `is not null` 只保證「對方宣告了這個 extension 且值是個物件」。修正後的條件已在測試專案重新建置通過。

### P2-04：章節映射的實測

```bash
$ grep -ci 'telemetry\|OpenTelemetry\|Application Insights' 19-docker-deployment.md   → 0
$ grep -ci 'telemetry\|OpenTelemetry\|Application Insights' 12-aspnetcore-hosting.md  → 3
```

報告的判斷成立，映射已改。

### 審查方對第一方自評的覆核——兩項被推翻

| 自評項 | 覆核結果 | 第一方查證 |
|---|---|---|
| 4. `ApplyAppUiAttributes` 冪等性未驗證 | 審查方判「未成立」 | ✅ **同意**。`McpApps.SetAppUi` 有 `if (!protocolTool.Meta.ContainsKey("ui"))` 保護，既有 `ui` 不覆寫；上游測試 `SetAppUi_DoesNotOverwrite_ExistingUiKey` 覆蓋此規則。原風險不成立 |
| 8. Apps TFM 未進附錄 A | 審查方判「未成立」 | ✅ **同意**。`appendix-a-nuget-packages.md:48` 與 `02-nuget-packages.md:117` 都已列 net10.0/net9.0/net8.0/netstandard2.0。原風險是撰稿時的誤記 |
| 2. typed resource meta 未逐欄位實測 | 審查方判「部分成立」 | ✅ **同意**。上游 `McpAppsTests.McpUiResourceMeta_CanBeRoundtrippedAsJson` 已覆蓋 Domain／PrefersBorder／Csp 三個網域清單／Permissions 的 round-trip，結構正確性不是未解風險 |
| 編號缺 3、實際 8 項不是 9 項 | 審查方指出 | ✅ **同意**。更新章節時重排編號漏了一號 |

## 未處理與仍存在的邊界

- **真正的 MCP Apps host 觀測仍未執行**。UI 是否呈現、CSP 是否被 enforce、主題變數是否注入、`prefersBorder` 是否被理會——這些依然只有規格與 metadata 層的證據。處置後正文已把這類敘述全部改為「規格要求／host-dependent／本教學未觀測」，符合審查方「正文誠實區分三層」的要求。
- **Application Insights 的資料落地未驗證**。附錄 D 已加揭露。
- **`McpApps.SetResourceUi` 仍未在測試專案中呼叫過**，章節只在文字提及。

## 結案狀態

第 21 章與附錄 D 已完成本輪第二意見審查的全部處置。修正後：

- `dotnet build`（net9.0 + NuGet 2.2.0）：0 警告 0 錯誤，含改寫後的降級判斷與 permissions 值域
- `node scripts/lint-docs.mjs`：9 組全過（21 章 / 4 附錄 / **27** 審查 / 32 概念）
- `validation/manifest.json` 的 `reviewMarkdownFiles` 已由 25 更新為 **27**（原 25 ＋ 本輪審查報告 ＋ 本處置記錄）

是否據此解除「尚未通過第二意見審查」的標註，由維護者決定——審查方原判為「尚未達可發佈水準」，本記錄逐項處置後請審查方確認結案。

## 第二意見覆核（2026-09-04）

**覆核結論：本輪暫不結案，尚不能解除「尚未達可發佈水準」的判定。**

這次直接以 `csharp-sdk/` 的 v2.2.0 commit
`6fa3825973949a9c4f0cd8af344e15a8db09dc35` 再查一次原始碼，並逐段比對第 21 章、
附錄 D、附錄 A 與第一方自評。P1-02、P1-03、P1-04 的核心技術修正成立；但 P1-01
在章首仍保留原先被指出的排他呼叫措辭，P2-02、P2-03、P2-05 與 P3-02 也仍有未清乾淨的內容。
因此，前文「P1×4、P2×5、P3×2 全部處置完畢」及 README 的同義狀態宣告目前尚不成立。

### 逐項覆核摘要

| # | 覆核結果 | 說明 |
|---|---|---|
| P1-01 | **部分解決，仍有阻塞項** | 主體小節已正確改成 host policy，表格也不再把 metadata 寫成 server 授權；但 `21-mcp-apps.md:15` 仍寫「`Visibility` 怎麼區分『只給模型呼叫』『只給 UI 呼叫』的工具」。這正是原報告列出的錯誤心智模型，且位於本章目標，應改成「標示工具的預期受眾」之類不含排他保證的說法。 |
| P1-02 | **已實質解決** | `McpApps.GetUiCapability`（`McpApps.cs:81-115`）只取 extension、辨認強型別或 `JsonElement` 並反序列化，沒有檢查 `MimeTypes`；`McpUiClientCapabilities.cs:18-25` 則要求支援 Apps 的 client 在清單中包含 `text/html;profile=mcp-app`。正文的 `uiCapability?.MimeTypes?.Contains(McpApps.HtmlMimeType) != true` 因此是正確的降級條件。常見錯誤 3 最好也明說「檢查回傳物件的 `MimeTypes`」，避免讀者又簡化回 non-null 判斷，但這不推翻主範例已修正的結論。 |
| P1-03 | **核心已解決，仍有措辭需收斂** | server↔client extension capability 與 app view↔host UI lifecycle 已分清。草案確實把 view 支援模式放在 `ui/initialize` 的 `appCapabilities.availableDisplayModes`，並以 `ui/request-display-mode` 申請切換；但 `McpUiInitializeResult.hostContext` 是 host **SHOULD** 提供，`availableDisplayModes` 本身也是 optional。`21-mcp-apps.md:373` 的「host 支援的模式則由 host context 帶下來」仍寫成無條件事實，宜改成「若 host 提供，會由 `hostContext.availableDisplayModes` 帶下來」。 |
| P1-04 | **已實質解決** | `McpUiResourcePermissions.Allow` 的型別是未封閉的 `IList<string>?`，原始碼沒有 enum 或執行期值域驗證；XML doc 列的是**例子**：`camera`、`microphone`、`geolocation`、`clipboard-read`、`clipboard-write`，並明說對應 iframe `allow` attribute。正文現在的值與「由 host policy 決定」均正確。章首 `:16` 與型別摘要註解 `:315` 仍稱「sandbox 權限」，雖沿用上游 summary 的廣義用語，為免再次與 `sandbox` token 混淆，建議統一成「iframe `allow`／Permissions Policy 請求」。另不可把上述五個例子寫成封閉值域。 |
| P2-01 | **已解決** | production gate 已明說抑制診斷不會穩定 API／wire contract，並包含 pin 版本、隔離、實際 host 相容性測試與升級重驗。 |
| P2-02 | **部分解決** | `.csproj` 的 `<Content Include="ui\*.html" CopyToOutputDirectory="PreserveNewest" />` 與上游 `WeatherAppServer.csproj:16-18` 相同，設定正確；新增 HTML 可被瀏覽器解析，CSS 變數也有 fallback。不過正文的 `WeatherForecast` 仍含未定義的 `UsCity`、`forecastData` 與省略實作，沒有在正文旁明示「節錄、不可獨立建置」。因此「上手範例可照抄跑通」仍未成立。最小 HTML 也缺 `<title>`（並建議補 `lang` 與 viewport）；這是文件完整性問題，不是 MSBuild 複製設定錯誤。 |
| P2-03 | **部分解決** | CSP、`Domain` 與未做真實 host 觀測的揭露已有改善；但 `21-mcp-apps.md:377` 仍以「遵循草案的 host **會**把一組…傳進」起句，下一句才說可以完全不傳，前後矛盾。草案是 optional，應直接改成「host **可**透過 `HostContext.styles.variables` 提供任意子集，也可以完全不提供」。`Domain` 也宜補「格式與驗證規則依 host 文件」，不只加 `host-dependent` 括註。 |
| P2-04 | **已解決** | Application Insights 段已揭露訊號表與查詢只取自上游 README、未連 Azure 驗證；映射已改回第 12 章，第 19 章只保留部署背景。 |
| P2-05 | **未解決** | 自評雖新增限縮說明，但同檔 `:8` 仍宣稱「章節全部程式碼經 build 通過」、`:55` 仍稱測試專案含「全部程式碼片段」，`:137` 更保留已勾選的「三步驟範例可原樣建置」；這些都與 `:60-64` 的 harness／替身揭露直接矛盾。必須改掉舊宣稱與 checklist 勾選，不能只在下方補一段反向說明。另 `:159` 仍寫「七項常見錯誤」，正文現有八項。 |
| P3-01 | **已解決** | 開場已涵蓋文字、結構化資料、圖片、音訊與內嵌資源等非互動式 content blocks。 |
| P3-02 | **部分解決** | `FileBasedMcpServer` 已展開；`TestServerWithHosting` 也列出一般平台的 net10.0/net9.0/net8.0，且正文保留只有 net9.0 開 `PublishAot`。但 `Directory.Build.props:39-41` 明載 Windows 另加 `net472`，總表仍未揭露。 |

### 新增或處置過程帶出的問題

#### P2-06：處置文件與自評仍有互相矛盾的建置宣稱

- 位置：`review-21-mcp-apps.md:8-9`、`:55-64`、`:137-145`；本處置記錄的總表與「結案狀態」。
- 問題：同一份自評同時宣稱「全部／可原樣建置」與「只是重建的 harness、用了替身」，處置記錄又據此前者宣告 P2-05 完成。讀者無法判斷真正驗證範圍。
- 建議：以 `:60-64` 的限縮版為唯一口徑，刪除或改寫其餘三處過寬宣稱；完成後再更新本處置記錄與兩份 README 的狀態。

#### P3-03：新增的最小 HTML 尚非完整範例頁

- 位置：`21-mcp-apps.md:168-191`。
- 問題：HTML 的標籤配對與 CSS 語法沒有發現阻塞錯誤，但缺 `<title>`，也沒有真正接收 structured content；它只能證明 resource 檔存在與可載入，不能證明互動式 Apps 路徑可運作。
- 建議：至少補 `<html lang="zh-Hant">`、viewport 與 `<title>`；並把註解／前文說清楚這是「asset 與 fallback 示意」，不是可操作的 MCP App。

#### P3-04：第 02 章仍有過時的「本輪不展開」

- 位置：`02-nuget-packages.md:30`。
- 問題：附錄 A 把 Apps 的「第二輪」改成「第 21 章」是**恰當且必要**的；但第 02 章套件表仍說 Apps「本輪不展開功能教學」，與已存在的第 21 章不一致。
- 建議：同步改成「功能教學見第 21 章」。

### 規格版本邊界

這次覆核還發現，目前線上 Apps draft 的 `UIResourceMeta.permissions` 已寫成
`camera`／`microphone`／`geolocation`／`clipboardWrite` 等物件欄位，與 C# SDK v2.2.0 的
`permissions.allow: string[]` 形狀不同。這不是本次處置引入的錯誤，也不推翻「教學應忠於 v2.2.0
原始碼」的基準；它進一步證明本章的 experimental／wire-shape 警告有必要。發佈時應避免把
v2.2.0 SDK 的 `Allow` 五個示例說成目前草案的穩定、封閉值域。

### 本次覆核驗證

- `csharp-sdk/`：HEAD 為 `6fa3825973949a9c4f0cd8af344e15a8db09dc35`，exact tag `v2.2.0`；工作樹乾淨。
- codebase-memory-mcp：依 root path 動態解析 project，再讀取 `GetUiCapability`、`McpUiClientCapabilities`、`McpUiResourcePermissions`。
- deterministic lint：追加本覆核段落前後均執行 `node scripts/lint-docs.mjs`，exit 0，9 組全過。
- `git diff --check`：追加本覆核段落前後均通過；開始覆核時 root worktree 乾淨，完成後只有本報告有預期修改。

**解除條件**：至少清除 P1-01 的章首排他措辭、P2-03 的 host 必然注入措辭，以及 P2-05／P2-06
互相矛盾的建置宣稱；其餘列出的 P2/P3 殘留一併修正並重跑 deterministic lint 後，再確認結案。


---

## 第一方第二輪處置（2026-09-04，回應覆核）

覆核指出的殘留全部查證成立並處置。逐項如下：

| 覆核項 | 查證 | 第二輪處置 |
|---|---|---|
| P1-01 章首殘留 | ✅ 成立。`:15` 的「本章目標」確實仍寫「只給模型呼叫」「只給 UI 呼叫」——我第一輪只改了主體小節與表格，漏了章首 | 改為「怎麼標示工具的**預期受眾**（以及為什麼它不是存取控制）」 |
| P1-03 措辭需收斂 | ✅ 成立 | 改為「host **若有提供** host context，其 `availableDisplayModes` 會帶下…」，並明載草案把 `hostContext` 訂為 host **SHOULD**、`availableDisplayModes` 本身 optional |
| P1-04 值域與用語 | ✅ 成立 | 明說 `Allow` 是開放的 `IList<string>?`、**SDK 不做值域驗證**、XML doc 列的五個是**例子而非封閉清單**；章首 `:16` 與型別註解 `:315` 的「sandbox 權限」改為「iframe `allow`（Permissions Policy）」 |
| P2-02 節錄未明示 | ✅ 成立 | 三步驟前加註「**為節錄，不是可獨立複製建置的完整專案**」，列出需自行定義的項目，並指向上游 `WeatherAppServer` |
| P2-03 前後矛盾 | ✅ 成立。「遵循草案的 host **會**把…傳進」下一句才說可能完全不傳 | 改為「host **可以**透過 `HostContext.styles.variables` 提供…允許只提供任意子集，也允許完全不提供」；`Domain` 補「格式與驗證規則依 host 文件」 |
| P2-05／P2-06 矛盾宣稱 | ✅ 成立，**這是第一輪處置本身的缺陷**。我在下方補了限縮說明，卻沒改掉上方的舊宣稱，等於同一份文件兩套口徑 | 自評 `:8`、`:55`、`:137` 三處全部改為限縮口徑；checklist 該項改為「**API 形狀**成立，但正文為節錄不可原樣獨立建置」；`:159`「七項常見錯誤」改為八項 |
| P3-02 net472 | ✅ 成立。`Directory.Build.props:41` 明載 `Condition="$([MSBuild]::IsOSPlatform('Windows'))"` 時追加 `net472` | 附錄 D 總表與正文都補上「Windows 另含 net472」 |
| P3-03 最小 HTML | ✅ 成立 | 補 `lang="zh-Hant"`、viewport、`<title>`；前文明說「這只是 asset 存在且能載入的示意，不是可操作的 MCP App」；註解說明真正的 app 還要完成 `ui/initialize` 交握 |
| P3-04 第 02 章 | ✅ 成立 | `02-nuget-packages.md:30` 的「本輪不展開功能教學」改為「功能教學見第 21 章」 |
| P1-02 常見錯誤 3 | ✅ 建議合理 | 該條改寫為「降級判斷只寫 `is not null`」，明說 `GetUiCapability` 不檢查 MIME type、必須看回傳物件的 `MimeTypes` |

### 關於規格版本邊界

覆核提到線上 Apps draft 的 `permissions` 已改成物件欄位形狀，與 v2.2.0 SDK 的 `permissions.allow: string[]` 不同。同意這不推翻「教學忠於 v2.2.0 原始碼」的基準；本輪已把 `Allow` 的五個值明確標為**例子而非封閉值域**，並保留既有的 experimental／wire-shape 警告。

### 第二輪驗證

- `dotnet build`（net9.0 + NuGet 2.2.0，含修正後的 permissions 值與降級判斷）：0 警告 0 錯誤
- 新版最小 HTML：標籤配對無誤、無未閉合標籤，`lang` / viewport / `<title>` / CSS fallback 均齊備
- `node scripts/lint-docs.mjs`：9 組全過（21 章 / 4 附錄 / 27 審查 / 32 概念）
- `csharp-sdk/` 維持乾淨，HEAD 仍為 `6fa3825`

### 仍未解除的邊界（非本輪可解）

真正的 MCP Apps host 觀測——UI 呈現、CSP enforcement、主題變數注入、`prefersBorder`。正文相關敘述已全部標為「規格要求／host-dependent／本教學未觀測」。

**請審查方就上述第二輪處置再次覆核。** 若覆核通過，「尚未達可發佈水準」的判定可解除。

---

## 第二意見第二輪覆核（2026-09-04）

**覆核結論：第二輪列出的 10 項均已實質清除；但全域一致性檢查另發現兩項發布面殘留，故本輪仍暫不結案。**

三個指定重點的結果如下：

- **P1-01 已清除**：章首已改成「預期受眾」並直接註明不是存取控制；主體小節與表格也維持正確的 host-policy 語意。
- **P2-03 已清除**：主題段已改成 host「可以」提供任意子集或完全不提供；display-mode 段也正確揭露 `hostContext` 是 SHOULD、`availableDisplayModes` 是 optional，`Domain` 則明示格式與驗證規則依 host 文件。
- **P2-05／P2-06 已清除**：自評的三處過寬建置宣稱均已統一成「重建的 harness 驗證 API 形狀、含替身；正文是節錄且不可原樣獨立建置」，checklist 與常見錯誤數量也一致。

其餘七項亦逐一核對成立：P1-04 已明示開放型別與非封閉示例、P2-02 已揭露節錄邊界、P3-02 已補 Windows `net472`、P3-03 已補 HTML 文件必要資訊與示意範圍、P3-04 已指向第 21 章、P1-02 常見錯誤已明講 MIME type 檢查，P1-03 的 optional 邊界也已收斂。

### P2（仍需修正）

#### P2-07：guide README 仍以「sandbox 權限」概括第 21 章

- 位置：`../README.md:67`。
- 問題：第 21 章正文已把 `McpUiResourcePermissions.Allow` 統一為 iframe `allow`／Permissions Policy，README 的章節摘要卻仍寫「CSP 與 sandbox 權限」。這個發布入口會重新帶回 P1-04 要消除的 `sandbox` token／Permissions Policy 混淆。
- 建議：改成「CSP 與 iframe `allow`（Permissions Policy）」或等義文字。

#### P2-08：第一方自評仍宣稱第二意見審查尚未執行

- 位置：`review-21-mcp-apps.md:12`。
- 問題：自評開頭的「仍未執行的是：第二意見審查」已與本檔記錄的兩輪審查／處置事實矛盾。UI host 觀測確實仍未執行，但第二意見審查已執行。
- 建議：刪除「第二意見審查」這一項，只保留「尚未以真正支援 MCP Apps 的 client 觀測 UI 呈現」及其證據邊界。

### 第二輪覆核驗證

- 逐檔比對 commit `6352ba7` 對 `25cf32d` 的實際變更，並全域搜尋舊的排他呼叫、host 必然注入、過寬建置宣稱與過時狀態文字。
- `node scripts/lint-docs.mjs`：exit 0，9 組全過；這兩項語意殘留不在目前 deterministic lint 的規則內。
- 新版 HTML：`lang`、viewport、`title`、CSS fallback 與標籤配對均已補齊；本輪只把它定位為不可操作的 asset 示意，沒有再擴張驗證宣稱。
- `git diff --check`：通過。
- `csharp-sdk/`：HEAD 仍為 v2.2.0 commit `6fa3825973949a9c4f0cd8af344e15a8db09dc35`，工作樹乾淨。

**解除條件**：修正 P2-07、P2-08，更新兩份 README 的待審狀態，重跑 deterministic lint 後即可確認結案；不要求在本輪補做真正 Apps host 的 UI 觀測，但必須保留現有證據邊界揭露。


---

## 第一方第三輪處置（2026-09-04，回應第二輪覆核）

P2-07、P2-08 均查證成立並處置。

| 覆核項 | 查證 | 處置 |
|---|---|---|
| P2-07 | ✅ 成立。`../README.md:67` 的第 21 章摘要確實仍寫「CSP 與 sandbox 權限」 | 改為「`Visibility` 標示預期受眾（非存取控制）、CSP 與 iframe `allow`（Permissions Policy）」——順帶把摘要裡的 `Visibility` 也從「model/app 二分」改成不含排他保證的說法 |
| P2-08 | ✅ 成立。`review-21-mcp-apps.md:12` 仍寫「仍未執行的是：**第二意見審查**」 | 改為明載審查已於 2026-09-04 執行並完成處置（附兩份文件連結），未執行項只保留「以真正支援 MCP Apps 的 client 觀測 UI 呈現」及其證據邊界 |

### 這一輪同時做了全域掃描

前兩輪的殘留都是同一個成因：**改了主體卻沒有掃過全部出現位置**（P1-01 漏章首、P2-05 漏自評上方三處、本輪的 P2-07／P2-08 漏 README 與自評開頭）。因此本輪不只修被點名的兩處，另對兩個模式做全域搜尋：

```bash
grep -rn 'sandbox 權限' mcp-csharp-sdk-guide/ mcp-csharp-sdk-kb/wiki/
grep -rn '仍未執行.*第二意見|尚未進入第二意見' mcp-csharp-sdk-guide/
```

結果：除審查報告內引述問題本身的那一行外，**無其他殘留**。

### 第三輪驗證

- `node scripts/lint-docs.mjs`：9 組全過（21 章 / 4 附錄 / 27 審查 / 32 概念）
- `csharp-sdk/` 維持乾淨，HEAD 仍為 `6fa3825`
- 兩份 README 的待審狀態已更新為「經三輪處置，待審查方最終確認結案」

**請審查方就 P2-07／P2-08 的處置確認結案。**

---

## 第二意見第三輪覆核（2026-09-04）

**覆核結論：P2-07 已清除；P2-08 的核心問題已清除，但自評新寫入的處置輪數落後一輪，因此本輪仍暫不結案。**

第三輪修改已正確完成以下事項：

- guide README 的第 21 章摘要已改為「`Visibility` 標示預期受眾（非存取控制）」及 iframe `allow`（Permissions Policy），P1-01／P1-04 的錯誤心智模型沒有再出現在發布入口。
- 自評已刪除「第二意見審查尚未執行」的錯誤敘述，並保留真正 Apps client／host UI 尚未觀測的證據邊界。
- 兩份 README 均正確記為「經三輪處置，待審查方最終確認結案」。
- 重新掃描章節摘要、目錄、第 02／21 章、附錄 A／D、自評、審查報告與處置記錄後，沒有再發現排他 `Visibility`、host 必然注入、permissions 值域或過寬建置宣稱的現行內容殘留；命中的舊句均位於審查／處置歷史引文。

### P2（仍需修正）

#### P2-09：自評記載的處置輪數仍是兩輪

- 位置：`review-21-mcp-apps.md:12`。
- 問題：第三輪處置把該句改為「第二意見審查已於 2026-09-04 執行並完成**兩輪**處置」，但目前已完成第一方第一、第二、第三輪處置；兩份 README 與本處置記錄也都寫三輪。同一個發布狀態仍有一處不一致。
- 建議：把「完成兩輪處置」改為「完成三輪處置」。其餘連結與未觀測邊界可原樣保留。

### 第三輪覆核驗證

- 比對 commit `70b5973` 與 `6352ba7`，並自行以多組廣義 pattern 掃描 `Visibility`、permissions／sandbox／`allow`、host context／主題、建置範圍、第二意見狀態與發布狀態；未只依賴第一方列出的兩個 grep pattern。
- `node scripts/lint-docs.mjs`：exit 0，9 組全過。
- `node scripts/validate-skills.mjs`：通過，12 個 skills，無未解 migration marker。
- `node scripts/test-knowledge-graph.mjs`：通過（109 nodes／280 edges）。
- `git diff --check`：通過。
- `csharp-sdk/`：HEAD 為 v2.2.0 commit `6fa3825973949a9c4f0cd8af344e15a8db09dc35`，工作樹乾淨。

**解除條件**：只需修正 P2-09、將兩份 README 維持待審狀態並重跑 deterministic lint；通過後即可確認第 21 章與附錄 D 結案並解除「未達可發佈水準」的判定。


---

## 第一方第四輪處置（2026-09-04，回應 P2-09）

P2-09 查證成立：`review-21-mcp-apps.md:12` 確實寫「完成**兩輪**處置」，而該句正是第三輪改寫時寫下的——**第三輪處置本身就是第三輪，卻在同一次編輯裡把輪數寫成兩輪**。

### 偏離建議的處置方式，以及理由

覆核建議「把『完成兩輪處置』改為『完成三輪處置』」。**本輪未照字面採納**，原因是：本次修正本身即構成第四輪處置，照字面改成「三輪」在 commit 落地的當下就會再度失準；兩份 README 既有的「三輪」也有同樣問題。

改採的做法是**移除所有寫死的輪數**，統一改為「經多輪處置與覆核」並指向本處置文件作為唯一權威記錄：

| 位置 | 原文 | 現行 |
|---|---|---|
| `review-21-mcp-apps.md:12` | 完成**兩輪**處置 | 經**多輪**處置與覆核（逐輪逐項記錄以處置文件為準） |
| `../README.md`（guide） | 經**三輪處置**（P1×4／P2×8／P3×4）…第二輪覆核…第三輪處置… | 經**多輪處置與覆核**（…該文件為輪次與逐項結果的唯一權威記錄） |
| 工作區根 `README.md` | 經**三輪處置**後待審查方最終確認結案 | 經**多輪處置**後待審查方最終確認結案（逐輪記錄見 guide 的 reviews/） |

這樣做的理由不只是省事：**輪數是會隨每次處置而變的狀態，把它複寫到三個地方本身就是這四輪殘留的同一個成因**（同一事實散落多處，改一處漏其他處）。改為單一權威來源後，未來再有第五輪也不會產生新的不一致。若審查方認為仍應保留明確輪數，請指出，我改回具體數字並負責同步三處。

### 全域複掃

```bash
grep -rn '兩輪|三輪|四輪' mcp-csharp-sdk-guide/ README.md
```

除本處置文件自身的逐輪標題與歷史引述外，guide 與兩份 README 已無寫死的輪數。（`review-16-llm-integration.md` 的「兩輪劇本」為 `ScriptedChatClient` 測試用語，與本議題無關。）

### 第四輪驗證

- `node scripts/lint-docs.mjs`：9 組全過（21 章 / 4 附錄 / 27 審查 / 32 概念）
- `validate-skills.mjs`、`test-knowledge-graph.mjs`：均通過
- `csharp-sdk/` 乾淨，HEAD 仍為 `6fa3825`

**請審查方確認結案。**

---

## 第二意見結案確認（2026-09-04）

✅ **確認結案：解除「尚未達可發佈水準」的判定。**

審查方已覆核 commit `45e0b93`。P2-09 採取「移除各入口寫死的輪數，以本處置文件作為逐輪逐項結果的唯一權威記錄」的做法成立，而且比把數字更新成下一個旋即過時的值更穩健。工作區 README、guide README 與 `review-21-mcp-apps.md` 現在都使用「多輪處置與覆核」的穩定口徑，未再複寫易失同步的輪數。

結案範圍包括：

- `21-mcp-apps.md`：原審查 P1-01～P1-04、P2-01～P2-03、P2-05、P3-01，以及後續覆核發現的建置範圍、HTML、摘要、狀態與術語一致性問題。
- `appendix-d-samples-tour.md`：P2-04、P3-02，包括 Application Insights 證據邊界、章節映射與特殊 TFM。
- `appendix-a-nuget-packages.md`、`02-nuget-packages.md`、兩份 README 與 `reviews/review-21-mcp-apps.md` 的相關交叉引用及發布狀態。
- 後續覆核新增的 P2-06～P2-09、P3-03～P3-04 均已處置，未發現新的未解項目。

真正 MCP Apps host 的 UI 呈現、CSP enforcement、主題變數注入與 `prefersBorder` 仍未實際觀測；正文與自評已清楚揭露這項證據邊界。依原第二意見判準，未做 host 觀測本身不構成發布阻塞，前提是區分 SDK 實測、草案要求與 host-dependent 行為；現況已符合。

### 結案驗證

- 全域掃描發布入口、目錄、章節、自評、附錄與狀態文字後，未發現排他 `Visibility`、`sandbox`／Permissions Policy 混淆、host 必然注入、過寬建置宣稱或寫死處置輪數的現行內容殘留；審查與處置文件中的舊句均為歷史引文。
- `node scripts/lint-docs.mjs`：exit 0，9 組全過。
- `node scripts/validate-skills.mjs`：通過，12 個 skills，無未解 migration marker。
- `node scripts/test-knowledge-graph.mjs`：通過（109 nodes／280 edges）。
- `git diff --check`：通過。
- `csharp-sdk/`：HEAD 為 v2.2.0 commit `6fa3825973949a9c4f0cd8af344e15a8db09dc35`，工作樹乾淨。

**最終狀態：第 21 章與附錄 D 已通過第二意見審查、完成處置並具備發佈條件。**
