# 第 21 章與附錄 D 第二意見審查結果（2026-09-04）

審查範圍：`../21-mcp-apps.md`、`../appendix-d-samples-tour.md`，以及撰寫方自評
`review-21-mcp-apps.md`。未重審第 01–20 章與附錄 A/B/C；只在跨章指涉需要時抽查。

查證基準：上游 `../../csharp-sdk/` commit
`6fa3825973949a9c4f0cd8af344e15a8db09dc35`、codebase-memory-mcp 動態解析出的 project
`Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk`、本地 raw/KB，以及 repo 外新建的
net9.0 + NuGet 2.2.0 暫存專案。未修改 guide 正文、KB 或上游 clone。

## 總結

**目前整批尚未達可發佈水準。** 附錄 D 的 sample 數量與 TFM 盤點大致正確，單獨看已接近可交付；
但第 21 章仍有四項 P1：`Visibility` 的表格與安全警告互相矛盾、降級判斷沒有檢查 client 支援的
MIME type、顯示模式的協商層級說錯，以及把 iframe `allow` 權限誤寫成 `scripts/forms/popups`。
前兩項會直接造成錯誤的安全或相容性心智模型，應在發佈前修正。

最優先處理順序：

1. 把 `Visibility` 全段改成「host 應執行的呈現／路由語意」，不要再寫成 server 已限制誰能呼叫。
2. 降級條件同時檢查 extension 與 `McpApps.HtmlMimeType`。
3. 把 display-mode 協商改成 app view ↔ host 的 `ui/initialize`，並修正 permissions 範例值。
4. 補齊 UI HTML 的輸出設定與 experimental production 決策提醒，再處理附錄 D 的實測揭露與章節映射。

三項指定的關鍵主張均已獨立覆核，**第一方的結論成立**：

| 主張 | 第二意見結果 | 獨立證據 |
|---|---|---|
| `Visibility = [App]` 仍出現在 `tools/list` | 成立，而且同一 client 可直接 `tools/call` 成功 | 暫存 server 回傳 `{"name":"app_only", ... "visibility":["app"]}`，隨後呼叫回傳 `"called"`；`McpAppsBuilderExtensions.cs:62-67` 只套 metadata，沒有過濾 |
| `[McpMeta("ui", "{...}")]` 產生字串 | 成立 | 同一次 `resources/list`：位置參數為 `"ui":"{\"prefersBorder\":true}"`，具名 `JsonValue` 為 `"ui":{"prefersBorder":true}`；另見 `McpMetaAttribute.cs:53-57` |
| `WithMcpApps()` 本身不觸發 `MCPEXP003` | 成立 | 新專案把呼叫放在 pragma 外仍以 0 warning / 0 error 建置；移除其餘 pragma 後只有 `McpAppUiAttribute`、`McpUiToolVisibility`、`McpApps` 報 error，`WithMcpApps()` 行沒有診斷 |

## 依嚴重度分級的發現清單

### P1（需修正才可發佈）

#### P1-01：`Visibility` 的表格仍把 metadata 說成 server 端呼叫限制

- 位置：`../21-mcp-apps.md:15`、`:209-227`；與同檔 `:229-236`、`:358-360` 直接矛盾。
- 問題：表格寫「只有 LLM 能呼叫／只有 app UI 能呼叫」，下一段才說 server 不過濾、任何 client
  都能直接呼叫。讀者通常會先把表格當規則；後面的強警告雖然語氣足夠，仍無法消除同頁前文造成的
  安全誤解。
- 查證：獨立 Streamable HTTP 實測確認 app-only 工具仍列在 `tools/list`，且直接 `tools/call`
  成功。上游 `src/ModelContextProtocol.Extensions.Apps/Server/McpAppsBuilderExtensions.cs:52-67`
  只把 attribute 套進 `_meta.ui`；沒有授權或清單過濾邏輯。
- 建議：小節改名為「工具的預期受眾（由 host 解讀）」，表格改寫為「host 應只向 agent 暴露／host
  應只允許同連線 app 呼叫」。把「SDK server 不執行這項 policy；工具內仍須驗證身分與授權」移到表格前。

#### P1-02：優雅降級只檢查 extension 是否存在，沒有檢查 HTML MIME type

- 位置：`../21-mcp-apps.md:240-261`、`:346-348`。
- 問題：`GetUiCapability(...) is not null` 只代表 extension value 可解析成物件，不代表 client 支援
  `text/html;profile=mcp-app`。未來 client 只支援其他 UI MIME type 時，範例會錯走 UI 分支並回傳
  「已載入 UI」。
- 查證：`src/ModelContextProtocol.Extensions.Apps/Server/McpApps.cs:81-115` 不驗證 `MimeTypes`；
  `McpUiClientCapabilities.cs:18-25` 明寫支援 Apps 的 client 必須把 HTML MIME type 放進清單。
  章節所連的 Apps draft 在 Client Capabilities 也把 `mimeTypes` 列為 required，範例使用
  `uiCap?.mimeTypes?.includes(RESOURCE_MIME_TYPE)`。
- 建議：條件改成 `uiCapability?.MimeTypes?.Contains(McpApps.HtmlMimeType) == true` 才走 UI 路徑；
  否則回完整文字／structured content。正文也應把 `GetUiCapability` 定位為「解析 capability」，不要說
  非 null 本身就已完成格式相容性檢查。

#### P1-03：display modes 不是在 server ↔ client 的 MCP extension capability exchange 協商

- 位置：`../21-mcp-apps.md:319-323`，尤其 `:321`。
- 問題：`inline/fullscreen/pip` 的可用模式是在 app view 與 host 的 UI 初始化／host context 中交換，
  view 之後可送 `ui/request-display-mode`；不是本章前面所示 server ↔ client
  `extensions["io.modelcontextprotocol/ui"]` capability payload 的逐項協商。
- 查證：v2.2.0 C# 型別 `McpUiClientCapabilities` 只有 `MimeTypes`；章節連結的
  [MCP Apps draft](https://github.com/modelcontextprotocol/ext-apps/blob/main/specification/draft/apps.mdx)
  把 view 支援模式放在 `ui/initialize` 的 `appCapabilities.availableDisplayModes`，host 支援模式放在
  `HostContext.availableDisplayModes`。
- 建議：改成「server 端沒有逐工具 display-mode API；模式由 app view 與 host 在 UI 專用初始化及後續
  request/notification 中協調」。因規格仍是 draft，避免把現在的 wire shape 寫成長期保證。

#### P1-04：`McpUiResourcePermissions.Allow` 的值舉錯類型

- 位置：`../21-mcp-apps.md:16`、`:270-287`，尤其 `:286` 的 `scripts、forms、popups`。
- 問題：`Allow` 對應 iframe 的 `allow`（Permissions Policy）值；`scripts/forms/popups` 是 iframe
  `sandbox` attribute 的 token 類型，不是這個清單的正確示例。照章節填值會形成錯誤設定與安全心智模型。
- 查證：`src/ModelContextProtocol.Extensions.Apps/Server/McpUiResourcePermissions.cs:7-12,18-26`
  明列 `camera`、`microphone`、`geolocation`、`clipboard-read`、`clipboard-write`，並說明對應 iframe
  `allow` attribute。官方 conceptual doc 的 `scripts/forms/popups` 轉述本身不可靠，不能凌駕原始碼。
- 建議：改稱「iframe `allow`／Permissions Policy 請求」，示例換成上述實際值；另註明 host 是否核准
  仍由 host policy 決定，不能當授權機制。

### P2（建議改善）

#### P2-01：experimental 警告密度夠，但 production 決策防線仍不足

- 位置：`../21-mcp-apps.md:5`、`:48-77`、`:290`、`:338-340`。
- 評估：章首、獨立小節、最小 pragma 與常見錯誤都有警告，**密度本身足夠**；不足的是沒有明說
  「抑制診斷只表示接受編譯風險，不會讓 API 或 draft wire contract 變穩定」。同章又直接給「正式環境」
  建議，容易讓讀者把 pragma 視為完成 production readiness。
- 建議：在安裝／pragma 後增加 production gate：pin SDK 版本、隔離 Apps adapter 或 feature flag、針對實際
  host 做相容性測試、升級時重驗 metadata/wire shape；未做真實 Apps client 驗證的範圍應在正文而不只在 review。

#### P2-02：「上手範例」缺少 UI 檔案與輸出複製設定，正文不能照抄跑通

- 位置：`../21-mcp-apps.md:79-194`，尤其 `:140-149`。
- 問題：resource 從 `AppContext.BaseDirectory/ui/weather-forecast.html` 讀檔，但章節沒有建立 HTML，也沒有
  把它複製到 output 的 `.csproj` 設定。工具片段還保留 `UsCity`、`forecastData` 與省略號，因此第一方自評的
  「三步驟範例可原樣建置」不能由正文重現。
- 查證：上游 `samples/WeatherAppServer/WeatherAppServer.csproj:16-18` 額外使用
  `<Content Include="ui\*.html" CopyToOutputDirectory="PreserveNewest" />`；正文未包含對應步驟。
- 建議：至少補 output-copy 項目與一份最小 HTML，或明確標成「節錄、不可獨立建置」，並把完整可跑版本
  的必要檔案逐一列出。這不要求補做真實 host UI 驗證，但要避免 server 在 `resources/read` 時
  `FileNotFoundException`。

#### P2-03：未經 host 觀測的行為寫得過度確定，主題句甚至高於規格保證

- 位置：`../21-mcp-apps.md:153`、`:263-290`、`:319-323`。
- 問題：CSP 可依規格描述為 host 的規範責任，但目前沒有實際 host 驗證；更明確的錯誤是「host 會把一組
  標準 CSS 變數傳進 iframe」。Apps draft 說 host **可以**傳入任意子集，也可以完全不傳；view 應自備 fallback。
  `Domain` 也是 host-dependent，格式與驗證規則須看 host 文件。
- 查證：上游 C# `McpUiResourceCsp.cs:7-16` 只描述 metadata 用途，不證明某個 host 已執行；Apps draft 的
  Theming/Domain 段分別寫 optional/subset/none 與 host-dependent。
- 建議：把「會／完全不用操心」改成「支援且遵循 draft 的 host 可提供」；CSS 必須給 fallback；CSP、
  `prefersBorder`、`Domain` 標明本教學未在真實 Apps host 觀測。

#### P2-04：附錄 D 的 Application Insights 段落缺少驗證層級揭露，且第 19 章映射不成立

- 位置：`../appendix-d-samples-tour.md:73-107`、`:211`。
- 問題：切換 exporter 的程式碼敘述可由原始碼直接確認；但訊號映射與 Kusto 查詢只是逐字近似轉述上游
  README，沒有進 Application Insights 實測。正文目前用「進到之後怎麼落地」呈現為已觀測結果。
  此外第 19 章是 Docker 部署，未講 OpenTelemetry/Application Insights，稱這支是「第 19 章的遙測範例」
  與 `:211`「遙測與部署」都不是成立的跨章回扣。
- 查證：`samples/AspNetCoreMcpServer/Program.cs:39-59` 確認 exporter 分支；訊號表與 query 來自
  `samples/AspNetCoreMcpServer/README.md:25-48`。抽查 `../19-docker-deployment.md` 未找到 telemetry、
  OpenTelemetry 或 Application Insights；第 12 章才有相關佈線說明。
- 建議：段首加「以下為上游 README 的預期映射，本輪未連線 Azure 驗證」；把主要章節映射改為第 12 章，
  若保留第 19 章只能說一般部署背景，不能稱其為遙測章。

#### P2-05：第一方 review 的建置範圍與現況記錄不精確

- 位置：`review-21-mcp-apps.md:7-9`、`:53-60`、`:107-109`、`:126-136`。
- 問題：文件宣稱「章節全部程式碼／三步驟範例可原樣建置」，但自評自己又承認 HTTP 邏輯以假資料替代，
  而正文片段含未定義項目且缺 UI output-copy。另風險 8 說附錄 A 尚未納入 Apps TFM，但目前
  `../appendix-a-nuget-packages.md:42-48` 已有完整一列，`../02-nuget-packages.md:109-117` 也已列入。
- 建議：把 build claim 限定為「重建的測試 harness 涵蓋 API 形狀」並列明替身／補充檔；風險 8 更新為已解決，
  只保留「第 21 章可否就地說明 sample 的 net10.0 不是套件門檻」。此外風險編號目前缺 3，實際只有
  8 個編號項，不是 9 個。

### P3（可選）

#### P3-01：第 21 章對既有工具輸出型態的開場概括過窄

- 位置：`../21-mcp-apps.md:22`。
- 問題：前章工具不只可回文字或 structured content，也可回 image/audio/embedded resource 等 content block。
- 建議：改成「到這裡為止，工具輸出主要是非互動式內容（文字、結構化資料或其他 content blocks）」即可。

#### P3-02：附錄 D 的特殊 TFM 可在總表直接展開

- 位置：`../appendix-d-samples-tour.md:30-33`、`:57-67`、`:113-115`。
- 結論：現有盤點**成立**，不是錯誤；但「單檔／多目標」不如具體值方便讀者判斷環境。
- 建議：`FileBasedMcpServer` 寫「.NET 10 file-based（無 csproj/TFM）」；`TestServerWithHosting` 寫
  `net10.0;net9.0;net8.0`（Windows 另含 `net472`），並保留只有 net9.0 設 `PublishAot=true` 的說明。

## 逐份審查結果

### 第 21 章：MCP Apps

動機、三構件、套件／namespace、builder post-configuration、typed metadata、AOT serializer 與
`McpMeta.JsonValue` 陷阱的編排清楚。第 05 章 structured content、第 07 章 resource、第 12 章 HTTP、
第 17 章 `MCPEXP002` 最小 pragma、第 18 章授權、第 20 章 source-generated JSON，以及附錄 D 的連結均成立。

但本章目前**不應發佈**：P1-01 與 P1-02 會導致 security／fallback 實作錯誤；P1-03 與 P1-04 是具體技術
敘述錯誤。真正 Apps host 尚未驗證並非單獨的發布阻塞，前提是正文誠實區分「SDK 實測」「規格要求」與
「host-dependent、未觀測」。UI HTML 未納入上手流程則使教學的可照做性不足，應一併補齊。

第 21 章放在「第八部分：Extension 生態」合理。Tasks 雖也是獨立 extension，但它直接延續 Sampling／
Elicitation 的長流程控制議題，留在第六部分有清楚的教學連續性；README `:69` 的一句解釋足夠，不建議
為了套件分類而搬動第 17 章。

### 附錄 D：官方 Samples 導覽

13 支 sample 的列舉完整，12 個 csproj 的 TFM 與兩個特例均核對成立：net8.0 五支、net9.0 五支、
`WeatherAppServer` net10.0、`TestServerWithHosting` 使用 `$(DefaultTestTargetFrameworks)`，另有無 csproj 的
`.NET 10` file-based program。README 數量 8 也正確。

大部分章節映射成立；唯一明確失配是把 Application Insights／遙測指向第 19 章。Application Insights
段落的 wiring、訊號表與 Kusto query 均能追到官方 sample 的 Program/README，未發現轉述抄錯；但由於沒有
Azure 實測，應標為「上游 README 提供的預期映射與查詢」，不能讓讀者誤認為本教學已觀測到資料落地。
完成 P2-04 後，附錄 D 可達交付水準。

## 對第一方自評的覆核

`review-21-mcp-apps.md` 實際列出 1、2、4、5、6、7、8、9，共八個編號項；編號 3 缺漏。以下仍按原編號覆核：

| 原項目 | 覆核結果 | 說明 |
|---|---|---|
| 1. 未跑真正 Apps client | **成立** | 確為主要證據邊界；不必在本輪補跑，但正文須弱化 host-dependent 行為。 |
| 2. typed resource meta 未逐欄位實測 | **部分成立** | 第一方自己未測的陳述成立；不過上游 `McpAppsTests.cs:76-109` 已覆蓋 csp 四欄、permissions、domain、prefersBorder 的 JSON round-trip，結構正確性不是未解風險。 |
| 3. | **缺項** | 自評沒有第 3 項，應修正編號或補回遺漏內容。 |
| 4. `ApplyAppUiAttributes` 冪等性 | **未成立（作為缺陷風險）** | `McpApps.cs:143-150` 遇既有 `ui` 不覆寫；重複套用安全。上游 `SetAppUi_DoesNotOverwrite_ExistingUiKey` 亦覆蓋此規則。 |
| 5. 顯示模式敘述 | **成立，且升為 P1** | 「非逐工具 server API」成立，但協商雙方／階段說錯，見 P1-03。 |
| 6. `Visibility` 語意 | **執行期結論成立，章節處置仍不完整** | 警告本身夠強；前方表格仍寫成排他呼叫權，見 P1-01。 |
| 7. `Domain` 深度 | **成立** | 可不展開 OAuth 實作，但至少要說 host-dependent、需查 host 文件，見 P2-03。 |
| 8. Apps TFM 未進附錄 A | **未成立（現況已解決）** | 附錄 A `:48` 與第 02 章 `:117` 都已列 net10/net9/net8/netstandard2.0。仍可在第 21 章就地澄清 Weather sample 的 net10.0 不是套件門檻。 |
| 9. 與附錄 D 互連 | **未成立** | 兩檔目前都存在、相對連結有效；是否同批核准是流程問題，不是內容缺陷。 |

對「建置實測記錄」的覆核：三項 wire/runtime 結論與 `WithMcpApps` 診斷結論均由第二意見獨立重現；
但「章節全部程式碼可原樣建置」證據不足且與正文／自評後文矛盾，應依 P2-05 限縮。另有第一方未列出的
P1-02（MIME type 判斷）、P1-04（permissions 值類型）與 P2-02（UI asset 輸出設定）。

## 本輪驗證記錄

- codebase-memory-mcp：先以 `list_projects` 動態解析 `/csharp-sdk` project，再用 `search_graph`／
  `get_code_snippet` 查 `WithMcpApps`、`SetResourceUi`、`GetUiCapability`、`ApplyAppUiAttributes` 等符號。
- repo 外 net9.0 暫存專案：正式 NuGet `ModelContextProtocol.AspNetCore` 2.2.0 +
  `ModelContextProtocol.Extensions.Apps` 2.2.0；pragma 正確時 `dotnet build -warnaserror` 為 0 warning / 0 error。
- Streamable HTTP：`initialize` 回應含 `extensions.io.modelcontextprotocol/ui`；`tools/list` 保留 app-only；
  `tools/call` 可直接執行；`resources/list` 同時驗證位置參數與 `JsonValue` 的 JSON 形狀。
- 未執行：真正 MCP Apps host UI 呈現、CSP enforcement、theme 注入、Application Insights ingestion/Kusto。
- deterministic lint：`node scripts/lint-docs.mjs` exit 1，唯一錯誤為 reviews baseline 預期 25 份 Markdown、
  新增本報告後實際為 26 份。依本次「只產出報告」範圍未修改 lint baseline；處置本報告時需同步更新預期數量。
