# 審查說明：第 17 章「Tasks——長時間執行的持久任務」

> 對應檔案：[`../17-tasks.md`](../17-tasks.md)
> 製作日期：2026-07-16 ｜ 基準：ModelContextProtocol v1.4.0 ｜ ⚠️ 實驗性 API（MCPEXP001）
> 審查方法總則見 [README.md](./README.md)

## 章節概要

教 2025-11-25 規格的 Tasks（收據模式的長時間工具呼叫）：`McpTask` 狀態機、`ToolTaskSupport` 三態
與自動判斷、`IMcpTaskStore`/`InMemoryMcpTaskStore`、client 全流程（`CallToolAsTaskAsync` →
`PollTaskUntilCompleteAsync` → `GetTaskResultAsync`）、取消/列表/`TaskStatusHandler`、durable store、
以及 MCPEXP001 實驗性標記的正確面對方式。

## 製作過程摘要

**圖譜＋原始檔驗證**：client 六個 task API 逐一在 `McpClient.Methods.cs` 定位（行號見草稿
元資料）；`McpTask` 的 required 屬性；`ToolTaskSupport` 三態與自動判斷規則（attribute docstring）；
`Experimentals.cs` 的 MCPEXP001/002 分工；`PollTaskUntilCompleteAsync` 內建 PollInterval 邏輯
（預設 1s——直接讀實作確認）。

**程式碼實測**：dotnet test 20/20,ch17 相關 3 個——(1) 有 task store 時 async 工具的
`ProtocolTool.Execution?.TaskSupport == ToolTaskSupport.Optional`；(2) 完整流程：task 模式呼叫
立即回收據 → 輪詢至 `Completed` → `GetTaskResultAsync` 的 JsonElement 解析出工具回傳文字；
(3) `ListTasksAsync` 可見已建任務。**兩個編譯期陷阱是實測撞出來的**：MCPEXP001 不抑制直接編譯
錯誤；`IMcpTaskStore` 在根 namespace（CS0246）。

**事實修正**：wiki `tasks` 條目 frontmatter 的 namespace 原寫 `ModelContextProtocol.Server`,
與原始碼不符，已修正為根 `ModelContextProtocol` 並補 MCPEXP001 註記（2026-07-16）。

**內容來源**：wiki `tasks`；上游 `samples/LongRunningTasks`（durable store 段落）、
`tests/.../ToolTaskSupportTests.cs`（task store 註冊模式）。

## 已知取捨與風險點（請多看一眼）

1. **實驗性 API 的時效**：全章 API 隨規格演進可能變動。審查時值得確認 SDK 是否已出新版、
   MCPEXP001 是否仍存在／已升穩定。
2. **「收據模式」ASCII 圖**：協定訊息名（tasks/get、tasks/result）取自 client 實作中的
   `RequestMethods.TasksResult` 等常數，但完整協定往返未逐一抓 wire format 驗證。
3. **`CancelTaskAsync`／`TaskStatusHandler` 未實測**：兩者只做了簽名驗證（原始檔），
   本章測試沒有覆蓋取消流程與狀態推播（取消流程涉及時序，in-memory 測試易 flaky,刻意略過）。
4. **「stateless + tasks 是好搭檔」**：依據是 LongRunningTasks sample 本身用 stateless,
   以及「多實例共享 durable store」的推論——後者（水平擴展場景）**未實測**。
5. **`FileBasedMcpTaskStore`**：是 sample 自帶的示範類別，不是 SDK 內建 API,章節有標明但
   請確認讀者不會誤解為 NuGet 提供。
6. **`GetTaskResultAsync` 的 JSON 解析**（`content[0].text`）：假設結果是單一文字區塊的
   `CallToolResult`;結構化輸出（structuredContent）場景未提。

## 審查 checklist

### A. 結構宣告

- [ ] client 六 API 簽名與回傳型別（`CallToolAsTaskAsync`→`ValueTask<McpTask>`、`GetTaskResultAsync`→`ValueTask<JsonElement>` 等）
- [ ] `IMcpTaskStore`/`InMemoryMcpTaskStore` namespace 為根 `ModelContextProtocol`（原始檔 `Server/IMcpTaskStore.cs` L5）
- [ ] `ToolTaskSupport` 三值與預設 `Forbidden`;「async＋task store → 自動 Optional」規則
- [ ] `McpTask` 屬性表與原始檔一致（required 四項＋TTL/PollInterval/StatusMessage）
- [ ] MCPEXP001 訊息內容與 `Experimentals.cs` 一致；「編譯錯誤而非警告」的宣稱正確
- [ ] `McpClientHandlers.TaskStatusHandler` 委派型別

### B. 程式碼

- [ ] csproj `NoWarn` 寫法正確且兩側（server/client）都需要的說法成立
- [ ] server 上手範例可編譯（`AddMcpServer(options => options.TaskStore = ...)` 過載存在）
- [ ] client 三步驟程式碼與實測碼一致
- [ ] `FileBasedMcpTaskStore` 段落與 sample 原始碼一致（建構子參數）

### C. 敘述

- [ ] 收據模式圖的訊息方向與名稱（風險點 2）
- [ ] `InputRequired` 自動狀態的觸發條件（sampling/elicitation during task）與 SDK docstring 一致
- [ ] 「task store 是整個功能的開關」（沒註冊→capability 不宣告→Forbidden）正確
- [ ] 風險點 3/4 的未實測宣稱是否需要弱化措辭

### D. 教學品質

- [ ] 實驗性警告的位置與力度（夠醒目、不至於嚇跑讀者）
- [ ] 與 ch09 的分工說明（進度 vs tasks）是否清楚
- [ ] 常見錯誤 4 的建議（同步工具先想為什麼是同步）是否合理
- [ ] 交叉引用（ch05/09/12/13/14/15）正確；繁中語感與骨架完整性

## v2.0.0 breaking 更新（2026-08-03）

本章已依 drift item B-001 重寫。舊 review 上述製作過程保留為 v1.4.x 歷史證據，不再代表 current API。

- Tasks 已移至 `ModelContextProtocol.Extensions.Tasks`；公開 namespace 同為 `ModelContextProtocol.Extensions.Tasks`
- server 改用 `WithTasks(IMcpTaskStore)`；normal path 不再要求 MCPEXP001
- client 主線改用 `CallToolWithPollingAsync(CallToolRequestParams, ...)`
- 手動流程改為 `CallToolAsTaskAsync` → `GetTaskAsync`／`UpdateTaskAsync`／`CancelTaskAsync`
- `PollTaskUntilCompleteAsync`、`GetTaskResultAsync`、`ListTasksAsync`、`TaskStatusHandler` 與 `McpServerOptions.TaskStore` 已移除
- v2 與 v1.4.x experimental Tasks 無 API 或 wire compatibility

驗證依據：v2.0.0 source commit `15f8b2d`、codebase-memory-mcp snippets、官方 `docs/concepts/tasks/tasks.md`。更新後以 NuGet `ModelContextProtocol.AspNetCore`／`ModelContextProtocol.Extensions.Tasks` v2.0.0 scratch web project 編譯，結果 0 warning、0 error。
