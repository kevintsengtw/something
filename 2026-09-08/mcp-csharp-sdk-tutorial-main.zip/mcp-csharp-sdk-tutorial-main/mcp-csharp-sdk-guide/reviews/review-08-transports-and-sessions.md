# 審查說明：第 08 章「傳輸層總覽與 Sessions」

> 對應檔案：[`../08-transports-and-sessions.md`](../08-transports-and-sessions.md)
> 製作時期：2026-07-14 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建——製作過程摘要為事後整理）

## 章節概要

傳輸層總覽章：stdio（子行程、stderr 紀律）、Streamable HTTP（POST+SSE、stateful 的 GET 長連線）、
**stateful vs stateless 取捨表**（官方自 v1.2.0 偏好 stateless）、legacy SSE 淘汰
（`EnableLegacySse` [Obsolete] MCP9004）、`HttpTransportMode` 三值、session 選項概覽
（IdleTimeout/MaxIdleSessionCount/ConfigureSessionOptions/RunSessionHandler）、
stdio 環境變數安全（v1.4.0 `InheritEnvironmentVariables`）、resumability 與 in-memory 概覽。

## 製作過程摘要（事後整理）

- 依 Pipeline D 由 wiki `stdio-transport`+`streamable-http-transport`+`sessions` 三概念草擬，
  經人工 review 移入（草稿存檔 `outputs/draft-transports-and-sessions.2026-07-14.bak.md`）。
- 程式碼來源：官方 `docs/concepts/transports/transports.md`（章內有標）、
  `StdioClientTransportOptions` 文件註解。
- **後續章節大量重驗本章事實**：`HttpServerTransportOptions` 全屬性於 ch12 製作時逐一
  從原始碼核實（Stateless 預設 false、IdleTimeout 2h、MaxIdleSessionCount 10,000、
  EnableLegacySse+Stateless 互斥丟 InvalidOperationException、RunSessionHandler=MCPEXP002）；
  stateless 端點行為於 ch19 容器實測（POST initialize 成功）；in-memory 段於 ch13 完整實測；
  `StreamClientTransport` namespace 陷阱於 ch13 grep 確認。
- **未實測部分**：resumability（ResumeSessionAsync/KnownSessionId/EventStreamStore）、
  legacy SSE 路徑、`HttpTransportMode.AutoDetect` 的退回行為、stdio 環境變數白名單的實際效果。

## 已知取捨與風險點（請多看一眼）

1. **取捨表的「官方建議」表述**：「自 v1.2.0 起官方文件偏好 stateless」——文件語氣的轉譯，
   請對照 raw/docs-conceptual 原文確認力度（偏好 vs 建議 vs 預設方向）。
2. **`GetDefaultEnvironmentVariables()` 回傳的「安全子集」內容**（PATH、HOME 等）：
   取自文件註解，未列完整清單也未實測——跨平台差異（Windows 的 SystemRoot 等）未提。
3. **resumability 段**：API 名稱（`KnownSessionId`/`ResumeSessionAsync`/`ResumeClientSessionOptions`）
   撰寫時經圖譜/原始碼確認，但流程未端對端實測，且細節「屬部署議題」推給 ch12——ch12 實際上
   也只給了選項表，resumability 的完整操作全書沒有實作示範。審查者評估是否可接受此留白。
4. **`AutoDetect` 先試新協定再退 SSE**：行為描述來自原始碼/文件，未實測退回路徑。
5. **「時好時壞的 session 404」**（常見錯誤 4）：多實例＋stateful 的症狀推演，合理但未重現。

## 審查 checklist

### A. 結構宣告

- [ ] 取捨表六列與 `HttpServerTransportOptions.cs`/文件一致（尤其 Roots 歸入 server→client 清單）
- [ ] `StdioClientTransportOptions` 屬性清單（required Command、ShutdownTimeout 預設 5s、StandardErrorLines）
- [ ] `HttpTransportMode` 三值與預設 AutoDetect
- [ ] `EnableLegacySse` 的 [Obsolete]/MCP9004 與互斥例外（ch12 已核，對照即可）
- [ ] `InheritEnvironmentVariables` 預設 true、v1.4.0 新增

### B. 程式碼

- [ ] 四段範例與官方 transports 文件一致
- [ ] 環境變數白名單片段可編譯

### C. 敘述

- [ ] Streamable HTTP 的 POST+SSE 機制描述與 ch19 實測的 SSE 回應一致
- [ ] 「stateful 的 GET 長連線」與 stateless 不掛 GET 端點的描述正確
- [ ] 風險點 1 的官方語氣轉譯
- [ ] 常見錯誤七條逐一核對（本章常見錯誤最多，是高價值防雷區）

### D. 教學品質

- [ ] 三種傳輸的定位是否幫讀者快速選型
- [ ] 概覽段（resumability/in-memory）點到為止的深度是否合適
- [ ] 交叉引用正確；繁中語感；骨架完整

## v2.0.0 breaking 更新（2026-08-03）

依 drift item B-002 修正：`HttpServerTransportOptions.Stateless` 自 v2.0.0 起預設為 `true`。原 review 中「預設 false」僅代表 v1.4.0 歷史基準；current 章節已改為 stateless-by-default，並提醒依賴 server→client request 的既有服務明確設回 `false`。
