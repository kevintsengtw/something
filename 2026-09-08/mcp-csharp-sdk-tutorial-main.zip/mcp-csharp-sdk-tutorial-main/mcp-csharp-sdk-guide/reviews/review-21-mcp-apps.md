# 審查說明：第 21 章「MCP Apps——讓工具帶著互動式 UI」

> 對應檔案：[`../21-mcp-apps.md`](../21-mcp-apps.md)
> 製作日期：2026-09-04 ｜ 基準：ModelContextProtocol v2.2.0（commit `6fa3825`）
> 審查方法總則見 [README.md](./README.md)

> **建置與執行期驗證已於 2026-09-04 補做**（見「建置實測記錄」一節）。
> 以**重建的測試 harness**（涵蓋章節各片段的 API 形狀，含替身，見下）通過 `dotnet build`；
> server 實際啟動並以 `initialize`／`tools/list`／`resources/list` 驗證了三項執行期宣稱，
> 其中兩項**推翻了原本的敘述**，章節已據此修正。**正文的三步驟範例是節錄，不可原樣獨立建置。**
>
> **第二意見審查已於 2026-09-04 執行，並經多輪處置與覆核**（逐輪逐項記錄以處置文件為準）——審查報告見
> [second-opinion-review-ch21-appendix-d-2026-09-04.md](./second-opinion-review-ch21-appendix-d-2026-09-04.md)，
> 處置與覆核記錄見
> [second-opinion-resolution-ch21-appendix-d-2026-09-04.md](./second-opinion-resolution-ch21-appendix-d-2026-09-04.md)。
>
> ⚠️ 仍未執行的是**以真正支援 MCP Apps 的 client 觀測 UI 呈現**。UI 是否顯示、CSP 是否生效、
> 主題變數是否傳入 iframe、`prefersBorder` 是否被理會，這些仍屬未驗證；正文相關敘述
> 已全部標為「規格要求／host-dependent／本教學未觀測」。

## 章節概要

教 MCP Apps extension：`WithMcpApps()` + `[McpAppUi]` 把工具關聯到互動式 HTML UI resource、
`Visibility` 的 model／app 二分（含 app-only 工具）、UI resource 以 `ui://` scheme 與
`text/html;profile=mcp-app` MIME type 註冊、`McpUiResourceMeta` 的 CSP／權限／domain／
prefersBorder、以 `McpApps.GetUiCapability` 做優雅降級、非 attribute 的兩條程式化路徑
（`ApplyAppUiAttributes` / `SetAppUi` / `SetResourceUi`）、顯示模式與 host 主題的歸屬、
以及 `McpApps.SerializerOptions` 的 AOT 理由。

全章 API 皆標記 `[Experimental("MCPEXP003")]`，章節開頭與常見錯誤 1 都明示了這一點。

## 製作過程摘要

**圖譜＋原始檔驗證**（本章唯一實際執行的驗證層）：

- `search_graph` 確認存在：`WithMcpApps`（唯一定義處）、`McpAppUiAttribute`、`McpApps`、
  `McpUiToolVisibility`、`McpUiToolMeta`、`McpUiResourceMeta`、`McpUiResourceCsp`、
  `McpUiResourcePermissions`、`McpUiClientCapabilities`、`ApplyAppUiAttributes`、
  `SetAppUi`、`GetUiCapability`、`McpMetaAttribute`
- 逐檔讀取 `src/ModelContextProtocol.Extensions.Apps/Server/*.cs` 取得所有公開成員與
  JSON 屬性名；章節中的型別定義區塊為原始碼去除註解後的逐字轉寫
- `Experimentals.cs` 確認三個診斷 ID 的實際值（`MCPEXP001` / `MCPEXP002` / `MCPEXP003`）
  與 Apps 對應的是 `Apps_DiagnosticId = "MCPEXP003"`
- `McpApps.cs` 確認 `HtmlMimeType = "text/html;profile=mcp-app"`、
  `ExtensionId = "io.modelcontextprotocol/ui"`

**抓到並修正的事實錯誤**：`wiki/concepts/mcp-apps.md` 的 frontmatter 把 `WithMcpApps` 的
namespace 記為 `Microsoft.Extensions.DependencyInjection`，實際是
`ModelContextProtocol.Extensions.Apps`（`McpAppsBuilderExtensions.cs:7`，且
`samples/WeatherAppServer/Program.cs` 的 using 佐證）。wiki 已修正，章節的常見錯誤 2
專門講這個坑。

**內容來源**：`raw/docs-conceptual/apps.md`（官方 conceptual doc）、
`samples/WeatherAppServer/{Program.cs,WeatherTools.cs,WeatherResources.cs}`、
wiki `mcp-apps`。上手範例三步驟改寫自 WeatherAppServer；進階用法的程式碼片段
多數改寫自 apps.md。

## 建置實測記錄（2026-09-04）

**環境**：macOS、.NET SDK 10.0.400、目標 `net9.0`、`ModelContextProtocol.AspNetCore` 2.2.0
＋ `ModelContextProtocol.Extensions.Apps` 2.2.0（NuGet 正式套件，非本機專案參考）。
測試專案涵蓋章節各片段的 API 形狀（含替身）：三步驟範例、app-only 工具、優雅降級、兩條程式化路徑
（`ApplyAppUiAttributes` / `SetAppUi`）與 `McpApps.SerializerOptions` 序列化。

**編譯**：`dotnet build` 通過，**0 警告 0 錯誤**。

⚠️ **這句話的範圍必須限縮**：通過建置的是一個**重建的測試 harness**，涵蓋章節各片段的
**API 形狀**（型別、成員、attribute 用法、collection expression、pragma 位置），
不等於「正文可原樣複製建置」。harness 中使用了替身：`WeatherForecast` 的 HTTP 取值邏輯
以假資料替代（正文保留的 `client.GetAsync` → `JsonDocument` 完整版未經建置），
`UsCity` 為自建 enum，UI HTML 與 `.csproj` 的 `Content` 複製設定原本缺漏（已依 P2-02 補進正文）。

**MCPEXP003 反向測試**：移除全部 pragma 後 `--no-incremental` 重建，確認診斷為
**error 等級**（非 warning），共 32 筆，分布為 `McpApps` 12、`McpAppUiAttribute` 8、
`McpUiToolVisibility` 6、`McpUiToolMeta` 6。**`WithMcpApps()` 不觸發任何診斷**——
`Program.cs` 完全乾淨。章節原本寫「`WithMcpApps`…無一例外」，已修正。

**執行期驗證**（server 實際啟動，走 Streamable HTTP）：

| 宣稱 | 結果 |
|------|------|
| `WithMcpApps()` 會把 `io.modelcontextprotocol/ui` 加進 capabilities | ✅ 確認，`initialize` 回應含 `"extensions": {"io.modelcontextprotocol/ui": {}}` |
| app-only 工具不會出現在模型的工具清單 | ❌ **推翻**——`tools/list` 照樣回傳，只在 `_meta.ui.visibility` 標 `["app"]`；過濾是 host 的責任 |
| `[McpMeta("ui", "{...}")]` 產生的 `_meta.ui` 是物件 | ❌ **推翻**——位置參數形式產生的是 **JSON 字串**；需具名 `JsonValue = ` 才是物件 |

後兩項都已回寫章節（工具可見性段落的警告、步驟 2 改用 `JsonValue =` 並加說明、
常見錯誤 6 改寫、新增常見錯誤 7）。

> 附帶發現：上游 `samples/WeatherAppServer` 目前用的是 `[McpMeta("ui", """{...}""")]`
> 位置參數形式，因此它送出的 `_meta.ui` 也是字串。本教學未跟進這個寫法。

## 已知取捨與風險點（請多看一眼）

1. **沒有跑過任何支援 MCP Apps 的 client**。UI 實際會不會顯示、CSP 設定是否如描述般
   生效、`prefersBorder` host 是否理會、主題 CSS 變數是否真的傳進 iframe——全部未觀測，
   均為文件轉述。這是目前最大的缺口。

2. ~~`McpUiResourceMeta` 的型別化形狀未逐欄位比對~~ → **部分解除**（第二意見覆核）：
   上游 `McpAppsTests.McpUiResourceMeta_CanBeRoundtrippedAsJson` 已覆蓋 Domain／
   PrefersBorder／Csp 三個網域清單／Permissions 的 JSON round-trip，結構正確性不是
   未解風險。仍未驗的只有「真實 host 會不會照著解讀」。

3. **`McpApps.SetResourceUi` 未在測試專案中呼叫過**。章節只在文字提及其存在與用途，
   簽名雖經原始碼確認，但沒有實際編譯過呼叫端。

4. ~~`ApplyAppUiAttributes` 的冪等性未測~~ → **已解除**（第二意見覆核並經第一方確認）：
   `McpApps.SetAppUi` 有 `if (!protocolTool.Meta.ContainsKey("ui"))` 保護，既有 `ui` 不覆寫；
   上游測試 `SetAppUi_DoesNotOverwrite_ExistingUiKey` 覆蓋此規則。重複套用安全。

5. ~~顯示模式的敘述來自 apps.md 未經佐證~~ → **已查明並修正**（第二意見 P1-03）：
   原文說「在能力交換階段由 client 與 server 協商」**是錯的**。實際在 app view ↔ host 的
   `ui/initialize` 交換，view 可再送 `ui/request-display-mode`。章節已改寫並標明規格為 draft。

6. ~~`Visibility` 的執行語意未驗證~~ → **已驗證並修正**：server 不過濾，見上方實測記錄。
   章節現在明確說明 app-only 工具對任何 client 都可見、可呼叫，不是安全邊界。
   請覆核這段警告的語氣是否足夠——這個誤解的後果不小。

7. **`Domain` 欄位只有一句話**。`McpUiResourceMeta.Domain` 註記為「OAuth flows 與 CORS 的
   專屬 origin」，來自 apps.md 的條列；實際怎麼設、與第 18 章的 OAuth 如何搭配，本章沒教。
   已依 P2-03 標為 host-dependent，但深度是否足夠仍請覆核。

8. ~~附錄 A 未納入 Apps 的 TFM~~ → **不成立**（第二意見覆核並經第一方確認）：
   `appendix-a-nuget-packages.md:48` 與 `02-nuget-packages.md:117` 早已列出
   net10.0 / net9.0 / net8.0 / netstandard2.0。原記述為撰稿時的誤記。
   已在第 21 章延伸閱讀就地澄清 `WeatherAppServer` 的 net10.0 是該範例的選擇、非套件門檻。

> 原自評的第 9 項（與附錄 D 的相互連結）經第二意見判為「未成立——是流程問題不是內容缺陷」，
> 已移除。原編號缺 3，本次一併重排。

## 審查 checklist

### A. 結構宣告

- [ ] `WithMcpApps` 的 namespace 為 `ModelContextProtocol.Extensions.Apps`（非 `Microsoft.*`）
- [ ] `McpAppUiAttribute` 僅有 `ResourceUri`、`Visibility` 兩個屬性，且 `AttributeTargets.Method`
- [ ] `McpUiToolVisibility.Model` / `.App` 的常數值為 `"model"` / `"app"`
- [ ] `McpApps.HtmlMimeType` / `ExtensionId` 的字面值正確
- [ ] `McpUiResourceMeta` / `McpUiResourceCsp` / `McpUiResourcePermissions` 的成員與 JSON 屬性名一致
- [ ] `GetUiCapability` 回傳 `McpUiClientCapabilities?` 且該型別只有 `MimeTypes`
- [ ] 三個 experimental 診斷 ID 的對應（001 規格 feature／002 extensibility＋RunSessionHandler／003 Apps）

### B. 程式碼（**已經 `dotnet build` 通過，以下為覆核項**）

- [x] 三步驟範例的 **API 形狀**成立（`using` 齊全、`CallToolResult` 初始化語法正確）——但正文為節錄，**不可原樣獨立建置**（`UsCity`、`forecastData` 需自行定義）
- [x] `[McpServerResource]` 搭配 `MimeType = McpApps.HtmlMimeType` 的用法正確
- [x] `[McpMeta]` 的 raw string literal 與 JSON 內容合法
- [x] `Visibility = [McpUiToolVisibility.App]` 的 collection expression 對 `string[]?` 成立
- [x] `#pragma warning disable/restore MCPEXP003` 的擺放位置能實際消除診斷
- [x] `McpApps.SetAppUi` / `ApplyAppUiAttributes` 的簽名與呼叫方式一致
- [ ] `McpApps.SetResourceUi` **未在測試專案中呼叫過**——章節只在文字提及，請覆核簽名
- [ ] 測試專案為求最小化，`WeatherForecast` 的 HTTP 取值邏輯以假資料替代；章節保留的
      完整版（`client.GetAsync` → `JsonDocument` 解析）未經建置

### C. 敘述

- [ ] 風險點 5、6、7 的推論措辭是否需要弱化或直接標為「未驗證」
- [ ] 「預設 CSP 會擋掉外部 script 與 style 載入」是否過度肯定（來源為 apps.md 一句話）
- [ ] 優雅降級段落「這一步不是可選的」的語氣是否恰當
- [ ] experimental 的警告密度是否足夠——讀者會不會把這章當成穩定 API 來用

### D. 教學品質

- [ ] 作為第 21 章（原 20 章之後新增），與全書結構的銜接是否自然
- [ ] 「為什麼需要這個」的動機（純文字對話撐不住的互動場景）是否有說服力
- [ ] 與第 05 章 structured content、第 07 章 resource、第 17 章 Tasks extension 的回扣是否到位
- [ ] 八項常見錯誤是否都是真實會犯的錯，而非湊數
- [ ] 繁中語感與骨架完整性

### E. 本章特有

- [ ] **是否應該在通過建置實測前就發佈**——若認為不應該，請直接說明
- [ ] 風險點 8 的 TFM 問題是否需要在章節內明示，或補進附錄 A
