# 教學章節審查指南（第二意見用）

> 本目錄存放每一章教學文件的**審查說明與 checklist**，供第二意見（另一位 reviewer 或另一個 AI/工具）
> 在不了解本專案製作流程的前提下，獨立審查對應章節。
> 每章一份：`review-NN-<slug>.md`，對應 `../NN-<slug>.md`。**涵蓋全部 20 章。**
>
> 註：各章 review 保留最初製作時的 v1.4.0 實證，不回寫成未曾執行的新版測試。current guide
> 已於 2026-08-15 升級至 v2.2.0；本頁下方另記錄各輪 verified drift 處置。
>
> ch13–20 的 review 文件與章節同步產出（製作過程為當日記錄）；ch01–12 的 review 文件
> 為 2026-07-16 補建（各檔開頭有標註），其「製作過程摘要」為事後整理，並記錄了哪些宣稱
> 已被後續章節（ch13–20）的實測回頭印證。補建過程本身也抓到並修正了兩處問題：
> ch07 訂閱範例的訂閱表初始化 bug、ch10 `complex_prompt` 參數型別不符——詳見各該 review 文件。

---

## 專案背景（審查前必讀）

- 這是 **MCP C# SDK 的繁體中文教學**，current baseline 為 **ModelContextProtocol v2.2.0**，目標讀者是熟悉
  C#/.NET 與 ASP.NET Core、初次接觸 MCP 的開發者。執行環境 .NET 9.0+。
- 章節內容由 AI 依固定 pipeline 產生：wiki 知識庫（`../../mcp-csharp-sdk-kb/wiki/concepts/`）提供敘述基礎、
  **codebase-memory-mcp 圖譜逐一驗證 API 結構宣告**、上游原始碼（`../../csharp-sdk/`，current v2.2.0）
  提供程式碼基準、每章程式碼在移入前經 `dotnet build`（可執行者經 `dotnet test`）實測。
- 因此**結構性錯誤（API 不存在、簽名錯誤）的風險已被工具壓低**——第二意見的價值在於工具測不到的層面，
  見下方「審查重點」。

## 審查重點（按價值排序）

1. **敘述正確性**：文字對 API 行為的描述是否與程式碼範例、上游文件一致？有沒有過度推廣
   （例如把某版本的行為說成永久保證）或因果說反？
2. **教學品質**：概念鋪陳順序是否合理？「為什麼需要這個」是否有說服力？範例是否從簡到繁？
   一個初學 MCP 的 .NET 工程師照著做會不會卡住？
3. **章節連貫性**：與前後章的銜接（每章的「相關章節」段落）是否正確？術語是否与其他章一致
   （例如 transport／工具／資源的譯法）？
4. **繁中語感**：語句是否通順？是否遵守「API 名稱、型別、套件名保持英文原名；程式碼註解用繁中」的規約？
5. **完整性**：固定骨架（本章目標 → 為什麼需要 → 核心概念 → 上手範例 → 進階用法 → 常見錯誤 →
   相關章節 → 延伸閱讀）是否每段都有實質內容而非湊數？

## 每份 review 文件的結構

- **章節概要**：這一章教什麼、在整個教學中的位置
- **製作過程摘要**：哪些 API 經圖譜驗證、程式碼如何實測（含測試結果）、內容來源（wiki 條目／上游 sample／原始碼）
- **已知取捨與風險點**：製作時 AI 自己標記的「這裡值得人多看一眼」——通常是敘述性宣告、
  自撰（非上游 sample 原文）的程式碼、或版本相關的行為描述
- **審查 checklist**：可逐項打勾的具體檢查項，分「結構宣告」「程式碼」「敘述」「教學品質」四組

## 如何回報審查結果

在對應 review 文件的 checklist 打勾／標記 ❌ 並附註即可；發現問題請引用章節檔的行號或小節標題。
結構性問題（API 簽名、namespace）請同時註明查證方式（上游原始碼路徑或官方文件 URL），
以便與 codebase-memory-mcp 的驗證結果對質。

## 驗證環境參考

- macOS + .NET SDK 10（target `net9.0`）；各 review 內的舊 build 結果仍標示當時實際 NuGet 版本
- 上游 clone 位置：`../../csharp-sdk/`（v2.2.0，唯讀）
- 各章的可編譯專案留存於製作當時的 scratchpad，review 文件中附有專案結構與套件版本，可照著重建

## v2.1.0 outdated drift 處置（2026-08-10）

| Drift | 處置 | 正式教學範圍 |
|------|------|-------------|
| O-001 | `AuthorizationRedirectDelegate` 改為 issuer-aware `AuthorizationCallbackHandler`；補 PKCE S256 與無進展 scope step-up | ch18、附錄 B/C |
| O-002 | `AsSamplingChatClient` 降為 MCP9005 legacy compatibility，不再作新專案主線 | ch14、ch16、README、附錄 B/C |
| O-003 | `AsClientLoggerProvider` 降為 MCP9005 legacy compatibility；current path 改為明確 logging notification | ch09、README、附錄 B/C |
| O-004 | current baseline 與套件 pin 升至 v2.1.0；五個可發佈套件分工寫入 ch02／附錄 A | README、ch01–20、附錄 A/B/C |
| O-005 | current protocol baseline 改為 2026-07-28，保留 down-level compatibility 說明 | ch01、ch19、附錄 C |
| O-006 | 補 OAuth fail-closed 條件與 troubleshooting | ch18 |
| O-007 | 將 stateless 限制改為 unsolicited push 與 request-bound `subscriptions/listen` 的精確分界 | ch07、08、10、11、12、附錄 B/C |

結構性證據來自 v2.1.0 commit `3be47ee31ede99ef9025af02d9eb37da938d7f05` 的 codebase-memory 索引、verified facts 與對應 wiki concepts。發布前仍須依受影響範圍完成 build/test 與 Docker smoke；結果不得由舊 review 推定。

## v2.2.0 outdated drift 處置（2026-08-15）

| Drift | 處置 | 正式教學範圍 |
|------|------|-------------|
| O-008 | current baseline 與套件 pin 升至 v2.2.0；歷史版本表與舊 review 實證維持原版本語意 | README、ch01–20、附錄 A/B/C、本頁 |
| O-009 | session 設定主線改為三態 `HttpServerSessionMode`；補 `StatefulForInitializeClients` hybrid 決策、stateless half 限制與 `Stateless` compatibility proxy | ch07、08、12、14、17–19、附錄 A/B/C |

結構性證據來自 v2.2.0 commit `6fa3825973949a9c4f0cd8af344e15a8db09dc35` 的 codebase-memory 索引、verified facts、`HttpServerTransportOptions` 原始碼與 hybrid session tests。這一輪沒有 breaking，E-001～E-009 enhancement 未納入核准 scope。

發布驗證使用已發佈的 `ModelContextProtocol.AspNetCore` v2.2.0：`SessionMode` 最小 web 專案與 OAuth/server wiring 均以 `-warnaserror` 建置通過（0 warning、0 error）。Docker release smoke 完成 multi-stage build、`/health`、2026-07-28 `server/discover`、`tools/list` 與非 root `app` 使用者檢查；測試也確認 build context 必須以 `.dockerignore` 排除本機 `bin/`、`obj/`，修正已寫入 ch19。上游 v2.2.0 AOT compatibility test app 以 `osx-arm64` 完成 native publish 並執行輸出 `Success!`。
