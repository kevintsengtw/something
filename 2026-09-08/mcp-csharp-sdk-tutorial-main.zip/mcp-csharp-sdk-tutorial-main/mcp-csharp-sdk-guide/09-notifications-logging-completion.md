# 第 09 章：通知、進度、Logging 與 Completion

> 對應 wiki 概念：[notifications-progress](../mcp-csharp-sdk-kb/wiki/concepts/notifications-progress.md)、[logging-and-completion](../mcp-csharp-sdk-kb/wiki/concepts/logging-and-completion.md)
> 上游 API：`NotificationMethods` / `ProgressNotificationValue` / `LoggingCapability` / `CompletionsCapability`（`ModelContextProtocol.Protocol`，套件 `.Core`）、`WithSetLoggingLevelHandler` / `WithCompleteHandler`（`ModelContextProtocol`）
> 基準版本：v2.2.0

## 本章目標

前面的章節都圍繞「請求/回應」：client 問、server 答。本章補上另一半——**單向訊息與輔助機制**。讀完本章，你可以：

- 理解 MCP 通知（JSON-RPC notification）的全貌與 `NotificationMethods` 常數
- 在長時間工具中回報進度：server 端注入 `IProgress<ProgressNotificationValue>`，client 端用 `progress:` 參數接收
- 把 server 的 `ILogger` 日誌轉送給 client，並尊重 client 設定的最低等級
- 為 prompt / resource template 參數提供補全：自動（`AllowedValuesAttribute`）與手動（`WithCompleteHandler`）

## 為什麼需要這個

工具跑 30 秒，client 那端只看得到轉圈圈；server 內部出錯，log 卻只落在 server 自己的檔案裡；使用者填 prompt 參數只能盲打。這些體驗問題的解法分別是**進度通知**、**日誌轉送**、**參數補全**——它們都不是請求/回應，而是搭在既有連線上的輔助訊息流。

MCP 的通知是**無回應的單向訊息**，client 與 server 都能送。SDK 用同一個入口送出：`SendNotificationAsync`（定義在 `McpSession`，server 與 client 共用），方法名稱常數集中在 `NotificationMethods`。

## 核心概念

### 通知一覽（`NotificationMethods` 常數）

| 常數 | 協定方法 | 方向 | 用途 |
|------|---------|------|------|
| `ToolListChangedNotification` | `notifications/tools/list_changed` | S→C | 工具清單變更 |
| `PromptListChangedNotification` | `notifications/prompts/list_changed` | S→C | prompt 清單變更 |
| `ResourceListChangedNotification` | `notifications/resources/list_changed` | S→C | 資源清單變更 |
| `ResourceUpdatedNotification` | `notifications/resources/updated` | S→C | 訂閱的資源內容變更（第 07 章） |
| `LoggingMessageNotification` | `notifications/message` | S→C | 日誌訊息（本章） |
| `ProgressNotification` | `notifications/progress` | 雙向 | 進度回報（本章） |
| `CancelledNotification` | `notifications/cancelled` | 雙向 | 取消先前的請求 |
| `RootsListChangedNotification` | `notifications/roots/list_changed` | C→S | client 的 roots 變更 |
| `InitializedNotification` | `notifications/initialized` | C→S | 初始化完成 |
| `TaskStatusNotification` | `notifications/tasks/status` | S→C | task 狀態變更（第 17 章） |

> 前三個 list-changed 通知由 primitive collection 的 `Changed` 事件驅動；批次修改時可用 `DeferChangedEvents` 把多筆彙整成一筆（見本章「進階用法」）。

> 收到 `notifications/cancelled` 時，SDK 會取消對應請求——這正是你在工具方法注入的 `CancellationToken` 被觸發的來源之一。

### 進度回報的管線

進度通知靠 **progress token** 關聯：client 呼叫工具時帶上 token，server 回報進度時附上同一個 token，client 才知道這筆進度屬於哪個請求。SDK 把這條管線包到幾乎看不見：

- **Server 端**：工具方法直接注入 `IProgress<ProgressNotificationValue>`。SDK 的注入判定（`RequestServiceProvider`）在請求帶 token 時給你真的會送通知的實作（`TokenProgress`）；**沒帶 token 時給 no-op 實作**——`Report()` 靜默不送，方法不用判空。
- **Client 端**：`CallToolAsync(..., progress: ...)` 傳入 `Progress<ProgressNotificationValue>`，SDK 自動產生 token 並把通知路由回 callback。

> 通知在傳輸層怎麼送到對面？請求處理**期間**的進度/日誌通知會寫進該請求的 POST 回應串流（stateless 也通）；請求**之外**的主動通知（資源訂閱等）才需要 stateful 或 stdio（第 08 章）。

## 上手範例

### Server 端：注入 `IProgress` 回報進度

```csharp
using ModelContextProtocol;            // ProgressNotificationValue
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerTool, Description("處理大批資料，逐步回報進度")]
public static async Task<string> ProcessBatch(
    IProgress<ProgressNotificationValue> progress,   // 框架注入，不進工具參數
    CancellationToken ct)
{
    const int total = 5;
    for (int i = 1; i <= total; i++)
    {
        await Task.Delay(1000, ct);          // 實際工作
        progress.Report(new ProgressNotificationValue
        {
            Progress = i,                    // required float
            Total = total,                   // float?
            Message = $"step {i}/{total}",   // string?
        });
    }
    return "done";
}
```

`ProgressNotificationValue` 三個屬性：`Progress`（required，應單調遞增；可當百分比或已完成件數）、`Total`、`Message`。

### Server 端：手動送（要更多控制時）

```csharp
// 取自 docs/concepts/progress/samples/server/Tools/LongRunningTools.cs（節錄）
using ModelContextProtocol.Protocol;   // ProgressNotificationParams

var progressToken = context.Params.ProgressToken;   // RequestContext 注入取 token
if (progressToken is not null)
{
    await server.SendNotificationAsync("notifications/progress", new ProgressNotificationParams
    {
        ProgressToken = progressToken.Value,
        Progress = new ProgressNotificationValue { Progress = i, Total = steps },
    });
}
```

### Client 端：接收進度

```csharp
// 取自 docs/concepts/progress/samples/client/Program.cs
var progressHandler = new Progress<ProgressNotificationValue>(value =>
{
    Console.WriteLine($"Tool progress: {value.Progress} of {value.Total} - {value.Message}");
});

var result = await mcpClient.CallToolAsync(toolName: "longRunningTool", progress: progressHandler);
```

`McpClientTool` 也有 `WithProgress(...)`——把工具交給 LLM 用（第 16 章）時預先綁定進度接收器。

## 進階用法

### 批次變更 primitive：`DeferChangedEvents`

前三個 list-changed 通知（tools / prompts / resources）由 `McpServerPrimitiveCollection<T>` 的 `Changed` 事件驅動。這個 collection 每被改一次就觸發一次事件——一次加十個工具就是十次通知，client 會收到十筆 `notifications/tools/list_changed`。

v2.0.0 加了 `DeferChangedEvents` 解決這件事：

```csharp
public IDisposable DeferChangedEvents();
```

```csharp
// options.ToolCollection 是 McpServerPrimitiveCollection<McpServerTool>
using (options.ToolCollection.DeferChangedEvents())
{
    foreach (var tool in newTools)
    {
        options.ToolCollection.Add(tool);
    }
    options.ToolCollection.Remove(retiredTool);
}
// 離開 using 才觸發一次 Changed，client 只收到一筆 list_changed
```

行為（取自上游 `McpServerPrimitiveCollectionTests`）：

- **多次變更彙整成一次**。scope 內改幾次都一樣，dispose 時只觸發一次 `Changed`。
- **沒有變更就不觸發**。scope 內什麼都沒改，dispose 時不會送出空通知。
- **巢狀安全**。內外層都開 scope 時，要等最外層也 dispose 才觸發，且仍只有一次。

`ToolCollection` 與 `PromptCollection` 掛在 `McpServerOptions` 上，resource 則是 `McpServerResourceCollection`（`McpServerPrimitiveCollection<McpServerResource>` 的子類，改用 URI template 比較器）。三者都有 `DeferChangedEvents`。

> 這個方法只影響**通知的觸發時機**，不影響 collection 的內容——scope 內的修改立刻生效，只是先不吵 client。

### Logging：把 server 日誌轉送 client

三個環節，SDK 都有現成件：

1. **client 設定最低等級**：送 `logging/setLevel`（參數 `SetLevelRequestParams`）。SDK 收到後**自動更新** `McpServer.LoggingLevel`；要在等級變更時做額外處理，才需要 `WithSetLoggingLevelHandler`：

```csharp
// 依 samples/EverythingServer/Program.cs 簡化
using ModelContextProtocol.Protocol;   // EmptyResult / LoggingMessageNotificationParams

builder.Services.AddMcpServer()
    .WithSetLoggingLevelHandler(async (ctx, ct) =>
    {
        // SDK 已更新 ctx.Server.LoggingLevel；這裡可掛自訂邏輯
        return new EmptyResult();
    });
```

2. **server 送日誌**：current path 是手動送 `NotificationMethods.LoggingMessageNotification`（參數 `LoggingMessageNotificationParams`，含 `Level` / `Logger` / `Data`），並依 `McpServer.LoggingLevel` 過濾。v2 仍保留下列 `ILoggerProvider` adapter 供 down-level compatibility，但已標記 MCP9005 obsolete：

```csharp
// server 為 McpServer；回傳標準 ILoggerProvider
#pragma warning disable MCP9005 // legacy compatibility only
ILoggerProvider provider = server.AsClientLoggerProvider();
#pragma warning restore MCP9005
// 掛進 LoggerFactory 後，該 factory 產生的 ILogger 寫的 log 都會轉成
// notifications/message 送給 client，並自動依 client 設定的 LoggingLevel 過濾
```

3. **等級型別**：協定的 `LoggingLevel` enum（`ModelContextProtocol.Protocol`）與 `Microsoft.Extensions.Logging.LogLevel` 是不同型別。legacy `AsClientLoggerProvider` 會代為映射；current 手動通知路徑需由應用程式明確轉換並套用最低等級。

### Completion：參數補全

**自動**（v1.1.0 起，第 06 章已見過）：prompt / resource template 的字串參數標 `AllowedValuesAttribute`（.NET BCL），SDK 自動產生補全，無需 handler。

**手動**（候選值需動態計算時）：`WithCompleteHandler` 接管 `completion/complete` 請求。請求的 `Ref` 分兩種——`ResourceTemplateReference`（補資源 URI 範本參數）與 `PromptReference`（補 prompt 參數）：

```csharp
// 依 samples/EverythingServer/Program.cs 簡化
using ModelContextProtocol.Protocol;   // CompleteResult / Completion / *Reference

builder.Services.AddMcpServer()
    .WithCompleteHandler(async (ctx, ct) =>
    {
        var @ref = ctx.Params!.Ref;
        var argument = ctx.Params.Argument;

        if (@ref is ResourceTemplateReference rtr)
        {
            // 依 rtr.Uri 與 argument.Name / argument.Value 算候選
            string[] values = ["1", "2", "3"];
            var matches = values.Where(v => v.StartsWith(argument.Value)).ToArray();
            return new CompleteResult
            {
                Completion = new Completion { Values = matches, HasMore = false, Total = matches.Length },
            };
        }

        if (@ref is PromptReference pr)
        {
            // 依 pr.Name 與 argument 算候選……
        }

        return new CompleteResult();   // 無候選
    });
```

`Completion` 三欄位：`Values`（候選清單）、`HasMore`、`Total`。

## 常見錯誤

- **client 沒帶 progress token，以為 server 進度壞了**：token 缺席時注入的 `IProgress` 是 no-op——這是設計（省掉判空），不是 bug。client 端要用 `CallToolAsync(progress: ...)` 才會產生 token。
- **`Progress` 值倒退**：協定期望單調遞增；亂跳會讓 client 端進度條行為不可預期。
- **在 stateless 下以為所有通知都不能用**：請求處理期間的進度/日誌通知走 POST 回應串流，stateless 也通；只有請求之外的主動通知需要 stateful（第 08 章的表）。
- **手寫 completion handler 只處理一種 `Ref`**：`ResourceTemplateReference` 與 `PromptReference` 都可能來，漏掉的那種會拿不到補全（或吃到你丟的例外）。
- **日誌等級全送**：手動送 `notifications/message` 時記得自己比對 `McpServer.LoggingLevel`。
- **把 `AsClientLoggerProvider()` 當作 v2 新專案入口**：它已標記 MCP9005 obsolete，只保留作 down-level compatibility；新程式使用明確的 logging notification 路徑。
- **把 `LoggingLevel`（協定 enum）與 `LogLevel`（Microsoft.Extensions.Logging）混用**：兩者名稱相近但屬不同體系，橋接由 SDK 處理，自己手動轉換時注意方向。

## 相關章節

- 第 05 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) — 參數注入判定（`IProgress` 是注入清單的一員）
- 第 06 章：[mcp-server-prompts](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-prompts.md) — `AllowedValuesAttribute` 自動補全的第一次出場
- 第 07 章：[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md) — 資源訂閱與 `ResourceUpdatedNotification`
- 第 08 章：[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md) — 哪些通知需要 stateful、訊息在傳輸層怎麼流
- 第 17 章：[tasks](../mcp-csharp-sdk-kb/wiki/concepts/tasks.md) — `TaskStatusNotification` 與長任務的另一種解法

## 延伸閱讀

- 官方概念文件：Progress（`raw/docs-conceptual/progress.md`）、Logging（`raw/docs-conceptual/logging.md`）、Completions（`raw/docs-conceptual/completions.md`）
- 上游 sample：`docs/concepts/progress/samples/`（server + client 成對範例）、`samples/EverythingServer/`（`LongRunningTool`、`WithSetLoggingLevelHandler`、`WithCompleteHandler`）
