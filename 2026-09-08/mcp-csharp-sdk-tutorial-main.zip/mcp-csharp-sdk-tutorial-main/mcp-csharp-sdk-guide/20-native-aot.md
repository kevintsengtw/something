# 第 20 章：Native AOT 相容

> 對應 wiki 概念：[aot-compatibility](../mcp-csharp-sdk-kb/wiki/concepts/aot-compatibility.md)
> 上游 API：泛型 `WithTools<T>`（AOT 友善路徑）、`McpServerToolCreateOptions.SerializerOptions`
> 引入版本：v1.0.0（SDK 以 AOT 相容為設計目標）
> 教學基準：v2.2.0

## 本章目標

- 把 MCP server 發佈成 Native AOT 單一執行檔（本章成品：10MB、免 runtime、瞬間啟動）
- 分清 SDK 的 AOT 安全區與危險區：泛型 `WithTools<T>` vs 反射掃描的 `WithToolsFromAssembly`
- 為自訂參數型別提供 source-generated `JsonSerializerContext`——以及那個命名策略陷阱
- 知道上游怎麼守住 AOT 相容性（`AotCompatibility.TestApp`），你的專案可以照抄這招

## 為什麼需要這個

Native AOT 把 .NET 程式編譯成原生機器碼：不帶 JIT、不需要安裝 runtime、啟動以毫秒計、記憶體佔用大減。對 MCP server 有兩個特別誘人的場景：

1. **stdio server 的發佈**：stdio server 由 client 當子行程啟動（第 4 章），使用者拿到的是「一個執行檔」。AOT 讓這個執行檔免安裝 .NET、免等 JIT 暖機——對「裝給非 .NET 開發者用的工具」是質變。
2. **容器映像瘦身**：第 19 章的映像還背著整個 ASP.NET Core runtime;AOT + `runtime-deps` 基底能把映像再砍一大截。

代價是限制：**沒有執行期程式碼生成，反射大受限**。凡是「執行期才決定型別」的操作——反射掃描、反射式 JSON 序列化——都可能被 trimming 剪掉或直接不支援。MCP C# SDK 從一開始就為此設計（協定層 JSON 全部走 source generation,套件自帶 analyzers），但**你的程式碼**也要遵守同一套紀律，本章就是這套紀律。

## 核心概念

### SDK 的 AOT 安全區與危險區

SDK 用 `[RequiresUnreferencedCode]` 標記了所有 AOT 危險 API,訊息說得很直白（原始碼原文）：

> The non-generic `WithTools` and `WithToolsFromAssembly` methods require dynamic lookup of method metadata and might not work in Native AOT. **Use the generic `WithTools` method instead.**

| | AOT 安全 | AOT 危險（`RequiresUnreferencedCode`） |
|--|---------|--------------------------------------|
| 工具註冊 | `WithTools<T>()`（泛型）、`McpServerTool.Create(delegate)` | `WithTools(IEnumerable<Type>)`、`WithToolsFromAssembly()` |
| Prompts／Resources | 泛型 `WithPrompts<T>`／`WithResources<T>` | 非泛型與 FromAssembly 版本 |

原因：泛型版本讓 trimmer 在編譯期就看見 `T`，方法 metadata 得以保留；assembly 掃描則要在執行期枚舉型別——trimming 後可能什麼都掃不到。第 4 章圖方便用的 `WithToolsFromAssembly`，在 AOT 世界要換成逐一列舉的 `WithTools<T>`。

### JSON：協定層已解決，你的型別自己帶

SDK 內部所有協定訊息的序列化走 source-generated context（`McpJsonUtilities.JsonContext`），AOT 下零反射。但**你的**自訂參數／回傳型別 SDK 不可能預知——要自己提供 `JsonSerializerContext`，在建立工具時透過 `SerializerOptions` 傳入（見上手範例）。只用 `string`／`int`／`bool` 等基本型別的工具則什麼都不用做。

## 上手範例

以下是本章的完整驗證程式——一個 in-memory 自測（第 13 章的模式），兩個工具分別代表「基本型別」與「自訂型別」兩種情況。實測：AOT 發佈成功、**10MB 單一原生執行檔**（osx-arm64 實測值，其他 RID 大小會不同，屬正常）、自測全過。

### csproj

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net9.0</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <PublishAot>true</PublishAot>
    <InvariantGlobalization>true</InvariantGlobalization>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="ModelContextProtocol" Version="2.1.0" />
  </ItemGroup>

</Project>
```

### 程式

```csharp
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;
using System.IO.Pipelines;
using System.Text.Json.Serialization;

Pipe clientToServerPipe = new(), serverToClientPipe = new();

await using McpServer server = McpServer.Create(
    new StreamServerTransport(clientToServerPipe.Reader.AsStream(), serverToClientPipe.Writer.AsStream()),
    new McpServerOptions
    {
        ToolCollection =
        [
            // 基本型別參數：不需要額外 JSON 設定
            McpServerTool.Create((string arg) => $"Echo: {arg}", new() { Name = "echo" }),

            // 自訂型別參數：AOT 下必須提供 source-generated JSON context
            McpServerTool.Create((OrderRequest order) => $"訂單：{order.Item} x{order.Count}",
                new McpServerToolCreateOptions
                {
                    Name = "order",
                    SerializerOptions = AppJsonContext.Default.Options,
                }),
        ],
    });
_ = server.RunAsync();

await using McpClient client = await McpClient.CreateAsync(
    new StreamClientTransport(clientToServerPipe.Writer.AsStream(), serverToClientPipe.Reader.AsStream()));

var tools = await client.ListToolsAsync();
Console.WriteLine($"tools: {string.Join(", ", tools.Select(t => t.Name))}");

var orderResult = await client.CallToolAsync("order",
    new Dictionary<string, object?>
    {
        ["order"] = new Dictionary<string, object?> { ["item"] = "咖啡", ["count"] = 2 },
    });
Console.WriteLine(((TextContentBlock)orderResult.Content[0]).Text);   // 訂單：咖啡 x2

public sealed record OrderRequest(string Item, int Count);

[JsonSourceGenerationOptions(PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase)]
[JsonSerializable(typeof(OrderRequest))]
[JsonSerializable(typeof(Dictionary<string, object?>))]
internal sealed partial class AppJsonContext : JsonSerializerContext;
```

### 發佈與執行

```bash
dotnet publish -c Release -r osx-arm64      # 或 linux-x64 / win-x64
./bin/Release/net9.0/osx-arm64/publish/AotEchoServer
```

實測輸出：

```text
tools: echo, order
Echo: Hello AOT
訂單：咖啡 x2
Success!
```

`ls -lh` 看到的是 10MB 的 Mach-O arm64 執行檔——不需要任何 .NET runtime,拷到另一台同架構的機器直接跑。

## 進階用法

### 命名策略陷阱（實測抓到的）

上面 context 上的 `[JsonSourceGenerationOptions(PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase)]` **不是裝飾**。本章第一次實測就漏了它：MCP 世界的引數是 camelCase（`item`／`count`），而沒設命名策略的 source-gen context 只認 PascalCase（`Item`／`Count`）——結果不是報錯，是**靜默拿到 default 值**（輸出變成 `訂單： x0`）。反射式序列化常見的大小寫寬容，在 source-gen 嚴格模式下不存在。寫測試盯住實際值，別只驗「有回應」。

### 上游怎麼守住 AOT：照抄這招

SDK 的 CI 有一個專門的驗證程式 `tests/ModelContextProtocol.AotCompatibility.TestApp`：把三個套件全部設為 `TrimmerRootAssembly`（強制 trimmer 分析整個套件），AOT 發佈後跑一個 in-memory 協定自測。你的 server 專案可以抄這個模式——CI 里加一步 `dotnet publish` + 跑自測執行檔，AOT 回歸一出現就會被抓到。

（`TrimmerRootAssembly` 是套件作者驗證全 API 面的手段；一般應用**不需要**設它，讓 trimmer 只保留你用到的部分，執行檔更小。）

### 依賴鏈決定成敗

你的程式 AOT 乾淨還不夠——**每個依賴**都得乾淨。上游 `ChatWithTools` sample 的 csproj 裡有一行註解值得引以為戒：`Anthropic SDK isn't AOT compatible yet`，所以那個 sample 的 `PublishAot` 被註解掉了。引入第三方套件前，先確認它的 AOT 支援聲明；trim 警告（IL2xxx／IL3xxx）是最早的警報。

### 容器 + AOT

接第 19 章：AOT 執行檔的容器基底可以降到 `mcr.microsoft.com/dotnet/runtime-deps`（只有原生依賴，沒有 .NET runtime），映像從百餘 MB 級掉到數十 MB 級。build 階段照舊用 `sdk` 映像（AOT 編譯需要完整工具鏈與 clang）。

## 常見錯誤

**1. AOT 下用 `WithToolsFromAssembly`**

編譯期就會收到 IL2026 trim 警告；真發佈後輕則工具清單缺漏，重則初始化失敗。換泛型 `WithTools<T>` 逐一註冊——這也是為什麼本教學從第 5 章起就偏好泛型寫法。

**2. 自訂型別沒提供 source-gen context**

AOT 下反射式 `JsonSerializer` 不可用，執行期丟 `NotSupportedException`（或被 trimmer 剪到序列化不完整）。凡是工具參數／回傳值用到自訂型別，就要有對應的 `[JsonSerializable]` 宣告並傳入 `SerializerOptions`。

**3. source-gen context 忘了 camelCase 命名策略**

症狀最陰險：不報錯，值全是 default（見進階用法的實測記錄）。

**4. 只在 Release AOT 才測**

`dotnet run` 是 JIT 模式，反射照常運作——很多 AOT 問題**只在發佈後**出現。把 AOT 發佈 + 自測放進 CI（照抄上游 TestApp 模式），別等上線才發現。

**5. 忽視第三方依賴的 AOT 相容性**

自己的程式碼再乾淨，一個不相容的依賴就全盤皆輸。留意 restore／build 時的 trim 警告來源。

## 相關章節

- [第 4 章：第一個工具，用 stdio 跑起來](./04-mcp-server-tools.md)——`WithToolsFromAssembly` 的便利在 AOT 下的對價
- [第 13 章：測試策略](./13-testing-strategy.md)——本章自測程式的模式出處
- [第 19 章：Docker 部署](./19-docker-deployment.md)——AOT 是映像瘦身的下一步

## 延伸閱讀

- 上游 `tests/ModelContextProtocol.AotCompatibility.TestApp`——官方 AOT 驗證程式
- [.NET Native AOT 部署官方文件](https://learn.microsoft.com/dotnet/core/deploying/native-aot/)
- [System.Text.Json source generation](https://learn.microsoft.com/dotnet/standard/serialization/system-text-json/source-generation)
- wiki 條目：[aot-compatibility](../mcp-csharp-sdk-kb/wiki/concepts/aot-compatibility.md)、[nuget-packages](../mcp-csharp-sdk-kb/wiki/concepts/nuget-packages.md)
