# 第 06 章：Prompts（可重用提示範本）

> 對應 wiki 概念：[mcp-server-prompts](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-prompts.md)
> 上游 API：`McpServerPrompt` / `[McpServerPrompt]` / `[McpServerPromptType]`（`ModelContextProtocol.Core`）、`WithPromptsFromAssembly` / `WithPrompts`（`ModelContextProtocol`）、`GetPromptResult` / `PromptMessage`（`ModelContextProtocol.Protocol`）
> 基準版本：v2.2.0

## 本章目標

Tools 是「模型自己決定要不要呼叫」的動作；Prompts 則相反——它是**使用者主動挑選**的可重用範本（想像成 slash command 或範本選單）。伺服器把常用的提示包成帶參數的範本，client 端使用者選一個、填參數，就能得到一組結構化訊息。讀完本章，你可以：

- 用 `[McpServerPromptType]` / `[McpServerPrompt]` 定義無參數與帶參數的 prompt
- 用 `[Description]` 描述 prompt 與參數，並用 `AllowedValuesAttribute` 提供參數補全
- 選對回傳型別（`string`、`ChatMessage`、`IEnumerable<ChatMessage>`、`GetPromptResult`）
- 用 `WithPromptsFromAssembly()` / `WithPrompts<T>()` 註冊
- 理解 prompt 與 tool 對稱的參數注入模型

## 為什麼需要這個

同樣是「伺服器提供給模型用的東西」，MCP 的三個 primitive 控制權不同：

| Primitive | 誰決定使用 | 典型場景 |
|-----------|-----------|---------|
| Tools（第 04–05 章） | **模型** 自主呼叫（model-controlled） | 查天氣、算數、存取系統 |
| **Prompts（本章）** | **使用者** 主動挑選（user-controlled） | 「幫我 code review」「產生 commit message」等範本 |
| Resources（第 07 章） | **應用程式** 決定提供（application-controlled） | 檔案、資料庫內容 |

把常用提示做成 prompt，好處是：範本集中維護、可帶參數、可被任何 MCP client 以一致方式列出與套用——使用者不必每次重打一長串指令。

## 核心概念

Prompts 的定義方式與 tools **完全對稱**：

- 類別標 `[McpServerPromptType]`
- 方法標 `[McpServerPrompt]`
- 以 `WithPromptsFromAssembly()`（掃描組件）或 `WithPrompts<T>()`（指定類別）註冊

差別在**回傳的是「訊息範本」而非「執行結果」**：一個 prompt 方法回傳一段或多段訊息（`string` / `ChatMessage` / `IEnumerable<ChatMessage>`），供 client 端組成對話送給模型。

> `McpServerPrompt`（`abstract class : IMcpServerPrimitive`）、`McpServerPromptAttribute`、`McpServerPromptTypeAttribute` 皆 namespace `ModelContextProtocol.Server`、套件 `.Core`。

## 上手範例

### 最小 prompt：無參數

回傳一段字串，SDK 會包成一則 user 訊息：

```csharp
// 取自 samples/EverythingServer/Prompts/SimplePromptType.cs
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerPromptType]
public class SimplePromptType
{
    [McpServerPrompt(Name = "simple_prompt"), Description("A prompt without arguments")]
    public static string SimplePrompt() => "This is a simple prompt without arguments";
}
```

### 帶參數 prompt：`[Description]` + 多則訊息

參數加 `[Description]`（`System.ComponentModel`）幫助使用者理解；回傳 `IEnumerable<ChatMessage>` 可組多則訊息（user/assistant 交錯，甚至含圖片）：

```csharp
// 取自 samples/EverythingServer/Prompts/ComplexPromptType.cs
using Microsoft.Extensions.AI;              // ChatMessage / ChatRole / DataContent
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerPromptType]
public class ComplexPromptType
{
    [McpServerPrompt(Name = "complex_prompt"), Description("A prompt with arguments")]
    public static IEnumerable<ChatMessage> ComplexPrompt(
        [Description("Temperature setting")] int temperature,
        [Description("Output style")] string? style = null)
    {
        return
        [
            new ChatMessage(ChatRole.User, $"This is a complex prompt with arguments: temperature={temperature}, style={style}"),
            new ChatMessage(ChatRole.Assistant, "I understand. You've provided a complex prompt with temperature and style arguments. How would you like me to proceed?"),
            new ChatMessage(ChatRole.User, [new DataContent(TinyImageTool.MCP_TINY_IMAGE)]),
        ];
    }
}
```

> 有預設值的參數（如 `style = null`）為選填。`ChatMessage` / `ChatRole` / `DataContent` 來自外部 NuGet `Microsoft.Extensions.AI`。

### 註冊

```csharp
builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithPromptsFromAssembly();   // 掃描組件中所有 [McpServerPromptType]
```

## 進階用法

### 回傳型別

| 回傳 | 結果 |
|------|------|
| `string` | 單則 user 訊息 |
| `ChatMessage`（Microsoft.Extensions.AI） | 單則訊息，指定 `ChatRole` |
| `IEnumerable<ChatMessage>` | 多則訊息 |
| `GetPromptResult` | 完全掌控結果（`Description` + `IList<PromptMessage> Messages`）|

回傳 `ChatMessage` 時 SDK 會自動轉成協定的 `PromptMessage`。要精準控制協定輸出（例如自訂整體 `Description`、直接組 `PromptMessage`）時，回傳 `GetPromptResult`：

```csharp
using ModelContextProtocol.Protocol;   // GetPromptResult / PromptMessage / Role

[McpServerPrompt(Name = "review"), Description("Code review prompt")]
public static GetPromptResult Review([Description("The code to review")] string code)
    => new()
    {
        Description = "Code review request",
        Messages =
        [
            new PromptMessage
            {
                Role = Role.User,
                Content = new TextContentBlock { Text = $"請 review 以下程式碼：\n{code}" },
            },
        ],
    };
```

> `GetPromptResult`(`sealed class : Result`) 與 `PromptMessage`（`required ContentBlock Content` + `required Role Role`）皆 ns `ModelContextProtocol.Protocol`、套件 `.Core`。

### 參數補全（Completion）

在參數上加 `AllowedValuesAttribute`（`System.ComponentModel.DataAnnotations`，.NET BCL），SDK 會為該參數自動提供 completion——使用者填參數時可得候選清單（自 1.1.0，#1380）：

```csharp
using System.ComponentModel.DataAnnotations;

[McpServerPrompt, Description("Summarize in a given tone")]
public static string Summarize(
    [Description("The content")] string content,
    [AllowedValues("formal", "casual", "technical")] string tone = "formal")
    => $"請以 {tone} 語氣摘要：\n{content}";
```

> 補全的完整機制（completion capability）見第 09 章（[logging-and-completion](../mcp-csharp-sdk-kb/wiki/concepts/logging-and-completion.md)）。

### 註冊的其他方式

| 擴充方法 | 用途 |
|---------|------|
| `WithPromptsFromAssembly()` | 掃描組件註冊所有 `[McpServerPromptType]` |
| `WithPrompts<T>()` | 指定單一類別 |
| `WithPrompts(IEnumerable<Type>)` / `WithPrompts(IEnumerable<McpServerPrompt>)` | 指定型別集合 / 實例集合 |

> 批次調整 prompt 清單時，`McpServerOptions.PromptCollection` 的 `DeferChangedEvents()` 可把多筆修改彙整成一次 `prompts/list_changed` 通知（第 09 章）。

### 參數注入（與 tools 對稱）

prompt 方法同樣能注入框架相依，這些不會出現在 prompt 的參數清單裡：

- `McpServer` — 當前連線的 server
- `RequestContext<GetPromptRequestParams>` — 本次 get-prompt 請求的 context
- `CancellationToken`
- DI 註冊的服務

判定機制與工具一致（見 [mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) 的「注入判定」）。

> 註：官方 samples 的 prompt 多為 static、無注入示範；上述型別與機制已由 SDK 原始碼驗證（`McpServerPrompt` / `AIFunctionMcpServerPrompt` 內部即以 `RequestContext<GetPromptRequestParams>` 驅動）。

### client 端如何取用

client 會先「列出」可用的 prompt（每個對應一個 protocol 層的 `Prompt` 描述子，含 `Title`、`Description`、`Arguments`），再依名稱與參數「取用」得到訊息。client 端 API（列出/取用 prompt）在第 10 章（[mcp-client](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client.md)）詳述，本章聚焦 server 端定義。

## 常見錯誤

- **把該做成 tool 的東西做成 prompt**：prompt 是「使用者挑選的範本」、不執行副作用；要模型自主呼叫且有副作用的用 tool。
- **忘了註冊 `WithPromptsFromAssembly()`**：只標 attribute 不註冊，client 會列不到任何 prompt。
- **以為注入的服務會變成 prompt 參數**：`McpServer` / DI 服務是框架注入，不會出現在使用者要填的參數清單。
- **手組 `GetPromptResult` 卻用錯 `Role`**：`PromptMessage.Role` 是 `ModelContextProtocol.Protocol` 的 `Role` enum（非 `Microsoft.Extensions.AI` 的 `ChatRole`）；回傳 `ChatMessage` 時才用 `ChatRole`。

## 相關章節

- 第 04–05 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) — 另一個 primitive，定義方式對稱、注入機制一致
- 第 07 章：[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md) — 第三個 server primitive
- 第 09 章：[logging-and-completion](../mcp-csharp-sdk-kb/wiki/concepts/logging-and-completion.md) — 參數補全 completion 的完整機制
- 第 10 章：[mcp-client](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client.md) — client 端列出與取用 prompt

## 延伸閱讀

- 上游 sample：`samples/EverythingServer/Prompts/`（`SimplePromptType`、`ComplexPromptType`）
- 官方概念文件：Prompts（`raw/docs-conceptual/prompts.md`）
