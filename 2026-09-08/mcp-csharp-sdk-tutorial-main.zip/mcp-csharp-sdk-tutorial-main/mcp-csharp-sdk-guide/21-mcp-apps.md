# 第 21 章：MCP Apps——讓工具帶著互動式 UI

> 上游 API：`WithMcpApps` / `McpAppUiAttribute` / `McpApps` / `McpUiToolVisibility` / `McpUiResourceMeta`（namespace `ModelContextProtocol.Extensions.Apps`、套件 **ModelContextProtocol.Extensions.Apps**）
> 教學基準：v2.2.0（MCP 2026-07-28）
> ⚠️ 本章介紹的 API 全部標記為 **Experimental**，診斷 ID `MCPEXP003`

---

## 本章目標

讀完這章，你會知道：

- MCP Apps 讓 server 端的工具關聯一個**互動式 HTML UI**，由 client 顯示在對話旁邊
- 怎麼用 `[McpAppUi]` + `WithMcpApps()` 把工具和 UI resource 綁起來
- `Visibility` 怎麼標示工具的**預期受眾**（以及為什麼它不是存取控制）
- UI resource 怎麼註冊，以及 CSP、iframe `allow` 權限這些設定放哪裡
- client 不支援時怎麼優雅降級
- 為什麼這整套目前還是 experimental，以及該怎麼防守

## 為什麼需要這個

到第 20 章為止，工具的產出都是**非互動式內容**——文字、結構化資料，或圖片／音訊／內嵌資源這類 content block（第 05 章）。LLM 讀了以後轉述給使用者。這對「查一筆資料」很夠用，但有些任務天生需要介面：挑日期、拖曳排序、看圖表、在地圖上點一個位置。把這些擠進純文字對話，體驗會很糟。

MCP Apps 的做法是：**server 提供一份 HTML，client 把它顯示在對話旁邊**。工具被呼叫時，client 知道要開哪一份 UI；UI 裡的按鈕又可以回頭呼叫 server 的工具。整條迴路都在 MCP 協定內，不需要另外架一個 web app。

典型場景：天氣預報的城市選擇器、報表的互動式圖表、需要視覺確認的核准流程。

## 核心概念

### 三個構件

| 構件 | 是什麼 | 協定上長什麼樣 |
|------|--------|--------------|
| **UI capability 協商** | client 與 server 互相宣告支不支援 | `extensions["io.modelcontextprotocol/ui"]` |
| **UI resource** | server 提供的 HTML 頁面 | MIME type `text/html;profile=mcp-app` |
| **Tool UI metadata** | 工具宣告它關聯哪一份 UI | 工具的 `_meta.ui` 欄位 |

兩個常數值得記住（都在 `McpApps` 上）：

```csharp
public static class McpApps
{
    public const string HtmlMimeType = "text/html;profile=mcp-app";
    public const string ExtensionId  = "io.modelcontextprotocol/ui";
}
```

### 獨立套件，且是 experimental

MCP Apps 住在自己的套件裡，疊在核心 SDK 之上：

```bash
dotnet add package ModelContextProtocol.Extensions.Apps --version 2.2.0
```

**這套 API 標了 `[Experimental("MCPEXP003")]`，而且是 error 等級不是 warning**——不抑制就編不過。實測（.NET 9、SDK 2.2.0）會觸發診斷的是這四個符號：

| 符號 | 典型出現位置 |
|------|------------|
| `McpAppUiAttribute` | 工具方法上的 `[McpAppUi]` |
| `McpApps` | `McpApps.HtmlMimeType`、`GetUiCapability`、`SetAppUi`… |
| `McpUiToolVisibility` | `Visibility = [...]` |
| `McpUiToolMeta` | 程式化設定 UI metadata |

**`WithMcpApps()` 本身不觸發**——實測拿掉所有 pragma 後，只有上面四個符號報 `MCPEXP003`，`Program.cs` 那段 builder 鏈完全乾淨。所以 pragma 通常包在**工具類別與資源類別**上，而不是 `Program.cs`。

抑制方式：

```csharp
#pragma warning disable MCPEXP003   // MCP Apps extension 仍隨規格演進
// ... 使用 MCP Apps 的程式碼
#pragma warning restore MCPEXP003
```

抑制範圍**壓到最小**，別整個專案關掉——這樣升級 SDK 時才看得出哪些地方會被規格變動掃到。

> ⚠️ **抑制診斷只代表你接受編譯風險，不會讓 API 或 wire contract 變穩定。** MCP Apps 規格本身還是 draft，`_meta` 形狀與 `ui/*` 方法都可能變。要放進正式環境前至少做到：
>
> - **釘死 SDK 版本**（`--version 2.2.0`），別讓 `dotnet restore` 自動跳版
> - **把 Apps 相關程式碼隔離**成一層 adapter 或包在 feature flag 後面，規格變動時改一個地方
> - **針對你實際要支援的 host 做相容性測試**——本章的實測只涵蓋 SDK 送出的 JSON 形狀，沒有涵蓋任何 host 的呈現行為
> - **升級 SDK 後重驗** metadata 與 wire shape，不要假設沒有 breaking change

> 第 17 章的 `MCPEXP002`（extensibility）、這裡的 `MCPEXP003`（Apps）、還有 `MCPEXP001`（規格層 feature）是 SDK 目前的三個 experimental 診斷 ID。

## 上手範例

> 📌 **以下三步驟為節錄，不是可獨立複製建置的完整專案。** 為聚焦 Apps 的 API，工具程式碼省略了資料取得的實作（`UsCity`、`forecastData` 等需自行定義）。完整可跑版本見上游 `samples/WeatherAppServer`（附錄 D 有導覽）。

### 步驟 1：把工具關聯到 UI resource

在工具方法上加 `[McpAppUi]`，指定要開哪一份 UI：

```csharp
using ModelContextProtocol.Extensions.Apps;
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerToolType]
public sealed class WeatherTools
{
    [McpServerTool(Name = "weather_ui")]
    [McpAppUi(ResourceUri = "ui://weather-app/forecast")]
    [Description("Display an interactive weather forecast UI with city picker.")]
    public static string WeatherUi() => "Showing weather forecast UI.";

    [McpServerTool(Name = "weather_forecast")]
    [McpAppUi(ResourceUri = "ui://weather-app/forecast")]
    [Description("Get weather forecast for a US city.")]
    public static async Task<CallToolResult> WeatherForecast(
        HttpClient client,
        [Description("US city to get the forecast for")] UsCity cityState)
    {
        // ... 取得預報資料
        return new CallToolResult
        {
            Content = [new TextContentBlock { Text = $"Weather forecast for {cityState}." }],
            StructuredContent = JsonSerializer.SerializeToElement(forecastData),
        };
    }
}
```

注意 `WeatherForecast` 同時回傳**文字內容**與 **structured content**——UI 讀 structured content 畫圖表，不支援 UI 的 client 讀文字。這個雙軌設計是 MCP Apps 的標準寫法（第 05 章的結構化輸出在這裡派上用場）。

`McpAppUiAttribute` 的形狀很小：

```csharp
[AttributeUsage(AttributeTargets.Method)]
[Experimental("MCPEXP003")]
public sealed class McpAppUiAttribute : Attribute
{
    public string? ResourceUri { get; set; }
    public string[]? Visibility { get; set; }
}
```

### 步驟 2：註冊 UI resource

UI 本身就是一份**資源**（第 07 章的 resource），只是 MIME type 特殊、URI 用 `ui://` scheme：

```csharp
using ModelContextProtocol.Extensions.Apps;
using ModelContextProtocol.Server;

[McpServerResourceType]
public sealed class WeatherResources
{
    private static readonly string UiDir = Path.Combine(AppContext.BaseDirectory, "ui");

    [McpServerResource(
        UriTemplate = "ui://weather-app/forecast",
        Name = "weather-forecast-ui",
        MimeType = McpApps.HtmlMimeType)]           // text/html;profile=mcp-app
    [McpMeta("ui", JsonValue = """{"csp":{"connectDomains":["https://api.weather.gov"]},"prefersBorder":true}""")]
    [Description("Interactive weather forecast UI with city picker")]
    public static string GetWeatherForecastUi() =>
        File.ReadAllText(Path.Combine(UiDir, "weather-forecast.html"));
}
```

這份 resource 從 `AppContext.BaseDirectory/ui/weather-forecast.html` 讀檔，所以**專案要有那個檔、而且要複製到輸出目錄**，否則 `resources/read` 會丟 `FileNotFoundException`。`.csproj` 補一行（上游 `WeatherAppServer` 也是這樣做的）：

```xml
<ItemGroup>
  <Content Include="ui\*.html" CopyToOutputDirectory="PreserveNewest" />
</ItemGroup>
```

最小的 `ui/weather-forecast.html` 可以先這樣。**這只是「asset 存在且能載入」的示意，不是一個可操作的 MCP App**——它沒有接收 structured content、也沒有回呼工具；重點在於示範 CSS 變數必須給 fallback：

```html
<!doctype html>
<html lang="zh-Hant">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Weather Forecast</title>
    <style>
      body {
        font-family: system-ui, sans-serif;
        background: var(--color-background-primary, #fff);
        color: var(--color-text-primary, #1a1a1a);
      }
    </style>
  </head>
  <body>
    <h1>Weather</h1>
    <div id="forecast">載入中……</div>
    <script>
      // 實際的 app 會在這裡完成 ui/initialize 交握、讀 structured content 並渲染，
      // 也可能回頭呼叫 app-only 工具。這些都超出本章範圍。
    </script>
  </body>
</html>
```

`[McpMeta("ui", ...)]` 把 UI 的安全設定塞進資源的 `_meta`——上面這份宣告「這個 UI 只能連 `api.weather.gov`」，並請 host 幫它畫個邊框。

> ⚠️ **注意是具名的 `JsonValue =`，不是第二個位置參數。** `McpMetaAttribute` 的字串建構子會把值**當成字串序列化**，用位置參數寫會得到
>
> ```json
> "_meta": { "ui": "{\"csp\":{...},\"prefersBorder\":true}" }
> ```
>
> ——`ui` 的值是一個**字串**而不是物件。用具名的 `JsonValue`（它標了 `[StringSyntax(Json)]`）才會得到
>
> ```json
> "_meta": { "ui": { "csp": {...}, "prefersBorder": true } }
> ```
>
> 兩種寫法都能編譯、都不會有警告，差別只在送出去的 JSON 形狀——**實測 `resources/list` 回應確認**。上游 `samples/WeatherAppServer` 目前用的是位置參數形式。

### 步驟 3：啟用 extension

`WithMcpApps()` 掛在 server builder 上，它會註冊一個 post-configuration 步驟，掃過所有已註冊的工具，把 `[McpAppUi]` 的內容寫進各自的 `_meta.ui`：

```csharp
using ModelContextProtocol.Extensions.Apps;

builder.Services
    .AddMcpServer(options =>
    {
        options.ServerInfo = new Implementation { Name = "weather-app-server", Version = "1.0.0" };
        options.Capabilities = new ServerCapabilities
        {
            Tools = new ToolsCapability(),
            Resources = new ResourcesCapability(),
        };
    })
    .WithHttpTransport()
    .WithTools<WeatherTools>()
    .WithResources<WeatherResources>()
    .WithMcpApps();                    // ← 放最後

var app = builder.Build();
app.MapMcp("/mcp");
app.Run();
```

`WithMcpApps()` 同時會把 `io.modelcontextprotocol/ui` 加進 server capabilities 的 `Extensions` 字典，client 才知道這台 server 支援 Apps。實測 `initialize` 的回應：

```json
"capabilities": {
  "logging": {}, "resources": {}, "tools": {},
  "extensions": { "io.modelcontextprotocol/ui": {} }
}
```

> `WithMcpApps` 定義在 namespace **`ModelContextProtocol.Extensions.Apps`**（不是 `Microsoft.Extensions.DependencyInjection`——`AddMcpServer` 那條慣例在這裡不適用），所以 `using` 別漏。

## 進階用法

### 工具的預期受眾：`Visibility`

**先講結論：`Visibility` 不是存取控制，SDK server 完全不執行它。** 它只是寫進 `_meta.ui.visibility` 的一個宣告，告訴 host「這個工具原本設計給誰用」。要不要據此隱藏或擋下呼叫，**全由 host 決定**——工具內部仍必須自行驗證身分與授權（第 18 章）。

在這個前提下，三種值的語意是：

| 值 | 對 host 的意思 |
|----|--------------|
| `McpUiToolVisibility.Model`（`"model"`） | host 應只把它暴露給 agent／模型 |
| `McpUiToolVisibility.App`（`"app"`） | host 應只允許同連線的 app UI 呼叫 |
| 兩者都給、或不設（null／空） | 沒有限制偏好（**預設**） |

**App-only 工具**的用意是 UI 上的按鈕處理器、表單送出這類「給介面用、不該干擾模型」的工具：

```csharp
[McpServerTool, Description("Submit the weather form")]
[McpAppUi(ResourceUri = "ui://weather/view.html", Visibility = [McpUiToolVisibility.App])]
public static string SubmitWeatherForm(string city) => GetWeatherHtml(city);
```

反過來，純資料查詢的工具可以設 `Model`，避免 UI 誤用。

實測佐證（Streamable HTTP，v2.2.0）：app-only 工具**照樣列在 `tools/list`**，而且同一個 client 可以直接 `tools/call` 成功——

```json
{ "name": "submit_weather_form",
  "_meta": { "ui": { "resourceUri": "ui://weather/view.html", "visibility": ["app"] } } }
```

上游 `McpAppsBuilderExtensions` 只把 attribute 套進 `_meta.ui`，沒有任何過濾或授權邏輯。所以不支援 MCP Apps 的 client 會看到你全部的 app-only 工具，並且能呼叫它們。

### 優雅降級：client 不支援怎麼辦

不是所有 client 都支援 MCP Apps。用 `McpApps.GetUiCapability` 檢查，回不同內容：

```csharp
[McpServerTool, Description("Get weather")]
[McpAppUi(ResourceUri = "ui://weather/view.html")]
public static string GetWeather(McpServer server, string location)
{
    var uiCapability = McpApps.GetUiCapability(server.ClientCapabilities);

    // 光是「有宣告 extension」不夠——還要確認它吃得下你要送的 MIME type
    if (uiCapability?.MimeTypes?.Contains(McpApps.HtmlMimeType) != true)
    {
        // client 不支援，或支援的格式不含 mcp-app HTML——回完整文字
        return $"Current weather for {location}: 72°F, sunny";
    }

    // 確認相容——UI resource 會被顯示，這裡回簡短說明即可
    return $"Weather data for {location} loaded into UI";
}
```

**注意判斷條件不能只寫 `is not null`。** `GetUiCapability` 做的事僅止於「把 `extensions["io.modelcontextprotocol/ui"]` 的值解析成 `McpUiClientCapabilities`」——它**不驗證** `MimeTypes`。回傳非 null 只代表那個 key 存在且值是個物件，不代表對方吃得下 `text/html;profile=mcp-app`。而依 `McpUiClientCapabilities.MimeTypes` 的規約，支援 MCP Apps 的 client **必須**把這個 MIME type 列進清單，所以正確的判斷是檢查清單內容。

**這一步不是可選的。** 你的 server 可能同時服務支援與不支援 Apps 的 client；沒有降級路徑，後者拿到的就是一句沒有意義的「已載入 UI」。

### UI resource 的安全設定

`McpUiResourceMeta` 是 UI resource `_meta.ui` 的型別化表示：

```csharp
public sealed class McpUiResourceMeta
{
    public McpUiResourceCsp? Csp { get; set; }                 // 網路與資源載入的來源限制
    public McpUiResourcePermissions? Permissions { get; set; } // iframe allow（Permissions Policy）
    public string? Domain { get; set; }                        // OAuth／CORS 用的專屬 origin（格式與驗證規則依 host 文件）
    public bool? PrefersBorder { get; set; }                   // 請 host 畫邊框
}

public sealed class McpUiResourceCsp
{
    public IList<string>? ConnectDomains { get; set; }   // 允許 fetch/XHR 的網域
    public IList<string>? ResourceDomains { get; set; }  // 允許載入資源的網域
    public IList<string>? FrameDomains { get; set; }     // 允許內嵌 iframe 的網域
    public IList<string>? BaseUris { get; set; }
}

public sealed class McpUiResourcePermissions
{
    public IList<string>? Allow { get; set; }            // camera、microphone、geolocation…
}
```

`Allow` 對應的是 iframe 的 **`allow` attribute（Permissions Policy）**，值是瀏覽器的權限名稱。型別是開放的 `IList<string>?`——**沒有 enum、SDK 也不做值域驗證**，XML doc 列的 `"camera"`、`"microphone"`、`"geolocation"`、`"clipboard-read"`、`"clipboard-write"` 是**例子而非封閉清單**。

> ⚠️ 別跟 iframe 的 `sandbox` attribute 搞混。`scripts`、`forms`、`popups` 是 `sandbox` 的 token，**不是** `allow` 的值，填進 `Allow` 不會有效果。官方 conceptual doc 在這裡的措辭（"Sandbox permissions (scripts, forms, popups, etc.)"）容易誤導；以 `McpUiResourcePermissions` 的 XML doc 為準。
>
> 另外這只是**請求**——host 要不要核准由它的 policy 決定，同樣不能當授權機制。

**預設 CSP 會擋掉外部 script 與 style 載入**（依規格對 host 的要求；本教學未在真正的 Apps host 上觀測過實際 enforcement）。正式環境的 app 應該用 [vite-plugin-singlefile](https://github.com/richardtallent/vite-plugin-singlefile) 這類工具把 JS 與 CSS 全部打包進單一 HTML；簡單的 app 直接用 inline `<script>` / `<style>` 就行。

### 不用 attribute 的兩條路

**手動處理 attribute**——工具是自己 `McpServerTool.Create` 建的、沒走 `WithMcpApps()`：

```csharp
var tools = new[]
{
    McpServerTool.Create(typeof(WeatherTools).GetMethod(nameof(WeatherTools.GetWeather))!),
};

McpApps.ApplyAppUiAttributes(tools);   // 也有單一 tool 的多載
```

**完全程式化**——連 attribute 都不用：

```csharp
var tool = McpServerTool.Create((string location) => $"Weather for {location}");

McpApps.SetAppUi(tool, new McpUiToolMeta
{
    ResourceUri = "ui://weather/view.html",
    Visibility = [McpUiToolVisibility.Model, McpUiToolVisibility.App],
});
```

資源端對應的是 `McpApps.SetResourceUi(resource, McpUiResourceMeta)`。UI 清單來自資料庫或設定檔時走這條。

### 顯示模式與主題

這兩件事都發生在 **app view ↔ host** 之間，server 端沒有對應的 API——本節說明的是「你的 HTML 要怎麼配合」，不是 server 要設定什麼。

**顯示模式**（`inline`、`fullscreen`、`pip`）**不在** server↔client 的 `extensions["io.modelcontextprotocol/ui"]` capability 裡協商。依 MCP Apps 規格草案，view 支援的模式在 UI 專用的 `ui/initialize` 交握中透過 `appCapabilities.availableDisplayModes` 提供；host 若有提供 host context，其 `availableDisplayModes` 會帶下 host 支援的模式（草案把 `hostContext` 訂為 host **SHOULD** 提供，`availableDisplayModes` 本身也是 optional，因此不能假設一定拿得到）。view 之後可以再送 `ui/request-display-mode` 要求切換。C# 這邊也印證了這一點——`McpUiClientCapabilities` 只有 `MimeTypes` 一個欄位，沒有任何 display-mode 相關成員。

> 規格仍是 draft，上述 wire shape 可能變動，別寫死。

**主題**：host **可以**透過 `HostContext.styles.variables` 提供一組標準 CSS 自訂屬性（`--color-background-primary`、`--color-text-primary` 等）給 app 的 iframe——草案允許它只提供**任意子集**，也允許**完全不提供**。所以**你的 CSS 一定要給 fallback**：

```css
body {
  background: var(--color-background-primary, #ffffff);
  color: var(--color-text-primary, #1a1a1a);
}
```

完整變數清單見規格草案（見延伸閱讀）。本教學未在真正的 Apps host 上觀測過主題注入。

### 序列化與 Native AOT

MCP Apps 的型別使用 source-generated JSON 序列化以相容 Native AOT（第 20 章）。手動序列化這些型別時要用專用的 options：

```csharp
var json = JsonSerializer.Serialize(toolMeta, McpApps.SerializerOptions);
var meta = JsonSerializer.Deserialize<McpUiToolMeta>(json, McpApps.SerializerOptions);
```

用預設的 `JsonSerializerOptions` 在 AOT 下會失敗。

## 常見錯誤

**1. 忘了抑制 `MCPEXP003`**

整套 API 都標了 Experimental，不抑制就編不過。但也**別在專案層級全域關掉**——那樣 SDK 升級帶來的破壞性變更你會完全看不到。用 `#pragma warning disable/restore` 包住最小範圍。

**2. `using` 寫成 `Microsoft.Extensions.DependencyInjection`**

`AddMcpServer` 那條「DI 擴充方法放 `Microsoft.*` namespace」的慣例（第 03 章）**不適用於 `WithMcpApps`**——它在 `ModelContextProtocol.Extensions.Apps`。找不到擴充方法時先檢查這個。

**3. 降級判斷只寫 `GetUiCapability(...) is not null`**

`GetUiCapability` 只負責解析 capability，**不檢查 MIME type**。要判斷相容性必須看回傳物件的 `MimeTypes` 是否包含 `McpApps.HtmlMimeType`。另外，只寫「UI 已載入」這種回覆，在不支援 Apps 的 client 上就是一句廢話——工具在無 UI 時要回傳有意義的文字或 structured content。

**4. UI resource 的 MIME type 用成 `text/html`**

必須是 `text/html;profile=mcp-app`——用 `McpApps.HtmlMimeType` 常數，別自己打字串。少了 `;profile=mcp-app`，client 會當成普通 HTML 資源而不是 app UI。

**5. 外部 CDN 的 script 載不進來**

預設 CSP 擋外部 script／style。要嘛把資源打包進單一 HTML，要嘛在 `McpUiResourceCsp` 明確列出允許的網域——後者要想清楚，那等於放寬了 UI 的網路邊界。

**6. 以為 `Visibility` 是權限控制**

它連「可見性」都不是——**server 不會依它過濾 `tools/list`**（實測見前面「工具可見性」段）。它只是寫進 `_meta.ui.visibility` 的一個宣告，要不要對模型隱藏完全由 host 決定。所以它既不是授權機制，也不能當成「模型看不到就等於呼叫不到」的依據：**任何 client 都能直接呼叫 app-only 工具**。真正的存取控制一律在工具內部做（第 18 章）。

**7. `[McpMeta]` 用位置參數傳 JSON**

`[McpMeta("ui", """{...}""")]` 送出去的是**字串**不是物件（見步驟 2 的說明）。要具名寫 `JsonValue = """{...}"""`。兩種都能編譯，錯了也沒有警告，只能靠檢查實際的 `resources/list` 回應發現。

**8. 只裝了 `ModelContextProtocol`**

MCP Apps 在獨立套件 `ModelContextProtocol.Extensions.Apps`，跟第 17 章的 Tasks 一樣要另外裝（第 02 章的套件表）。

## 相關章節

- [第 02 章：SDK 套件選擇與安裝](./02-nuget-packages.md)——`.Extensions.Apps` 的定位
- [第 05 章：工具進階](./05-mcp-server-tools-advanced.md)——structured content，UI 讀的就是它
- [第 07 章：Resources](./07-mcp-server-resources.md)——UI resource 就是特殊 MIME type 的資源
- [第 12 章：ASP.NET Core 託管](./12-aspnetcore-hosting.md)——Apps 範例走 HTTP 傳輸
- [第 17 章：Tasks](./17-tasks.md)——另一個獨立 extension 套件，`MCPEXP002` 的抑制模式相同
- [第 18 章：Authorization 與傳輸安全](./18-authorization-and-security.md)——`Visibility` 不是授權
- [第 20 章：Native AOT](./20-native-aot.md)——`McpApps.SerializerOptions` 的存在理由
- [附錄 D：官方 Samples 導覽](./appendix-d-samples-tour.md)——`WeatherAppServer` 的完整版本

## 延伸閱讀

- 官方概念文件：`raw/docs-conceptual/apps.md`
- 上游範例：`samples/WeatherAppServer`（目標框架 net10.0——這是**該範例**的選擇，不是套件門檻；`.Extensions.Apps` 本身支援 net10.0 / net9.0 / net8.0 / netstandard2.0，見附錄 A）
- [MCP Apps 規格草案](https://github.com/modelcontextprotocol/ext-apps/blob/main/specification/draft/apps.mdx)——含完整的 host CSS 變數清單
- wiki：[mcp-apps](../mcp-csharp-sdk-kb/wiki/concepts/mcp-apps.md)
- 本章程式碼的建置與執行期驗證記錄：[reviews/review-21-mcp-apps.md](./reviews/review-21-mcp-apps.md)
