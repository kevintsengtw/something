# 第 08 章：傳輸層總覽與 Sessions

> 對應 wiki 概念：[stdio-transport](../mcp-csharp-sdk-kb/wiki/concepts/stdio-transport.md)、[streamable-http-transport](../mcp-csharp-sdk-kb/wiki/concepts/streamable-http-transport.md)、[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md)
> 上游 API：`StdioClientTransport` / `HttpClientTransport` / `StreamClientTransport`（`ModelContextProtocol.Core`）、`WithStdioServerTransport`（`ModelContextProtocol`）、`WithHttpTransport` / `MapMcp` / `HttpServerTransportOptions`（`ModelContextProtocol.AspNetCore`）
> 基準版本：v2.2.0

## 本章目標

前七章的範例都用 stdio 一種傳輸。本章把鏡頭拉遠，看 MCP 的**傳輸層全貌**與 HTTP 下的 **session 模式**。讀完本章，你可以：

- 依場景選對傳輸：Stdio（本機子行程）、Streamable HTTP（遠端/網路）、In-memory（測試）
- 寫出 stdio 與 HTTP 兩種傳輸的 server 端與 client 端設定
- 分辨 **stateless、stateful 與 hybrid** 三種 HTTP session 模式，並知道各自犧牲了什麼
- 理解 legacy SSE 的處境（v1.2.0 起預設停用）與 client 端 `AutoDetect` 的行為
- 避開 stdio 汙染 stdout、stateless 下期待伺服器主動通知等經典陷阱

## 為什麼需要這個

MCP 的協定訊息（JSON-RPC）與「訊息怎麼送到對面」是分離的——後者就是傳輸層。SDK 把 client 端傳輸抽象成 `IClientTransport`，`McpClient.CreateAsync(transport)` 接受任何實作；server 端則由 builder 擴充方法（`WithStdioServerTransport` / `WithHttpTransport`）決定。三種傳輸各有明確的適用場景：

| 傳輸 | 連線形態 | 適用 | Client 端型別 | Server 端設定 |
|------|---------|------|--------------|--------------|
| **Stdio** | 子行程 stdin/stdout | 本機工具（桌面 host 啟動 server） | `StdioClientTransport` | `WithStdioServerTransport()` |
| **Streamable HTTP** | HTTP POST + SSE 串流 | 遠端/網路、雲端部署 | `HttpClientTransport` | `WithHttpTransport()` + `MapMcp()` |
| **In-memory（stream）** | 行程內 stream 對接 | 測試（不開行程、不開 port） | `StreamClientTransport` | `StreamServerTransport` |

選錯傳輸的代價不小：把該遠端服務的東西做成 stdio，就得在每台機器安裝執行檔；把本機工具做成 HTTP，就多了網路面攻擊面與部署負擔。

## 核心概念

### Stdio：client 啟動 server 子行程

client 負責**啟動** server 行程，雙方以 stdin/stdout 交換訊息。因此 stdio 天生一對一、有狀態——行程活著 session 就在。

最重要的紀律：**stdout 專供協定使用，log 一律走 stderr**。任何 `Console.WriteLine` 都會混進 JSON-RPC 流、直接弄壞連線。

### Streamable HTTP：POST 送請求、SSE 串流回應

client 的每個請求是一個 HTTP POST；server 把該 POST 的回應 body 當 SSE 串流開著，把 JSON-RPC 回應（與中途的進度通知等）寫回去。在 **stateful** 模式下，client 還能另開一條長連線 GET，接收 server **主動發起**的訊息（如第 07 章的資源變更通知）。

### Session 模式：stateless、stateful 與 hybrid 的取捨

v2.2.0 起，HTTP server 以 `HttpServerTransportOptions.SessionMode` 明確選擇三種策略：

| 模式 | `SessionMode` | Session 與協定行為 | 適用 |
|------|---------------|-------------------|------|
| **Stateless**（預設） | `HttpServerSessionMode.Stateless` | 每請求獨立；`SessionId` 為 null；不支援 session-only 的 unsolicited message 與 server→client request | 雲端、serverless、多數 tools/resources server；可加 request-bound listen stream |
| **Stateful** | `HttpServerSessionMode.Stateful` | initialize client 維持 `Mcp-Session-Id`；2026-07-28 request 會收到 `UnsupportedProtocolVersion`，讓 dual-path client 降回 initialize handshake | 所有 client 都必須使用 session 功能 |
| **Hybrid** | `HttpServerSessionMode.StatefulForInitializeClients` | initialize client 使用完整 session；同一 endpoint 的 2026-07-28 client 以 stateless request 運作 | 新舊 client 並存、漸進遷移 |

Stateless 不需要 session affinity，可任意水平擴展；stateful 的 session request 必須回到同一實例。Hybrid 同時具備兩條路徑，但 **stateless 那一半仍不能使用 session-only 功能**。Sampling、一般 Elicitation、Roots 與 unsolicited notification 仍需 session；v2.1.0 的 `subscriptions/listen` 是 request-bound 例外，由 client 建立 held-open POST，因此 stateless request 也能接收這條串流上的通知。需要在 stateless request 中徵詢輸入時，另見 MRTR，而不是把 hybrid 誤解為所有請求都有 session。

舊的 `Stateless` 布林屬性仍是 compatibility proxy：設 `true` 會選 `Stateless`，設 `false` 會選 `Stateful`，但它無法表示 hybrid。若與 `SessionMode` 混用，以最後一次指定為準；新程式應直接使用 `SessionMode`。

### Legacy SSE：已是過去式

舊版 HTTP+SSE 傳輸（`/sse` + `/message` 雙端點）自 v1.2.0 起 `MapMcp()` **預設不再掛載**。要過渡期兼容只能設 `HttpServerTransportOptions.EnableLegacySse = true`（已標 `[Obsolete]`，觸發 `MCP9004` 警告）。新專案一律用 Streamable HTTP。

## 上手範例

### Stdio：server 端與 client 端

```csharp
// Server（同第 04 章）
builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithToolsFromAssembly();
```

```csharp
// Client：啟動子行程 server
using ModelContextProtocol.Client;

var transport = new StdioClientTransport(new StdioClientTransportOptions
{
    Name = "Everything",
    Command = "npx",
    Arguments = ["-y", "@modelcontextprotocol/server-everything"],
});
var client = await McpClient.CreateAsync(transport);
```

`StdioClientTransportOptions` 的 `Command` 為必填（required）；`Name` 只是 log 識別用；另有 `WorkingDirectory`、`EnvironmentVariables`、`ShutdownTimeout`（預設 5 秒）、`StandardErrorLines`（逐行接收 server 的 stderr）可用。

### Streamable HTTP：server 端與 client 端

```csharp
// Server：ModelContextProtocol.AspNetCore 套件
// 取自 docs/concepts/transports/transports.md
using ModelContextProtocol.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMcpServer()
    .WithHttpTransport(options =>
    {
        // 不需要 session-only server→client 請求，顯式選 stateless
        options.SessionMode = HttpServerSessionMode.Stateless;
    })
    .WithTools<MyTools>();

var app = builder.Build();
app.MapMcp();          // 預設掛在根端點；app.MapMcp("/mcp") 可自訂路由
app.Run();
```

```csharp
// Client：連遠端 MCP server
// 取自 docs/concepts/transports/transports.md
using ModelContextProtocol.Client;

var transport = new HttpClientTransport(new HttpClientTransportOptions
{
    Endpoint = new Uri("https://my-mcp-server.example.com/mcp"),
    TransportMode = HttpTransportMode.StreamableHttp,
});
await using var client = await McpClient.CreateAsync(transport);
```

`HttpTransportMode` 有三個值：`AutoDetect`（**預設**，先試 Streamable HTTP、失敗再退回 SSE）、`StreamableHttp`（只用新協定）、`Sse`（只用 legacy）。連自己控制的新 server 可直接鎖 `StreamableHttp`。

## 進階用法

### Session 相關選項（`HttpServerTransportOptions`）

| 選項 | 預設 | 用途 |
|------|------|------|
| `SessionMode` | `HttpServerSessionMode.Stateless` | 選擇 `Stateless`、`Stateful` 或 `StatefulForInitializeClients`；見上 |
| `Stateless` | `true` | `SessionMode` 的 compatibility proxy；無法表示 hybrid，混用時最後一次指定生效 |
| `ConfigureSessionOptions` | — | 每 session 初始化時（stateless 為每請求）以 `HttpContext` 客製 `McpServerOptions` |
| `RunSessionHandler` | — | 手動接管 session 執行（前後掛邏輯）；**Experimental（MCPEXP002）**，官方建議優先用 `ConfigureSessionOptions` |
| `IdleTimeout` | 2 小時 | 閒置 session 逾時；逾時後 client 拿到 404 需重建 session |
| `MaxIdleSessionCount` | 10,000 | 記憶體中閒置 session 上限，超過會強制回收最舊的 |

Hybrid 下，`ConfigureSessionOptions` 與 `RunSessionHandler` 對 initialize client 是每 session 執行一次，對 2026-07-28 client 則是每 request 執行一次。第 07 章 EverythingServer 的訂閱表清理就是掛在 `RunSessionHandler`（並以 `#pragma warning disable MCPEXP002` 抑制警告）的例子。

### Client 端傳輸選項（`HttpClientTransportOptions`）

**`EnableStandaloneGetStream`（預設 `true`）**——Streamable HTTP client 在初始化後會另外開一條 standalone GET SSE stream，專門接收 server 主動推送的訊息（訂閱通知那類）。設成 `false` 就不開這條：

```csharp
var transport = new HttpClientTransport(new HttpClientTransportOptions
{
    Endpoint = new Uri("http://localhost:5000/"),
    TransportMode = HttpTransportMode.StreamableHttp,
    EnableStandaloneGetStream = false,   // 不需要主動推送時關掉
});
```

兩個關掉它的理由：**用不到**（你的 client 只發請求收回應，不需要 unsolicited 訊息），或是**連線池被卡住**（長壽命的 GET 會佔住一條連線，`HttpClient` 連線池吃緊時會排擠其他請求）。關掉之後，POST 請求的直接回應與串流回應照常運作——只是少了那條 standalone GET。

**`AutoDetect` 的探測行為**——`HttpTransportMode.AutoDetect`（預設）先試 Streamable HTTP，失敗才退回 legacy SSE。探測期間兩條路徑共用同一個 message channel，SSE 端在 AutoDetect 尚未定案前不會關掉它，避免探測中的訊息掉包。退回時 SDK 會記錄一則 Information 等級的日誌，帶上觸發退回的 HTTP 狀態碼。

**HTTP 狀態碼的跨 TFM 保存（v2.1.0）**——傳輸層失敗時丟的是 `HttpRequestException`。`HttpRequestException.StatusCode` 這個屬性只有較新的 TFM 才有，所以 SDK **在所有 TFM 上**都額外把狀態碼放進 `Data`：

```csharp
catch (HttpRequestException ex)
{
    // 較新 TFM：ex.StatusCode 可直接用
    // 所有 TFM（含 netstandard2.0）：一律可從 Data 取
    if (ex.Data["ModelContextProtocol.HttpStatusCode"] is HttpStatusCode status)
    {
        logger.LogWarning("MCP 傳輸失敗，HTTP {Status}", status);
    }
}
```

多目標框架的函式庫要讀狀態碼時，用 `Data` 這條路才不必寫 `#if` 分支。

### Stdio 環境變數與安全（v1.4.0）

stdio 子行程**預設繼承**父行程的全部環境變數（`InheritEnvironmentVariables = true`，v1.4.0 新增此開關）。跑第三方 server 時這會把 `GITHUB_TOKEN`、`OPENAI_API_KEY` 之類的機密一併帶過去——關掉繼承、改用白名單起點：

```csharp
// 取自 StdioClientTransportOptions 的官方文件註解
var env = StdioClientTransportOptions.GetDefaultEnvironmentVariables();  // PATH、HOME 等安全子集
env["MY_SERVER_API_KEY"] = apiKey;

var transport = new StdioClientTransport(new StdioClientTransportOptions
{
    Command = "my-mcp-server",
    InheritEnvironmentVariables = false,   // 子行程從空環境開始
    EnvironmentVariables = env,
});
```

### Session 恢復（resumability，概覽）

stateful 模式支援斷線恢復：client 保存 `SessionId` 與 server 資訊後，以 `HttpClientTransportOptions.KnownSessionId` + `McpClient.ResumeSessionAsync(transport, new ResumeClientSessionOptions { ... })` 重連；server 端可設定 `HttpServerTransportOptions.EventStreamStore` 讓斷線期間的 SSE 事件可重播。細節屬部署議題，見第 12 章（[aspnetcore-hosting](../mcp-csharp-sdk-kb/wiki/concepts/aspnetcore-hosting.md)）。

### In-memory：測試專用（概覽）

行程內以 stream 對接 `StreamServerTransport`（server）與 `StreamClientTransport`（client），不開子行程、不開 port，適合端對端測試。注意 `StreamClientTransport` 的 namespace 是 `ModelContextProtocol.Protocol`（檔案在 `Client/` 目錄下，但 namespace 不同）。完整用法與官方 `InMemoryTransport` sample 見第 13 章（[testing-strategy](../mcp-csharp-sdk-kb/wiki/concepts/testing-strategy.md)、[in-memory-transport](../mcp-csharp-sdk-kb/wiki/concepts/in-memory-transport.md)）。

## 常見錯誤

- **stdio server 對 stdout 寫 log**：`Console.WriteLine` 會汙染協定流。log 走 stderr（client 端可用 `StandardErrorLines` 接）；用 `Microsoft.Extensions.Logging` 時把 console logger 導向 stderr。
- **stateless 下期待任意伺服器主動通知**：`SessionMode = HttpServerSessionMode.Stateless` 時沒有持久 session，`SessionId` 為 null；Sampling、一般 Elicitation、Roots 與 unsolicited notification 不可用。v2.1.0 的 `subscriptions/listen` 只是在 client 開啟的 held-open POST 上送 request-bound 通知，不改變這項限制。
- **`SessionMode = Stateless` 又 `EnableLegacySse = true`**：啟動即丟 `InvalidOperationException`——SSE 需要記憶體內 session 狀態，兩者互斥。
- **把 hybrid 當成「每個 client 都有 session」**：`StatefulForInitializeClients` 只替 initialize-handshake client 建 session；2026-07-28 request 仍是 stateless，不能使用 session-only 功能。
- **混用 `Stateless` 與 `SessionMode` 卻假設前者優先**：兩者寫入同一設定，最後一次指定生效。新程式只使用 `SessionMode`，可避免初始化順序改變行為。
- **升級後仍假設預設 stateful**：預設仍是 stateless；需要 Sampling、一般 Elicitation、Roots、一般主動通知或其他 server→client request 時，明確選 `Stateful`，或用 hybrid 只替 initialize client 保留 session。只有採用 v2.1.0 自訂 `subscriptions/listen` 的 request-bound 訂閱串流可例外留在 stateless。
- **升級 v1.2.0+ 後 legacy client 連不上**：`MapMcp()` 不再自動掛 `/sse`、`/message`。確認 client 支援 Streamable HTTP，或過渡期顯式 `EnableLegacySse = true`（會有 `MCP9004`）。
- **自訂路由後 client 連錯端點**：`app.MapMcp("/mcp")` 時 Streamable HTTP client 連 `https://host/mcp`；legacy SSE client（若啟用）連 `https://host/mcp/sse`。
- **跑第三方 stdio server 不管環境變數**：預設全數繼承，機密可能外流；用 `InheritEnvironmentVariables = false` + `GetDefaultEnvironmentVariables()` 白名單。

## 相關章節

- 第 04 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) — 第一次用 stdio 跑起 server
- 第 07 章：[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md)、[subscriptions-listen](../mcp-csharp-sdk-kb/wiki/concepts/subscriptions-listen.md) — stateful 訂閱與 v2.1.0 request-bound listen stream
- 第 09 章：[notifications-progress](../mcp-csharp-sdk-kb/wiki/concepts/notifications-progress.md) — 通知機制總覽（哪些訊息需要 server 主動推）
- 第 12 章：[aspnetcore-hosting](../mcp-csharp-sdk-kb/wiki/concepts/aspnetcore-hosting.md) — HTTP 部署深入（stateless/stateful 取捨、resumability、安全）
- 第 13 章：[testing-strategy](../mcp-csharp-sdk-kb/wiki/concepts/testing-strategy.md)、[in-memory-transport](../mcp-csharp-sdk-kb/wiki/concepts/in-memory-transport.md) — in-memory transport 的完整用法
- 第 18 章：[transport-security](../mcp-csharp-sdk-kb/wiki/concepts/transport-security.md) — host validation、CORS、DNS rebinding

## 延伸閱讀

- 官方概念文件：Transports（`raw/docs-conceptual/transports.md`）、Stateless（`raw/docs-conceptual/stateless.md`）
- 上游 sample：`samples/InMemoryTransport/`、`samples/AspNetCoreMcpPerSessionTools/`（自訂路由）
- 第 07 章用到的 `samples/EverythingServer/Program.cs`（stateful + `RunSessionHandler` 實例）
