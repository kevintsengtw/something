# 第 05 章：工具進階（DI 注入、McpServer、Schema、錯誤處理）

> 對應 wiki 概念：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md)
> 上游 API：`McpServerTool` / `[McpServerTool]`（`ModelContextProtocol.Core`）、`CallToolResult`（`ModelContextProtocol.Protocol`）、`McpException` / `McpProtocolException` / `McpErrorCode`（`ModelContextProtocol`，`ModelContextProtocol.Core`）
> 基準版本：v2.2.0

## 本章目標

第 04 章讓一個 `[McpServerTool]` 方法跑了起來。真實世界的工具還需要：拿到相依服務、在執行中與 server 互動、精準控制對外的 JSON Schema、把錯誤正確地回報給模型。讀完本章，你可以：

- 分辨工具參數的兩種身分：**模型輸入**（進 JSON Schema）vs **框架注入**（DI 服務、`McpServer`、`RequestContext<TParams>`、`CancellationToken`）
- 用 DI 注入服務到工具方法，並注入 `McpServer` 取得當前連線的 server
- 掌握參數 JSON Schema 的自動產生規則、`[Description]` 與預設值
- 選對回傳型別（`string`、`ContentBlock`、`CallToolResult`、結構化輸出）
- 用 tool annotations（`ReadOnly` / `Destructive` / `Idempotent` / `OpenWorld`）宣告工具行為
- 用 `McpException` / `McpProtocolException` 正確區分「工具錯誤」與「協定錯誤」

## 為什麼需要這個

MCP C# SDK 對工具方法的參數做了一件關鍵的事：**依型別把參數分成兩類**。

- 「一般值」型別（`string`、`int`、你的 DTO……）→ 視為**模型要填的輸入**，進到工具的 JSON Schema，由 LLM 決定值。
- 「框架/服務」型別（DI 註冊的服務、`McpServer`、`RequestContext<TParams>`、`CancellationToken`）→ 視為**框架要注入的相依**，**不會**出現在 Schema 裡，模型看不到也不需要填。

這個設計讓你能把「一個需要 `HttpClient`、需要在執行中向 client 送進度、還要支援取消」的工具，寫得跟一個普通 C# 方法一樣自然——相依由 DI 給、Schema 只暴露真正的輸入。這一章就是在講這條分界線兩側的細節。

## 核心概念

### 參數的兩種身分

當 SDK 從你的方法產生工具時，會逐一檢視參數型別：

| 參數型別 | 身分 | 進 JSON Schema？ | 值從哪來 |
|---------|------|:---:|---------|
| `string` / `int` / `bool` / 你的類別… | 模型輸入 | ✅ 是 | LLM 依 Schema 填 |
| DI 容器中註冊的服務型別（如 `HttpClient`） | 框架注入 | ❌ 否 | `IServiceProvider` 解析 |
| `McpServer` | 框架注入 | ❌ 否 | 當前連線的 server 實例 |
| `RequestContext<CallToolRequestParams>` | 框架注入 | ❌ 否 | 本次請求的 context（含 `Params`） |
| `CancellationToken` | 框架注入 | ❌ 否 | 框架傳入（連線中斷/取消時觸發） |

> 📌 **注入判定機制**：SDK 用 `IServiceProviderIsService.IsService(參數型別)` 判斷某個參數型別是否為「已註冊的服務」——是的話就從 `IServiceProvider` 解析，不當成 Schema 輸入（`src/ModelContextProtocol.Core/Server/AIFunctionMcpServerTool.cs`）。所以「有沒有被 DI 認得」決定了一個參數是輸入還是注入。

> ⚠️ **注入的是 `McpServer`，不是 `IMcpServer`**。SDK 沒有 `IMcpServer` 這個介面；工具要拿到 server 就宣告一個 `McpServer` 型別的參數（型別在 namespace `ModelContextProtocol.Server`，套件 `.Core`）。

## 上手範例

### 注入 DI 服務（接續第 03 章的相依註冊）

工具型別可以是**非 static 的 instance 類別**，透過建構式注入 DI 已註冊的服務。下例（官方 `ProtectedMcpServer`）注入 `IHttpClientFactory`；工具方法的 `state` 是模型輸入，但 factory **不會**出現在 input schema：

```csharp
// 取自 samples/ProtectedMcpServer/Tools/WeatherTools.cs（節錄）
using ModelContextProtocol;                 // McpException
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerToolType]
public sealed class WeatherTools
{
    private readonly IHttpClientFactory _httpClientFactory;

    public WeatherTools(IHttpClientFactory httpClientFactory)   // ← DI 注入
    {
        _httpClientFactory = httpClientFactory;
    }

    [McpServerTool, Description("Get weather alerts for a US state.")]
    public async Task<string> GetAlerts(
        [Description("The US state to get alerts for. Use the 2 letter abbreviation for the state (e.g. NY).")] string state) // ← 模型輸入
    {
        var client = _httpClientFactory.CreateClient("WeatherApi");
        using var doc = await client.GetFromJsonAsync<JsonDocument>($"/alerts/active/area/{state}")
            ?? throw new McpException("No JSON returned from alerts endpoint");
        // ... 解析 doc 並回傳文字 ...
    }
}
```

搭配第 03 章的服務註冊（例如）：

```csharp
builder.Services.AddHttpClient("WeatherApi", c => c.BaseAddress = new Uri("https://api.weather.gov"));
```

> 你也可以直接把一個 `HttpClient` 參數放進**方法簽名**（而非建構式），只要該型別被 DI 認得，同樣會被注入且排除於 schema。建構式注入適合 instance 工具型別共用相依；參數注入適合單一方法臨時取用。

### 注入 `McpServer` 與 `RequestContext<TParams>`

需要在工具執行中「回頭用 server」時（送進度通知、向 client 反向請求 LLM 補全），注入 `McpServer`；要讀本次請求的參數（如 `ProgressToken`）就注入 `RequestContext<CallToolRequestParams>`。下例取自官方 `EverythingServer`：

```csharp
// 取自 samples/EverythingServer/Tools/LongRunningTool.cs
using ModelContextProtocol;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerToolType]
public class LongRunningTool
{
    [McpServerTool(Name = "longRunningOperation"), Description("Demonstrates a long running operation with progress updates")]
    public static async Task<string> LongRunningOperation(
        McpServer server,                             // ← 注入當前 server
        RequestContext<CallToolRequestParams> context, // ← 注入本次請求 context
        int duration = 10,                            // ← 模型輸入（選填，有預設值）
        int steps = 5)                                // ← 模型輸入（選填）
    {
        var progressToken = context.Params?.ProgressToken;
        var stepDuration = duration / steps;

        for (int i = 1; i <= steps + 1; i++)
        {
            await Task.Delay(stepDuration * 1000);
            if (progressToken is not null)
            {
                await server.SendNotificationAsync("notifications/progress", new
                {
                    Progress = i,
                    Total = steps,
                    progressToken
                });
            }
        }
        return $"Long running operation completed. Duration: {duration} seconds. Steps: {steps}.";
    }
}
```

> `server`、`context` 都不在工具的 input schema 裡；模型只需（選擇性）提供 `duration` 與 `steps`。進度通知的完整說明在第 09 章（[notifications-progress](../mcp-csharp-sdk-kb/wiki/concepts/notifications-progress.md)）；用注入的 `McpServer` 向 client 反向請求 LLM 補全（sampling）見第 14 章（[sampling](../mcp-csharp-sdk-kb/wiki/concepts/sampling.md)）。

## 進階用法

### JSON Schema 的自動產生

工具參數的 input schema 由方法簽名自動產生（JSON Schema）。.NET 型別對應：

| .NET 型別 | JSON Schema 型別 |
|-----------|-----------------|
| `string` | `string` |
| `int`、`long` | `integer` |
| `float`、`double` | `number` |
| `bool` | `boolean` |
| 複雜型別（你的類別） | `object` + `properties` |

- `[Description]`（`System.ComponentModel.DescriptionAttribute`，.NET BCL——非 SDK 型別，SDK 只是讀它）會填入 Schema 的 `description` 欄位，幫助模型理解參數用途。
- **參數的預設值會被帶進 Schema**——有預設值的參數即為選填。

```csharp
[McpServerTool, Description("Searches for items")]
public static string Search(
    [Description("The search query string")] string query,
    [Description("Maximum results to return (1-100)")] int maxResults = 10)  // 預設值 → 選填
{
    // Schema 會含 query（必填）、maxResults（選填、預設 10）
    return $"searching '{query}', top {maxResults}";
}
```

### 回傳型別：從 `string` 到多內容區塊

工具的回傳型別很有彈性，SDK 會自動包裝成協定的內容區塊（`ContentBlock`，ns `ModelContextProtocol.Protocol`）：

| 回傳 | 結果 |
|------|------|
| `string` | 自動包成 `TextContentBlock` |
| `ContentBlock`（如 `ImageContentBlock`、`AudioContentBlock`、`EmbeddedResourceBlock`） | 直接作為該內容 |
| `IEnumerable<ContentBlock>` | 多內容區塊（如文字 + 圖片） |
| 你的類別 / record | 序列化為 JSON（可搭配結構化輸出，見下） |
| `CallToolResult` | 完全掌控結果（含 `IsError`、`StructuredContent`）|

```csharp
using ModelContextProtocol.Protocol;

// 回傳多個內容區塊：一段文字 + 一張圖
[McpServerTool, Description("Returns text and an image")]
public static IEnumerable<ContentBlock> Describe(byte[] pngBytes)
{
    return
    [
        new TextContentBlock { Text = "這是產生的圖片：" },
        ImageContentBlock.FromBytes(pngBytes, "image/png"),
    ];
}
```

> `TextContentBlock` / `ImageContentBlock` / `AudioContentBlock` / `EmbeddedResourceBlock` 皆為 `sealed class : ContentBlock`；`ImageContentBlock.FromBytes` / `AudioContentBlock.FromBytes` 為工廠方法（`src/ModelContextProtocol.Core/Protocol/ContentBlock.cs`）。

### 內嵌資源與二進位內容的 client 邊界

`EmbeddedResourceBlock` 讓工具把一份資源**直接嵌在結果裡**，不必讓 client 再發一次 `resources/read`。它的 `Resource` 欄位吃 `TextResourceContents` 或 `BlobResourceContents`（第 07 章介紹過這兩個型別）：

```csharp
using ModelContextProtocol.Protocol;

// 文字資源
[McpServerTool, Description("Returns a document as an embedded resource")]
public static EmbeddedResourceBlock GetDocument() =>
    new()
    {
        Resource = new TextResourceContents
        {
            Uri = "docs://readme",
            MimeType = "text/plain",
            Text = "This is the document content.",
        },
    };

// 二進位資源：用 FromBytes 讓 SDK 處理 base64 編碼
[McpServerTool, Description("Returns a binary resource")]
public static EmbeddedResourceBlock GetBinaryData(string id) =>
    new()
    {
        Resource = BlobResourceContents.FromBytes(
            LoadData(id), $"data://items/{id}", "application/octet-stream"),
    };
```

**這裡有一條容易誤會的界線**：SDK 只負責把二進位資源用 MCP 的資源形狀送出去——URI、MIME type、base64 的 `blob`——**它不做格式轉換**。丟一份 `application/pdf` 出去，SDK 不會替你轉成圖片。至於這份資源會不會被顯示、會不會餵給模型、怎麼呈現，**完全由 client 決定**。

所以面向不確定支不支援某種二進位格式的 client 時，務必**同時附一個備援表示**：

```csharp
[McpServerTool, Description("Returns a chart, with a text fallback")]
public static IEnumerable<ContentBlock> GetChart()
{
    yield return new TextContentBlock { Text = "Q3 營收 1,240 萬，較上季成長 8%。" };  // 任何 client 都讀得到
    yield return new EmbeddedResourceBlock
    {
        Resource = BlobResourceContents.FromBytes(RenderPdf(), "reports://q3", "application/pdf"),
    };
}
```

#### 與 `Microsoft.Extensions.AI` 的 `DataContent` 互轉

工具也可以直接回傳 `Microsoft.Extensions.AI` 的 `DataContent`，SDK 依 **top-level media type** 自動對應（實作在 `AIContentExtensions`）：

| `DataContent` 的 media type | 對應的 MCP content block |
|---|---|
| `image/*` | `ImageContentBlock` |
| `audio/*` | `AudioContentBlock` |
| 其他全部 | `EmbeddedResourceBlock`（二進位 resource contents） |

反方向也成立：`ImageContentBlock` / `AudioContentBlock` 轉回 `DataContent`，`EmbeddedResourceBlock` 則取其 `Resource` 再轉；`BlobResourceContents` 的 MIME type 若沒填，轉換時預設為 `application/octet-stream`。這條雙向管線是第 16 章把 MCP 工具餵給 `IChatClient` 時的底層機制。

### 結構化輸出（Structured Content）

要讓工具回傳**機器可解析的結構化資料**（而非只有文字），在 attribute 上開 `UseStructuredContent`；SDK 會據回傳型別產生 output schema（填入 protocol 層的 `Tool.OutputSchema`，`JsonElement?`），並把結果放進 `CallToolResult.StructuredContent`（`JsonElement?`）：

```csharp
[McpServerTool(UseStructuredContent = true), Description("Returns structured weather data")]
public static WeatherReport GetReport(string city) => new(city, 28.5, "Sunny");

public record WeatherReport(string City, double TempC, string Condition);
```

> 若要讓「宣告的 output schema」與「實際回傳型別」解耦，用 `[McpServerTool]` 的 `OutputSchemaType`（`Type?`）指定另一個型別作為 schema 依據（**1.2.0** 起，對應上游 #1425）。這在你回傳 `CallToolResult` 卻仍想宣告輸出結構時特別有用。

### 行為提示（Tool Annotations）

`[McpServerTool]` 有幾個布林屬性，向 client / 模型宣告工具的行為特性（**僅為提示，不改變執行**）。屬性與預設值（`src/ModelContextProtocol.Core/Server/McpServerToolAttribute.cs`，預設為 `const`）：

| 屬性 | 型別 | 預設 | 含意 |
|------|------|:---:|------|
| `ReadOnly` | `bool` | `false` | 工具只讀、不改變環境狀態 |
| `Destructive` | `bool` | `true` | 可能做破壞性更新（`ReadOnly=false` 時才有意義）|
| `Idempotent` | `bool` | `false` | 相同參數重複呼叫無額外影響（`ReadOnly=false` 時才有意義）|
| `OpenWorld` | `bool` | `true` | 與「開放世界」的外部實體互動（如網路搜尋）；`false` 表示封閉、可預期（如記憶體存取）|

```csharp
[McpServerTool(ReadOnly = true, OpenWorld = false), Description("Reads a value from local cache")]
public static string GetCached(string key) => _cache.TryGetValue(key, out var v) ? v : "";
```

其他常用屬性：`Name`（覆寫工具名，見第 04 章）、`Title`（人類可讀標題）、`IconSource`（圖示）。

### 錯誤處理：工具錯誤 vs 協定錯誤

MCP 把兩種錯誤分得很清楚，這是本章最重要的一節（依官方 `tools.md`「Error handling」）：

**（1）工具錯誤 — 讓模型看見並可能自我修復。** 工具方法丟出例外時，server 會**攔截**它、回傳一個 `IsError = true` 的 `CallToolResult`（而不是讓連線炸掉）。訊息處理規則：

- 若例外**衍生自 `McpException`**（且不是 `McpProtocolException`）→ 其 `Message` 會被放進錯誤文字（你可控制對模型顯示的內容）。
- 其他例外 → 只回一句**通用訊息**（`"An error occurred invoking '<tool>'."`），避免洩漏內部細節。

```csharp
using ModelContextProtocol;   // McpException

[McpServerTool, Description("Divides two numbers")]
public static double Divide(double a, double b)
{
    if (b == 0)
        throw new McpException("Cannot divide by zero.");  // 訊息會傳給模型
    return a / b;
}
```

> 對照：若上例丟的是 `ArgumentException`，模型只會看到通用訊息 `"An error occurred invoking 'divide'."`——內部細節不外洩。想讓模型看到具體原因，就用 `McpException`。

**（2）協定錯誤 — 以 JSON-RPC error 回應。** 要表達「這是協定層級的錯誤」（如參數非法、未知工具），丟 `McpProtocolException`（`: McpException`）；它**不會**被包成工具結果，而是 re-throw 成 JSON-RPC error response，可帶 `McpErrorCode`：

```csharp
using ModelContextProtocol;   // McpProtocolException / McpErrorCode

[McpServerTool, Description("Processes the input")]
public static string Process(string input)
{
    if (string.IsNullOrEmpty(input))
        // 對外為 JSON-RPC error，code -32602 (InvalidParams)
        throw new McpProtocolException("Missing required input", McpErrorCode.InvalidParams);
    return $"Processed: {input}";
}
```

`McpErrorCode` 的完整成員（`src/ModelContextProtocol.Core/McpErrorCode.cs`）：

| 成員 | 值 | 用途 |
|------|-----|------|
| `ParseError` | -32700 | JSON 解析失敗 |
| `InvalidRequest` | -32600 | 請求格式不合法 |
| `MethodNotFound` | -32601 | 方法不存在 |
| `InvalidParams` | -32602 | 參數不合法——**工具最常用的一個** |
| `InternalError` | -32603 | 內部錯誤 |
| `ResourceNotFound` | -32002 | 找不到資源（第 07 章） |
| `HeaderMismatch` | -32020 | HTTP header 與協定狀態不符 |
| `MissingRequiredClientCapability` | -32021 | client 未宣告必要能力（如未掛 elicitation handler） |
| `UnsupportedProtocolVersion` | -32022 | 協定版本協商失敗（第 08、10 章的 fallback 依據） |
| `UrlElicitationRequired` | -32042 | 需要 URL 模式的 elicitation（第 15 章） |

前五個是 JSON-RPC 標準碼；`-32002` 與 `-320xx` 區段是 MCP 自訂。後四個是 v2.x 隨協定演進加入的，`UnsupportedProtocolVersion` 尤其常見——HTTP stateful server 就是用它拒絕 2026-07-28 的 client，讓對方退回舊握手。

> 三個型別都在 namespace `ModelContextProtocol`、套件 `.Core`（`McpException`、`McpProtocolException`、`McpErrorCode`）。除了 `McpProtocolException` 一律 re-throw，`OperationCanceledException` 在取消權杖被觸發時也會 re-throw（讓取消正常傳播），不會變成工具錯誤結果。

**（3）client 端檢查錯誤。** 呼叫端看 `CallToolResult.IsError`（`bool?`，ns `ModelContextProtocol.Protocol`）：

```csharp
using ModelContextProtocol.Protocol;

var result = await client.CallToolAsync("divide",
    new Dictionary<string, object?> { ["a"] = 10, ["b"] = 0 });

if (result.IsError is true)
    Console.WriteLine($"工具錯誤：{result.Content.OfType<TextContentBlock>().FirstOrDefault()?.Text}");
```

### 動態工具與清單變更通知（概念）

工具清單可在執行中變動。變動後注入 `McpServer` 送出通知，client 就能刷新清單：

```csharp
using ModelContextProtocol;            // SendNotificationAsync
using ModelContextProtocol.Protocol;   // NotificationMethods

await server.SendNotificationAsync(NotificationMethods.ToolListChangedNotification);
```

> 一次要改多個工具時，別讓每筆修改各送一次通知——`McpServerPrimitiveCollection<T>.DeferChangedEvents()` 可把整批彙整成一次 `list_changed`（第 09 章）。

> ⚠️ 這種「非請求觸發」的通知需要 **stateful 模式或 stdio**；stateless server 無法主動送通知。細節見第 08 章（[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md)）與第 09 章（[notifications-progress](../mcp-csharp-sdk-kb/wiki/concepts/notifications-progress.md)）。

## 常見錯誤

- **以為 DI 服務會出現在 Schema 裡**：不會。只要型別被 DI 認得（`IServiceProviderIsService`），就當注入處理、排除於 input schema。反過來，忘了註冊某服務又把它當參數，會在呼叫時解析失敗。
- **想注入 `IMcpServer`**：沒有這個介面。注入型別是具體類別 `McpServer`。
- **用一般例外想把細節傳給模型**：非 `McpException` 的例外只會回通用訊息。要讓模型看到原因，丟 `McpException`。
- **混淆兩種例外**：`McpException` → 工具錯誤結果（`IsError=true`，Message 顯示）；`McpProtocolException` → JSON-RPC 協定錯誤。用途不同，別互換。
- **在 stateless server 送 `ToolListChangedNotification`**：送不出去。非請求觸發的通知需要 stateful/stdio。
- **回傳 `CallToolResult` 卻忘了它能帶 `IsError`**：手動組 `CallToolResult` 時，錯誤情境記得設 `IsError = true`，否則 client 會當成成功。

## 相關章節

- 第 04 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) — 工具基礎（attribute、註冊、stdio 跑起來）
- 第 03 章：[mcp-server-builder](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-builder.md) — DI 服務註冊與 server 骨架
- 第 07 章：[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md) — 另一種 primitive，注入模型與此章一致
- 第 09 章：[notifications-progress](../mcp-csharp-sdk-kb/wiki/concepts/notifications-progress.md) — 通知與進度回報
- 第 14 章：[sampling](../mcp-csharp-sdk-kb/wiki/concepts/sampling.md) — 用注入的 `McpServer` 向 client 反向請求 LLM 補全
- 第 16 章：[mef-ai-integration](../mcp-csharp-sdk-kb/wiki/concepts/mef-ai-integration.md) — 工具與 `IChatClient` 的整合

## 延伸閱讀

- 上游 sample：`samples/ProtectedMcpServer`（DI 注入 `IHttpClientFactory` + `McpException`）、`samples/EverythingServer`（`LongRunningTool`、`SampleLlmTool`）
- 官方概念文件：Tools（`raw/docs-conceptual/tools.md`）— Content types / Error handling / JSON Schema generation
