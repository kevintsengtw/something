# 第 15 章：Elicitation——工具執行中向使用者徵詢輸入

> 對應 wiki 概念：[elicitation](../mcp-csharp-sdk-kb/wiki/concepts/elicitation.md)
> 上游 API：`McpServer.ElicitAsync`、`McpClientHandlers.ElicitationHandler`（皆屬 `ModelContextProtocol.Core`）
> 引入版本：v1.0.0（2025-11-25 規格的互動式 primitive）
> 教學基準：v2.2.0（MCP 2026-07-28；保留 down-level compatibility）

## 本章目標

- 理解 elicitation：工具執行到一半，server 向**使用者**（經由 client）徵詢缺少的資訊或確認
- 用型別化的 `ElicitAsync<T>` 讓 SDK 自動生成表單 schema、自動反序列化回應
- 用協定原生的 `ElicitAsync(ElicitRequestParams)` 手寫 schema,處理 accept／decline／cancel 三種結果
- 在 client 端掛 `ElicitationHandler` 呈現表單，並沿用第 13 章方法測試整個往返

## 為什麼需要這個

第 14 章的 sampling 是 server 借 client 的「模型」；elicitation 則是 server 借 client 的「使用者」。典型情境：

- **缺參數**：訂位工具執行時發現少了人數，與其失敗，不如當場問
- **危險操作確認**：刪除、覆寫、扣款前，要使用者親口說「是」
- **多步驟流程**：依前一步的結果決定下一個要問什麼

沒有 elicitation 時，這些互動只能靠「工具回傳錯誤 → LLM 轉述 → 使用者重新下指令」繞一大圈，而且 LLM 可能自作主張補參數。elicitation 讓 server **直接**向使用者要資料——host 應用彈出表單，填完回傳，工具接著跑完。LLM 完全不在這條路徑上，這正是它與 sampling 的關鍵差異：sampling 問模型，elicitation 問人。

## 核心概念

### 訊息流與三種結局

工具執行中，server 發 `elicitation/create` 請求（同 sampling,是 server → client 方向，需要雙向傳輸）。

> ⚠️ 這條路徑的前提是 **stateful session**。2026-07-28 協定移除了 `elicitation/create` 這類 server→client 請求方法，改用 MRTR（見下方「進階用法」）；本節與「上手範例」描述的是 stateful 情境（stdio、或 HTTP 的 stateful／hybrid session）。client 把 `Message` 與表單 schema 呈現給使用者，結果回到 `ElicitResult.Action`：

| Action | 意義 | 工具該做什麼 |
|--------|------|------------|
| `"accept"` | 使用者填了表單送出 | 從 `Content` 取資料繼續 |
| `"decline"` | 使用者明確拒絕 | 走取消路徑，別重問 |
| `"cancel"` | 使用者關掉對話框（預設值） | 走取消路徑 |

`ElicitResult.IsAccepted` 是 `Action == "accept"` 的便利屬性。**永遠要處理非 accept 的分支**——使用者拒絕是正常流程，不是錯誤。

### 表單 schema：受限的 JSON Schema 子集

Elicitation 的表單只支援**平面的基本型別欄位**：字串、數字／整數、布林、字串 enum（單選／多選）。沒有巢狀物件、沒有陣列（enum 多選除外）。這是刻意的——表單要能在任何 host 裡渲染成 UI。

對應的 SDK 型別都巢狀在 `ElicitRequestParams` 裡：`RequestSchema`（外層，`Properties` + `Required`）與 `StringSchema`／`NumberSchema`／`BooleanSchema`／各式 enum schema。

### 兩層 API：型別化優先

| API | Schema 來源 | 回應形態 |
|-----|------------|---------|
| `ElicitAsync<T>(message, options?, ct)` | 由 `T` 的公開屬性自動生成 | `ElicitResult<T>`，`Content` 已反序列化為 `T` |
| `ElicitAsync(ElicitRequestParams, ct)` | 手寫 | `ElicitResult`，`Content` 是 `IDictionary<string, JsonElement>` |

型別化版本是日常首選：定義一個 POCO,SDK 讀公開屬性建 schema（不支援的成員型別會被**忽略**）、把 `[Description]` 帶進欄位說明、回應直接變回 `T`。手寫版本留給需要 enum 選項、欄位級驗證範圍等細節控制的場合。

### Client 端：handler 與 capability

與 sampling 同款設計：handler 掛在 `McpClientOptions.Handlers.ElicitationHandler`，委派型別是

```csharp
Func<ElicitRequestParams?, CancellationToken, ValueTask<ElicitResult>>
```

掛了 handler,SDK 就在握手時自動宣告 elicitation capability（未細指時預設宣告 form 模式）。server 端 `ElicitAsync` 發送前會檢查，client 沒宣告直接丟 `InvalidOperationException`。

## 上手範例

### 步驟 1：定義表單、寫工具（型別化版）

```csharp
using ModelContextProtocol.Server;
using System.ComponentModel;

public sealed class ReservationForm
{
    [Description("訂位大名")]
    public string? Name { get; set; }

    [Description("人數")]
    public int Seats { get; set; }
}

[McpServerToolType]
public sealed class ReservationTools
{
    [McpServerTool, Description("Reserves a table, asking the user for details.")]
    public static async Task<string> Reserve(
        McpServer server, CancellationToken cancellationToken)
    {
        var result = await server.ElicitAsync<ReservationForm>(
            message: "請提供訂位資訊",
            cancellationToken: cancellationToken);

        if (!result.IsAccepted || result.Content is null)
        {
            return $"使用者未提供資訊（{result.Action}），訂位取消。";
        }

        return $"已為 {result.Content.Name} 訂位 {result.Content.Seats} 人。";
    }
}
```

流程一目了然：問（`ElicitAsync<T>`）→ 判（`IsAccepted`）→ 用（強型別的 `Content`）。以預設序列化選項，`Name`／`Seats` 在協定層的欄位名是 camelCase 的 `name`／`seats`（實測確認）——client 回傳的字典鍵要對得上。

### 步驟 2：client 端掛 handler

真實的 host 應用會在 handler 裡彈 UI；骨架如下：

```csharp
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;
using System.Text.Json;

var client = await McpClient.CreateAsync(transport, new McpClientOptions
{
    Handlers = new McpClientHandlers
    {
        ElicitationHandler = async (request, cancellationToken) =>
        {
            // request.Message 給使用者看；request.RequestedSchema 決定表單欄位
            // …在這裡呈現 UI、收集輸入…

            return new ElicitResult
            {
                Action = "accept",
                Content = new Dictionary<string, JsonElement>
                {
                    ["name"] = JsonSerializer.SerializeToElement("Alice"),
                    ["seats"] = JsonSerializer.SerializeToElement(3),
                },
            };
        },
    },
});
```

`Content` 的值是 `JsonElement`——用 `JsonSerializer.SerializeToElement(...)` 最省事。使用者按下取消就回 `new ElicitResult { Action = "cancel" }`（也是 `Action` 的預設值）。

## 進階用法

### 手寫 schema：布林確認的危險操作

需要精確控制表單時，用協定原生多載。經典場景——刪除前確認：

```csharp
using ModelContextProtocol.Protocol;
using System.Text.Json;

[McpServerTool, Description("Deletes everything after a boolean confirmation.")]
public static async Task<string> DangerousCleanup(
    McpServer server, CancellationToken cancellationToken)
{
    var result = await server.ElicitAsync(new ElicitRequestParams
    {
        Message = "確定要刪除所有暫存資料嗎？",
        RequestedSchema = new ElicitRequestParams.RequestSchema
        {
            Properties =
            {
                ["confirm"] = new ElicitRequestParams.BooleanSchema
                {
                    Description = "true 表示確認刪除",
                },
            },
        },
    }, cancellationToken);

    if (result.IsAccepted
        && result.Content is { } content
        && content.TryGetValue("confirm", out var confirm)
        && confirm.ValueKind == JsonValueKind.True)
    {
        return "已刪除。";
    }

    return "已取消，未做任何事。";
}
```

注意判斷的嚴格程度：`accept` **且** 有 `confirm` 欄位 **且** 值為 `true` 才動手，其餘一律不做——對危險操作，預設要是「不做」。

### URL 模式：不讓 client 看到敏感資料

`ElicitRequestParams.Mode` 除了預設的 `"form"` 還有 `"url"`：server 給一個 URL,client 徵得使用者同意後開瀏覽器，使用者在**帶外**（out-of-band）完成互動——OAuth 授權、付款頁都是這種形態。關鍵差異：form 模式收集的資料會流經 client；url 模式的敏感資料只在使用者與目標網站之間流動。url 模式必須設定 `ElicitationId`（追蹤完成狀態用），且基於安全考量 URL 只能放在 `Url` 欄位。本章不展開，上游 `tests/.../UrlElicitationTests.cs` 有完整示範。

### Stateless 下怎麼問？多輪往返請求（MRTR）

前面的 `ElicitAsync` 有個硬前提：**server 要能主動對 client 發請求**，也就是需要 stateful session。而 2026-07-28 協定把 Streamable HTTP 的 session 拿掉了，同時從規格移除 `elicitation/create`、`sampling/createMessage`、`roots/list` 這三個 server→client 請求方法。

取而代之的是 **MRTR（multi-round-trip requests）**：工具不主動發問，而是**回傳一個「還沒做完」的結果**，說明它需要什麼；client 解決後**重試同一個 `tools/call`**，把答案帶回來。

流程是這樣：

1. client 呼叫 `tools/call`
2. 工具發現需要輸入，丟出 `InputRequiredException`，帶著 `inputRequests` 與／或 `requestState`
3. client 逐一解決（問使用者、呼叫 LLM、列出 roots）
4. client **重試原本的 `tools/call`**，帶上 `inputResponses`（用 key 對應）與原樣回送的 `requestState`
5. server 處理回應，回最終結果——或再丟一次 `InputRequiredException` 進入下一輪

#### 先檢查支援度

```csharp
public override bool IsMrtrSupported => ClientSupportsMrtr() || HasStatefulTransport();
```

`McpServer.IsMrtrSupported` 在兩種情況為 `true`：協商到 2026-07-28（原生支援），或是 2025-11-25 下的 stateful session（SDK 用 legacy JSON-RPC 解析後重試 handler）。丟 `InputRequiredException` 前**應該先檢查**：

```csharp
[McpServerTool, Description("A tool that uses MRTR")]
public static string MyTool(McpServer server, RequestContext<CallToolRequestParams> context)
{
    if (!server.IsMrtrSupported)
    {
        return "此工具需要協商 2026-07-28 的 client，或 2025-11-25 下的 stateful session。";
    }
    // ... MRTR 邏輯
}
```

#### 回傳未完成的結果

```csharp
public class InputRequiredException : Exception
{
    public InputRequiredException(InputRequiredResult result);
    public InputRequiredException(
        IDictionary<string, InputRequest>? inputRequests = null,
        string? requestState = null);   // 兩者不可皆為 null
    public InputRequiredResult Result { get; }
}
```

同一個工具方法要同時處理「第一次呼叫」與「帶著答案重試」兩條路徑——靠 `context.Params` 上的 `RequestState` 與 `InputResponses` 區分：

```csharp
using ModelContextProtocol.Protocol;

[McpServerTool, Description("Tool managing its own MRTR flow")]
public static string AnswerTool(
    McpServer server,
    RequestContext<CallToolRequestParams> context,
    [Description("The user's question")] string question)
{
    var requestState = context.Params!.RequestState;
    var inputResponses = context.Params!.InputResponses;

    // 重試回合：處理 client 送回來的答案
    if (requestState is not null && inputResponses is not null)
    {
        var elicitResult = inputResponses["user_answer"]
            .Deserialize(InputResponse.ElicitResultJsonTypeInfo);
        return $"You answered: {elicitResult?.Content?.FirstOrDefault().Value}";
    }

    if (!server.IsMrtrSupported)
    {
        return "MRTR is not supported by this client.";
    }

    // 第一回合：要求輸入
    throw new InputRequiredException(
        inputRequests: new Dictionary<string, InputRequest>
        {
            ["user_answer"] = InputRequest.ForElicitation(new ElicitRequestParams
            {
                Message = $"Please answer: {question}",
                RequestedSchema = new()
                {
                    Properties = new Dictionary<string, ElicitRequestParams.PrimitiveSchemaDefinition>
                    {
                        ["answer"] = new ElicitRequestParams.StringSchema { Description = "Your answer" },
                    },
                },
            }),
        },
        requestState: "awaiting-answer");
}
```

`InputRequest.ForElicitation` 是把 `ElicitRequestParams` 包成 `InputRequest` 的工廠；sampling 與 roots 也走同一組型別，差別在 `InputRequest.Method`。

#### 該用哪一種？

| 情境 | 用什麼 |
|------|--------|
| stdio（永遠 stateful） | `ElicitAsync` 或 MRTR 皆可 |
| HTTP + `SessionMode = Stateful` | `ElicitAsync`；該模式會以 `UnsupportedProtocolVersion` 拒絕 2026-07-28 |
| HTTP + stateless | **只能 MRTR**；`ElicitAsync` 會拋 `InvalidOperationException` |
| HTTP + `StatefulForInitializeClients`（hybrid） | 2026-07-28 client 走 stateless 因而支援 MRTR；`initialize` 握手的舊 client 仍拿到 session |

要在 2026-07-28 的 Streamable HTTP server 上運作的程式碼，**一律用 `InputRequiredException`**。legacy 的 `ElicitAsync` / `SampleAsync` / `RequestRootsAsync` 在 stateful session（含 2026-07-28 的 stdio）仍可用，但在任何 stateless session 上都會丟 `InvalidOperationException("X is not supported in stateless mode.")`。

> 不需要任何 experimental 旗標；把 `McpClientOptions.ProtocolVersion` 釘在 initialize 世代的版本就等於退出 MRTR。session 模式的完整對照見第 08 與第 12 章。

### 測試 elicitation（第 13 章方法）

假 handler 就是「機器人使用者」，accept／decline 兩條路都能測（以下實測通過）：

```csharp
public class ElicitationTests : McpServerTestBase
{
    protected override void ConfigureServices(
        ServiceCollection services, IMcpServerBuilder builder)
    {
        builder.WithTools<ReservationTools>();
    }

    [Fact]
    public async Task 使用者接受_工具取得強型別內容()
    {
        await using var client = await CreateClientAsync(new McpClientOptions
        {
            Handlers = new McpClientHandlers
            {
                ElicitationHandler = (request, ct) => ValueTask.FromResult(new ElicitResult
                {
                    Action = "accept",
                    Content = new Dictionary<string, JsonElement>
                    {
                        ["name"] = JsonSerializer.SerializeToElement("Alice"),
                        ["seats"] = JsonSerializer.SerializeToElement(3),
                    },
                }),
            },
        });

        var result = await client.CallToolAsync("reserve");

        var text = Assert.IsType<TextContentBlock>(result.Content[0]);
        Assert.Equal("已為 Alice 訂位 3 人。", text.Text);
    }

    [Fact]
    public async Task 使用者拒絕_工具走取消路徑()
    {
        await using var client = await CreateClientAsync(new McpClientOptions
        {
            Handlers = new McpClientHandlers
            {
                ElicitationHandler = (request, ct) =>
                    ValueTask.FromResult(new ElicitResult { Action = "decline" }),
            },
        });

        var result = await client.CallToolAsync("reserve");

        var text = Assert.IsType<TextContentBlock>(result.Content[0]);
        Assert.Contains("訂位取消", text.Text);
    }
}
```

## 常見錯誤

**1. 只處理 accept,沒處理 decline／cancel**

`ElicitResult.Action` 的預設值就是 `"cancel"`——使用者關掉對話框是最常見的結局之一。工具必須把「沒拿到資料」當正常分支，回一個有意義的訊息，而不是 `NullReferenceException`。

**2. client 回傳的欄位名大小寫對不上**

型別化模式下，協定層欄位名依序列化選項生成（預設 camelCase：`Name` → `name`）。client handler 回傳的字典鍵拼錯或大小寫不符，server 端反序列化會拿到預設值而不是報錯——這種靜默失敗要靠測試抓。

**3. 在表單型別裡放巢狀物件或集合**

`ElicitAsync<T>` 只支援基本型別成員，**不支援的成員會被忽略**（不會丟例外）——表單看起來少欄位，就是這個原因。需要複雜結構時，拆成多輪 elicitation 或改用工具參數。

**4. client 沒掛 handler**

與 sampling 同款：server 端 `ElicitAsync` 丟 `InvalidOperationException`，工具結果 `IsError = true`（實測）。加分項寫法是先看 `server.ClientCapabilities?.Elicitation` 再決定要不要問。

**5. 在 stateless HTTP 上呼叫 `ElicitAsync`**

會丟 `InvalidOperationException("... is not supported in stateless mode.")`。2026-07-28 的 Streamable HTTP 沒有 session，要問使用者只能走 MRTR（丟 `InputRequiredException`）。先看 `server.IsMrtrSupported` 決定走哪條路。

**6. 把 elicitation 當成參數的替代品**

能在工具參數裡宣告的，就讓 LLM／使用者在呼叫時給——那有 schema 驗證、有補全（第 6 章）。elicitation 是給「執行中才知道要問」與「需要人親自確認」的場合，不是逃避設計參數的後門。

## 相關章節

- [第 5 章：工具進階](./05-mcp-server-tools-advanced.md)——`McpServer` 注入
- [第 12 章：ASP.NET Core 託管 MCP Server](./12-aspnetcore-hosting.md)——session 模式決定走 `ElicitAsync` 還是 MRTR
- [第 13 章：測試策略](./13-testing-strategy.md)——假 handler 測試法的出處
- [第 14 章：Sampling](./14-sampling.md)——同為 server→client 請求，問模型 vs 問人的對照

## 延伸閱讀

- 上游 `tests/ModelContextProtocol.Tests/Protocol/ElicitationTypedTests.cs`——型別化 elicitation 的官方測試（含 enum、預設值、AOT source-gen 場景）
- 上游 `tests/ModelContextProtocol.Tests/Protocol/UrlElicitationTests.cs`——URL 模式
- wiki 條目：[elicitation](../mcp-csharp-sdk-kb/wiki/concepts/elicitation.md)、[sampling](../mcp-csharp-sdk-kb/wiki/concepts/sampling.md)
