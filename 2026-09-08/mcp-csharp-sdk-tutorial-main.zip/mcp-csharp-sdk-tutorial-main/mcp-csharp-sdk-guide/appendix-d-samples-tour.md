# 附錄 D：官方 Samples 導覽

> 本附錄導覽上游 `csharp-sdk/samples/` 的 13 個官方範例，說明每個範例示範什麼、對應本教學哪一章，
> 以及哪些是「照著跑就懂」、哪些要先讀完對應章節。
> 基準：SDK **v2.2.0**（commit `6fa3825`）｜ 最後更新：2026-09-04

---

## 怎麼用這份導覽

官方範例是可執行的，跟教學章節互補——章節解釋「為什麼這樣寫」，範例給你「完整跑得起來的一份」。建議路徑是：**讀章節 → 跑對應範例 → 回頭改範例**。

先把上游 clone 下來（教學的 `csharp-sdk/` 就是它）：

```bash
git clone https://github.com/modelcontextprotocol/csharp-sdk.git
cd csharp-sdk
git checkout v2.2.0          # 對齊本教學基準
```

---

## 全部範例一覽

| 範例 | 示範什麼 | TFM | 對應章節 |
|------|---------|-----|---------|
| `QuickstartWeatherServer` | 最小 stdio server（天氣工具） | net8.0 | 03、04 |
| `QuickstartClient` | 最小 client，連 stdio server 呼叫工具 | net8.0 | 10 |
| `EverythingServer` | 綜合 server：tools + prompts + resources | net9.0 | 05、06、07 |
| `FileBasedMcpServer` | 單檔 server（.NET 10 file-based program） | .NET 10 file-based（無 csproj／TFM） | 03 |
| `AspNetCoreMcpServer` | HTTP server + OpenTelemetry／Application Insights | net9.0 | 08、12 |
| `AspNetCoreMcpPerSessionTools` | per-session 動態工具（明確選 Stateful） | net9.0 | 08、12 |
| `TestServerWithHosting` | Generic Host 託管，並開 `PublishAot` | `$(DefaultTestTargetFrameworks)`＝net10.0/net9.0/net8.0（Windows 另含 net472） | 03、13、20 |
| `InMemoryTransport` | 同行程 client↔server，不開行程不走網路 | net8.0 | 13 |
| `ChatWithTools` | MCP 工具餵給 `IChatClient` 做 function calling | net8.0 | 16 |
| `TasksExtension` | Tasks extension 端對端（背景 task + 輪詢） | net8.0 | 17 |
| `WeatherAppServer` | MCP Apps extension，互動式 UI | net10.0 | 21 |
| `ProtectedMcpServer` | OAuth 2.0 保護的 server | net9.0 | 18 |
| `ProtectedMcpClient` | 連線受保護 server 的 client（OAuth flow） | net9.0 | 18 |

> 13 支裡有 8 支附 README（`AspNetCoreMcpServer`、`AspNetCoreMcpPerSessionTools`、`FileBasedMcpServer`、`InMemoryTransport`、`ProtectedMcpServer`、`ProtectedMcpClient`、`TasksExtension`、`WeatherAppServer`）。其餘直接讀 `Program.cs` 即可，程式碼都很短。

---

## 入門三支

### `QuickstartWeatherServer` + `QuickstartClient`

官方 quickstart 的兩半，配成一對讀最有效：server 用 `AddMcpServer` + `WithStdioServerTransport` + `WithToolsFromAssembly` 註冊 `[McpServerTool]` 方法，client 用 `McpClient.CreateAsync` + `StdioClientTransport` 連上去 `ListToolsAsync` / `CallToolAsync`。

對應第 03、04、10 章。這是理解 stdio「client 啟動 server 子行程」模型最快的路。

### `EverythingServer`

三種 primitive 一次到齊——`[McpServerTool]`、`[McpServerPrompt]`、`[McpServerResource]`，還包含 completion handler。第 05～07 章的範例多數可在這裡找到完整脈絡。

### `FileBasedMcpServer`

**.NET 10 的 file-based program**：沒有 `.csproj`，靠檔案開頭的指示詞宣告相依：

```csharp
#!/usr/bin/env dotnet
#:package Microsoft.Extensions.Hosting
#:project ../../src/ModelContextProtocol/ModelContextProtocol.csproj
```

直接 `dotnet run Program.cs` 就跑得起來。適合做最小重現、或把一個 MCP server 當腳本散布。需要 .NET 10 SDK。

---

## 傳輸與託管

### `AspNetCoreMcpServer` — 兼顧 HTTP 託管與可觀測性

這支是第 12 章的託管範例，同時示範可觀測性佈線（第 12 章有相關說明；第 19 章講的是 Docker 部署，不涉及 OpenTelemetry）。它把 OpenTelemetry 接上 MCP 操作、ASP.NET Core 請求、對外 HTTP 請求、metrics 與結構化日誌。

**匯出到 Application Insights**——設好連線字串再跑即可：

```bash
export APPLICATIONINSIGHTS_CONNECTION_STRING='InstrumentationKey=<key>;IngestionEndpoint=https://<region>.in.applicationinsights.azure.com/'
dotnet run --project samples/AspNetCoreMcpServer
```

切換邏輯很單純（`Program.cs`）：連線字串有值就 `telemetry.UseAzureMonitor(...)`，沒值就維持預設的 `telemetry.UseOtlpExporter()`，後者用標準的 `OTEL_EXPORTER_OTLP_*` 環境變數設定。連線字串走 ASP.NET Core 組態讀取——**別進版控**，正式環境用部署平台的祕密管理。

**以下訊號映射與查詢取自上游 `samples/AspNetCoreMcpServer/README.md`，本教學未實際連線 Azure 驗證資料落地。** 上游 README 描述的預期映射是：

| MCP 端 | Application Insights |
|--------|---------------------|
| server activity | requests |
| client activity | dependencies |
| 結構化日誌 | traces |
| MCP histogram | custom metrics |

MCP activity 可能帶這些屬性：`mcp.method.name`、`mcp.protocol.version`、`mcp.session.id`、`jsonrpc.request.id`、`gen_ai.tool.name`——實際有哪些取決於操作類型，以及是否啟用敏感資料遙測。查詢範例：

```kusto
union withsource=TelemetryType requests, dependencies
| extend McpMethod = tostring(customDimensions["mcp.method.name"]),
         ToolName = tostring(customDimensions["gen_ai.tool.name"]),
         McpSession = tostring(customDimensions["mcp.session.id"])
| where isnotempty(McpMethod)
| project timestamp, TelemetryType, name, success, resultCode, McpMethod, ToolName, McpSession
| order by timestamp desc
```

> ⚠️ **這支範例只匯出既有遙測，不新增自訂協定事件或 per-tool instrumentation。** 非法工具呼叫、格式錯誤的 JSON-RPC 訊息這類失敗，只有在目前 SDK 或 ASP.NET Core instrumentation 有為該路徑發出日誌／activity 時才看得到。想要更細的追蹤得自己加。

### `AspNetCoreMcpPerSessionTools`

per-session 動態工具——不同 session 看到不同工具清單。v2 預設 stateless，所以這支**明確選用** `HttpServerSessionMode.Stateful` 才留得住 session-scoped 行為。第 08 章 session 模式那張表的實例。

### `TestServerWithHosting`

用 Generic Host（`Host.CreateApplicationBuilder`）託管 server，多目標建置並在 net9.0 開 `PublishAot`——第 20 章 Native AOT 的實際設定可以參考它的 `.csproj`。TFM 來自 `Directory.Build.props` 的 `$(DefaultTestTargetFrameworks)`，在 Windows 上會額外加入 `net472`。

---

## 測試：`InMemoryTransport`

第 13 章測試策略的骨幹範例，也是**最值得先跑的一支**——它把 client 與 server 放進同一個行程，不開子行程、不走網路：

```csharp
using System.IO.Pipelines;

Pipe clientToServerPipe = new(), serverToClientPipe = new();

// server：直接 McpServer.Create，不需要 host 或 DI 容器
await using McpServer server = McpServer.Create(
    new StreamServerTransport(clientToServerPipe.Reader.AsStream(), serverToClientPipe.Writer.AsStream()),
    new McpServerOptions
    {
        ToolCollection = [McpServerTool.Create((string arg) => $"Echo: {arg}", new() { Name = "Echo" })],
    });
_ = server.RunAsync();          // 同行程，刻意 fire-and-forget

// client：接到同一對 pipe 的另一端
await using McpClient client = await McpClient.CreateAsync(
    new StreamClientTransport(clientToServerPipe.Writer.AsStream(), serverToClientPipe.Reader.AsStream()));

var tools = await client.ListToolsAsync();
var echo = tools.First(t => t.Name == "Echo");
Console.WriteLine(await echo.InvokeAsync(new() { ["arg"] = "Hello World" }));
```

三個關鍵：

- **兩條 pipe，一個方向一條**。client 的輸出串流就是 server 的輸入串流，反之亦然——接反了會直接卡住。
- **`StreamServerTransport` / `StreamClientTransport` 吃任何 `Stream`**，不限於 `System.IO.Pipelines`。這裡用 `Pipe` 只是最省事的記憶體內管線。
- **`server.RunAsync()` 是 fire-and-forget**，因為兩端都在同一行程；靠 `await using` 確保程式結束時兩者都被 dispose。

除了測試，這個模式也適合**把 server 嵌進更大的應用程式**，或在同行程內跑 client/server 而不想付傳輸成本。

---

## 進階主題

### `ChatWithTools`

把 `McpClientTool`（`: AIFunction`）直接放進 `Microsoft.Extensions.AI` 的 `ChatOptions.Tools`，讓 `IChatClient` 做 function calling。第 16 章的完整可跑版本。需要 LLM API key。

### `TasksExtension`

Tasks extension（SEP-2663）的端對端示範，用 in-memory transport 跑背景 task 與輪詢：`WithTasks`、`IMcpTaskStore`、`CallToolAsTaskAsync`、`GetTaskAsync`。第 17 章對應。

> 它取代了 v1.4.1 時代的 `LongRunningTasks` 範例——Tasks 在 v2.0.0 被拆成獨立的 `ModelContextProtocol.Extensions.Tasks` 套件。看舊教材時注意這個斷點。

### `WeatherAppServer`

MCP Apps extension 範例，提供互動式天氣 UI 與 structured content：`[McpAppUi]`、`WithMcpApps`、`McpServerResource`。對應第 21 章。**目標框架是 net10.0**，比其他範例高。

### `ProtectedMcpServer` + `ProtectedMcpClient`

OAuth 2.0 的兩半：server 用 `McpAuthenticationExtensions` / `McpAuthenticationOptions`（`.AspNetCore.Authentication`），client 走完整 OAuth flow。第 18 章對應。這對要一起跑才有意義。

---

## conceptual docs 裡的另一組範例

`samples/` 之外，上游 `docs/concepts/` 底下還有四組聚焦單一主題的小範例：

| 路徑 | 主題 | 章節 |
|------|------|------|
| `docs/concepts/progress/samples/` | 進度回報（含完整 client） | 09 |
| `docs/concepts/logging/samples/` | 日誌轉送 | 09 |
| `docs/concepts/elicitation/samples/` | Elicitation | 15 |
| `docs/concepts/httpcontext/samples/` | 在工具內取用 `HttpContext` | 12 |

這幾組比 `samples/` 的更小、更聚焦，適合只想看某個 API 怎麼用的時候。

---

## v2.x 的範例變動

跨版本讀舊資料時要注意這幾個斷點：

- **v2.0.0**：`TasksExtension` 取代 `LongRunningTasks`；新增 `WeatherAppServer`（MCP Apps）；`AspNetCoreMcpPerSessionTools` 因應預設改 stateless 而明確設定 session 模式。
- **v2.1.0**：`AspNetCoreMcpServer` 加入 Application Insights 匯出；`InMemoryTransport` 補上 README。
- **v2.2.0**：`AspNetCoreMcpServer`、`AspNetCoreMcpPerSessionTools`、`EverythingServer`、`ProtectedMcpServer` 改用 `HttpServerTransportOptions.SessionMode` + `HttpServerSessionMode`，取代原本只用 `Stateless` 布林值的寫法。

---

## 相關章節

- [第 03 章](./03-mcp-server-builder.md)、[第 04 章](./04-mcp-server-tools.md)——quickstart 兩支的對應
- [第 08 章](./08-transports-and-sessions.md)、[第 12 章](./12-aspnetcore-hosting.md)——session 模式與 HTTP 託管
- [第 13 章](./13-testing-strategy.md)——`InMemoryTransport` 的方法論
- [第 16 章](./16-llm-integration.md)——`ChatWithTools`
- [第 17 章](./17-tasks.md)——`TasksExtension`
- [第 18 章](./18-authorization-and-security.md)——`Protected*` 兩支
- [第 12 章](./12-aspnetcore-hosting.md)——`AspNetCoreMcpServer` 的託管與可觀測性佈線
- [第 19 章](./19-docker-deployment.md)——容器化部署（不涉及本附錄的遙測段落）
- [第 21 章](./21-mcp-apps.md)——`WeatherAppServer`

## 延伸閱讀

- 上游範例索引：`csharp-sdk/samples/`
- 素材摘要：`mcp-csharp-sdk-kb/raw/samples/README.md`（由 `sync-upstream` 維護）
