# 第 02 章：SDK 套件選擇與安裝

> 對應 wiki 概念：[nuget-packages](../mcp-csharp-sdk-kb/wiki/concepts/nuget-packages.md)
> 上游 API：N/A（套件清單）
> 基準版本：v2.2.0

## 本章目標

讀完本章，你可以：

- 說出 MCP C# SDK 三個核心／hosting 套件與兩個 extension 套件的分工
- 知道套件之間的依賴關係（裝上層會自動帶下層）
- 用 `dotnet add package` 完成安裝，並確認目標框架（TFM）相容
- 避免一個常見誤解：以為有獨立的 `ModelContextProtocol.Authentication` 套件

## 為什麼需要這個

MCP C# SDK 不是單一套件。三個核心／hosting 套件依「依賴最小化」分層，Tasks 與 MCP Apps 則各自放在 extension 套件。選錯套件不會讓你寫不出功能，但可能多背一堆用不到的依賴。花兩分鐘搞懂分工，後面每一章的 `using` 與 `dotnet add package` 都會順。

## 核心概念

### 五個可發佈套件與分工

| 套件 | 適用情境 | 主要內容 |
|------|---------|---------|
| **ModelContextProtocol.Core** | 只需 client 或 low-level server API、想要最少依賴 | 絕大多數型別：`McpClient`、`McpServer`、所有 primitive 型別與 attribute（`McpServerTool` 等）、`ModelContextProtocol.Protocol` 協定型別、`ModelContextProtocol.Authentication`（client/共用驗證）|
| **ModelContextProtocol** | client 或 stdio server，要 hosting + DI + attribute 探索（**多數專案起點**）| `AddMcpServer`、`WithStdioServerTransport`、`WithTools` / `WithToolsFromAssembly` 等 DI/builder 擴充方法 |
| **ModelContextProtocol.AspNetCore** | 以 ASP.NET Core 託管的 HTTP server | `WithHttpTransport`、`MapMcp`、`ModelContextProtocol.AspNetCore.Authentication`（server 端 OAuth handler）|
| **ModelContextProtocol.Extensions.Tasks** | 使用 v2 Tasks extension | `WithTasks`、task store、client task lifecycle 與 protocol 型別 |
| **ModelContextProtocol.Extensions.Apps** | 使用 MCP Apps extension | Apps metadata、UI resource 與相關 builder API；功能教學見[第 21 章](./21-mcp-apps.md) |

> 還有一個 `ModelContextProtocol.Analyzers`（編譯期 Roslyn analyzers / source generators），通常隨上述套件自動帶入，不需手動引用。

### 依賴關係（裝上層自動帶下層）

依賴鏈取自上游各 `.csproj` 的 `ProjectReference`：

```text
ModelContextProtocol.AspNetCore
        └─ 參考 ModelContextProtocol
                    └─ 參考 ModelContextProtocol.Core
                                └─ 參考 Microsoft.Extensions.AI.Abstractions（外部）等

ModelContextProtocol.Extensions.Tasks ── 參考 ModelContextProtocol
ModelContextProtocol.Extensions.Apps  ── 參考 ModelContextProtocol
```

因此：

- 裝 `ModelContextProtocol` → 自動含 `.Core`
- 裝 `ModelContextProtocol.AspNetCore` → 自動含 `ModelContextProtocol` 與 `.Core`
- Tasks 或 Apps 功能 → 額外安裝對應 `ModelContextProtocol.Extensions.*`
- 只裝 `.Core` → 最精簡，但沒有 `AddMcpServer` 那層 DI/hosting 糖

### ⚠️ 沒有獨立的 Authentication 套件

很多人（包括早期規劃）會以為有一個 `ModelContextProtocol.Authentication` NuGet 套件——**沒有**。驗證相關型別分布在：

- **`.Core`** → namespace `ModelContextProtocol.Authentication`（client 端 / 共用，如 `ClientOAuthProvider`、`IdentityAssertionGrantProvider`）
- **`.AspNetCore`** → namespace `ModelContextProtocol.AspNetCore.Authentication`（server 端 handler，如 `McpAuthenticationHandler`）

也就是說：**namespace 帶 `Authentication` 字樣 ≠ 有同名套件**。第 18 章（[authorization](../mcp-csharp-sdk-kb/wiki/concepts/authorization.md)）會詳談。

## 上手範例

### 用 CLI 安裝

```bash
# 多數情境：stdio server 或 client（含 DI/hosting）
dotnet add package ModelContextProtocol --version 2.2.0

# HTTP server（ASP.NET Core 託管）
dotnet add package ModelContextProtocol.AspNetCore --version 2.2.0

# 最小依賴：只寫 client 或 low-level server
dotnet add package ModelContextProtocol.Core --version 2.2.0

# 選用 extension
dotnet add package ModelContextProtocol.Extensions.Tasks --version 2.2.0
dotnet add package ModelContextProtocol.Extensions.Apps --version 2.2.0
```

> 釘住 `--version 2.2.0` 是為了與本教學完全可重現；拿掉版本參數即安裝最新版（屆時請搭配 drift 檢查確認範例仍適用）。

### 在 .csproj 中宣告

```xml
<ItemGroup>
  <!-- 版本號以實際發佈為準，本教學基準 v2.2.0 -->
  <PackageReference Include="ModelContextProtocol" Version="2.1.0" />
</ItemGroup>
```

### 怎麼選？一個簡單決策

```text
要不要用 HTTP（ASP.NET Core）託管 server？
├─ 要 ───────────────► ModelContextProtocol.AspNetCore
└─ 不要
     └─ 需要 attribute 工具探索 / DI / hosting（stdio server 或一般 client）？
          ├─ 需要 ─────► ModelContextProtocol      ← 多數人選這個
          └─ 只要最精簡的 client / low-level server ► ModelContextProtocol.Core
```

## 進階用法

### 目標框架（TFM）相容性

各套件支援的 TFM（取自上游 `.csproj`）：

| 套件 | 支援 TFM |
|------|---------|
| `ModelContextProtocol.Core` | net10.0 / net9.0 / net8.0 / netstandard2.0 |
| `ModelContextProtocol` | net10.0 / net9.0 / net8.0 / netstandard2.0 |
| `ModelContextProtocol.AspNetCore` | net10.0 / net9.0 / net8.0 |
| `ModelContextProtocol.Extensions.Tasks` | net10.0 / net9.0 / net8.0 / netstandard2.0 |
| `ModelContextProtocol.Extensions.Apps` | net10.0 / net9.0 / net8.0 / netstandard2.0 |

SDK 支援到 .NET 8.0（`.Core` 與 `ModelContextProtocol` 甚至支援 `netstandard2.0`）。本教學的範例以 **.NET 9.0+** 撰寫與執行。

### 與 Microsoft.Extensions.AI 的關係

`.Core` 依賴 `Microsoft.Extensions.AI.Abstractions`，所以像 `IChatClient`、`AIFunction` 這些抽象型別會隨 SDK 一起進到你的專案。但要真正接上某個 LLM（OpenAI / Azure / Anthropic），你還需要對應的 `Microsoft.Extensions.AI.*` 實作套件——那是**獨立的外部套件**，不在 MCP SDK 範圍。詳見第 16 章（[mef-ai-integration](../mcp-csharp-sdk-kb/wiki/concepts/mef-ai-integration.md)）。

## 常見錯誤

- **找不到 `ModelContextProtocol.Authentication` 套件**：因為它不存在。auth 型別在 `.Core` 與 `.AspNetCore` 內（見上）。
- **只裝 `.Core` 卻想用 `AddMcpServer`**：`AddMcpServer` / `WithStdioServerTransport` 在 `ModelContextProtocol` 套件，不在 `.Core`。改裝 `ModelContextProtocol`。
- **重複安裝下層套件**：裝了 `ModelContextProtocol.AspNetCore` 又手動加 `.Core`——多餘，依賴鏈已自動帶入（不會出錯，但沒必要）。
- **TFM 不相容**：把 `.AspNetCore` 用在 `netstandard2.0` 專案會失敗（它只支援 net8.0+）。

## 相關章節

- 第 01 章：[what-is-mcp](../mcp-csharp-sdk-kb/wiki/concepts/what-is-mcp.md) — 協定全貌
- 第 03 章：[mcp-server-builder](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-builder.md) — 用 `ModelContextProtocol` 套件建第一個 server
- 第 12 章：[aspnetcore-hosting](../mcp-csharp-sdk-kb/wiki/concepts/aspnetcore-hosting.md) — 用 `.AspNetCore` 套件託管 HTTP server
- 第 18 章：[authorization](../mcp-csharp-sdk-kb/wiki/concepts/authorization.md) — auth 型別實際落在哪個套件

## 延伸閱讀

- [Getting Started（官方）](https://csharp.sdk.modelcontextprotocol.io/concepts/getting-started.html)
- [NuGet：ModelContextProtocol](https://www.nuget.org/packages/ModelContextProtocol)
- [附錄 A：NuGet 套件清單與版本記錄](./appendix-a-nuget-packages.md)
