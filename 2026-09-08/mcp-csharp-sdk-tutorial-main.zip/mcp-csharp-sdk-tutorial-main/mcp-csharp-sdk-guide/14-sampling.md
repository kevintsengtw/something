# 第 14 章：Sampling——伺服器借用客戶端的 LLM

> 對應 wiki 概念：[sampling](../mcp-csharp-sdk-kb/wiki/concepts/sampling.md)
> 上游 API：`McpServer.SampleAsync`、`McpClientHandlers.SamplingHandler`、`CreateSamplingHandler`（皆屬 `ModelContextProtocol.Core`）
> 引入版本：v1.0.0
> 教學基準：v2.2.0

## 本章目標

- 理解 sampling 的**反向請求**流程：server 在處理工具呼叫的途中，反過來請 client 的 LLM 生成內容
- 在工具方法內注入 `McpServer`，用 `SampleAsync` 發出補全請求
- 在 client 端掛上 `SamplingHandler`——手寫或用 `CreateSamplingHandler` 把 `IChatClient` 包成 handler
- 辨識 legacy `AsSamplingChatClient()` 的 MCP9005 警告，不把它當作新專案主線
- 沿用第 13 章的 in-memory 測試法，用**假 LLM** 驗證 sampling 流程

## 為什麼需要這個

到目前為止的訊息流都是單向的：client 發請求、server 回應。但有些工具的工作本身需要語言模型——「幫我摘要這份文件」「把查到的資料改寫成報告」。讓 server 自帶模型有兩個問題：

1. **成本與金鑰管理**：每個 MCP server 都要自備 API key、自付推論費用
2. **模型選擇權**：使用者在 host 應用（IDE、聊天介面）裡已經選好了模型與供應商，server 硬塞另一個模型反而突兀

MCP 的解法是 **sampling**：server 不自帶模型，而是向 client 發 `sampling/createMessage` 請求，請「持有 LLM 的那一端」代為推論。host 應用因此保有完整控制權——它可以在轉送前審核 prompt、限制 token、甚至先徵求使用者同意（human-in-the-loop）。

一句話總結角色分工：**server 出 prompt，client 出模型**。

## 核心概念

### 訊息流：一次工具呼叫，兩層請求

```text
client                         server
  │  tools/call "summarize"      │
  ├─────────────────────────────▶│ 工具方法開始執行
  │                              │
  │  sampling/createMessage      │
  │◀─────────────────────────────┤ server.SampleAsync(...)
  │ SamplingHandler → 呼叫 LLM    │
  ├─────────────────────────────▶│ CreateMessageResult
  │                              │ 工具方法繼續、組回傳值
  │  tools/call 結果              │
  │◀─────────────────────────────┤
```

注意方向：`sampling/createMessage` 是 **server → client** 的請求。這依賴雙向傳輸——stdio 與 Streamable HTTP（stateful）都支援；第 12 章的 `SessionMode = HttpServerSessionMode.Stateless` 路徑則不支援 sampling，這正是那章「stateless 犧牲清單」的第一項。Hybrid 的 2026-07-28 路徑同樣是 stateless，只有 initialize client 那一半有 session。

### Capability 協商：掛了 handler 才算數

Client 在 `McpClientOptions.Handlers` 設定 `SamplingHandler` 後，SDK 會在初始化握手時**自動**宣告 sampling capability,不需要手動設定 `Capabilities`。Server 端的 `SampleAsync` 在發送前會檢查 client 宣告——沒宣告就直接丟 `InvalidOperationException`，不會白跑一趟網路。

Handler 的委派型別（`McpClientHandlers.SamplingHandler`）：

```csharp
Func<CreateMessageRequestParams?, IProgress<ProgressNotificationValue>,
     CancellationToken, ValueTask<CreateMessageResult>>
```

三個輸入分別是：sampling 請求參數、進度回報器（第 9 章的機制，推論慢時可回報進度）、取消權杖。

### Server 端的兩種 API 形態

`McpServer.SampleAsync` 有兩個多載（皆經圖譜驗證）：

| 多載 | 輸入 | 回傳 | 適合 |
|------|------|------|------|
| 協定原生 | `CreateMessageRequestParams` | `Task<CreateMessageResult>` | 需要完整控制協定欄位時 |
| M.E.AI 風格 | `IEnumerable<ChatMessage>, ChatOptions?` | `Task<ChatResponse>` | 已習慣 Microsoft.Extensions.AI 的程式碼 |

第二種多載會自動翻譯：`ChatRole.System` 訊息併入 `SystemPrompt`、`ChatOptions.ModelId` 變成 `ModelPreferences` 的 hint、`MaxOutputTokens` 對應 `MaxTokens`。v2 仍保留 `AsSamplingChatClient()` 作 down-level compatibility，但它已標記 MCP9005 obsolete；新程式以 `SampleAsync` 或明確的 handler 佈線為主。

## 上手範例

### 步驟 1：server 端——會「借模型」的摘要工具

沿用第 5 章的 `McpServer` 參數注入：

```csharp
using Microsoft.Extensions.AI;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerToolType]
public sealed class SummarizeTools
{
    [McpServerTool, Description("Summarizes the given text via the client's LLM.")]
    public static async Task<string> Summarize(
        McpServer server,                     // DI 注入當前 session 的 server
        [Description("The text to summarize.")] string text,
        CancellationToken cancellationToken)
    {
        var result = await server.SampleAsync(new CreateMessageRequestParams
        {
            Messages = [new SamplingMessage
            {
                Role = Role.User,
                Content = [new TextContentBlock { Text = $"請將以下文字摘要成一句話：\n{text}" }],
            }],
            SystemPrompt = "You are a concise summarizer.",
            MaxTokens = 100,
            Temperature = 0.3f,
        }, cancellationToken: cancellationToken);

        return result.Content.OfType<TextContentBlock>().FirstOrDefault()?.Text
            ?? "(no text returned)";
    }
}
```

`CreateMessageRequestParams` 常用欄位（對照官方 `SampleLlmTool` sample）：

| 欄位 | 意義 |
|------|------|
| `Messages` | `SamplingMessage` 清單，每則有 `Role`（User/Assistant）與 `Content` 區塊 |
| `SystemPrompt` | 系統提示（client 端可能覆寫或忽略，是**建議**不是命令） |
| `MaxTokens` / `Temperature` / `StopSequences` | 推論參數建議 |
| `ModelPreferences` | 模型偏好 hint（如模型名），同樣僅供 client 參考 |
| `IncludeContext` | 請 client 附上 MCP 情境（`None`/`ThisServer`/`AllServers`）——client 未宣告對應 capability 時應保守用 `None` |

注意這些欄位的語意都是「**建議**」：最終用什麼模型、真的給多少 token,決定權在 client。

### 步驟 2：client 端——把 IChatClient 掛成 handler

Client 這邊唯一要做的，是把手上的 LLM（任何 `IChatClient`，來自 Microsoft.Extensions.AI 生態）包成 handler。官方 `samples/ChatWithTools` 的佈線如下（節錄改寫）：

```csharp
using Microsoft.Extensions.AI;
using ModelContextProtocol;          // CreateSamplingHandler（AIContentExtensions）
using ModelContextProtocol.Client;

IChatClient chatClient = /* 你的 LLM client，如 openAIClient.AsIChatClient() */;

var client = await McpClient.CreateAsync(transport, new McpClientOptions
{
    Handlers = new McpClientHandlers
    {
        SamplingHandler = chatClient.CreateSamplingHandler(),
    },
});
```

兩個容易踩的點：

- `CreateSamplingHandler` 是 `AIContentExtensions` 的擴充方法，住在**根 namespace `ModelContextProtocol`**——漏了這行 using 會得到 CS1061
- handler 掛在 **`McpClientOptions.Handlers`**,不是 `Capabilities`。capability 宣告由 SDK 自動處理（部分舊範例把 handler 寫在 `SamplingCapability` 上，v1.4.0 的 `SamplingCapability` 只剩 `Context`/`Tools` 兩個子 capability 屬性，沒有 `SamplingHandler`）

之後 client 每收到一次 `sampling/createMessage`,SDK 就呼叫一次你的 `IChatClient`，並把 `ChatResponse` 翻譯回協定格式。

## 進階用法

### Legacy：`AsSamplingChatClient` 的 down-level 相容寫法

既有程式若已經以 `IChatClient` 抽象寫成，v2 仍可暫時把 server 包成 chat client。不過此 API 已標記 MCP9005 obsolete；下列只供遷移期間辨識，不是新專案建議路徑：

```csharp
[McpServerTool, Description("Summarizes via IChatClient abstraction.")]
public static async Task<string> SummarizeViaChatClient(
    McpServer server,
    [Description("The text to summarize.")] string text,
    CancellationToken cancellationToken)
{
#pragma warning disable MCP9005 // legacy compatibility only
    IChatClient chatClient = server.AsSamplingChatClient();
#pragma warning restore MCP9005
    var response = await chatClient.GetResponseAsync(
        [new ChatMessage(ChatRole.User, $"Summarize: {text}")],
        new ChatOptions { MaxOutputTokens = 100 },
        cancellationToken);
    return response.Text;
}
```

呼叫鏈變成：工具 → `IChatClient` → sampling 請求 → client 的 `IChatClient` → 真正的 LLM。`AsSamplingChatClient()` 同樣會先檢查 client capability，不支援時丟 `InvalidOperationException`。規劃新程式時，優先讓實際呼叫點直接使用 `SampleAsync`，避免把 legacy adapter 擴散到更多程式碼。

### 用假 LLM 測試 sampling（第 13 章方法的延伸）

sampling 流程「server 請求、client 回應」的雙向特性，正好用第 13 章的 in-memory 基底驗證——把 `SamplingHandler` 換成寫死回應的假 LLM,不花一毛推論費：

```csharp
public class SamplingTests : McpServerTestBase
{
    protected override void ConfigureServices(
        ServiceCollection services, IMcpServerBuilder builder)
    {
        builder.WithTools<SummarizeTools>();
    }

    private Task<McpClient> CreateClientWithFakeLlmAsync()
        => CreateClientAsync(new McpClientOptions
        {
            Handlers = new McpClientHandlers
            {
                SamplingHandler = (request, progress, cancellationToken) =>
                    ValueTask.FromResult(new CreateMessageResult
                    {
                        Model = "fake-model",          // required
                        Role = Role.Assistant,
                        StopReason = "endTurn",
                        Content = [new TextContentBlock { Text = "這是假 LLM 的摘要。" }],
                    }),
            },
        });

    [Fact]
    public async Task summarize_透過假SamplingHandler回傳摘要()
    {
        await using var client = await CreateClientWithFakeLlmAsync();

        var result = await client.CallToolAsync("summarize",
            new Dictionary<string, object?> { ["text"] = "很長的文章……" });

        var text = Assert.IsType<TextContentBlock>(result.Content[0]);
        Assert.Equal("這是假 LLM 的摘要。", text.Text);
    }

    [Fact]
    public async Task client未宣告sampling_工具回傳IsError()
    {
        await using var client = await CreateClientAsync();   // 沒有 SamplingHandler

        var result = await client.CallToolAsync("summarize",
            new Dictionary<string, object?> { ["text"] = "x" });

        Assert.True(result.IsError);   // SampleAsync 丟 InvalidOperationException
    }
}
```

（`McpServerTestBase` 即第 13 章的基底，`CreateClientAsync` 加了一個可選的 `McpClientOptions` 參數。以上測試連同本章其餘範例實測通過。）

`CreateMessageResult` 有兩個 `required` 屬性別漏：`Content` 與 `Model`。`StopReason` 用協定慣例字串 `"endTurn"`／`"maxTokens"`／`"stopSequence"`／`"toolUse"`——SDK 內有同名常數但是 `internal`，外部程式直接寫字串。

## 常見錯誤

**1. client 沒掛 handler,工具直接失敗**

`SampleAsync` 檢查到 client 未宣告 sampling capability 時丟 `InvalidOperationException`，對 client 呈現為 `IsError = true` 的工具結果（上方測試實證）。寫工具時若 sampling 只是加分項，可先檢查 `server.ClientCapabilities?.Sampling` 再決定要不要走 LLM 路徑。

**2. `CreateSamplingHandler` 找不到（CS1061）**

擴充方法在根 namespace,需要 `using ModelContextProtocol;`——不是 `.Client` 也不是 `.Protocol`。

**3. 把 handler 掛在 `SamplingCapability` 上（CS0117 或無效）**

v1.4.0 的正確位置是 `McpClientOptions.Handlers.SamplingHandler`。`SamplingCapability` 是純協商資料，只有 `Context` 與 `Tools` 兩個屬性。

**4. `CreateMessageResult.StopReasonEndTurn` 存取不到（CS0117）**

那些常數是 `internal`。自己建 `CreateMessageResult`（通常只在測試的假 handler 裡）時，`StopReason` 直接寫字串 `"endTurn"`。

**5. 在 stateless HTTP 模式下用 sampling**

第 12 章的 `SessionMode = HttpServerSessionMode.Stateless` 明確不支援 server→client 請求，sampling 會失敗。需要 sampling 的 server 要用 stateful 模式（或 stdio）；hybrid 也只有 initialize client 路徑能使用 sampling。

**6. 把 `AsSamplingChatClient()` 當作 v2 新專案入口**

它在 v2 已標記 MCP9005 obsolete，只適合既有 `IChatClient`-based 程式的短期相容。新程式直接使用 `SampleAsync`。

## 相關章節

- [第 5 章：工具進階](./05-mcp-server-tools-advanced.md)——`McpServer` 參數注入，本章 server 端範例的基礎
- [第 9 章：通知、進度、Logging 與 Completion](./09-notifications-logging-completion.md)——handler 簽名裡 `IProgress<ProgressNotificationValue>` 的來源
- [第 10 章：建立 MCP Client](./10-mcp-client.md)——`McpClientOptions` 佈線
- [第 12 章：ASP.NET Core 託管 MCP Server](./12-aspnetcore-hosting.md)——stateless 模式為何犧牲 sampling
- [第 13 章：測試策略](./13-testing-strategy.md)——本章測試手法的出處
- [第 16 章：與 LLM 整合](./16-llm-integration.md)——`IChatClient` 生態的完整介紹

## 延伸閱讀

- 上游 `samples/ChatWithTools`——真實 LLM（OpenAI）的 client 端佈線
- 上游 `samples/TestServerWithHosting/Tools/SampleLlmTool.cs`——官方 server 端 sampling 工具
- 上游 `samples/EverythingServer`——sampling 與其他 capability 的綜合示範
- wiki 條目：[sampling](../mcp-csharp-sdk-kb/wiki/concepts/sampling.md)、[mef-ai-integration](../mcp-csharp-sdk-kb/wiki/concepts/mef-ai-integration.md)
