# 第 01 章：什麼是 MCP（Model Context Protocol）

> 對應 wiki 概念：[what-is-mcp](../mcp-csharp-sdk-kb/wiki/concepts/what-is-mcp.md)
> 上游 API：N/A（協定概念）
> 基準版本：v2.2.0（MCP 2026-07-28）

## 本章目標

讀完本章，你可以：

- 用一句話說明 MCP 解決什麼問題，以及它為什麼存在
- 說出 MCP 的三種 server primitive（Tools / Resources / Prompts）各自的角色
- 理解 client、server、傳輸層三者的關係
- 看懂一個最小 MCP server 與 client 的骨架，知道後續章節會把它們補完

## 為什麼需要這個

假設你有 M 個 AI 應用（Claude Desktop、VS Code、你自家的聊天機器人……），想讓它們都能存取 N 種外部能力（查資料庫、讀檔案、呼叫內部 API……）。如果每個應用都各自為每種能力寫一套整合，你會得到 **M × N 套**互不相容的黏合程式碼——這就是「M×N 整合問題」。

MCP（Model Context Protocol）是 Anthropic 在 2024 年提出的**開放協定**，把這個問題收斂成 **M + N**：每個應用只要會說 MCP（成為 client），每種能力只要包成一個 MCP server，任何 client 就能連任何 server。協定本身與語言無關、與廠商無關。

**MCP C# SDK** 是這個協定的官方 .NET 實作（與 Microsoft 合作維護），讓你用熟悉的 C# / .NET 與 ASP.NET Core 技術，把 .NET 應用變成 MCP server 或 client。本教學的基準是 NuGet 套件 `ModelContextProtocol` **v2.2.0**，current protocol path 為 MCP **2026-07-28**；SDK 仍可與 2025-11-25 等 down-level peer 協商互通。

## 核心概念

### 通訊模型

MCP 以 **JSON-RPC 2.0** 為訊息格式，在 **client** 與 **server** 之間雙向通訊。常見的兩種傳輸層（transport）：

- **stdio**：client 把 server 當成子行程啟動，雙方用標準輸入/輸出交換訊息（最適合本機工具，見 [stdio-transport](../mcp-csharp-sdk-kb/wiki/concepts/stdio-transport.md)）
- **Streamable HTTP**：server 是一個 HTTP 服務，適合遠端/雲端部署（見 [streamable-http-transport](../mcp-csharp-sdk-kb/wiki/concepts/streamable-http-transport.md)）

> ⚠️ 用 stdio 時，**stdout 專供協定使用**，server 的 log 必須走 stderr，否則會污染訊息流。後續章節會反覆強調這點。

### 三種 Server Primitive

server 向 client 宣告它提供哪些能力，分三種第一級 primitive：

| Primitive | 角色 | 由誰主導 | 對應章節 |
|-----------|------|---------|---------|
| **Tools** | 可執行的動作（查天氣、寫檔、呼叫 API） | 模型（model-controlled） | 第 04、05 章（[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md)）|
| **Resources** | 唯讀資料，以 URI 定址（檔案、設定、紀錄） | 應用程式（application-controlled）；host 可把資源納入模型上下文 | 第 07 章（[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md)）|
| **Prompts** | 可重用的提示範本，可帶參數 | 使用者（user-controlled） | 第 06 章（[mcp-server-prompts](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-prompts.md)）|

除了這三種，MCP 還有 **Sampling**（server 反向請 client 的 LLM 補全，見 [sampling](../mcp-csharp-sdk-kb/wiki/concepts/sampling.md)）、**Elicitation**（server 向使用者徵詢輸入，見 [elicitation](../mcp-csharp-sdk-kb/wiki/concepts/elicitation.md)）與 **Tasks extension**（長時間任務，見 [tasks](../mcp-csharp-sdk-kb/wiki/concepts/tasks.md)）等進階互動，留待第六部分。

## 上手範例

先不求看懂每一行——這是要讓你對「一個 MCP server 長什麼樣」有畫面。以下取自官方 `QuickstartWeatherServer` sample：

```csharp
// Program.cs — 一個最小的 stdio MCP server
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddMcpServer()      // 註冊 MCP server（第 03 章）
    .WithStdioServerTransport()      // 用 stdio 傳輸（第 04、08 章）
    .WithTools<WeatherTools>();      // 掛上一組工具（第 04 章）

builder.Logging.AddConsole(o =>
{
    o.LogToStandardErrorThreshold = LogLevel.Trace;   // log 走 stderr，不污染 stdout
});

await builder.Build().RunAsync();
```

工具本身只是一個標了 attribute 的普通 C# 方法：

```csharp
// 取自 QuickstartWeatherServer/Tools/WeatherTools.cs（節錄）
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerToolType]
public sealed class WeatherTools
{
    [McpServerTool, Description("Get weather alerts for a US state.")]
    public static async Task<string> GetAlerts(
        HttpClient client,                                    // 由 DI 自動注入
        [Description("The US state, e.g. NY.")] string state)
    {
        // ... 呼叫氣象 API，回傳文字 ...
    }
}
```

另一端，一個 client 連上 server、列出它的工具（簡化自官方 `QuickstartClient`）：

```csharp
using ModelContextProtocol.Client;

var clientTransport = new StdioClientTransport(new()
{
    Name = "Demo Server",
    Command = "dotnet",
    Arguments = ["run", "--project", "../QuickstartWeatherServer"],
    // 真實的 QuickstartClient 還設了 InheritEnvironmentVariables = false 與 EnvironmentVariables
    // （v1.4.0 新增的子行程環境變數控制 + 安全強化）——完整版見第 10 章、安全細節見第 18 章。
});

await using var mcpClient = await McpClient.CreateAsync(clientTransport);

var tools = await mcpClient.ListToolsAsync();
foreach (var tool in tools)
    Console.WriteLine($"Connected to server with tools: {tool.Name}");
```

這三段分別對應：**怎麼建 server（第 03 章）**、**怎麼寫工具（第 04 章）**、**怎麼建 client（第 10 章）**。本章只要先有整體輪廓。

## 進階用法

MCP 工具能無縫接上 LLM。因為 client 取回的工具型別 `McpClientTool` 繼承自 `Microsoft.Extensions.AI` 的 `AIFunction`，可以直接餵給 `IChatClient` 做 function calling：

```csharp
// 概念示意（完整版見第 16 章）
var tools = await mcpClient.ListToolsAsync();
var options = new ChatOptions { Tools = [.. tools] };   // MCP 工具當成 AIFunction
var response = await chatClient.GetResponseAsync("台北今天天氣？", options);
```

> 📌 `IChatClient`、`AIFunction`、`ChatOptions` 來自外部 NuGet **Microsoft.Extensions.AI**，不是 MCP SDK 的型別。MCP SDK 側負責橋接的型別是 `McpClientTool`。詳見 [mef-ai-integration](../mcp-csharp-sdk-kb/wiki/concepts/mef-ai-integration.md)（第 16 章）。

## 常見錯誤

- **用 stdio 卻把 log 寫到 stdout**：會把非 JSON-RPC 的文字混進協定流，導致 client 解析失敗。務必設定 log 走 stderr。
- **以為 MCP 綁定某個 LLM 廠商**：MCP 是中立協定；server 不需要自帶模型，client 用哪個 LLM 與 server 無關。
- **把 Tools / Resources / Prompts 混為一談**：三者語意不同——Tools 是「會改變狀態或執行動作」、Resources 是「唯讀資料」、Prompts 是「給使用者選的範本」。挑錯 primitive 會讓 client 的 UX 不直覺。
- **沿用過時範例的 `McpClientFactory`**：current client 建立入口是 `McpClient.CreateAsync`，舊版的 `McpClientFactory` 已不存在（見[附錄 B](./appendix-b-migration.md)）。

## 相關章節

- 第 02 章：[nuget-packages](../mcp-csharp-sdk-kb/wiki/concepts/nuget-packages.md) — SDK 核心／hosting 與 extension 套件怎麼選、怎麼裝
- 第 03 章：[mcp-server-builder](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-builder.md) — `AddMcpServer` 與 hosting 架構
- 第 04 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) — 寫第一個工具並用 stdio 跑起來
- 第 10 章：[mcp-client](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client.md) — 建立 client、列出與呼叫工具

## 延伸閱讀

- [MCP 規格](https://modelcontextprotocol.io/specification/)
- [MCP C# SDK 概念文件](https://csharp.sdk.modelcontextprotocol.io/)
- [modelcontextprotocol/csharp-sdk（GitHub）](https://github.com/modelcontextprotocol/csharp-sdk)
- [附錄 C：MCP 規格映射](./appendix-c-spec-mapping.md)（2026-07-28 primitive ↔ C# 型別）
