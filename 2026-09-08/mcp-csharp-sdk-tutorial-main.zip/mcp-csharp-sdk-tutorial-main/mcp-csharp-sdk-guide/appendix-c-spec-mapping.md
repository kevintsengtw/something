# 附錄 C：MCP 規格映射（2026-07-28 primitive ↔ C# 型別）

> 本附錄把 MCP 規格（2026-07-28）的概念逐一對應到 SDK 的 C# 型別與 API，供「讀規格找 C#」
> 或「讀 C# 找規格」時雙向速查。所有映射均出自對應教學章節的已驗內容。
> 基準：MCP 規格 2026-07-28 ／ SDK v2.2.0 ｜ 最後更新：2026-08-15

## Server primitives

| 規格概念 | 控制權 | Server 端定義 | Client 端消費 | 協定型別 | 章節 |
|---------|--------|--------------|--------------|---------|------|
| Tools | 模型（model-controlled） | `[McpServerToolType]` + `[McpServerTool]`；低階 `McpServerTool.Create` | `ListToolsAsync` → `McpClientTool`；`CallToolAsync` → `CallToolResult` | `Tool`、`CallToolRequestParams`、`CallToolResult`、`ContentBlock` 家族 | 04、05、10 |
| Resources | 應用程式（application-controlled） | `[McpServerResourceType]` + `[McpServerResource(UriTemplate=…)]` | `ListResourcesAsync`／`ListResourceTemplatesAsync`／`ReadResourceAsync` | `Resource`、`ResourceTemplate`、`ResourceContents`（`Text`／`Blob`）、`ReadResourceResult` | 07、10 |
| Prompts | 使用者（user-controlled） | `[McpServerPromptType]` + `[McpServerPrompt]` | `ListPromptsAsync`／`GetPromptAsync` | `Prompt`、`PromptMessage`、`GetPromptResult` | 06、10 |

註冊：三種 primitive 同型三組 builder 擴充（`WithTools<T>`／`WithToolsFromAssembly`…）。

## Server → Client 請求（需要雙向傳輸；stateless HTTP 不支援）

| 規格概念 | 協定方法 | Server 端發起 | Client 端處理 | 章節 |
|---------|---------|--------------|--------------|------|
| Sampling | `sampling/createMessage` | `McpServer.SampleAsync`（兩多載）；legacy `AsSamplingChatClient()`（MCP9005） | `McpClientHandlers.SamplingHandler`；`CreateSamplingHandler(IChatClient)` | 14 |
| Elicitation | `elicitation/create` | `McpServer.ElicitAsync`／`ElicitAsync<T>` | `McpClientHandlers.ElicitationHandler` | 15 |
| Roots | `roots/list` | `McpServer` 的 roots 請求 API | client 宣告 roots capability | 08（概述） |

## Utilities

| 規格概念 | 協定方法 | SDK 對應 | 章節 |
|---------|---------|---------|------|
| 進度回報 | `notifications/progress` | server 注入 `IProgress<ProgressNotificationValue>`；client `CallToolAsync(progress:)` | 09 |
| 日誌轉送 | `logging/setLevel`＋`notifications/message` | `SetLoggingLevelAsync`；`LoggingLevel`；legacy `AsClientLoggerProvider()`（MCP9005） | 09 |
| 參數補全 | `completion/complete` | `AllowedValuesAttribute`（自動）；`WithCompleteHandler`（手動）；`Completion` | 06、09 |
| 取消 | `notifications/cancelled` | 方法注入的 `CancellationToken` 被觸發 | 05、09 |
| Ping | `ping` | `PingAsync()` | 10 |
| 清單變更通知 | `notifications/*/list_changed` | `SendNotificationAsync(NotificationMethods.…)` | 05、07、09 |
| 資源訂閱 | `resources/subscribe`／`unsubscribe`＋`notifications/resources/updated` | `WithSubscribeToResourcesHandler`（訂閱表自管）；client `SubscribeToResourceAsync` | 07、10 |
| 訂閱監聽 | `subscriptions/listen` | `WithSubscriptionsListenHandler`；stateless 可沿 held-open POST 提供 request-bound 通知 | 07、08、12 |
| Tasks extension（v2.0.0） | `tasks/get`／`tasks/update`／`tasks/cancel` | `WithTasks(IMcpTaskStore)`；client `CallToolWithPollingAsync`，或 `CallToolAsTaskAsync`→`GetTaskAsync`／`UpdateTaskAsync`／`CancelTaskAsync`；`GetTaskResult` 子型別／`McpTaskStatus` | 17 |

## 傳輸層

| 規格傳輸 | Server 端 | Client 端 | 章節 |
|---------|----------|----------|------|
| stdio | `WithStdioServerTransport()` | `StdioClientTransport(+Options)` | 04、08 |
| Streamable HTTP | `WithHttpTransport(+HttpServerTransportOptions)`＋`MapMcp()` | `HttpClientTransport(+Options)`，`HttpTransportMode.StreamableHttp` | 08、12 |
| （SDK 加值）in-memory | `StreamServerTransport`／`WithStreamServerTransport` | `StreamClientTransport`（ns `.Protocol`！） | 13 |
| （淘汰）HTTP+SSE | `EnableLegacySse = true`（MCP9004） | `HttpTransportMode.Sse` | 08、附錄 B |

## 訊息與生命週期

| 規格概念 | SDK 對應 | 章節 |
|---------|---------|------|
| JSON-RPC 2.0 訊息 | SDK 內部處理；低階可見 `JsonRpcRequest` 等（`RequestContext.JsonRpcRequest`） | 05、17 |
| discovery／initialize＋能力協商 | `McpClient.CreateAsync` 一次完成；`McpClientOptions.Capabilities` 多由 `Handlers` 自動推導 | 10、14、15 |
| 協定版本 | 兩端協商；`McpServerOptions.ProtocolVersion` 可覆寫 | 03、19 |
| Session（Streamable HTTP） | `Mcp-Session-Id` 標頭；`HttpServerSessionMode`／`SessionMode` 三態設定；`Stateless` compatibility proxy；`McpServer.SessionId` | 08、12 |
| 工具錯誤 vs 協定錯誤 | 工具內丟 `McpException` → `IsError=true` 結果；`McpProtocolException(+McpErrorCode)` → JSON-RPC error | 05 |

## Capabilities 對照

| 規格 capability | 宣告方 | SDK 中的形態 | 章節 |
|----------------|--------|-------------|------|
| `tools`／`resources`／`prompts`／`logging` | server | 註冊對應 primitive／handler 即自動宣告 | 03–07 |
| `resources.subscribe` | server | 掛 subscribe handler | 07 |
| `sampling` | client | 設 `Handlers.SamplingHandler` 自動宣告（`SamplingCapability` 另有 `Context`／`Tools` 子項） | 14 |
| `elicitation` | client | 設 `Handlers.ElicitationHandler` 自動宣告（form／url 模式） | 15 |
| `roots` | client | client 端 roots 設定 | 08（概述） |
| `io.modelcontextprotocol/tasks` extension（v2） | server | `WithTasks(IMcpTaskStore)` 自動公告 extension；`ExecutionModeSelector` 決定 Synchronous／Optional／Required | 17 |

## 讀規格時的 SDK 命名對照提醒

- 規格的 camelCase 欄位（`inputSchema`、`isError`…）↔ SDK 的 PascalCase 屬性（`InputSchema`、`IsError`）——序列化層自動轉換。
- 工具名稱：SDK 預設把方法名轉 **snake_case**（`GetAlerts` → `get_alerts`），見第 04 章。
- 規格的「content」區塊 ↔ `ContentBlock` 家族（`TextContentBlock`／`ImageContentBlock`／`AudioContentBlock`／`EmbeddedResourceBlock`）。

## 參考連結

- [MCP 規格](https://modelcontextprotocol.io/specification/)
- 知識庫事實層：`../mcp-csharp-sdk-kb/raw/facts/v2.2.0-verified-changes.json`
- [第 01 章：什麼是 MCP](./01-what-is-mcp.md)（primitive 總覽）
