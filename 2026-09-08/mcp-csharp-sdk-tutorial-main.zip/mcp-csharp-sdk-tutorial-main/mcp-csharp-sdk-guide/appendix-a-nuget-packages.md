# 附錄 A：NuGet 套件清單與版本記錄

> 本附錄整理 MCP C# SDK 的套件分工、依賴、目標框架與版本時間線，供選型與升級時速查。
> 敘事版說明見[第 02 章](./02-nuget-packages.md)。
> 基準版本：**ModelContextProtocol v2.2.0** ｜ 最後更新：2026-08-15

## 套件總表

| NuGet 套件 | 角色 | 代表性內容 | 主要 namespace | 對應教學章節 |
|-----------|------|-----------|---------------|------------|
| `ModelContextProtocol.Core` | 協定核心；最小依賴的 client / low-level server | `McpClient`、`McpServer`、全部 primitive attribute 與協定型別、client/共用 auth | `ModelContextProtocol`（根）、`.Client`、`.Server`、`.Protocol`、`.Authentication` | 全書 |
| `ModelContextProtocol` | hosting + DI + attribute 探索（**多數專案起點**） | `AddMcpServer`、`WithStdioServerTransport`、`WithTools*`／`WithPrompts*`／`WithResources*` | `Microsoft.Extensions.DependencyInjection`（DI 慣例） | ch03–11、13–17、20 |
| `ModelContextProtocol.AspNetCore` | ASP.NET Core 託管 HTTP server | `WithHttpTransport`、`MapMcp`、`HttpServerTransportOptions`、server 端 OAuth handler | `ModelContextProtocol.AspNetCore`、`.AspNetCore.Authentication` | ch12、18、19 |
| `ModelContextProtocol.Extensions.Tasks` | v2 Tasks extension | `WithTasks`、task store、client task lifecycle 與 Tasks protocol 型別 | `ModelContextProtocol.Extensions.Tasks` | ch17 |
| `ModelContextProtocol.Extensions.Apps` | MCP Apps extension | Apps metadata、UI resource 與 builder API | `ModelContextProtocol.Extensions.Apps` | 第 21 章 |
| `ModelContextProtocol.Analyzers` | 編譯期 Roslyn analyzers / source generators | 隨上列套件自動帶入，不需手動引用 | —— | —— |

> ⚠️ **沒有** `ModelContextProtocol.Authentication` 套件——auth 型別分佈在 `.Core`（client/共用）與 `.AspNetCore`（server handler），詳見第 02、18 章。

## 依賴鏈與安裝

```text
ModelContextProtocol.AspNetCore ─▶ ModelContextProtocol ─▶ ModelContextProtocol.Core ─▶ Microsoft.Extensions.AI.Abstractions（外部）
ModelContextProtocol.Extensions.Tasks ─▶ ModelContextProtocol ─▶ ModelContextProtocol.Core
ModelContextProtocol.Extensions.Apps ───▶ ModelContextProtocol ─▶ ModelContextProtocol.Core
```

裝上層自動帶下層。安裝指令（釘住教學基準版本）：

```bash
dotnet add package ModelContextProtocol --version 2.2.0            # 多數情境
dotnet add package ModelContextProtocol.AspNetCore --version 2.2.0 # HTTP server
dotnet add package ModelContextProtocol.Core --version 2.2.0       # 最小依賴

# 選用 extensions
dotnet add package ModelContextProtocol.Extensions.Tasks --version 2.2.0 # 第 17 章
dotnet add package ModelContextProtocol.Extensions.Apps --version 2.2.0  # 第 21 章
```

## 目標框架（TFM）

| 套件 | net10.0 | net9.0 | net8.0 | netstandard2.0 |
|------|:---:|:---:|:---:|:---:|
| `ModelContextProtocol.Core` | ✅ | ✅ | ✅ | ✅ |
| `ModelContextProtocol` | ✅ | ✅ | ✅ | ✅ |
| `ModelContextProtocol.AspNetCore` | ✅ | ✅ | ✅ | ❌ |
| `ModelContextProtocol.Extensions.Tasks` | ✅ | ✅ | ✅ | ✅ |
| `ModelContextProtocol.Extensions.Apps` | ✅ | ✅ | ✅ | ✅ |

本教學所有範例以 **net9.0** 撰寫與驗證。

## 各套件重點型別速查

### ModelContextProtocol.Core

| 分類 | 型別（節選） | namespace |
|------|------------|-----------|
| Client | `McpClient`、`McpClientTool`（`: AIFunction`）、`McpClientPrompt`、`McpClientResource`、`McpClientHandlers` | `ModelContextProtocol.Client` |
| Client 傳輸 | `StdioClientTransport(+Options)`、`HttpClientTransport(+Options)`、`HttpTransportMode`、`ClientTransportClosedException` | `ModelContextProtocol.Client` |
| Server | `McpServer`、`McpServerOptions`、`McpServerTool/Prompt/Resource` 與各 attribute、`RequestContext<T>`、`StreamServerTransport` | `ModelContextProtocol.Server` |
| 協定 | `CallToolResult`、`ContentBlock` 家族、`ResourceContents` 家族、`GetPromptResult`、`CreateMessageRequestParams`、`ElicitRequestParams`、`NotificationMethods` | `ModelContextProtocol.Protocol` |
| 根 namespace | `McpException`、`McpProtocolException`、`McpErrorCode`、`AIContentExtensions`（`CreateSamplingHandler`）、`McpJsonUtilities` | `ModelContextProtocol` |
| Auth（client/共用） | `ClientOAuthOptions`、`IdentityAssertionGrantProvider`、`TokenContainer`、`ITokenCache` | `ModelContextProtocol.Authentication` |
| 例外位置提醒 | `StreamClientTransport` 在 **`ModelContextProtocol.Protocol`**（檔案在 Client/ 目錄） | —— |

### ModelContextProtocol

| 分類 | 型別／方法（節選） | namespace |
|------|------------------|-----------|
| DI 入口 | `AddMcpServer`、`IMcpServerBuilder` | `Microsoft.Extensions.DependencyInjection` |
| 傳輸註冊 | `WithStdioServerTransport`、`WithStreamServerTransport` | 同上 |
| primitive 註冊 | `WithTools<T>`／`WithTools(IEnumerable<Type>)`／`WithToolsFromAssembly`（Prompts／Resources 同型三組） | 同上 |
| 低階 handler | `WithCallToolHandler`、`WithCompleteHandler`、`WithSubscribeToResourcesHandler` 等 | 同上 |

> AOT 注意：非泛型 `With*(IEnumerable<Type>)` 與 `With*FromAssembly` 標 `[RequiresUnreferencedCode]`，見[第 20 章](./20-native-aot.md)。

### ModelContextProtocol.AspNetCore

| 分類 | 型別／方法（節選） | namespace |
|------|------------------|-----------|
| 佈線 | `WithHttpTransport`、`MapMcp` | `Microsoft.Extensions.DependencyInjection`／`Microsoft.AspNetCore.Builder` |
| 選項 | `HttpServerTransportOptions`（`SessionMode`、`Stateless` compatibility proxy、`IdleTimeout`、`ConfigureSessionOptions`…完整表見[第 12 章](./12-aspnetcore-hosting.md)） | `ModelContextProtocol.AspNetCore` |
| Auth（server） | `AddMcp`、`McpAuthenticationOptions`、`McpAuthenticationDefaults`、`McpAuthenticationHandler` | `ModelContextProtocol.AspNetCore.Authentication` |

### ModelContextProtocol.Extensions.Tasks（v2）

| 分類 | 型別／方法（節選） | namespace |
|------|------------------|-----------|
| Server | `WithTasks`、`IMcpTaskStore`、`InMemoryMcpTaskStore`、`McpTasksOptions` | `ModelContextProtocol.Extensions.Tasks` |
| Client | `CallToolWithPollingAsync`、`CallToolAsTaskAsync`、`GetTaskAsync`、`UpdateTaskAsync`、`CancelTaskAsync` | `ModelContextProtocol.Extensions.Tasks` |
| Protocol | `CreateTaskResult`、`GetTaskResult` 子型別、`McpTaskStatus`、`TasksProtocol` | `ModelContextProtocol.Extensions.Tasks` |

## 常搭配的外部套件

| 套件 | 用途 | 教學實測版本 |
|------|------|------------|
| `Microsoft.Extensions.Hosting` | Generic Host（stdio server） | 9.0.6（ch11） |
| `Microsoft.Extensions.DependencyInjection` | 測試中自建容器 | 9.0.6（ch13） |
| `Microsoft.Extensions.AI` | `UseFunctionInvocation` 等 middleware | 10.8.0（ch16 的既有 v1.4.0 實證；v2.2.0 需重驗） |
| `Microsoft.Extensions.AI.OpenAI` 等供應商套件 | 實際接 LLM | 未實測（見 ch16 說明） |
| `Microsoft.AspNetCore.Authentication.JwtBearer` | HTTP server 驗 token | 9.0.6（ch18，編譯驗證） |

## SDK 版本時間線

| 版本 | 日期 | 重點 | 教學相關 |
|------|------|------|---------|
| 1.0.0 | 2026-02-25 | 首個穩定版（2025-11-25 規格） | 全書基礎 |
| 1.1.0 | 2026-03-06 | `AllowedValues` 自動補全、client completion details | ch06、09 |
| 1.2.0 | 2026-03-27 | ⚠️ legacy SSE 預設停用；`RequestContext` 2-arg ctor 淘汰；`OutputSchemaType` | ch05、08（migration 見附錄 B） |
| 1.3.0 | 2026-05-08 | `ClientTransportClosedException`；連線失敗改丟 `IOException` 系 | ch10 |
| 1.4.0 | 2026-06-04 | 前一教學基準；ID-JAG、`InheritEnvironmentVariables`、session 安全強化 | ch08、12、18 |
| 1.4.1 | 2026-07-09 | 純 bug-fix（SSE 記憶體洩漏）；**無 API 變更**——教學內容完全適用 | —— |
| 2.0.0-preview.1 | 2026-06-26 | 2026-07-28 規格草案的 preview | 歷史 |
| 2.0.0 | 2026-07-28 | Tasks／Apps extensions；`Stateless` 預設 true；explicit SSE 保留底層例外 | ch08、10、12、17、附錄 B |
| 2.1.0 | 2026-08-05 | `subscriptions/listen` 公開 handler、transport/discovery 修正 | ch07、08、10、12、附錄 B |
| **2.2.0** | 2026-08-13 | **教學基準**；新增三態 `HttpServerSessionMode` 與 hybrid HTTP session mode；修正退化 base64 header wrapper 解碼 | ch08、12、附錄 B/C |

## 參考連結

- [NuGet：ModelContextProtocol](https://www.nuget.org/packages/ModelContextProtocol)（另兩套件同 prefix）
- [上游 Releases](https://github.com/modelcontextprotocol/csharp-sdk/releases)
- [第 02 章：SDK 三套件選擇與安裝](./02-nuget-packages.md)
- [附錄 B：API 變更與 Migration](./appendix-b-migration.md)
