# MCP C# SDK 繁中教學工作區指引

## 專案狀態

- 基準：ModelContextProtocol v2.2.0；上游 `csharp-sdk/` 對齊 v2.2.0 commit `6fa3825973949a9c4f0cd8af344e15a8db09dc35`。
- 交付：20 章＋附錄 A/B/C，已於 2026-07-16 完成第二意見審查與處置，具備發佈條件。
- 附錄 D/E 是第二輪工作，不是目前發佈阻塞。
- Claude Code → Codex 移轉進度以 `CODEX-HANDOFF-PLAN.md` 為準。

## 目錄角色

| 路徑 | 角色 | 寫入規則 |
| --- | --- | --- |
| `csharp-sdk/` | 上游 SDK clone、結構性事實基準 | 永遠唯讀；不得修改、格式化或提交到 root repo |
| `mcp-csharp-sdk-kb/` | facts、raw 素材、wiki concepts、知識圖譜 | 依該目錄 `AGENTS.md` 維護 |
| `mcp-csharp-sdk-guide/` | 已審查的繁中教學與 reviews | 依該目錄 `AGENTS.md` 維護 |
| `outputs/` | 草稿與暫存產物 | 新章節/附錄先寫此處，人工確認後才移入 guide |

## Ground Truth

1. API 名稱、簽名、namespace、繼承與套件歸屬先由 `codebase-memory-mcp` 或上游原始碼查證。
2. project name 由絕對路徑產生；每個 session 先以 `list_projects` 找 root path 以 `/csharp-sdk` 結尾者，不得硬編碼本機名稱。
3. 套件歸屬以 `csharp-sdk/src/<Package>/...` 路徑判定，不可只由 namespace 推測。
4. `Microsoft.Extensions.AI.*` 是外部 NuGet，圖譜查無型別本體屬正常；改查上游使用端。
5. LLM 負責敘述與教學編排，不得憑記憶宣告 API 存在或不存在。

## 工作規則

- 保留 `.claude/`、`CLAUDE.md` 與 `.mcp.json`；移轉並存期不得修改或刪除 Claude Code 來源面。
- Codex 專案設定放在 `.codex/`，repository skills 放在 `.agents/skills/`。
- 不把 secrets、本機 token 或索引 DB 寫入 repository。
- 修改前先讀目標範圍的 `AGENTS.md`、相關 wiki concept、guide review 與上游對齊記錄。
- 已審查內容只在明確使用者要求、已驗證 drift 或可重現錯誤下修改。
- 保留繁體中文敘述；API、型別、方法、套件與協定欄位保留英文原名。
- 使用 `apply_patch` 做人工檔案編輯；bulk formatter 只能處理已明確界定且可驗證的機械轉換。

## 標準流程

- 查詢：`$wiki-query`
- 文件檢查：`$lint-tutorial`
- 上游更新：`$sync-upstream` → `$extract-facts` → `$compile-knowledge` → `$snapshot-knowledge` → `$drift-check` → `$update-tutorial` → `$lint-tutorial`
- 教學建立：`$draft-chapter` / `$draft-appendix` → `outputs/` → 人工 review → `$regenerate-toc` → `$lint-tutorial`

高風險寫入 skill 必須先 preview/dry-run，缺少版本或 scope 時不得直接修改。

## 驗證與完成定義

- 快速文件驗證：`node scripts/lint-docs.mjs`（腳本建立前不得聲稱 deterministic lint 已通過）。
- 修改 Codex artifacts 後執行 migrator `--validate-target .codex`。
- 修改 guide 程式碼時，依影響範圍執行對應 build/test；Docker、OAuth、AOT 只在相關章節或發布驗證時跑 release profile。
- 完成前檢查 `git diff --check`、root Git status 與 `git -C csharp-sdk status --short`。
- 不修正與當前任務無關的既有問題；發現時記錄並回報。

## Git 安全

- baseline tag：`tutorial-v1.4.0-reviewed-2026-07-16`。
- 不使用 `git reset --hard` 或 `git checkout --` 回復使用者變更。
- 每個移轉 phase 使用獨立、可審查的 commit；提交前檢查 staged diff、secrets 與 `csharp-sdk/` 排除狀態。
