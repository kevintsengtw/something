# 新機器環境設定指南

本文說明如何在新機器上 clone 本 repo 並完成完整工作環境設定。

> **目標環境：macOS**

---

## 前置需求

| 工具 | 版本 | 用途 |
|------|------|------|
| macOS | 任意 | 主要支援的 OS |
| Node.js | 18+ | codebase-memory-mcp、UA Dashboard |
| .NET SDK | 9.0+ | 執行教學範例程式碼 |
| Codex CLI | 最新版 | 主要工作區操作入口 |
| Claude Code | 選用 | 移轉並存期的 legacy commands |
| pnpm | 任意 | UA Dashboard 依賴管理 |

```bash
node --version    # >= 18
dotnet --version  # >= 9.0
codex --version
npm install -g pnpm
```

---

## 步驟一：Clone 本 repo

```bash
git clone <本 repo 的 URL> mcp-csharp-sdk-tutorial
cd mcp-csharp-sdk-tutorial
```

---

## 步驟二：Clone 上游 SDK（csharp-sdk/）

`csharp-sdk/` 不包含在本 repo 中（已 gitignore），需在**工作區根內**另行 clone，並對齊至目前知識庫對應的 commit/tag：

```bash
# 在 mcp-csharp-sdk-tutorial/ 工作區根執行
git clone https://github.com/modelcontextprotocol/csharp-sdk.git

# 對齊至目前知識庫基準版本（見 mcp-csharp-sdk-kb/UPSTREAM-REF.md）
cd csharp-sdk
git fetch --tags
git checkout v2.2.0
cd ..
```

完成後目錄結構應為：

```text
mcp-csharp-sdk-tutorial/
├── csharp-sdk/                  ← 上游 SDK（自行 clone）
├── mcp-csharp-sdk-kb/
└── mcp-csharp-sdk-guide/
```

> 最新基準 commit/tag 見 [`mcp-csharp-sdk-kb/UPSTREAM-REF.md`](./mcp-csharp-sdk-kb/UPSTREAM-REF.md)。

---

## 步驟三：安裝 codebase-memory-mcp

```bash
npm install -g codebase-memory-mcp
which codebase-memory-mcp   # 確認安裝成功
```

---

## 步驟四：啟用 Codex 專案設定

repository 已包含：

- `AGENTS.md` 與子目錄 `AGENTS.md`：專案與範圍化規約
- `.agents/skills/`：可重用維護工作流
- `.codex/config.toml`：`codebase-memory-mcp` 專案設定

首次開啟時將本 repository 標示為 trusted，然後重新啟動 Codex session：

```bash
codex mcp list
```

確認 `codebase-memory-mcp` 為 enabled。若 command 找不到，先確認 Codex 啟動環境的 PATH 可解析 `codebase-memory-mcp`。

---

## 步驟五：首次索引 csharp-sdk/

索引是機器本地狀態，不隨 repository 共享。使用 CLI 建立：

```bash
codebase-memory-mcp cli index_repository \
  '{"repo_path":"<絕對路徑>/mcp-csharp-sdk-tutorial/csharp-sdk"}'

codebase-memory-mcp cli list_projects '{}'
```

project name 由絕對路徑產生、因機器而異。每個 session 取 root path 以 `/csharp-sdk` 結尾的項目，不可假設字面名稱是 `csharp-sdk`。

> 索引 cache 位於使用者層（目前工具版本使用 `~/.cache/codebase-memory-mcp/`），**不在本 repo 內**、**不跨機共享**。工具主要版本變更或 `index_status` 異常時應重建索引。

---

## 步驟六：首次驗證（重要）

需確認 codebase-memory-mcp 在本機對 C# 的解析準度達標（至少 6/7，基準為 7/7）。探測規格見工作區根 [`AGENTS.md`](./AGENTS.md) 與 `mcp-csharp-sdk-kb/raw/facts/codebase-memory-mcp-validation.md`。

> 本機基準線：2026-09-04 @ v2.2.0 通過 6/7（`WithToolsFromAssembly` 的 in_degree=0 屬鏈式擴充方法的已知限制，非解析失敗）。新機器若得到相同的 6/7 即視為達標。

---

## 步驟七：驗證既有建庫

本 repository 已包含 32 個 concepts、facts、knowledge graph、20 章與附錄 A/B/C；新機器不需重新建庫。先執行：

```text
$lint-tutorial
```

只有在上游發布新版本時，才依 `mcp-csharp-sdk-kb/PLAYBOOK-version-update.md` 執行完整 Pipeline。

若需單獨重建 knowledge graph，使用 `$snapshot-knowledge`。該 skill 會先在 repository 外 staging 執行 builder、validator 與 Dashboard smoke；正式發布另有明確確認閘門，不會直接覆寫最後有效快照。

---

## 完成

```bash
cd mcp-csharp-sdk-tutorial
codex
```

常用指令快速參考見 [`mcp-csharp-sdk-kb/QuickStart.md`](./mcp-csharp-sdk-kb/QuickStart.md)。

---

## 選用：Claude Code 並存與知識圖譜 Dashboard

Claude Code 並存期仍可使用 `.claude/commands/`。若需要其 Understand-Anything plugin：

```text
/plugin marketplace add Lum1104/Understand-Anything
/plugin install understand-anything
```

Knowledge graph 的重建不依賴 Claude；下列 Understand-Anything plugin 只提供相容 Dashboard viewer。Dashboard 使用既有 graph，不需要 Claude session：

```bash
cd ~/.claude/plugins/cache/understand-anything/understand-anything/<version>/packages/core
npx tsc
cd ../dashboard
pnpm install

GRAPH_DIR=<絕對路徑>/mcp-csharp-sdk-tutorial/mcp-csharp-sdk-kb/wiki \
  npx vite --host 127.0.0.1
```
