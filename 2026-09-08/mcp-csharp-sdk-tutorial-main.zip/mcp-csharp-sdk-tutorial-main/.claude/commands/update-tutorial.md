# /update-tutorial — 依偏移報告更新教學目錄內容

讀取 `mcp-csharp-sdk-kb/wiki/drift-report.md`，將偵測到的偏移逐項修正至 `mcp-csharp-sdk-guide/` 中的對應教學檔案。

> **project 名稱**：本檔所有 `project: "<csharp-sdk-project>"` 為 placeholder。執行前以 `mcp__codebase-memory-mcp__list_projects` 取路徑以 `/csharp-sdk` 結尾的 project 名稱代入（名稱因機器而異，見工作區根 CLAUDE.md §6）。

## 使用方式

```
/update-tutorial              ← 處理全部項目
/update-tutorial breaking     ← 只處理 🔴 Breaking
/update-tutorial outdated     ← 只處理 🟡 Outdated
/update-tutorial all          ← 同 /update-tutorial（明確全量）
```

## 前置檢查

1. `mcp-csharp-sdk-kb/wiki/drift-report.md` 存在且非空白
2. `mcp-csharp-sdk-guide/` 目錄存在
3. drift-report 中有未修正項目

## 執行步驟

### 1. 載入偏移報告
- 讀取 `mcp-csharp-sdk-kb/wiki/drift-report.md`
- 解析所有 🔴 / 🟡 / 🟢 項目
- 建立修正工作清單，依優先排序：🔴 Breaking（P1 編譯失敗）→ 🔴（P2）→ 🟡 Outdated → 🟢 Enhancement（僅 all 模式）

### 2. 逐項修正

**a. 讀取目標檔案**：根據報告「影響檔案」讀取 `mcp-csharp-sdk-guide/<filename>.md`

**b. 套用修正**

| 偏移類型 | 修正策略 |
|---------|---------|
| API 重新命名 | 精確字串替換（如 `McpClientFactory.CreateAsync` → `McpClient.CreateAsync`） |
| 型別名稱變更 | 替換程式碼區塊內的型別宣告 |
| 方法簽名變更 | 替換完整方法呼叫 |
| 集合型別變更 | 如 `List<T>`/`T[]` → `IList<T>`，`.Length` → `.Count` |
| `--prerelease` 移除 | 移除 `dotnet add package` 中的 `--prerelease` |
| Experimental 標記 | 加上 `#pragma warning disable MCPEXP###` 說明或替代 API |
| 過時描述文字 | 更新文字說明，保留敘事連貫性 |

**修正原則**：
- 只修改報告明確指出的位置
- 不改變章節結構、標題、非偏移相關敘述
- 保留繁體中文寫作風格
- NuGet 版本號更新為 drift-report 依據的 current_version

**c. codebase-memory-mcp 替換方向確認**（API 重新命名類型，**必做**）
```
mcp__codebase-memory-mcp__search_graph
  project: "<csharp-sdk-project>"
  name_pattern: "<新 API 名稱>"
```
- 必要時 `trace_path` direction: outbound 確認依賴結構
- 若圖譜找不到新名稱，**不自動替換**，標記 `⚠️ 需人工確認`

**d. 記錄修正結果**：每項記錄「[item-id] ✅ 已修正：<簡述>」

### 3. 產出修正摘要

```
## /update-tutorial 修正摘要
**執行時間**：YYYY-MM-DD
**處理範圍**：breaking / outdated / all

### 已修正
- [B-001] ✅ <簡述>（N 個檔案，M 處）

### 跳過 / 需人工確認
- [B-002] ⚠️ <簡述>（圖譜未確認）

### 未處理（本次範圍外）
- 🟢 Enhancement 項目
```

### 4. 同步工作區層基準宣告（**必做，過去三輪都漏了**）

drift 修正完成後，教學外還有一組「目前基準」敘述必須跟著改；`node scripts/lint-docs.mjs` 的 `baseline-version` 規則會以 `mcp-csharp-sdk-kb/UPSTREAM-REF.md` 主表的 Tag 為 ground truth 強制檢查，漏改會直接 lint 失敗：

| 檔案 | 需更新處 |
|------|---------|
| `README.md`（工作區根） | 基準版本、最後更新、目錄結構、SDK 套件速覽 |
| `SETUP.md` | `git checkout <tag>`、concepts 數量 |
| `CLAUDE.md`（工作區根） | §6 codebase-memory-mcp 驗證狀態、§10 基準版本 |
| `AGENTS.md` | 「專案狀態」基準行 |
| `mcp-csharp-sdk-kb/README.md` | 目前狀態段、concepts 數量 |
| `mcp-csharp-sdk-kb/QuickStart.md` | `git checkout <tag>`、concepts 數量 |
| `mcp-csharp-sdk-kb/WORKFLOW-DESIGN-v1.md` | 目前基準版本行 |
| `mcp-csharp-sdk-kb/PLAYBOOK-version-update.md` | 歷次執行記錄新增一列 |
| `CODEX-HANDOFF-PLAN.md` | 僅檔頭「目前內容基準」；以下各節是歷史證據，不改寫 |

**不可捏造驗證結果**：跨 minor/major 版本時，`CLAUDE.md` §6 的七項 codebase-memory-mcp 探測需依規則重跑並更新 `raw/facts/codebase-memory-mcp-validation.md`；未重跑就如實標註「尚未重驗」，不得直接把舊結論的版本號改成新版。

完整清單以 `mcp-csharp-sdk-kb/PLAYBOOK-version-update.md` Step 9 為準。

### 5. 後續建議
```
/drift-check    ← 驗證偏移是否消除
/lint           ← 確認一致性
```

## 需人工確認的情況
- 整章程式碼需大幅改寫
- 報告標註「需驗證 SDK 實際簽名」
- 同一位置有多種可能正確寫法
- Enhancement 涉及新增段落或章節
- **codebase-memory-mcp 圖譜找不到要替換的新名稱**

### 修正的完整性要求

以下兩條出自第 21 章第二意見審查的四輪殘留檢討（記錄見 `mcp-csharp-sdk-guide/reviews/second-opinion-resolution-ch21-appendix-d-2026-09-04.md`），該輪每一次「已處置」宣告都因為同一個成因而不成立。

**1. 改完一處措辭，必須全域掃描該措辭。**

修正不是「改掉被指出的那一行」，而是「讓這個說法在整個 repo 不再出現」。同一個錯誤敘述通常散落在正文、章節摘要、目錄、自評、附錄與 README。宣告完成前先跑：

```bash
grep -rn '<被修正的關鍵措辭>' mcp-csharp-sdk-guide/ mcp-csharp-sdk-kb/wiki/ README.md
```

確認殘留只剩「審查／處置文件中引述問題本身」的歷史文字。**補一段反向說明不算修正**——舊宣稱必須改掉，包含 checklist 的勾選狀態。

實例：`Visibility` 的排他語意改了主體小節卻漏章首；自評下方補了限縮說明卻留著上方三處舊宣稱；`sandbox` 用語改了正文卻漏 README 摘要。三次都被審查方退回。

**2. 會變動的狀態事實只寫一處。**

處置輪數、審查結案狀態、章節/附錄計數這類**會隨工作推進而變**的事實，指定一份權威文件記載，其他位置一律指向它，不要複寫數值。複寫本身就是不一致的來源——改一處漏其他處。

實例：處置輪數同時寫在自評與兩份 README，每加一輪就有三處要同步，連續兩輪失準。最終改為「經多輪處置與覆核」＋指向處置文件，才不再產生新的不一致。

> 已機械化的部分：版本基準宣告由 `lint-docs.mjs` 的 `baseline-version` 規則強制與 `UPSTREAM-REF.md` 一致。發佈狀態等自然語言敘述目前無法機械檢查（不同時間點的結案事實本來就該不同），仍靠本條規約與審查。

## 注意事項
- 不執行 `/drift-check` 比對邏輯，只依現有 drift-report 修正
- 若 drift-report 已過時（>7 天），摘要加上提醒
- 🟢 Enhancement 預設不自動處理
- 修正後程式碼以語意正確為目標，不保證 dotnet build 通過
- 替換前圖譜驗證是**硬性規定**
