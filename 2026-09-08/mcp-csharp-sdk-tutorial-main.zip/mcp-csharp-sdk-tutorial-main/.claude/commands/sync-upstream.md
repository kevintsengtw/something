# /sync-upstream — 同步上游素材與更新 codebase-memory-mcp 索引

從 MCP C# SDK 的 GitHub 儲存庫與官方 conceptual docs 抓取最新素材，放入 `mcp-csharp-sdk-kb/raw/`，並對 `csharp-sdk/` 確認 codebase-memory-mcp 索引已同步。

> **project 名稱**：本檔所有 `project: "<csharp-sdk-project>"` 為 placeholder。每個 session 首次呼叫 codebase-memory-mcp 前，先以 `mcp__codebase-memory-mcp__list_projects` 取路徑以 `/csharp-sdk` 結尾的 project 名稱代入（名稱因機器而異，見工作區根 CLAUDE.md §6）。

## 執行步驟

1. **檢查 raw/ 現有內容**
   - 列出 `mcp-csharp-sdk-kb/raw/` 各子目錄的現有檔案
   - 記錄最後更新日期（從檔案的 YAML frontmatter 或檔名中取得）

2. **抓取 Release Notes**
   - 來源：`https://github.com/modelcontextprotocol/csharp-sdk/releases`
   - 抓取最新的 release notes（含 Breaking Changes 段落）
   - 存入 `mcp-csharp-sdk-kb/raw/release-notes/`，檔名格式：`v{version}.md`（如 `v1.4.0.md`）
   - 可用 `gh api`：
     ```bash
     gh api "repos/modelcontextprotocol/csharp-sdk/releases?per_page=10" \
       --jq '.[] | {tag: .tag_name, date: .published_at, name: .name}'
     ```

3. **抓取 Conceptual Docs**
   - 來源：`https://csharp.sdk.modelcontextprotocol.io/concepts/`（getting-started、tools、prompts、resources、transports、sessions、sampling、elicitation、authorization 等）
   - 對應 GitHub 來源：`https://github.com/modelcontextprotocol/csharp-sdk/tree/main/docs/concepts/`
   - 用 WebFetch 取得每篇 doc，存入 `mcp-csharp-sdk-kb/raw/docs-conceptual/`，檔名保持原名

4. **抓取 API Surface 摘要**
   - 來源：API 文件 `https://csharp.sdk.modelcontextprotocol.io/api/` 或 NuGet 套件公開 API
   - 更新 `mcp-csharp-sdk-kb/raw/api-surface/`，依套件分檔（Core / ModelContextProtocol / AspNetCore）

5. **抓取相關 DevBlog**
   - 來源：`https://devblogs.microsoft.com/dotnet/`（MCP C# SDK 版本發佈文章）
   - 存入 `mcp-csharp-sdk-kb/raw/devblogs/`

6. **檢查官方 Samples 更新**
   - 來源：`https://github.com/modelcontextprotocol/csharp-sdk/tree/main/samples`
   - 讀取 `mcp-csharp-sdk-kb/raw/samples/README.md` frontmatter 中的 `fetched` 與 `last_sync_version`
   - 用 `gh api` 取得 samples 目錄最新狀態：
     ```bash
     gh api "repos/modelcontextprotocol/csharp-sdk/contents/samples" \
       --jq '[.[] | select(.type == "dir") | .name]'
     ```
   - 對有變動的 sample 目錄，抓取 README 作為摘要素材
   - 更新 `raw/samples/README.md` 的 frontmatter（`fetched`、`last_sync_version`）與受影響段落

7. **更新上游 SDK 原始碼與 codebase-memory-mcp 索引**
   - `git -C csharp-sdk pull`（或 `git -C csharp-sdk fetch && git -C csharp-sdk checkout v<version>`）取得最新
   - **首次使用**需執行：
     ```
     mcp__codebase-memory-mcp__index_repository
       repo_path: "csharp-sdk"
     ```
     完成後用 `mcp__codebase-memory-mcp__list_projects` 確認 project 名稱（**為路徑全名，非字面 `csharp-sdk`**；取以 `/csharp-sdk` 結尾者，見 CLAUDE.md §6）
   - **後續同步**：file watcher 自動同步增量變更，git pull 後無需手動重索引

8. **codebase-memory-mcp 新 API 存在性確認**
   - 從本次 release notes 找出新增或改名的 API 名稱
   - 逐一 `search_graph`：
     ```
     mcp__codebase-memory-mcp__search_graph
       project: "<csharp-sdk-project>"
       name_pattern: "<新 API 名稱>"
     ```
   - 有結果代表上游原始碼已包含此 API，記錄確認清單作為 `/extract-facts` 的重點線索
   - 注意：`Microsoft.Extensions.AI.*`（`IChatClient`、`AIFunction`）為外部 NuGet，圖譜查無屬正常，改找使用端

9. **產出同步摘要**
   - 列出本次新增/更新的檔案清單
   - 標記哪些是新的 breaking change 相關素材
   - 附上步驟 8 的 API 存在性確認結果
   - 建議接下來執行 `/extract-facts <new-version>`

## 注意事項
- 新舊比對以 `mcp-csharp-sdk-kb/raw/` 的實際檔案為唯一基準，不參考對話歷史
- raw/ 是唯讀基準層，同步後不做任何修改
- `csharp-sdk/` 內任何檔案**不可改動**——它是上游唯讀基準層
- 教學目錄 `mcp-csharp-sdk-guide/` 不在同步範圍內
- 此指令**不呼叫 LLM 寫敘述**，純素材搬運與索引確認
- **`UPSTREAM-REF.md` 主表的 Tag 一旦更新，工作區層的基準宣告就會立刻變成 lint 失敗狀態**（`baseline-version` 規則）。本 skill 不修那些檔案；請在同一輪版本更新中以 `/update-tutorial` 步驟 4 或依 `PLAYBOOK-version-update.md` Step 9 補齊，不要把 lint 紅燈留到下一輪。
