#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { validateKnowledgeGraph } from "./validate-knowledge-graph.mjs";

const root = process.cwd();
const manifestPath = path.join(root, "validation", "manifest.json");
const errors = [];
const passes = [];

function fail(rule, file, message) {
  errors.push({ rule, file: path.relative(root, file) || ".", message });
}

function pass(message) {
  passes.push(message);
}

function read(file) {
  return fs.readFileSync(file, "utf8");
}

function listFiles(directory, predicate) {
  const files = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      files.push(...listFiles(fullPath, predicate));
    } else if (predicate(fullPath)) {
      files.push(fullPath);
    }
  }
  return files;
}

function stripFencedCode(text) {
  const lines = text.split(/\r?\n/);
  let inFence = false;
  return lines.map((line) => {
    if (/^\s*```/.test(line)) {
      inFence = !inFence;
      return "";
    }
    return inFence ? "" : line;
  }).join("\n");
}

function stripInlineCode(text) {
  return text.replace(/`[^`\n]*`/g, "");
}

function parseScalar(value) {
  const trimmed = value.trim();
  if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
    return trimmed.slice(1, -1);
  }
  if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
    const body = trimmed.slice(1, -1).trim();
    return body ? body.split(",").map((item) => parseScalar(item)) : [];
  }
  if (trimmed === "true") return true;
  if (trimmed === "false") return false;
  if (trimmed === "[]") return [];
  return trimmed;
}

function parseFrontmatter(file) {
  const text = read(file);
  const match = text.match(/^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);
  if (!match) {
    fail("frontmatter", file, "missing YAML frontmatter");
    return null;
  }
  const result = {};
  let listKey = null;
  for (const rawLine of match[1].split(/\r?\n/)) {
    const listMatch = rawLine.match(/^\s+-\s+(.+)$/);
    if (listMatch && listKey) {
      result[listKey].push(parseScalar(listMatch[1]));
      continue;
    }
    const keyMatch = rawLine.match(/^([A-Za-z_][A-Za-z0-9_-]*):\s*(.*)$/);
    if (!keyMatch) continue;
    const [, key, value] = keyMatch;
    if (value === "") {
      result[key] = [];
      listKey = key;
    } else {
      result[key] = parseScalar(value);
      listKey = null;
    }
  }
  return result;
}

function validateBaseline(manifest) {
  const guide = path.join(root, "mcp-csharp-sdk-guide");
  const reviews = path.join(guide, "reviews");
  const concepts = path.join(root, "mcp-csharp-sdk-kb", "wiki", "concepts");
  const chapters = fs.readdirSync(guide).filter((name) => /^\d{2}-.+\.md$/.test(name)).sort();
  const appendices = fs.readdirSync(guide).filter((name) => /^appendix-[a-d]-.+\.md$/.test(name)).sort();
  const reviewFiles = fs.readdirSync(reviews).filter((name) => name.endsWith(".md")).sort();
  const conceptFiles = fs.readdirSync(concepts).filter((name) => name.endsWith(".md")).sort();

  const expected = manifest.expected;
  if (chapters.length !== expected.chapters) fail("baseline", guide, `expected ${expected.chapters} chapters, found ${chapters.length}`);
  if (appendices.length !== expected.appendices) fail("baseline", guide, `expected ${expected.appendices} completed appendices, found ${appendices.length}`);
  if (reviewFiles.length !== expected.reviewMarkdownFiles) fail("baseline", reviews, `expected ${expected.reviewMarkdownFiles} review markdown files, found ${reviewFiles.length}`);
  if (conceptFiles.length !== expected.concepts) fail("baseline", concepts, `expected ${expected.concepts} concepts, found ${conceptFiles.length}`);

  const chapterNumbers = chapters.map((name) => Number(name.slice(0, 2)));
  const expectedNumbers = Array.from({ length: expected.chapters }, (_, index) => index + 1);
  if (JSON.stringify(chapterNumbers) !== JSON.stringify(expectedNumbers)) fail("baseline", guide, `chapter numbers must be contiguous 01-${String(expected.chapters).padStart(2, "0")}`);

  for (const chapter of chapters) {
    const review = `review-${chapter}`;
    if (!reviewFiles.includes(review)) fail("reviews", reviews, `missing ${review}`);
  }
  for (const required of ["README.md", "review-appendix-abc.md", "second-opinion-review-2026-07-16.md", "second-opinion-resolution-2026-07-16.md"]) {
    if (!reviewFiles.includes(required)) fail("reviews", reviews, `missing ${required}`);
  }

  const guideReadme = read(path.join(guide, "README.md"));
  for (const file of [...chapters, ...appendices]) {
    if (!guideReadme.includes(`./${file}`)) fail("guide-toc", path.join(guide, "README.md"), `missing link to ${file}`);
  }
  if (!guideReadme.includes("狀態：✅ **具備發佈條件**")) fail("release-status", path.join(guide, "README.md"), "release-ready status line is missing");

  const wikiIndex = read(path.join(root, "mcp-csharp-sdk-kb", "wiki", "INDEX.md"));
  for (const concept of conceptFiles) {
    const slug = concept.slice(0, -3);
    if (!wikiIndex.includes(`[[${slug}]]`)) fail("wiki-index", path.join(root, "mcp-csharp-sdk-kb", "wiki", "INDEX.md"), `missing [[${slug}]]`);
  }

  if (errors.length === 0) pass(`baseline counts: ${chapters.length} chapters, ${appendices.length} appendices, ${reviewFiles.length} reviews, ${conceptFiles.length} concepts`);
  return { chapters, appendices, reviewFiles, conceptFiles };
}

function validateMarkdownLinks(markdownFiles) {
  const linkPattern = /!?\[[^\]]*\]\(([^)]+)\)/g;
  for (const file of markdownFiles) {
    const text = stripFencedCode(read(file));
    for (const match of text.matchAll(linkPattern)) {
      let target = match[1].trim();
      if (target.startsWith("<") && target.endsWith(">")) target = target.slice(1, -1);
      target = target.split(/\s+["']/)[0];
      if (!target || target.startsWith("#") || /^(https?:|mailto:|data:)/i.test(target)) continue;
      const cleanTarget = target.split("#")[0].split("?")[0];
      let decoded = cleanTarget;
      try {
        decoded = decodeURIComponent(cleanTarget);
      } catch {
        fail("relative-link", file, `invalid URL encoding in ${target}`);
        continue;
      }
      const resolved = path.resolve(path.dirname(file), decoded);
      if (!fs.existsSync(resolved)) fail("relative-link", file, `missing target ${target}`);
    }
  }
  pass(`checked relative Markdown links in ${markdownFiles.length} files`);
}

function validateFences(markdownFiles) {
  for (const file of markdownFiles) {
    let inFence = false;
    let openingLine = 0;
    const lines = read(file).split(/\r?\n/);
    lines.forEach((line, index) => {
      const match = line.match(/^\s*```(.*)$/);
      if (!match) return;
      if (!inFence) {
        inFence = true;
        openingLine = index + 1;
        if (!match[1].trim()) fail("code-fence", file, `opening fence at line ${openingLine} has no language label`);
      } else {
        inFence = false;
      }
    });
    if (inFence) fail("code-fence", file, `unclosed fence opened at line ${openingLine}`);
  }
  pass(`checked fenced code blocks in ${markdownFiles.length} files`);
}

function validateWikiLinks(guideFiles, kbFiles, conceptFiles) {
  const conceptSlugs = new Set(conceptFiles.map((name) => name.slice(0, -3)));
  const wikiPattern = /\[\[([^\]]+)\]\]/g;
  for (const file of guideFiles) {
    const prose = stripInlineCode(stripFencedCode(read(file)));
    for (const match of prose.matchAll(wikiPattern)) fail("guide-wiki-link", file, `unconverted wiki link [[${match[1]}]]`);
  }
  for (const file of kbFiles) {
    const prose = stripInlineCode(stripFencedCode(read(file)));
    for (const match of prose.matchAll(wikiPattern)) {
      const target = match[1].split("|")[0].split("#")[0].trim();
      if (!conceptSlugs.has(target)) fail("kb-wiki-link", file, `missing concept [[${target}]]`);
    }
  }
  pass("checked guide and KB wiki-style link policy");
}

function validateConcepts(conceptFiles) {
  const kbRoot = path.join(root, "mcp-csharp-sdk-kb");
  const conceptRoot = path.join(kbRoot, "wiki", "concepts");
  const required = ["title", "api_name", "namespace", "package", "since", "current_version", "updated", "tags", "tutorial_chapters", "sources"];
  const factsReferenced = new Set();
  for (const name of conceptFiles) {
    const file = path.join(conceptRoot, name);
    const frontmatter = parseFrontmatter(file);
    if (!frontmatter) continue;
    for (const key of required) {
      if (!(key in frontmatter) || frontmatter[key] === "") fail("concept-frontmatter", file, `missing ${key}`);
    }
    if (!Array.isArray(frontmatter.tags) || frontmatter.tags.length === 0) fail("concept-frontmatter", file, "tags must contain at least one item");
    if (!Array.isArray(frontmatter.tutorial_chapters)) fail("concept-frontmatter", file, "tutorial_chapters must be an array");
    for (const chapter of frontmatter.tutorial_chapters || []) {
      if (/^appendix-[a-c]$/.test(String(chapter))) {
        const letter = String(chapter).slice(-1);
        const exists = fs.readdirSync(path.join(root, "mcp-csharp-sdk-guide")).some((entry) => entry.startsWith(`appendix-${letter}-`) && entry.endsWith(".md"));
        if (!exists) fail("tutorial-chapter", file, `missing guide appendix ${chapter}`);
        continue;
      }
      const match = String(chapter).match(/^ch(\d{2})$/);
      if (!match) {
        fail("tutorial-chapter", file, `invalid chapter reference ${chapter}`);
        continue;
      }
      const prefix = `${match[1]}-`;
      const exists = fs.readdirSync(path.join(root, "mcp-csharp-sdk-guide")).some((entry) => entry.startsWith(prefix) && entry.endsWith(".md"));
      if (!exists) fail("tutorial-chapter", file, `missing guide chapter ${chapter}`);
    }
    if (!Array.isArray(frontmatter.sources)) fail("concept-frontmatter", file, "sources must be an array");
    for (const source of frontmatter.sources || []) {
      const sourceText = String(source);
      if (/^https?:/.test(sourceText)) continue;
      const resolved = sourceText.startsWith("csharp-sdk/") ? path.join(root, sourceText) : path.join(kbRoot, sourceText);
      if (!fs.existsSync(resolved)) fail("concept-source", file, `missing source ${sourceText}`);
      if (sourceText.startsWith("raw/facts/") && sourceText.endsWith(".json")) factsReferenced.add(path.join(kbRoot, sourceText));
    }
    const text = read(file);
    const overviewAlternatives = {
      "sessions.md": "## 模式對照",
      "what-is-mcp.md": "## 協定概念"
    };
    const overviewHeading = overviewAlternatives[name] || "## 概述";
    const headings = [overviewHeading, "## 變更歷史", "## 教學章節對應", "## 相關概念"];
    for (const heading of headings) {
      if (!text.includes(heading)) fail("concept-sections", file, `missing ${heading}`);
    }
    if (!String(frontmatter.api_name).includes("N/A") && !text.includes("## 目前 API 簽名")) fail("concept-sections", file, "API concept missing ## 目前 API 簽名");
  }
  pass(`checked frontmatter, sources, and tutorial mappings for ${conceptFiles.length} concepts`);
  return factsReferenced;
}

function validateFacts(factsReferenced) {
  const factsRoot = path.join(root, "mcp-csharp-sdk-kb", "raw", "facts");
  const jsonFiles = fs.readdirSync(factsRoot).filter((name) => name.endsWith(".json")).map((name) => path.join(factsRoot, name));
  const parsedFiles = new Set();
  function inspect(value, file, pointer = "$") {
    if (Array.isArray(value)) {
      value.forEach((item, index) => inspect(item, file, `${pointer}[${index}]`));
      return;
    }
    if (!value || typeof value !== "object") return;
    if (value.verified === true) {
      for (const key of ["name", "namespace", "package", "file_path"]) {
        if (typeof value[key] !== "string" || value[key].length === 0) fail("verified-fact", file, `${pointer} missing ${key}`);
      }
    }
    for (const [key, child] of Object.entries(value)) inspect(child, file, `${pointer}.${key}`);
  }
  for (const file of jsonFiles) {
    try {
      const value = JSON.parse(read(file));
      parsedFiles.add(file);
      inspect(value, file);
    } catch (error) {
      fail("facts-json", file, error.message);
    }
  }
  for (const file of factsReferenced) {
    if (!parsedFiles.has(file)) fail("facts-reference", file, "referenced facts file was not parsed");
  }
  pass(`parsed ${jsonFiles.length} facts JSON files and checked verified records`);
}

// 基準版本宣告一致性：以 UPSTREAM-REF.md 主表的 Tag 為 ground truth，
// 確保工作區層的「目前基準」敘述不會停留在舊版本（歷史記錄段落除外）。
const BASELINE_DECLARATION_DOCS = [
  { file: "README.md" },
  { file: "SETUP.md" },
  { file: "CLAUDE.md" },
  { file: "AGENTS.md" },
  { file: "CODEX-HANDOFF-PLAN.md", headerOnly: true },
  { file: path.join("mcp-csharp-sdk-kb", "README.md") },
  { file: path.join("mcp-csharp-sdk-kb", "QuickStart.md") },
  { file: path.join("mcp-csharp-sdk-kb", "UPSTREAM-REF.md") },
  { file: path.join("mcp-csharp-sdk-kb", "WORKFLOW-DESIGN-v1.md") },
  { file: path.join("mcp-csharp-sdk-kb", "PLAYBOOK-version-update.md"), declarationsOnly: true },
  { file: path.join("mcp-csharp-sdk-guide", "README.md") },
];

const BASELINE_DECLARATION_PATTERN = /基準版本|內容基準|知識庫基準|對齊|git checkout/;
const HISTORY_HEADING_PATTERN = /^(#{1,6})\s+.*(歷史記錄|歷次執行記錄|History)/;
const VERSION_TOKEN_PATTERN = /\bv?\d+\.\d+\.\d+\b/;

// 丟掉歷史記錄段落（該段標題到下一個同級或更高級標題之間），這些行本來就該保留舊版本號。
function stripHistorySections(text) {
  const kept = [];
  let historyLevel = 0;
  for (const line of text.split("\n")) {
    const heading = /^(#{1,6})\s+/.exec(line);
    if (heading) {
      const level = heading[1].length;
      if (historyLevel > 0 && level <= historyLevel) historyLevel = 0;
      if (historyLevel === 0 && HISTORY_HEADING_PATTERN.test(line)) {
        historyLevel = level;
        continue;
      }
    }
    if (historyLevel === 0) kept.push(line);
  }
  return kept.join("\n");
}

function validateBaselineVersion() {
  const upstreamRef = path.join(root, "mcp-csharp-sdk-kb", "UPSTREAM-REF.md");
  if (!fs.existsSync(upstreamRef)) {
    fail("baseline-version", upstreamRef, "UPSTREAM-REF.md is missing; cannot resolve the baseline tag");
    return;
  }
  const tagMatch = /\|\s*\*\*Tag\*\*\s*\|\s*`(v\d+\.\d+\.\d+)`\s*\|/.exec(read(upstreamRef));
  if (!tagMatch) {
    fail("baseline-version", upstreamRef, "could not parse the `| **Tag** | `vX.Y.Z` |` row");
    return;
  }
  const tag = tagMatch[1];
  const bare = tag.slice(1);

  let checked = 0;
  for (const { file, headerOnly, declarationsOnly } of BASELINE_DECLARATION_DOCS) {
    const fullPath = path.join(root, file);
    if (!fs.existsSync(fullPath)) {
      fail("baseline-version", fullPath, "declared baseline document is missing");
      continue;
    }
    let text = stripHistorySections(read(fullPath));
    if (headerOnly) text = text.split(/^##\s+/m)[0];
    checked += 1;

    if (!declarationsOnly && !text.includes(bare)) {
      fail("baseline-version", fullPath, `does not mention the current baseline ${tag} outside history sections`);
    }
    for (const [index, line] of text.split("\n").entries()) {
      if (!BASELINE_DECLARATION_PATTERN.test(line)) continue;
      if (!VERSION_TOKEN_PATTERN.test(line)) continue;
      if (line.includes(bare)) continue;
      fail("baseline-version", fullPath, `line ${index + 1} declares a baseline without ${tag}: ${line.trim().slice(0, 120)}`);
    }
  }
  pass(`checked baseline ${tag} declarations in ${checked} workspace documents`);
}

function validateState(markdownFiles) {
  const stalePhrases = ["骨架階段", "待首次 compile", "尚未驗證"];
  const stateFiles = markdownFiles.filter((file) => path.basename(file) !== "CODEX-HANDOFF-PLAN.md" && (path.dirname(file) === root || ["README.md", "QuickStart.md", "WORKFLOW-DESIGN-v1.md", "UPSTREAM-REF.md", "PLAYBOOK-version-update.md"].includes(path.basename(file))));
  for (const file of stateFiles) {
    const prose = stripFencedCode(read(file));
    for (const phrase of stalePhrases) {
      if (prose.includes(phrase)) fail("stale-state", file, `contains ${phrase}`);
    }
  }
  pass(`checked stale state phrases in ${stateFiles.length} status files`);
}

function validateGraph(manifest) {
  const graphDirectory = path.join(root, "mcp-csharp-sdk-kb", "wiki", ".understand-anything");
  const graphFile = path.join(graphDirectory, "knowledge-graph.json");
  const report = validateKnowledgeGraph({
    graphDirectory,
    wikiDirectory: path.join(root, "mcp-csharp-sdk-kb", "wiki"),
    augmentationFile: path.join(root, "mcp-csharp-sdk-kb", "wiki", "graph-augmentations.json"),
    repositoryRoot: root,
  });
  for (const message of report.errors || []) fail("knowledge-graph", graphFile, message);
  const expected = manifest.knowledgeGraph || {};
  if (report.counts) {
    for (const key of ["nodes", "edges", "layers", "tourSteps", "articles", "augmentationNodes"]) {
      if (expected[key] !== undefined && report.counts[key] !== expected[key]) {
        fail("knowledge-graph", graphFile, `expected ${key}=${expected[key]}, found ${report.counts[key]}`);
      }
    }
  }
  if (report.ok && report.counts && !(report.errors || []).length) {
    pass(`validated knowledge graph: ${report.counts.nodes} nodes, ${report.counts.edges} edges, ${report.counts.articles} articles`);
  }
}

function main() {
  if (!fs.existsSync(manifestPath)) {
    fail("manifest", manifestPath, "validation manifest is missing");
  }
  let manifest = { expected: {} };
  try {
    manifest = JSON.parse(read(manifestPath));
  } catch (error) {
    fail("manifest", manifestPath, error.message);
  }

  const baseline = validateBaseline(manifest);
  const rootMarkdown = fs.readdirSync(root).filter((name) => name.endsWith(".md") && name !== "CLAUDE.md").map((name) => path.join(root, name));
  const guideRoot = path.join(root, "mcp-csharp-sdk-guide");
  const kbRoot = path.join(root, "mcp-csharp-sdk-kb");
  const guideFiles = listFiles(guideRoot, (file) => file.endsWith(".md"));
  const kbFiles = listFiles(kbRoot, (file) => file.endsWith(".md") && !file.includes(`${path.sep}raw${path.sep}`));
  const markdownFiles = [...rootMarkdown, ...guideFiles, ...kbFiles];

  validateMarkdownLinks(markdownFiles);
  validateFences(markdownFiles);
  validateWikiLinks(guideFiles, kbFiles, baseline.conceptFiles || []);
  const factsReferenced = validateConcepts(baseline.conceptFiles || []);
  validateFacts(factsReferenced);
  validateState(markdownFiles);
  validateBaselineVersion();
  validateGraph(manifest);

  if (errors.length > 0) {
    console.error(`Documentation lint failed with ${errors.length} error(s):`);
    for (const error of errors) console.error(`- [${error.rule}] ${error.file}: ${error.message}`);
    process.exitCode = 1;
    return;
  }

  console.log(`Documentation lint passed (${passes.length} groups):`);
  for (const message of passes) console.log(`- ${message}`);
}

main();
