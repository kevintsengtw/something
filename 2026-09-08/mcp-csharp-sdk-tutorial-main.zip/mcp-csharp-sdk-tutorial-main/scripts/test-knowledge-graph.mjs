#!/usr/bin/env node

import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import process from "node:process";
import { buildKnowledgeGraph } from "./build-knowledge-graph.mjs";
import { safePublish } from "./publish-knowledge-graph.mjs";
import { validateKnowledgeGraph } from "./validate-knowledge-graph.mjs";

const root = process.cwd();
const wiki = path.join(root, "mcp-csharp-sdk-kb", "wiki");
const augmentations = path.join(wiki, "graph-augmentations.json");
const baseline = path.join(wiki, ".understand-anything", "knowledge-graph.json");
const temporaryRoot = fs.mkdtempSync(path.join(os.tmpdir(), "mcp-csharp-sdk-graph-test-"));
const first = path.join(temporaryRoot, "first");
const second = path.join(temporaryRoot, "second");
const timestamp = "2026-07-18T00:00:00.000Z";

try {
  buildKnowledgeGraph({ wikiDirectory: wiki, outputDirectory: first, augmentationFile: augmentations, timestamp, repositoryRoot: root });
  buildKnowledgeGraph({ wikiDirectory: wiki, outputDirectory: second, augmentationFile: augmentations, timestamp, repositoryRoot: root });

  assert.equal(fs.readFileSync(path.join(first, "knowledge-graph.json"), "utf8"), fs.readFileSync(path.join(second, "knowledge-graph.json"), "utf8"));
  assert.equal(fs.readFileSync(path.join(first, "meta.json"), "utf8"), fs.readFileSync(path.join(second, "meta.json"), "utf8"));

  const valid = validateKnowledgeGraph({
    graphDirectory: first,
    wikiDirectory: wiki,
    augmentationFile: augmentations,
    baselineFile: baseline,
    repositoryRoot: root,
  });
  assert.equal(valid.ok, true, valid.errors?.join("\n"));
  assert.equal(valid.orphanNodes.length, 0);
  assert.equal(valid.counts.nodeTypes.article, 35);
  assert.equal(valid.counts.nodeTypes.entity, 39);
  assert.equal(valid.counts.nodeTypes.claim, 25);

  const brokenGraphFile = path.join(second, "knowledge-graph.json");
  const broken = JSON.parse(fs.readFileSync(brokenGraphFile, "utf8"));
  broken.edges.push({ source: "article:missing", target: broken.nodes[0].id, type: "related", direction: "forward", weight: 0.7 });
  fs.writeFileSync(brokenGraphFile, `${JSON.stringify(broken, null, 2)}\n`);
  const invalid = validateKnowledgeGraph({
    graphDirectory: second,
    wikiDirectory: wiki,
    augmentationFile: augmentations,
    baselineFile: baseline,
    repositoryRoot: root,
  });
  assert.equal(invalid.ok, false);
  assert.ok(invalid.errors.some((error) => error.includes("Dangling edge source")));

  const publishTarget = path.join(temporaryRoot, "publish-target");
  fs.mkdirSync(publishTarget);
  fs.copyFileSync(baseline, path.join(publishTarget, "knowledge-graph.json"));
  fs.copyFileSync(path.join(wiki, ".understand-anything", "meta.json"), path.join(publishTarget, "meta.json"));
  const beforeFailedPublish = {
    graph: fs.readFileSync(path.join(publishTarget, "knowledge-graph.json"), "utf8"),
    meta: fs.readFileSync(path.join(publishTarget, "meta.json"), "utf8"),
  };
  const incompleteSource = path.join(temporaryRoot, "incomplete-source");
  fs.mkdirSync(incompleteSource);
  fs.copyFileSync(path.join(first, "knowledge-graph.json"), path.join(incompleteSource, "knowledge-graph.json"));
  assert.throws(() => safePublish({ sourceDirectory: incompleteSource, targetDirectory: publishTarget }));
  assert.equal(fs.readFileSync(path.join(publishTarget, "knowledge-graph.json"), "utf8"), beforeFailedPublish.graph);
  assert.equal(fs.readFileSync(path.join(publishTarget, "meta.json"), "utf8"), beforeFailedPublish.meta);

  safePublish({ sourceDirectory: first, targetDirectory: publishTarget });
  assert.equal(fs.readFileSync(path.join(publishTarget, "knowledge-graph.json"), "utf8"), fs.readFileSync(path.join(first, "knowledge-graph.json"), "utf8"));
  assert.equal(fs.readFileSync(path.join(publishTarget, "meta.json"), "utf8"), fs.readFileSync(path.join(first, "meta.json"), "utf8"));

  console.log(`Knowledge graph tests passed: reproducible build, valid baseline migration, dangling-edge rejection, publisher rollback (${valid.counts.nodes} nodes / ${valid.counts.edges} edges).`);
} finally {
  fs.rmSync(temporaryRoot, { recursive: true, force: true });
}
