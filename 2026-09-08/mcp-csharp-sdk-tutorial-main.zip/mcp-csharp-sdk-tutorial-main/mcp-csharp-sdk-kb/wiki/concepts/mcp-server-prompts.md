---
title: MCP Server 提示（Prompts）
api_name: McpServerPrompt
namespace: ModelContextProtocol.Server
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 2.2.0
updated: 2026-09-04
tags: [server, prompts, attribute, primitive, completion]
tutorial_chapters: [ch06]
sources:
  - raw/docs-conceptual/prompts.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - csharp-sdk/src/ModelContextProtocol.Core/Server/McpServerPromptAttribute.cs
  - csharp-sdk/src/ModelContextProtocol/McpServerBuilderExtensions.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/GetPromptResult.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/PromptMessage.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/Prompt.cs
  - csharp-sdk/samples/EverythingServer/Prompts/SimplePromptType.cs
  - csharp-sdk/samples/EverythingServer/Prompts/ComplexPromptType.cs
---

## 概述

Prompts 是 MCP 的「可重用範本」primitive，供客戶端取得結構化、可帶參數的訊息範本。定義方式與 tools 對稱：在類別上標 `[McpServerPromptType]`、在方法上標 `[McpServerPrompt]`，以 `WithPromptsFromAssembly()` 或 `WithPrompts<T>()` 註冊。回傳通常為 `ChatMessage` 或字串，參數可帶 `[Description]`，並可用 `AllowedValuesAttribute`（.NET BCL）自動產生補全。

> `McpServerPrompt`（`abstract class : IMcpServerPrimitive`）、`McpServerPromptAttribute`、`McpServerPromptTypeAttribute` 皆 namespace `ModelContextProtocol.Server`、套件 **.Core**。`WithPrompts` / `WithPromptsFromAssembly` 為 builder 擴充方法，namespace `Microsoft.Extensions.DependencyInjection`、屬 **ModelContextProtocol** 套件。回傳/協定型別 `GetPromptResult` / `PromptMessage` / `Prompt` 皆 namespace `ModelContextProtocol.Protocol`、套件 **.Core**。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Server;
using Microsoft.Extensions.AI;            // ChatMessage（外部 Microsoft.Extensions.AI）
using System.ComponentModel;

[McpServerPromptType]
public static class MyPrompts
{
    [McpServerPrompt, Description("產生一段摘要提示")]
    public static ChatMessage Summarize([Description("要摘要的內容")] string content)
        => new(ChatRole.User, $"請摘要以下內容：\n{content}");
}

// 註冊
builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithPromptsFromAssembly();
```

> `ChatMessage` / `ChatRole` 來自外部 NuGet `Microsoft.Extensions.AI`（圖譜無此節點，屬正常）。

---

## Prompts 進階（ch06）

以下面向對應第 06 章，API 已逐筆經 codebase-memory-mcp + `csharp-sdk/src` 驗證（見 `raw/facts/v1.4.0-api-inventory.json`）。

### 1. 定義：無參數 / 有參數

最小 prompt 回傳一段字串；帶參數的 prompt 在參數上加 `[Description]`（`System.ComponentModel`，.NET BCL）。

```csharp
// 取自 samples/EverythingServer/Prompts/SimplePromptType.cs
[McpServerPrompt(Name = "simple_prompt"), Description("A prompt without arguments")]
public static string SimplePrompt() => "This is a simple prompt without arguments";

// 取自 samples/EverythingServer/Prompts/ComplexPromptType.cs
[McpServerPrompt(Name = "complex_prompt"), Description("A prompt with arguments")]
public static IEnumerable<ChatMessage> ComplexPrompt(
    [Description("Temperature setting")] int temperature,
    [Description("Output style")] string? style = null)
    => [ /* 多則 ChatMessage，見下 */ ];
```

> `[McpServerPrompt]` 可設 `Name`（覆寫 prompt 名）、`Title`、`IconSource` 等屬性（與 `[McpServerTool]` 對稱）。有預設值的參數為選填。

### 2. 回傳型別

| 回傳 | 結果 |
|------|------|
| `string` | 單則 user 訊息 |
| `ChatMessage`（Microsoft.Extensions.AI） | 單則訊息，指定 `ChatRole` |
| `IEnumerable<ChatMessage>` | 多則訊息（可含 user/assistant 交錯、圖片等） |
| `GetPromptResult` | 完全掌控結果（`Description` + `IList<PromptMessage> Messages`）|

`GetPromptResult`（`sealed class : Result`）與 `PromptMessage`（`sealed class`，`required ContentBlock Content` + `required Role Role`）皆為 protocol 層型別（ns `ModelContextProtocol.Protocol`）。回傳 `ChatMessage` 時 SDK 會自動轉為 `PromptMessage`；要精準控制協定輸出時可直接組 `GetPromptResult`。

```csharp
// 取自 ComplexPromptType.cs：多則訊息、user/assistant 交錯、含圖片
return
[
    new ChatMessage(ChatRole.User, $"temperature={temperature}, style={style}"),
    new ChatMessage(ChatRole.Assistant, "I understand. How would you like me to proceed?"),
    new ChatMessage(ChatRole.User, [new DataContent(TinyImageTool.MCP_TINY_IMAGE)]),
];
```

### 3. 參數補全（Completion）

在 prompt 參數上加 `AllowedValuesAttribute`（`System.ComponentModel.DataAnnotations`，.NET BCL）時，SDK 會自動為該參數提供 completion——client 徵詢參數值時可得候選清單（自 1.1.0, #1380）。詳見 [[logging-and-completion]]。

### 4. 註冊

| 擴充方法 | 用途 |
|---------|------|
| `WithPromptsFromAssembly()` | 掃描組件註冊所有 `[McpServerPromptType]` |
| `WithPrompts<T>()` / `WithPrompts(IEnumerable<Type>)` / `WithPrompts(IEnumerable<McpServerPrompt>)` | 指定類別/型別/實例註冊 |

### 5. 參數注入

與 tools 一致：prompt 方法可注入 `McpServer`、`RequestContext<GetPromptRequestParams>`、`CancellationToken` 與 DI 服務，這些不會出現在 prompt 的參數清單中（見 [[mcp-server-tools]] 的注入判定機制）。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（attribute 式 prompts）|
| 1.1.0 | 2026-03-06 | prompt 參數上的 `AllowedValuesAttribute` 自動補全（#1380）|
| 1.4.0 | 2026-06-04 | 前一穩定基準 |

## 教學章節對應
- 第 06 章：定義 Prompts（無參/有參）、參數與 `[Description]`、補全（`AllowedValuesAttribute`）、回傳型別（`string` / `ChatMessage` / `IEnumerable<ChatMessage>` / `GetPromptResult` + `PromptMessage`）、註冊（`WithPromptsFromAssembly` / `WithPrompts`）、參數注入

## 相關概念
- [[mcp-server-tools]]
- [[mcp-server-resources]]
- [[logging-and-completion]]
- [[mef-ai-integration]]
