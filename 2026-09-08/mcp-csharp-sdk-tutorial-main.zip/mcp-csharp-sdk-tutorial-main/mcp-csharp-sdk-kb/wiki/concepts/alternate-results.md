---
title: 替代結果（Result or Alternate）
api_name: ResultOrAlternate<TResult>
namespace: ModelContextProtocol.Protocol
package: ModelContextProtocol.Core
since: 2.0.0
current_version: 2.2.0
updated: 2026-09-04
tags: [protocol, extensibility, result, experimental]
tutorial_chapters: [ch17]
sources:
  - raw/docs-conceptual/mrtr.md
  - raw/docs-conceptual/tasks.md
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.0.0.md
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/ResultOrAlternate.cs
  - csharp-sdk/src/ModelContextProtocol.Extensions.Tasks/Server/McpTasksBuilderExtensions.cs
---

## 概述

`ResultOrAlternate<TResult>` 讓 request handler 回傳標準結果或由 extension 定義的另一種結果形狀，供 Tasks、MRTR 等擴充協定組合處理。此型別在 v2.0.0 標記為 Experimental，診斷 ID 為 `MCPEXP002`。

需要使用時應在最小程式碼範圍抑制 `MCPEXP002`，並避免把目前形狀視為長期穩定契約。

## 目前 API 簽名

```csharp
[Experimental("MCPEXP002")]
public class ResultOrAlternate<TResult> where TResult : Result
{
    public static ResultOrAlternate<TResult> FromAlternate<TAlternate>(
        TAlternate alternate,
        JsonTypeInfo<TAlternate> alternateTypeInfo)
        where TAlternate : Result;
}
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 2.0.0 | 2026-07-28 | 新增 experimental extensibility result（MCPEXP002）|

## 教學章節對應

- 第 17 章：`ResultOrAlternate<TResult>` 的形狀、隱式轉換與 `MCPEXP002` 抑制範圍；一般 Tasks 應用碼由 `WithTasks` 包住不會直接碰到

## 相關概念

- [[tasks]]
- [[multi-round-trip-requests]]
