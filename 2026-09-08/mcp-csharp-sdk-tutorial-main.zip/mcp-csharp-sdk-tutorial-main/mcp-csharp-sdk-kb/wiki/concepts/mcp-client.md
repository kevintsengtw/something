---
title: 建立 MCP Client
api_name: McpClient
namespace: ModelContextProtocol.Client
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 2.2.0
updated: 2026-09-04
tags: [client, transport, primitive]
tutorial_chapters: [ch10]
sources:
  - raw/docs-conceptual/getting-started.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/facts/v2.0.0-verified-changes.json
  - raw/facts/v2.1.0-verified-changes.json
  - raw/release-notes/v2.1.0.md
  - csharp-sdk/src/ModelContextProtocol.Core/Client/McpClient.Methods.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Client/McpClient.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Client/McpClientImpl.cs
  - csharp-sdk/tests/ModelContextProtocol.Tests/Client/McpClientAddKnownToolsTests.cs
  - csharp-sdk/tests/ModelContextProtocol.Tests/Client/July2026ProtocolFallbackTests.cs
---

## 概述

MCP Client 可連接「任何」相容的 MCP server，不限於本 SDK 建立的伺服器（協定 server-agnostic）。以 `McpClient.CreateAsync(transport)` 建立並連線，之後用 `ListToolsAsync` / `CallToolAsync` / `ListResourcesAsync` 等操作伺服器。傳輸層以 `StdioClientTransport`（啟動子行程）或 HTTP client transport 提供。`McpClient` 為 `abstract partial class : McpSession`，namespace `ModelContextProtocol.Client`，屬 `ModelContextProtocol.Core` 套件。

v2.0.0 新增 `AddKnownTools`、`RemoveKnownTools` 與 `ClearKnownTools`，可預先填入或調整 client 的已知工具快取；`McpClientOptions.InitializeMeta` 則可在 initialize request 附帶 meta。discovery-first negotiation 與結果快取提示見 [[result-caching]]。

v2.1.0 改善 discovery-first fallback：若 `server/discover` probe 在 HTTP 層收到無結構化 JSON-RPC error 的 `400 Bad Request` 或 `404 Not Found`，client 會改走舊版 `initialize` handshake；其他 HTTP status 仍直接回報，避免掩蓋真正的 transport failure。

> 入口確認：repo 已**無** `McpClientFactory`；建立入口為 `McpClient.CreateAsync`（取代舊版 `McpClientFactory.CreateAsync`）。較舊範例使用 `McpClientFactory` 是 `/drift-check` 要抓的典型 Breaking。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;

var clientTransport = new StdioClientTransport(new StdioClientTransportOptions
{
    Name = "Everything",
    Command = "npx",
    Arguments = ["-y", "@modelcontextprotocol/server-everything"],
});

var client = await McpClient.CreateAsync(clientTransport);

foreach (var tool in await client.ListToolsAsync())
    Console.WriteLine($"{tool.Name} ({tool.Description})");

var result = await client.CallToolAsync(
    "echo",
    new Dictionary<string, object?> { ["message"] = "Hello MCP!" },
    cancellationToken: CancellationToken.None);

// v2.0.0：預先填入或維護已知工具快取
client.AddKnownTools(knownTools);
client.RemoveKnownTools(["retired-tool"]);
client.ClearKnownTools();
```

驗證簽名（codebase-memory-mcp）：
```csharp
public static Task<McpClient> CreateAsync(
    IClientTransport clientTransport,
    McpClientOptions? clientOptions = null,
    ILoggerFactory? loggerFactory = null,
    CancellationToken cancellationToken = default)
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（建立入口為 `McpClient.CreateAsync`）|
| 1.1.0 | 2026-03-06 | client completion details（連線結束原因）|
| 1.3.0 | 2026-05-08 | SSE/HTTP 連線失敗改以 `ClientTransportClosedException`（derives `IOException`）回報 |
| 1.4.0 | 2026-06-04 | 前一穩定基準 |
| 2.0.0 | 2026-07-28 | 新增 known-tools 快取管理 API、`InitializeMeta` 與 discovery-first negotiation |
| 2.1.0 | 2026-08-05 | `server/discover` probe 收到 HTTP 400/404 時可回退至 `initialize` handshake |

## 教學章節對應
- 第 10 章：建立 MCP Client、列出與呼叫工具、讀取資源

## 相關概念
- [[mcp-client-tools]]
- [[mcp-client-resources]]
- [[stdio-transport]]
- [[mef-ai-integration]]
- [[result-caching]]
- [[multi-round-trip-requests]]
