---
title: Sampling（伺服器向客戶端請求 LLM 補全）
api_name: SamplingCapability
namespace: ModelContextProtocol.Protocol
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 2.2.0
updated: 2026-08-03
tags: [sampling, capability, ai-integration, advanced]
tutorial_chapters: [ch14]
sources:
  - raw/docs-conceptual/sampling.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.0.0.md
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/SamplingCapability.cs
  - csharp-sdk/src/ModelContextProtocol.Core/AIContentExtensions.cs
---

## 概述

Sampling 讓 **server 反向向 client 請求 LLM 補全**——server 不需自帶模型，而是請持有 `IChatClient` 的 client 代為推論。Client 在建立時宣告 sampling capability 並提供 handler；最簡單的方式是用 `AIContentExtensions.CreateSamplingHandler(chatClient)` 將外部 `IChatClient`（Microsoft.Extensions.AI）包成 handler。

> `SamplingCapability` namespace `ModelContextProtocol.Protocol`、套件 .Core；`CreateSamplingHandler` 為 `AIContentExtensions` 的擴充方法（套件 .Core），接收外部 `IChatClient`（圖譜無此節點，屬正常）。

## 目前 API 簽名

```csharp
using Microsoft.Extensions.AI;       // IChatClient（外部 NuGet）
using ModelContextProtocol;          // CreateSamplingHandler（AIContentExtensions，根 namespace）
using ModelContextProtocol.Client;

IChatClient chatClient = /* 你的 LLM client */;

var client = await McpClient.CreateAsync(transport, new McpClientOptions
{
    Handlers = new McpClientHandlers
    {
        SamplingHandler = chatClient.CreateSamplingHandler(),
    },
});
```

> v1.4.0 實況（原始檔確認，2026-07-16）：handler 掛在 **`McpClientOptions.Handlers.SamplingHandler`**
>（`Client/McpClientHandlers.cs`），SDK 於初始化時自動宣告 sampling capability（`McpClientImpl` 中
> `_options.Capabilities.Sampling ??= new()`）。`SamplingCapability` 本身只有 `Context`/`Tools`
> 兩個子 capability 屬性，**沒有** `SamplingHandler`——舊寫法已不適用。server 端由
> `McpServer.SampleAsync`（兩多載）與 `AsSamplingChatClient()` 發起請求。

> v2.0.0：`McpServer.AsSamplingChatClient()` 已標記 `[Obsolete]`，診斷 ID 為 `MCP9005`。既有程式仍可能編譯，但升級檢查應將警告視為遷移訊號。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（sampling capability + `CreateSamplingHandler`）|
| 1.4.0 | 2026-06-04 | 前一穩定基準 |
| 2.0.0 | 2026-07-28 | `McpServer.AsSamplingChatClient()` 廢棄（MCP9005）|

## 教學章節對應
- 第 14 章：Sampling——server 借用 client 的 LLM

## 相關概念
- [[mef-ai-integration]]
- [[elicitation]]
- [[mcp-client]]
