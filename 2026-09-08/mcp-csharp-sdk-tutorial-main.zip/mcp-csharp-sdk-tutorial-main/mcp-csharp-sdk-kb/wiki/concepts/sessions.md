---
title: Session 設計（Stateless vs Stateful）
api_name: N/A (stateless/stateful 設計)
namespace: ModelContextProtocol.AspNetCore
package: ModelContextProtocol.AspNetCore
since: 1.0.0
current_version: 2.2.0
updated: 2026-08-15
tags: [protocol-concept, sessions, http, aspnetcore]
tutorial_chapters: [ch08, ch12]
sources:
  - raw/docs-conceptual/stateless.md
  - raw/api-surface/ModelContextProtocol.AspNetCore.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/release-notes/v1.2.0.md
  - raw/release-notes/v2.0.0.md
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.2.0.md
  - raw/facts/v2.2.0-verified-changes.json
  - csharp-sdk/src/ModelContextProtocol.AspNetCore/HttpServerSessionMode.cs
  - csharp-sdk/src/ModelContextProtocol.AspNetCore/HttpServerTransportOptions.cs
  - csharp-sdk/tests/ModelContextProtocol.AspNetCore.Tests/HttpServerTransportOptionsTests.cs
  - csharp-sdk/tests/ModelContextProtocol.AspNetCore.Tests/July2026ProtocolHybridSessionModeTests.cs
---

## 模式對照

HTTP server 可透過 `HttpServerTransportOptions.SessionMode` 選擇三種 session 策略：

| 模式 | `SessionMode` | 特性 | 適用 |
|------|---------------|------|------|
| **Stateless**（無狀態）| `HttpServerSessionMode.Stateless`（預設）| 每請求獨立、易水平擴展、無 session-only 主動通知 | 雲端、serverless、無狀態水平擴展 |
| **Stateful**（有狀態）| `HttpServerSessionMode.Stateful` | initialize client 維持長期 session；2026-07-28 request 會被拒絕以觸發降版 | 所有 client 都必須使用 session 功能 |
| **Hybrid**（混合）| `HttpServerSessionMode.StatefulForInitializeClients` | initialize client 使用 session，2026-07-28 client 在同一 endpoint 以 stateless request 運作 | 漸進遷移與新舊 client 並存 |

v2.0.0 將 stateless 設為預設並採 discovery-first negotiation。v2.2.0 新增混合模式；原有 `Stateless` 布林屬性保留為 `SessionMode` 的相容 proxy，但無法表示混合模式。

> 這些屬性都在 `HttpServerTransportOptions`（namespace `ModelContextProtocol.AspNetCore`、套件 .AspNetCore）。

## 目前 API 簽名

N/A — 本條目為設計概念。關鍵設定型別見 `HttpServerTransportOptions`（[[transport-security]]、[[streamable-http-transport]]）。

```csharp
builder.Services.AddMcpServer()
    .WithHttpTransport(o =>
    {
        o.SessionMode = HttpServerSessionMode.Stateless;
        // o.EnableLegacySse = false;  // 預設停用（MCP9004）
    });
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | `RunSessionHandler` 標記 Experimental（MCPEXP002），建議改 `ConfigureSessionOptions` |
| 1.2.0 | 2026-03-27 | 新增 stateless 文件、預設偏好 stateless、預設停用 legacy SSE |
| 1.3.0 | 2026-05-08 | 修正 stateless 誤報 listChanged capability |
| 1.4.0 | 2026-06-04 | 前一穩定基準 |
| 2.0.0 | 2026-07-28 | **Breaking 預設值**：`Stateless = true`；採 discovery-first negotiation |
| 2.2.0 | 2026-08-13 | 新增 `HttpServerSessionMode`、`SessionMode` 與 `StatefulForInitializeClients` 混合模式；`Stateless` 保留為相容 proxy |

## 教學章節對應
- 第 08 章：session 模式概念
- 第 12 章：HTTP 部署的 stateless/stateful 取捨

## 相關概念
- [[streamable-http-transport]]
- [[http-server-session-mode]]
- [[aspnetcore-hosting]]
- [[transport-security]]
- [[notifications-progress]]
- [[result-caching]]
