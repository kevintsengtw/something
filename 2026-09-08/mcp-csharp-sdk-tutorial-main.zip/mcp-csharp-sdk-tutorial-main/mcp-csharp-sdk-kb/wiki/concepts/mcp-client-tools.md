---
title: MCP Client 工具（Client Tools）
api_name: McpClientTool
namespace: ModelContextProtocol.Client
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 2.2.0
updated: 2026-08-03
tags: [client, tools, ai-integration]
tutorial_chapters: [ch10, ch16]
sources:
  - raw/docs-conceptual/getting-started.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/facts/v2.0.0-verified-changes.json
  - csharp-sdk/src/ModelContextProtocol.Core/Client/McpClientTool.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Client/McpClient.Methods.cs
---

## 概述

Client 端以 `client.ListToolsAsync()` 取得伺服器工具清單（每項為 `McpClientTool`），以 `client.CallToolAsync(name, args)` 呼叫。`McpClientTool` 為 `sealed class : AIFunction`，因此可直接餵給 `Microsoft.Extensions.AI` 的 `IChatClient` 做 function calling——這是 MCP 與 LLM 整合的關鍵橋接（見 [[mef-ai-integration]]）。

> `McpClientTool` namespace `ModelContextProtocol.Client`、套件 .Core；其基底 `AIFunction` 來自外部 NuGet `Microsoft.Extensions.AI`（圖譜無此節點，屬正常）。`ListToolsAsync` / `CallToolAsync` 為 `McpClient` 的實例方法。

v2.0.0 的 wire shape 有兩項需特別留意：`Tool.inputSchema` 在反序列化時成為必要欄位；結構化工具結果在 2026-07-28 peer 上會保留自然的非 object JSON 值，舊 peer 才使用 `{ result: value }` envelope。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Client;

var client = await McpClient.CreateAsync(transport);

// 列出工具（每項是 McpClientTool : AIFunction）
IList<McpClientTool> tools = await client.ListToolsAsync();
foreach (var tool in tools)
    Console.WriteLine($"{tool.Name}: {tool.Description}");

// 呼叫工具
var result = await client.CallToolAsync(
    "echo",
    new Dictionary<string, object?> { ["message"] = "Hello" });
```

```csharp
// 因 McpClientTool : AIFunction，可直接交給 IChatClient（外部 Microsoft.Extensions.AI）
var response = await chatClient.GetResponseAsync(
    messages,
    new ChatOptions { Tools = [.. tools] });
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（`McpClientTool : AIFunction`）|
| 1.4.0 | 2026-06-04 | 前一穩定基準 |
| 2.0.0 | 2026-07-28 | **Breaking**：`Tool.inputSchema` 必填；非 object structured result 對新版 peer 不再包成 `{ result: ... }` |

## 教學章節對應
- 第 10 章：列出與呼叫工具
- 第 16 章：與 `IChatClient` 整合做 function calling

## 相關概念
- [[mcp-client]]
- [[mcp-server-tools]]
- [[mef-ai-integration]]
- [[result-caching]]
