---
title: NuGet 套件清單
api_name: N/A (套件清單)
namespace: N/A
package: N/A
since: N/A
current_version: 2.2.0
updated: 2026-08-03
tags: [packages, setup, devops]
tutorial_chapters: [ch02, appendix-a]
sources:
  - raw/docs-conceptual/getting-started.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/api-surface/ModelContextProtocol.md
  - raw/api-surface/ModelContextProtocol.AspNetCore.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.0.0.md
---

## 概述

MCP C# SDK v2.0.0 由五個發佈用 NuGet 套件組成（外加一個 analyzers 專案），依使用情境選擇。多數專案從 `ModelContextProtocol` 開始；Tasks 與 MCP Apps 則使用獨立 extension package。**沒有獨立的 `ModelContextProtocol.Authentication` 套件**——驗證相關型別分屬 `.Core`（`ModelContextProtocol.Authentication` namespace，client/共用）與 `.AspNetCore`（`ModelContextProtocol.AspNetCore.Authentication` namespace，server handler）。

## 套件清單

| 套件 | 用途 | 依賴 |
|------|------|------|
| **ModelContextProtocol.Core** | 只需 client 或 low-level server API、想要最少依賴。包含絕大多數型別（`McpClient`、`McpServer`、所有 primitive 型別與 attribute、Protocol 型別、`ModelContextProtocol.Authentication`）。 | — |
| **ModelContextProtocol** | client 或 stdio server，含 hosting、DI、attribute 式探索（多數專案起點）。提供 `AddMcpServer` / `WithStdioServerTransport` / `WithToolsFromAssembly` 等擴充方法。 | 引用 .Core |
| **ModelContextProtocol.AspNetCore** | HTTP server（ASP.NET Core 託管）。提供 `WithHttpTransport` / `MapMcp` 與 `ModelContextProtocol.AspNetCore.Authentication`。 | 引用 ModelContextProtocol |
| **ModelContextProtocol.Extensions.Tasks** | Tasks extension；提供 `WithTasks`、`IMcpTaskStore`、client task extensions 與 Tasks protocol 型別。 | 引用 ModelContextProtocol（其再引用 .Core）|
| **ModelContextProtocol.Extensions.Apps** | MCP Apps extension；提供 `WithMcpApps` 與 app UI metadata。 | 引用 ModelContextProtocol |
| **ModelContextProtocol.Analyzers** | 編譯期 Roslyn analyzers / source generators（通常隨上述套件帶入，不需手動引用）。 | — |

> ⚠️ 套件 ↔ namespace 不一定同名：SDK 的 DI／builder 擴充方法刻意放在 `Microsoft.Extensions.DependencyInjection` 與 `Microsoft.AspNetCore.Builder` namespace（.NET 慣例），但分別屬於 `ModelContextProtocol` 與 `.AspNetCore` 套件。

## 安裝

```bash
# stdio server / client（多數情境）
dotnet add package ModelContextProtocol

# HTTP server
dotnet add package ModelContextProtocol.AspNetCore

# 最小依賴（僅 client 或 low-level）
dotnet add package ModelContextProtocol.Core

# Tasks extension
dotnet add package ModelContextProtocol.Extensions.Tasks

# MCP Apps extension
dotnet add package ModelContextProtocol.Extensions.Apps
```

> 版本基準 v2.0.0。v0.5.0 前套件發佈於 `ModelContextProtocolOfficial` profile，之後改為 `ModelContextProtocol` profile。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 三套件穩定版，啟用 `EnablePackageValidation`（1.1.0 #1330）|
| 1.4.0 | 2026-06-04 | 前一穩定基準；`.Core` 新增 `ModelContextProtocol.Authentication` 的 ID-JAG 型別 |
| 2.0.0 | 2026-07-28 | 新增 `ModelContextProtocol.Extensions.Tasks` 與 `ModelContextProtocol.Extensions.Apps`，共五個可發佈 SDK 套件 |

## 教學章節對應
- 第 02 章：選擇套件與安裝
- 附錄 A：完整套件對照與版本記錄

## 相關概念
- [[what-is-mcp]]
- [[mcp-server-builder]]
- [[aspnetcore-hosting]]
- [[authorization]]
- [[tasks]]
- [[mcp-apps]]
