---
title: Streamable HTTP 傳輸層
api_name: MapMcp
namespace: Microsoft.AspNetCore.Builder
package: ModelContextProtocol.AspNetCore
since: 1.0.0
current_version: 2.2.0
updated: 2026-09-04
tags: [transport, http, sse, aspnetcore]
tutorial_chapters: [ch08, ch12]
sources:
  - raw/docs-conceptual/transports.md
  - raw/docs-conceptual/stateless.md
  - raw/api-surface/ModelContextProtocol.AspNetCore.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/release-notes/v1.2.0.md
  - raw/release-notes/v2.0.0.md
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.1.0.md
  - raw/facts/v2.1.0-verified-changes.json
  - csharp-sdk/src/ModelContextProtocol.Core/Client/HttpClientTransportOptions.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Client/SseClientSessionTransport.cs
  - csharp-sdk/src/Common/HttpResponseMessageExtensions.cs
  - csharp-sdk/tests/ModelContextProtocol.Tests/Transport/HttpClientTransportTests.cs
  - csharp-sdk/tests/ModelContextProtocol.Tests/Transport/HttpClientTransportAutoDetectTests.cs
  - csharp-sdk/src/ModelContextProtocol.AspNetCore/McpEndpointRouteBuilderExtensions.cs
  - raw/release-notes/v2.2.0.md
  - raw/facts/v2.2.0-verified-changes.json
  - raw/samples/README.md
  - csharp-sdk/src/ModelContextProtocol.AspNetCore/HttpServerSessionMode.cs
  - csharp-sdk/src/ModelContextProtocol.AspNetCore/HttpServerTransportOptions.cs
  - csharp-sdk/samples/AspNetCoreMcpPerSessionTools/Program.cs
  - csharp-sdk/samples/AspNetCoreMcpServer/Program.cs
  - csharp-sdk/tests/ModelContextProtocol.AspNetCore.Tests/July2026ProtocolHybridSessionModeTests.cs
---

## 概述

Streamable HTTP 是遠端／網路情境的傳輸層，由 `ModelContextProtocol.AspNetCore` 套件提供。Server 端以 `AddMcpServer().WithHttpTransport()` 設定，再用 `MapMcp()` 將 MCP 端點掛到 ASP.NET Core 路由。Client 端使用 HTTP client transport（預設 `HttpTransportMode.AutoDetect`，會先嘗試 Streamable HTTP）。**自 v1.2.0 起，legacy SSE（`/sse`、`/message`）預設停用**，須以 `HttpServerTransportOptions.EnableLegacySse = true`（會觸發 `MCP9004` 警告）才會繼續服務。

> `MapMcp` namespace **`Microsoft.AspNetCore.Builder`**、套件 .AspNetCore；`WithHttpTransport` namespace `Microsoft.Extensions.DependencyInjection`、套件 .AspNetCore。

v2.0.0 的 client transport 新增 `EnableStandaloneGetStream`（預設 `true`），可選擇退出 Streamable HTTP standalone GET stream。SSE 連線失敗也改為直接傳遞底層例外，不再一律包成 `IOException`。

v2.1.0 修正 AutoDetect fallback 的可靠性：尚未正式採用 SSE 前若 provisional SSE 失敗，共用 message channel 會保持開啟以便改試其他 transport；HTTP error status 也會跨 target framework 保存在 `HttpRequestException` 中。Stateless server 若需要長連線通知，可搭配 [[subscriptions-listen]] 使用 request-bound stream。

v2.2.0 新增 `HttpServerSessionMode` 與 `HttpServerTransportOptions.SessionMode`。`StatefulForInitializeClients` 可在同一 endpoint 為 initialize-handshake client 建立 session，同時直接以 stateless 模式服務 2026-07-28 client，避免為新協定 request 強制降版。

## 目前 API 簽名

```csharp
using Microsoft.Extensions.DependencyInjection;  // AddMcpServer / WithHttpTransport
using Microsoft.AspNetCore.Builder;              // MapMcp

var builder = WebApplication.CreateBuilder(args);
builder.Services
    .AddMcpServer()
    .WithHttpTransport()
    .WithToolsFromAssembly();

var app = builder.Build();
app.MapMcp();          // 預設掛在根端點（不再自動 map /sse、/message）
app.Run();
```

```csharp
// 過渡期：同時服務 Streamable HTTP 與 legacy SSE
builder.Services.AddMcpServer()
    .WithHttpTransport(o =>
    {
        o.SessionMode = HttpServerSessionMode.Stateful;
        o.EnableLegacySse = true;  // 觸發 MCP9004，需抑制
    });
```

```csharp
// 漸進遷移：舊 client 使用 session，新協定 client 保持 stateless
builder.Services.AddMcpServer()
    .WithHttpTransport(o =>
        o.SessionMode = HttpServerSessionMode.StatefulForInitializeClients);
```

```csharp
var transportOptions = new HttpClientTransportOptions
{
    EnableStandaloneGetStream = false,
};
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版 |
| 1.1.0 | 2026-03-06 | transports 文件補 SSE server 範例 |
| 1.2.0 | 2026-03-27 | **Breaking 行為**：`MapMcp()` 預設不再 map `/sse`、`/message`；新增 `EnableLegacySse`（`[Obsolete]` MCP9004）|
| 1.3.0 | 2026-05-08 | 修正 stateless 傳輸誤報 listChanged capability（#1509）|
| 1.4.0 | 2026-06-04 | 前一穩定基準 |
| 2.0.0 | 2026-07-28 | 新增 standalone GET stream opt-out；SSE 連線錯誤直接傳遞底層例外 |
| 2.1.0 | 2026-08-05 | 修正 AutoDetect provisional SSE fallback，並跨 target framework 保留 HTTP status code |
| 2.2.0 | 2026-08-13 | 新增 `SessionMode` 三態設定與 `StatefulForInitializeClients` 混合模式 |

## 教學章節對應
- 第 08 章：傳輸層選擇
- 第 12 章：ASP.NET Core HTTP server 與部署

## 相關概念
- [[aspnetcore-hosting]]
- [[sessions]]
- [[http-server-session-mode]]
- [[stdio-transport]]
- [[transport-security]]
- [[result-caching]]
- [[subscriptions-listen]]
