---
title: MCP Apps
api_name: WithMcpApps
namespace: ModelContextProtocol.Extensions.Apps
package: ModelContextProtocol.Extensions.Apps
since: 2.0.0
current_version: 2.2.0
updated: 2026-09-04
tags: [apps, extension, server, ui, experimental]
tutorial_chapters: []
sources:
  - raw/docs-conceptual/apps.md
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.0.0.md
  - csharp-sdk/src/ModelContextProtocol.Extensions.Apps/Server/McpAppsBuilderExtensions.cs
  - csharp-sdk/src/ModelContextProtocol.Extensions.Apps/Server/McpAppUiAttribute.cs
  - csharp-sdk/samples/WeatherAppServer/Program.cs
  - csharp-sdk/samples/WeatherAppServer/WeatherTools.cs
---

## 概述

MCP Apps extension 讓 server 將工具與互動式 UI resource 關聯。以 `WithMcpApps` 啟用 extension，再用 `McpAppUiAttribute` 描述 resource URI 與可見範圍。

⚠️ `WithMcpApps` 的 namespace 為 **`ModelContextProtocol.Extensions.Apps`**（`McpAppsBuilderExtensions.cs:7` 驗證），**不是** `Microsoft.Extensions.DependencyInjection`——`AddMcpServer` 的 DI namespace 慣例不適用於此。`samples/WeatherAppServer/Program.cs` 的 using 亦可佐證。

三個構件：UI capability 協商（`extensions["io.modelcontextprotocol/ui"]`）、UI resource（MIME type `text/html;profile=mcp-app`）、tool UI metadata（工具的 `_meta.ui`）。

執行期實測（2026-09-04，net9.0 + SDK 2.2.0 正式套件）：

- `WithMcpApps()` 確實把 `io.modelcontextprotocol/ui` 寫入 `initialize` 回應的 capabilities extensions。
- **`Visibility` 不影響 server 端過濾**——`Visibility = [App]` 的工具仍會出現在 `tools/list`，僅在 `_meta.ui.visibility` 帶標記；隱藏與否由 host 決定，因此不可作為安全邊界。
- **`MCPEXP003` 為 error 等級**，觸發符號為 `McpApps`、`McpAppUiAttribute`、`McpUiToolVisibility`、`McpUiToolMeta`；`WithMcpApps()` 本身不觸發。
- **`[McpMeta(name, value)]` 的字串建構子會把值當字串序列化**，產生的 `_meta.ui` 是 JSON 字串而非物件；需改用具名的 `JsonValue = `（`[StringSyntax(Json)]`）。上游 `samples/WeatherAppServer` 目前使用位置參數形式。

`McpAppUiAttribute` 在 v2.0.0 標記為 Experimental，診斷 ID 為 `MCPEXP003`；使用前應評估 API 仍可能變更，必要時僅在最小範圍抑制該診斷。

## 目前 API 簽名

```csharp
builder.Services.AddMcpServer()
    .WithMcpApps();
```

```csharp
public static IMcpServerBuilder WithMcpApps(this IMcpServerBuilder builder);

[Experimental("MCPEXP003")]
public sealed class McpAppUiAttribute : Attribute
{
    public string? ResourceUri { get; set; }
    public string[]? Visibility { get; set; }
}
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 2.0.0 | 2026-07-28 | 新增 MCP Apps extension 與 experimental `McpAppUiAttribute`（MCPEXP003）|

## 教學章節對應

- 第 21 章：MCP Apps 完整教學（UI resource、`Visibility`、CSP/權限、優雅降級、AOT 序列化）

## 相關概念

- [[mcp-server-tools]]
- [[mcp-server-resources]]
- [[mcp-server-builder]]
