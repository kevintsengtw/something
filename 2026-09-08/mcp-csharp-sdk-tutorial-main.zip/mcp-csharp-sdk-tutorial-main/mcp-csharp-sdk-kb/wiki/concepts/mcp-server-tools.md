---
title: MCP Server 工具（Tools）
api_name: McpServerTool
namespace: ModelContextProtocol.Server
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 2.2.0
updated: 2026-09-04
tags: [server, tools, attribute, primitive, dependency-injection, schema, error-handling]
tutorial_chapters: [ch04, ch05, ch11]
sources:
  - raw/docs-conceptual/tools.md
  - raw/docs-conceptual/getting-started.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.0.0.md
  - raw/release-notes/v2.1.0.md
  - csharp-sdk/src/ModelContextProtocol.Core/Server/McpServerTool.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Server/McpServerToolAttribute.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Server/RequestContext.cs
  - csharp-sdk/src/ModelContextProtocol.Core/McpException.cs
  - csharp-sdk/src/ModelContextProtocol.Core/McpProtocolException.cs
  - csharp-sdk/src/ModelContextProtocol.Core/McpErrorCode.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/CallToolResult.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/Tool.cs
  - csharp-sdk/samples/ProtectedMcpServer/Tools/WeatherTools.cs
  - csharp-sdk/samples/EverythingServer/Tools/LongRunningTool.cs
  - csharp-sdk/tests/ModelContextProtocol.Tests/Server/McpServerToolTests.cs
---

## 概述

Tools 是 MCP 三大 primitive 中的「可執行動作」。在 SDK 中以 attribute 式定義最常見：在類別上標 `[McpServerToolType]`、在方法上標 `[McpServerTool]`，再透過 `WithToolsFromAssembly()`（掃描整個組件）或 `WithTools<T>()`（指定類別）註冊。工具方法可透過參數注入 `McpServer` 與 DI 服務；參數會自動產生 JSON Schema。

> 套件／namespace 對照：`McpServerTool`（`abstract class : IMcpServerPrimitive`）、`McpServerToolAttribute`、`McpServerToolTypeAttribute` 皆 namespace **`ModelContextProtocol.Server`**、屬 **ModelContextProtocol.Core** 套件。`WithToolsFromAssembly` / `WithTools` 為 builder 擴充方法，namespace `Microsoft.Extensions.DependencyInjection`、屬 **ModelContextProtocol** 套件。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Server;          // [McpServerToolType] / [McpServerTool]
using Microsoft.Extensions.DependencyInjection; // WithToolsFromAssembly / WithTools
using System.ComponentModel;

[McpServerToolType]
public static class EchoTool
{
    [McpServerTool, Description("Echoes the message back to the client.")]
    public static string Echo(string message) => $"hello {message}";
}

// 註冊：掃描組件中所有 [McpServerToolType]
builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithToolsFromAssembly();

// 或指定類別
builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithTools<EchoTool>();
```

驗證（codebase-memory-mcp）：`McpServerToolAttribute` 全名為 `McpServerToolAttribute : Attribute`（`[McpServerTool]` 為其簡寫）；型別檔位於 `src/ModelContextProtocol.Core/Server/`。`WithToolsFromAssembly` 定義於 `src/ModelContextProtocol/McpServerBuilderExtensions.cs`（套件 ModelContextProtocol）。

---

## 工具進階（ch05）

以下五個面向是第 05 章的主題，對應 API 已逐筆經 codebase-memory-mcp + `csharp-sdk/src` 驗證（見 `raw/facts/v1.4.0-api-inventory.json`）。

### 1. 參數 Schema：`[Description]`

工具方法的參數會自動產生 input JSON Schema；在參數上加 `[Description]`（`System.ComponentModel.DescriptionAttribute`，.NET BCL）即可為每個參數補上 schema 的 description，讓 LLM 知道如何填值。`[Description]` 不是 SDK 定義的型別——SDK 只是讀取它。

```csharp
[McpServerTool, Description("Get weather alerts for a US state.")]
public async Task<string> GetAlerts(
    [Description("The US state to get alerts for. Use the 2 letter abbreviation for the state (e.g. NY).")] string state)
```

> 來源：`csharp-sdk/samples/ProtectedMcpServer/Tools/WeatherTools.cs`。方法層的 `[Description]` 描述工具本身，參數層的 `[Description]` 描述各參數。

### 2. DI 服務注入

工具型別可為**非 static 的 instance 類別**，透過建構式注入已在 DI 容器註冊的服務（如 `IHttpClientFactory`）。SDK 會由 request-scoped `IServiceProvider`（.NET BCL）解析工具型別與其相依。

```csharp
[McpServerToolType]
public sealed class WeatherTools
{
    private readonly IHttpClientFactory _httpClientFactory;

    public WeatherTools(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
    }

    [McpServerTool, Description("Get weather alerts for a US state.")]
    public async Task<string> GetAlerts(/* ... */) { /* 使用 _httpClientFactory */ }
}
```

> 來源：`csharp-sdk/samples/ProtectedMcpServer/Tools/WeatherTools.cs`。相依服務需先在 `builder.Services` 註冊（如 `AddHttpClient("WeatherApi", ...)`）。

### 3. `McpServer` 與 `RequestContext<TParams>` 注入

工具方法只要宣告型別為 `McpServer` 或 `RequestContext<CallToolRequestParams>` 的參數，SDK 就會**自動注入**（不是由客戶端傳入，也不會出現在工具的 input schema）。用途包括回送通知/進度、讀取本次請求參數（如 `ProgressToken`）。`RequestContext<TParams>` 為 `sealed class : MessageContext`，namespace `ModelContextProtocol.Server`。

```csharp
[McpServerTool(Name = "longRunningOperation"), Description("Demonstrates a long running operation with progress updates")]
public static async Task<string> LongRunningOperation(
    McpServer server,
    RequestContext<CallToolRequestParams> context,
    int duration = 10,
    int steps = 5)
{
    var progressToken = context.Params.ProgressToken;
    // ... 迴圈中 await server.SendNotificationAsync("notifications/progress", ...)
}
```

> 來源：`csharp-sdk/samples/EverythingServer/Tools/LongRunningTool.cs`。注意 `RequestContext(McpServer, JsonRpcRequest)` 的 2-arg 建構式自 1.2.0 起標 `[Obsolete MCP9003]`，改用 3-arg 多載——但一般工具作者不會手動 new `RequestContext`，而是靠 SDK 注入。

### 4. 回傳型別與結構化輸出

工具方法可回傳 `string`（純文字）、任意可序列化物件，或直接回傳 `CallToolResult`（`sealed class : Result`，namespace `ModelContextProtocol.Protocol`）以完全掌控輸出——包含 `Content`（`IList<ContentBlock>`）、`IsError`（`bool?`）、`StructuredContent`（`JsonElement?`）。

若要提供 **output schema**，用 `[McpServerTool]` 的 `OutputSchemaType`（`Type?`，since 1.2.0, #1425）指定對應 CLR 型別；搭配 `UseStructuredContent` 決定是否回填 `StructuredContent`。SDK 會據此填入 protocol 層的 `Tool.OutputSchema`（`JsonElement?`）。

v2.0.0 要求反序列化的 `Tool.inputSchema` 必須存在。`Tool.OutputSchema` 可接受 JSON Schema 2020-12 的 object 或 boolean；對 2026-07-28 peer，非 object 的 structured result 會保留自然 JSON 值，只有舊 peer 繼續使用 `{ result: value }` envelope。

Binary embedded resource 會以 MCP resource shape 傳送：URI、MIME type 與 base64 `blob`。SDK 不會把 `application/pdf` 等格式自動轉為影像；client 是否能顯示或提供給模型取決於自身能力，不相容時應另附文字或 client 支援的 content block。

```csharp
// 自動由回傳型別推得 schema，並回填 structured content
[McpServerTool(UseStructuredContent = true, OutputSchemaType = typeof(Person))]
public static Person GetPerson() => new("Alice", 30);
```

> 來源：`csharp-sdk/tests/ModelContextProtocol.Tests/Server/McpServerToolTests.cs`（`CanReturnCallToolResult`、`OutputSchemaType` 案例）。`OutputSchemaType` 自 v1.2.0 起允許工具**獨立於回傳型別**指定 output schema（尤其在回傳 `CallToolResult` 時）。

### 5. 錯誤處理：工具錯誤 vs 協定錯誤

MCP 把兩種錯誤分清楚（依 `raw/docs-conceptual/tools.md`「Error handling」）。**工具方法丟例外時，SDK 預設攔截成工具錯誤結果 `CallToolResult { IsError = true }`（而非 JSON-RPC error）**，讓模型看得到並可能自我修復——只有兩個例外會 re-throw：`McpProtocolException` 與（取消時的）`OperationCanceledException`。

- **`McpException`**（`class : Exception`，namespace **`ModelContextProtocol`**，.Core）→ 工具錯誤結果；其 `Message` 會放進錯誤文字。非 `McpException` 的一般例外只回通用訊息（`"An error occurred invoking '<tool>'."`），避免洩漏內部細節。
- **`McpProtocolException`**（`class : McpException`，同 namespace/套件）→ **re-throw 成 JSON-RPC error response**（不包成工具結果）。用於協定層錯誤（如非法參數、未知工具），可帶 `McpErrorCode`（enum，如 `InvalidParams = -32602`）。

```csharp
using ModelContextProtocol;   // McpException / McpProtocolException / McpErrorCode

// (a) 工具錯誤：訊息會傳給模型
[McpServerTool, Description("Divides two numbers")]
public static double Divide(double a, double b)
    => b == 0 ? throw new McpException("Cannot divide by zero.") : a / b;

// (b) 協定錯誤：對外為 JSON-RPC error，code -32602
[McpServerTool, Description("Processes the input")]
public static string Process(string input)
    => string.IsNullOrEmpty(input)
        ? throw new McpProtocolException("Missing required input", McpErrorCode.InvalidParams)
        : $"Processed: {input}";
```

> 來源：`csharp-sdk/samples/ProtectedMcpServer/Tools/WeatherTools.cs`（`throw new McpException(...)` 實例）；行為語意見 `raw/docs-conceptual/tools.md`「Automatic exception handling / Protocol errors」，及測試 `tests/ModelContextProtocol.Tests/Server/McpServerTests.cs`（`Can_Handle_Call_Tool_Requests_With_McpException`）。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（attribute 式工具 + assembly 掃描）|
| 1.2.0 | 2026-03-27 | 工具可獨立於回傳型別指定 `OutputSchema`（`McpServerToolAttribute.OutputSchemaType`，回傳 `CallToolResult` 時，#1425）；`RequestContext` 2-arg 建構式標 `[Obsolete MCP9003]` |
| 1.4.0 | 2026-06-04 | 前一穩定基準（工具 task 支援屬性可設於 attribute）|
| 2.0.0 | 2026-07-28 | **Breaking wire shape**：`Tool.inputSchema` 必填；新版 peer 接收自然的非 object structured result；新增三個協定 error code |
| 2.1.0 | 2026-08-05 | 官方文件釐清 binary embedded resource 的 wire shape 與 client rendering 責任 |

## 教學章節對應
- 第 04 章：加入第一個工具（Echo），用 stdio 跑起來
- 第 05 章：工具進階——參數 Schema（`[Description]`）、DI 服務注入（`IHttpClientFactory` 等）、`McpServer` / `RequestContext<CallToolRequestParams>` 注入、回傳型別（`CallToolResult` / `OutputSchemaType` / `Tool.OutputSchema`）、錯誤處理（工具錯誤 `McpException` vs 協定錯誤 `McpProtocolException` + `McpErrorCode`）
- 第 11 章：實作範例——以 `samples/QuickstartWeatherServer` 為骨架組裝完整天氣 server（`HttpClient` 以**工具方法參數**從 DI 注入的簡化形式、`McpException`、與 resources 同台註冊）。注意 `WithTools<T>()` 的 `T` 不可為 static class（C# CS0718，ch11 編譯實證）；static class 工具型別走 `WithToolsFromAssembly()` 掃描

## 相關概念
- [[mcp-server-builder]]
- [[mcp-server-prompts]]
- [[mcp-server-resources]]
- [[mcp-client-tools]]
- [[notifications-progress]]
- [[mef-ai-integration]]
- [[mcp-apps]]
- [[primitive-change-batching]]
- [[tasks]]
