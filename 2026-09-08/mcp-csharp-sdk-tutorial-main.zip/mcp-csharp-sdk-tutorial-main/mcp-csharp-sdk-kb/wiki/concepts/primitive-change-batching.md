---
title: Primitive 變更批次通知
api_name: McpServerPrimitiveCollection<T>.DeferChangedEvents
namespace: ModelContextProtocol.Server
package: ModelContextProtocol.Core
since: 2.0.0
current_version: 2.2.0
updated: 2026-09-04
tags: [server, primitive, notifications, batching]
tutorial_chapters: [ch05, ch06, ch07, ch09]
sources:
  - raw/docs-conceptual/capabilities.md
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.0.0.md
  - csharp-sdk/src/ModelContextProtocol.Core/Server/McpServerPrimitiveCollection.cs
  - csharp-sdk/tests/ModelContextProtocol.Tests/Server/McpServerPrimitiveCollectionTests.cs
---

## 概述

`DeferChangedEvents` 可在一次批次修改 tools、prompts 或 resources 時延後 collection changed events，避免每筆修改各送一次變更通知。回傳的 `IDisposable` 結束生命週期後，collection 才彙整觸發事件。

## 目前 API 簽名

```csharp
public IDisposable DeferChangedEvents();
```

```csharp
using (primitives.DeferChangedEvents())
{
    // 在此批次新增、移除或替換 primitive。
}
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 2.0.0 | 2026-07-28 | 新增 `DeferChangedEvents`，支援批次 primitive-change 通知 |

## 教學章節對應

- 第 09 章：批次變更 primitive 與 list-changed 通知彙整（主要說明）
- 第 05–07 章：動態 tool / prompt / resource 管理處的交叉指標

## 相關概念

- [[mcp-server-tools]]
- [[mcp-server-prompts]]
- [[mcp-server-resources]]
- [[notifications-progress]]
