---
title: 訂閱監聽串流（subscriptions/listen）
api_name: McpServerBuilderExtensions.WithSubscriptionsListenHandler
namespace: Microsoft.Extensions.DependencyInjection
package: ModelContextProtocol
since: 2.1.0
current_version: 2.2.0
updated: 2026-08-10
tags: [subscriptions, notifications, stream, stateless, sep-2575]
tutorial_chapters: [ch07, ch08, ch12]
sources:
  - raw/docs-conceptual/resources.md
  - raw/facts/v2.1.0-verified-changes.json
  - raw/release-notes/v2.1.0.md
  - csharp-sdk/src/ModelContextProtocol/McpServerBuilderExtensions.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Server/McpServerHandlers.cs
  - csharp-sdk/tests/ModelContextProtocol.Tests/Server/SubscriptionsListenHandlerTests.cs
  - csharp-sdk/tests/ModelContextProtocol.AspNetCore.Tests/StatelessServerTests.cs
---

## 概述

`subscriptions/listen` 是 2026-07-28 協定版本的長連線 request。v2.1.0 新增 `WithSubscriptionsListenHandler`，讓 server 完整接管這條 solicited server-to-client stream；即使使用 stateless Streamable HTTP，也能在該 request 的 response stream 上傳送訂閱通知。

這是 SDK 內建 listen handler 的**完整替代**，不是額外疊加。自訂 handler 必須自行送出一次 `notifications/subscriptions/acknowledged`、在每則通知的 `_meta.subscriptionId` 放入 listen request ID、維持執行直到 cancellation，並只宣告實際能提供的 capabilities。

## 目前 API 簽名

```csharp
using Microsoft.Extensions.DependencyInjection;
using ModelContextProtocol.Protocol;

public static IMcpServerBuilder WithSubscriptionsListenHandler(
    this IMcpServerBuilder builder,
    McpRequestHandler<SubscriptionsListenRequestParams, EmptyResult> handler);
```

對應的低階 handler property 位於 `McpServerHandlers`：

```csharp
public McpRequestHandler<SubscriptionsListenRequestParams, EmptyResult>?
    SubscriptionsListenHandler { get; set; }
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 2.1.0 | 2026-08-05 | 新增公開的 `WithSubscriptionsListenHandler` 與 `McpServerHandlers.SubscriptionsListenHandler`（SEP-2575）|

## 教學章節對應

- 第 07 章：Resources 訂閱與變更通知
- 第 08、12 章：stateless Streamable HTTP 的 solicited notification stream

## 相關概念

- [[mcp-server-resources]]
- [[notifications-progress]]
- [[streamable-http-transport]]
- [[sessions]]
