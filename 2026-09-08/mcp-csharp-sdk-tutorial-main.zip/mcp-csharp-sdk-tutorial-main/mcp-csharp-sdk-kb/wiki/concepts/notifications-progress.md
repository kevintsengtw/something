---
title: 通知與進度（Notifications & Progress）
api_name: NotificationMethods
namespace: ModelContextProtocol.Protocol
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 2.2.0
updated: 2026-08-03
tags: [notifications, progress, protocol]
tutorial_chapters: [ch09]
sources:
  - raw/docs-conceptual/progress.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.0.0.md
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/NotificationMethods.cs
  - csharp-sdk/src/ModelContextProtocol.Core/ProgressNotificationValue.cs
---

## 概述

MCP 雙方可互送 JSON-RPC 通知（無回應的單向訊息）。SDK 以 `SendNotificationAsync`（`McpSession` 的方法，server 與 client 共用）送出，方法名稱常數集中在 `NotificationMethods`。進度回報是常見用例：長操作的工具可回報 `ProgressNotificationValue`（progress / total / message），client 端以 `IProgress<ProgressNotificationValue>` 接收。

> `NotificationMethods` namespace `ModelContextProtocol.Protocol`、套件 .Core；`ProgressNotificationValue` namespace `ModelContextProtocol`（root）、套件 .Core；`SendNotificationAsync` 定義於 `McpSession.Methods.cs`（套件 .Core）。

## 目前 API 簽名

```csharp
using ModelContextProtocol;            // ProgressNotificationValue
using ModelContextProtocol.Server;

[McpServerTool]
public static async Task<string> LongJob(
    IProgress<ProgressNotificationValue> progress,   // 由框架注入
    CancellationToken ct)
{
    for (int i = 0; i <= 100; i += 20)
    {
        progress.Report(new ProgressNotificationValue { Progress = i, Total = 100, Message = $"{i}%" });
        await Task.Delay(200, ct);
    }
    return "done";
}
```

> 通用通知以 `session.SendNotificationAsync(...)` 送出；方法名稱常數見 `NotificationMethods`。確切屬性名稱以 `ProgressNotificationValue.cs` 為準。

v2.0.0 新增 `McpServerPrimitiveCollection<T>.DeferChangedEvents()`，可將一批 tools、prompts 或 resources 變更合併成較少的 changed events；詳見 [[primitive-change-batching]]。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版 |
| 1.1.0 | 2026-03-06 | 註冊 ping handler 支援 server-initiated pings（#1391）|
| 1.2.0 | 2026-03-27 | 修正 `WithMeta` + `WithProgress` 併用導致工具呼叫失敗（#1464）|
| 1.4.0 | 2026-06-04 | 前一穩定基準 |
| 2.0.0 | 2026-07-28 | 新增 primitive changed-event 批次延後機制 |

## 教學章節對應
- 第 09 章：通知、進度回報、ping

## 相關概念
- [[mcp-server-tools]]
- [[logging-and-completion]]
- [[tasks]]
- [[primitive-change-batching]]
