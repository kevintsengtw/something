---
title: HTTP Server Session 模式
api_name: HttpServerSessionMode
namespace: ModelContextProtocol.AspNetCore
package: ModelContextProtocol.AspNetCore
since: 2.2.0
current_version: 2.2.0
updated: 2026-08-15
tags: [transport, sessions, http, aspnetcore]
tutorial_chapters: [ch08, ch12]
sources:
  - raw/docs-conceptual/stateless.md
  - raw/docs-conceptual/transports.md
  - raw/release-notes/v2.2.0.md
  - raw/facts/v2.2.0-verified-changes.json
  - raw/samples/README.md
  - csharp-sdk/src/ModelContextProtocol.AspNetCore/HttpServerSessionMode.cs
  - csharp-sdk/src/ModelContextProtocol.AspNetCore/HttpServerTransportOptions.cs
  - csharp-sdk/samples/AspNetCoreMcpPerSessionTools/Program.cs
  - csharp-sdk/samples/AspNetCoreMcpServer/Program.cs
  - csharp-sdk/tests/ModelContextProtocol.AspNetCore.Tests/HttpServerTransportOptionsTests.cs
  - csharp-sdk/tests/ModelContextProtocol.AspNetCore.Tests/July2026ProtocolHybridSessionModeTests.cs
---

## 概述

`HttpServerSessionMode` 讓 ASP.NET Core MCP server 明確選擇無狀態、有狀態或混合 session 策略。混合模式可讓舊版 initialize-handshake client 保有 session，同一 endpoint 上的 2026-07-28 client 則以 stateless request 運作。

## 目前 API 簽名

```csharp
public enum HttpServerSessionMode
{
    Stateless,
    Stateful,
    StatefulForInitializeClients,
}

public HttpServerSessionMode SessionMode { get; set; }
```

`HttpServerTransportOptions.Stateless` 仍是相容 proxy：指定 `true` 會選擇 `Stateless`，指定 `false` 會選擇 `Stateful`；只有 `SessionMode` 能選擇 `StatefulForInitializeClients`。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 2.2.0 | 2026-08-13 | 新增三態 `HttpServerSessionMode` 與 `SessionMode` 屬性，支援 initialize clients 使用 session、2026-07-28 clients 同 endpoint stateless 的混合模式 |

## 教學章節對應

- 第 08 章：HTTP transport 與 session 模式選擇
- 第 12 章：ASP.NET Core endpoint 的部署與相容性策略

## 相關概念

- [[sessions]]
- [[streamable-http-transport]]
- [[aspnetcore-hosting]]
- [[multi-round-trip-requests]]
- [[subscriptions-listen]]
