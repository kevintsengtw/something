---
title: Stdio 傳輸層
api_name: StdioClientTransport
namespace: ModelContextProtocol.Client
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 2.2.0
updated: 2026-08-03
tags: [transport, stdio, client, server]
tutorial_chapters: [ch04, ch08]
sources:
  - raw/docs-conceptual/transports.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/facts/v1.4.0-verified-changes.json
  - csharp-sdk/src/ModelContextProtocol.Core/Client/StdioClientTransportOptions.cs
---

## 概述

Stdio 是最常見的本機傳輸：client 啟動 server 作為子行程，雙方以 stdin/stdout 交換 JSON-RPC 訊息。Server 端以 `WithStdioServerTransport()`（builder 擴充方法）或底層 `StdioServerTransport` 設定；client 端以 `StdioClientTransport` + `StdioClientTransportOptions`（指定 `Command` / `Arguments` / `Name`）。**重要**：stdio server 的 log 必須走 stderr（stdout 專供協定）。

> `StdioClientTransport`（`sealed partial class : IClientTransport`）/ `StdioClientTransportOptions` namespace `ModelContextProtocol.Client`、套件 .Core；`StdioServerTransport`（`: StreamServerTransport`）namespace `ModelContextProtocol.Server`、套件 .Core；`WithStdioServerTransport` namespace `Microsoft.Extensions.DependencyInjection`、套件 ModelContextProtocol。

## 目前 API 簽名

```csharp
// Client：啟動子行程 server
using ModelContextProtocol.Client;

var transport = new StdioClientTransport(new StdioClientTransportOptions
{
    Name = "Everything",
    Command = "npx",
    Arguments = ["-y", "@modelcontextprotocol/server-everything"],
    InheritEnvironmentVariables = true,   // v1.4.0 新增，預設 true
});
var client = await McpClient.CreateAsync(transport);
```

```csharp
// Server：stdio transport
builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithToolsFromAssembly();
```

v1.4.0 新增屬性（驗證）：`public bool InheritEnvironmentVariables { get; set; } = true;`——控制子行程是否繼承父行程環境變數（預設 true，向後相容）。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版 |
| 1.3.0 | 2026-05-08 | 修正測試 Stderr 時的 host crash（#1449）|
| 1.4.0 | 2026-06-04 | 新增 `InheritEnvironmentVariables`（#1563）；stdio 不再於 Trace log 列出環境變數（#1538，安全）|

## 教學章節對應
- 第 04 章：用 stdio 跑起第一個 server
- 第 08 章：傳輸層選擇（stdio vs HTTP）

## 相關概念
- [[mcp-server-builder]]
- [[mcp-client]]
- [[streamable-http-transport]]
- [[in-memory-transport]]
