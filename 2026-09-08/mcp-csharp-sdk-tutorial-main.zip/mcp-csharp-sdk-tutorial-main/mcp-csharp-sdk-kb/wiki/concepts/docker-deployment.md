---
title: Docker 部署
api_name: N/A (DevOps)
namespace: N/A
package: N/A
since: 1.0.0
current_version: 2.2.0
updated: 2026-08-03
tags: [docker, devops, deployment]
tutorial_chapters: [ch19]
sources:
  - raw/docs-conceptual/docker.md
  - raw/docs-conceptual/transports.md
  - raw/docs-conceptual/stateless.md
  - raw/facts/v1.4.0-api-inventory.json
---

## 概述

容器化 MCP server 以 HTTP 傳輸（`ModelContextProtocol.AspNetCore`）最常見。建議採 **stateless** 模式以利水平擴展（多副本可任意路由），並以標準 .NET 容器最佳實踐建置（多階段建置、非 root 使用者、健康檢查端點）。stdio server 通常不需容器化（由 client 啟動子行程）；若要打包 stdio server，重點是讓 client 能在容器內以正確 `Command`/`Arguments` 啟動。

## 關鍵設定

```dockerfile
# 多階段建置（HTTP MCP server）
FROM mcr.microsoft.com/dotnet/sdk:10.0 AS build
WORKDIR /src
COPY . .
RUN dotnet publish -c Release -o /app

FROM mcr.microsoft.com/dotnet/aspnet:10.0
WORKDIR /app
COPY --from=build /app .
EXPOSE 8080
ENV ASPNETCORE_URLS=http://+:8080
ENTRYPOINT ["dotnet", "MyMcpServer.dll"]
```

部署要點：
- **stateless = true**：多副本可水平擴展，無 session 親和性需求（見 [[sessions]]）
- **傳輸安全**：設定 allowed hosts / CORS（見 [[transport-security]]）
- **健康檢查**：暴露 ASP.NET Core health endpoint 供 orchestrator 探測
- 進階：考慮 Native AOT 縮小映像（見 [[aot-compatibility]]）

> 本條目為 DevOps 指引，無對應 C# API；.NET 版本與基底映像 tag 請依專案 `global.json` 調整。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（HTTP server 可容器化）|
| 1.4.0 | 2026-06-04 | 前一穩定基準 |
| 2.0.0 | 2026-07-28 | 對齊 v2.0.0 官方 Docker 部署指引 |

## 教學章節對應
- 第 19 章：容器化與部署 MCP server

## 相關概念
- [[aspnetcore-hosting]]
- [[sessions]]
- [[transport-security]]
- [[aot-compatibility]]
