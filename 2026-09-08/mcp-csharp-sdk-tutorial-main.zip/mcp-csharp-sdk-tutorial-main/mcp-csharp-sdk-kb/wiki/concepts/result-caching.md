---
title: 結果快取提示（Result Caching Hints）
api_name: ICacheableResult
namespace: ModelContextProtocol.Protocol
package: ModelContextProtocol.Core
since: 2.0.0
current_version: 2.2.0
updated: 2026-09-04
tags: [client, protocol, caching, discovery]
tutorial_chapters: [ch07, ch10]
sources:
  - raw/docs-conceptual/transports.md
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.0.0.md
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/ICacheableResult.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/CacheScope.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/DiscoverResult.cs
  - csharp-sdk/tests/ModelContextProtocol.Tests/Protocol/CacheableResultTests.cs
---

## 概述

v2.0.0 依 SEP-2549 加入結果快取提示。實作 `ICacheableResult` 的協定結果可提供存活時間與 `CacheScope`，讓接收端判斷可否及如何重用結果；這是提示而非強制快取機制。

`DiscoverResult` 同時實作 `ICacheableResult`，用於 discovery-first negotiation。`ServerInfo` 已不再是其直接屬性，改由 `Meta[MetaKeys.ServerInfo]` 承載。

實作 `ICacheableResult` 的不只 `DiscoverResult`，還包括 `ListToolsResult`、`ListPromptsResult`、`ListResourcesResult`、`ListResourceTemplatesResult` 與 `ReadResourceResult`（驗證自 `src/ModelContextProtocol.Core/Protocol/`）。client 的便利多載會聚合分頁並丟棄 per-page 提示，需改用帶 `requestParams` 的低階多載才讀得到；SDK 本身不做任何內部快取。

## 目前 API 簽名

```csharp
public interface ICacheableResult
{
    TimeSpan? TimeToLive { get; set; }
    CacheScope? CacheScope { get; set; }
}

public enum CacheScope
{
    Public,
    Private,
}
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 2.0.0 | 2026-07-28 | 新增 SEP-2549 `ICacheableResult`、`CacheScope` 與 discovery 快取提示；`DiscoverResult.ServerInfo` 改由 meta key 表示 |

## 教學章節對應

- 第 07 章：`ReadResourceResult` 也實作 `ICacheableResult`
- 第 10 章：discovery-first 握手、`DiscoverResult` 與快取提示的讀取方式（便利多載會丟掉提示；SDK 不做內部快取）

## 相關概念

- [[mcp-client]]
- [[streamable-http-transport]]
- [[sessions]]
