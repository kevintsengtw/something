---
title: 多輪往返請求（MRTR）
api_name: InputRequest
namespace: ModelContextProtocol.Protocol
package: ModelContextProtocol.Core
since: 2.0.0
current_version: 2.2.0
updated: 2026-09-04
tags: [protocol, client, elicitation, tasks, advanced]
tutorial_chapters: [ch15, ch17]
sources:
  - raw/docs-conceptual/mrtr.md
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.0.0.md
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/InputRequest.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Client/McpClient.cs
  - csharp-sdk/src/ModelContextProtocol.Extensions.Tasks/Server/IMcpTaskStore.cs
---

## 概述

Multi-round-trip requests（MRTR）讓一個尚未完成的操作攜帶多筆待處理輸入請求，再由 client 解決後送回。`InputRequest` 描述方法與參數，`McpClient.ResolveInputRequestsAsync` 負責解析一組 request 並回傳相對應的 `InputResponse`。

## 目前 API 簽名

```csharp
public sealed class InputRequest
{
    public required string Method { get; set; }
    public JsonElement? Params { get; set; }
    public static InputRequest ForElicitation(ElicitRequestParams requestParams);
}

public abstract ValueTask<IDictionary<string, InputResponse>> ResolveInputRequestsAsync(
    IDictionary<string, InputRequest> inputRequests,
    CancellationToken cancellationToken);
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 2.0.0 | 2026-07-28 | 新增 MRTR 的 `InputRequest` 與 client 解析 API |

## 教學章節對應

- 第 15 章：工具層 MRTR——`InputRequiredException`、`IsMrtrSupported`、`RequestState`/`InputResponses` 重試流程，以及 stateless 下 `ElicitAsync` 不可用的對照表
- 第 17 章：task 層 MRTR 與 `IMcpTaskStore.ResolveInputRequestsAsync`

## 相關概念

- [[elicitation]]
- [[tasks]]
- [[alternate-results]]
- [[mcp-client]]
