---
title: 授權（OAuth 2.1 / OIDC / ID-JAG）
api_name: IdentityAssertionGrantProvider
namespace: ModelContextProtocol.Authentication
package: ModelContextProtocol.Core
since: 1.4.0
current_version: 2.2.0
updated: 2026-08-03
tags: [authorization, oauth, security, authentication]
tutorial_chapters: [ch18]
sources:
  - raw/docs-conceptual/transports.md
  - raw/docs-conceptual/identity.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/api-surface/ModelContextProtocol.AspNetCore.md
  - raw/facts/v1.4.0-verified-changes.json
  - raw/facts/v1.4.0-api-inventory.json
  - raw/release-notes/v1.4.0.md
  - raw/release-notes/v2.0.0.md
  - raw/facts/v2.0.0-verified-changes.json
  - csharp-sdk/src/ModelContextProtocol.Core/Authentication/IdentityAssertionGrantProvider.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Authentication/ClientOAuthOptions.cs
  - csharp-sdk/tests/ModelContextProtocol.AspNetCore.Tests/OAuth/AuthTests.cs
---

## 概述

MCP 的 HTTP 傳輸支援以 OAuth 2.1 / OIDC 保護 server。**Server 端**（`.AspNetCore`）以 `McpAuthenticationHandler` / `McpAuthenticationOptions`（namespace `ModelContextProtocol.AspNetCore.Authentication`）與 DI 擴充 `McpAuthenticationExtensions` 接入 ASP.NET Core 驗證管線。**Client 端**（`.Core`）以 `ClientOAuthProvider` / `ClientOAuthOptions`（namespace `ModelContextProtocol.Authentication`）執行 OAuth flow。

v1.4.0 新增 **Identity Assertion Authorization Grant（ID-JAG，SEP-990）**：`IdentityAssertionGrantProvider` 實作企業 SSO 情境——使用者在企業 IdP 驗證一次，即可存取多個 MCP server 而無須逐一授權。流程為 RFC 8693 token exchange（ID Token → JAG）接 RFC 7523 JWT bearer grant（JAG → access token）。

> 沒有獨立的 Authentication 套件：client/共用 auth 型別在 **.Core**（`ModelContextProtocol.Authentication`），server handler 在 **.AspNetCore**（`ModelContextProtocol.AspNetCore.Authentication`）。

v2.0.0 強化 client OAuth：新增 `ScopeSelectorDelegate`、`AuthorizationCallbackHandler` 與 dynamic registration 的 `ApplicationType`；舊 `AuthorizationRedirectDelegate` 標記 `[Obsolete]`（MCP9007）。authorization server metadata 必須明確宣告 PKCE `S256`，而重複且沒有新增 scope 的 `insufficient_scope` challenge 會直接失敗，避免無限重跑授權。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Authentication;   // .Core

// v1.4.0：ID-JAG 企業授權（驗證簽名）
var provider = new IdentityAssertionGrantProvider(
    new IdentityAssertionGrantProviderOptions
    {
        ClientId = "mcp-client-id",
        IdpClientId = "enterprise-idp-client-id",
        IdpUrl = "https://idp.example.com",
        IdTokenCallback = async (ctx, ct) => await GetEnterpriseIdTokenAsync(ctx, ct),
    },
    httpClient);

TokenContainer tokens = await provider.GetAccessTokenAsync(
    resourceUrl: new Uri("https://mcp.example.com/"),
    authorizationServerUrl: new Uri("https://auth.example.com/"));
```

驗證簽名（codebase-memory-mcp）：
```csharp
public IdentityAssertionGrantProvider(
    IdentityAssertionGrantProviderOptions options,
    HttpClient httpClient,
    ILoggerFactory? loggerFactory = null);
public Task<TokenContainer> GetAccessTokenAsync(Uri resourceUrl, Uri authorizationServerUrl, CancellationToken cancellationToken = default);
public void InvalidateCache();
```

```csharp
var oauthOptions = new ClientOAuthOptions
{
    AuthorizationCallbackHandler = async (context, cancellationToken) =>
    {
        // 由應用程式完成授權互動，再回傳 AuthorizationResult。
        return await HandleAuthorizationAsync(context, cancellationToken);
    },
};
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（OAuth 2.1，含 2025-03-26 向後相容）|
| 1.3.0 | 2026-05-08 | role/identity 傳遞文件 |
| 1.4.0 | 2026-06-04 | 新增 `IdentityAssertionGrantProvider`（ID-JAG / SEP-990，#1305）|
| 2.0.0 | 2026-07-28 | 新增 scope selector、callback handler、`ApplicationType`；`AuthorizationRedirectDelegate` 廢棄（MCP9007）；強制驗證 PKCE S256 並阻止無進展的 scope step-up |

## 教學章節對應
- 第 18 章：保護 MCP server（OAuth 2.1、ID-JAG 企業 SSO）

## 相關概念
- [[transport-security]]
- [[aspnetcore-hosting]]
- [[nuget-packages]]
