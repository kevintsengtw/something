---
title: Tasks（長時間執行 / 持久任務）
api_name: IMcpTaskStore
namespace: ModelContextProtocol.Extensions.Tasks
package: ModelContextProtocol.Extensions.Tasks
since: 2.0.0
current_version: 2.2.0
updated: 2026-08-03
tags: [tasks, durable, extension, advanced, server]
tutorial_chapters: [ch17]
sources:
  - raw/docs-conceptual/tasks.md
  - raw/facts/v2.0.0-verified-changes.json
  - raw/release-notes/v2.0.0.md
  - raw/samples/README.md
  - csharp-sdk/src/ModelContextProtocol.Extensions.Tasks/Server/IMcpTaskStore.cs
  - csharp-sdk/src/ModelContextProtocol.Extensions.Tasks/Server/McpTasksBuilderExtensions.cs
  - csharp-sdk/src/ModelContextProtocol.Extensions.Tasks/Client/McpTasksClientExtensions.cs
  - csharp-sdk/tests/ModelContextProtocol.ConformanceServer/Program.cs
---

## 概述

Tasks 是獨立的 MCP extension，讓工具呼叫建立可輪詢、取消並取得結果的持久任務。v2.0.0 已把 v1.4.x 的 Core 實作換成 `ModelContextProtocol.Extensions.Tasks` 套件；新舊 API 與 wire format 不相容，不能只改 namespace。

Server 端以 `WithTasks` 綁定 `IMcpTaskStore`；client 端則透過 extension methods，例如 `CallToolAsTaskAsync`。協定方法名稱集中在 `TasksProtocol`，extension ID 為 `io.modelcontextprotocol/tasks`。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Extensions.Tasks;

IMcpTaskStore store = /* 應用程式提供的 task store */;

builder.Services.AddMcpServer()
    .WithHttpTransport()
    .WithTasks(
        store,
        options => { });
```

已驗證的核心簽名：

```csharp
public static IMcpServerBuilder WithTasks(
    this IMcpServerBuilder builder,
    IMcpTaskStore store,
    Action<McpTasksOptions> configure);

public interface IMcpTaskStore
{
    Task<McpTaskInfo> CreateTaskAsync(CancellationToken cancellationToken = default);
    Task<McpTaskInfo?> GetTaskAsync(string taskId, CancellationToken cancellationToken = default);
    Task ResolveInputRequestsAsync(
        string taskId,
        IDictionary<string, InputResponse> inputResponses,
        CancellationToken cancellationToken = default);
}
```

`CallToolAsTaskAsync` 回傳 `ResultOrCreatedTask<CallToolResult>`，呼叫端必須分辨同步結果與已建立的 task。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | Core 曾提供 experimental Tasks 實作 |
| 2.0.0 | 2026-07-28 | **Breaking**：改為 `ModelContextProtocol.Extensions.Tasks` extension package；`IMcpTaskStore`、client/server API 與 wire format 全面重設計 |

## 教學章節對應

- 第 17 章：目前內容以舊 Core Tasks API 為基準，需由 drift report 判定並更新

## 相關概念

- [[mcp-server-tools]]
- [[notifications-progress]]
- [[multi-round-trip-requests]]
- [[alternate-results]]
- [[aspnetcore-hosting]]
