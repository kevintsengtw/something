---
updated: 2026-09-04
---

# Wiki 編譯規則（SCHEMA）

> 此檔案定義 `/compile` 指令在產生或更新 `wiki/concepts/` 條目時必須遵循的規則。

## 1. 條目檔案命名
- 使用小寫 kebab-case：`mcp-server-tools.md`、`stdio-transport.md`
- 一個概念一個檔案，不合併
- 檔名即為 wiki-link 識別名稱：`[[mcp-server-tools]]`

## 2. YAML Frontmatter 必填欄位

```yaml
---
title: <繁體中文概念名稱>          # 必填
api_name: <C# 類別/介面/attribute 名稱>  # 必填，若無 API 則填 "N/A (描述)"
namespace: <命名空間>              # 必填，若無則填 "N/A"
package: <NuGet 套件>             # ModelContextProtocol.Core | ModelContextProtocol | ModelContextProtocol.AspNetCore | ModelContextProtocol.Extensions.Tasks | ModelContextProtocol.Extensions.Apps | ModelContextProtocol.Analyzers | N/A
                                  # ⚠️ 沒有 ModelContextProtocol.Authentication 套件；auth 型別分屬 .Core 與 .AspNetCore
since: <首次出現版本>              # 如 0.1.0, 1.0.0, 1.4.0
current_version: <目前版本>        # 與 raw/release-notes/ 最新版本一致
updated: <YYYY-MM-DD>             # 最後更新日期
tags: [tag1, tag2]                # 至少 1 個 tag
tutorial_chapters: [ch02, ch05]   # 教學章節代號列表
sources:                          # 引用的 raw/ 素材路徑
  - raw/docs-conceptual/tools.md
  - raw/facts/v1.4.0-verified-changes.json
---
```

## 3. 正文必備區段（順序固定）

| 順序 | 區段標題 | 規則 |
|------|----------|------|
| 1 | `## 概述` | 1–3 句，繁體中文說明概念用途 |
| 2 | `## 目前 API 簽名` | C# 程式碼區塊，標 `csharp`；協定/DevOps/遷移類可寫 "N/A" |
| 3 | `## 變更歷史` | Markdown 表格：版本 / 日期 / 變更內容 |
| 4 | `## 教學章節對應` | 條列式，指出每章使用情境 |
| 5 | `## 相關概念` | 使用 `[[concept-name]]` wiki-link 格式 |

## 4. 語言規則
- 散文使用**繁體中文**
- API 名稱、C# 型別、方法簽名、attribute、NuGet 套件名稱保持**英文原名**
- 程式碼區塊註解使用**繁體中文**

## 4.5 可引用的證據型別

條目正文引用 codebase-memory-mcp 佐證時，**只可引用穩定的結構性事實**：存在性、qualified_name、簽名、namespace、`src/<Package>/...` 路徑歸屬、繼承關係。

- ❌ **不得引用 `in_degree` / `out_degree` / caller 數量**。這是索引工具的產物而非 SDK 事實，會隨索引模式與工具版本變動；鏈式 fluent 擴充方法（`builder.AddMcpServer().WithX()`）的 CALLS 邊只記到鏈首，鏈上後續方法一律得到 0。
- 實證見 `raw/facts/codebase-memory-mcp-validation.md` 第 3 節：v2.2.0 下 `WithToolsFromAssembly`、`WithPromptsFromAssembly`、`WithResourcesFromAssembly`、`WithStdioServerTransport` 的 in_degree 皆為 0，但四者都存在且被測試呼叫。
- `drift-check` 同理：不得以 in_degree=0 或 `trace_path` 空結果判定 API 已移除，須以 `search_code` 交叉驗證。

## 4.6 素材的階層：conceptual doc 不是事實層

`raw/docs-conceptual/` 是**敘述素材**——它解釋設計意圖、使用情境與取捨，這些是章節敘事的好來源。但它**不是結構性事實的來源**。

引用它描述 API 的**形狀**（型別、成員、值域、預設值、行為）之前，一律回上游原始碼確認。兩者衝突時**以原始碼為準**，並在條目中標明官方文件此處易誤導。

實證：`apps.md:125` 把 `McpUiResourcePermissions` 寫成
`Sandbox permissions (scripts, forms, popups, etc.)`，但 `McpUiResourcePermissions.cs` 的 XML doc 明載它對應 iframe 的 `allow` attribute，值為 `camera`／`microphone`／`geolocation`／`clipboard-read`／`clipboard-write`。前者是 `sandbox` attribute 的 token，兩者不通用——照 conceptual doc 填不會生效。第 21 章初稿因直接轉述而寫錯，經第二意見審查抓出（P1-04）。

**判斷準則**：這句話如果錯了，讀者的程式會不會壞？會 → 必須查原始碼。不會（是動機、情境、取捨） → conceptual doc 可用。

> 同一原則的另一個面向見 §4.5：工具產物（in_degree 等）也不是事實。事實層只有兩個來源——**上游原始碼**與 **codebase-memory-mcp 圖譜**。

## 5. 來源追溯
- `sources` 列出的路徑必須實際存在於 `raw/` 目錄
- 若 raw/ 中無對應素材，`sources` 填空陣列 `[]`
- `/lint` 驗證 sources 路徑有效性

## 6. 版本對齊
- `current_version` 必須與 `raw/release-notes/` 中最新穩定版一致
- 上游發佈新版本時 `/compile` 需更新所有條目的 `current_version`
- `since` 一旦設定後不再變更

## 7. 交叉引用
- 相關概念使用 `[[concept-name]]`，須與 `wiki/concepts/` 檔名（去 `.md`）完全一致
- `/lint` 驗證所有 wiki-link 指向有效條目

## 8. 索引同步
- 每次 `/compile` 後同步更新 `wiki/INDEX.md`
- 新增條目時根據 tags 決定歸入哪個分類

## 9. 變更日誌
- 每次 `/compile` 後同步更新 `wiki/api-changelog.md`，以版本為主軸記錄 API 變更

## 10. 非 API 概念條目豁免規則

部分條目描述**架構指引、協定概念、遷移策略或套件清單**，而非特定 C# API，不要求 `## 目前 API 簽名` 區段。

| 條目類型 | 替代區段標題 | 說明 |
|------|------------|------|
| `docker-deployment.md` | `## 關鍵設定` | 容器化部署，無對應 C# API |
| `testing-strategy.md` | `## 關鍵技巧` | 測試模式，無單一 API |
| `nuget-packages.md` | `## 套件清單` + `## 安裝` | 套件清單，API 散佈各套件 |
| `what-is-mcp.md` | `## 協定概念` | MCP 規格概念，非 SDK API |
| `sessions.md` | `## 模式對照` | stateless/stateful 設計概念 |

**識別方式**：`api_name` 欄位填 `"N/A (描述)"` 的條目視為非 API 概念條目。
`/lint` 對 `api_name` 含 `"N/A"` 的條目跳過 `## 目前 API 簽名` 存在性檢查。

## 11. drift-check 整合

條目中供 `/drift-check` 比對使用的資訊：
- `api_name`：確認教學使用的類別名稱與最新 API 一致
- `namespace` + `package`：確認 `using` 與 `dotnet add package` 正確
- `tutorial_chapters`：識別哪些章節需檢查
- `## 目前 API 簽名`：做為比對教學範例程式碼的基準
