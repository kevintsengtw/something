---
generated: 2026-08-15
indexed_commit: 6fa3825973949a9c4f0cd8af344e15a8db09dc35
baseline: wiki/concepts/ (32 條目，v2.2.0) vs guide/ (50 個 Markdown；交付為 20 章與附錄 A/B/C)
upstream_tag: v2.2.0
status: enhancements-only
---

# 偏移報告

> 本報告以 v2.2.0 verified facts、最新 wiki concepts 與 codebase-memory-mcp 的 v2.2.0 索引做全量比對。`reviews/` 視為歷史審查證據；current guide 已依使用者核准的 `outdated` scope 完成更新。

## 摘要

| 等級 | 數量 | 說明 |
|------|------|------|
| 🔴 Breaking | 0 | v2.2.0 是非 breaking minor release；既有 B-001～B-003 維持已修正 |
| 🟡 Outdated | 0 | O-008～O-009 已於 2026-08-15 完成處置 |
| 🟢 Enhancement | 9 | 既有 8 項未選 enhancement，加上 header decode 邊界修正的非阻塞補充 |

## 🔴 Breaking

**無未修正 breaking。**

- [B-001] ✅ 第 17 章使用 `ModelContextProtocol.Extensions.Tasks`、`WithTasks` 與 v2 client lifecycle。
- [B-002] ✅ ch08/ch12 已反映 v2.0.0 的 stateless 預設值。
- [B-003] ✅ ch10/附錄 B 已反映 explicit SSE 保留底層例外。

v2.2.0 release notes 與 verified facts 的 breaking、removed、deprecated 數均為 0；`HttpServerTransportOptions.Stateless` 仍存在，並成為 `SessionMode` 的相容 proxy。

## 🟡 Outdated

**無未修正 outdated。**

| 項目 | 處置摘要 | 主要檔案 |
|------|---------|---------|
| O-008 | current baseline 與所有明確套件 pin 升至 v2.2.0；歷史版本表與舊 review 實證維持原版本語意 | README、ch01–20、附錄 A/B/C、reviews/README |
| O-009 | session 設定主線改為三態 `SessionMode`；補 hybrid 決策、stateless half 限制、callback 執行時機及 `Stateless` compatibility proxy | ch07、08、12、14、17–19、附錄 A/B/C |

結構性驗證：`HttpServerSessionMode`、`HttpServerTransportOptions.SessionMode` 與 `Stateless` proxy 均由 v2.2.0 索引及原始碼確認；三種模式行為另由 `July2026ProtocolHybridSessionModeTests` 與 options tests 對照。current 安裝指令均 pin v2.2.0。

## 🟢 Enhancement

### E-001：新增 MCP Apps 教學入口

- **現況**：guide 只在套件分工列出 Apps extension，尚未教 `WithMcpApps`、`McpAppUiAttribute` 或 UI resource。
- **來源 wiki**：`wiki/concepts/mcp-apps.md`
- **建議**：列為附錄或第二輪 enhancement；清楚標示 experimental surface。

### E-002：補充 MRTR 與 Tasks/Elicitation 的多輪輸入整合

- **現況**：第 15、17 章尚未完整串起 v2 的多輪輸入流程。
- **來源 wiki**：`wiki/concepts/multi-round-trip-requests.md`、`wiki/concepts/alternate-results.md`
- **建議**：介紹 `InputRequest`、`ResolveInputRequestsAsync` 與 experimental alternate result surface。

### E-003：補充 discovery-first 與結果快取提示

- **現況**：第 19 章已改為 discovery-first smoke，但 client 初始化章未完整說明 `DiscoverResult`、`ICacheableResult`、`CacheScope` 與 `MetaKeys.ServerInfo`。
- **來源 wiki**：`wiki/concepts/result-caching.md`、`wiki/concepts/mcp-client.md`
- **建議**：在第 10 章加入 discovery fallback、TTL/scope 與 v2.1.0 HTTP 400/404 fallback。

### E-004：補充 client known-tools 與 primitive 批次通知

- **現況**：第 10 章未涵蓋 `AddKnownTools`／`RemoveKnownTools`／`ClearKnownTools`；第 05–07、09 章未涵蓋 `DeferChangedEvents`。
- **來源 wiki**：`wiki/concepts/mcp-client.md`、`wiki/concepts/primitive-change-batching.md`
- **建議**：作為動態工具目錄與批次更新的進階段落。

### E-005：補充 v2 transport 與 error-code 選項

- **現況**：未完整涵蓋 `EnableStandaloneGetStream`、`InitializeMeta`、新 `McpErrorCode`、AutoDetect shared-channel 與跨 TFM status preservation。
- **來源 wiki**：`wiki/concepts/streamable-http-transport.md`、`wiki/concepts/mcp-client.md`、`wiki/concepts/elicitation.md`
- **建議**：在第 08、10、15 章加入進階 transport／error handling 說明。

### E-006：加入 Application Insights telemetry 範例導覽

- **現況**：guide 尚未導覽上游新增的 Application Insights sample。
- **來源 raw**：`raw/samples/README.md`
- **建議**：在 logging／部署章以選讀方式連結，不改成主線依賴。

### E-007：補充 binary embedded resource 的 client 顯示方式

- **現況**：resource 章著重文字內容，尚未涵蓋 binary embedded resource rendering guidance。
- **來源 raw**：`raw/docs-conceptual/tools.md`
- **建議**：補充 MIME type、blob 與 client rendering 邊界。

### E-008：補充 `InMemoryTransport` sample 的雙向 pipe 架構

- **現況**：testing 章有 in-memory 概念，但未導覽 v2.1.0 補齊的 sample README。
- **來源 raw**：`raw/samples/README.md`
- **建議**：作為不依賴 stdio／HTTP 的整合測試參考。

### E-009：記錄退化 base64 header wrapper 的解碼修正

- **現況**：guide 沒有教 `McpHeaderEncoder`，因此不構成既有敘述錯誤。
- **來源 facts**：`raw/facts/v2.2.0-verified-changes.json`
- **建議**：若未來新增自訂 protocol header 或互通性除錯附錄，再註明 `DecodeValue("=?base64?=")` 自 v2.2.0 起會原樣回傳而非拋例外；本輪不需為此改動主線章節。

## 結論

v2.2.0 **沒有未修正 breaking 或 outdated**。剩餘 9 項均為使用者未選入本輪的 enhancement，不應預設混入。教學處置後已刷新 knowledge graph 並完成 release lint；本報告未新增需要執行 build/test 的 guide 程式碼變更。
