---
updated: 2026-08-15
total_concepts: 32
last_compile: 2026-08-15 — 依 v2.2.0 verified facts 增量編譯：新增 HTTP server session mode concept，更新 sessions/Streamable HTTP，並將全部條目的 current_version 對齊 2.2.0。
last_sync: 2026-08-15 — /sync-upstream 完成（v2.2.0 release notes、13 篇 conceptual docs、samples）；source 對齊 v2.2.0。
baseline_version: v2.2.0
indexed_commit: 6fa3825973949a9c4f0cd8af344e15a8db09dc35
note: 全部 32 條目已編譯；package 歸屬以 csharp-sdk src/ file_path 第一段為準。v2.2.0 新增 hybrid stateful/stateless HTTP serving，無 breaking change。
---

# Wiki 概念索引（種子地圖）

> 本索引依官方 [conceptual docs](https://csharp.sdk.modelcontextprotocol.io/) 與 [GitHub repo](https://github.com/modelcontextprotocol/csharp-sdk) 規劃。
> API 名稱為官方文件實證，但所有結構性事實（namespace、簽名、所屬套件、since）**必須**經 `/extract-facts` → `/compile` 以 codebase-memory-mcp 驗證後才寫入各條目 frontmatter。
> 建立流程：`/sync-upstream` → `/extract-facts 2.2.0` → `/compile`（產生下列條目）→ `/snapshot-knowledge`。

## 核心概念（Core）

| 條目 | 主要 API | 套件 | 教學章節 | 狀態 |
|------|----------|------|----------|------|
| [[what-is-mcp]] | N/A（協定概念） | N/A | ch01 | ✅ |
| [[nuget-packages]] | `ModelContextProtocol` 系列 | 全部 | ch02, appendix-a | ✅ |
| [[mcp-server-builder]] | `AddMcpServer` / `McpServerOptions` / `McpServer.Create` | ModelContextProtocol | ch03, ch04 | ✅ |
| [[mcp-client]] | `McpClient` / `McpClient.CreateAsync` | ModelContextProtocol.Core | ch10 | ✅ |
| [[result-caching]] | `ICacheableResult` / `CacheScope` / `DiscoverResult` | ModelContextProtocol.Core | — | ✅ |

## 伺服器 Primitive（Server Primitives）

| 條目 | 主要 API | 套件 | 教學章節 | 狀態 |
|------|----------|------|----------|------|
| [[mcp-server-tools]] | `McpServerTool` / `[McpServerTool]` / `[McpServerToolType]` / `WithToolsFromAssembly` / `WithTools<T>` | ModelContextProtocol.Core（型別）; ModelContextProtocol（WithX 擴充）| ch04, ch05, ch11 | ✅ |
| [[mcp-server-prompts]] | `[McpServerPrompt]` / `[McpServerPromptType]` | ModelContextProtocol.Core | ch06 | ✅ |
| [[mcp-server-resources]] | `[McpServerResource]` / `[McpServerResourceType]` / `ResourceContents` / `TextResourceContents` / `BlobResourceContents` | ModelContextProtocol.Core | ch07, ch11 | ✅ |
| [[primitive-change-batching]] | `McpServerPrimitiveCollection<T>.DeferChangedEvents` | ModelContextProtocol.Core | — | ✅ |

## 客戶端（Client）

| 條目 | 主要 API | 套件 | 教學章節 | 狀態 |
|------|----------|------|----------|------|
| [[mcp-client-tools]] | `McpClientTool`（: `AIFunction`） / `ListToolsAsync` / `CallToolAsync` | ModelContextProtocol.Core | ch10, ch16 | ✅ |
| [[mcp-client-resources]] | `McpClientResource` / `ListResourcesAsync` / `ReadResourceAsync` / `ListResourceTemplatesAsync` | ModelContextProtocol.Core | ch10 | ✅ |

## 傳輸層（Transports）

| 條目 | 主要 API | 套件 | 教學章節 | 狀態 |
|------|----------|------|----------|------|
| [[stdio-transport]] | `WithStdioServerTransport` / `StdioClientTransport` / `StdioClientTransportOptions` | ModelContextProtocol.Core（型別）; ModelContextProtocol（WithStdioServerTransport）| ch04, ch08 | ✅ |
| [[streamable-http-transport]] | `WithHttpTransport` / `MapMcp` / SSE | ModelContextProtocol.AspNetCore | ch08, ch12 | ✅ |
| [[in-memory-transport]] | `StreamServerTransport` / `StreamClientTransport` | ModelContextProtocol.Core | ch13（測試） | ✅ |
| [[sessions]] | N/A（stateless vs stateful 設計） | ModelContextProtocol.AspNetCore | ch08, ch12 | ✅ |
| [[http-server-session-mode]] | `HttpServerSessionMode` / `HttpServerTransportOptions.SessionMode` | ModelContextProtocol.AspNetCore | ch08, ch12 | ✅ |

## 伺服器↔客戶端進階（Server ↔ Client / Advanced）

| 條目 | 主要 API | 套件 | 教學章節 | 狀態 |
|------|----------|------|----------|------|
| [[sampling]] | `CreateSamplingHandler` / sampling capability | ModelContextProtocol.Core | ch14 | ✅ |
| [[elicitation]] | elicitation capability | ModelContextProtocol.Core | ch15 | ✅ |
| [[tasks]] | `WithTasks` / `IMcpTaskStore` / `TasksProtocol` | ModelContextProtocol.Extensions.Tasks | ch17 | ✅ |
| [[multi-round-trip-requests]] | `InputRequest` / `ResolveInputRequestsAsync` | ModelContextProtocol.Core | — | ✅ |
| [[alternate-results]] | `ResultOrAlternate<TResult>`（MCPEXP002）| ModelContextProtocol.Core | — | ✅ |
| [[notifications-progress]] | `SendNotificationAsync` / `NotificationMethods` / progress | ModelContextProtocol.Core | ch09 | ✅ |
| [[subscriptions-listen]] | `WithSubscriptionsListenHandler` / `McpServerHandlers.SubscriptionsListenHandler` | ModelContextProtocol + ModelContextProtocol.Core | ch07, ch08, ch12 | ✅ |
| [[logging-and-completion]] | logging capability / completion（`AllowedValuesAttribute` 為 .NET BCL，非 SDK 型別） | ModelContextProtocol.Core | ch09 | ✅ |

## 驗證與安全（Auth & Security）

| 條目 | 主要 API | 套件 | 教學章節 | 狀態 |
|------|----------|------|----------|------|
| [[authorization]] | OAuth 2.1 / OIDC / PKCE / `IdentityAssertionGrantProvider` | ModelContextProtocol.Core（client/共用 auth）+ .AspNetCore（server handler）；**無獨立 .Authentication 套件** | ch18 | ✅ |
| [[transport-security]] | N/A（host validation / CORS / DNS rebinding） | ModelContextProtocol.AspNetCore | ch12, ch18 | ✅ |

## 整合（Integration）

| 條目 | 主要 API | 套件 | 教學章節 | 狀態 |
|------|----------|------|----------|------|
| [[mef-ai-integration]] | `IChatClient` / `AIFunction`（外部 Microsoft.Extensions.AI） | 外部 NuGet | ch16 | ✅ |
| [[mcp-apps]] | `WithMcpApps` / `McpAppUiAttribute`（MCPEXP003）| ModelContextProtocol.Extensions.Apps | — | ✅ |

## 託管與部署（Hosting & Ops）

| 條目 | 主要 API | 套件 | 教學章節 | 狀態 |
|------|----------|------|----------|------|
| [[aspnetcore-hosting]] | `MapMcp` / `AddMcpServer` / `WithHttpTransport` | ModelContextProtocol.AspNetCore | ch12 | ✅ |
| [[aot-compatibility]] | Native AOT / source generation | 全部 | ch20 | ✅ |
| [[testing-strategy]] | N/A（測試模式 + in-memory transport） | N/A | ch13 | ✅ |
| [[docker-deployment]] | N/A（DevOps） | N/A | ch19 | ✅ |

---

## 按教學章節反查（規劃）

| 章節 | 相關概念 |
|------|----------|
| ch01 | [[what-is-mcp]] |
| ch02 | [[nuget-packages]], [[what-is-mcp]] |
| ch03 | [[mcp-server-builder]], [[nuget-packages]] |
| ch04 | [[mcp-server-builder]], [[mcp-server-tools]], [[stdio-transport]] |
| ch05 | [[mcp-server-tools]] |
| ch06 | [[mcp-server-prompts]] |
| ch07 | [[mcp-server-resources]], [[subscriptions-listen]] |
| ch08 | [[stdio-transport]], [[streamable-http-transport]], [[sessions]], [[http-server-session-mode]], [[subscriptions-listen]] |
| ch09 | [[notifications-progress]], [[logging-and-completion]] |
| ch10 | [[mcp-client]], [[mcp-client-tools]], [[mcp-client-resources]] |
| ch11 | [[mcp-server-tools]], [[mcp-server-resources]] |
| ch12 | [[aspnetcore-hosting]], [[streamable-http-transport]], [[sessions]], [[http-server-session-mode]], [[transport-security]], [[subscriptions-listen]] |
| ch13 | [[testing-strategy]], [[in-memory-transport]] |
| ch14 | [[sampling]] |
| ch15 | [[elicitation]] |
| ch16 | [[mef-ai-integration]], [[mcp-client-tools]] |
| ch17 | [[tasks]] |
| ch18 | [[authorization]], [[transport-security]] |
| ch19 | [[docker-deployment]] |
| ch20 | [[aot-compatibility]] |
| appendix-a | [[nuget-packages]] |

---

## brainstorming/qa-sessions 記錄

| 檔案 | 主題 | 相關概念 | promoted |
|------|------|----------|---------|
| （尚無） | | | |
