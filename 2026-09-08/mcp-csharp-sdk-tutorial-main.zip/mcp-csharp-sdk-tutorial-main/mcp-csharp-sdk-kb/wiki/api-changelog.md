# API 變更時間線（API Changelog）

> 由 `/compile` 維護，以版本為主軸記錄 MCP C# SDK 的 API 層面變更。
> 目前基準版本 v2.2.0（indexed commit `6fa3825`）。結構性事實來源：`raw/release-notes/*.md` + `raw/facts/*-verified-changes.json`（皆經 codebase-memory-mcp 驗證）。

| 版本 | 日期 | 類型 | 變更摘要 |
|------|------|------|---------|
| 2.2.0 | 2026-08-13 | ✨ Added + 🛠 Fix | 新增 `HttpServerSessionMode` 與 hybrid HTTP session mode；修正退化 base64 header wrapper 解碼 |
| 2.1.0 | 2026-08-05 | ✨ Added + 🛠 Reliability | 新增公開 `subscriptions/listen` server handler；改善 discovery/AutoDetect fallback 與 HTTP status 保存 |
| 2.0.0 | 2026-07-28 | 🔴 Major + ✨ Added + 🔒 Security | 對齊 MCP 2026-07-28；stateless/discovery-first、Tasks/Apps extensions、MRTR、快取提示與 OAuth 強化 |
| 1.4.0 | 2026-06-04 | ✨ Added + 🔒 Security | ID-JAG 企業授權、`InheritEnvironmentVariables`、session 安全強化 |
| 1.3.0 | 2026-05-08 | ✨ Added | `ClientTransportClosedException` 公開（: IOException）|
| 1.2.0 | 2026-03-27 | 🔴 Breaking（行為）| legacy SSE 預設停用；2-arg `RequestContext` ctor 標 Obsolete |
| 1.1.0 | 2026-03-06 | ✨ Added | `AllowedValuesAttribute` 自動補全、client completion details |
| 1.0.0 | 2026-02-25 | 🎉 Stable | 首個穩定版；`RunSessionHandler` 標 Experimental |

---

## v2.2.0（2026-08-13）

### ✨ Added

- `HttpServerSessionMode`（namespace `ModelContextProtocol.AspNetCore`、套件 `ModelContextProtocol.AspNetCore`）提供 `Stateless`、`Stateful` 與 `StatefulForInitializeClients`
- `HttpServerTransportOptions.SessionMode` 以三態設定取代只靠布林值表達 session 策略的限制
- `StatefulForInitializeClients` 讓 initialize-handshake client 使用 session，2026-07-28 client 則在同一 endpoint 以 stateless request 運作

### 🛠 Fix

- `HttpServerTransportOptions.Stateless` 保留為 `SessionMode` 相容 proxy；最後一次設定的屬性決定實際模式
- `McpHeaderEncoder.DecodeValue("=?base64?=")` 對退化且重疊的 wrapper 回傳原字串，不再於截取內容時拋出例外

> 無 breaking、deprecated 或 removed 項目。facts 統計：4 筆已驗證、0 筆未驗證。

## v2.1.0（2026-08-05）

### ✨ Added

- `McpServerBuilderExtensions.WithSubscriptionsListenHandler`（namespace `Microsoft.Extensions.DependencyInjection`、套件 `ModelContextProtocol`）
- `McpServerHandlers.SubscriptionsListenHandler`（namespace `ModelContextProtocol.Server`、套件 `ModelContextProtocol.Core`）
- 自訂 handler 完整接管 SEP-2575 `subscriptions/listen` stream，可支援 stateless Streamable HTTP 的 request-bound 通知

### 🛠 Reliability

- `server/discover` probe 收到 plain HTTP 400/404 時回退至 `initialize` handshake；其他 HTTP status 仍直接回報
- AutoDetect provisional SSE failure 不再提早關閉共用 message channel
- `HttpRequestException` 的 HTTP status code 可跨 target framework 保存

> 無 breaking、deprecated 或 removed 項目。facts 統計：5 筆已驗證、0 筆未驗證。

## v2.0.0（2026-07-28）

### 🔴 Breaking / Relocated

- `HttpServerTransportOptions.Stateless` 預設值改為 `true`；client 採 discovery-first negotiation
- Tasks 移至 `ModelContextProtocol.Extensions.Tasks`；v1.4.x 實作與新 API、wire format 不相容，改用 `WithTasks`、`TasksProtocol` 與 extension methods
- `Tool.inputSchema` 在反序列化時為必要欄位
- 2026-07-28 peer 的非 object structured tool result 使用自然 JSON 值，不再固定包成 `{ result: value }`
- OAuth metadata 必須明確支援 PKCE `S256`；無新增 scope 的重複 `insufficient_scope` challenge 直接失敗
- SSE 連線失敗直接傳遞底層例外，不再一律包成 `IOException`
- `DiscoverResult.ServerInfo` 移除；改由 `MetaKeys.ServerInfo` 讀取 meta

### ✨ Added

- client known-tools 快取：`AddKnownTools`、`RemoveKnownTools`、`ClearKnownTools`
- OAuth：`ScopeSelectorDelegate`、`AuthorizationCallbackHandler`、`DynamicClientRegistrationOptions.ApplicationType`
- discovery/cache：`DiscoverResult`、`ICacheableResult`、`CacheScope`
- HTTP client：`EnableStandaloneGetStream`
- Tasks extension：`WithTasks`、`TasksProtocol`、`ResultOrCreatedTask<TResult>` 與 `CallToolAsTaskAsync`
- MCP Apps extension：`WithMcpApps`、experimental `McpAppUiAttribute`（MCPEXP003）
- extensibility：experimental `ResultOrAlternate<TResult>`（MCPEXP002）
- MRTR：`InputRequest`、`McpClient.ResolveInputRequestsAsync`
- primitive batching：`McpServerPrimitiveCollection<T>.DeferChangedEvents`
- error codes：`MissingRequiredClientCapability`、`UnsupportedProtocolVersion`、`UrlElicitationRequired`

### ⚠️ Deprecated

- `AuthorizationRedirectDelegate` → `AuthorizationCallbackHandler`（MCP9007）
- Roots、Sampling、Logging convenience APIs（代表項目：`RequestRootsAsync`、`AsSamplingChatClient`、`AsClientLoggerProvider`）標記 MCP9005
- `McpErrorCode.ResourceNotFound` 標記 `[Obsolete]`

> facts 統計：37 筆已驗證、2 筆未驗證。未驗證項目是 prerelease/internal rename 敘述，不納入結構性 frontmatter。

## v1.4.0（2026-06-04）

### ✨ Added
- `IdentityAssertionGrantProvider`（ns `ModelContextProtocol.Authentication`，套件 **.Core**，PR #1305 / SEP-990）— ID-JAG 企業 SSO 授權，含 `IdentityAssertionGrantProviderOptions`、`IdentityAssertionGrantContext`、`IdentityAssertionGrantException`、`IdentityAssertionGrantIdTokenCallback`
- `StdioClientTransportOptions.InheritEnvironmentVariables`（`bool`，預設 `true`，ns `ModelContextProtocol.Client`，套件 .Core，PR #1563）

### 🔒 Security
- session `DELETE` 現要求相同已驗證使用者（`HandleDeleteRequestAsync` + `HasSameUserId`，否則 403；PR #1604，套件 .AspNetCore）
- stdio 傳輸不再於 Trace log 列出子行程環境變數（PR #1538，套件 .Core）

> 無 breaking change。詳見 `raw/facts/v1.4.0-verified-changes.json`。

## v1.3.0（2026-05-08）

### ✨ Added
- `ClientTransportClosedException` 公開（derives `IOException`，PR #1467）— stdio/HTTP client 取得結構化的傳輸關閉細節
- 行為調整：SSE/HTTP 連線失敗自 `McpClient.CreateAsync` 改以 `IOException`（而非 `InvalidOperationException`）回報

## v1.2.0（2026-03-27）

### 🔴 Breaking（行為）
- `MapMcp()` 預設不再 map legacy SSE 端點 `/sse`、`/message`；以 `HttpServerTransportOptions.EnableLegacySse=true` 對應（`[Obsolete]` 診斷 **MCP9004**，PR #1468）
- `RequestContext(McpServer, JsonRpcRequest)` 2-arg ctor 標 `[Obsolete]`（診斷 **MCP9003**）；改用 3-arg `RequestContext(server, request, parameters)`（PR #1462）；`Params` 由 `TParams?` 改為 `TParams`

### ✨ Added
- 工具回傳 `CallToolResult` 時可獨立指定 output schema：`McpServerToolAttribute.OutputSchemaType`（`Type?`，ns `ModelContextProtocol.Server`，套件 .Core，PR #1425；git 首見 commit `2958a75`，earliest tag v1.2.0）；SDK 據此填入 protocol 層 `Tool.OutputSchema`

## v1.1.0（2026-03-06）

### ✨ Added
- prompt / resource 參數的 `AllowedValuesAttribute`（.NET BCL）自動產生 completion handler（PR #1380）
- client completion notification / details（PR #1368）

## v1.0.0（2026-02-25）

### 🎉 Stable
- 首個穩定版，完整 2025-11-25 MCP 規格支援

### ⚠️ Experimental
- `HttpServerTransportOptions.RunSessionHandler` 標 `[Experimental("MCPEXP002")]`（PR #1383）；建議改用 `ConfigureSessionOptions`，以 `#pragma warning disable MCPEXP002` 抑制
