# mcp-csharp-sdk-kb — LLM Wiki 知識庫

MCP C# SDK 繁中教學的知識庫，基於 [Karpathy LLM Wiki](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) pattern，沿用 `agent-framework-tutorial` 的事實層/敘述層二分設計。

## 目錄
- `AGENTS.md` — Codex 的 kb 補充指引
- `CLAUDE.md` — kb 補充指引（條目格式、編譯規則、工具呼叫慣例）
- `WORKFLOW-DESIGN-v1.md` — 工作流完整設計
- `PLAYBOOK-version-update.md` — 版本更新操作手冊（Pipeline A）
- `QuickStart.md` — 快速操作指南
- `UPSTREAM-REF.md` — 上游 commit/tag 對齊記錄
- `wiki/` — 結構化知識
  - `SCHEMA.md` — 條目編譯規則
  - `INDEX.md` — 概念分類索引 + 章節反查
  - `concepts/` — 32 個已編譯概念條目
  - `api-changelog.md` / `drift-report.md`
  - `.understand-anything/` — Codex-native generator 產生的 UA 相容知識圖譜與 metadata
  - `graph-augmentations.json` — 已審查的 entity/claim 敘述層素材
- `raw/` — 上游素材鏡像（唯讀，由 `sync-upstream` 工作流抓取）
  - `release-notes/` `docs-conceptual/` `devblogs/` `samples/` `api-surface/` `facts/`
- `brainstorming/qa-sessions/` — 問答記錄

## 目前狀態

✅ **v2.2.0 基準與 Codex Level 2 維運能力已完成**。`wiki/concepts/` 含 32 個概念條目，facts、API inventory、knowledge graph 與 drift report 均已建立；knowledge graph 可由 repository 內建流程重建、驗證及 rollback-safe 發布。對應 guide 的 20 章與附錄 A/B/C 已完成第二意見審查並具備發佈條件。

目前 `csharp-sdk/` worktree、codebase-memory-mcp 索引與 facts/wiki 基準均對齊 v2.2.0（commit `6fa3825`、MCP 規格 2026-07-28）。詳見 `UPSTREAM-REF.md`；後續版本更新依 `PLAYBOOK-version-update.md` 執行。
