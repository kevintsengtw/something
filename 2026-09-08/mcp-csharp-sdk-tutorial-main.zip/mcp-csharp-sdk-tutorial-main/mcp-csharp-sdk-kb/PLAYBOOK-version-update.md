# MCP C# SDK 版本更新 Playbook

> 當 MCP C# SDK 發佈新版本時，依本文步驟執行教學同步更新。對應 [`./WORKFLOW-DESIGN-v1.md`](./WORKFLOW-DESIGN-v1.md) 的 Pipeline A。

## 前置條件
- Codex CLI（主要）或 Claude Code（並存期）
- 工作區根 `mcp-csharp-sdk-tutorial/`（repository skills / commands 入口）
- 三子目錄存在：`csharp-sdk/`、`mcp-csharp-sdk-kb/`、`mcp-csharp-sdk-guide/`
- codebase-memory-mcp 已安裝且通過 macOS 驗證
- Node.js 可執行 repository 內的 deterministic graph builder、validator、publisher 與 tests
- `csharp-sdk/` 已索引（project 名由路徑自動產生、因機而異；以 `list_projects` 取以 `/csharp-sdk` 結尾者，見 `AGENTS.md` 與 `UPSTREAM-REF.md`）

---

## Step 1：同步上游素材
```text
$sync-upstream
```
確認：`raw/release-notes/` 出現新版本檔案、`raw/docs-conceptual/` 更新、samples README 更新、codebase-memory-mcp 索引同步、步驟 8 的新 API 存在性確認清單。預估 3–5 分鐘。

## Step 2：建立事實清單
```text
$extract-facts <new-version>
```
確認：`raw/facts/v<version>-verified-changes.json` 產出、終端顯示「已驗證 X / 未驗證 Y」。**事實層源頭**，後續 `$compile-knowledge` frontmatter 從此取得。預估 5–10 分鐘。

## Step 3：編譯知識庫
```text
$compile-knowledge
```
確認：wiki/concepts/ 條目清單、INDEX.md 同步、api-changelog.md 新增版本段落、所有條目 `current_version` 更新。frontmatter（api_name/namespace/package/since/current_version）來自 raw/facts/。預估 5–10 分鐘。

## Step 4：知識圖譜快照
```text
$snapshot-knowledge
```
確認：先在 repository 外 staging 重建，再以 validator 比對正式 baseline；article/entity/claim、既有語意邊不得遺失，orphan nodes 必須為零。Dashboard smoke 通過且使用者明確核准後，才以 rollback-safe publisher 更新 `.understand-anything/`；失敗時保留最後有效快照。詳細命令與閘門見 `.agents/skills/snapshot-knowledge/SKILL.md`。

## Step 5：偏移檢查
```text
$drift-check
```
確認：`wiki/drift-report.md` 重新產生、三級偏移分類。

| 等級 | 意義 | 行動 |
|------|------|------|
| 🔴 Breaking | 會編譯失敗 | 必須立即修復 |
| 🟡 Outdated | 過時但可運作 | 建議修復 |
| 🟢 Enhancement | 可選補充 | 評估決定 |

## Step 6：規劃修改範圍
優先順序：🔴 → 🟡 → 🟢。檔案多（>5）時分批。

## Step 7：教學修改
```text
$update-tutorial breaking
$update-tutorial outdated
```
替換前 codebase-memory-mcp 確認新名稱存在（**硬性規定**）。預估 10–20 分鐘。

## Step 8：驗證
```text
$drift-check    ← 確認 🔴 = 0
$lint-tutorial  ← wiki + tutorial 一致性
```

## Step 9：更新版本記錄

教學／知識庫層：

- `mcp-csharp-sdk-guide/README.md` — 版本資訊
- `mcp-csharp-sdk-guide/appendix-a-nuget-packages.md` — NuGet 版本號與版本時間線
- `mcp-csharp-sdk-kb/UPSTREAM-REF.md` — tag/commit/索引規模 + 歷史記錄一列
- 本檔歷次執行記錄表

**工作區層基準宣告（過去三次版本更新都漏掉這一組，不可省略）**：

- `README.md`（工作區根）— 基準版本、最後更新、目錄結構、SDK 套件速覽
- `SETUP.md` — `git checkout <tag>`、concepts 數量
- `CLAUDE.md`（工作區根）— §6 codebase-memory-mcp 驗證狀態、§10 基準版本
- `AGENTS.md` — 「專案狀態」基準行
- `mcp-csharp-sdk-kb/README.md` — 目前狀態段、concepts 數量
- `mcp-csharp-sdk-kb/QuickStart.md` — `git checkout <tag>`、concepts 數量
- `mcp-csharp-sdk-kb/WORKFLOW-DESIGN-v1.md` — 目前基準版本行

> `node scripts/lint-docs.mjs` 的 `baseline-version` 規則會以 `UPSTREAM-REF.md` 主表的 Tag 為 ground truth，強制檢查上述檔案的基準宣告；漏改會讓 lint 直接失敗。跨 minor/major 版本時另需依 `CLAUDE.md` §6 重跑七項 codebase-memory-mcp 探測並更新 `raw/facts/codebase-memory-mcp-validation.md`。

---

## 完整流程圖

```text
上游發佈新版本
  → $sync-upstream            （raw/ 素材 + 索引同步 + search_graph 存在性）
  → $extract-facts <ver>      （事實 JSON：search_graph + get_code_snippet + trace_path inbound）
  → $compile-knowledge        （wiki：snippet + search_code sources + 廢棄確認）
  → $snapshot-knowledge       （staging 重建 + schema/diff/Dashboard 驗證 + 安全發布）
  → $drift-check              （query_graph 存在性 + search_code usage）
  → 閱讀 drift-report
  → $update-tutorial          （search_graph 替換方向確認）
  → $drift-check              （🔴 = 0）
  → $lint-tutorial
  → 更新版本記錄
  → 完成 ✅
```

## 預估總時間
約 1–2 小時（Step 1–5 自動化 25–40 分、Step 6 規劃 5–10 分、Step 7 修改 30–60 分、Step 8–9 驗證 10–15 分）。

---

## 歷次執行記錄

| 版本 | 執行日期 | drift 結果 | 修改檔案數 | 備註 |
|------|----------|-----------|-----------|------|
| v1.4.0 | 2026-06-30 | —（guide 尚無章節，drift-check 未適用） | — | **首次建庫完成**：clone+index v1.4.0 (`06e3604`, 7084 nodes)、驗證 7/7、/sync-upstream + /extract-facts 1.4.0 + /compile 產生 25 個概念條目、/snapshot-knowledge 產生 knowledge-graph.json。事實層修正了 stub 推測（AddMcpServer ns、無獨立 Authentication 套件、McpClientFactory→McpClient）。剩 outputs/ 4 篇章節草稿待 review 移入 guide/ |
| v2.0.0 → v2.1.0 | 2026-08-10 | 🔴 0（B-001～B-003 已於本輪修正）；🟡 已處置 | 101（commit `9b1d4b7`） | 一次合併處理 v2.0.0 與 v2.1.0：clone 對齊 v2.1.0 (`3be47ee`)、索引 8636 nodes / 29684 edges；產出 `v2.0.0-verified-changes.json`、`v2.1.0-verified-changes.json`，concepts 擴增至 32 條目。**工作區層基準宣告未同步更新**（見 2026-09-04 補正）。 |
| v2.2.0 | 2026-08-15 | 🔴 0／🟡 0／🟢 9（enhancements-only） | 82（commit `d0a1762`） | clone 對齊 v2.2.0 (`6fa3825`)、完整重建索引 8746 nodes / 29659 edges；`HttpServerSessionMode` 三態與 hybrid session mode 納入 ch08/ch12/附錄 B。**工作區層基準宣告未同步更新**（見 2026-09-04 補正）。 |
| v2.2.0 graph | 2026-08-24 | 無新 drift | 6（commit `fa1de98`） | 知識圖譜狀態刷新；證據見 `validation/knowledge-graph-refresh-2026-08-24.md`。 |
| v2.2.0 補正 | 2026-09-04 | 上游查無新版本（v2.2.0 仍為 latest；`origin/main` 有 4 筆未 tag commit） | 工作區層文件 + lint 規則 + skills | 補正 v2.0.0～v2.2.0 三輪遺漏的工作區層基準宣告（root `README.md`/`SETUP.md`/`CLAUDE.md`、kb `README.md`/`QuickStart.md`/`WORKFLOW-DESIGN-v1.md`、`CODEX-HANDOFF-PLAN.md` 檔頭）；新增 `lint-docs.mjs` 的 `baseline-version` 規則與本 Step 9 清單，使同類遺漏後續由 lint 攔截。另重跑七項 codebase-memory-mcp 探測（v1.4.1 後首次），結果 6/7 通過並修正 in_degree 慣例。 |
| v1.4.1 graph | 2026-07-18 | 無教學 drift；UA Level 2 工作流更新 | graph + workflow artifacts | 採 G2 路徑 C，以 deterministic wiki graph + reviewed augmentations 重建；102 nodes、228 edges、零 orphan，Dashboard 與 rollback smoke 通過。 |
