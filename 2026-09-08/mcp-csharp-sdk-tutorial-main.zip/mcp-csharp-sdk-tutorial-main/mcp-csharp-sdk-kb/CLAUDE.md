# MCP C# SDK 知識庫（LLM Wiki）— 補充指引

> **重要**：本檔是工作區根 [`../CLAUDE.md`](../CLAUDE.md) 的**補充指引**，不是主導文件。
> 工具二分原則、指令入口點、版本更新流程等基本規範請見工作區根 CLAUDE.md。
> 設計依據：[`./WORKFLOW-DESIGN-v1.md`](./WORKFLOW-DESIGN-v1.md)

---

## 1. 本目錄角色

| 子目錄 | 用途 | 規則 |
|------|------|------|
| `raw/release-notes/` | GitHub release notes（per-version） | **唯讀** |
| `raw/docs-conceptual/` | 官方 conceptual docs 鏡像 | **唯讀**；屬敘述素材，非事實層——描述 API 形狀前須回原始碼確認（見 [`wiki/SCHEMA.md`](./wiki/SCHEMA.md) §4.6） |
| `raw/devblogs/` | .NET DevBlog 版本文章 | **唯讀** |
| `raw/samples/` | 官方 samples README 摘要 | **唯讀** |
| `raw/api-surface/` | 各套件公開 API 摘要 | **唯讀** |
| `raw/facts/` | `/extract-facts` 產出的事實清單 JSON | 由指令自動寫入 |
| `wiki/concepts/` | LLM 編譯的結構化知識 | 由 `/compile` 產生與更新 |
| `wiki/INDEX.md` | 分類索引 + 章節反查表 | 由 `/compile` 維護 |
| `wiki/api-changelog.md` | API 變更時間線 | 由 `/compile` 維護 |
| `wiki/drift-report.md` | 偏移檢查報告 | 由 `/drift-check` 每次完整覆寫 |
| `.understand-anything/` | Understand-Anything 知識圖譜產出 | 由 `/snapshot-knowledge` 維護 |
| `brainstorming/qa-sessions/` | `/wiki-query` 問答記錄 | 由 `/save-qa` 產生，`/compile` 會掃描 |

**指令入口點**：所有 slash commands 都住在 `../.claude/commands/`（工作區根），不在本目錄內。

---

## 2. 語言規範

- 所有 `wiki/` 產出使用**繁體中文**
- API 名稱、類別名稱、方法簽名、attribute、NuGet 套件名稱保持英文原名
- frontmatter 欄位名稱使用英文

---

## 3. wiki/concepts/ 條目格式

詳見 [`wiki/SCHEMA.md`](./wiki/SCHEMA.md)。frontmatter 必含：title、api_name、namespace、**package**、since、current_version、updated、tags、tutorial_chapters、sources。

**frontmatter 嚴格規範**：
- `api_name`、`namespace`、`package`、`since`、`current_version` **必須來自 `raw/facts/*.json` 的已驗證事實**
- 若該 API 未經 `/extract-facts` 驗證，frontmatter 留空並改用 `<!-- 待驗證 -->` 註解
- LLM 不得在條目敘述中即興宣告 API 簽名或方法存在

---

## 4. drift-check 偵測規則

### 🔴 Breaking（教學範例會編譯失敗）
- guide/ 中的 C# 類別名稱在最新 API 中已不存在（`search_graph` 確認；**不可只憑 in_degree=0 或 trace_path 空結果判定**，須以 `search_code` 交叉驗證，否則會產生假 breaking——見 `raw/facts/codebase-memory-mcp-validation.md` 第 3 節）
- 方法簽名不匹配（`get_code_snippet` 確認）
- using namespace 已變更
- NuGet 套件名稱/profile 已改名
- 集合型別 breaking（`List<T>`/`T[]` → `IList<T>` 等）
- API 被標 Experimental（`MCPEXP###`）但教學未加抑制

### 🟡 Outdated
- 描述文字使用舊名稱
- NuGet 套件版本過時（落後 2+ minor）
- 範例可運作但非最佳實踐（如未顯式 `Stateless`）

### 🟢 Enhancement
- 上游新增了教學未涵蓋的功能（Tasks、Elicitation、新驗證模式等）
- 有新官方 sample 可參考

---

## 5. 工具呼叫慣例（kb 範圍內）

| 場景 | 工具 | 用途 |
|------|------|------|
| 確認 API 存在 | `search_graph` | 取得節點與基本資訊 |
| 取簽名與位置 | `get_code_snippet` | namespace、file_path、signatures |
| Cypher 查詢 | `query_graph` | namespace 核對、屬性查詢 |
| 廢棄確認 | `trace_path` direction: inbound | 結果為空 **不等於**已廢棄——鏈式 fluent 擴充方法的邊只記到鏈首，須再以 `search_code` 交叉驗證 |
| 取上游使用範例 | `search_code` | 從上游 tests/samples 找實際用法 |
| 取依賴鏈 | `trace_path` direction: outbound | 確認新 API 依賴結構 |
| wiki 知識圖譜 | `/understand-knowledge mcp-csharp-sdk-kb/wiki --language zh-TW` | 由 `/snapshot-knowledge` 包裝 |

> ⚠️ codebase-memory-mcp 的 project 名由**索引時的絕對路徑**自動產生，**不是** `csharp-sdk`。所有呼叫一律寫 `<csharp-sdk-project>` placeholder，每個 session 首次查詢前先以 `list_projects` 取 root path 以 `/csharp-sdk` 結尾者代入。規約見工作區根 [`../CLAUDE.md`](../CLAUDE.md) §6 與 [`./UPSTREAM-REF.md`](./UPSTREAM-REF.md)。

---

## 6. 重要禁止事項
- ❌ 不要在 wiki/concepts/ 條目中即興宣告 API 簽名——必須來自 raw/facts/ 或 codebase-memory-mcp
- ❌ 不要在 raw/ 目錄修改任何上游素材——它是唯讀基準層
- ❌ 不要在本目錄新增 `.claude/` 子目錄——指令入口點只在工作區根
- ❌ 不要在 wiki/ 中製造未經 `/lint` 驗證的交叉引用（`[[xxx]]`）

---

## 7. 參考連結
- 工作區根主導文件：[`../CLAUDE.md`](../CLAUDE.md)
- 工作流設計：[`./WORKFLOW-DESIGN-v1.md`](./WORKFLOW-DESIGN-v1.md)
- 版本更新操作手冊：[`./PLAYBOOK-version-update.md`](./PLAYBOOK-version-update.md)
- 上游對齊記錄：[`./UPSTREAM-REF.md`](./UPSTREAM-REF.md)
- 快速操作指南：[`./QuickStart.md`](./QuickStart.md)
