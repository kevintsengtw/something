---
fetched: 2026-08-15
last_sync_version: 2.2.0
source: https://github.com/modelcontextprotocol/csharp-sdk/tree/v2.2.0/samples
indexed_commit: 6fa3825973949a9c4f0cd8af344e15a8db09dc35
---

# 官方 Samples 摘要

> 由 `/sync-upstream` 維護。素材、本機 `csharp-sdk/` 與 codebase-memory 索引均對齊官方 `v2.2.0` tag。
> 「用到的核心 API」欄位以目錄語意與上游 `Program.cs`/README 為依據，作為 `/compile` 與 `/draft-chapter` 的素材線索；確切簽名仍以 `raw/facts/*.json` 為準。

| Sample 目錄 | 說明 | 用到的核心 API（線索） | 對應章節 |
|-------------|------|---------------|---------|
| `QuickstartWeatherServer` | 最小 stdio MCP server（天氣工具），官方 quickstart | `AddMcpServer` / `WithStdioServerTransport` / `WithToolsFromAssembly` / `[McpServerTool]` | ch03, ch04 |
| `QuickstartClient` | 最小 MCP client，連 stdio server 並呼叫工具 | `McpClient.CreateAsync` / `StdioClientTransport` / `ListToolsAsync` / `CallToolAsync` | ch10 |
| `EverythingServer` | 綜合 server，示範 tools/prompts/resources/完整 primitive | `[McpServerTool]` / `[McpServerPrompt]` / `[McpServerResource]` | ch05, ch06, ch07 |
| `FileBasedMcpServer` | 以檔案為基礎的完整 MCP server 範例 | `[McpServerResource]` / resources | ch07 |
| `AspNetCoreMcpServer` | ASP.NET Core 託管的 HTTP MCP server | `AddMcpServer` / `WithHttpTransport` / `MapMcp` | ch08, ch12 |
| `AspNetCoreMcpPerSessionTools` | per-session 動態工具（依 session 提供不同工具） | `MapMcp` / session 設定 / `WithHttpTransport` | ch08, ch12 |
| `TestServerWithHosting` | 以 Generic Host 託管的 server（測試用） | `Host.CreateApplicationBuilder` / `AddMcpServer` | ch03, ch13 |
| `InMemoryTransport` | in-memory transport，測試 client↔server 不開行程 | `StreamClientTransport` / `StreamServerTransport` | ch13 |
| `ChatWithTools` | 結合 `IChatClient`（Microsoft.Extensions.AI）以 MCP 工具做 function calling | `McpClientTool`（: `AIFunction`） / `IChatClient`（外部 NuGet） | ch16 |
| `TasksExtension` | SEP-2663 Tasks extension 的端對端範例，以 in-memory transport 示範背景 task 與輪詢 | `WithTasks` / `IMcpTaskStore` / `CallToolAsTaskAsync` / `GetTaskAsync` | ch17 |
| `WeatherAppServer` | MCP Apps extension 範例，提供互動式天氣 UI 與 structured content | `[McpAppUi]` / `WithMcpApps` / `McpServerResource` / `StructuredContent` | 第二輪規劃 |
| `ProtectedMcpServer` | 需 OAuth 2.0 驗證的 server | `McpAuthenticationExtensions` / `McpAuthenticationOptions`（`.AspNetCore.Authentication`） | ch18 |
| `ProtectedMcpClient` | 連線受保護 server 的 client（OAuth flow） | client OAuth / `ModelContextProtocol.Authentication` | ch18 |

## 與 v2.0.0 release notes 的關聯
- `TasksExtension` 取代 v1.4.1 的 `LongRunningTasks`，對應獨立的 `ModelContextProtocol.Extensions.Tasks` 套件與 SEP-2663。
- `WeatherAppServer` 對應新的 MCP Apps extension 與 `ModelContextProtocol.Extensions.Apps` 套件。
- `AspNetCoreMcpPerSessionTools` 在 v2 預設 stateless 的前提下，明確設定 `Stateless = false` 以保留 per-session 工具過濾。

## v2.1.0 更新

- `AspNetCoreMcpServer` 新增 Application Insights 匯出範例；設定 `APPLICATIONINSIGHTS_CONNECTION_STRING` 時使用 Azure Monitor，未設定時維持 OTLP exporter。
- `InMemoryTransport` 新增 README，說明以 `System.IO.Pipelines`、`StreamServerTransport` 與 `StreamClientTransport` 在同一行程建立 client/server 測試連線。
- conceptual docs 補充 binary embedded resources 的 client 相容性說明；SDK 傳送 URI、MIME type 與 base64 `blob`，不負責把 PDF 等格式轉成影像。

## v2.2.0 更新

- `AspNetCoreMcpServer`、`AspNetCoreMcpPerSessionTools`、`EverythingServer` 與 `ProtectedMcpServer` 改用 `HttpServerTransportOptions.SessionMode` 搭配 `HttpServerSessionMode`，取代只用 `Stateless` 布林值選擇模式的寫法。
- `AspNetCoreMcpPerSessionTools` 明確選用 `HttpServerSessionMode.Stateful`，保留 session-scoped 工具行為。
- v2.2.0 新增 `HttpServerSessionMode.StatefulForInitializeClients`，可在同一 endpoint 讓 initialize-handshake clients 使用 stateful session，同時以 stateless 模式服務 2026-07-28 clients。
