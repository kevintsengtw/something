---
validated: 2026-09-04
tool: codebase-memory-mcp 0.6.1
target_repo: csharp-sdk
target_tag: v2.2.0
indexed_commit: 6fa3825973949a9c4f0cd8af344e15a8db09dc35
project_name: Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk
index_nodes: 8746
index_edges: 29659
result: PASS (6/7)
platform: macOS
previous_validation: 2026-07-16 @ v1.4.1 — PASS (7/7)
---

# codebase-memory-mcp macOS 驗證報告（csharp-sdk @ v2.2.0）

> 依工作區根 `AGENTS.md` 與 `CODEX-HANDOFF-PLAN.md` 的 7 項探測規格執行。判定門檻：≥ 6/7 通過視為可用。
> **結果：6/7 通過** → codebase-memory-mcp 在本機對此 repo 的 C# 解析可用，事實層 / 敘述層二分架構成立。
> 唯一未通過的是 probe 5 的 `in_degree > 0` 子條件，**不影響 API 存在性與簽名的判定能力**；成因與因應見第 3 節。

## 0. 索引基本資訊

| 項目 | 值 |
|------|-----|
| project 名稱 | `Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk`（⚠️ 路徑自動產生，非 `csharp-sdk`） |
| 索引模式 | `full`（2026-08-15 對齊 v2.2.0 時完整重建） |
| 節點 / 邊 | 8746 / 29659 |
| 索引 commit | `6fa3825` (tag v2.2.0) |
| src `.cs` 檔數 | 372（全 repo 722） |
| 索引狀態 | `ready` |
| 工具版本 | 0.6.1（**與 2026-07-16 那次相同**，本次差異非工具升級所致） |

## 1. 七項探測結果

| # | 探測 | 目標 | 結果 | 證據 |
|---|------|------|------|------|
| 1 | 外部依賴使用端 | `IChatClient`（Microsoft.Extensions.AI） | ✅ PASS | `search_graph name_pattern="^IChatClient$"` 回 0（外部 NuGet 無本體節點，符合預期）；`search_code` 回 30 個結構化使用端 / 40 grep matches，分布 src 10、tests 14、docs 3、samples 2、.github 1 |
| 2 | 方法簽名 | `McpClient.CreateAsync` | ✅ PASS | 節點 in_degree=155（v1.4.1 為 99）；`get_code_snippet` 取得 `public static async Task<McpClient> CreateAsync(IClientTransport, McpClientOptions?, ILoggerFactory?, CancellationToken)`——與 v1.4.1 簽名相同 |
| 3 | 繼承鏈 | `McpClientTool : AIFunction` | ✅ PASS | `get_code_snippet` 回傳 `public sealed class McpClientTool : AIFunction`，位於 `src/ModelContextProtocol.Core/Client/McpClientTool.cs` |
| 4 | Attribute 型別 | `McpServerToolAttribute` | ✅ PASS | `search_graph label=Class` 回 9 筆，其中 `McpServerToolAttribute` 與 `McpServerToolTypeAttribute` 皆在 `src/ModelContextProtocol.Core/Server/`；未混入 Analyzer 內同名字串常數 |
| 5 | Extension 方法 | `AddMcpServer` / `MapMcp` / `WithToolsFromAssembly` | ⚠️ **FAIL（子條件）** | 三者皆存在於 src/ 且 file_path 正確，但 `in_degree > 0` 只成立兩項：`AddMcpServer`=171（v1.4.1 為 153）、`MapMcp`=32（v1.4.1 為 78）、**`WithToolsFromAssembly`=0**（v1.4.1 為 4） |
| 6 | callers 連結度 | `AddMcpServer` 的 `trace_path` | ✅ PASS | `trace_path(direction="inbound", depth=1, include_tests=true)` 回傳約 100 個 caller，涵蓋 `samples/QuickstartWeatherServer`、`samples/TestServerWithHosting`、`samples/FileBasedMcpServer`、`samples/WeatherAppServer` 與大量 tests |
| 7 | Namespace 一致性 | 抽樣 `ModelContextProtocol.*` | ✅ PASS | `search_code("namespace ModelContextProtocol")` 回 500 個結構化結果 / 500 matches（src 325、tests 173、samples 1、.github 1）；src 普查結果與套件歸屬規則一致（見第 2 節） |

## 2. 套件 ↔ namespace 對照（probe 7 普查，src/ 內 `namespace` 宣告計數）

| Namespace | 檔數 | 所屬 NuGet 套件（由 file_path 第一段判定） |
|-----------|------|------|
| `ModelContextProtocol.Protocol` | 124 | ModelContextProtocol.Core（+ `src/Common/` 共用內部碼） |
| `ModelContextProtocol.Server` | 62 | ModelContextProtocol.Core + ModelContextProtocol |
| `ModelContextProtocol` | 30 | ModelContextProtocol |
| `ModelContextProtocol.Client` | 27 | ModelContextProtocol.Core |
| `ModelContextProtocol.Authentication` | 26 | **ModelContextProtocol.Core**（`src/ModelContextProtocol.Core/Authentication/`） |
| `ModelContextProtocol.Extensions.Tasks` | 21 | ModelContextProtocol.Extensions.Tasks（**v2.0.0 新增**） |
| `ModelContextProtocol.AspNetCore` | 15 | ModelContextProtocol.AspNetCore |
| `Microsoft.Extensions.DependencyInjection` | 12 | ModelContextProtocol + ModelContextProtocol.AspNetCore（DI 擴充方法刻意放此 ns） |
| `ModelContextProtocol.Extensions.Apps` | 10 | ModelContextProtocol.Extensions.Apps（**v2.0.0 新增**） |
| `ModelContextProtocol.AspNetCore.Authentication` | 5 | ModelContextProtocol.AspNetCore |
| `ModelContextProtocol.Analyzers` | 5 | ModelContextProtocol.Analyzers |
| `Microsoft.AspNetCore.Builder` | 1 | ModelContextProtocol.AspNetCore（`MapMcp` 放此 ns） |

> 對照 v1.4.1：新增 `.Extensions.Tasks` 與 `.Extensions.Apps` 兩個 namespace／套件；`Microsoft.Extensions.DependencyInjection` 由單一套件擴為橫跨 `ModelContextProtocol` 與 `.AspNetCore`。「**沒有獨立 `ModelContextProtocol.Authentication` NuGet 套件**」的結論在 v2.2.0 仍成立。

## 3. Probe 5 未通過的成因與因應（**重要**）

### 現象

`WithToolsFromAssembly` 的 in_degree 由 4（v1.4.1）掉到 0（v2.2.0），`MapMcp` 由 78 掉到 32。

### 排除的成因

| 假設 | 查證 | 結論 |
|------|------|------|
| API 被移除或改名 | `search_graph` 找到節點，`src/ModelContextProtocol/McpServerBuilderExtensions.cs:189` 定義完整、`out_degree=2` | ❌ 排除 |
| 上游呼叫點消失 | `git show v1.4.1:...ToolsTests.cs` 與現況逐行比對，**4 個呼叫點形狀完全相同**（含兩處 `sc.AddMcpServer().WithToolsFromAssembly();`）；samples 兩版皆未使用 | ❌ 排除 |
| 工具版本升級 | 兩次驗證皆為 codebase-memory-mcp **0.6.1** | ❌ 排除 |
| `MapMcp` 多載數變動 | `public static ... MapMcp` 定義數：v1.4.1 = 1、v2.2.0 = 1 | ❌ 排除 |

### 實際成因

**鏈式 fluent 擴充方法的 CALLS 邊只接到鏈首**。`trace_path("AddMcpServer", direction="inbound")` 的 caller 清單中明確包含 `WithToolsFromAssembly_Parameters_Satisfiable_From_DI` 與 `Register_Tools_From_Current_Assembly`——這兩個測試呼叫的是 `sc.AddMcpServer().WithToolsFromAssembly()`，邊被歸給 `AddMcpServer`，鏈上後續方法拿不到 in_degree。

兩次驗證的差異項只剩**索引建立模式**：v1.4.1 是 `incremental`（由既有完整索引重建 3 個變更檔），v2.2.0 是 `full`（完整重建）。合理推論是兩種建索引路徑對鏈式呼叫的邊解析不一致；此點**未經隔離實驗證實**，僅記錄為待查。

### 因應（**取代舊慣例第 6 條**）

- ❌ **不可**用 `in_degree = 0` 判定 API 已廢棄或無人使用——鏈式擴充方法（`builder.AddMcpServer().WithX()`、`.WithTools()...`）會系統性地拿到 0。
- ✅ 判定 API 存在性用 `search_graph`（節點 + file_path）；判定實際使用端用 `search_code` 或 grep。
- ✅ `in_degree` 只作為**非鏈式**方法的連結度參考，且高值可信、低值不可信。
- ✅ `drift-check` 若因 in_degree=0 而想標記 🔴 Breaking，**必須**先以 `search_code` 交叉驗證，否則會產生假的 breaking change。

## 4. 工具使用慣例（本機實證，累積）

1. **project 參數必用動態解析名稱**：本次為 `Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk`，非字面 `csharp-sdk`。任何工作流若硬編碼短名稱，在本機都無效。
2. **外部依賴不索引**：`Microsoft.Extensions.AI.*`（`IChatClient`、`AIFunction`、`ChatOptions`）查無本體節點屬正常。
3. **`get_code_snippet` 用完整 qualified_name**；**`trace_path` 用「短名稱」**（傳完整 qualified_name 反而報 function not found）。兩者相反，勿混用。
4. **套件歸屬以 file_path 第一段為準**（`src/<Package>/...`），不可由 C# namespace 推測——SDK 的 DI/builder 擴充方法刻意放在 `Microsoft.*` namespace。
5. **`search_graph` 的 `name_pattern` 搭配 `file_pattern` 時可能回 0**（本次 `name_pattern="CreateAsync"` + `file_pattern="Client"` 即回 0）；建議兩者擇一，或用寬鬆 pattern 再以 file_path 過濾。
6. **`in_degree` 對鏈式 fluent 擴充方法不可靠**（見第 3 節，本次驗證修正的舊結論）。存在性一律以 `search_graph` + `search_code` 為準。
7. **sandbox 與使用者 cache 視圖可能不同**：需要讀寫使用者層 cache 的 CLI 查驗應在相同權限視圖執行，否則可能看到舊的 0-node metadata。

## 5. 歷次驗證

| 日期 | Tag | 工具版本 | 索引 | 結果 |
|------|-----|---------|------|------|
| 2026-06-30 | v1.4.0 (`06e3604`) | — | 7084 / 22986 | PASS (7/7) |
| 2026-07-16 | v1.4.1 (`2b7fd35`) | 0.6.1 | 7098 / 23419（incremental） | PASS (7/7) |
| 2026-09-04 | v2.2.0 (`6fa3825`) | 0.6.1 | 8746 / 29659（full） | **PASS (6/7)** — probe 5 的 in_degree 子條件未過，見第 3 節 |
