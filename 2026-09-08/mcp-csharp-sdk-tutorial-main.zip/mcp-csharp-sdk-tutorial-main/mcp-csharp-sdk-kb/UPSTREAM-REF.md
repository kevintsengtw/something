# 上游原始碼對齊記錄

每台機器需獨立 clone `csharp-sdk`（不從其他機器複製索引），對齊到此處記錄的 commit/tag，再透過 Codex MCP 或 `codebase-memory-mcp cli index_repository` 重建索引。`mcp-csharp-sdk-kb/` 與 `mcp-csharp-sdk-guide/` 可隨 root repository 取得。

---

## 目前對齊版本

| 項目 | 值 |
|------|-----|
| **Tag** | `v2.2.0` |
| **Commit Hash** | `6fa3825973949a9c4f0cd8af344e15a8db09dc35` |
| **知識庫基準版本** | source/raw、facts/wiki 與正式 knowledge graph 均已對齊 v2.2.0 |
| **最後更新** | 2026-08-15 |
| **索引規模** | 8746 nodes / 29659 edges（完整重建後為 `ready`） |
| **codebase-memory-mcp project 名稱** | `Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk`（⚠️ 路徑自動產生，**非** `csharp-sdk`；所有工具呼叫須用此全名） |
| **MCP 規格** | 2026-07-28 |

> ⚠️ **project 名稱規則**：codebase-memory-mcp 由絕對路徑自動命名。所有可移植工作流都使用 `<csharp-sdk-project>` placeholder，並在 session 首次查詢前以 `list_projects` 找出 root path 以 `/csharp-sdk` 結尾的 project；不可硬編碼本機名稱。
>
> ⚠️ **套件結構修正**：v2.0.0 的 `src/` 下有 5 個 NuGet 專案 + Analyzers：`ModelContextProtocol.Core`、`ModelContextProtocol`、`ModelContextProtocol.AspNetCore`、`ModelContextProtocol.Extensions.Apps`、`ModelContextProtocol.Extensions.Tasks`、`ModelContextProtocol.Analyzers`（+ `Common` 共用內部碼）。**沒有獨立的 `ModelContextProtocol.Authentication` 專案**。套件歸屬一律以圖譜 `file_path` 第一段（`src/<Package>/...`）為準。

> 注意：GitHub releases 頁面與 NuGet 偶有短暫不同步。實際最新版一律以 `$sync-upstream` 的查證結果為準（GitHub releases API + NuGet flat container 雙向確認）。

---

## 切換機器 / 首次設定的對齊指令

```bash
# 在 mcp-csharp-sdk-tutorial/ 工作區根
git clone https://github.com/modelcontextprotocol/csharp-sdk.git
cd csharp-sdk
git fetch --tags
git checkout v2.2.0
cd ..

# 使用 CLI 或已設定的 Codex MCP：
codebase-memory-mcp cli index_repository '{"repo_path":"<絕對路徑>/csharp-sdk"}'
codebase-memory-mcp cli list_projects '{}'
# 取 root path 以 /csharp-sdk 結尾的 project 名稱；不要硬編碼本機值
```

---

## codebase-memory-mcp 索引同步策略

| 場景 | 動作 |
|------|------|
| 同機 `git pull` 後 | 無需動作，file watcher 自動增量更新 |
| 跨機初次設定 | 對該機器執行 `index_repository`（cache 位於使用者層，不跨機共享） |
| 工具版本升級後 | 視情況重跑 `index_repository` |
| 索引疑似失準 | 重跑 `index_repository` |

**為何索引不 commit**：體積大、路徑為機器絕對路徑不可移植、可隨時從 source 重建。

---

## 歷史記錄

| 日期 | Tag/Commit | 說明 |
|------|-----------|------|
| 2026-06-30 | `v1.4.0` | 初始建立此記錄與專案骨架。尚未 clone/index，commit hash 與索引規模待補。 |
| 2026-06-30 | `06e3604` | 首次 clone（detached HEAD @ v1.4.0）+ `index_repository` 完成：7084 nodes / 22986 edges。確認 project 名為路徑全名（非 `csharp-sdk`）；確認無獨立 Authentication 套件。 |
| 2026-07-09 | `2b7fd35` | `/sync-upstream`：checkout v1.4.1（純 bug-fix，修 `StreamableHttpServerTransport` 記憶體洩漏，**無 API 變更**）。抓取 v1.4.1 release notes；samples/docs 零變動。索引 status=ready、規模不變（7084/22986）。facts/wiki 基準維持 v1.4.0（API 等價，不需重抽）。 |
| 2026-07-13 | `2b7fd35` / 索引 `06e3604` | **閉環驗證（ch05 事實補入後）**：確認「worktree=v1.4.1、索引/基準=v1.4.0」為刻意狀態、非未受控 drift。`git diff 06e3604..2b7fd35 --stat` 僅 4 檔（`Directory.Build.props`、`StreamableHttpServerTransport.cs`、`PACKAGE.md` + 其測試）。逐檔確認本輪 ch05 驗證碰過的 9 個 src 檔（`McpException`/`McpProtocolException`/`McpErrorCode`/`CallToolResult`/`RequestContext`/`Tool`/`McpServerToolAttribute`/`ContentBlock`/`AIFunctionMcpServerTool`）在兩 commit 間 **byte-identical** → 以 v1.4.1 worktree grep 出的事實與 v1.4.0 圖譜索引完全一致。index_status=ready、7084/22986 不變。無需重建索引、無需 checkout。 |
| 2026-07-16 | `2b7fd35` | Codex 接手時以 codebase-memory-mcp 0.6.1 重建索引；status=`ready`、7098 nodes / 23419 edges，並重跑七項 C# 探測 7/7 通過。詳細證據見 `raw/facts/codebase-memory-mcp-validation.md`。 |
| 2026-08-02 | `v2.0.0` / `15f8b2d`（線上） | `/sync-upstream` 已從固定 `v2.0.0` tag 同步 release notes、conceptual docs 與 samples 摘要；tarball SHA-256 `57bb8bceaf0a0b7fbe25d10fde4c63e029a91c3a28b3ef713fe5e1634f537ddf`。本機唯讀 clone 與 codebase-memory-mcp 索引仍為 v1.4.1，故 API surface、存在性驗證與 facts 抽取尚未執行。 |
| 2026-08-03 | `v2.0.0` / `15f8b2d` | 經使用者明確授權，將 workspace 的 upstream clone 以 detached HEAD 對齊 v2.0.0，並完整重建 codebase-memory 索引；status=`ready`、8590 nodes / 29347 edges。下一步為 `$extract-facts 2.0.0`。 |
| 2026-08-10 | `v2.1.0` / `3be47ee` | 經使用者於工作流外對齊唯讀 upstream clone；`/sync-upstream` 同步 v2.1.0 release notes、兩篇 conceptual docs 與 samples 摘要，並增量重建 codebase-memory 索引；status=`ready`、8636 nodes / 29684 edges。 |
| 2026-08-15 | `v2.2.0` / `6fa3825` | 經使用者明確授權，將 workspace 的 upstream clone 以 detached HEAD 對齊 v2.2.0；`/sync-upstream` 同步 v2.2.0 release notes、13 篇 conceptual docs 與 samples 摘要，並完整重建 codebase-memory 索引；status=`ready`、8746 nodes / 29659 edges。 |
| 2026-09-04 | `v2.2.0` / `6fa3825` | 上游查無新版本（v2.2.0 仍為 GitHub/NuGet latest；`origin/main` 有 4 筆未 tag commit）。補正工作區層基準宣告，並重跑七項 C# 探測：**6/7 通過**（索引未變動、工具仍為 0.6.1）。probe 5 的 `in_degree>0` 子條件因鏈式 fluent 擴充方法的邊解析限制而未過，已修正「in_degree 為可靠代理」的舊慣例。詳見 `raw/facts/codebase-memory-mcp-validation.md`。 |
