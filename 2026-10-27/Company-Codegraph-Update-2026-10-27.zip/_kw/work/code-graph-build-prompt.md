# 公司原始碼建圖入口（2026-10-27）

已改為使用 Agent Skill。完成本包安裝後，在 `D:\Projects\FX` 用原本方式開啟新的 Codex CLI session，直接輸入：

```text
$kw-build-graphs
```

也可以同時提供 repo：

```text
$kw-build-graphs 請為我指定的 repo 建立並驗證 codebase 圖譜。
```

Repo 路徑未提供時由 Skill 詢問，不要把「我指定的 repo」當實際路徑。已提供則不重問。其他必要位置若尚無可讀設定，才確認缺口；本公司的既有位置已列在同目錄的 `code-graph-common-procedure.md`。

不需要 INVOKE.txt、重貼長版提示詞、逐階段輸入繼續，或每次補上不呼叫 Codebase-Memory MCP。該限制已在 Skill 與共用流程中。

共用流程：`D:\Projects\FX\_kw\work\code-graph-common-procedure.md`。
Skill：`D:\Projects\FX\.agents\skills\kw-build-graphs\SKILL.md`。

本檔是已安裝 Skill 的簡短啟動說明，不取代 Skill 與固定命令範例。CLI 實際失敗、核准遭拒或來源變動時依共用流程停止並保留證據，不自動重試或調整 timeout。
