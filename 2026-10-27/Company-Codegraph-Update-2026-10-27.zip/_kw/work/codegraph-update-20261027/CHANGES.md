# 更新內容與照片對照

本包是完整的 Skill 與共用文件更新包，取代先前尚未傳到公司的 `Codebase-Agent-Skill-Codex-CWD-2026-10-22.zip`；不要求先套用舊包。

| 項目 | 本包處理 |
| --- | --- |
| ClosingRate 已成功建圖／驗證 | 沿用歷史結果，不重新建圖，不帶入或覆蓋其產物 |
| JSON 讀回 | 保留 ReadAllText 與 ConvertFrom-Json，避免 Join-Path 接到 -Raw |
| 命令檢查 | 保留同一份 BuildScriptText 的 Parser.ParseInput，不使用易遺漏／未展開的 parser 輸入檔 |
| probeCode／runTag | 區分合法 `${probeCode}:` 與檔名殘留 `${runTag}`，不改回先前寫法 |
| 準備錯誤與 CLI 失敗 | 提交前可修正並重查，實際 CLI 失敗後停止，不自動重試 |
| manifest SHA 抄寫更正 | 只涉及歷史檢查紀錄；固定範例讀真正 manifest SHA，比對 build report，再提交 verify，不修改 artifact |
| Skill 化 | 完整 Skill 加共用文件放在 `.agents\skills\kw-build-graphs`，支援從 D:\Projects\FX 啟動 |
| 公司既有文件 | 一併提供更新後 `code-graph-common-procedure.md`、`code-graph-build-prompt.md`，安裝前保留公司原件 |

Skill 本體、其七份共用文件與 PHASE1-HANDOFF.md 沿用已驗證來源 bytes；本次沒有為了換 ZIP 名稱重寫核心流程。相較先前未傳入的 ZIP，新增公司兩份共用文件、公司導入說明、明確的更新清單與這一包實際內容的核對資料。

不呼叫 Codebase-Memory MCP、不需要 INVOKE.txt、不要求每個 repo 重跑整套測試或獨立 CGR 診斷。沿用公司已核准工具與 D 槽隔離，不調 timeout，不修改工具或已驗證圖譜。

先前 probe_timeout 根因仍未解；重複 probe、argv／PID／終止狀態等診斷缺口未在此包修正。最新 Skill 的公司探索及執行，需在人工導入後另記真實結果。
