#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { runProcess, processDetails, errorDetails } from "./lib/process-runner.mjs";
import { fileURLToPath } from "node:url";
import { getSystemErrorMap } from "node:util";

function remediationFor(kind, details) {
  switch (kind) {
    case "project-outside-workspace":
      return ["確認 workspace root、target source 與 test project 路徑；兩個專案路徑都必須位於目前工作區。"];
    case "target-source-unavailable":
      return ["確認 target source 是目前工作區內存在且可讀的檔案。"];
    case "restore-project-unavailable":
      return ["確認既有 test csproj，或 target 所在路徑最近的來源專案；同一目錄有多個 csproj 時，請明確提供既有 test project。"];
    case "nuget-cache-unavailable":
      return ["檢查已明確設定的 NUGET_PACKAGES：必須是存在且目前執行環境可讀的絕對目錄。",
        "若不需要指定快取，可移除自己設定的 override，沿用 NuGet.Config 與 NuGet 預設快取；一般啟動不需要此變數。"];
    case "dotnet-unavailable":
      if (details.process?.error?.stage) return ["依 process 與 capture 診斷檢查工作區暫存準備、輸出大小、讀取或清理失敗；這不是缺少 SDK 的判定。"];
      if (["EPERM", "EACCES"].includes(details.process?.error?.code)) {
        return ["子程序執行遭拒；保留原始 code、syscall 與目前執行環境證據，檢查實際存取限制。單憑此錯誤不能判定管線、ACL 或安全軟體是原因。"];
      }
      return ["依原始執行錯誤檢查 .NET SDK、PATH 或還原逾時問題；預檢未完成不代表後續建置已失敗。"];
    case "nuget-restore-unavailable": {
      const output = details.output ?? "";
      const advice = [];
      if (/\bNU(?:1301|1801)\b/i.test(output)) {
        advice.push("套件來源存取失敗：依原始診斷檢查 NuGet.Config 的來源，以及連線、代理伺服器、憑證或來源驗證；錯誤代碼本身不能判定是哪一項原因。");
      }
      if (/\bNU(?:1101|1102)\b/i.test(output)) {
        advice.push("找不到所需套件或版本：核對套件識別碼、版本、NuGet.Config 的套件來源與 packageSourceMapping，以及既有快取是否包含所需套件。");
      }
      if (/EACCES|EPERM|access (?:is )?denied|unauthorizedaccess|permission denied|存取.*拒絕|拒絕存取/i.test(output)) {
        advice.push("診斷包含存取拒絕：核對錯誤指出的來源、快取或專案輸出路徑及目前執行環境的存取權限。");
      }
      if (advice.length === 0) {
        advice.push("先依原始 dotnet restore 診斷檢查專案、SDK、套件來源或快取；目前資訊不足以判定原因，不應先加入 NuGet override。");
      } else if (/\bNU(?:1301|1801|1101|1102)\b/i.test(output)) {
        advice.push("選用處理：只有確認所需套件已在另一個可讀快取、且目前環境未使用該快取時，才考慮用單次 CLI -c shell_environment_policy.set.NUGET_PACKAGES 指定其絕對路徑。");
      }
      return [...advice, "預檢不會修改使用者層設定、開啟網路或放寬權限；依組織允許的方式處理後，再從預檢重新執行。"];
    }
    default:
      return ["依原始錯誤核對預檢參數、工作區與檔案存取狀態，再重新執行。"];
  }
}

function diagnosticSummary(status, kind, message, details, rawOutput) {
  const lines = [
    `NuGet 前置還原：${status} / ${kind}`,
    `還原專案：${details.project ?? "未取得"}`,
    `dotnet restore 退出碼：${Number.isInteger(details.exitCode) ? details.exitCode : "未取得"}`,
    `原因：${message}`,
  ];
  if (status === "skipped") lines.push("還原未驗證；略過不代表還原成功。");
  const error = details.process?.error ?? details.error;
  if (error) {
    const text = typeof error === "string" ? [details.code, error].filter(Boolean).join(": ")
      : [error.code, error.stage, error.syscall, error.message].filter(Boolean).join(": ");
    lines.push(`原始執行錯誤：${text.slice(0, 800)}${text.length > 800 ? "（已裁切）" : ""}`);
  }
  if (details.process?.signal) lines.push(`程序 signal：${details.process.signal}`);
  const output = (rawOutput ?? details.output ?? "").trim();
  if (!output) {
    lines.push("原始輸出：未取得可用文字。");
  } else {
    // Select from the captured output before the legacy 4,000-character tail is applied.
    const outputLines = output.split(/\r?\n/u);
    const errorPattern = /\berror\b|\b(?:EACCES|EPERM)\b|access (?:is )?denied|permission denied|unauthorizedaccess|錯誤|失敗|拒絕/iu;
    const codePattern = /\b(?:NU\d{4}|NETSDK\d{4}|MSB\d{4})\b/iu;
    const errors = outputLines.filter(line => errorPattern.test(line));
    const pattern = errors.length ? errorPattern : codePattern;
    const keyLines = errors.length ? errors : outputLines.filter(line => codePattern.test(line));
    const selected = keyLines.length ? keyLines.slice(0, 6).map(line => {
      const start = Math.max(0, line.search(pattern) - 160);
      return line.slice(start, start + 600);
    }).join("\n") : output;
    const excerpt = selected.slice(0, 1600);
    const truncated = excerpt !== output;
    lines.push(`原始輸出節錄${truncated ? "（已節錄／裁切）" : ""}：\n${excerpt}`);
  }
  return lines.join("\n");
}

function blocked(kind, message, details = {}, rawOutput) {
  return { status: "blocked", kind, message, remediation: remediationFor(kind, details), ...details,
    diagnosticSummary: diagnosticSummary("blocked", kind, message, details, rawOutput) };
}

function skipped(kind, message, details = {}, rawOutput) {
  return { status: "skipped", kind, message, restoreVerified: false,
    remediation: [...remediationFor(kind, details),
      "記錄此次預檢未完成並繼續啟動 driver；後續實際還原、建置、測試與完整性檢查仍依原規則判定。不要提高權限或自動重跑預檢。"],
    ...details, diagnosticSummary: diagnosticSummary("skipped", kind, message, details, rawOutput) };
}

const permissionDenied = error => ["EPERM", "EACCES"].includes(error?.code);
const systemErrorCodes = new Set([...getSystemErrorMap().values()].map(([code]) => code));
const systemError = error => systemErrorCodes.has(error?.code);

function statIfPresent(file) {
  try { return fs.statSync(file); }
  catch (error) {
    if (["ENOENT", "ENOTDIR"].includes(error?.code)) return null;
    throw error;
  }
}

function inside(root, candidate) {
  const relative = path.relative(root, candidate);
  return relative !== "" && relative !== ".." && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative);
}

function sourceProject(root, targetSource) {
  let directory = path.dirname(targetSource);
  while (directory === root || inside(root, directory)) {
    const projects = fs.readdirSync(directory).filter(name => name.endsWith(".csproj"));
    if (projects.length === 1) return path.join(directory, projects[0]);
    if (projects.length > 1) return null;
    directory = path.dirname(directory);
  }
  return null;
}

function inspectNugetSandbox({ workspaceRoot, targetSource, testProject },
  { env = process.env, restore = runProcess } = {}) {
  const root = fs.realpathSync(path.resolve(workspaceRoot));
  const source = path.resolve(targetSource);
  const test = path.resolve(testProject);
  if (!inside(root, source) || !inside(root, test)) {
    return blocked("project-outside-workspace", "Target 與測試專案必須位於目前工作區。", { root, source, test });
  }
  if (!statIfPresent(source)?.isFile() || !inside(root, fs.realpathSync(source))) {
    return blocked("target-source-unavailable", "Target source 不存在或不在工作區內。", { source });
  }
  let project = test;
  let projectKind = "test";
  if (!statIfPresent(test)) {
    project = sourceProject(root, source);
    projectKind = "source";
  }
  if (!project || !statIfPresent(project)?.isFile() ||
      !inside(root, fs.realpathSync(project))) {
    return blocked("restore-project-unavailable", "無法找到工作區內唯一的還原專案。", { source, test });
  }

  const packages = env.NUGET_PACKAGES || null;
  if (packages) {
    try {
      if (!path.isAbsolute(packages) || !fs.statSync(packages).isDirectory()) throw Error("快取目錄無效");
      fs.accessSync(packages, fs.constants.R_OK);
    } catch (error) {
      if (permissionDenied(error)) {
        return skipped("nuget-cache-unavailable", "目前環境無法檢查指定快取；略過前置還原檢查。", {
          packages, error: error.message, code: error.code,
        });
      }
      return blocked("nuget-cache-unavailable", "指定的 NUGET_PACKAGES 不是存在且可讀的絕對目錄。", {
        packages, error: error.message,
      });
    }
  }

  const args = ["restore", project, ...(packages ? ["--packages", packages] : []),
    "--ignore-failed-sources", "--verbosity", "minimal"];
  let result;
  try {
    result = restore("dotnet", args, {
      cwd: path.dirname(project), captureRoot: root, env, encoding: "utf8", windowsHide: true,
      maxBuffer: 2 * 1024 * 1024, timeout: 120000,
    });
  } catch (error) {
    // Only system invocation errors are optional; do not hide programming errors.
    if (!systemError(error)) throw error;
    result = { error, status: null, signal: null };
  }
  // Windows capture returns invocation errors instead of throwing them. Apply the
  // same classification to both paths; a missing status alone is not evidence of an environment failure.
  if (result?.error && !systemError(result.error)) throw result.error;
  const signalled = typeof result?.signal === "string" && result.signal.length > 0;
  if (!result || typeof result !== "object" || Array.isArray(result) ||
      (result.signal != null && !signalled) ||
      (!result.error && !signalled && (!Number.isInteger(result.status) || result.status < 0))) {
    return blocked("preflight-result-invalid", "預檢執行層回傳無法辨識的結果；停止並保留原始診斷。", {
      project, projectKind, packages, restoreVerified: false, rawResult: result ?? null,
    });
  }
  const output = `${result.stdout ?? ""}${result.stderr ?? ""}`;
  if (result.error || signalled) {
    return skipped("dotnet-unavailable", "無法取得完整的 NuGet 預檢結果；略過預檢並繼續 workflow。", {
      project, projectKind, packages,
      error: result.error?.message ?? (result.signal ? `預檢被 ${result.signal} 中止` : "預檢未回傳有效退出碼"),
      exitCode: result.status ?? null,
      process: processDetails(result),
      output: output.slice(-4000),
    }, output);
  }
  if (result.status !== 0) {
    return blocked("nuget-restore-unavailable", "指定專案在目前快取、套件來源與沙箱權限下無法還原。", {
      project, projectKind, packages, exitCode: result.status,
      process: processDetails(result),
      output: output.slice(-4000),
    }, output);
  }
  return { status: "ready", project, projectKind, packages, restoreExitCode: 0 };
}

export function checkNugetSandbox(options, dependencies = {}) {
  try {
    return inspectNugetSandbox(options, dependencies);
  } catch (error) {
    if (!permissionDenied(error)) throw error;
    return skipped("preflight-access-denied", "目前環境無法讀取預檢所需資訊；略過前置還原檢查。", {
      error: error.message, code: error.code,
    });
  }
}

function parseArgs(argv) {
  const options = {};
  for (let index = 0; index < argv.length; index += 2) {
    const key = argv[index];
    if (!["--workspace-root", "--target-source", "--test-project"].includes(key) || !argv[index + 1]) {
      throw Error(`未知或缺少參數: ${key}`);
    }
    options[key.slice(2).replace(/-([a-z])/gu, (_, letter) => letter.toUpperCase())] = argv[index + 1];
  }
  for (const key of ["workspaceRoot", "targetSource", "testProject"]) {
    if (!options[key]) throw Error(`缺少 ${key}`);
  }
  return options;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const result = checkNugetSandbox(parseArgs(process.argv.slice(2)));
    const canContinue = ["ready", "skipped"].includes(result.status);
    (canContinue ? process.stdout : process.stderr).write(`${JSON.stringify(result)}\n`);
    if (!canContinue) process.exitCode = 1;
  } catch (error) {
    process.stderr.write(`${JSON.stringify(blocked("preflight-error", error.message, { error: errorDetails(error) }))}\n`);
    process.exitCode = 1;
  }
}
