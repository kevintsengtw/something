# 更新內容與照片對照

本包是 r2 完整修正版，取代 `Company-Codegraph-Update-2026-10-27.zip`；不要求先套用舊包。

| 項目 | 本包處理 |
| --- | --- |
| 本次未指定 repo | 先問本次完整路徑並等待，禁止從歷史、啟動目錄或舊報告選案 |
| 找到舊 pass 結果 | 不能替代新的建圖要求；只有明確要求沿用／只驗證才進入該模式 |
| ClosingRate 已成功建圖／驗證 | 沿用歷史結果，不重新建圖，不帶入或覆蓋其產物 |
| JSON 讀回 | 保留 ReadAllText 與 ConvertFrom-Json，避免 Join-Path 接到 -Raw |
| 命令檢查 | 保留同一份 BuildScriptText 的 Parser.ParseInput，不使用易遺漏／未展開的 parser 輸入檔 |
| probeCode／runTag | 區分合法 `${probeCode}:` 與檔名殘留 `${runTag}`，不改回先前寫法 |
| 準備錯誤與 CLI 失敗 | 提交前可修正並重查，實際 CLI 失敗後停止，不自動重試 |
| manifest SHA 抄寫更正 | 只涉及歷史檢查紀錄；固定範例讀真正 manifest SHA，比對 build report，再提交 verify，不修改 artifact |
| Skill 化 | 完整 Skill 加共用文件放在 `.agents\skills\kw-build-graphs`，支援從 D:\Projects\FX 啟動 |
| 公司既有文件 | 一併提供更新後 `code-graph-common-procedure.md`、`code-graph-build-prompt.md`，安裝前保留公司原件 |

本次僅修改 Skill 說明／入口與共用流程的選案分支，並以既有 maintainer scripts 同步入口與 development release。先前的 JSON／PowerShell／temp／失敗處理／manifest 驗證範例與 8 個行為測試保持原樣。原保護基準清單沒有覆寫；5 個刻意變動的路徑與修改前副本另有紀錄。

不呼叫 Codebase-Memory MCP、不需要 INVOKE.txt、不要求每個 repo 重跑整套測試或獨立 CGR 診斷。沿用公司已核准工具與 D 槽隔離，不調 timeout，不修改工具或已驗證圖譜。

先前 probe_timeout 根因仍未解；重複 probe、argv／PID／終止狀態等診斷缺口未在此包修正。最新 Skill 的公司探索及執行，需在人工導入後另記真實結果。
