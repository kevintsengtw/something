# Git Worktree 基礎知識

## 1. 這篇文件的目的

這篇文件補充傳統 Git worktree 的基礎知識。

如果你已經先閱讀：

```text
01-codex-git-worktree-workflow.md
```

那麼你已經知道 Codex 為什麼需要 worktree。

這篇則補上：

```text
- git worktree 是什麼
- 它和 branch 的關係
- 它和 git clone 的差異
- 常用指令
- 目錄規劃
- 常見限制
- 清理方式
- 實務建議
```

---

## 2. 傳統 Git branch 工作方式的問題

多數開發者平常會這樣使用 Git：

```bash
git switch main
git switch feature/payment-refactor
git switch hotfix/login-error
```

這代表：

```text
你有很多 branch
但通常只有一個 working directory
```

也就是同一個專案目錄在不同 branch 之間切換。

例如：

```text
C:\github\payment-service
```

這個目錄同一時間只能呈現一個 branch 的內容。

當你開發到一半，突然要切去 hotfix，常見做法是：

```bash
git stash
git switch hotfix/login-error
# 修 hotfix
git switch feature/payment-refactor
git stash pop
```

這會帶來幾個問題：

```text
- stash 多了容易混亂
- 切換 branch 會打斷工作節奏
- 未完成修改容易影響測試
- 很難同時開兩個版本的 IDE
- 不適合多個 AI Agent 同時工作
```

`git worktree` 就是用來改善這個問題。

---

## 3. Git worktree 是什麼？

簡單說：

> `git worktree` 讓同一個 Git repository 可以擁有多個 working directory。

範例：

```text
payment-service/
  主工作目錄，checkout feature/payment-refactor

payment-service/.worktrees/hotfix-login-error/
  額外 worktree，checkout hotfix/login-error

payment-service/.worktrees/codex-add-tests/
  額外 worktree，checkout codex/add-tests
```

每個 worktree 都是一個實際的工作目錄，可以開 IDE、改檔案、跑測試、commit。

---

## 4. Branch 與 Worktree 的關係

要分清楚兩件事：

```text
branch：
  一條版本線

worktree：
  一個工作目錄
```

例如：

```text
branch:
  feature/payment-refactor
  codex/currency-service-tests
  hotfix/login-error

worktree:
  C:\github\payment-service
  C:\github\payment-service\.worktrees\currency-service-tests
  C:\github\payment-service\.worktrees\hotfix-login-error
```

一個 worktree 通常 checkout 一個 branch。

---

## 5. Worktree 與 Clone 的差異

有些人會用多份 clone 來達到類似效果：

```text
C:\github\payment-service
C:\github\payment-service-copy
C:\github\payment-service-hotfix
```

這樣可以運作，但缺點是：

```text
- 每份 clone 都有自己的 .git
- 佔用更多空間
- remote、hook、config 管理分散
- fetch / pull 狀態可能不同步
- 容易忘記哪份才是主要目錄
```

worktree 則是：

```text
- 共用同一個 repository 的 Git object database
- 每個 worktree 有自己的 working directory
- 比多份 clone 更適合同一個 repo 的多任務開發
```

---

## 6. 建議目錄結構

建議把 worktree 放在 repo 底下的 `.worktrees`：

```text
payment-service/
  src/
  tests/
  .git/
  .worktrees/
    codex-add-tests/
    codex-refactor-service/
    hotfix-login-error/
```

並加入 `.gitignore`：

```gitignore
.worktrees/
```

好處：

```text
- 容易找到
- 不會散落在檔案系統各處
- 不會誤加入版控
- 適合 Codex / Agent 任務命名
```

---

## 7. 常用指令

### 7.1 查看 worktree

```bash
git worktree list
```

範例輸出：

```text
C:/github/payment-service                          abc1234 [feature/payment-refactor]
C:/github/payment-service/.worktrees/add-tests     def5678 [codex/add-tests]
C:/github/payment-service/.worktrees/hotfix-login  987abcd [hotfix/login-error]
```

---

### 7.2 建立 worktree 並建立新 branch

```bash
git worktree add <path> -b <new-branch> <base-branch>
```

範例：

```bash
git worktree add .worktrees/add-tests -b codex/add-tests main
```

意思是：

```text
從 main 建立 codex/add-tests branch
並把它 checkout 到 .worktrees/add-tests
```

---

### 7.3 使用既有 branch 建立 worktree

```bash
git worktree add <path> <existing-branch>
```

範例：

```bash
git worktree add .worktrees/hotfix-login-error hotfix/login-error
```

---

### 7.4 移除 worktree

```bash
git worktree remove <path>
```

範例：

```bash
git worktree remove .worktrees/add-tests
```

---

### 7.5 強制移除 worktree

如果 worktree 有未清理狀態，Git 可能拒絕移除。

可以使用：

```bash
git worktree remove --force <path>
```

但不建議一開始就使用 `--force`。

使用前應先確認：

```bash
cd <path>
git status
```

---

### 7.6 清理 stale metadata

如果你手動刪除了 worktree 資料夾，Git 可能仍保留 metadata。

可以執行：

```bash
git worktree prune
```

---

### 7.7 鎖定 worktree

如果某個 worktree 暫時不希望被 prune：

```bash
git worktree lock <path>
```

解除鎖定：

```bash
git worktree unlock <path>
```

---

## 8. 完整範例：建立 hotfix worktree

假設你正在開發：

```text
feature/payment-refactor
```

突然需要修 hotfix：

```text
hotfix/login-error
```

### Step 1：確認狀態

```bash
git status
git branch --show-current
```

### Step 2：建立 hotfix worktree

```bash
git worktree add .worktrees/hotfix-login-error -b hotfix/login-error main
```

### Step 3：進入 hotfix worktree

```bash
cd .worktrees/hotfix-login-error
```

### Step 4：修正問題並提交

```bash
git status
git add .
git commit -m "fix: correct login error handling"
```

### Step 5：合併或發 PR

回到主目錄：

```bash
cd C:/github/payment-service
```

合併到目標分支：

```bash
git switch main
git merge --no-ff hotfix/login-error
git push origin main
```

### Step 6：清理 worktree

```bash
git worktree remove .worktrees/hotfix-login-error
git worktree prune
git branch -d hotfix/login-error
```

---

## 9. 完整範例：建立 Codex 任務 worktree

假設目前功能分支是：

```text
feature/payment-refactor
```

要建立 Codex 任務：

```text
codex/currency-service-tests
```

執行：

```bash
git worktree add .worktrees/currency-service-tests -b codex/currency-service-tests feature/payment-refactor
cd .worktrees/currency-service-tests
codex
```

Codex 完成後：

```bash
git status
git diff
dotnet test
git add .
git commit -m "test: add CurrencyService unit tests"
```

回主目錄合併：

```bash
cd C:/github/payment-service
git switch feature/payment-refactor
git merge --no-ff codex/currency-service-tests
dotnet test
git push origin feature/payment-refactor
```

清理：

```bash
git worktree remove .worktrees/currency-service-tests
git worktree prune
git branch -d codex/currency-service-tests
```

---

## 10. 常見限制與注意事項

### 10.1 同一個 branch 通常不能同時被多個 worktree checkout

錯誤觀念：

```text
我想讓兩個 worktree 都 checkout feature/payment-refactor
```

正確做法：

```text
feature/payment-refactor
codex/add-tests
codex/refactor-service
hotfix/login-error
```

每個 worktree 使用自己的 branch。

---

### 10.2 worktree 移除不等於 branch 刪除

這個指令：

```bash
git worktree remove .worktrees/add-tests
```

只會移除工作目錄。

如果 branch 不需要，要另外刪：

```bash
git branch -d codex/add-tests
```

如果遠端 branch 也不需要：

```bash
git push origin --delete codex/add-tests
```

---

### 10.3 手動刪資料夾後要 prune

如果你直接用檔案總管或 `rm -rf` 刪掉 worktree 目錄，Git 可能仍然認為它存在。

執行：

```bash
git worktree prune
```

---

### 10.4 未追蹤檔案不會自動出現在新 worktree

新 worktree 只會 checkout Git 追蹤的內容。

這些檔案如果沒有進版控，就不會自動出現在新 worktree：

```text
.env
appsettings.Development.json
local.settings.json
docker-compose.override.yml
secrets.json
```

建議提供 example 檔案：

```text
.env.example
appsettings.Development.example.json
```

---

### 10.5 每個 worktree 可能需要自己的相依套件與 build output

例如：

```text
.NET:
  bin/
  obj/
  NuGet restore 狀態

Node.js:
  node_modules/
  package lock 狀態

Python:
  .venv/
  __pycache__/
```

不要假設主目錄能跑，新的 worktree 就一定能跑。

---

### 10.6 不要把 `.worktrees/` 加入版控

`.worktrees/` 應該只存在本機。

請加入 `.gitignore`：

```gitignore
.worktrees/
```

---

## 11. 建議 branch 命名方式

功能分支：

```text
feature/payment-refactor
feature/order-import
```

Codex 任務分支：

```text
codex/currency-service-tests
codex/refactor-payment-validator
codex/update-api-docs
```

Hotfix 分支：

```text
hotfix/login-error
hotfix/currency-rounding
```

命名原則：

```text
- 清楚描述任務
- 不要使用 codex/fix、codex/test 這種模糊名稱
- worktree 目錄名稱應該能對應 branch 名稱
- 每個 worktree 只處理一個任務
```

---

## 12. 建議檢查清單

建立前：

```text
- 目前在正確 repository
- base branch 正確
- branch 名稱清楚
- `.worktrees/` 已加入 `.gitignore`
```

建立後：

```text
- `git branch --show-current` 正確
- `git status` 乾淨
- 專案可以 build / test
```

合併前：

```text
- 已 commit
- `git diff` 符合預期
- 沒有 secrets / local config
- 測試通過
- 沒有 unrelated changes
```

清理前：

```text
- worktree 變更已合併或不需要
- worktree 中沒有未提交變更
- branch 是否需要保留已確認
```

---

## 13. 常用指令速查

```bash
# 查看 worktree
git worktree list

# 建立新 branch + worktree
git worktree add .worktrees/<task> -b <new-branch> <base-branch>

# 用既有 branch 建立 worktree
git worktree add .worktrees/<task> <existing-branch>

# 移除 worktree
git worktree remove .worktrees/<task>

# 強制移除 worktree
git worktree remove --force .worktrees/<task>

# 清理 stale metadata
git worktree prune

# 刪除 local branch
git branch -d <branch>

# 刪除 remote branch
git push origin --delete <branch>
```

---

## 14. 總結

`git worktree` 的核心價值是：

> 同一個 repository，可以同時擁有多個獨立工作目錄。

它解決的是：

```text
- 不想一直 stash
- 不想反覆切 branch
- 想同時處理 feature / hotfix / experiment
- 想讓 Codex 或其他 Agent 在不同任務中獨立工作
```

對一般開發者來說，worktree 是多工開發工具。

對 Codex / AI Agent 工作流來說，worktree 是任務隔離邊界。
