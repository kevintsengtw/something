# Codex 與 Git Worktree 教學文件

這組文件整理「如何在 Codex 工作流中使用 Git worktree」，並補充傳統 Git worktree 的基礎知識。

文件順序建議如下：

1. [`01-codex-git-worktree-workflow.md`](./01-codex-git-worktree-workflow.md)  
   先看這篇。重點是 Codex 使用情境：怎麼開始、怎麼建立 worktree、怎麼讓 Codex 工作、怎麼合併、怎麼清理，以及有哪些限制。

2. [`02-git-worktree-basics.md`](./02-git-worktree-basics.md)  
   再看這篇。重點是傳統 Git worktree 的觀念、指令、限制與常見問題。

## 適用讀者

這份文件適合：

- 沒有使用過 `git worktree` 的開發者
- 已經會 Git branch，但不熟悉多工作目錄開發的開發者
- 正在使用 Codex / AI Agent 協助開發的團隊
- 想讓多個 Codex 任務平行處理，但不希望污染目前工作目錄的開發者

## 核心觀念

以前的 Git 使用方式通常是：

```bash
git switch feature/a
git switch hotfix/b
git switch main
```

也就是多個 branch 共用同一個 working directory。

`git worktree` 則是：

```text
repo/
repo/.worktrees/feature-a/
repo/.worktrees/hotfix-b/
repo/.worktrees/codex-add-tests/
```

同一個 repository 可以擁有多個獨立 working directory。

對 Codex 來說，worktree 的價值是：

> 讓不同 Codex 任務或 thread 在不同工作目錄中修改程式碼，避免互相干擾，也避免污染你目前正在開發的 local checkout。

## 建議目錄結構

```text
your-repo/
  src/
  tests/
  .git/
  .worktrees/
    codex-add-tests/
    codex-refactor-service/
    codex-update-docs/
```

建議把 `.worktrees/` 加入 `.gitignore`：

```gitignore
.worktrees/
```

## 建議命名規則

Codex 任務分支建議使用：

```text
codex/<task-name>
```

例如：

```text
codex/add-currency-service-tests
codex/refactor-payment-validator
codex/update-api-docs
```

## 參考來源

- OpenAI Codex App Worktrees: https://developers.openai.com/codex/app/worktrees
- OpenAI Codex App Features: https://developers.openai.com/codex/app/features
- OpenAI Codex App Automations: https://developers.openai.com/codex/app/automations
- OpenAI Codex App Troubleshooting: https://developers.openai.com/codex/app/troubleshooting
- Git 官方 `git worktree` 文件: https://git-scm.com/docs/git-worktree
