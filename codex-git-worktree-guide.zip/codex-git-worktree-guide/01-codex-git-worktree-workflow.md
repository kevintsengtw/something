# Codex 使用 Git Worktree 的實務流程

## 1. 這篇文件的目的

這篇文件先不從 Git 理論開始，而是直接從 Codex 實務流程開始。

目標是讓開發者知道：

- 什麼時候要讓 Codex 使用 worktree
- 在 Codex 裡可以怎麼下指令
- 在 Codex CLI / terminal 裡怎麼手動建立 worktree
- Codex 完成後怎麼檢查成果
- 怎麼合併回功能分支
- 怎麼結束並清理 worktree
- 使用上有哪些限制與注意事項

---

## 2. Codex 為什麼需要 worktree？

Codex 可以協助處理多種開發任務，例如：

```text
- 修 bug
- 補單元測試
- 重構 service
- 更新文件
- 調整 CI/CD 設定
- 分析錯誤並修改程式碼
```

如果所有任務都在同一個 working directory 執行，會有幾個問題：

```text
- Codex 可能改到你目前尚未完成的檔案
- 多個 Codex thread 可能互相覆蓋修改
- 測試、build output、local config 可能互相干擾
- 你很難 review 每個任務各自產生了什麼 diff
```

`git worktree` 可以讓每個任務有自己的工作目錄。

例如：

```text
payment-service/
  你自己的主要工作目錄

payment-service/.worktrees/codex-add-tests/
  Codex 補測試

payment-service/.worktrees/codex-refactor-service/
  Codex 重構 service

payment-service/.worktrees/codex-update-docs/
  Codex 更新文件
```

對 Codex 來說，worktree 不是炫技，而是任務隔離機制。

---

## 3. Codex App 與 Codex CLI 要分開看

使用 Codex 時，要先區分兩種情境。

### 3.1 Codex App

如果你使用的是 Codex App，優先使用 Codex App 內建的 worktree / thread 能力。

此時你通常不需要自己手動執行：

```bash
git worktree add ...
```

而是用自然語言清楚要求 Codex：

```text
請使用獨立 worktree / thread 處理這個任務，不要修改我目前的 local checkout。
```

Codex App 本身已經支援 worktrees，用於讓多個 Codex threads 在同一個專案中獨立工作。

### 3.2 Codex CLI / Terminal

如果你使用的是 Codex CLI 或 terminal 工作流，建議流程是：

```text
先用 git worktree 建立獨立工作目錄
再進入該 worktree 啟動 codex
```

也就是：

```bash
git worktree add .worktrees/codex-add-tests -b codex/add-tests feature/my-feature
cd .worktrees/codex-add-tests
codex
```

---

## 4. 什麼任務適合使用 worktree？

適合使用 worktree：

```text
- Codex 要修改多個檔案
- Codex 要補大量測試
- Codex 要做重構
- Codex 要嘗試不同實作方案
- 你目前 local checkout 有未完成修改
- 你希望多個 Codex 任務平行進行
- 你希望每個任務都能獨立 review / merge
```

不一定需要 worktree：

```text
- 單純問問題
- 單純解釋程式碼
- 單純產生一小段程式碼
- 單檔小修正
- 不會實際修改 repository
```

建議原則：

> 只要 Codex 會實際修改 repository，而且任務不是非常小，就優先使用 worktree。

---

## 5. 在 Codex App 裡怎麼下指令建立 worktree 工作流？

在 Codex App 中，你可以用自然語言描述工作方式。

### 5.1 基本指令範本

```text
請使用獨立 worktree / thread 處理這個任務，不要污染我目前的 local checkout。

任務：
補上 CurrencyService 的單元測試。

基準分支：
feature/payment-refactor

建議工作分支：
codex/currency-service-tests

要求：
1. 先檢查目前 repository 狀態
2. 在獨立 worktree 中進行修改
3. 不要修改 unrelated files
4. 完成後執行測試
5. 回報修改檔案、測試結果與需要 review 的地方
```

### 5.2 簡短版指令

```text
請用獨立 worktree 處理這個任務，不要污染目前工作目錄。
從 feature/payment-refactor 建立 codex/currency-service-tests，
完成 CurrencyService 單元測試後，執行測試並回報 diff 摘要。
```

### 5.3 多任務平行版指令

```text
請將以下任務拆成兩個獨立 Codex worktree thread：

1. codex/currency-service-tests
   補 CurrencyService 單元測試

2. codex/currency-service-review
   檢查 CurrencyService 是否有可讀性或結構問題，但不要直接重構

每個 thread 都要獨立工作，不要共用同一個 branch。
完成後分別回報修改摘要、測試結果與建議。
```

### 5.4 下指令時要講清楚的資訊

建議一定要講清楚：

```text
- 是否要使用獨立 worktree / thread
- base branch 是哪一個
- 建議的 Codex 任務分支名稱
- 不要污染目前 local checkout
- 不要修改 unrelated files
- 完成後要執行哪些測試
- 回報格式要包含哪些資訊
```

---

## 6. 在 Codex CLI / Terminal 裡怎麼開始？

假設專案在：

```text
C:\github\payment-service
```

目前功能分支是：

```text
feature/payment-refactor
```

要讓 Codex 補測試，並建立任務分支：

```text
codex/currency-service-tests
```

### Step 1：回到主要 repo

```bash
cd C:/github/payment-service
```

### Step 2：檢查目前狀態

```bash
git status
git branch --show-current
git fetch --all --prune
```

### Step 3：建立 `.worktrees` 目錄

```bash
mkdir .worktrees
```

### Step 4：將 `.worktrees/` 加入 `.gitignore`

```bash
echo ".worktrees/" >> .gitignore
```

如果 `.gitignore` 已經有這一行，就不要重複加入。

### Step 5：建立新的 worktree 與任務分支

```bash
git worktree add .worktrees/currency-service-tests -b codex/currency-service-tests feature/payment-refactor
```

意思是：

```text
.worktrees/currency-service-tests
  新的 worktree 目錄

codex/currency-service-tests
  新的 Codex 任務分支

feature/payment-refactor
  建立任務分支的 base branch
```

### Step 6：進入 worktree

```bash
cd .worktrees/currency-service-tests
```

### Step 7：確認分支與狀態

```bash
git branch --show-current
git status
```

### Step 8：啟動 Codex

```bash
codex
```

### Step 9：對 Codex 下任務

```text
目前這個目錄是獨立 git worktree。
目前分支是 codex/currency-service-tests。
base branch 是 feature/payment-refactor。

請補上 CurrencyService 的單元測試。

要求：
1. 使用 xUnit
2. 使用 NSubstitute
3. 使用 AutoFixture 時要保持測試可讀性
4. 測試命名要清楚表達行為
5. 不要修改 production code，除非測試暴露出必要問題
6. 不要修改 unrelated files
7. 完成後執行 dotnet test
8. 回報修改檔案、測試結果與後續建議
```

---

## 7. Codex 完成後要怎麼檢查？

Codex 完成後，不要直接合併。

先要求 Codex 回報：

```text
請整理本次 worktree 的成果：

1. 修改了哪些檔案
2. 每個檔案的修改目的
3. 是否有修改 production code
4. 是否有新增或修改測試
5. 執行了哪些測試
6. 測試結果
7. 是否有未完成事項
8. 合併回 feature/payment-refactor 前需要注意什麼
```

接著在 worktree 裡檢查：

```bash
git status
git diff
git log --oneline --decorate -5
```

如果是 .NET 專案，至少執行：

```bash
dotnet build
dotnet test
```

如果有 solution：

```bash
dotnet test YourSolution.sln
```

---

## 8. Codex 變更要不要 commit？

建議要 commit。

如果 Codex 還沒有 commit，可以要求它整理 commit：

```text
請將目前變更整理成一個清楚的 commit。
commit message 使用 Conventional Commits 格式。
```

或手動 commit：

```bash
git add .
git commit -m "test: add CurrencyService unit tests"
```

建議 commit message：

```text
test: add CurrencyService unit tests
fix: correct payment validation
refactor: simplify CurrencyService approval flow
docs: update worktree usage guide
```

---

## 9. 怎麼合併回功能分支？

假設：

```text
功能分支：
feature/payment-refactor

Codex 任務分支：
codex/currency-service-tests
```

### 9.1 方式一：在本機直接 merge

先回到主要 repo 目錄：

```bash
cd C:/github/payment-service
```

切回功能分支：

```bash
git switch feature/payment-refactor
```

確認狀態乾淨：

```bash
git status
```

合併 Codex 分支：

```bash
git merge --no-ff codex/currency-service-tests
```

執行測試：

```bash
dotnet test
```

推送功能分支：

```bash
git push origin feature/payment-refactor
```

### 9.2 方式二：透過 Pull Request 合併

如果團隊要求 code review，建議不要直接 merge。

在 worktree 中推送 Codex 分支：

```bash
cd C:/github/payment-service/.worktrees/currency-service-tests
git push -u origin codex/currency-service-tests
```

建立 PR：

```text
codex/currency-service-tests
  → feature/payment-refactor
```

PR 通過後再合併。

適合用 PR 的情境：

```text
- 修改範圍大
- 需要團隊 review
- 需要 CI 驗證
- Codex 有修改 production code
- 需要留下審查紀錄
```

---

## 10. 合併前檢查清單

合併前建議執行：

```bash
git status
git diff feature/payment-refactor...codex/currency-service-tests
git log --oneline feature/payment-refactor..codex/currency-service-tests
```

檢查：

```text
- 是否只有修改預期檔案
- 是否有不必要的格式化變更
- 是否誤加入 secrets
- 是否誤加入 local config
- 是否誤加入 bin / obj / node_modules
- 測試是否通過
- 是否破壞既有 API 行為
- 是否引入過度設計
```

---

## 11. 如果 merge conflict 怎麼辦？

合併時可能會出現 conflict：

```bash
git merge --no-ff codex/currency-service-tests
```

查看狀態：

```bash
git status
```

處理 conflict 後：

```bash
git add .
git commit
dotnet test
```

也可以請 Codex 協助，但指令要寫清楚：

```text
目前正在將 codex/currency-service-tests 合併回 feature/payment-refactor，
發生 merge conflict。

請協助分析 conflict，但不要直接採用任一方全部內容。
請保留 feature/payment-refactor 的既有行為，
並整合 codex/currency-service-tests 新增的測試。
完成後說明每個 conflict 的處理理由。
```

---

## 12. 怎麼結束整個 worktree？

合併完成後，要清理 worktree。

### Step 1：確認 worktree 沒有未提交變更

```bash
cd C:/github/payment-service/.worktrees/currency-service-tests
git status
```

### Step 2：回到主要 repo

```bash
cd C:/github/payment-service
```

### Step 3：移除 worktree

```bash
git worktree remove .worktrees/currency-service-tests
```

### Step 4：清理 stale metadata

```bash
git worktree prune
```

### Step 5：刪除已合併的 local branch

```bash
git branch -d codex/currency-service-tests
```

### Step 6：如果遠端分支也不需要，刪除遠端分支

```bash
git push origin --delete codex/currency-service-tests
```

完整範例：

```bash
cd C:/github/payment-service

git switch feature/payment-refactor
git merge --no-ff codex/currency-service-tests
dotnet test
git push origin feature/payment-refactor

git worktree remove .worktrees/currency-service-tests
git worktree prune
git branch -d codex/currency-service-tests
git push origin --delete codex/currency-service-tests
```

---

## 13. Codex worktree 使用限制

### 13.1 不要讓兩個 worktree 使用同一個 branch

Git 通常不允許同一個 branch 同時被多個 worktree checkout。

錯誤觀念：

```text
主目錄 checkout feature/payment-refactor
另一個 worktree 也 checkout feature/payment-refactor
```

建議做法：

```text
主功能分支：
feature/payment-refactor

Codex 任務分支：
codex/currency-service-tests
codex/refactor-payment-validator
codex/update-api-docs
```

每個 worktree 對應一個獨立任務分支。

---

### 13.2 worktree 不是完整 clone

worktree 不是重新 clone 一份 repository。

它會共用同一個 Git repository 的物件資料，但每個 worktree 仍然有自己的 working directory。

因此每個 worktree 可能都需要：

```text
- restore NuGet packages
- npm install
- 建立自己的 .env
- 建立自己的 local settings
- 產生自己的 bin / obj / node_modules
```

---

### 13.3 未納入 Git 的檔案不會自動出現在新的 worktree

新的 worktree 預設只會有 Git 追蹤的檔案。

如果專案依賴：

```text
.env
appsettings.Development.json
local.settings.json
secrets.json
docker-compose.override.yml
```

新的 worktree 可能無法直接執行。

建議提供：

```text
.env.example
appsettings.Development.example.json
README setup 說明
```

不要讓 Codex 自行猜測 secrets。

---

### 13.4 不要手動亂刪 Codex App 管理的 worktree

如果 worktree 是 Codex App 建立和管理的，應優先使用 Codex App 的 UI / thread / handoff 流程。

不要直接到檔案系統刪除資料夾，否則可能留下 Git metadata 或造成 Codex App 狀態不一致。

---

### 13.5 移除 worktree 不等於刪除 branch

```bash
git worktree remove .worktrees/currency-service-tests
```

只會移除 worktree 工作目錄。

如果 branch 不需要，要另外刪除：

```bash
git branch -d codex/currency-service-tests
git push origin --delete codex/currency-service-tests
```

---

### 13.6 worktree 不取代 review

worktree 解決的是隔離問題，不是正確性問題。

Codex 完成後仍然要 review：

```text
- 是否符合需求
- 是否修改到不該改的檔案
- 測試是否真的有效
- 是否破壞架構
- 是否有過度設計
- 是否誤加入 secrets 或 local config
```

---

## 14. 建議團隊規範

可以把以下規則放進團隊文件：

```text
1. Codex 大型修改必須使用獨立 worktree 或 Codex App worktree thread。
2. Codex 任務分支使用 codex/<task-name> 命名。
3. 每個 worktree 只處理一個明確任務。
4. 不允許多個 worktree 共用同一個 branch。
5. 合併前必須檢查 git diff 與測試結果。
6. 合併後必須清理 worktree。
7. Codex 不應自行提交 secrets、local config、build artifacts。
8. Codex App 管理的 worktree 不應手動亂刪。
9. 如果修改範圍大，應透過 PR 合併回功能分支。
10. worktree 解決隔離問題，不取代 code review。
```

---

## 15. 總結

Codex 使用 worktree 的核心目標是：

> 讓每個 Codex 任務有自己的獨立工作目錄與任務分支，避免污染目前 local checkout，也避免多個任務互相干擾。

實務上可以分成兩種：

```text
Codex App：
  優先使用內建 worktree / thread 功能，
  用自然語言要求 Codex 在獨立 worktree 中處理任務。

Codex CLI / Terminal：
  手動用 git worktree 建立任務目錄，
  再進入該目錄啟動 codex。
```

一句話總結：

> 以前是人類在同一個目錄切 branch。  
> 現在是 Codex 可以平行處理多個任務。  
> 所以我們需要用 worktree 把每個任務隔離起來。
