# 官方 MCP C# SDK v1.0 正式發布

> 原文：[Release v1.0 of the official MCP C# SDK - .NET Blog](https://devblogs.microsoft.com/dotnet/release-v10-of-the-official-mcp-csharp-sdk/)
> 發布日期：2026 年 3 月 5 日

---

## 概覽

Model Context Protocol（模型上下文協定，MCP）C# SDK 已達成 **v1.0** 的里程碑，完整支援 MCP 規範的 **2025-11-25** 版本。本次發布帶來了一系列豐富的新功能——從改進的授權流程和更豐富的中繼資料，到工具呼叫、引出（Elicitation）和長時間運行請求處理的強大新模式。

SDK 以三個 NuGet 套件的形式發佈：

- **`ModelContextProtocol.Core`**：適用於僅需使用客戶端或低階伺服器 API 且希望最少相依性的專案
- **`ModelContextProtocol`**：包含託管和相依性注入擴展的主要套件，適合大多數不需要 HTTP 伺服器功能的專案
- **`ModelContextProtocol.AspNetCore`**：適用於基於 HTTP 的 MCP 伺服器的程式庫

如果您不確定該用哪個，請從 `ModelContextProtocol` 套件開始。

---

## 授權（Authorization）

### 增強的授權伺服器探索

在先前的規範中，伺服器必須在 `WWW-Authenticate` 標頭的 `resource_metadata` 參數中提供指向其受保護資源中繼資料（Protected Resource Metadata，PRM）文件的連結。2025-11-25 規範擴展了這一機制，為伺服器提供了**三種方式**來公開 PRM：

1. **透過 `WWW-Authenticate` 標頭中的 URL**：與之前相同，在 `resource_metadata` 參數中提供 URL
2. **透過「眾所周知（well-known）」URL**：從伺服器的 MCP 端點路徑衍生而來
3. **透過根層級的眾所周知 URL**：在伺服器根路徑的 well-known 位置

MCP C# SDK 的客戶端實作會自動按照規範定義的優先順序依次嘗試這三種方式。

### 遞增式範圍同意（Incremental Scope Consent）

遞增式範圍同意是本次發布的另一個關鍵功能。它將**最小權限原則**應用於 MCP 授權，允許客戶端僅請求每次操作所需的最小存取權限。

透過這個新機制：

- 客戶端從最小範圍開始
- 在需要時才請求額外的範圍
- SDK 在客戶端自動處理此流程

當客戶端收到帶有 `scopes` 參數的 `401` 或 `403` 回應的 `WWW-Authenticate` 標頭時，它會提取所需的範圍並啟動授權流程——無需額外的客戶端程式碼。

### 客戶端 ID 中繼資料文件（Client ID Metadata Documents）

2025-11-25 規範引入了**客戶端 ID 中繼資料文件（CIMDs）**作為動態客戶端註冊（Dynamic Client Registration，DCR）的替代方案，用於與授權伺服器建立客戶端身份。

CIMDs 允許客戶端在自託管的 URL 上發佈其中繼資料，而非透過 DCR 端點動態註冊。授權伺服器可以在需要時取得此中繼資料以驗證客戶端身份。

---

## 圖示支援（Icon Support）

2025-11-25 規範為工具（Tools）、資源（Resources）和提示詞（Prompts）新增了圖示中繼資料。此資訊包含在 `tools/list`、`resources/list` 和 `prompts/list` 請求的回應中。

在 C# SDK 中，您可以透過 `McpServerTool` 屬性的簡單參數指定圖示：

```csharp
[McpServerTool(IconUrl = "https://example.com/icon.png"),
 Description("取得天氣資訊")]
public static string GetWeather(string city) => $"{city} 的天氣晴朗";
```

對於更進階的場景，可以使用 `McpServerTool.Create()` 搭配 `McpServerToolCreateOptions` 來設定多個圖示、MIME 類型、尺寸提示和主題偏好。

---

## 結構化輸出（Structured Output）

MCP C# SDK 讓工具能夠透過 `McpServerTool` 屬性的 `UseStructuredContent` 參數指定其輸出為結構化格式。

啟用後，C# SDK 會根據方法的回傳型別為工具的輸出生成 JSON Schema，並將此 Schema 包含在工具的中繼資料中。客戶端在呼叫工具後，可以在回應的 `structuredContent` 欄位中存取結構化資料。

```csharp
[McpServerTool(UseStructuredContent = true),
 Description("取得結構化的產品資料列表")]
public static List<Product> GetProducts(int count = 5)
{
    return Enumerable.Range(1, count)
        .Select(i => new Product($"Product {i}", i * 10.0m))
        .ToList();
}

public record Product(string Name, decimal Price);
```

---

## URL 模式引出（URL Mode Elicitation）

URL 模式引出是本次發布的一項重要新功能，它使伺服器能夠將敏感互動（如 API 金鑰收集或第三方授權）從 MCP 客戶端完全重新導向到安全的伺服器託管 URL。

這解決了一個重要的安全問題：防止敏感資料透過客戶端傳輸。主要應用場景包括：

- **API 金鑰收集**：安全地向使用者收集 API 金鑰
- **第三方授權**：引導使用者完成 OAuth 流程
- **付款資訊**：安全地處理支付相關資料

使用 Streamable HTTP 傳輸的 MCP 伺服器必須將每個引出請求和回應與正確的 MCP 工作階段關聯，並維護狀態以追蹤待處理的引出請求，然後將回應傳回給發起的 MCP 請求。

---

## 取樣中的工具呼叫（Tool Calling in Sampling）

這是規範中最重要的技術新增功能之一。伺服器現在可以在其取樣（Sampling）請求中**包含工具**，大型語言模型（LLM）可以調用這些工具來產生回應。

這為以下場景開啟了大門：

- 伺服器可以向客戶端發送取樣請求，要求 LLM 完成特定任務
- LLM 在生成回應的過程中可以使用提供的工具
- 工具呼叫的結果會被整合回最終回應中

---

## 長時間運行請求處理（Long-Running Request Handling）

### HTTP 輪詢改進

2025-11-25 規範改進了長時間運行請求的處理方式。使用 HTTP 的伺服器在開啟 SSE（Server-Sent Events）串流時：

1. 以一個**空事件**開始，其中包含**事件 ID**和可選的 **Retry-After** 欄位
2. 發送此初始事件後，伺服器可以隨時關閉串流
3. 客戶端可以使用事件 ID 重新連接

這使得連接管理更加可靠和靈活。

### 任務（Tasks）功能（實驗性）

MCP C# SDK 1.0 引入了**任務（Tasks）**，這是 2025-11-25 MCP 規範的一項實驗性功能，提供持久狀態追蹤和延遲結果擷取。

工作流程如下：

1. **建立任務**：客戶端在請求中（例如 `tools/call`）包含 `task` 欄位，表示希望進行持久結果追蹤
2. **伺服器回應**：伺服器回傳 `CreateTaskResult`，包含任務中繼資料——唯一的任務 ID、目前狀態（`working`）、時間戳記、存活時間（TTL），以及可選的建議輪詢間隔
3. **客戶端操作**：
   - `tasks/get`：輪詢狀態
   - `tasks/result`：擷取儲存的結果
   - `tasks/list`：列舉任務
   - `tasks/cancel`：取消正在運行的任務

---

## 進度通知（Progress Notifications）

MCP 透過通知訊息支援長時間運行操作的進度追蹤。伺服器在處理請求時，可以使用 `McpServer` 的 `SendNotificationAsync` 擴展方法發送進度更新，指定 `"notifications/progress"` 作為通知方法名稱。

C# SDK 會向相依性注入容器註冊 `McpServer` 實例，因此工具只需在其方法簽章中加入 `McpServer` 型別的參數即可存取它。

客戶端可以透過兩種方式處理進度通知：

1. **註冊通知處理器**：使用 `McpClient` 實例的 `RegisterNotificationHandler` 方法
2. **使用 `Progress<T>`**：標準 .NET 型別，`T` 應為 `ProgressNotificationValue`。MCP C# SDK 會自動處理進度通知並透過 `Progress<T>` 實例回報

---

## 取消支援（Cancellation Support）

`CancellationToken` 參數會自動繫結到 `McpServer` 提供的 `CancellationToken`，並尊重客戶端為此操作的 `RequestId` 發送的任何 `CancelledNotificationParams`。

用於指示先前發出的請求應被取消的通知名稱為 `"notifications/cancelled"`。此通知表示結果將不再使用，因此任何相關的處理**應該**停止。

---

## 自動核准（Auto-Approve）

沙盒化的 MCP 伺服器工具確認會自動核准，因為伺服器運行在受控環境中，僅能存取明確允許的檔案系統路徑和網路網域。

透過 npm、pnpm 或 yarn 執行的 npm 腳本，若已定義在 `package.json` 中，現在預設自動核准。

---

## 重大變更（Breaking Changes）

### RequestOptions 重構

高階請求方法已被重構，改為接受新的 `RequestOptions` 參數，取代原本的個別 `JsonSerializerOptions` 和 `ProgressToken` 參數。

**影響**：將 `JsonSerializerOptions` 或 `ProgressToken` 作為具名或位置參數傳遞給高階請求方法的程式碼將會中斷，必須更新為使用 `RequestOptions` 包裝物件。

```csharp
// 舊寫法（會中斷）
await client.CallToolAsync("toolName", args, jsonOptions, progressToken);

// 新寫法
await client.CallToolAsync("toolName", args, new RequestOptions
{
    SerializerOptions = jsonOptions,
    ProgressToken = progressToken
});
```

### McpServerFactory 移除

`McpServerFactory` 類別已作為過時的伺服器建立工廠類別被移除。

---

## 快速入門（Getting Started）

### 建立 MCP 伺服器

```csharp
// 1. 建立新的主控台應用程式
// dotnet new console
// dotnet add package ModelContextProtocol
// dotnet add package Microsoft.Extensions.Hosting

using Microsoft.Extensions.Hosting;
using ModelContextProtocol.Server;
using System.ComponentModel;

var builder = Host.CreateApplicationBuilder(args);
builder.Services
    .AddMcpServer()
    .WithStdioServerTransport()
    .WithToolsFromAssembly();

await builder.Build().RunAsync();

[McpServerToolType]
public static class MyTools
{
    [McpServerTool, Description("將兩個數字相加")]
    public static double Add(double a, double b) => a + b;
}
```

### 建立 MCP 客戶端

```csharp
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol.Transport;

var client = await McpClientFactory.CreateAsync(
    new StdioClientTransport(new StdioClientTransportOptions
    {
        Command = "dotnet",
        Arguments = ["run", "--project", "../MyMcpServer"]
    }));

// 列出可用工具
var tools = await client.ListToolsAsync();
foreach (var tool in tools)
{
    Console.WriteLine($"工具：{tool.Name} - {tool.Description}");
}

// 呼叫工具
var result = await client.CallToolAsync("Add", new { a = 1, b = 2 });
Console.WriteLine($"結果：{result}");
```

### 基於 HTTP 的 MCP 伺服器（使用 ASP.NET Core）

```csharp
// dotnet add package ModelContextProtocol.AspNetCore

var builder = WebApplication.CreateBuilder(args);
builder.Services
    .AddMcpServer()
    .WithToolsFromAssembly();

var app = builder.Build();
app.MapMcp();
app.Run();
```

---

## 總結

MCP C# SDK v1.0 的發布標誌著 .NET 生態系統中 MCP 支援的一個重要里程碑。本次更新的核心亮點包括：

- **增強的授權流程**：更靈活的 PRM 探索、遞增式範圍同意、客戶端 ID 中繼資料文件
- **圖示支援**：工具、資源和提示詞現在可以包含圖示中繼資料
- **結構化輸出**：工具可以回傳具有 JSON Schema 的結構化內容
- **URL 模式引出**：安全地處理敏感互動
- **取樣中的工具呼叫**：LLM 可在取樣過程中調用工具
- **長時間運行請求處理**：改進的 SSE 串流和實驗性任務功能
- **進度通知與取消支援**：完善的長時間操作管理

此 SDK 由 Microsoft 與 Model Context Protocol 組織合作維護，原始碼託管於 [GitHub](https://github.com/modelcontextprotocol/csharp-sdk)。

---

## 詞彙對照表

| 英文 | 繁體中文 |
|------|----------|
| Model Context Protocol (MCP) | 模型上下文協定 |
| Authorization | 授權 |
| Protected Resource Metadata (PRM) | 受保護資源中繼資料 |
| Incremental Scope Consent | 遞增式範圍同意 |
| Client ID Metadata Documents (CIMDs) | 客戶端 ID 中繼資料文件 |
| Dynamic Client Registration (DCR) | 動態客戶端註冊 |
| Structured Output | 結構化輸出 |
| Elicitation | 引出 |
| URL Mode Elicitation | URL 模式引出 |
| Sampling | 取樣 |
| Tool Calling | 工具呼叫 |
| Long-Running Request | 長時間運行請求 |
| Tasks | 任務 |
| Progress Notifications | 進度通知 |
| Cancellation | 取消 |
| Server-Sent Events (SSE) | 伺服器推送事件 |
| Breaking Changes | 重大變更 |
| Dependency Injection | 相依性注入 |
| NuGet Package | NuGet 套件 |
| Streamable HTTP Transport | 可串流 HTTP 傳輸 |
| stdio Transport | 標準輸入輸出傳輸 |
| Well-Known URL | 眾所周知 URL |
| Least Privilege | 最小權限 |
| Polling | 輪詢 |
| Time-to-Live (TTL) | 存活時間 |
| JSON Schema | JSON 結構描述 |

---

*注意：由於原始部落格頁面（devblogs.microsoft.com）在此環境中無法直接存取完整全文，本翻譯內容是根據官方部落格搜尋摘要、InfoQ 報導、InfoWorld 報導、GitHub 儲存庫資訊及 MCP C# SDK 官方文件整理而成。原始部落格文章可能包含更多的程式碼範例、截圖和實作細節。強烈建議參閱[原文](https://devblogs.microsoft.com/dotnet/release-v10-of-the-official-mcp-csharp-sdk/)以獲取最完整的資訊。*

*翻譯來源：*
- [.NET Blog 原文](https://devblogs.microsoft.com/dotnet/release-v10-of-the-official-mcp-csharp-sdk/)
- [InfoQ 報導](https://www.infoq.com/news/2026/03/mcp-csharp-v1/)
- [InfoWorld 報導](https://www.infoworld.com/article/4141959/mcp-c-sharp-sdk-1-0-arrives-with-improved-authorization-server-discovery.html)
- [GitHub 儲存庫](https://github.com/modelcontextprotocol/csharp-sdk)
- [MCP C# SDK 官方文件](https://csharp.sdk.modelcontextprotocol.io/)
