# /extract-facts — 從 release notes 抽取事實清單並逐筆驗證

**用法**：`/extract-facts <version>`（例：`/extract-facts 1.7.0`）

從 `agent-framework-kb/raw/release-notes/dotnet-<version>.md` 抽取本次版本提到的所有 API 變更，**逐筆用 codebase-memory-mcp 驗證存在性、簽名、namespace**，產出結構化事實清單 JSON。

這個指令是 ground truth 的源頭——`/compile` 編譯 wiki 時的 frontmatter（api_name、namespace、簽名）必須引用此清單。

## 前置條件

- `agent-framework-kb/raw/release-notes/dotnet-<version>.md` 已存在（由 `/sync-upstream` 抓取）
- codebase-memory-mcp 已對 `agent-framework/` 建立索引（首次需 `index_repository`）

## 執行步驟

1. **讀取 release notes**
   - 讀取 `agent-framework-kb/raw/release-notes/dotnet-<version>.md`
   - 抽取本次版本提到的所有 API 變更，分三類：
     - `added`：新增的 class / interface / method / extension method
     - `renamed`：改名（記錄舊名 + 新名）
     - `deprecated` / `removed`：廢棄或移除

2. **逐筆 codebase-memory-mcp 驗證**

   對每個項目：

   **存在性確認**
   ```
   mcp__codebase-memory-mcp__search_graph
     project: "agent-framework"
     name_pattern: "<API 名稱>"
   ```
   - 結果 = 1 個節點 → ✅ 正常
   - 結果 > 1 個節點（多個同名）→ 用 namespace 或 file_path 消歧
   - 結果 = 0 → 標記 `⚠️ release notes 提到但圖譜查無`

   **簽名與 namespace**
   ```
   mcp__codebase-memory-mcp__get_code_snippet
     project: "agent-framework"
     qualified_name: "<完整 qualified name>"
   ```
   - 取得 namespace、file_path、method signatures
   - 寫入事實清單

   **取得依賴鏈與測試覆蓋**
   ```
   mcp__codebase-memory-mcp__trace_path
     project: "agent-framework"
     function_name: "<API 名稱>"
     direction: "inbound"
     depth: 2
     include_tests: true
   ```
   - 取得 callers 數量與測試引用，作為使用脈絡參考

   **廢棄確認**（針對 removed / deprecated）
   ```
   mcp__codebase-memory-mcp__trace_path
     project: "agent-framework"
     function_name: "<舊 API 名稱>"
     direction: "inbound"
     depth: 1
   ```
   - 結果為空 → 廢棄徹底
   - 結果非空 → 上游仍有內部呼叫，標記 `[Deprecated, internal references remain]`

3. **寫入事實清單 JSON**

   產出 `agent-framework-kb/raw/facts/dotnet-<version>-verified-changes.json`：

   ```json
   {
     "version": "1.7.0",
     "generated": "YYYY-MM-DDTHH:MM:SSZ",
     "indexed_commit": "<agent-framework HEAD hash>",
     "changes": [
       {
         "kind": "added",
         "name": "<API 名稱>",
         "qualified_name": "<完整 qualified name>",
         "namespace": "<namespace>",
         "file_path": "<agent-framework/dotnet/src/...>",
         "signatures": ["..."],
         "callers_in_upstream": 0,
         "verified": true,
         "source_release_note_line": "<原文引用>"
       }
     ],
     "unverified": [
       { "name": "...", "reason": "圖譜查無此節點" }
     ]
   }
   ```

4. **產出摘要**
   - 已驗證項目數 / 未驗證項目數
   - 列出未驗證項目並建議人工檢查
   - 建議接下來執行 `/compile`

## 注意事項

- 此指令是事實層的源頭，**LLM 在此階段不寫敘述**
- 所有結構性宣告（namespace、簽名）必須來自 codebase-memory-mcp，不可由 release notes 文字推測
- 未驗證項目**不直接寫入 wiki**——必須先排查原因
- 此 JSON 是 commit 對象，是後續流程的審計憑證
