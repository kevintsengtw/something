# /regenerate-toc — 重建 README.md 章節索引

掃描 `microsoft-agent-framework-tutorial/*.md` 標題，重建 `microsoft-agent-framework-tutorial/README.md` 中的章節表格與附錄表格。

## 用途

- 新章節由 `/draft-chapter` 草擬並人工移入後，需更新 TOC
- 新附錄由 `/draft-appendix` 草擬並人工移入後，需更新附錄索引
- 章節重新編號或拆分後，TOC 同步
- 定期一致性維護

## 執行步驟

1. **掃描現有章節**
   - 列出 `microsoft-agent-framework-tutorial/` 中所有 `NN-*.md`（01–99）
   - 列出 `microsoft-agent-framework-tutorial/appendix-*-*.md`
   - 對每個檔案讀取第一行 `# <章節編號> 標題` 取得標題

2. **抽取章節分類**
   - 根據 PLAN-beginner-tutorial.md 與既有 README 的分類規則，把章節分到「第一部分」「第二部分」等
   - 若有新增章節未在原規劃中，標記 ⚠️ 並提示需人工放入適當分類

3. **抽取附錄資訊**
   - 對每個附錄檔案，取得標題與描述（從檔案前幾行解析）

4. **讀取現有 README 結構**
   - 讀取 `microsoft-agent-framework-tutorial/README.md`
   - 找出章節表格區塊（## 教學目錄 之後）
   - 保留非章節表格內容（前言、版本記錄、授權等）

5. **重建章節表格**

   依分類順序產出表格：

   ```markdown
   ## 教學目錄

   ### 第一部分：認識框架

   | 章節 | 標題 | 說明 |
   |------|------|------|
   | 01 | [什麼是 Microsoft Agent Framework](./01-what-is-agent-framework.md) | <說明> |
   | 02 | [核心概念總覽](./02-core-concepts.md) | <說明> |

   ### 第二部分：環境建置與快速開始
   ...

   ### 附錄

   | 附錄 | 標題 | 說明 |
   |------|------|------|
   | A | [NuGet 套件清單](./appendix-a-nuget-packages.md) | <說明> |
   ```

6. **寫回 README.md**
   - 只更新章節與附錄表格區塊
   - 保留其他內容（前言、版本記錄表、授權、參考連結）
   - 使用 Edit 工具進行精確替換

7. **產出摘要**
   - 列出本次新增的章節（既有 README 沒有但檔案存在）
   - 列出本次移除的章節（README 有但檔案不存在）
   - 列出標題變動的章節
   - 標記未分類章節（⚠️ 需人工放入正確分類）

## 注意事項

- 此指令**不刪除任何教學檔案**，只更新 README 索引
- 若有未分類章節（新增章節未在 PLAN 規劃中），需人工編輯 PLAN-beginner-tutorial.md
- 章節描述（「說明」欄）若 README 既有的描述合理，保留；新章節用該章節第一段摘要
- 不修改章節檔案本身的內容
