# 29 — Agent Skills：可攜式技能套件

> 本章介紹 Microsoft Agent Framework v1.1.0 GA 的 **Agent Skills** 技能系統——將工具、資源（Resources）與腳本（Scripts）打包為可攜式、可重用套件的機制。代理透過漸進式揭露（Progressive Disclosure）按需載入技能內容，大幅節省 context window 空間。

---

## 為什麼需要 Agent Skills

假設你要建立一個能回答公司各種內部政策問題的代理。最直觀的做法是把所有文件都塞入 System Prompt：

```csharp
// ❌ 不好的做法：把所有知識一次塞入
AIAgent agent = chatClient.AsAIAgent(
    instructions: $"""
        你是公司政策助理。
        
        【請假規定】
        {File.ReadAllText("leave-policy.md")}
        
        【費用報銷規則】
        {File.ReadAllText("expense-policy.md")}
        
        【IT 設備申請流程】
        {File.ReadAllText("it-policy.md")}
        """);
```

問題在於：每次對話都要傳入數千個 token，即使使用者只問了一個簡單的請假問題。

**Agent Skills 的解法**：只在 System Prompt 裡宣告技能的名稱和描述（每個技能約 100 tokens），代理自己判斷何時需要哪個技能，再按需載入。

---

## 本章情境：公司政策問答代理

整章使用同一個情境：一個協助員工查詢 Contoso 公司政策的代理，需要回答三類問題：

| 知識領域 | 維護方式 | 使用的 Skill 類型 |
|----------|---------|-----------------|
| 請假規定 | HR 人員維護的 Markdown 文件 | File-Based |
| 費用報銷 | 需要 C# 計算邏輯（金額上限判斷） | Class-Based（`AgentClassSkill<T>`）|
| IT 設備申請 | 每次查詢時動態取得最新庫存 | Inline（`AgentInlineSkill`）|

---

## 漸進式揭露（Progressive Disclosure）

Agent Skills 的核心機制是「按需揭露」，分四個階段：

```text
① Advertise（~100 tokens/技能）
   → 每次 Run 開始時，代理自動收到技能名稱與描述

② Load（建議 < 5000 tokens）
   → 代理決定需要某技能時，呼叫 load_skill 取得完整指令

③ Read（按需）
   → 代理呼叫 read_skill_resource 讀取附加資源（文件、表格）

④ Run（按需）
   → 代理呼叫 run_skill_script 執行腳本（計算、查詢）
```

相較於一次性注入的做法，在有 10 個技能的情境下，漸進式揭露可節省超過 90% 的 context 用量。

---

## 安裝套件

Agent Skills 屬於核心套件，無需額外安裝：

```bash
dotnet add package Microsoft.Agents.AI
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

---

## 方式一：File-Based Skills（檔案式技能）

**適用情境**：請假規定由 HR 人員用 Markdown 文件維護，開發者不需介入內容更新。

### 目錄結構

在專案輸出目錄（通常是 `bin/Debug/net9.0/`）建立以下結構：

```text
skills/
└── hr-leave/
    ├── SKILL.md              # 必要：frontmatter + 代理指令
    ├── references/
    │   └── leave-policy.md  # 資源：詳細請假規則
    └── scripts/
        └── check-balance.py # 腳本：查詢員工剩餘假期
```

### SKILL.md

```yaml
---
name: hr-leave
description: Answer questions about company leave policy including annual leave, sick leave, and special leave.
license: MIT
---

Use this skill when an employee asks about leave policy.
1. Read the leave-policy resource for the current policy details.
2. Answer based on the policy, citing specific rules where relevant.
3. If the employee asks about their balance, use the check-balance script with their employee ID.
```

| 欄位 | 必要 | 說明 |
|------|------|------|
| `name` | 是 | 必須與目錄名稱相符，最多 64 字元 |
| `description` | 是 | 代理用來判斷何時載入此技能的關鍵，最多 1024 字元 |
| `license` | 否 | 授權聲明 |

YAML frontmatter 結束後，其餘內容就是代理載入技能時收到的指令文字。

### references/leave-policy.md

```markdown
# 請假規定（2026 年版）

## 年假
- 年資 1 年以下：7 天
- 年資 1–3 年：10 天
- 年資 3 年以上：15 天

## 病假
- 每年 30 天（含 15 天支薪病假）

## 事假
- 每年 14 天（不支薪）

## 申請方式
請至 HR 系統（hr.contoso.com）填寫請假單，至少提前 3 個工作天（緊急除外）。
```

### scripts/check-balance.py

```python
import sys
import json

def main():
    # v1.4.0+：引數以 --key value 旗標格式傳入
    employee_id = None
    args = sys.argv[1:]
    for i, arg in enumerate(args):
        if arg == "--employee_id" and i + 1 < len(args):
            employee_id = args[i + 1]

    if not employee_id:
        print(json.dumps({"error": "employee_id is required"}))
        return

    # 模擬查詢（實際可連接 HR 系統資料庫）
    balances = {
        "E001": {"annual": 8, "sick": 25, "personal": 10},
        "E002": {"annual": 12, "sick": 30, "personal": 14},
    }
    balance = balances.get(employee_id, {"annual": 0, "sick": 0, "personal": 0})
    print(json.dumps({"employee_id": employee_id, "balance": balance}))

if __name__ == "__main__":
    main()
```

### 建立 AgentSkillsProvider

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Azure.AI.OpenAI;
using Azure.Identity;

string endpoint       = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
string deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-4o-mini";

// 傳入技能目錄路徑 + script runner
var skillsProvider = new AgentSkillsProvider(
    Path.Combine(AppContext.BaseDirectory, "skills"),
    SubprocessScriptRunner.RunAsync);

AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        instructions: "你是 Contoso 公司的人資助理，協助員工查詢公司政策。",
        options: new ChatClientAgentOptions
        {
            AIContextProviders = [skillsProvider],
        });

string response = await agent.RunAsync("我今年還有幾天年假？我的員工編號是 E001。");
Console.WriteLine(response);
// 代理流程：Advertise hr-leave → Load hr-leave → Read leave-policy → Run check-balance(E001)
```

> **生產環境提醒**：`SubprocessScriptRunner` 以子行程執行腳本，僅供示範。正式環境需加入沙箱隔離、輸入驗證、輸出長度限制與稽核日誌。

---

### ⚠️ v1.4.0 Breaking Change：腳本引數型別改為 `string[]`

v1.4.0（PR #5475）將 file-based skill scripts 的引數傳遞方式從單一字串改為 `string[]`（`--key value` 旗標格式）。**若從 v1.3.0 升級，Python 腳本的引數解析方式需更新：**

```python
# Before（v1.3.0 及以前）— 引數作為位置引數傳入
import sys
employee_id = sys.argv[1]  # ❌ 不再有效
```

```python
# After（v1.4.0+）— 引數以 --key value 旗標格式傳入
import sys
args = sys.argv[1:]
for i, arg in enumerate(args):
    if arg == "--employee_id" and i + 1 < len(args):
        employee_id = args[i + 1]  # ✅ 正確
```

本章的 `check-balance.py` 已使用 v1.4.0+ 的格式。

---

## 方式二：Class-Based Skills（類別式技能）

**適用情境**：費用報銷需要計算核銷金額、判斷是否超過上限——這類邏輯用 C# 類別最清晰，也方便單元測試。

### ExpenseSkill 完整實作

```csharp
using System.ComponentModel;
using System.Text.Json;
using Microsoft.Agents.AI;

internal sealed class ExpenseSkill : AgentClassSkill<ExpenseSkill>
{
    public override AgentSkillFrontmatter Frontmatter { get; } = new(
        "expense-reimbursement",
        "Answer questions about expense reimbursement policy and calculate reimbursable amounts.");

    protected override string Instructions => """
        Use this skill when an employee asks about expense reimbursement.
        1. Read the expense-policy resource to understand limits and rules.
        2. Use the calculate script to compute the reimbursable amount.
        3. Clearly state whether the full amount is covered, or only the policy limit.
        """;

    // 屬性 → Resource（代理呼叫 read_skill_resource 時返回此屬性值）
    [AgentSkillResource("expense-policy")]
    [Description("費用報銷政策，含各類別上限與核銷規則。")]
    public string ExpensePolicy => """
        ## 費用報銷政策（2026）
        | 類別       | 每次上限（TWD） | 需要收據 |
        |------------|----------------|---------|
        | 交通       | 3,000          | 是      |
        | 餐費       | 800            | 是      |
        | 住宿       | 5,000          | 是      |
        | 辦公用品   | 2,000          | 否      |

        申請截止：費用發生後 30 天內。
        """;

    // 靜態方法 → Script（代理呼叫 run_skill_script 時執行）
    [AgentSkillScript("calculate")]
    [Description("計算核銷金額。若申請金額超過政策上限，回傳上限金額。")]
    private static string Calculate(string category, double amount)
    {
        var limits = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
        {
            ["交通"]     = 3000,
            ["餐費"]     = 800,
            ["住宿"]     = 5000,
            ["辦公用品"] = 2000,
        };

        double limit        = limits.TryGetValue(category, out var l) ? l : 0;
        double reimbursable = Math.Min(amount, limit);
        bool   capped       = amount > limit;

        return JsonSerializer.Serialize(new
        {
            category,
            requested    = amount,
            limit,
            reimbursable,
            capped,
        });
    }
}
```

**屬性說明：**

| 屬性 | 套用對象 | 說明 |
|------|---------|------|
| `[AgentSkillResource]` | 屬性或方法 | 標記為代理可讀取的資源 |
| `[AgentSkillScript]` | **僅**靜態方法 | 標記為代理可執行的腳本（不需外部 script runner） |
| `[Description]` | 兩者皆可 | 讓代理知道何時使用此資源或腳本 |

### 加入代理

```csharp
using Microsoft.Agents.AI;
using Azure.AI.OpenAI;
using Azure.Identity;

string endpoint       = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
string deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-4o-mini";

var skillsProvider = new AgentSkillsProvider(new ExpenseSkill());

AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        instructions: "你是 Contoso 公司的財務助理，協助員工辦理費用報銷。",
        options: new ChatClientAgentOptions
        {
            AIContextProviders = [skillsProvider],
        });

string response = await agent.RunAsync("我餐費花了 1200 元，可以全額報銷嗎？");
Console.WriteLine(response);
// 代理流程：Advertise expense-reimbursement → Load → Read expense-policy
//          → Run calculate("餐費", 1200)
// 預期回應：「餐費上限為 800 TWD，您可報銷 800 元，超出的 400 元需自行負擔。」
```

---

## 方式三：Inline Skills（內聯式技能）

**適用情境**：IT 設備庫存每天都在變動，需要每次查詢時動態取得最新資料。`AgentInlineSkill` 讓你在程式碼中直接定義技能，資源可以是靜態字串或動態 factory delegate。

### 靜態資源 vs. 動態資源

```csharp
using Microsoft.Agents.AI;

// 靜態資源：內容在建立時決定，之後不再改變
var policySkill = new AgentInlineSkill(
    name: "it-policy",
    description: "IT equipment request policies and approval process.",
    instructions: "Use this skill for questions about IT equipment request policies.")
    .AddResource(
        "request-process",
        """
        ## IT 設備申請流程
        1. 填寫申請表（it-helpdesk@contoso.com）
        2. 直屬主管簽核（3 個工作天）
        3. IT 部門審核與出貨（5–10 個工作天）
        """);

// 動態資源：每次代理呼叫 read_skill_resource 時執行 factory delegate
var itEquipmentSkill = new AgentInlineSkill(
    name: "it-equipment",
    description: "Check available IT equipment inventory and lead times.",
    instructions: """
        Use this skill when an employee asks about available IT equipment.
        1. Read the inventory resource to check current stock and lead times.
        2. Answer with item names, available quantities, and estimated delivery.
        """)
    .AddResource("inventory", () =>
    {
        // 每次讀取時重新計算（實際可改為呼叫資料庫或 REST API）
        return $"""
            ## 可申請設備庫存（截至 {DateTime.UtcNow:yyyy-MM-dd}）
            | 設備         | 庫存 | 到貨時間 |
            |--------------|------|---------|
            | 筆記型電腦   | 3    | 即時    |
            | 外接螢幕     | 8    | 即時    |
            | 機械鍵盤     | 0    | 2 週    |
            | 無線滑鼠     | 12   | 即時    |
            申請請寄信至 it-helpdesk@contoso.com
            """;
    });
```

**靜態 vs. 動態資源的選擇：**

| | 靜態資源 | 動態資源 |
|--|---------|---------|
| 內容 | 建立時固定 | 每次讀取時重新計算 |
| 適用 | 不常變動的規則、文件 | 庫存、天氣、使用者狀態 |
| 語法 | `.AddResource("name", "字串")` | `.AddResource("name", () => ...)` |

### 加入代理

```csharp
using Microsoft.Agents.AI;
using Azure.AI.OpenAI;
using Azure.Identity;

string endpoint       = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
string deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-4o-mini";

var skillsProvider = new AgentSkillsProvider(itEquipmentSkill);

AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        instructions: "你是 Contoso 公司的 IT 助理，協助員工申請設備。",
        options: new ChatClientAgentOptions
        {
            AIContextProviders = [skillsProvider],
        });

string response = await agent.RunAsync("現在有哪些筆電可以申請？");
Console.WriteLine(response);
// 代理會讀取 inventory 資源（factory 在此時執行），回傳即時庫存資訊
```

---

## 組合三種來源：AgentSkillsProviderBuilder

現實專案中，三種 Skill 通常同時使用。`AgentSkillsProviderBuilder` 可以把它們組合成一個 Provider：

```csharp
using Microsoft.Agents.AI;
using Azure.AI.OpenAI;
using Azure.Identity;

string endpoint       = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
string deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-4o-mini";

// 建立 Inline Skill
var itEquipmentSkill = new AgentInlineSkill(
    name: "it-equipment",
    description: "Check available IT equipment inventory and lead times.",
    instructions: "Read the inventory resource and answer equipment questions.")
    .AddResource("inventory", () => $"截至 {DateTime.UtcNow:yyyy-MM-dd} 的庫存：筆電 3 台、螢幕 8 台");

// 用 Builder 組合三種來源
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "skills"))  // hr-leave（File-Based）
    .UseSkill(new ExpenseSkill())                                    // 費用報銷（Class-Based）
    .UseSkill(itEquipmentSkill)                                      // IT 設備（Inline）
    .UseFileScriptRunner(SubprocessScriptRunner.RunAsync)            // file-based 腳本執行器
    .Build();

AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        instructions: "你是 Contoso 公司的員工自助助理，可以回答請假、報銷與 IT 設備相關問題。",
        options: new ChatClientAgentOptions
        {
            AIContextProviders = [skillsProvider],
        });

// 代理現在有三個技能，根據問題自動選擇
Console.WriteLine(await agent.RunAsync("請問報銷住宿 6000 元，可以全額核銷嗎？"));
Console.WriteLine(await agent.RunAsync("我有幾天年假？員工編號 E002"));
Console.WriteLine(await agent.RunAsync("現在有哪些設備可以申請？"));
```

### 技能過濾（`.UseFilter()`）

若技能來自共用技能庫，可用過濾器限制哪些技能對代理可見：

```csharp
var approvedSkills = new HashSet<string> { "hr-leave", "expense-reimbursement" };

var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "all-company-skills"))
    .UseFilter(skill => approvedSkills.Contains(skill.Frontmatter.Name))
    .Build();
```

這在多租戶場景很實用：同一份技能庫，依角色或部門開放不同子集。

---

## DI 整合

當 Skill 需要存取應用程式服務（資料庫、HTTP 客戶端、快取）時，可透過 `IServiceProvider` 注入。

### AgentClassSkill\<T\> 的 DI 注入

方法參數加上 `IServiceProvider` 型別，框架在執行時自動注入：

```csharp
using System.ComponentModel;
using System.Text.Json;
using Microsoft.Agents.AI;
using Microsoft.Extensions.DependencyInjection;

// 費率查詢服務（替換為你的實際服務類別）
public class ExchangeRateService
{
    public double GetTwdRate(string currency) =>
        currency.ToUpper() switch { "USD" => 32.5, "JPY" => 0.22, _ => 1.0 };
}

internal sealed class ExpenseSkillWithDI : AgentClassSkill<ExpenseSkillWithDI>
{
    public override AgentSkillFrontmatter Frontmatter { get; } = new(
        "expense-reimbursement-fx",
        "Calculate reimbursable amounts with live exchange rate conversion.");

    protected override string Instructions => """
        Use this skill for expense reimbursement questions involving foreign currency.
        1. Read the expense-policy resource.
        2. Use the calculate script, providing category, amount, and currency.
        """;

    [AgentSkillResource("expense-policy")]
    [Description("費用報銷政策（含外幣說明）")]
    public string ExpensePolicy => """
        ## 費用報銷政策（2026）
        | 類別     | 上限（TWD） |
        |----------|------------|
        | 交通     | 3,000      |
        | 餐費     | 800        |
        | 住宿     | 5,000      |
        | 辦公用品 | 2,000      |
        外幣費用依申請當日匯率換算為 TWD。
        """;

    // 方法參數加入 IServiceProvider → 框架自動注入，不需手動傳遞
    [AgentSkillScript("calculate")]
    [Description("計算核銷金額，支援外幣換算。參數：category（類別）、amount（金額）、currency（幣別，如 TWD/USD/JPY）")]
    private static string Calculate(
        string category,
        double amount,
        string currency,
        IServiceProvider serviceProvider)
    {
        var rateService  = serviceProvider.GetRequiredService<ExchangeRateService>();
        double amountTWD = amount * rateService.GetTwdRate(currency);

        var limits = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
        {
            ["交通"] = 3000, ["餐費"] = 800, ["住宿"] = 5000, ["辦公用品"] = 2000,
        };
        double limit        = limits.TryGetValue(category, out var l) ? l : 0;
        double reimbursable = Math.Min(amountTWD, limit);

        return JsonSerializer.Serialize(new
        {
            category, currency, originalAmount = amount,
            amountTWD = Math.Round(amountTWD, 0), limit, reimbursable,
            capped = amountTWD > limit,
        });
    }
}
```

### AgentInlineSkill 的 DI 注入

```csharp
// lambda 參數加入 IServiceProvider 即可（替換 InventoryDatabase 為你的實際服務）
var itSkillWithDI = new AgentInlineSkill(
    name: "it-equipment-live",
    description: "IT equipment inventory with real-time database lookup.",
    instructions: "Read the inventory resource and answer equipment questions.")
    .AddResource("inventory", (IServiceProvider sp) =>
    {
        // 範例：替換為你的實際資料庫服務
        // var db = sp.GetRequiredService<YourInventoryService>();
        // return db.GetCurrentInventoryMarkdown();
        return $"截至 {DateTime.UtcNow:yyyy-MM-dd} 的庫存（來自資料庫）";
    });
```

### 完整接線

```csharp
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Agents.AI;
using Azure.AI.OpenAI;
using Azure.Identity;

string endpoint       = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
string deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-4o-mini";

// 1. 服務注冊
var services = new ServiceCollection();
services.AddSingleton<ExchangeRateService>();
IServiceProvider serviceProvider = services.BuildServiceProvider();

// 2. 建立 Skills Provider
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseSkill(new ExpenseSkillWithDI())
    .Build();

// 3. 傳入代理（services 讓 Skill 方法可取得 IServiceProvider）
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        instructions: "你是 Contoso 公司的員工助理。",
        options: new ChatClientAgentOptions
        {
            AIContextProviders = [skillsProvider],
        },
        services: serviceProvider);  // ← 關鍵：傳入 IServiceProvider

string response = await agent.RunAsync("我出差花了 150 USD 的住宿費，可以報銷多少？");
Console.WriteLine(response);
```

---

## 進階選項：AgentSkillsProviderOptions

```csharp
var skillsProvider = new AgentSkillsProvider(
    skillPath: Path.Combine(AppContext.BaseDirectory, "skills"),
    options: new AgentSkillsProviderOptions
    {
        // v1.11.1 新增：腳本失敗時，是否把例外細節回傳給模型（讓它換參數重試）
        // 預設 false（例外向上傳遞，交由 FunctionInvokingChatClient 的政策處理）
        IncludeDetailedErrors = false,

        // 自訂注入 System Prompt 的格式（{skills} 佔位符為必要）
        SkillsInstructionPrompt = """
            你有以下技能可用：
            {skills}
            """,

        // v1.13.0 新增：per-tool 停用核可（預設皆 false = 需核可），詳見下一節
        DisableLoadSkillApproval = false,          // load_skill
        DisableReadSkillResourceApproval = false,  // read_skill_resource
        DisableRunSkillScriptApproval = false,     // run_skill_script
    });
```

> **SkillsInstructionPrompt 注意事項**：必須包含 `{skills}` 佔位符。若 prompt 字串本身含有大括號，需用 `{{` / `}}` 跳脫。
>
> **v1.11.1 Breaking（PR #6706）**：舊版的 `{resource_instructions}` 與 `{script_instructions}` 佔位符已移除。可用資源與腳本清單現在由框架自動輸出為 `available_resources` / `available_scripts` 區塊（v1.11.0 PR #6672 引入），不再需要在範本中手動放置佔位符。
>
> **⚠️ v1.12.0 Breaking（PR #6768）— `DisableCaching` 已移除**：舊版以 `AgentSkillsProviderOptions.DisableCaching = true` 停用技能快取。v1.12.0 起，快取邏輯自 `AgentSkillsProvider` **抽離為獨立的裝飾器 `CachingAgentSkillsSource`**（命名空間 `Microsoft.Agents.AI.Skills.Decorators`），`DisableCaching` 屬性**已移除**。快取現在改由 source 端以裝飾器模式組合——需要停用快取時，改為「不套用 `CachingAgentSkillsSource` 裝飾器」，而不是設定選項。一般使用 `AgentSkillsProvider(skillPath, ...)` 的預設路徑不受影響。

### 腳本執行預設需人工核可（v1.11.1 Breaking）

> **v1.11.1 Breaking（PR #6729）**：舊版以 `AgentSkillsProviderOptions.ScriptApproval = true` 屬性或 `AgentSkillsProviderBuilder.UseScriptApproval(true)` 方法「選擇性開啟」腳本審批。這兩個成員**已移除**。自 v1.11.1 起，`AgentSkillsProvider` 產出的所有工具（`load_skill`、`read_skill_resource`、`run_skill_script`）**一律預設需要核可**——框架會把它們包裝成 `ApprovalRequiredAIFunction`，無需任何 opt-in。

換言之，安全管控由「預設關閉、需手動開啟」變成「預設開啟、無法關閉」。核可流程沿用標準的 Human-in-the-Loop 機制（[第 16 章](./16-human-in-the-loop.md)）：代理執行技能工具前會先發出 `FunctionApprovalRequest`，由你的應用程式決定是否放行。

```csharp
// 不需要任何審批設定——load_skill / read_skill_resource / run_skill_script 預設皆需核可
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "skills"))
    .UseFileScriptRunner(SubprocessScriptRunner.RunAsync)
    .Build();

// 在 run loop 中處理核可請求（與 ch16 相同的 FunctionApprovalRequest 模式）
// 詳見第 16 章：Human-in-the-Loop
```

適用場景：技能腳本本就可能觸發真實副作用（傳送郵件、寫入資料庫、呼叫付款 API）。v1.11.1 把人工審閱定為**預設安全底線**，避免遺漏設定造成未授權執行。

### 細緻核可控制（v1.13.0 新增）

> **v1.13.0 增強（PR #6843）**：v1.11.1 的「全部工具一律需核可」是安全底線，但過於嚴格——例如唯讀的 `load_skill` / `read_skill_resource` 通常沒有副作用。v1.13.0 提供兩種放寬方式，讓你在保留安全性的同時減少不必要的核可提示。

**方式一：per-tool 停用核可**。`AgentSkillsProviderOptions` 新增三個開關，可個別停用某工具的核可（預設皆為 `false`，即維持需核可）：

```csharp
var skillsProvider = new AgentSkillsProvider(
    skillPath: Path.Combine(AppContext.BaseDirectory, "skills"),
    options: new AgentSkillsProviderOptions
    {
        // 唯讀工具免核可，只有真正執行腳本的 run_skill_script 才需人工放行
        DisableLoadSkillApproval = true,           // load_skill 免核可
        DisableReadSkillResourceApproval = true,   // read_skill_resource 免核可
        DisableRunSkillScriptApproval = false,     // run_skill_script 仍需核可（預設）
    });
```

**方式二：自動核可規則**。若想保留「所有工具都是需核可工具」的定義、但以規則在執行時自動放行，可套用 `AgentSkillsProvider` 的兩個靜態自動核可規則（與[第 16 章](./16-human-in-the-loop.md) `ToolApprovalAgent` 的自動核可機制同源）：

```csharp
// ReadOnlyToolsAutoApprovalRule：自動核可唯讀工具（load_skill、read_skill_resource），
// run_skill_script 仍會浮出核可請求
var rule = AgentSkillsProvider.ReadOnlyToolsAutoApprovalRule;

// AllToolsAutoApprovalRule：自動核可所有技能工具（等同關閉核可，僅在完全信任時使用）
// var rule = AgentSkillsProvider.AllToolsAutoApprovalRule;
```

> **`EnableNonApprovalRequiredFunctionBypassing`**：當同一回應中仍有其他需核可的工具、但你不希望某個已放行的技能工具被列為核可請求時，將 `ChatClientAgentOptions.EnableNonApprovalRequiredFunctionBypassing` 設為 `true`。

> **v1.13.0：Agent Skills API 轉正式（PR #6861）**：自 v1.13.0 起，`Microsoft.Agents.AI` 的 Agent Skills API（`AgentSkillsProvider`、`AgentSkillsProviderBuilder`、`AgentSkill` 等）**移除 `[Experimental]` 標記，正式轉為穩定 API**，使用技能不再需要抑制 experimental 診斷警告。同時，內建的 skills source 類別（`AgentInMemorySkillsSource`、`AggregatingAgentSkillsSource`、`FilteringAgentSkillsSource`、`DeduplicatingAgentSkillsSource`、`CachingAgentSkillsSource`）改為 public，可自訂組合；`AgentSkillsSource` 抽象基底改為實作 `IDisposable`，其 `GetSkillsAsync` 新增 `AgentSkillsSourceContext`（帶當前 `AIAgent` 與 `AgentSession`）參數（PR #6797/#6827/#6838）。這些變更僅影響**自訂 `AgentSkillsSource`** 的進階場景，本章的三種撰寫方式範例不受影響。

---

## v1.8.0 新增：MCP-based Skills（第四種來源）

除了前述 File-Based、Class-Based、Inline 三種來源，v1.8.0（PR [#6108](https://github.com/microsoft/agent-framework/pull/6108)）新增**第四種來源**：透過 MCP（Model Context Protocol）伺服器動態探索技能（`skill-md` 類型）。適合技能由外部 MCP 服務集中維護、多個應用共用的場景。

```csharp
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Mcp;          // UseMcpSkills 擴充方法
using ModelContextProtocol.Client;       // McpClient

// 連線到提供 Agent Skills 資源的 MCP 伺服器
McpClient mcpClient = /* 建立並連線你的 MCP client */;

// 透過 Builder 加入 MCP 技能來源（可與其他來源混用）
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseMcpSkills(mcpClient)                                         // ← MCP 來源（v1.8.0）
    .UseSkill(new ExpenseSkill())                                    // 仍可混用 Class-Based
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "skills"))  // 與 File-Based
    .Build();
```

對應型別（命名空間 `Microsoft.Agents.AI.Mcp.Skills`）：`AgentMcpSkill`、`AgentMcpSkillResource`、`AgentMcpSkillsSource`；`UseMcpSkills(this AgentSkillsProviderBuilder, McpClient)` 為擴充方法。

> MCP 整合的基礎概念見[第 25 章：MCP 整合](./25-mcp-integration.md)。

---

## 選擇指引：Skills vs. Tools vs. Workflows

| 問題 | 建議 |
|------|------|
| 需要呼叫外部 API 或執行一次性動作？ | **Tools**（ch05 `AIFunctionFactory`） |
| 需要把相關知識、腳本打包為可攜式、可重用套件？ | **Agent Skills**（本章） |
| 需要保證某些步驟按序執行，且可從中斷點恢復？ | **Workflows**（ch18–ch19） |

更詳細的比較：

| 面向 | Tools | Agent Skills | Workflows |
|------|-------|-------------|-----------|
| 知識封裝 | 無（邏輯散落在工具方法中） | 有（資源 + 腳本 + 指令一體） | 無 |
| 動態載入 | 一律注入（token 固定消耗） | 按需載入（節省 context） | 不適用 |
| 跨代理重用 | 需手動複製 | 可打包為 NuGet 套件或目錄 | 有限 |
| 失敗恢復 | 無 | 無（單一 turn） | Checkpointing 支援 |
| 副作用管控 | 自行實作 | 技能工具預設需核可（v1.11.1） | 明確定義每個步驟 |

---

## 小結

本章你學會了：

- Agent Skills 的**漸進式揭露**機制，以及它如何節省 context window token 用量
- **方式一 File-Based Skills**：`SKILL.md` 目錄格式、資源與腳本的組織方式
- **v1.4.0 Breaking Change**：file-based scripts 引數型別改為 `string[]`（`--key value` 旗標格式）
- **方式二 Class-Based Skills**：`AgentClassSkill<T>` 的泛型繼承、`[AgentSkillResource]` 與 `[AgentSkillScript]` 屬性
- **方式三 Inline Skills**：`AgentInlineSkill` 的靜態資源與動態 factory 資源
- **方式四 MCP-based Skills（v1.8.0 新增）**：以 `UseMcpSkills(mcpClient)` 從 MCP 伺服器探索技能
- `AgentSkillsProviderBuilder` 混合多種來源、`.UseFilter()` 技能過濾
- DI 整合：讓 Skill 方法透過 `IServiceProvider` 存取應用程式服務
- `AgentSkillsProviderOptions` 的進階選項（`SkillsInstructionPrompt`、`IncludeDetailedErrors`、以及 v1.13.0 的三個 `Disable*Approval` 核可開關）
- **v1.11.1 Breaking**：技能工具（`load_skill`/`read_skill_resource`/`run_skill_script`）預設一律需人工核可（`ScriptApproval`/`UseScriptApproval` 已移除）；`SkillsInstructionPrompt` 範本只需 `{skills}` 佔位符
- **v1.12.0 Breaking**：技能快取抽離為 `CachingAgentSkillsSource` 裝飾器，`AgentSkillsProviderOptions.DisableCaching` 已移除
- **v1.13.0**：Agent Skills API 移除 `[Experimental]` 正式轉穩定；新增細緻核可控制（per-tool `Disable*Approval` + `ReadOnlyToolsAutoApprovalRule`/`AllToolsAutoApprovalRule` 自動核可規則）

> **關於 ch05 延伸閱讀**：第 05 章的 Agent Skills 簡介現在有了完整的章節說明（本章），請以本章為主要參考。

---

### 延伸閱讀

- 針對 Skills 的測試策略 → [第 12 章：測試策略](./12-testing-strategy.md)
- 在 ASP.NET Core 服務中裝配 Skills → [第 11 章：ASP.NET Core 整合](./11-aspnetcore-webapi.md)
- 腳本執行搭配人工審批的完整流程 → [第 16 章：Human-in-the-Loop](./16-human-in-the-loop.md)
- ADR 0021 技能系統設計決策 → [附錄 D](./appendix-d-proposed-adrs.md#3-agent-skills-多來源架構adr-0021)

---
