# 07 — 範例實作：Travel Agent

> 本章透過官方的 Travel Agent 範例，展示如何將前幾章學到的概念（AIAgent、Tools、Streaming）整合成一個完整的應用。
>
> 對應官方範例：[Agent-Framework-Samples/00.ForBeginners/01-intro-to-ai-agents](https://github.com/microsoft/Agent-Framework-Samples/tree/main/00.ForBeginners/01-intro-to-ai-agents/code_samples/dotnet-agent-framework-travelagent)

---

## 範例情境

我們要建立一個**旅行規劃代理**，它能夠：

- 隨機推薦一個旅遊目的地
- 根據目的地規劃一日遊行程
- 支援串流回應，即時顯示規劃過程

這個範例雖然簡單，卻涵蓋了代理開發的核心流程：建立代理、定義工具、執行對話與串流。

---

## 範例架構

```mermaid
flowchart LR
    User["使用者"] -->|"Plan me a day trip"| Agent["TravelAgent"]
    Agent -->|"需要目的地"| Tool["GetRandomDestination()"]
    Tool -->|"Paris, France"| Agent
    Agent -->|"根據目的地規劃行程"| LLM["LLM\n(gpt-4o-mini)"]
    LLM -->|"一日遊行程"| User

    style Agent fill:#4A90D9,color:#fff,stroke:#2C5F8A
    style Tool fill:#D4EDDA,stroke:#28A745,color:#333
```

---

## 完整程式碼

### 專案建立

```bash
mkdir TravelAgent
cd TravelAgent
dotnet new console
dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.OpenAI
dotnet add package Microsoft.Extensions.AI
dotnet add package Microsoft.Extensions.AI.OpenAI
dotnet add package OpenAI
```

### Program.cs

```csharp
using System.ClientModel;
using System.ComponentModel;
using Microsoft.Extensions.AI;
using Microsoft.Agents.AI;
using OpenAI;

// ============================================================
// 設定 LLM 提供者
// ============================================================

// 以下提供三種選項，取消註解你要使用的那一種

// --- 選項 A：GitHub Models（免費入門）---
var endpoint = Environment.GetEnvironmentVariable("GITHUB_ENDPOINT")
    ?? "https://models.inference.ai.azure.com";
var modelId = Environment.GetEnvironmentVariable("GITHUB_MODEL_ID")
    ?? "gpt-4o-mini";
var token = Environment.GetEnvironmentVariable("GITHUB_TOKEN")
    ?? throw new InvalidOperationException("請設定 GITHUB_TOKEN 環境變數");

var openAIOptions = new OpenAIClientOptions()
{
    Endpoint = new Uri(endpoint)
};
var chatClient = new OpenAIClient(new ApiKeyCredential(token), openAIOptions)
    .GetChatClient(modelId);

// --- 選項 B：OpenAI ---
// var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY")
//     ?? throw new InvalidOperationException("請設定 OPENAI_API_KEY");
// var chatClient = new OpenAIClient(apiKey).GetChatClient("gpt-4o-mini");

// --- 選項 C：Azure OpenAI ---
// var chatClient = new Azure.AI.OpenAI.AzureOpenAIClient(
//     new Uri(Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!),
//     new Azure.Identity.AzureCliCredential())
//     .GetChatClient("gpt-4o-mini");

// ============================================================
// 建立 Travel Agent
// ============================================================

AIAgent agent = chatClient
    .AsIChatClient()
    .AsAIAgent(
        name: "TravelAgent",
        instructions: """
            你是一個樂於助人的旅行規劃 AI 助理。
            你可以幫客戶規劃隨機目的地的旅行行程。
            請用繁體中文回答，並提供具體的行程建議。
            """,
        tools: [AIFunctionFactory.Create(GetRandomDestination)]
    );

// ============================================================
// 執行代理：一般回應
// ============================================================

Console.WriteLine("=== 旅行規劃 ===\n");
var response = await agent.RunAsync("幫我規劃一趟一日遊");
Console.WriteLine(response.Text);

// ============================================================
// 執行代理：串流回應
// ============================================================

Console.WriteLine("\n=== 串流旅行規劃 ===\n");
await foreach (var update in agent.RunStreamingAsync("幫我規劃一趟一日遊"))
{
    Console.Write(update);
}
Console.WriteLine();

// ============================================================
// 工具定義：隨機目的地產生器
// ============================================================

[Description("提供一個隨機的度假目的地")]
static string GetRandomDestination()
{
    var destinations = new List<string>
    {
        "巴黎，法國",
        "東京，日本",
        "紐約，美國",
        "雪梨，澳洲",
        "羅馬，義大利",
        "巴塞隆納，西班牙",
        "開普敦，南非",
        "里約熱內盧，巴西",
        "曼谷，泰國",
        "溫哥華，加拿大"
    };

    var random = new Random();
    int index = random.Next(destinations.Count);
    return destinations[index];
}
```

---

## 程式碼解析

### 步驟 1：設定 LLM 提供者

範例使用 GitHub Models 作為 LLM 提供者（免費），透過 `OpenAIClient` 搭配自訂 Endpoint 來連接：

```csharp
var openAIOptions = new OpenAIClientOptions()
{
    Endpoint = new Uri(endpoint)  // GitHub Models 的 Endpoint
};
var chatClient = new OpenAIClient(new ApiKeyCredential(token), openAIOptions)
    .GetChatClient(modelId);
```

GitHub Models 使用 OpenAI 相容的 API，所以可以直接使用 `OpenAIClient`，只需要替換 Endpoint。

### 步驟 2：定義工具

`GetRandomDestination` 是一個簡單的靜態方法，用 `[Description]` 描述其功能：

```csharp
[Description("提供一個隨機的度假目的地")]
static string GetRandomDestination()
{
    // 從預定義清單中隨機選擇一個目的地
}
```

當使用者說「幫我規劃一趟旅行」時，LLM 會判斷需要先知道目的地，於是呼叫 `GetRandomDestination` 取得目的地，再根據結果規劃行程。

### 步驟 3：建立代理

透過 `AsAIAgent()` 將 ChatClient 包裝為代理，同時傳入工具：

```csharp
AIAgent agent = chatClient
    .AsIChatClient()        // 轉換為 IChatClient 介面
    .AsAIAgent(             // 包裝為 AIAgent
        name: "TravelAgent",
        instructions: "...",
        tools: [AIFunctionFactory.Create(GetRandomDestination)]
    );
```

注意 `.AsIChatClient()` 這個步驟，它將 OpenAI 的 ChatClient 轉換為框架的 `IChatClient` 介面。

### 步驟 4：執行與串流

範例展示了兩種執行方式：

```csharp
// 一般回應：等待完整回應後一次輸出
var response = await agent.RunAsync("幫我規劃一趟一日遊");

// 串流回應：逐段即時輸出
await foreach (var update in agent.RunStreamingAsync("幫我規劃一趟一日遊"))
{
    Console.Write(update);
}
```

---

## 執行結果範例

```text
=== 旅行規劃 ===

今天的隨機目的地是：東京，日本！以下是為你規劃的一日遊行程：

🌅 上午
- 08:00 前往淺草寺，體驗東京最古老的寺廟
- 09:30 在仲見世通商店街逛逛，品嘗人形燒和雷門烤餅

🏙️ 中午
- 12:00 到築地場外市場享用新鮮壽司午餐
- 13:30 散步到銀座逛逛精品街

🌆 下午
- 15:00 前往明治神宮，感受都市中的寧靜
- 16:30 到竹下通和表參道體驗潮流文化

🌃 晚上
- 18:00 前往東京鐵塔或晴空塔觀賞夕陽
- 19:30 在新宿歌舞伎町附近的居酒屋享用晚餐

祝你有個美好的一日遊！
```

---

## 延伸練習

### 練習 1：新增更多工具

試著新增天氣查詢和匯率轉換工具，讓旅行助理更實用：

```csharp
[Description("取得指定城市的天氣資訊")]
static string GetWeather([Description("城市名稱")] string city)
    => $"{city}：晴天，25°C，適合出遊";

[Description("將新台幣轉換為當地貨幣")]
static string ConvertCurrency(
    [Description("新台幣金額")] decimal amount,
    [Description("目標貨幣代碼")] string currency)
    => $"NT${amount:N0} ≈ {amount * 4.5m:N0} {currency}";

// 建立代理時加入所有工具
tools: [
    AIFunctionFactory.Create(GetRandomDestination),
    AIFunctionFactory.Create(GetWeather),
    AIFunctionFactory.Create(ConvertCurrency)
]
```

### 練習 2：加入多輪對話

使用 `AgentSession` 讓使用者可以追問細節：

```csharp
var session = await agent.CreateSessionAsync();

// 第一輪：規劃行程
var r1 = await agent.RunAsync("幫我規劃一趟一日遊", session);
Console.WriteLine(r1.Text);

// 第二輪：追問細節（代理記得目的地）
var r2 = await agent.RunAsync("午餐有沒有素食選項？", session);
Console.WriteLine(r2.Text);
```

### 練習 3：加入 Middleware 記錄工具呼叫

```csharp
var trackedClient = chatClient
    .AsIChatClient()
    .AsBuilder()
    .Use(async (funcCall, next, ct) =>
    {
        Console.WriteLine($"[工具呼叫] {funcCall.Function.Name}");
        var result = await next(funcCall, ct);
        Console.WriteLine($"[工具結果] {result}");
        return result;
    })
    .Build();
```

---

## 本章重點回顧

| 概念 | 在範例中的體現 |
|------|---------------|
| AIAgent | `chatClient.AsIChatClient().AsAIAgent(...)` |
| Tools | `AIFunctionFactory.Create(GetRandomDestination)` |
| Instructions | 定義代理是旅行規劃助理，指定回應語言 |
| RunAsync | 一般回應模式 |
| RunStreamingAsync | 串流回應模式 |
| LLM Provider | GitHub Models（OpenAI 相容 API） |

---

> **返回目錄**：[README](README.md) | **上一章**：[06 — Middleware 與 Context 基礎](./06-middleware-and-context.md) | **下一章**：[08 — 範例實作：RAG Search](./08-example-rag-search.md)
