# 附錄 D — 提案中的架構決策（Proposed ADRs）

> ⚠️ **重要提醒**：本附錄收錄的 ADR 狀態為 **Proposed**（提案中），表示 API 設計尚未最終確定，可能會在正式發布前發生變動。請將這些內容作為「方向預覽」參考，而非穩定 API 文件。

---

## 1. Agent Tools 統一抽象（ADR 0002）

> [完整文件](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0002-agent-tools.md) | Proposed, 2025-06-23

### 解決什麼問題

目前每個 LLM 提供者（OpenAI、Anthropic、Google、Amazon Bedrock）對工具的定義方式不盡相同。開發者在切換提供者時，需要重新實作工具整合。

### 提案方向

採用**混合式方法**（Hybrid Approach）：

1. **通用抽象**：在 `Microsoft.Extensions.AI.Abstractions` 中定義共用工具類型（code interpreter、web search、file search），繼承自 `AITool` 基底類別
2. **提供者專屬衍生**：各提供者套件中可定義 `AITool` 的子類別，處理獨有功能
3. **Fallback 機制**：`RawRepresentationFactory` 處理無法歸類的邊緣情況

```csharp
// ⚠️ 提案中的 API，可能變動

// 通用工具類型（跨提供者共用）
var codeInterpreter = new CodeInterpreterTool();
var webSearch = new WebSearchTool();

// 提供者專屬工具
var computerUse = new AnthropicComputerUseTool();

// 統一傳入代理
var agent = chatClient.AsAIAgent(
    tools: [codeInterpreter, webSearch, computerUse]
);
```

### 對教學的影響

若此 ADR 被接受，第 05 章（Tools 基礎）中的 `AIFunctionFactory.Create()` 模式仍有效，但會新增更多內建工具類型。

---

## 2. AgentRunContext — 執行期上下文存取（ADR 0015）

> [完整文件](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0015-agent-run-context.md) | Proposed, 2026-01-27

### 解決什麼問題

當代理以巢狀方式執行（例如一個代理作為另一個代理的工具被呼叫）時，內層代理無法存取外層的執行上下文（Session、RunOptions 等），除非透過繁瑣的參數傳遞。

### 提案方向

混合式設計：**明確參數 + AsyncLocal 環境存取**

```csharp
// ⚠️ 提案中的 API，可能變動

// AgentRunContext 包含四個唯讀屬性
public class AgentRunContext
{
    public AIAgent Agent { get; }         // 目前執行的代理
    public AgentSession Session { get; }  // 關聯的 Session
    public IList<ChatMessage> Messages { get; } // 請求訊息
    public AgentRunOptions Options { get; }     // 執行選項
}

// 在任何巢狀深度存取目前的執行上下文
var currentContext = AIAgent.CurrentRunContext;
if (currentContext is not null)
{
    Console.WriteLine($"目前代理：{currentContext.Agent.Name}");
    Console.WriteLine($"Session ID：{currentContext.Session.Id}");
}
```

### 核心機制

`AIAgent.CurrentRunContext` 使用 `AsyncLocal<AgentRunContext?>` 儲存，在每次 `RunAsync` 開始時設定、結束時清除。這讓深層的工具函式或 Middleware 可以直接存取上下文，無需層層傳遞參數。

### 對教學的影響

若此 ADR 被接受，第 06 章（Middleware）和第 14 章（Context Providers）中的 Middleware 可以透過 `AIAgent.CurrentRunContext` 更方便地存取 Session 資訊。

---

## 3. Agent Skills 多來源架構（ADR 0021）

> [完整文件](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0021-agent-skills-design.md) | **部分 Accepted**（v1.1.0 已實作類別式技能）, 2026-03-23

> 🆕 **v1.1.0 實作進度**（2026-04-10）：本 ADR 提案的**類別式技能**（Class-based Skill）已於 v1.1.0 實作完成：
>
> - PR [#5027](https://github.com/microsoft/agent-framework/pull/5027) — Skill as class
> - PR [#5183](https://github.com/microsoft/agent-framework/pull/5183) — Reflection-based resource / script discovery
> - PR [#5152](https://github.com/microsoft/agent-framework/pull/5152) — Custom types in skill resource/script functions
> - PR [#5078](https://github.com/microsoft/agent-framework/pull/5078) — Align skill folder discovery with spec
> - PR [#5205](https://github.com/microsoft/agent-framework/pull/5205) — Directory 術語統一
>
> **v1.1.0 三種技能定義方式均已 GA**：類別式（`AgentClassSkill<T>`）、內聯式（`AgentInlineSkill`）、檔案式（SKILL.md 目錄）。`AgentSkillsProviderBuilder` 可混合多種來源。**聚合 / 快取 / 去重來源**（`AggregatingAgentSkillsSource`、`CachingAgentSkillsSource`、`DeduplicatingAgentSkillsSource`）仍為 Proposed 狀態。

### 解決什麼問題

代理需要一個統一的 Skills 系統，支援從多種來源載入技能：檔案系統、程式碼內聯、類別庫，且需要可組合和快取。

### 提案方向

定義四個抽象基底類別：

| 類別 | 用途 |
|------|------|
| `AgentSkill` | 一個技能，包含 frontmatter、內容、資源、腳本 |
| `AgentSkillResource` | 技能的附加資源（透過 `ReadAsync()` 存取） |
| `AgentSkillScript` | 可執行的腳本（透過 `RunAsync()` 執行） |
| `AgentSkillsSource` | 技能來源（負責探索與載入技能集合） |

### 三種技能類別

```csharp
// ✅ v1.1.0 GA API

// 1. 檔案式技能：從 SKILL.md 目錄載入
var provider = new AgentSkillsProvider(
    Path.Combine(AppContext.BaseDirectory, "skills"),
    SubprocessScriptRunner.RunAsync);

// 2. 內聯式技能：在程式碼中以 AgentInlineSkill 定義
var inlineSkill = new AgentInlineSkill(
    name: "greeting",
    description: "友善的問候技能",
    instructions: "使用此技能回答問候相關問題。")
    .AddResource("templates", () => "Hello {name}!")
    .AddScript("greet", (string name) => $"你好，{name}！");

// 3. 類別式技能：繼承 AgentClassSkill<T>（泛型）
public class MyCustomSkill : AgentClassSkill<MyCustomSkill> { /* ... */ }

// 混合多種來源
var provider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "skills"))
    .UseSkill(inlineSkill)
    .UseSkill(new MyCustomSkill())
    .Build();
```

### 組合式來源

```csharp
// ⚠️ 提案中的 API，可能變動

// 聚合多個來源
var combinedSource = new AggregatingAgentSkillsSource(
    new AgentFileSkillsSource("/skills"),
    new AgentInMemorySkillsSource(inlineSkill));

// 加入快取和去重
var cachedSource = new CachingAgentSkillsSource(
    new DeduplicatingAgentSkillsSource(combinedSource));
```

### 對教學的影響

三種技能定義方式（類別式、內聯式、檔案式）與 `AgentSkillsProviderBuilder` 均已於 v1.1.0 GA，建議新增獨立章節完整說明。聚合 / 快取 / 去重來源仍待正式實作。

> **📖 完整教學**：三種 Skill 定義方式、`AgentSkillsProviderBuilder`、DI 整合與 `AgentSkillsProviderOptions` 的完整說明，請見 **[第 29 章：Agent Skills 可攜式技能套件](./29-agent-skills.md)**。

---

## 4. Provider-Leading Clients 與套件拆分（ADR 0021b）

> [完整文件](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0021-provider-leading-clients.md) | Accepted, 2026-03-20

### 解決什麼問題

OpenAI 相關的實作目前放在核心套件中，造成不必要的相依。同時，類別命名不夠直觀（`OpenAIResponsesClient` vs `OpenAIChatClient` 容易混淆）。

### 決策結果

1. **套件拆分**：新增獨立的 `agent-framework-openai` 套件
2. **類別重命名**：

| 舊名稱 | 新名稱 | 說明 |
|--------|--------|------|
| `OpenAIResponsesClient` | `OpenAIChatClient` | 主要推薦使用 |
| `OpenAIChatClient`（舊） | `OpenAIChatCompletionClient` | 舊版 Chat Completions API |

3. **統一 `model` 參數**：所有 Client 建構子統一使用 `model` 參數名（取代 `model_id`、`deployment_name` 等變體）

### 對教學的影響

第 02 章（核心概念）的 LLM 提供者表格和第 04 章（第一個代理）的套件安裝指引可能需要微調。目前舊名稱會保留為 `[Obsolete]` 別名，短期內不影響。

---

## 5. CodeAct Integration（ADR 0024）

> [完整文件](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0024-codeact-integration.md) | **🆕 GA — v1.4.0（2026-05-05）**

> 🆕 **v1.4.0 GA**：此功能已以 `Microsoft.Agents.AI.Hyperlight` 套件正式發布（PR #5329），不再是 Proposed 狀態。

### 解決什麼問題

傳統 function-call 模式中，LLM 每個步驟都需要一次 round-trip；複雜的多步驟計算需要多輪 LLM 呼叫，耗時且 token 消耗高。CodeAct 讓 LLM **生成可執行程式碼**來協調工具呼叫，整段邏輯在一次執行中完成。

### 決策結果

以獨立套件 `Microsoft.Agents.AI.Hyperlight` 發布，不影響 core。框架提供 `execute_code` 工具，LLM 生成的程式碼在 **Hyperlight 沙盒**中隔離執行，並可透過 `call_tool(...)` 呼叫已配置的工具。

```bash
dotnet add package Microsoft.Agents.AI.Hyperlight
```

```csharp
// ✅ v1.4.0 GA API
using Microsoft.Agents.AI.Hyperlight;

var codeActProvider = new HyperlightCodeActProvider(options =>
{
    options.AllowedTools = [searchTool, calculatorTool];
});

AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    AIContextProviders = [codeActProvider],
});

// 呼叫方式與一般 agent 相同
var response = await agent.RunAsync("計算這組資料的統計摘要並篩選前10筆");
```

### CodeAct vs. 一般 Tool Calling

| | 一般 Tool Calling | CodeAct |
|---|---|---|
| LLM 輸出 | JSON 結構 | 可執行程式碼 |
| 執行環境 | 主程序（in-process） | Hyperlight 沙盒（隔離） |
| 多步邏輯 | 多輪 LLM 呼叫 | 單次沙盒執行 |
| Token 消耗 | 較高（多輪） | 較低（單輪） |

### 對教學的影響

CodeAct 已 GA，可作為進階工具整合的替代方案。若計畫長期使用，建議在第 05 章（Tools 基礎）延伸閱讀段落補充 `Microsoft.Agents.AI.Hyperlight` 的安裝與基本使用說明。

---

## 6. FIDES Prompt Injection 防禦（ADR 0024b）

> [完整文件](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0024-prompt-injection-defense.md) | Proposed, 2026-01-14（contact: shruti）

> ⚠️ **重要提醒**：此 ADR 狀態為 **Proposed**，API 設計尚未最終確定，請作為方向預覽參考。

### 解決什麼問題

AI 代理容易受到 **Prompt Injection 攻擊**：惡意指令嵌入在外部 API 回應、使用者輸入等不信任內容中，操控代理行為。傳統的 Prompt Engineering 防禦方式（如「忽略以下指令」）是啟發式的，無法提供可驗證的安全保證。

### 提案方向

**FIDES**（Flow Integrity Deterministic Enforcement System）採用**資訊流控制（Information-Flow Control）**理論，透過標籤系統提供確定性安全保證：

```csharp
// ⚠️ 提案中的 API，可能變動

// 一行啟用安全代理（SecureAgentConfig）
var agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Middleware = SecureAgentConfig.DefaultMiddleware()
    // 未標記的外部內容預設視為 UNTRUSTED
});
```

#### 四個核心元件

| 元件 | 說明 |
|------|------|
| `IntegrityLabel`（TRUSTED/UNTRUSTED） | 標記內容的信任程度 |
| `LabelTrackingFunctionMiddleware` | 自動傳播標籤至衍生內容 |
| `PolicyEnforcementFunctionMiddleware` | 工具執行前檢查標籤政策 |
| `ContentVariableStore` + `VariableReferenceContent` | 將不信任內容與 LLM context 物理隔離 |

標籤組合採用**最嚴格優先（most-restrictive-wins）**：TRUSTED + UNTRUSTED → UNTRUSTED。

### 對教學的影響

FIDES 完全 opt-in，現有代理不受影響。若未來 GA，可在第 16 章（Human-in-the-Loop）或新增安全章節中介紹 `SecureAgentConfig.DefaultMiddleware()` 的啟用方式。

---

## 總結對照表

| ADR | 主題 | 狀態 | 影響範圍 | 預計可用版本 |
|-----|------|------|---------|-------------|
| 0002 | Tools 統一抽象 | Proposed | 第 05 章 | 未定 |
| 0015 | AgentRunContext | Proposed | 第 06、14 章 | 未定 |
| 0021 | Agent Skills | **部分 Accepted** | 新功能 | v1.1.0（類別式已釋出） |
| 0021b | Provider Clients 重命名 | Accepted | 第 02、04 章 | 近期 |
| 0024 | CodeAct Integration | **🆕 GA（v1.4.0）** | 進階 / 附錄 | v1.4.0（`Microsoft.Agents.AI.Hyperlight`） |
| 0024b | FIDES Prompt Injection 防禦 | Proposed | 安全性（未來章節） | 未定 |

> 🆕 **ADR 0024 已於 v1.4.0 GA**：`Microsoft.Agents.AI.Hyperlight` 套件正式發布，CodeAct .NET 整合現已可用。LLM 生成可執行程式碼，在 Hyperlight 沙盒中隔離執行。詳見 `wiki/concepts/codeact-integration.md`。

> 💡 **建議**：在正式版發布前，以本教學中已確定的 API（`AIFunctionFactory.Create()`、`AsAIAgent()`、`CreateSessionAsync()` 等）為主。上述提案內容可作為後續追蹤的方向參考。

---

> **返回目錄**：[README](README.md) | **上一篇**：[附錄 C — 學習資源與社群連結](./appendix-c-resources.md) | **下一篇**：[附錄 E — SDK 入門範例解析](./appendix-e-sdk-samples-get-started.md)
