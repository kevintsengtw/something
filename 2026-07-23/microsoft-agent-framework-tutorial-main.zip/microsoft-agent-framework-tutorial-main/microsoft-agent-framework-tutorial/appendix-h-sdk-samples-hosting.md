# 附錄 H — SDK 代理主機整合（dotnet/samples/04-hosting）

> 來源：[microsoft/agent-framework — dotnet/samples/04-hosting](https://github.com/microsoft/agent-framework/tree/main/dotnet/samples/04-hosting)
> 版本基準：v1.6.1

`04-hosting` 提供三個代理/工作流程持久化部署的完整範例，展示如何將代理從開發模式提升至生產等級的主機環境。

---

## 目錄結構

```text
04-hosting/
├── DurableAgents/
│   ├── AzureFunctions/    ← 生產部署：Azure Functions + Durable Task
│   └── ConsoleApps/       ← 開發測試：Console App 本地 Emulator
├── DurableWorkflows/      ← 工作流程持久化主機
└── FoundryHostedAgents/   ← Foundry 雲端主機
```

---

## DurableAgents — 持久化代理主機

> 對應教學：[第 20 章](./20-durable-agents-concepts.md)、[第 21 章](./21-durable-agents-implementation.md)

Durable Agents 讓代理對話能在 Process 重啟、橫向擴展後繼續進行。基於 Azure Durable Task Framework，每個 `AgentSession` 以 Durable Entity 形式持久化。

### AzureFunctions — 生產部署

**目的**：將代理部署為 Azure Functions，自動產生 REST API 端點，支援橫向擴展與 TTL 自動清理。

```csharp
// Program.cs（精簡版）
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Hosting.AzureFunctions;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Hosting;

// 建立代理（標準方式）
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient("gpt-5.4-mini")
    .AsAIAgent(instructions: "You are a helpful assistant.", name: "HostedAgent");

// 配置 Azure Functions 主機
using IHost app = FunctionsApplication.CreateBuilder(args)
    .ConfigureFunctionsWebApplication()
    .ConfigureDurableAgents(options =>
        options.AddAIAgent(agent, timeToLive: TimeSpan.FromHours(1)))
    .Build();

app.Run();
```

**NuGet 套件**：

```bash
dotnet add package Microsoft.Agents.AI.Hosting.AzureFunctions
```

**自動產生的 HTTP API**：

| 方法 | 路徑 | 說明 |
|------|------|------|
| POST | `/api/agents/{name}/run` | 建立新 Session 並執行一輪 |
| POST | `/api/agents/{name}/sessions/{id}/run` | 在現有 Session 繼續對話 |
| GET | `/api/agents/{name}/sessions/{id}` | 查詢 Session 狀態 |
| DELETE | `/api/agents/{name}/sessions/{id}` | 手動刪除 Session |

**調用範例**（使用 curl）：

```bash
# 建立新對話 Session 並傳送訊息
curl -X POST http://localhost:7071/api/agents/HostedAgent/run \
  -H "Content-Type: application/json" \
  -d '{"message": "你好！"}'
# 回應含 sessionId 與代理回應

# 繼續對話（使用同一個 sessionId）
curl -X POST http://localhost:7071/api/agents/HostedAgent/sessions/{sessionId}/run \
  -H "Content-Type: application/json" \
  -d '{"message": "請問剛才你說了什麼？"}'
```

**本地開發**：

```bash
# 需要 Azure Functions Core Tools
npm install -g azure-functions-core-tools@4

# 設定環境變數
cp local.settings.json.template local.settings.json
# 編輯 local.settings.json 填入 AZURE_OPENAI_ENDPOINT 等

# 啟動
func start
```

**TimeToLive 策略**：

| 場景 | 建議 TTL |
|------|---------|
| 客服 Bot（一次性對話） | `TimeSpan.FromHours(1)` |
| 個人助理（需要長期記憶） | `TimeSpan.FromDays(30)` |
| 合規稽核代理 | `null`（永不自動刪除） |
| 任務代理（任務完成後清理） | `TimeSpan.FromMinutes(30)` |

---

### ConsoleApps — 本地 Emulator 開發測試

**目的**：在 Console App 中使用本地 Durable Task Emulator 測試 Durable Agent 行為，無需部署到 Azure。

```csharp
using Microsoft.Agents.AI;
using Microsoft.DurableTask.Client;

// 使用本地 Emulator（開發/測試用）
await using var host = DurableTaskScheduler.CreateEmulatorBuilder()
    .ConfigureServices(services =>
    {
        services.ConfigureDurableAgents(options =>
        {
            options.AddAIAgent(
                chatClient.AsAIAgent(instructions: "...", name: "TestAgent"),
                timeToLive: TimeSpan.FromMinutes(5));
        });
    })
    .Build();

await host.StartAsync();

// 直接呼叫（與 Azure Functions 行為一致）
var client = host.Services.GetRequiredService<IDurableAgentClient>();
var sessionId = await client.StartSessionAsync("TestAgent");
var response = await client.RunAsync("TestAgent", sessionId, "你好！");
Console.WriteLine(response);

await host.StopAsync();
```

**本地 Emulator vs Azure Functions**：

| 面向 | 本地 Emulator | Azure Functions |
|------|-------------|----------------|
| 用途 | 開發 / 單元測試 | 生產部署 |
| 持久化 | 記憶體（重啟後消失） | Azure Storage / CosmosDB |
| 擴展性 | 單一 Process | 自動橫向擴展 |
| 設定難度 | 零配置 | 需要 Azure 資源 |

---

## DurableWorkflows — 持久化工作流程主機

**目的**：讓工作流程可以跨越 Process 重啟繼續執行，適合需要數小時乃至數天才能完成的工作流程。

```csharp
// 設定工作流程持久化主機
await using var host = DurableTaskScheduler.CreateEmulatorBuilder()
    .ConfigureWorkflows(workflows =>
    {
        workflows.AddWorkflow(myWorkflow);
    })
    .Build();

await host.StartAsync();

// 啟動工作流程
var client = host.Services.GetRequiredService<IDurableWorkflowClient>();
var runId = await client.StartWorkflowAsync("MyWorkflow", input: "Hello");

// 查詢狀態（可在 Process 重啟後繼續查詢）
var status = await client.GetStatusAsync(runId);
Console.WriteLine($"Status: {status.State}");
```

**Checkpoint 機制**：每個 Executor 完成後自動 Checkpoint，即使在 Executor 執行中間 Process 崩潰，也能從上一個 Checkpoint 恢復（不從頭重執行）。

---

## FoundryHostedAgents — Foundry 雲端主機

**目的**：在 Microsoft Azure AI Foundry 服務上部署代理，使用 Foundry 提供的持久化儲存、向量資料庫、Code Interpreter 等企業功能。

```csharp
// Foundry 雲端代理（無需管理本地 Session）
FoundryAgent agent = new AIProjectClient(new Uri(foundryEndpoint), new DefaultAzureCredential())
    .AsAIAgent(
        model: "gpt-5.4-mini",
        instructions: "你是企業知識庫助理。",
        name: "KnowledgeBaseAgent");

// Foundry 管理所有 Session 持久化
var session = await agent.CreateSessionAsync();
Console.WriteLine(await agent.RunAsync("請查詢公司差旅政策", session));
```

**Foundry 托管代理的優勢**：
- Session 持久化由 Foundry 管理（不需要 Azure Durable Task）
- 可直接使用 Foundry 的 File Search、Code Interpreter 等原生工具
- 與 Azure AI Studio 的 Playground 互通

**DurableAgents vs FoundryHostedAgents**：

| 面向 | DurableAgents | FoundryHostedAgents |
|------|-------------|-------------------|
| 代理型別 | 任意 `AIAgent` | `FoundryAgent` |
| 持久化層 | Azure Durable Task | Azure AI Foundry |
| 原生工具 | 無（自行整合） | File Search、Code Interpreter 等 |
| 計費 | Function App + Storage | Foundry 按用量計費 |
| 適合 | 自定義業務邏輯 | 需要 Foundry 原生工具 |

---

## 完整部署決策流程

```text
代理需要持久化 Session？
├─ 否 → 使用一般 AIAgent，不需要 04-hosting 的功能
└─ 是 → 需要 Foundry 原生工具（File Search / Code Interpreter）？
          ├─ 是 → FoundryHostedAgents
          └─ 否 → 需要自定義工具 + 業務邏輯？
                    ├─ 是 → DurableAgents
                    │        ├─ 生產環境 → AzureFunctions
                    │        └─ 開發測試 → ConsoleApps（Emulator）
                    └─ 否（純工作流程） → DurableWorkflows
```

---

> **返回目錄**：[README](README.md) | **上一篇**：[附錄 G — SDK 工作流程範例](./appendix-g-sdk-samples-workflows.md) | **下一篇**：[附錄 I — SDK 端對端整合範例](./appendix-i-sdk-samples-end-to-end.md)
