# 27 — Feature Collections（功能集合）

> 本章介紹 Agent Framework 的 Feature Collections 機制。這是一個型別安全的擴展點，讓你在代理執行時傳遞任意服務和設定資料，而不需要在編譯時知道所有可能的擴展。
>
> 對應官方決策：[ADR 0014 — Feature Collections](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0014-feature-collections.md)（Accepted, 2025-01-21）

---

## 為什麼需要 Feature Collections

在開發代理應用時，你經常會遇到這類需求：

- **協定層需要注入自訂儲存**：A2A 或 AG-UI 託管時，需要替換預設的對話歷史儲存方式
- **特定執行需要特殊設定**：某次 `RunAsync` 需要啟用結構化輸出，但其他執行不需要
- **Middleware 需要傳遞狀態**：Decorator stack 中的各層需要共享某些 per-run 資訊

如果用 `Dictionary<string, object>` 的方式來傳遞這些資訊，你會失去型別安全；如果每個需求都加新參數到 `RunAsync`，API 表面會膨脹。Feature Collections 提供了兩全其美的方案。

---

## 核心概念

Feature Collections 的設計靈感來自 ASP.NET Core 的 `IFeatureCollection`。如果你熟悉 `HttpContext.Features`，Agent Framework 的 Feature Collections 遵循相同模式。

### 在 AgentRunOptions 上的 Features 屬性

```csharp
public class AgentRunOptions
{
    // ... 其他屬性 ...

    /// <summary>
    /// 型別鍵值的功能集合，用於傳遞 per-run 的服務和設定。
    /// </summary>
    public IFeatureCollection Features { get; } = new FeatureCollection();
}
```

### 基本操作：Set 與 TryGet

```csharp
var options = new AgentRunOptions();

// 設定功能
options.Features.Set<IChatMessageStore>(myCustomStore);

// 取得功能
if (options.Features.TryGet<IChatMessageStore>(out var store))
{
    Console.WriteLine($"使用自訂儲存：{store.GetType().Name}");
}
```

---

## 使用場景一：Per-Run 服務覆寫

最常見的場景是在特定執行中覆寫預設的服務。例如，A2A 協定的 Hosting 層需要使用 conversation-ID 作為對話歷史的 key：

```csharp
// A2A Hosting 層在收到請求時
var options = new AgentRunOptions();

// 注入基於 conversation-ID 的對話歷史儲存
options.Features.Set<IChatMessageStore>(
    new ConversationIdBasedStore(conversationId));

// 代理執行時會自動使用這個覆寫的儲存
var response = await agent.RunAsync(message, session, options);
```

在代理或 Middleware 內部取用：

```csharp
public class MyMiddleware : IAgentMiddleware
{
    public async Task InvokeAsync(
        AgentMiddlewareContext context,
        AgentMiddlewareDelegate next)
    {
        // 從 Features 中取得自訂儲存（如果有的話）
        if (context.RunOptions.Features.TryGet<IChatMessageStore>(out var store))
        {
            // 使用自訂儲存
            await store.SaveAsync(context.Input);
        }

        await next(context);
    }
}
```

---

## 使用場景二：可選功能的漸進式揭露

不是所有代理都支援結構化輸出。Feature Collections 讓支援的代理可以在運行時查詢：

```csharp
// 呼叫端設定「我需要結構化輸出」
var options = new AgentRunOptions();
options.Features.Set<IStructuredOutputFeature>(
    new StructuredOutputFeature<TravelPlan>());

var response = await agent.RunAsync(message, session, options);

// 代理實作內部
protected override async Task RunCoreAsync(...)
{
    if (runOptions.Features.TryGet<IStructuredOutputFeature>(out var soFeature))
    {
        // 啟用結構化輸出模式
        chatOptions.ResponseFormat = soFeature.CreateResponseFormat();
    }
    // 繼續正常處理
}
```

---

## 使用場景三：Decorator Stack 狀態傳遞

當代理被多層 Decorator 包裝時（例如 OpenTelemetry + 日誌 + 認證），外層可以透過 Features 傳遞狀態給內層：

```csharp
// Tracing Decorator 設定追蹤 ID（注意：勿與 SDK 內建的 OpenTelemetryAgent 同名）
public class TracingAgent : AIAgent
{
    protected override async Task RunCoreAsync(...)
    {
        var activity = ActivitySource.StartActivity("agent.run");
        runOptions.Features.Set<Activity>(activity);

        try
        {
            await _inner.RunAsync(messages, session, runOptions);
        }
        finally
        {
            activity?.Dispose();
        }
    }
}

// 內層的 Logging Middleware 可以取得追蹤 ID
if (context.RunOptions.Features.TryGet<Activity>(out var activity))
{
    logger.LogInformation("TraceId: {TraceId}", activity.TraceId);
}
```

---

## Feature Collections vs 其他擴展機制

| 機制 | 型別安全 | 可變性 | 生命週期 | 適用場景 |
|------|---------|--------|----------|----------|
| **Feature Collections** | ✅ 強型別 | ✅ 可在 Stack 中修改 | Per-Run | 服務覆寫、可選功能、Stack 狀態 |
| **AdditionalProperties** | ❌ `object` 型別 | ✅ 可修改 | Per-Agent / Per-Session | 描述性 metadata、序列化屬性 |
| **IServiceProvider (DI)** | ✅ 強型別 | ❌ 不可變 | Application 層級 | 全域共用服務 |
| **AgentRunOptions 屬性** | ✅ 強型別 | ✅ 可修改 | Per-Run | 框架內建的標準選項 |

### 何時用哪一個

- 需要 per-run 且型別安全？ → **Feature Collections**
- 需要持久化 / 序列化？ → **AdditionalProperties**
- 全域共用的服務？ → **DI / IServiceProvider**
- 框架已定義的標準選項？ → **AgentRunOptions 的具名屬性**

---

## 自訂 Feature 的最佳實踐

### 定義 Feature 介面

```csharp
/// <summary>
/// 自訂的多租戶 Feature，讓代理知道目前是哪個租戶的請求。
/// </summary>
public interface ITenantFeature
{
    string TenantId { get; }
    string TenantName { get; }
    TenantTier Tier { get; } // Free, Pro, Enterprise
}

public record TenantFeature(
    string TenantId,
    string TenantName,
    TenantTier Tier) : ITenantFeature;
```

### 使用擴充方法簡化存取

```csharp
public static class FeatureCollectionExtensions
{
    public static ITenantFeature? GetTenant(this IFeatureCollection features)
        => features.TryGet<ITenantFeature>(out var tenant) ? tenant : null;

    public static void SetTenant(
        this IFeatureCollection features,
        string tenantId,
        string tenantName,
        TenantTier tier)
        => features.Set<ITenantFeature>(
            new TenantFeature(tenantId, tenantName, tier));
}

// 使用
options.Features.SetTenant("t-001", "Contoso", TenantTier.Enterprise);
var tenant = options.Features.GetTenant();
```

---

## 小結

Feature Collections 是 Agent Framework 的進階擴展機制：

1. **型別安全**：使用泛型 `Set<T>` / `TryGet<T>`，無需強制轉型
2. **Per-Run 生命週期**：每次 `RunAsync` 的 Features 互不干擾
3. **Stack 可變**：Decorator 可以新增或修改 Features 後傳遞給內層
4. **漸進式揭露**：不支援的功能優雅降級，不影響基本使用

### 延伸閱讀：官方 ADR 參考

- [ADR 0014 — Feature Collections](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0014-feature-collections.md)：完整設計決策，與 ASP.NET Core `IFeatureCollection` 的對比，型別安全 vs `IServiceProvider` 的取捨

---

> **返回目錄**：[README](README.md) | **上一章**：[26 — Long-Running Operations](./26-long-running-operations.md) | **下一章**：[28 — Agent Evaluation](./28-agent-evaluation.md)
