# 12 — 測試策略：單元測試與整合測試

> 本章介紹如何為 Microsoft Agent Framework 應用程式建立完整的測試策略，涵蓋工具方法的單元測試、Middleware 的單元測試、Mock ChatClient 測試代理行為，以及透過 `WebApplicationFactory` 進行端對端整合測試。

---

## 測試金字塔在 Agent 應用中的應用

傳統的測試金字塔在 Agent 應用中依然適用，但各層的測試對象有所不同：

```text
        ┌─────────────────┐
        │  端對端測試 E2E  │  ← 真實 LLM + 真實 API（費用高，執行慢）
        │    （少量）      │
       ┌┴─────────────────┴┐
       │   整合測試         │  ← WebApplicationFactory + Mock LLM
       │  （適量）          │
      ┌┴───────────────────┴┐
      │      單元測試        │  ← 工具方法、Middleware、純商業邏輯
      │    （大量）          │
      └─────────────────────┘
```

| 測試層級 | 測試對象 | 是否需要真實 LLM | 執行速度 |
|----------|----------|-----------------|----------|
| **單元測試** | 工具方法、Middleware、商業邏輯 | 否（Mock） | 極快 |
| **整合測試** | Web API 端點、Agent 流程 | 否（Mock ChatClient） | 快 |
| **E2E 測試** | 完整對話流程 | 是 | 慢（需費用） |

本章重點放在**單元測試**與**整合測試**。

---

## 測試專案建立

```bash
# 在解決方案根目錄
dotnet new xunit -n MyAgentApi.Tests
cd MyAgentApi.Tests

# 加入專案參考
dotnet add reference ../MyAgentApi/MyAgentApi.csproj

# 加入測試套件
dotnet add package Moq
dotnet add package FluentAssertions
dotnet add package Microsoft.AspNetCore.Mvc.Testing
# Microsoft.Extensions.AI.Testing 不存在，Mock IChatClient 請用 Moq（已列於上方）
```

### 測試專案結構

```text
MyAgentApi.Tests/
├── Unit/
│   ├── Tools/
│   │   └── CustomerSupportToolsTests.cs    ← 工具方法單元測試
│   ├── Middleware/
│   │   └── RequestLoggingMiddlewareTests.cs
│   └── Agents/
│       └── AgentBehaviorTests.cs           ← Mock ChatClient 測試
├── Integration/
│   ├── AgentApiTests.cs                    ← Web API 整合測試
│   └── Fixtures/
│       └── AgentApiFactory.cs              ← WebApplicationFactory
└── Helpers/
    └── MockChatClientBuilder.cs            ← 共用 Mock 工具
```

---

## 單元測試：工具方法

工具方法是純 C# 函式，最容易測試——不需要任何 Mock，直接呼叫即可。

### 範例：測試 GetOrderStatus

```csharp
// Unit/Tools/CustomerSupportToolsTests.cs
using FluentAssertions;
using Xunit;

public class CustomerSupportToolsTests
{
    [Theory]
    [InlineData("ORD-001234", "已出貨")]
    [InlineData("ORD-001235", "處理中")]
    public void GetOrderStatus_KnownOrder_ReturnsCorrectStatus(
        string orderId, string expectedKeyword)
    {
        // Act
        var result = CustomerSupportTools.GetOrderStatus(orderId);

        // Assert
        result.Should().Contain(expectedKeyword);
    }

    [Fact]
    public void GetOrderStatus_UnknownOrder_ReturnsNotFoundMessage()
    {
        // Arrange
        var unknownOrderId = "ORD-999999";

        // Act
        var result = CustomerSupportTools.GetOrderStatus(unknownOrderId);

        // Assert
        result.Should().Contain(unknownOrderId)
              .And.Contain("找不到訂單");
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData(null)]
    public void GetOrderStatus_InvalidInput_ReturnsErrorMessage(string? orderId)
    {
        // Act
        var act = () => CustomerSupportTools.GetOrderStatus(orderId!);

        // Assert - 根據你的實作決定是拋例外還是回傳錯誤訊息
        act.Should().NotThrow();
    }
}
```

> **建議**：將工具方法提取為 `static` 方法並放到獨立類別（如 `CustomerSupportTools`），方便獨立測試，也方便在多個代理之間共用。

---

## 單元測試：Middleware

Middleware 測試的核心是驗證「前置/後置邏輯是否正確執行」，以及「`next` 是否被正確呼叫」。

```csharp
// Unit/Middleware/RequestLoggingMiddlewareTests.cs
using Microsoft.Agents.AI;
using Microsoft.Extensions.Logging;
using Moq;
using FluentAssertions;
using Xunit;

public class RequestLoggingMiddlewareTests
{
    private readonly Mock<ILogger<RequestLoggingMiddleware>> _loggerMock;
    private readonly RequestLoggingMiddleware _middleware;

    public RequestLoggingMiddlewareTests()
    {
        _loggerMock = new Mock<ILogger<RequestLoggingMiddleware>>();
        _middleware = new RequestLoggingMiddleware(_loggerMock.Object);
    }

    [Fact]
    public async Task InvokeAsync_NormalFlow_CallsNext()
    {
        // Arrange
        var context = CreateFakeContext("測試訊息");
        var nextCalled = false;
        Task Next(AgentMiddlewareContext _) { nextCalled = true; return Task.CompletedTask; }

        // Act
        await _middleware.InvokeAsync(context, Next);

        // Assert
        nextCalled.Should().BeTrue();
    }

    [Fact]
    public async Task InvokeAsync_WhenNextThrows_LogsErrorAndRethrows()
    {
        // Arrange
        var context = CreateFakeContext("測試訊息");
        var expectedException = new InvalidOperationException("LLM 呼叫失敗");
        Task Next(AgentMiddlewareContext _) => Task.FromException(expectedException);

        // Act
        var act = async () => await _middleware.InvokeAsync(context, Next);

        // Assert
        await act.Should().ThrowAsync<InvalidOperationException>()
            .WithMessage("LLM 呼叫失敗");

        // 驗證錯誤已被記錄
        _loggerMock.Verify(
            x => x.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, _) => v.ToString()!.Contains("failed")),
                expectedException,
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }

    private static AgentMiddlewareContext CreateFakeContext(string message)
    {
        // AgentMiddlewareContext 的建立方式依框架版本而定
        // 可能需要使用 builder 或直接 new
        return new AgentMiddlewareContext(
            messages: [new ChatMessage(ChatRole.User, message)],
            session: new AgentSession());
    }
}
```

---

## 單元測試：Mock ChatClient 測試代理行為

這是 Agent 測試中最重要的部分：用 Mock 替換真實的 LLM 呼叫，讓測試快速且穩定。

### 建立 MockChatClientBuilder

```csharp
// Helpers/MockChatClientBuilder.cs
using Microsoft.Extensions.AI;
using Moq;

public class MockChatClientBuilder
{
    private readonly Mock<IChatClient> _mock = new();

    /// <summary>設定 LLM 每次都回傳固定文字</summary>
    public MockChatClientBuilder ReturnsText(string text)
    {
        var response = new ChatCompletion(new ChatMessage(ChatRole.Assistant, text));

        _mock.Setup(c => c.CompleteAsync(
                It.IsAny<IList<ChatMessage>>(),
                It.IsAny<ChatOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(response);

        return this;
    }

    /// <summary>設定 LLM 依訊息內容回傳不同結果</summary>
    public MockChatClientBuilder ReturnsTextWhen(
        Func<IList<ChatMessage>, bool> condition, string text)
    {
        var response = new ChatCompletion(new ChatMessage(ChatRole.Assistant, text));

        _mock.Setup(c => c.CompleteAsync(
                It.Is<IList<ChatMessage>>(msgs => condition(msgs)),
                It.IsAny<ChatOptions?>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(response);

        return this;
    }

    /// <summary>設定 LLM 拋出例外（模擬服務中斷）</summary>
    public MockChatClientBuilder Throws(Exception exception)
    {
        _mock.Setup(c => c.CompleteAsync(
                It.IsAny<IList<ChatMessage>>(),
                It.IsAny<ChatOptions?>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(exception);

        return this;
    }

    public IChatClient Build() => _mock.Object;
    public Mock<IChatClient> GetMock() => _mock;
}
```

### 使用 Mock ChatClient 測試代理回應

```csharp
// Unit/Agents/AgentBehaviorTests.cs
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.OpenAI;
using FluentAssertions;
using Xunit;

public class AgentBehaviorTests
{
    [Fact]
    public async Task Agent_WhenAskedSimpleQuestion_ReturnsResponse()
    {
        // Arrange
        var mockClient = new MockChatClientBuilder()
            .ReturnsText("台北是台灣的首都，人口約 260 萬。")
            .Build();

        var agent = mockClient.AsAIAgent(
            name: "TestAgent",
            instructions: "你是一個地理助理");

        var session = new AgentSession();

        // Act
        var reply = new System.Text.StringBuilder();
        await foreach (var update in agent.RunStreamingAsync("台北是哪裡？", session))
        {
            reply.Append(update.Text);
        }

        // Assert
        reply.ToString().Should().Contain("台北");
    }

    [Fact]
    public async Task Agent_WhenLlmFails_ThrowsException()
    {
        // Arrange
        var mockClient = new MockChatClientBuilder()
            .Throws(new HttpRequestException("Service Unavailable"))
            .Build();

        var agent = mockClient.AsAIAgent(name: "TestAgent", instructions: "...");
        var session = new AgentSession();

        // Act
        var act = async () =>
        {
            await foreach (var _ in agent.RunStreamingAsync("問題", session)) { }
        };

        // Assert
        await act.Should().ThrowAsync<HttpRequestException>();
    }

    [Fact]
    public async Task Agent_MultiTurn_MaintainsConversationContext()
    {
        // Arrange
        var mockClient = new MockChatClientBuilder()
            .ReturnsTextWhen(
                msgs => msgs.Any(m => m.Text?.Contains("你好") == true),
                "你好！我是客服代理人，有什麼可以幫你的？")
            .ReturnsTextWhen(
                msgs => msgs.Any(m => m.Text?.Contains("訂單") == true),
                "請提供您的訂單編號，我立刻為您查詢。")
            .Build();

        var agent = mockClient.AsAIAgent(name: "CustomerSupport", instructions: "...");
        var session = new AgentSession();

        // Act - 第一輪
        var reply1 = await GetFullReply(agent, "你好", session);
        // Act - 第二輪（同一個 session）
        var reply2 = await GetFullReply(agent, "我想查詢訂單", session);

        // Assert
        reply1.Should().Contain("客服代理人");
        reply2.Should().Contain("訂單編號");
    }

    private static async Task<string> GetFullReply(
        AIAgent agent, string message, AgentSession session)
    {
        var sb = new System.Text.StringBuilder();
        await foreach (var update in agent.RunStreamingAsync(message, session))
            sb.Append(update.Text);
        return sb.ToString();
    }
}
```

---

## 整合測試：Web API 端點

整合測試驗證整個 HTTP 請求到回應的完整流程，但仍用 Mock LLM 取代真實 API 呼叫。

### WebApplicationFactory 設定

```csharp
// Integration/Fixtures/AgentApiFactory.cs
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.AI;

public class AgentApiFactory : WebApplicationFactory<Program>
{
    public IChatClient MockChatClient { get; private set; } = null!;

    protected override IHost CreateHost(IHostBuilder builder)
    {
        // 建立 Mock ChatClient
        MockChatClient = new MockChatClientBuilder()
            .ReturnsText("這是來自 Mock LLM 的測試回應。")
            .Build();

        builder.ConfigureServices(services =>
        {
            // 覆蓋真實的 AIAgent 為使用 Mock ChatClient 的版本
            var descriptor = services.SingleOrDefault(
                d => d.ServiceType == typeof(AIAgent));
            if (descriptor != null)
                services.Remove(descriptor);

            services.AddSingleton<AIAgent>(_ =>
                MockChatClient.AsAIAgent(
                    name: "TestAgent",
                    instructions: "測試用代理"));
        });

        return base.CreateHost(builder);
    }
}
```

### API 整合測試

```csharp
// Integration/AgentApiTests.cs
using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Xunit;

public class AgentApiTests : IClassFixture<AgentApiFactory>
{
    private readonly HttpClient _client;
    private readonly AgentApiFactory _factory;

    public AgentApiTests(AgentApiFactory factory)
    {
        _factory = factory;
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task PostChat_ValidRequest_Returns200WithReply()
    {
        // Arrange
        var request = new { Message = "你好", SessionId = (string?)null };

        // Act
        var response = await _client.PostAsJsonAsync("/api/agent/chat", request);
        var body = await response.Content.ReadFromJsonAsync<ChatResponseDto>();

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        body!.Reply.Should().NotBeNullOrEmpty();
        body.SessionId.Should().NotBeNullOrEmpty();
    }

    [Fact]
    public async Task PostChat_WithExistingSession_ContinuesConversation()
    {
        // Arrange - 第一輪取得 SessionId
        var firstRequest = new { Message = "你好", SessionId = (string?)null };
        var firstResponse = await _client.PostAsJsonAsync("/api/agent/chat", firstRequest);
        var firstBody = await firstResponse.Content.ReadFromJsonAsync<ChatResponseDto>();

        // Act - 第二輪使用同一個 Session
        var secondRequest = new { Message = "繼續", SessionId = firstBody!.SessionId };
        var secondResponse = await _client.PostAsJsonAsync("/api/agent/chat", secondRequest);
        var secondBody = await secondResponse.Content.ReadFromJsonAsync<ChatResponseDto>();

        // Assert
        secondResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        secondBody!.SessionId.Should().Be(firstBody.SessionId);
    }

    [Fact]
    public async Task PostChat_EmptyMessage_ReturnsBadRequest()
    {
        // Arrange
        var request = new { Message = "", SessionId = (string?)null };

        // Act
        var response = await _client.PostAsJsonAsync("/api/agent/chat", request);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task DeleteSession_ExistingSession_Returns204()
    {
        // Arrange - 先建立一個 Session
        var createRequest = new { Message = "建立測試 Session", SessionId = (string?)null };
        var createResponse = await _client.PostAsJsonAsync("/api/agent/chat", createRequest);
        var body = await createResponse.Content.ReadFromJsonAsync<ChatResponseDto>();

        // Act
        var deleteResponse = await _client.DeleteAsync($"/api/agent/sessions/{body!.SessionId}");

        // Assert
        deleteResponse.StatusCode.Should().Be(HttpStatusCode.NoContent);
    }

    [Fact]
    public async Task HealthCheck_Always_Returns200()
    {
        // Act
        var response = await _client.GetAsync("/health");

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    // DTO for deserialization
    private record ChatResponseDto(string Reply, string SessionId, int TokensUsed);
}
```

---

## 測試 Middleware 在整合測試中的效果

```csharp
[Fact]
public async Task PostChat_WhenMiddlewareActive_LogsRequest()
{
    // 使用自訂 Factory，注入可驗證的 Logger
    var loggerMock = new Mock<ILogger<RequestLoggingMiddleware>>();

    var factory = _factory.WithWebHostBuilder(builder =>
        builder.ConfigureServices(services =>
        {
            services.AddSingleton(loggerMock.Object);
        }));

    var client = factory.CreateClient();

    // Act
    await client.PostAsJsonAsync("/api/agent/chat",
        new { Message = "測試日誌", SessionId = (string?)null });

    // Assert - 驗證 Information 層級的日誌被呼叫
    loggerMock.Verify(
        x => x.Log(
            LogLevel.Information,
            It.IsAny<EventId>(),
            It.IsAny<It.IsAnyType>(),
            null,
            It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
        Times.AtLeastOnce);
}
```

---

## 測試資料隔離策略

在 Agent 測試中，Session（對話狀態）的隔離特別重要：

```csharp
// 每個測試用獨立的 Session，避免狀態污染
public class IsolatedAgentTests : IAsyncLifetime
{
    private AgentSession _session = null!;
    private AIAgent _agent = null!;

    public Task InitializeAsync()
    {
        var mockClient = new MockChatClientBuilder()
            .ReturnsText("測試回應")
            .Build();

        _agent = mockClient.AsAIAgent(name: "IsolatedAgent", instructions: "...");
        _session = new AgentSession(); // 每次測試都是全新 Session
        return Task.CompletedTask;
    }

    public Task DisposeAsync() => Task.CompletedTask;

    [Fact]
    public async Task Test_WithCleanSession_NoPreviousContext()
    {
        // 每個測試都從全新的 Session 開始
        var reply = await GetFullReply(_agent, "你記得我嗎？", _session);
        // 新 Session 不應該有任何先前的對話記憶
        reply.Should().NotBeNullOrEmpty();
    }

    private static async Task<string> GetFullReply(
        AIAgent agent, string message, AgentSession session)
    {
        var sb = new System.Text.StringBuilder();
        await foreach (var update in agent.RunStreamingAsync(message, session))
            sb.Append(update.Text);
        return sb.ToString();
    }
}
```

---

## 執行測試

```bash
# 執行所有測試
dotnet test

# 只執行單元測試
dotnet test --filter "FullyQualifiedName~Unit"

# 只執行整合測試
dotnet test --filter "FullyQualifiedName~Integration"

# 顯示詳細輸出
dotnet test --logger "console;verbosity=detailed"

# 產生覆蓋率報告（需先安裝 coverlet）
dotnet test --collect:"XPlat Code Coverage"
dotnet tool install -g dotnet-reportgenerator-globaltool
reportgenerator -reports:"**/coverage.cobertura.xml" -targetdir:"coverage-report" -reporttypes:Html
```

---

## 測試策略建議

對於 Agent 應用，建議遵循以下原則：

**工具方法（高覆蓋率優先）**：工具是代理能力的核心，且是純函式，應達到 90% 以上覆蓋率，涵蓋所有邊界案例與錯誤情境。

**Middleware（驗證流程正確性）**：重點測試「`next` 是否被呼叫」「例外是否被正確傳遞」「日誌是否被記錄」，而非 LLM 的回應品質。

**代理行為（使用 Mock LLM）**：不要在單元測試中測試 LLM 的「聰明程度」，而是測試代理的流程邏輯，例如：是否正確傳遞 Session、是否正確呼叫工具、多輪對話是否維護狀態。

**Web API 端點（整合測試）**：使用 `WebApplicationFactory` 驗證 HTTP 行為：狀態碼、回應格式、錯誤處理。

---

> **返回目錄**：[README](README.md) | **上一章**：[11 — ASP.NET Core WebAPI 整合](./11-aspnetcore-webapi.md) | **下一章**：[13 — Docker 部署](./13-docker-deployment.md)
