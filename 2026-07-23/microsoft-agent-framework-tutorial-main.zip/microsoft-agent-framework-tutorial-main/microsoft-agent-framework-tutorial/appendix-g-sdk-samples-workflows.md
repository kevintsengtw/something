# 附錄 G — SDK 工作流程範例（dotnet/samples/03-workflows）

> 來源：[microsoft/agent-framework — dotnet/samples/03-workflows](https://github.com/microsoft/agent-framework/tree/main/dotnet/samples/03-workflows)
> 版本基準：v1.6.1

`03-workflows` 是工作流程功能的主要範例庫，共 14 個子目錄，涵蓋從最基礎的執行器組合到複雜的多代理編排模式。

> **建議學習順序**：先完整走過 `_StartHere/` 的 7 個步驟，再按需求學習其他子目錄。

---

## 目錄總覽

| 子目錄 | 層級 | 主題 |
|--------|------|------|
| `_StartHere/` | ⭐ 必讀 | 7 個基礎概念，按順序學習 |
| `Agents/` | 進階 | 代理在工作流程中的各種角色 |
| `Checkpoint/` | 進階 | 工作流程狀態持久化 |
| `Concurrent/` | 進階 | Fan-Out / Fan-In 並行執行 |
| `ConditionalEdges/` | 進階 | 條件路由（Switch、Multi-Select） |
| `Declarative/` | 進階 | YAML 宣告式工作流程 |
| `Evaluation/` | 進階 | 工作流程評測 |
| `HumanInTheLoop/` | 進階 | 工作流程中的人工審核節點 |
| `Loop/` | 進階 | 迴圈工作流程 |
| `Observability/` | 進階 | 工作流程追蹤與監控 |
| `Orchestration/` | 進階 | Handoff 交接編排 |
| `Resources/` | 共用 | 共用資源與設定 |
| `SharedStates/` | 進階 | Executor 間共享狀態 |
| `Visualization/` | 工具 | 工作流程圖形視覺化 |

---

## _StartHere — 七步驟基礎概念

### 01 — Streaming：工作流程事件串流

工作流程執行產生一系列 `WorkflowEvent`。`InProcessExecution.RunStreamingAsync` 讓你即時接收每個事件：

```csharp
// 串流執行（即時接收事件）
await using StreamingRun run = await InProcessExecution.RunStreamingAsync(workflow, input);
await foreach (WorkflowEvent evt in run.WatchStreamAsync())
{
    switch (evt)
    {
        case RunStartedEvent started:
            Console.WriteLine($"工作流程開始：{started.RunId}");
            break;
        case ExecutorStartedEvent executorStarted:
            Console.WriteLine($"  → 執行 {executorStarted.ExecutorId}...");
            break;
        case ExecutorCompletedEvent completed:
            Console.WriteLine($"  ✓ {completed.ExecutorId}: {completed.Data}");
            break;
        case RunCompletedEvent done:
            Console.WriteLine($"工作流程完成，輸出：{done.Data}");
            break;
        case RunErrorEvent error:
            Console.WriteLine($"執行錯誤：{error.Exception?.Message}");
            break;
    }
}

// 非串流執行（等待全部完成）
await using Run run = await InProcessExecution.RunAsync(workflow, input);
foreach (WorkflowEvent evt in run.NewEvents)
    Console.WriteLine(evt);
```

| 事件類型 | 觸發時機 |
|---------|---------|
| `RunStartedEvent` | 工作流程開始 |
| `ExecutorStartedEvent` | 某個 Executor 開始處理 |
| `ExecutorCompletedEvent` | 某個 Executor 完成（含輸出資料） |
| `RunCompletedEvent` | 整個工作流程完成 |
| `RunErrorEvent` | 發生錯誤 |

---

### 02 — Agents In Workflows：代理作為 Executor

在工作流程中使用 `AIAgent` 作為一個可替換的執行節點：

```csharp
// 將 AIAgent 包裝為 Executor（輸入/輸出皆為 string）
var translatorAgent = new AzureOpenAIClient(...)
    .GetChatClient("gpt-5.4-mini")
    .AsAIAgent(instructions: "你是翻譯助理，將輸入翻譯為繁體中文。", name: "Translator");

// AsWorkflowExecutor() 將 AIAgent 轉換為可在工作流程中使用的 Executor
var translatorExecutor = translatorAgent.AsWorkflowExecutor("TranslatorExecutor");

var summarizerAgent = new AzureOpenAIClient(...)
    .GetChatClient("gpt-5.4-mini")
    .AsAIAgent(instructions: "你是摘要助理，將輸入濃縮為一段話。", name: "Summarizer");
var summarizerExecutor = summarizerAgent.AsWorkflowExecutor("SummarizerExecutor");

// 建構 Sequential 工作流程：先翻譯，再摘要
WorkflowBuilder builder = new(translatorExecutor);
builder.AddEdge(translatorExecutor, summarizerExecutor)
       .WithOutputFrom(summarizerExecutor);
var workflow = builder.Build();
```

---

### 03 — Agent Workflow Patterns：常見代理工作流程模式

**Reflection 模式（自我批評）**：讓代理反思自己的輸出並改善：

```csharp
// Writer → Critic → (改進) → Writer → (判斷夠好?) → 輸出
var writer = writerAgent.AsWorkflowExecutor("Writer");
var critic = criticAgent.AsWorkflowExecutor("Critic");
var judger = judgeAgent.AsWorkflowExecutor("Judge");

WorkflowBuilder builder = new(writer);
builder.AddEdge(writer, critic);
builder.AddEdge(critic, judger);
// Judger 根據品質決定回到 Writer（繼續改進）或輸出（夠好了）
builder.AddConditionalEdge(judger,
    output => output.Contains("APPROVED"),
    approved: null,           // null = workflow end
    rejected: writer);        // 繼續讓 Writer 改進
```

---

### 04 — Multi-Model Service：多 AI 服務工作流程

在同一個工作流程中使用不同的 AI 模型（如一個用 gpt-5.4-mini 做初稿，另一個用 Claude 做精煉）：

```csharp
var draftAgent = gpt5mini.AsWorkflowExecutor("DraftAgent");
var refineAgent = claudeSonnet.AsWorkflowExecutor("RefineAgent");

WorkflowBuilder builder = new(draftAgent);
builder.AddEdge(draftAgent, refineAgent).WithOutputFrom(refineAgent);
var workflow = builder.Build();
```

---

### 05 — Sub-Workflows：子工作流程組合

子工作流程可以作為另一個工作流程中的一個 Executor 節點：

```csharp
// 建立子工作流程
var subWorkflow = BuildTranslateAndSummarizeWorkflow();

// 將子工作流程轉換為 Executor
var subExecutor = subWorkflow.AsExecutor("TranslateAndSummarize");

// 在主工作流程中使用子工作流程
WorkflowBuilder mainBuilder = new(fetchDataExecutor);
mainBuilder.AddEdge(fetchDataExecutor, subExecutor);
mainBuilder.AddEdge(subExecutor, publishExecutor).WithOutputFrom(publishExecutor);
var mainWorkflow = mainBuilder.Build();
```

**優點**：
- 子工作流程可獨立測試
- 可在多個主工作流程中重用
- 簡化複雜工作流程的視覺組織

---

### 06 — Mixed Workflow：Agent 與 Executor 混合

在同一個工作流程中同時使用 AI 代理（`AIAgent.AsWorkflowExecutor`）和純邏輯執行器（繼承 `Executor<T,T>`），透過型別 Adapter 橋接不同的輸入/輸出型別：

```csharp
// 純邏輯 Executor（資料預處理）
var preprocessor = new DataPreprocessorExecutor();

// AI 代理 Executor（AI 處理）
var analyzer = analyzerAgent.AsWorkflowExecutor("Analyzer");

// 型別 Adapter（將 ProcessedData 轉換為 string 給代理）
var adapter = ((Func<ProcessedData, string>)(d => d.ToString()))
    .BindAsExecutor("DataToStringAdapter");

WorkflowBuilder builder = new(preprocessor);
builder.AddEdge(preprocessor, adapter);
builder.AddEdge(adapter, analyzer).WithOutputFrom(analyzer);
```

---

### 07 — Writer-Critic Workflow：迭代精煉工作流程

展示帶有品質門控、最大迭代保護、多訊息 Handler 的完整 Reflection 模式：

```csharp
// 防止無限迴圈：最多迭代 5 次
int iterations = 0;

WorkflowBuilder builder = new(writerExecutor);
builder.AddEdge(writerExecutor, criticExecutor);
builder.AddConditionalEdge(
    criticExecutor,
    output =>
    {
        iterations++;
        if (iterations >= 5) return true;  // 強制通過
        return output.Contains("LGTM");    // Critic 認可
    },
    approved: outputExecutor,
    rejected: writerExecutor);  // 繼續迭代
```

---

## Concurrent — Fan-Out / Fan-In 並行執行

> 對應教學：[第 18 章](./18-workflows-basics.md)

```csharp
// Fan-Out：一個輸入同時觸發多個並行 Executor
var source = fetchDataExecutor;
var branch1 = sentimentAnalyzer.AsWorkflowExecutor("Sentiment");
var branch2 = entityExtractor.AsWorkflowExecutor("Entities");
var branch3 = summaryGenerator.AsWorkflowExecutor("Summary");
var merge = new MergeResultsExecutor();

WorkflowBuilder builder = new(source);
// Fan-Out：source → 三個並行分支
builder.AddEdge(source, branch1);
builder.AddEdge(source, branch2);
builder.AddEdge(source, branch3);
// Fan-In：三個分支 → merge（等待全部完成後合併）
builder.AddEdge(branch1, merge);
builder.AddEdge(branch2, merge);
builder.AddEdge(branch3, merge).WithOutputFrom(merge);
var workflow = builder.Build();
```

**效能優勢**：三個分析 Executor 並行執行，整體耗時等於最慢的那個，而非三者相加。

---

## ConditionalEdges — 條件路由

> 對應教學：[第 19 章](./19-workflows-advanced.md)

```csharp
// 01 — 基礎條件邊（Binary）
builder.AddConditionalEdge(
    evaluator,
    output => output.Score >= 0.8,
    target: publisher,        // 條件成立時
    fallback: reviser);       // 條件不成立時

// 02 — Switch-Case 多路路由
builder.AddSwitchEdge(
    classifier,
    output => output.Category,
    cases: new Dictionary<string, IWorkflowNode>
    {
        ["URGENT"] = urgentHandler,
        ["NORMAL"] = normalHandler,
        ["LOW"] = lowPriorityHandler,
    },
    defaultCase: genericHandler);

// 03 — Multi-Selection（一個輸出觸發多個下游）
builder.AddMultiSelectionEdge(
    router,
    output => output.SelectedHandlers,  // 返回 IEnumerable<string>
    handlerMap: new Dictionary<string, IWorkflowNode>
    {
        ["email"] = emailHandler,
        ["slack"] = slackHandler,
        ["sms"] = smsHandler,
    });
```

---

## HumanInTheLoop — 工作流程中的人工審核

> 對應教學：[第 16 章](./16-human-in-the-loop.md)、[第 19 章](./19-workflows-advanced.md)

```csharp
// 在工作流程中插入一個等待人工核准的節點
var approvalNode = new HumanApprovalExecutor(
    prompt: "請審核以下草稿是否可以發布？",
    timeout: TimeSpan.FromHours(24));

WorkflowBuilder builder = new(draftWriter);
builder.AddEdge(draftWriter, approvalNode);
builder.AddConditionalEdge(
    approvalNode,
    result => result.Approved,
    target: publisher,
    fallback: draftWriter);  // 退回修改
```

---

## Orchestration — Handoff 交接編排

```csharp
// Handoff 模式：代理間的任務交接
// Manager 代理根據任務內容決定交接給哪個 Worker
var orchestrator = new HandoffOrchestrator(managerAgent, [
    new AgentHandoffTarget(writingAgent, "適合需要撰寫文件的任務"),
    new AgentHandoffTarget(codeAgent, "適合需要撰寫程式的任務"),
    new AgentHandoffTarget(dataAgent, "適合需要分析資料的任務"),
]);

// Manager 自動選擇並交接給最合適的 Worker
await foreach (var update in orchestrator.RunStreamingAsync("請幫我撰寫一份報告"))
    Console.Write(update);
```

---

## SharedStates — Executor 間共享狀態

```csharp
// 定義共享狀態型別
public class PipelineState
{
    public List<string> ProcessedItems { get; set; } = [];
    public int ErrorCount { get; set; }
}

// 在 Executor 中存取共享狀態
sealed class ItemProcessor() : Executor<string, string>("ItemProcessor")
{
    public override async ValueTask<string> HandleAsync(
        string input, IWorkflowContext context, CancellationToken ct = default)
    {
        // 透過 IWorkflowContext 存取共享狀態
        var state = context.GetOrCreate<PipelineState>();
        state.ProcessedItems.Add(input);
        return $"Processed: {input}";
    }
}
```

---

## 章節對應速查

| 功能 | 對應章節 |
|------|---------|
| WorkflowBuilder 基礎 | [第 18 章](./18-workflows-basics.md) |
| Executor 自訂 + 串流事件 | [第 18 章](./18-workflows-basics.md) |
| Concurrent（Fan-Out/Fan-In） | [第 18 章](./18-workflows-basics.md) |
| Conditional Edges | [第 19 章](./19-workflows-advanced.md) |
| Declarative YAML 工作流程 | [第 19 章](./19-workflows-advanced.md) |
| Checkpoint（工作流程持久化） | [第 21 章](./21-durable-agents-implementation.md) |
| HITL 工作流程 | [第 16 章](./16-human-in-the-loop.md) |

---

> **返回目錄**：[README](README.md) | **上一篇**：[附錄 F — SDK 代理功能範例](./appendix-f-sdk-samples-agents.md) | **下一篇**：[附錄 H — SDK 代理主機整合](./appendix-h-sdk-samples-hosting.md)
