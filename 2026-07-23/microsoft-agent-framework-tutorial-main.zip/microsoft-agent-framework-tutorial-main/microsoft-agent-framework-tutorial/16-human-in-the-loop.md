# 16 — Human-in-the-Loop（人工介入）

> 本章介紹如何在代理工作流程中加入人工確認節點。當代理即將執行高風險操作（如刪除資料、傳送郵件、下訂單），必須先暫停並等待使用者明確授權，才繼續執行。

---

## 什麼是 Human-in-the-Loop

傳統的代理會自動執行所有工具呼叫。但在企業應用中，某些操作需要人工確認：

- 代理準備**刪除資料庫記錄** → 需要使用者確認
- 代理準備**寄送重要郵件** → 需要使用者審閱
- 代理準備**執行金融交易** → 需要雙重驗證
- 代理準備**部署程式碼** → 需要負責人簽核

Agent Framework 提供了一套完整的 Human-in-the-Loop 機制，核心設計原則是：**代理本身決定哪些操作需要確認，呼叫端負責呈現確認請求並回傳使用者決定**。

---

## 核心型別架構（ADR 0006）

框架採用繼承設計，所有使用者互動請求都繼承自同一個基底類別：

```text
AIContent
  └── UserInputRequestContent          ← 所有互動請求的基底
        ├── FunctionApprovalRequestContent  ← 工具呼叫確認
        ├── TextApprovalRequestContent      ← 純文字確認
        └── StructuredDataInputRequestContent ← 結構化資料輸入

  └── UserInputResponseContent         ← 所有互動回應的基底
        ├── FunctionApprovalResponseContent ← 工具呼叫確認回應
        ├── TextApprovalResponseContent     ← 純文字確認回應
        └── StructuredDataInputResponseContent ← 結構化資料輸入回應
```

---

## 方式一：ApprovalRequiredAIFunction（最簡單）

最常用的方式是將工具標記為「需要確認」，使用 `ApprovalRequiredAIFunction` 包裝：

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using System.ComponentModel;

// 定義高風險工具（刪除訂單）
[Description("刪除指定的訂單記錄")]
static string DeleteOrder(
    [Description("要刪除的訂單 ID")] string orderId)
{
    // 實際刪除邏輯
    return $"訂單 {orderId} 已成功刪除";
}

// 正常工具
AIFunction queryOrder = AIFunctionFactory.Create(
    ([Description("訂單 ID")] string id) => $"訂單 {id} 狀態：處理中",
    "QueryOrder",
    "查詢訂單狀態");

// 需要人工確認的工具
AIFunction deleteOrderTool = AIFunctionFactory.Create(DeleteOrder);
AIFunction deleteWithApproval = new ApprovalRequiredAIFunction(
    deleteOrderTool,
    approvalMessage: "即將刪除訂單，此操作無法復原，是否確認？");

// 建立代理
AIAgent agent = chatClient.AsAIAgent(
    name: "OrderManager",
    instructions: "你是訂單管理助理。刪除訂單前必須先取得使用者確認。",
    tools: [queryOrder, deleteWithApproval]);
```

---

## 核心互動迴圈

使用 `UserInputRequests` 屬性偵測代理是否在等待人工確認：

```csharp
var session = await agent.CreateSessionAsync();
var messages = new List<ChatMessage>
{
    new(ChatRole.User, "請刪除訂單 ORD-001234")
};

// 第一次執行：代理發現需要確認，暫停並回傳確認請求
AgentResponse response = await agent.RunAsync(messages, session);

// 持續處理，直到沒有待確認的請求
while (response.UserInputRequests.Any())
{
    var approvalMessages = new List<ChatMessage>();

    foreach (var request in response.UserInputRequests)
    {
        switch (request)
        {
            case FunctionApprovalRequestContent approval:
                // 顯示確認請求給使用者
                Console.WriteLine($"\n⚠️  需要確認：{approval.Text}");
                Console.WriteLine($"   工具：{approval.FunctionCall?.Name}");
                Console.Write("   請輸入 (y/n)：");
                var input = Console.ReadLine();

                // 根據使用者輸入建立回應
                var responseContent = input?.ToLower() == "y"
                    ? approval.CreateApproval()
                    : approval.CreateRejection();

                approvalMessages.Add(new ChatMessage(ChatRole.User, [responseContent]));
                break;

            case TextApprovalRequestContent textApproval:
                Console.WriteLine($"\n❓ {textApproval.Text}");
                Console.Write("   請輸入 (y/n)：");
                var textInput = Console.ReadLine();
                approvalMessages.Add(new ChatMessage(ChatRole.User,
                    [new TextApprovalResponseContent
                    {
                        Id = textApproval.Id,
                        Approved = textInput?.ToLower() == "y"
                    }]));
                break;
        }
    }

    // 將使用者決定傳回代理，繼續執行
    response = await agent.RunAsync(approvalMessages, session);
}

Console.WriteLine($"\n代理回應：{response.Text}");
```

---

## 方式二：自訂 ApprovalRequiredAIFunction

若需要更精細的確認邏輯，可以繼承 `ApprovalRequiredAIFunction`：

```csharp
// 根據參數值決定是否需要確認
public class ConditionalApprovalFunction : ApprovalRequiredAIFunction
{
    private readonly decimal _amountThreshold;

    public ConditionalApprovalFunction(AIFunction inner, decimal threshold)
        : base(inner, "此操作需要確認")
    {
        _amountThreshold = threshold;
    }

    // 覆寫以實作條件式確認
    protected override bool RequiresApproval(
        IReadOnlyDictionary<string, object?> arguments)
    {
        // 只有金額超過門檻才需要確認
        if (arguments.TryGetValue("amount", out var amountObj)
            && amountObj is decimal amount)
        {
            return amount > _amountThreshold;
        }
        return false;
    }
}
```

---

## 方式三：Middleware 實作（集中式確認邏輯）

透過 `IFunctionMiddleware` 在 Middleware 層集中管理確認邏輯，適合需要統一審計的場景：

```csharp
using Microsoft.Agents.AI;

public class AuditApprovalMiddleware : IFunctionMiddleware
{
    private readonly IApprovalService _approvalService;
    private readonly HashSet<string> _requireApprovalFunctions;

    public AuditApprovalMiddleware(
        IApprovalService approvalService,
        params string[] requireApprovalFunctions)
    {
        _approvalService = approvalService;
        _requireApprovalFunctions = [.. requireApprovalFunctions];
    }

    public async Task InvokeAsync(
        FunctionInvocationContext context,
        Func<FunctionInvocationContext, Task> next)
    {
        var funcName = context.Function.Metadata.Name;

        if (_requireApprovalFunctions.Contains(funcName))
        {
            // 記錄審計日誌
            await _approvalService.LogPendingApprovalAsync(
                funcName, context.Arguments);

            // 等待非同步審批（如 Slack/Email 通知）
            var approved = await _approvalService.WaitForApprovalAsync(
                funcName,
                context.Arguments,
                timeout: TimeSpan.FromMinutes(5));

            if (!approved)
            {
                context.Result = FunctionResult.FromValue("操作已被拒絕");
                return; // 不呼叫 next，跳過工具執行
            }
        }

        await next(context);
    }
}

// 使用方式
var agent = chatClient
    .AsAIAgent(name: "FinanceAgent", instructions: "...")
    .WithFunctionMiddleware(new AuditApprovalMiddleware(
        approvalService,
        "TransferFunds", "DeleteRecord", "SendEmail"));
```

---

## Web API 整合（非同步確認）

在 Web API 情境中，確認流程通常是非同步的（使用者不在線等待）。以下示範如何用 Pending State 模式處理：

```csharp
// Controllers 或 Minimal API

// 第一個請求：代理執行並暫停
app.MapPost("/api/agent/run", async (
    RunRequest req, AIAgent agent, ISessionStore store) =>
{
    var session = await store.GetOrCreateAsync(req.SessionId);
    var result = await agent.RunAsync(req.Message, session);

    if (result.UserInputRequests.Any())
    {
        // 儲存待確認狀態
        var pendingId = Guid.NewGuid().ToString();
        await store.SavePendingAsync(pendingId, session, result.UserInputRequests);

        return Results.Ok(new
        {
            Status = "pending_approval",
            PendingId = pendingId,
            Requests = result.UserInputRequests.Select(r => new
            {
                r.Id,
                Type = r.GetType().Name,
                Message = r is FunctionApprovalRequestContent f ? f.Text : "需要確認"
            })
        });
    }

    return Results.Ok(new { Status = "completed", Reply = result.Text });
});

// 第二個請求：使用者回應確認
app.MapPost("/api/agent/approve", async (
    ApproveRequest req, AIAgent agent, ISessionStore store) =>
{
    var (session, requests) = await store.GetPendingAsync(req.PendingId);

    var approvalMessages = requests
        .OfType<FunctionApprovalRequestContent>()
        .Select(r => req.Approved
            ? new ChatMessage(ChatRole.User, [r.CreateApproval()])
            : new ChatMessage(ChatRole.User, [r.CreateRejection()]))
        .ToList();

    var result = await agent.RunAsync(approvalMessages, session);
    await store.SaveSessionAsync(session);

    return Results.Ok(new { Status = "completed", Reply = result.Text });
});
```

---

## 搭配 AG-UI 的 Human-in-the-Loop

在 AG-UI 協定中，確認請求會自動轉換為 `TOOL_CALL_START` 事件，前端可用 CopilotKit 的 `useCoAgent` 元件渲染確認 UI：

```csharp
// 使用 ApprovalRequiredAIFunction
// AG-UI 協定自動處理暫停/恢復流程
// 前端使用 CopilotKit 的確認元件

app.MapAGUIServer("/api/agent", agentWithApprovalTools);
```

前端接收到確認請求時，AG-UI 協定會暫停串流，等待前端回傳 `FunctionApprovalResponseContent`，然後繼續執行。

---

## 確認類型總覽

| 型別 | 使用場景 | 建立方式 |
|------|----------|----------|
| `FunctionApprovalRequestContent` | 工具呼叫前確認 | `ApprovalRequiredAIFunction` 包裝 |
| `TextApprovalRequestContent` | 自由文字確認 | Agent 邏輯中手動產生 |
| `StructuredDataInputRequestContent` | 需要使用者填寫資料 | Agent 邏輯中手動產生，帶 JSON Schema |

---

## 最佳實踐

**明確的確認訊息**：`ApprovalRequiredAIFunction` 的 `approvalMessage` 應包含操作的具體影響，讓使用者能做出知情決策。

**超時處理**：非同步確認場景應設定超時，避免代理無限等待：

```csharp
var cts = new CancellationTokenSource(TimeSpan.FromMinutes(10));
var result = await agent.RunAsync(messages, session, cancellationToken: cts.Token);
```

**審計日誌**：所有確認結果（批准/拒絕）都應記錄，即使 `AgentSession` 無法持久化這些內容，也要在 Middleware 層補充記錄。

---

## v1.2.0：Handoff Orchestration 的 HITL 支援

> 🆕 **v1.2.0 新增**（[PR #5174](https://github.com/microsoft/agent-framework/pull/5174)）：Handoff Orchestration 的 Human-in-the-Loop 支援。在多代理 Handoff 場景中，當一個代理要移交控制權給另一個代理時，現在可以在移交點插入人工確認節點。搭配 ch19 的 Handoff Workflows 使用，詳見官方範例 [#5245](https://github.com/microsoft/agent-framework/pull/5245)。

---

## v1.6.1 新增：跨代理 HITL（A2A input-request）

> 🆕 **v1.6.1 新增**：A2A 協定新增 `input-request` 內容類型，讓多代理工作流程在執行期間可以暫停，等待人工輸入後再繼續。

這是 HITL 的**跨框架延伸**：當你的代理透過 A2A 協定呼叫另一個代理時，遠端代理可以在關鍵決策點發出 `input-request`，客戶端代理必須收集人工輸入並以 `send-input` 繼續任務。

與本章介紹的 `ApprovalRequiredAIFunction`（in-process HITL）的差異：

| 特性 | `ApprovalRequiredAIFunction` | A2A `input-request` |
|------|------------------------------|---------------------|
| 適用範圍 | 同一程序內的工具確認 | 跨代理（A2A 協定邊界） |
| 等待方式 | 同步等待（呼叫端輪詢 `UserInputRequests`） | 非同步（A2A 任務暫停） |
| 典型場景 | 刪除資料、發送郵件 | 多代理審批流程、外部系統確認 |

完整實作範例請見 **[第 23 章：A2A Protocol](./23-a2a-protocol.md#v161-新增human-in-the-loop-工作流程)**。

---

## v1.10.0 新增：ToolApprovalAgent 自動核可規則

> 🆕 **v1.10.0 新增，v1.14.0 轉 stable**：除了本章前述的逐次 `FunctionApprovalRequestContent` 流程，框架另提供 `ToolApprovalAgent` middleware，以 `AIAgentBuilder.UseToolApproval()` 掛載，支援「不再詢問」（don't ask again）的常駐核可，並在 v1.10.0（PR #6335）加入**啟發式自動核可規則**。

當你的代理會反覆呼叫同一批低風險工具（例如唯讀查詢）時，逐次彈出確認會干擾體驗。`ToolApprovalAgentOptions.AutoApprovalRules` 讓你以一組啟發式函式預先放行符合條件的呼叫：

```csharp
using Microsoft.Agents.AI;

var options = new ToolApprovalAgentOptions
{
    AutoApprovalRules =
    [
        // 範例：所有 get_ 開頭的唯讀工具自動核可
        context => new ValueTask<bool>(
            context.FunctionCallContent.Name.StartsWith(
                "get_", StringComparison.OrdinalIgnoreCase)),
    ],
};

AIAgent agent = innerAgent
    .AsBuilder()
    .UseToolApproval(options)   // 掛載工具核可 middleware
    .Build();
```

核可的評估順序為：

1. **常駐規則（standing rules）**：使用者先前回傳「不再詢問」（`AlwaysApproveToolApprovalResponseContent`）後建立的常駐核可；
2. **AutoApprovalRules**：依序評估，第一個回傳 `true` 者即自動核可；
3. 皆未命中 → 才向使用者顯示確認請求。

> ⚠️ 常駐規則**優先於**自動核可規則。自動核可規則應只用於確定安全的工具——對有副作用的操作（轉帳、刪除、發送）切勿自動放行，仍應走本章前述的逐次人工確認流程。

此外，`UseApprovalNotRequiredFunctionBypassing` 會把「本就不需核可」的函式呼叫繞過核可流程並記錄於 session 狀態；當它們與需核可工具一同回傳時，**只把真正需要人工確認的工具浮現給呼叫端**。v1.14.0 起此行為預設啟用；只有需要停用時，才設定 `ChatClientAgentOptions.DisableApprovalNotRequiredFunctionBypassing = true`。

> 此 `ToolApprovalAgent` 路線（agent pipeline middleware + 常駐/啟發式核可）與本章前面的 ADR 0006 `FunctionApprovalRequestContent` 逐次流程是兩條並行的核可機制，可依場景擇一採用。

---

### 延伸閱讀：官方 ADR 參考

- [ADR 0006 — User Approval](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0006-userapproval.md)：`UserInputRequestContent` / `UserInputResponseContent` 類型階層設計，`FunctionApprovalRequestContent`、`TextApprovalRequestContent`、`StructuredDataInputRequestContent` 的完整規格

---

> **返回目錄**：[README](README.md) | **上一章**：[15 — 結構化輸出](./15-structured-output.md) | **下一章**：[17 — 多 LLM 提供者整合](./17-llm-providers.md)
