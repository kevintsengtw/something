# 11 — ASP.NET Core WebAPI 整合

> 本章介紹如何將 Microsoft Agent Framework 整合進 ASP.NET Core Web API 專案，讓代理透過 HTTP 端點對外提供服務。涵蓋兩種官方整合模式：**AG-UI 串流協定**（前端即時對話）與 **Hosting Library DI 整合**（多代理、工作流程、生產環境架構）。

---

## 整合模式一覽

Agent Framework 在 ASP.NET Core 上提供兩種主要整合模式，各有適用場景：

| 模式 | 套件 | 適合場景 | 特色 |
|------|------|----------|------|
| **AG-UI 直接掛載** | `Hosting.AGUI.AspNetCore` | 快速原型、前端即時對話 | 幾行程式碼即可完成，SSE 串流 |
| **Hosting Library (DI)** | `Microsoft.Agents.AI.Hosting` | 生產環境、多代理、工作流程 | 完整 DI 整合、Session 管理、Protocol 無關 |

---

## 模式一：AG-UI 快速整合

AG-UI（Agent-User Interface）是 Agent Framework 支援的開放協定，使用 **Server-Sent Events（SSE）** 串流代理回應，適合搭配 [CopilotKit](https://copilotkit.ai/) 等前端元件庫。

### 安裝套件

```bash
dotnet new web -n MyAgentApi
cd MyAgentApi

dotnet add package Microsoft.Agents.AI.Hosting.AGUI.AspNetCore
dotnet add package Azure.AI.Projects
dotnet add package Azure.Identity
dotnet add package Microsoft.Agents.AI.Foundry
```

> `Microsoft.Agents.AI.Foundry` 提供 `AIProjectClient.AsAIAgent()` 擴充方法。

### Program.cs

```csharp
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Hosting.AGUI.AspNetCore;

WebApplicationBuilder builder = WebApplication.CreateBuilder(args);
builder.Services.AddHttpClient().AddLogging();

// ── 1. 加入 AG-UI JSON 序列化支援 ──────────────────────────────
builder.Services.AddAGUIServer();

WebApplication app = builder.Build();

// ── 2. 讀取設定 ─────────────────────────────────────────────────
string endpoint = builder.Configuration["AZURE_OPENAI_ENDPOINT"]
    ?? throw new InvalidOperationException("AZURE_OPENAI_ENDPOINT is not set.");
string deploymentName = builder.Configuration["AZURE_OPENAI_DEPLOYMENT_NAME"]
    ?? throw new InvalidOperationException("AZURE_OPENAI_DEPLOYMENT_NAME is not set.");

// ── 3. 建立 AIAgent ─────────────────────────────────────────────
AIAgent agent = new AIProjectClient(
        new Uri(endpoint),
        new DefaultAzureCredential())
    .AsAIAgent(
        model: deploymentName,
        name: "AssistantAgent",
        instructions: "你是一個友善且專業的 AI 助理，能夠回答各種問題。");

// ── 4. 掛載 AG-UI 端點 ──────────────────────────────────────────
app.MapAGUIServer("/", agent);

await app.RunAsync();
```

### 設定環境變數

```bash
# 本機開發
dotnet user-secrets set "AZURE_OPENAI_ENDPOINT" "https://your-resource.openai.azure.com/"
dotnet user-secrets set "AZURE_OPENAI_DEPLOYMENT_NAME" "gpt-4o-mini"

# 或直接使用環境變數
export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4o-mini"
```

### 驗證端點

```bash
dotnet run --urls http://localhost:8888

# 用 curl 測試 SSE 串流
curl -N http://localhost:8888/ \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -d '{"messages": [{"role": "user", "content": "你好！"}]}'
```

回應為 AG-UI 格式的 SSE 串流事件：

```text
data: {"type":"RUN_STARTED","threadId":"...","runId":"..."}
data: {"type":"TEXT_MESSAGE_START","messageId":"...","role":"assistant"}
data: {"type":"TEXT_MESSAGE_CONTENT","messageId":"...","delta":"你好"}
...
data: {"type":"RUN_FINISHED","threadId":"...","runId":"..."}
```

### AG-UI 概念對應表

| Agent Framework | AG-UI 對應 | 說明 |
|-----------------|-----------|------|
| `AIAgent` | Agent Endpoint | 每個代理對應一個 HTTP 端點 |
| `agent.Run()` | HTTP POST Request | 用戶端用 POST 傳送訊息 |
| `agent.RunStreamingAsync()` | Server-Sent Events | 串流回應 |
| `AIFunctionFactory.Create()` | Backend Tools | 在伺服器端執行，結果串流回用戶端 |
| `AgentSession` | Session Management | `ConversationId` 維護對話上下文 |
| `ApprovalRequiredAIFunction` | Human-in-the-Loop | 請求使用者確認操作 |

---

## 模式二：Hosting Library（DI 整合）

當需要多個代理、工作流程編排、或更精細的生產環境控制時，使用官方的 Hosting Library，它透過 `IHostApplicationBuilder` 的擴充方法將代理注册到 DI 容器。

### 安裝套件

```bash
# 核心 Hosting 套件
dotnet add package Microsoft.Agents.AI.Hosting

# A2A 協定支援（選用）
dotnet add package Microsoft.Agents.AI.Hosting.A2A
dotnet add package Microsoft.Agents.AI.AspNetCore
```

### 核心概念：AddAIAgent()

`builder.AddAIAgent()` 是 `IHostApplicationBuilder` 的擴充方法，與 `services.AddSingleton()` 不同——它將代理以**具名 Keyed Service** 的形式注册，並回傳 `IHostedAgentBuilder` 供後續鏈式設定。

```csharp
// 先注册 IChatClient
IChatClient chatClient = new AIProjectClient(
        new Uri(endpoint),
        new DefaultAzureCredential())
    .GetProjectOpenAIClient()
    .GetProjectResponsesClient()
    .AsIChatClient(deploymentName);

builder.Services.AddKeyedSingleton("chat-model", chatClient);

// 注册代理，引用已注册的 ChatClient
var myAgent = builder.AddAIAgent(
    "my-agent",                              // 代理名稱（Keyed Service Key）
    instructions: "你是一個有用的助理",
    description: "通用助理代理",
    chatClientServiceKey: "chat-model");     // 引用上面注册的 ChatClient key
```

`IHostedAgentBuilder` 支援鏈式設定工具與 Session Store：

```csharp
var myAgent = builder.AddAIAgent("customer-support",
        instructions: "你是客服代理人",
        chatClientServiceKey: "chat-model")
    .WithAITool(new GetOrderStatusTool())    // 加入自訂工具
    .WithAITool(new GetProductInfoTool())
    .WithInMemorySessionStore();             // 啟用記憶體 Session 管理
```

### 完整 Program.cs（A2A 協定版）

```csharp
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.AspNetCore;
using Microsoft.Agents.AI.Hosting;
using Microsoft.Extensions.AI;

var builder = WebApplication.CreateBuilder(args);

string endpoint = builder.Configuration["AZURE_OPENAI_ENDPOINT"]!;
string deployment = builder.Configuration["AZURE_OPENAI_DEPLOYMENT_NAME"]!;

// ── 1. 注册 IChatClient ─────────────────────────────────────────
IChatClient chatClient = new AIProjectClient(
        new Uri(endpoint),
        new DefaultAzureCredential())
    .GetProjectOpenAIClient()
    .GetProjectResponsesClient()
    .AsIChatClient(deployment);

builder.Services.AddKeyedSingleton("chat-model", chatClient);

// ── 2. 注册代理 ─────────────────────────────────────────────────
builder.AddAIAgent(
    "pirate",
    instructions: "You are a pirate. Speak like a pirate",
    description: "An agent that speaks like a pirate.",
    chatClientServiceKey: "chat-model");

// ── 3. 加入 A2A 伺服器（讓代理透過 A2A 協定對外暴露）───────────
// v1.3.0：AddA2AServer 需明確設定 AgentCard 與 AgentFactory
builder.Services.AddA2AServer(options =>
{
    options.AgentCard = new AgentCard
    {
        Name        = "pirate",
        Description = "An agent that speaks like a pirate."
    };
    options.AgentFactory = sp =>
        sp.GetRequiredKeyedService<AIAgent>("pirate");
});

var app = builder.Build();

// ── 4. 掛載 A2A 端點 ────────────────────────────────────────────
app.MapA2AServer();

app.Run();
```

### 多代理工作流程

```csharp
// 注册兩個獨立代理
builder.AddAIAgent("agent-1",
    instructions: "你是第一階段代理，負責分析問題",
    chatClientServiceKey: "chat-model");

builder.AddAIAgent("agent-2",
    instructions: "你是第二階段代理，負責根據分析結果給出建議",
    chatClientServiceKey: "chat-model");

// 組合成循序執行的工作流程
builder.AddWorkflow("analysis-workflow", (sp, key) =>
{
    var agent1 = sp.GetRequiredKeyedService<AIAgent>("agent-1");
    var agent2 = sp.GetRequiredKeyedService<AIAgent>("agent-2");
    return AgentWorkflowBuilder.BuildSequential(key, [agent1, agent2]);
});
```

若要透過 A2A 或 AG-UI 協定暴露工作流程，需先轉換為 AIAgent：

```csharp
builder.AddWorkflow("science-workflow", (sp, key) => { ... })
    .AddAsAIAgent();  // 轉換後即可用 MapA2AServer() 或 MapAGUIServer() 暴露
```

---

## 模式三：自訂 REST API（完全控制）

若需要完全自訂 HTTP 行為（自訂認證、回應格式、Session 邏輯），可直接用標準 Minimal API 包裝代理：

```csharp
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI;

var builder = WebApplication.CreateBuilder(args);

// 直接建立代理並注册為 Singleton
AIAgent agent = new AIProjectClient(
        new Uri(builder.Configuration["AZURE_OPENAI_ENDPOINT"]!),
        new DefaultAzureCredential())
    .AsAIAgent(
        model: builder.Configuration["AZURE_OPENAI_DEPLOYMENT_NAME"]!,
        name: "CustomAgent",
        instructions: "你是一個客服助理");

builder.Services.AddSingleton(agent);
builder.Services.AddCors(opt =>
    opt.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();
app.UseCors();

// ── 自訂 chat 端點 ──────────────────────────────────────────────
app.MapPost("/api/chat", async (
    ChatRequest req,
    AIAgent agentSvc,
    CancellationToken ct) =>
{
    var session = await agentSvc.CreateSessionAsync();
    var sb = new System.Text.StringBuilder();

    var response = await agentSvc.RunAsync(req.Message, session);

    return Results.Ok(new { reply = response.Text, sessionId = session.Id });
});

// ── 自訂串流端點 (SSE) ──────────────────────────────────────────
app.MapPost("/api/chat/stream", async (
    ChatRequest req,
    AIAgent agentSvc,
    HttpResponse response,
    CancellationToken ct) =>
{
    response.ContentType = "text/event-stream";
    response.Headers.CacheControl = "no-cache";
    var writer = new StreamWriter(response.Body);
    var session = await agentSvc.CreateSessionAsync();

    await foreach (var update in agentSvc.RunStreamingAsync(req.Message, session))
    {
        if (!string.IsNullOrEmpty(update.Text))
        {
            await writer.WriteLineAsync($"data: {update.Text}");
            await writer.WriteLineAsync();
            await writer.FlushAsync(ct);
        }
    }

    await writer.WriteLineAsync("data: [DONE]");
    await writer.FlushAsync(ct);
});

app.Run();

record ChatRequest(string Message);
```

---

## 加入 Middleware（日誌 + 錯誤處理）

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.Logging;

public class RequestLoggingMiddleware : IAgentMiddleware
{
    private readonly ILogger<RequestLoggingMiddleware> _logger;

    public RequestLoggingMiddleware(ILogger<RequestLoggingMiddleware> logger)
        => _logger = logger;

    public async Task InvokeAsync(
        AgentMiddlewareContext context,
        AgentMiddlewareDelegate next)
    {
        var requestId = Guid.NewGuid().ToString("N")[..8];
        _logger.LogInformation("[{RequestId}] Agent invoked", requestId);

        try
        {
            await next(context);
            _logger.LogInformation("[{RequestId}] Agent completed", requestId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[{RequestId}] Agent failed", requestId);
            throw;
        }
    }
}
```

在 DI 整合模式中掛載 Middleware：

```csharp
builder.Services.AddSingleton<RequestLoggingMiddleware>();

builder.AddAIAgent("my-agent", instructions: "...", chatClientServiceKey: "chat-model")
    .WithMiddleware(sp => sp.GetRequiredService<RequestLoggingMiddleware>());
```

---

## 健康檢查端點

```bash
dotnet add package Microsoft.Extensions.Diagnostics.HealthChecks
```

```csharp
builder.Services.AddHealthChecks()
    .AddCheck("agent", () => HealthCheckResult.Healthy("Agent is ready"));

app.MapHealthChecks("/health");
```

---

## 模式選擇指引

```text
需要快速原型 / 搭配前端 AG-UI 元件？
    → 模式一：app.MapAGUIServer("/", agent)

需要多代理編排 / 工作流程 / 企業級架構？
    → 模式二：builder.AddAIAgent() + A2A 或 AG-UI 協定

需要完全自訂 HTTP 行為（認證、格式、Session 邏輯）？
    → 模式三：Minimal API 直接包裝
```

> ⚠️ **注意**：AG-UI 協定仍在持續演進中，API 可能隨版本調整，使用時請關注官方發佈說明。

---

## v1.8.0 新增：依使用者身分隔離 Session

多租戶或多使用者的 Web 服務中，不同使用者不應共用同一個 agent session。v1.8.0（PR [#5696](https://github.com/microsoft/agent-framework/pull/5696)）在 `Microsoft.Agents.AI.Hosting.AspNetCore` 新增擴充方法，依目前登入使用者的 `ClaimsIdentity` 自動為 session 產生隔離鍵：

```csharp
using Microsoft.Agents.AI.Hosting.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpContextAccessor();        // 必要前置：擴充方法依賴 IHttpContextAccessor

// 依使用者 claims 產生 session 隔離鍵，不同使用者各自獨立 session
builder.Services.UseClaimsBasedSessionIsolation();

// 可選：自訂要採用哪些 claim
builder.Services.UseClaimsBasedSessionIsolation(new ClaimsIdentitySessionIsolationKeyProviderOptions
{
    // ... 依需求設定
});
```

運作方式：註冊一個 `SessionIsolationKeyProvider`（實作為 `ClaimsIdentitySessionIsolationKeyProvider`），框架在存取 session store 時以該隔離鍵 scope，配合 `IsolationKeyScopedAgentSessionStore` 確保跨使用者隔離。

> 此為 **ASP.NET Core 自管 hosting** 的 session 隔離；若使用 Azure AI Foundry 託管環境，對應機制為 `HostedSessionContext`（每用戶 context），屬不同層級。

---

## v1.15.0 新增：app-owned OpenAI Responses helpers

v1.15.0 新增 `OpenAIResponses` 與 `OpenAIResponsesRunRequest`，讓應用程式自行掌控 HTTP route、authentication、authorization、middleware 與 storage，同時重用 OpenAI Responses wire protocol 的 request/response mapping。這些 helper 本身不執行 I/O；從 request 取得的 `previous_response_id` 或 conversation id 也不能直接視為已授權的 session key，必須先與已驗證的呼叫者身分綁定並完成授權。

這是本章三種 hosting 模式之外的進階選項：需要完整掌控路由與儲存時採用 app-owned helpers；只需快速掛載前端協定時，仍可使用前述 AG-UI server endpoint。

---

> **返回目錄**：[README](README.md) | **上一章**：[10 — 範例實作：Multi-Agent 初探](./10-example-multi-agent.md) | **下一章**：[12 — 測試策略](./12-testing-strategy.md)
