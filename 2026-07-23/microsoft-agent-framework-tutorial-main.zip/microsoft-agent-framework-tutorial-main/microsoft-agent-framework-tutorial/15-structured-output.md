# 15 — 結構化輸出（Structured Output）

> 本章介紹如何讓代理回傳結構化的 JSON 資料，而非自由格式的文字。結構化輸出是將 AI 整合進商業系統的關鍵技術，讓你能可靠地解析代理回應並直接操作物件。

---

## 為什麼需要結構化輸出

想像你要讓代理分析客服訊息並分類情緒，如果回應是純文字：

```text
這則訊息的情緒是正面的，信心度大約是 0.85，主要話題是產品品質。
```

你還要再解析這段文字。但若用結構化輸出：

```json
{
  "sentiment": "positive",
  "confidence": 0.85,
  "topics": ["product_quality"]
}
```

就可以直接反序列化為 C# 物件，進入後續業務邏輯。

---

## 主要 API：ChatResponseFormat.ForJsonSchema\<T\>()

Agent Framework 透過 `ChatResponseFormat.ForJsonSchema<T>()` 設定回應格式，這個 API 來自 `Microsoft.Extensions.AI`：

```csharp
using Microsoft.Extensions.AI;
using Microsoft.Agents.AI;

// 定義期望的輸出結構
public record SentimentAnalysis(
    string Sentiment,        // "positive" | "negative" | "neutral"
    double Confidence,
    string[] Topics,
    string Summary
);

// 建立帶有結構化輸出格式的代理選項
var options = new AgentRunOptions
{
    ResponseFormat = ChatResponseFormat.ForJsonSchema<SentimentAnalysis>()
};

// 執行並取得結構化結果
var session = await agent.CreateSessionAsync();
var result = await agent.RunAsync(
    "分析這則客服訊息：『你們的產品品質真的很棒，下次還會再買！』",
    session,
    options);

// 反序列化
var analysis = JsonSerializer.Deserialize<SentimentAnalysis>(result.Text!);
Console.WriteLine($"情緒：{analysis!.Sentiment}，信心度：{analysis.Confidence:P0}");
// 輸出：情緒：positive，信心度：92%
```

---

## 定義輸出 Schema 的最佳實踐

### 使用具描述性的型別定義

```csharp
using System.Text.Json.Serialization;
using System.ComponentModel;

// 搭配 Description 屬性提升 Schema 說明品質
public record ProductReview
{
    [Description("評分，1 到 5 分")]
    [JsonPropertyName("rating")]
    public int Rating { get; init; }

    [Description("情緒分析結果：positive、negative 或 neutral")]
    [JsonPropertyName("sentiment")]
    public string Sentiment { get; init; } = "";

    [Description("評論提到的主要產品特點清單")]
    [JsonPropertyName("key_points")]
    public string[] KeyPoints { get; init; } = [];

    [Description("是否建議改進，若有請填寫具體建議")]
    [JsonPropertyName("improvement_suggestion")]
    public string? ImprovementSuggestion { get; init; }
}
```

### 巢狀複雜結構

```csharp
public record TravelPlan
{
    public string Destination { get; init; } = "";
    public int DurationDays { get; init; }
    public DayItinerary[] Itinerary { get; init; } = [];
    public BudgetEstimate Budget { get; init; } = new();
}

public record DayItinerary
{
    public int Day { get; init; }
    public string[] Activities { get; init; } = [];
    public string AccommodationSuggestion { get; init; } = "";
}

public record BudgetEstimate
{
    public decimal MinUSD { get; init; }
    public decimal MaxUSD { get; init; }
    public string Currency { get; init; } = "USD";
}
```

---

## 完整範例：訂單意圖解析

這是一個實際的業務場景——解析客戶的自然語言訂單請求，轉換為系統可直接處理的結構：

```csharp
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using System.Text.Json;

// ── 定義輸出結構 ──────────────────────────────────────────────────
public record OrderIntent
{
    public string Action { get; init; } = "";     // "create" | "modify" | "cancel" | "query"
    public string? OrderId { get; init; }
    public OrderItem[] Items { get; init; } = [];
    public string? DeliveryAddress { get; init; }
    public bool IsUrgent { get; init; }
    public string? SpecialInstructions { get; init; }
}

public record OrderItem(string ProductName, int Quantity, string? Size = null);

// ── 建立代理 ─────────────────────────────────────────────────────
var endpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
var deployment = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME")!;

AIAgent agent = new AIProjectClient(new Uri(endpoint), new DefaultAzureCredential())
    .AsAIAgent(
        model: deployment,
        name: "OrderParser",
        instructions: """
            你是一個訂單意圖解析器。
            分析使用者的自然語言描述，提取訂單資訊。
            確保輸出符合要求的 JSON 格式。
            """);

// ── 解析訂單意圖 ──────────────────────────────────────────────────
var options = new AgentRunOptions
{
    ResponseFormat = ChatResponseFormat.ForJsonSchema<OrderIntent>()
};

var session = await agent.CreateSessionAsync();
var result = await agent.RunAsync(
    "我想要加急訂 2 件 M 號的白色 T-Shirt 和 1 件 L 號的黑色外套，送到台北市信義路 100 號",
    session,
    options);

var order = JsonSerializer.Deserialize<OrderIntent>(result.Text!, new JsonSerializerOptions
{
    PropertyNameCaseInsensitive = true
});

Console.WriteLine($"動作：{order!.Action}");
Console.WriteLine($"商品數量：{order.Items.Length}");
Console.WriteLine($"加急：{order.IsUrgent}");
Console.WriteLine($"送貨地址：{order.DeliveryAddress}");
```

---

## AgentRunOptions vs 建立時設定

結構化輸出格式可以在兩個地方設定：

### 1. 每次呼叫時設定（靈活，同一代理可輸出不同格式）

```csharp
// 同一個代理，根據需求切換輸出格式
var sentimentResult = await agent.RunAsync(
    "分析這段文字的情緒：...",
    session,
    new AgentRunOptions { ResponseFormat = ChatResponseFormat.ForJsonSchema<SentimentAnalysis>() });

var keywordsResult = await agent.RunAsync(
    "提取這段文字的關鍵字：...",
    session,
    new AgentRunOptions { ResponseFormat = ChatResponseFormat.ForJsonSchema<KeywordExtraction>() });
```

### 2. 建立代理時設定（固定格式，適合單一職責代理）

```csharp
// 這個代理永遠只輸出 OrderIntent 格式
AIAgent orderParser = chatClient.AsAIAgent(
    name: "OrderParser",
    instructions: "你是訂單解析器...",
    defaultRunOptions: new AgentRunOptions
    {
        ResponseFormat = ChatResponseFormat.ForJsonSchema<OrderIntent>()
    });

// 呼叫時不需要再指定格式
var result = await orderParser.RunAsync("我想訂購...", session);
```

---

## 搭配 AG-UI 的 State Snapshots

在 AG-UI 協定中，結構化輸出可以作為「State Snapshots」同步到前端：

```csharp
// 代理用 ForJsonSchema 輸出狀態快照
// AG-UI 協定自動將結構化輸出轉換為 STATE_SNAPSHOT 事件
// 前端可直接用 useCoAgentStateRender() 訂閱這些狀態

var agent = chatClient.AsAIAgent(
    name: "TravelPlanner",
    instructions: "根據使用者需求規劃旅遊行程，以結構化格式輸出",
    defaultRunOptions: new AgentRunOptions
    {
        ResponseFormat = ChatResponseFormat.ForJsonSchema<TravelPlan>()
    });

// 在 AG-UI 端點掛載此代理，前端即可即時渲染結構化旅遊計畫
app.MapAGUIServer("/api/planner", agent);
```

---

## 多輪對話中的結構化輸出

結構化輸出在多輪對話中同樣有效，每輪都可以取得結構化結果：

```csharp
var session = await agent.CreateSessionAsync();
var options = new AgentRunOptions
{
    ResponseFormat = ChatResponseFormat.ForJsonSchema<ConversationState>()
};

// 第一輪：代理輸出初始狀態
var state1 = Deserialize<ConversationState>(
    await agent.RunAsync("我想規劃一個日本旅遊", session, options));
Console.WriteLine($"目的地：{state1.Destination}，確定程度：{state1.Confidence}");

// 第二輪：使用者補充資訊，代理更新狀態
var state2 = Deserialize<ConversationState>(
    await agent.RunAsync("我想去東京，5 天行程，預算約 5 萬台幣", session, options));
Console.WriteLine($"目的地：{state2.Destination}，天數：{state2.Days}，預算：{state2.Budget}");

static T Deserialize<T>(AgentResponse result)
    => JsonSerializer.Deserialize<T>(result.Text!)!;
```

---

## 注意事項

**頂層型別限制**：使用 `ChatResponseFormat.ForJsonSchema<T>()` 時，原始型別（`string`、`int` 等）和陣列無法直接作為頂層結構，需要包在物件中。若使用 `RunAsync<T>` 泛型方法，框架會自動進行透明包裝，不需手動處理：

```csharp
// ❌ ChatResponseFormat 不支援頂層陣列
var options = new AgentRunOptions
{
    ResponseFormat = ChatResponseFormat.ForJsonSchema<string[]>() // 頂層陣列
};

// ✅ ChatResponseFormat：包裝在物件中
public record TagList(string[] Tags);
var options = new AgentRunOptions
{
    ResponseFormat = ChatResponseFormat.ForJsonSchema<TagList>()
};

// ✅ RunAsync<T>：框架自動處理陣列/基本型別的透明包裝
string[] tags = await agent.RunAsync<string[]>(
    "從這段文章提取 5 個關鍵標籤", session);
```

**模型相容性**：並非所有 LLM 提供者都支援結構化輸出。Azure OpenAI（gpt-4o 系列）和 OpenAI 完整支援；使用 Ollama 等本地模型時，效果可能因模型而異。

**Prompt 配合**：在 `instructions` 中明確告知代理「輸出 JSON 格式」有助於提升準確性，特別是在複雜結構時：

```csharp
instructions: """
    你是一個資料提取器。
    請嚴格按照指定的 JSON Schema 輸出結果，不要包含任何額外說明文字。
    """;
```

---

### 延伸閱讀：官方 ADR 參考

- [ADR 0016 — Structured Output](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0016-structured-output.md)：`RunAsync<T>` 泛型方法的設計決策，陣列與基本型別的透明包裝，與 `ResponseFormat` 的互補關係

---

> **返回目錄**：[README](README.md) | **上一章**：[14 — Context Providers 深度](./14-context-providers.md) | **下一章**：[16 — Human-in-the-Loop](./16-human-in-the-loop.md)
