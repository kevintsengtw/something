# 09 — 範例實作：Planning Pattern

> 本章透過官方的 Planning 範例，展示如何讓代理使用**結構化輸出（Structured Output）**來拆解複雜任務、產生可執行的計畫。
>
> 對應官方範例：[Agent-Framework-Samples/00.ForBeginners/07-planning-design](https://github.com/microsoft/Agent-Framework-Samples/tree/main/00.ForBeginners/07-planning-design)
>
> 參考教程：[AI Agents for Beginners — Planning Design Pattern](https://microsoft.github.io/ai-agents-for-beginners/07-planning-design/)

---

## 什麼是 Planning Pattern

Planning Pattern（規劃模式）是一種讓 AI 代理能夠**將複雜任務拆解為多個步驟**，並產生結構化計畫的設計模式。

### 為什麼需要 Planning

當使用者給出一個模糊或複雜的需求時，例如「幫我規劃一趟日本七日遊」，代理如果直接回應一段長文字，結果往往不夠精確也難以後續處理。Planning Pattern 的做法是：

1. **目標定義**：代理先理解使用者的最終目標
2. **任務拆解**：將大目標分解為多個具體的小任務
3. **結構化輸出**：以 JSON Schema 約束輸出格式，確保回應可被程式解析
4. **執行追蹤**：每個步驟都有明確定義，可以追蹤進度

### Planning Pattern 的運作流程

```mermaid
flowchart TD
    A["使用者輸入複雜需求"] --> B["代理分析目標"]
    B --> C["拆解為多個子任務"]
    C --> D["以 JSON Schema\n約束輸出格式"]
    D --> E["產生結構化計畫\n（JSON）"]
    E --> F["程式解析 JSON\n並呈現計畫"]

    style B fill:#E8F0FE,stroke:#4A90D9,color:#333
    style D fill:#FFF3CD,stroke:#FFC107,color:#333
    style E fill:#D4EDDA,stroke:#28A745,color:#333
```

### 關鍵技術：Structured Output

Structured Output（結構化輸出）是 OpenAI 提供的功能，也被 Microsoft Agent Framework 所支援。它允許你透過 JSON Schema 來**約束 LLM 的輸出格式**，確保回應一定符合你定義的資料結構。

這比起單純在 prompt 中要求「請用 JSON 格式回覆」要可靠得多，因為 Structured Output 是在模型層級強制執行的。

---

## 範例情境

我們要建立一個**旅行規劃代理**，使用者只需要說明旅行需求（目的地、天數、預算等），代理就會產生一份結構化的旅行計畫，包含每天的行程安排。

---

## 核心概念：定義輸出模型

Planning Pattern 的第一步是定義代理回應的資料結構。我們使用 C# 的類別搭配 `JsonPropertyName` 與 `Description` 屬性來描述期望的輸出格式。

### 模型類別定義

```csharp
using System.ComponentModel;
using System.Text.Json.Serialization;

/// <summary>
/// 完整的旅行計畫
/// </summary>
[Description("A structured travel plan with daily activities")]
public class TravelPlan
{
    [JsonPropertyName("destination")]
    [Description("The primary travel destination")]
    public string Destination { get; set; } = string.Empty;

    [JsonPropertyName("duration_days")]
    [Description("Total number of travel days")]
    public int DurationDays { get; set; }

    [JsonPropertyName("estimated_budget")]
    [Description("Estimated total budget in USD")]
    public decimal EstimatedBudget { get; set; }

    [JsonPropertyName("plans")]
    [Description("Daily plans for each day of the trip")]
    public List<DailyPlan> Plans { get; set; } = [];
}

/// <summary>
/// 單日行程
/// </summary>
[Description("A single day's plan within the travel itinerary")]
public class DailyPlan
{
    [JsonPropertyName("day")]
    [Description("Day number (starting from 1)")]
    public int Day { get; set; }

    [JsonPropertyName("title")]
    [Description("A short title for this day's theme")]
    public string Title { get; set; } = string.Empty;

    [JsonPropertyName("activities")]
    [Description("List of planned activities for this day")]
    public List<string> Activities { get; set; } = [];

    [JsonPropertyName("accommodation")]
    [Description("Recommended accommodation for the night")]
    public string Accommodation { get; set; } = string.Empty;

    [JsonPropertyName("estimated_cost")]
    [Description("Estimated cost for this day in USD")]
    public decimal EstimatedCost { get; set; }
}
```

### 屬性說明

| 屬性 | 用途 |
|------|------|
| `[JsonPropertyName("...")]` | 定義 JSON 序列化時的屬性名稱，確保輸出的 JSON 使用指定的 key |
| `[Description("...")]` | 提供屬性的語意描述，幫助 LLM 理解每個欄位應該填入什麼內容 |

`[Description]` 屬性特別重要——它不只是程式碼文件，更是 LLM 理解欄位語意的關鍵。描述越清楚，LLM 產出的內容就越準確。

---

## 核心概念：JSON Schema 約束輸出

有了模型類別後，我們需要：

1. 從 C# 類別**自動產生 JSON Schema**
2. 用這個 Schema **約束代理的輸出格式**

### 產生 JSON Schema

```csharp
using System.Text.Json.Schema; // AIJsonUtilities 所在的命名空間

// 從 C# 類別自動產生 JSON Schema
var travelPlanSchema = AIJsonUtilities.CreateJsonSchema(
    type: typeof(TravelPlan),
    inferenceOptions: new AIJsonSchemaCreateOptions
    {
        IncludeSchemaKeyword = false,        // 不包含 $schema 關鍵字
        DisallowAdditionalProperties = true, // 不允許 Schema 定義以外的屬性
        RequireAllProperties = true           // 所有屬性都是必填
    }
);
```

`AIJsonUtilities.CreateJsonSchema()` 會讀取類別的屬性定義、`JsonPropertyName`、`Description` 等資訊，自動產生對應的 JSON Schema。產生的 Schema 大致如下：

```json
{
  "type": "object",
  "properties": {
    "destination": {
      "type": "string",
      "description": "The primary travel destination"
    },
    "duration_days": {
      "type": "integer",
      "description": "Total number of travel days"
    },
    "estimated_budget": {
      "type": "number",
      "description": "Estimated total budget in USD"
    },
    "plans": {
      "type": "array",
      "description": "Daily plans for each day of the trip",
      "items": {
        "type": "object",
        "properties": {
          "day": { "type": "integer", "description": "Day number (starting from 1)" },
          "title": { "type": "string", "description": "A short title for this day's theme" },
          "activities": { "type": "array", "items": { "type": "string" } },
          "accommodation": { "type": "string" },
          "estimated_cost": { "type": "number" }
        },
        "required": ["day", "title", "activities", "accommodation", "estimated_cost"],
        "additionalProperties": false
      }
    }
  },
  "required": ["destination", "duration_days", "estimated_budget", "plans"],
  "additionalProperties": false
}
```

### 設定 ChatOptions

```csharp
using Microsoft.Extensions.AI;

var chatOptions = new ChatOptions
{
    ResponseFormat = ChatResponseFormat.ForJsonSchema(
        schema: travelPlanSchema,
        schemaName: "TravelPlan",
        schemaDescription: "A structured travel plan with daily activities"
    )
};
```

`ChatResponseFormat.ForJsonSchema()` 將 Schema 傳給模型提供者（OpenAI / Azure OpenAI），讓模型在生成時**被強制約束**只能輸出符合此 Schema 的 JSON。

---

## 完整範例程式碼

以下是完整的 Planning Pattern 範例，結合了前面所有概念：

```csharp
using System.ComponentModel;
using System.Text.Json;
using System.Text.Json.Schema;
using System.Text.Json.Serialization;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using OpenAI;

// ============================================================
// 步驟 1：定義輸出模型
// ============================================================

[Description("A structured travel plan with daily activities")]
public class TravelPlan
{
    [JsonPropertyName("destination")]
    [Description("The primary travel destination")]
    public string Destination { get; set; } = string.Empty;

    [JsonPropertyName("duration_days")]
    [Description("Total number of travel days")]
    public int DurationDays { get; set; }

    [JsonPropertyName("estimated_budget")]
    [Description("Estimated total budget in USD")]
    public decimal EstimatedBudget { get; set; }

    [JsonPropertyName("plans")]
    [Description("Daily plans for each day of the trip")]
    public List<DailyPlan> Plans { get; set; } = [];
}

[Description("A single day's plan within the travel itinerary")]
public class DailyPlan
{
    [JsonPropertyName("day")]
    [Description("Day number (starting from 1)")]
    public int Day { get; set; }

    [JsonPropertyName("title")]
    [Description("A short title for this day's theme")]
    public string Title { get; set; } = string.Empty;

    [JsonPropertyName("activities")]
    [Description("List of planned activities for this day")]
    public List<string> Activities { get; set; } = [];

    [JsonPropertyName("accommodation")]
    [Description("Recommended accommodation for the night")]
    public string Accommodation { get; set; } = string.Empty;

    [JsonPropertyName("estimated_cost")]
    [Description("Estimated cost for this day in USD")]
    public decimal EstimatedCost { get; set; }
}

// ============================================================
// 步驟 2：建立 LLM 用戶端
// ============================================================

// --- 選項 A：使用 OpenAI ---
IChatClient chatClient = new OpenAIClient(
    Environment.GetEnvironmentVariable("OPENAI_API_KEY")
).GetChatClient("gpt-4o").AsIChatClient();

// --- 選項 B：使用 Azure OpenAI ---
// IChatClient chatClient = new AzureOpenAIClient(
//     new Uri(Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!),
//     new Azure.AzureKeyCredential(
//         Environment.GetEnvironmentVariable("AZURE_OPENAI_API_KEY")!)
// ).GetChatClient("gpt-4o").AsIChatClient();

// --- 選項 C：使用 GitHub Models（免費） ---
// IChatClient chatClient = new OpenAIClient(
//     new System.ClientModel.ApiKeyCredential(
//         Environment.GetEnvironmentVariable("GITHUB_TOKEN")!),
//     new OpenAIClientOptions
//     {
//         Endpoint = new Uri("https://models.inference.ai.azure.com")
//     }
// ).GetChatClient("gpt-4o").AsIChatClient();

// ============================================================
// 步驟 3：建立代理
// ============================================================

var agent = chatClient.AsAIAgent("""
    你是一位專業的旅行規劃師。
    根據使用者提供的需求（目的地、天數、預算、興趣等），
    產生一份詳細的每日行程計畫。

    規劃原則：
    - 每天的行程要合理安排，不要過於緊湊
    - 考慮景點之間的交通時間
    - 包含當地特色美食的推薦
    - 住宿建議要符合預算等級
    - 活動要多元，涵蓋文化、美食、自然等面向
    """);

// ============================================================
// 步驟 4：產生 JSON Schema 並設定 ChatOptions
// ============================================================

var travelPlanSchema = AIJsonUtilities.CreateJsonSchema(
    type: typeof(TravelPlan),
    inferenceOptions: new AIJsonSchemaCreateOptions
    {
        IncludeSchemaKeyword = false,
        DisallowAdditionalProperties = true,
        RequireAllProperties = true
    }
);

var chatOptions = new ChatOptions
{
    ResponseFormat = ChatResponseFormat.ForJsonSchema(
        schema: travelPlanSchema,
        schemaName: "TravelPlan",
        schemaDescription: "A structured travel plan with daily activities"
    )
};

// ============================================================
// 步驟 5：執行代理並解析結構化輸出
// ============================================================

Console.WriteLine("=== 旅行規劃代理 ===");
Console.WriteLine();

// 使用者的旅行需求
var userRequest = "我想去日本東京玩 5 天，預算大約 2000 美元，喜歡美食和文化體驗";
Console.WriteLine($"使用者：{userRequest}");
Console.WriteLine();
Console.WriteLine("規劃中...");
Console.WriteLine();

// 建立對話 Session
var session = await agent.CreateSessionAsync();

// 執行代理（帶有 ChatOptions 約束輸出格式）
var response = await agent.RunAsync(
    session,
    userRequest,
    new AgentRunOptions { ChatOptions = chatOptions }
);

// 從回應中取得 JSON 字串
var jsonResponse = response.Message.Text ?? string.Empty;

// 反序列化為強型別物件
var travelPlan = JsonSerializer.Deserialize<TravelPlan>(jsonResponse);

if (travelPlan is null)
{
    Console.WriteLine("錯誤：無法解析代理的回應");
    return;
}

// ============================================================
// 步驟 6：呈現結構化結果
// ============================================================

Console.WriteLine($"📍 目的地：{travelPlan.Destination}");
Console.WriteLine($"📅 天數：{travelPlan.DurationDays} 天");
Console.WriteLine($"💰 預估總預算：${travelPlan.EstimatedBudget:N0}");
Console.WriteLine();
Console.WriteLine(new string('─', 50));

foreach (var day in travelPlan.Plans)
{
    Console.WriteLine();
    Console.WriteLine($"【第 {day.Day} 天】{day.Title}");
    Console.WriteLine($"  預估花費：${day.EstimatedCost:N0}");
    Console.WriteLine($"  住宿：{day.Accommodation}");
    Console.WriteLine("  行程：");
    foreach (var activity in day.Activities)
    {
        Console.WriteLine($"    • {activity}");
    }
}

Console.WriteLine();
Console.WriteLine(new string('─', 50));
Console.WriteLine("✅ 規劃完成！");
```

---

## 程式碼逐段解析

### 步驟 1：定義輸出模型

```csharp
[Description("A structured travel plan with daily activities")]
public class TravelPlan
{
    [JsonPropertyName("destination")]
    [Description("The primary travel destination")]
    public string Destination { get; set; } = string.Empty;
    // ...
}
```

這是 Planning Pattern 最重要的環節。你透過 C# 類別來定義「計畫」的結構。每個屬性都有兩個關鍵的 Attribute：

- **`[JsonPropertyName]`**：控制 JSON 中的 key 名稱。使用 snake_case 是慣例
- **`[Description]`**：告訴 LLM 這個欄位的語意。描述越精確，LLM 填入的內容越好

注意 `TravelPlan` 包含了 `List<DailyPlan>`，這展示了 Structured Output 也支援**巢狀物件與陣列**。

### 步驟 4：產生 Schema 並設定選項

```csharp
var travelPlanSchema = AIJsonUtilities.CreateJsonSchema(
    type: typeof(TravelPlan),
    inferenceOptions: new AIJsonSchemaCreateOptions
    {
        IncludeSchemaKeyword = false,
        DisallowAdditionalProperties = true,
        RequireAllProperties = true
    }
);
```

`AIJsonUtilities.CreateJsonSchema()` 是 `System.Text.Json` 提供的工具方法，能從 C# 類別自動產生 JSON Schema。三個選項的意義：

| 選項 | 說明 |
|------|------|
| `IncludeSchemaKeyword = false` | 不在 Schema 中加入 `$schema` 關鍵字，OpenAI API 不需要它 |
| `DisallowAdditionalProperties = true` | 禁止 LLM 輸出 Schema 未定義的額外屬性 |
| `RequireAllProperties = true` | 所有屬性都是必填，LLM 不能跳過任何欄位 |

然後用 `ChatResponseFormat.ForJsonSchema()` 把 Schema 包裝為回應格式設定：

```csharp
var chatOptions = new ChatOptions
{
    ResponseFormat = ChatResponseFormat.ForJsonSchema(
        schema: travelPlanSchema,
        schemaName: "TravelPlan",
        schemaDescription: "A structured travel plan with daily activities"
    )
};
```

### 步驟 5：執行與反序列化

```csharp
var response = await agent.RunAsync(
    session, userRequest,
    new AgentRunOptions { ChatOptions = chatOptions }
);

var jsonResponse = response.Message.Text ?? string.Empty;
var travelPlan = JsonSerializer.Deserialize<TravelPlan>(jsonResponse);
```

由於我們使用了 JSON Schema 約束，`response.Message.Text` **一定是合法的 JSON**（只要模型支援 Structured Output）。因此可以直接用 `JsonSerializer.Deserialize<T>()` 反序列化為強型別物件，不需要額外的錯誤處理或格式清理。

---

## 執行流程圖

```mermaid
sequenceDiagram
    participant User as 使用者
    participant App as 應用程式
    participant Agent as AIAgent
    participant LLM as LLM（GPT-4o）

    User->>App: "我想去日本東京玩 5 天..."
    App->>Agent: RunAsync(thread, message, chatOptions)
    Agent->>LLM: 發送 prompt + JSON Schema 約束
    Note over LLM: 根據 Schema 生成<br/>結構化 JSON 回應
    LLM-->>Agent: 回傳 JSON 字串
    Agent-->>App: AgentResponse
    App->>App: JsonSerializer.Deserialize<TravelPlan>()
    App-->>User: 呈現結構化的每日行程
```

---

## 執行結果範例

```text
=== 旅行規劃代理 ===

使用者：我想去日本東京玩 5 天，預算大約 2000 美元，喜歡美食和文化體驗

規劃中...

📍 目的地：東京，日本
📅 天數：5 天
💰 預估總預算：$1,950

──────────────────────────────────────────────────

【第 1 天】淺草與傳統文化
  預估花費：$350
  住宿：淺草區商務旅館
  行程：
    • 上午：參觀淺草寺與仲見世商店街
    • 中午：在淺草品嚐天婦羅定食
    • 下午：搭乘隅田川水上巴士至台場
    • 晚上：台場 teamLab Borderless 數位藝術美術館

【第 2 天】築地與銀座美食之旅
  預估花費：$400
  住宿：銀座區飯店
  行程：
    • 上午：築地外市場早餐（海鮮丼、玉子燒）
    • 中午：銀座區散步與購物
    • 下午：參觀東京國立近代美術館
    • 晚上：在銀座體驗懷石料理

【第 3 天】原宿與澀谷現代文化
  預估花費：$380
  住宿：澀谷區旅館
  行程：
    • 上午：明治神宮參拜
    • 中午：竹下通街頭美食巡禮
    • 下午：表參道設計建築散步
    • 晚上：澀谷十字路口夜景與居酒屋體驗

【第 4 天】秋葉原與上野
  預估花費：$420
  住宿：上野區飯店
  行程：
    • 上午：秋葉原電器街與動漫文化探索
    • 中午：在秋葉原品嚐拉麵
    • 下午：上野公園與東京國立博物館
    • 晚上：阿美橫町市場小吃巡禮

【第 5 天】新宿與最後巡禮
  預估花費：$400
  住宿：（返程）
  行程：
    • 上午：新宿御苑散步
    • 中午：新宿思出橫丁燒鳥
    • 下午：採購伴手禮
    • 晚上：前往成田/羽田機場

──────────────────────────────────────────────────
✅ 規劃完成！
```

---

## Planning Pattern vs 純文字回應

| 比較項目 | 純文字回應 | Planning Pattern（Structured Output） |
|----------|-----------|--------------------------------------|
| **輸出格式** | 自由文字，格式不固定 | 嚴格符合 JSON Schema |
| **程式處理** | 需要複雜的文字解析 | 直接反序列化為強型別物件 |
| **可靠性** | LLM 可能偶爾忘記遵循格式 | 模型層級強制，100% 符合格式 |
| **可擴展性** | 難以自動處理或串接 | 可直接傳入下一個代理或儲存到資料庫 |
| **巢狀結構** | 難以表達複雜的階層關係 | 原生支援物件巢狀與陣列 |

---

## 延伸練習

### 練習 1：自訂不同的計畫模型

試著定義一個會議規劃模型，讓代理產生結構化的會議議程：

```csharp
[Description("A structured meeting agenda")]
public class MeetingPlan
{
    [JsonPropertyName("meeting_title")]
    [Description("Title of the meeting")]
    public string Title { get; set; } = string.Empty;

    [JsonPropertyName("duration_minutes")]
    [Description("Total meeting duration in minutes")]
    public int DurationMinutes { get; set; }

    [JsonPropertyName("agenda_items")]
    [Description("Ordered list of agenda items")]
    public List<AgendaItem> AgendaItems { get; set; } = [];
}

public class AgendaItem
{
    [JsonPropertyName("topic")]
    public string Topic { get; set; } = string.Empty;

    [JsonPropertyName("duration_minutes")]
    public int DurationMinutes { get; set; }

    [JsonPropertyName("presenter")]
    public string Presenter { get; set; } = string.Empty;
}
```

### 練習 2：結合 Tools 與 Planning

將 Planning Pattern 與第 05 章學到的 Tools 結合——先讓代理呼叫工具取得即時資訊（天氣、匯率），再根據資訊產生結構化計畫。

### 練習 3：計畫的迭代修正

建立多輪對話，讓使用者可以針對代理產出的計畫提出修改要求，代理每次都重新產生完整的結構化計畫：

```csharp
var session = await agent.CreateSessionAsync();

// 第一輪：產生初始計畫
var response1 = await agent.RunAsync(
    session, "規劃一趟東京 5 日遊，預算 2000 美元",
    new AgentRunOptions { ChatOptions = chatOptions }
);
// ... 呈現計畫 ...

// 第二輪：修改計畫
var response2 = await agent.RunAsync(
    session, "第三天改去鎌倉，其他天不變",
    new AgentRunOptions { ChatOptions = chatOptions }
);
// ... 呈現修改後的計畫 ...
```

由於使用了 `AgentSession`，代理記得之前的對話脈絡，能夠在保留原有計畫的基礎上進行局部修改。

---

## 小結

Planning Pattern 的核心價值在於：

1. **用 C# 類別定義輸出結構**：透過 `[JsonPropertyName]` 和 `[Description]` 讓 LLM 理解期望的輸出格式
2. **用 JSON Schema 約束輸出**：`AIJsonUtilities.CreateJsonSchema()` + `ChatResponseFormat.ForJsonSchema()` 確保模型回應一定是合法的 JSON
3. **強型別反序列化**：`JsonSerializer.Deserialize<T>()` 讓你以物件導向的方式處理代理的回應

這個模式特別適合需要**程式化處理代理回應**的場景：自動化工作流程、資料管線、API 回應、報表生成等。在後續的進階篇中，我們會看到 Planning Pattern 如何與 Multi-Agent 協作搭配，讓一個代理負責規劃、其他代理負責執行。

---

> **返回目錄**：[README](README.md) | **上一章**：[08 — 範例實作：RAG Search](./08-example-rag-search.md) | **下一章**：[10 — 範例實作：Multi-Agent 初探](./10-example-multi-agent.md)
