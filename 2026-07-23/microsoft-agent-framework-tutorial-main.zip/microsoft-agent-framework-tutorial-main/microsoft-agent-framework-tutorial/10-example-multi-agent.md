# 10 — 範例實作：Multi-Agent 初探

> 本章透過官方的 Multi-Agent 範例，展示如何讓多個代理**分工協作**，在工作流程中依序處理使用者的需求。
>
> 對應官方範例：[Agent-Framework-Samples/00.ForBeginners/08-multi-agent](https://github.com/microsoft/Agent-Framework-Samples/tree/main/00.ForBeginners/08-multi-agent)
>
> 參考文件：[Agents in Workflows — Microsoft Learn](https://learn.microsoft.com/en-us/agent-framework/workflows/agents-in-workflows)

---

## 為什麼需要 Multi-Agent

在前面的章節中，我們使用的都是**單一代理**。單一代理適合處理範圍明確的任務，但當需求變複雜時，會遇到幾個問題：

1. **Instructions 過長**：把所有職責塞在一個 prompt 裡，LLM 容易遺漏或混淆
2. **工具過多**：單一代理掛載太多工具，模型選擇正確工具的準確度會下降
3. **職責不清**：一個代理同時負責接待、查詢、規劃、回覆，難以維護

Multi-Agent（多代理）的解決方式是：**讓每個代理專注於單一職責**，透過工作流程串聯起來，就像公司裡不同部門各司其職一樣。

### 單一代理 vs 多代理

```mermaid
flowchart LR
    subgraph single["單一代理"]
        direction TB
        A1["一個代理\n負責所有事"]
    end

    subgraph multi["多代理"]
        direction TB
        B1["前台代理\n接待 + 分類"] --> B2["專業代理 A\n旅行規劃"]
        B1 --> B3["專業代理 B\n預算計算"]
        B1 --> B4["專業代理 C\n訂票服務"]
    end

    style single fill:#FFF3CD,stroke:#FFC107,color:#333
    style multi fill:#D4EDDA,stroke:#28A745,color:#333
```

---

## 核心概念：Workflow

Microsoft Agent Framework 使用 `Microsoft.Agents.AI.Workflows` 套件提供工作流程（Workflow）能力，讓多個代理能在一個有向圖（Directed Graph）中協作。

### 關鍵元件

```mermaid
flowchart TD
    WB["WorkflowBuilder\n建構工作流程"] --> Edge["AddEdge()\n定義代理間的連線"]
    Edge --> WF["Workflow\n不可變的工作流程定義"]
    WF --> Exec["InProcessExecution\n.RunStreamingAsync()\n執行工作流程"]
    Exec --> SR["StreamingRun\n串流執行實例"]
    SR --> Events["WorkflowEvent\n即時事件串流"]

    style WB fill:#E8F0FE,stroke:#4A90D9,color:#333
    style Exec fill:#FFF3CD,stroke:#FFC107,color:#333
    style Events fill:#D4EDDA,stroke:#28A745,color:#333
```

| 元件 | 說明 |
|------|------|
| **WorkflowBuilder** | 用 Fluent API 建構工作流程，定義代理與代理之間的連線 |
| **AddEdge()** | 在兩個代理之間建立有向邊，定義訊息傳遞的方向 |
| **Workflow** | 建構完成後的不可變物件，描述完整的代理協作拓撲 |
| **InProcessExecution** | 在當前程序中執行工作流程 |
| **StreamingRun** | 代表一次執行中的工作流程，支援串流事件監控 |
| **WorkflowEvent** | 工作流程執行過程中發出的事件 |

---

## 範例情境

我們要建立一個**旅行服務系統**，包含兩個代理：

1. **前台代理（FrontDesk）**：負責接待使用者，理解需求，進行初步分類
2. **旅行顧問代理（Concierge）**：負責提供詳細的旅行建議與行程規劃

使用者的訊息先經過前台代理整理，再轉交給旅行顧問產生最終回覆。

### 架構圖

```mermaid
flowchart LR
    User["使用者"] --> FD["前台代理\n(FrontDesk)\n理解需求、整理重點"]
    FD --> CG["旅行顧問\n(Concierge)\n提供專業建議"]
    CG --> Output["最終回覆"]

    style FD fill:#E8F0FE,stroke:#4A90D9,color:#333
    style CG fill:#D4EDDA,stroke:#28A745,color:#333
```

---

## 完整範例程式碼

```csharp
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Extensions.AI;
using OpenAI;

// ============================================================
// 步驟 1：建立 LLM 用戶端
// ============================================================

// --- 選項 A：使用 OpenAI ---
IChatClient chatClient = new OpenAIClient(
    Environment.GetEnvironmentVariable("OPENAI_API_KEY")
).GetChatClient("gpt-4o").AsIChatClient();

// --- 選項 B：使用 Azure OpenAI ---
// IChatClient chatClient = new AzureOpenAIClient(
//     new Uri(Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!),
//     new Azure.AzureKeyCredential(
//         Environment.GetEnvironmentVariable("AZURE_OPENAI_API_KEY")!)
// ).GetChatClient("gpt-4o").AsIChatClient();

// --- 選項 C：使用 GitHub Models（免費） ---
// IChatClient chatClient = new OpenAIClient(
//     new System.ClientModel.ApiKeyCredential(
//         Environment.GetEnvironmentVariable("GITHUB_TOKEN")!),
//     new OpenAIClientOptions
//     {
//         Endpoint = new Uri("https://models.inference.ai.azure.com")
//     }
// ).GetChatClient("gpt-4o").AsIChatClient();

// ============================================================
// 步驟 2：定義代理
// ============================================================

// 前台代理：負責理解使用者需求並整理成結構化的摘要
var frontDesk = chatClient.AsAIAgent("""
    你是旅行服務中心的前台接待。你的工作是：
    1. 理解使用者的旅行需求
    2. 整理出關鍵資訊（目的地、天數、預算、偏好）
    3. 用清楚條列的方式將需求摘要轉交給旅行顧問

    請注意：
    - 如果使用者的需求不夠具體，請根據合理假設補充
    - 輸出格式為條列式的需求摘要，方便旅行顧問理解
    """);

// 旅行顧問代理：根據前台整理的需求，提供專業的旅行建議
var concierge = chatClient.AsAIAgent("""
    你是一位資深旅行顧問。你會收到前台整理好的使用者需求摘要。
    根據這些需求，提供詳細的旅行建議，包括：
    1. 推薦行程概要
    2. 必去景點與活動
    3. 美食推薦
    4. 交通建議
    5. 預算分配建議
    6. 注意事項與旅行小提示

    請用友善、專業的語氣回覆使用者。
    """);

// ============================================================
// 步驟 3：建構工作流程
// ============================================================

// 使用 WorkflowBuilder 建立有向圖
var workflow = new WorkflowBuilder(frontDesk)
    .AddEdge(frontDesk, concierge)  // 前台 → 旅行顧問
    .WithOutputFrom(concierge)       // 最終輸出來自旅行顧問
    .Build();

// ============================================================
// 步驟 4：執行工作流程（串流模式）
// ============================================================

Console.WriteLine("=== 旅行服務中心（Multi-Agent）===");
Console.WriteLine();

var userMessage = "我跟女朋友想去峇里島度假，大概五天四夜，想要放鬆但也想體驗當地文化";
Console.WriteLine($"使用者：{userMessage}");
Console.WriteLine();

// 建立初始訊息
var initialMessage = new ChatMessage(ChatRole.User, userMessage);

// 以串流模式執行工作流程
await using var run = await InProcessExecution.RunStreamingAsync(
    workflow, initialMessage);

// ============================================================
// 步驟 5：監控工作流程事件
// ============================================================

Console.WriteLine("--- 工作流程執行中 ---");
Console.WriteLine();

await foreach (var evt in run.WatchStreamAsync())
{
    switch (evt)
    {
        case ExecutorInvokedEvent invoked:
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"[代理啟動] {invoked.ExecutorId}");
            Console.ResetColor();
            break;

        case AgentResponseUpdateEvent update:
            // 串流輸出：逐字顯示代理的回應
            Console.Write(update.Update.Text);
            break;

        case ExecutorCompletedEvent completed:
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"[代理完成] {completed.ExecutorId}");
            Console.ResetColor();
            Console.WriteLine();
            break;

        case WorkflowOutputEvent output:
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("--- 工作流程完成 ---");
            Console.ResetColor();
            break;

        case WorkflowErrorEvent error:
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"[錯誤] {error.Data}");
            Console.ResetColor();
            break;
    }
}

Console.WriteLine();
Console.WriteLine("✅ 所有代理已完成工作！");
```

---

## 程式碼逐段解析

### 步驟 2：定義代理

```csharp
var frontDesk = chatClient.AsAIAgent("""
    你是旅行服務中心的前台接待。你的工作是：
    1. 理解使用者的旅行需求
    2. 整理出關鍵資訊（目的地、天數、預算、偏好）
    3. 用清楚條列的方式將需求摘要轉交給旅行顧問
    """);

var concierge = chatClient.AsAIAgent("""
    你是一位資深旅行顧問。...
    """);
```

每個代理都使用相同的 `chatClient`（相同的 LLM），但有**不同的 Instructions**。這是 Multi-Agent 的關鍵：不是使用不同的模型，而是透過不同的 prompt 讓同一個模型扮演不同角色。

當然，你也可以為不同代理使用不同的 LLM（例如前台用 GPT-4o-mini 節省成本，顧問用 GPT-4o 確保品質），只需要建立多個 `IChatClient` 即可。

### 步驟 3：建構工作流程

```csharp
var workflow = new WorkflowBuilder(frontDesk)
    .AddEdge(frontDesk, concierge)
    .WithOutputFrom(concierge)
    .Build();
```

這是最核心的部分。讓我們拆解每一行：

| 程式碼 | 說明 |
|--------|------|
| `new WorkflowBuilder(frontDesk)` | 建立工作流程，以 `frontDesk` 作為**起始節點**（接收使用者訊息的第一個代理） |
| `.AddEdge(frontDesk, concierge)` | 建立有向邊：`frontDesk` 的輸出會傳遞給 `concierge` 作為輸入 |
| `.WithOutputFrom(concierge)` | 指定 `concierge` 的輸出作為**整個工作流程的最終輸出** |
| `.Build()` | 建構不可變的 `Workflow` 物件 |

整個工作流程的拓撲就是一個簡單的序列：`使用者 → frontDesk → concierge → 輸出`。

### 步驟 4：串流執行

```csharp
await using var run = await InProcessExecution.RunStreamingAsync(
    workflow, initialMessage);
```

`InProcessExecution.RunStreamingAsync()` 會在當前程序中啟動工作流程的執行。它回傳一個 `StreamingRun` 物件，你可以用它來監控執行過程中的事件。

注意 `await using` — `StreamingRun` 實作了 `IAsyncDisposable`，確保資源會被正確釋放。

### 步驟 5：事件監控

```csharp
await foreach (var evt in run.WatchStreamAsync())
{
    switch (evt)
    {
        case ExecutorInvokedEvent invoked:
            // 代理開始處理
            break;
        case AgentResponseUpdateEvent update:
            // 代理正在串流輸出（逐字）
            Console.Write(update.Update.Text);
            break;
        case ExecutorCompletedEvent completed:
            // 代理完成處理
            break;
        case WorkflowOutputEvent output:
            // 整個工作流程完成
            break;
    }
}
```

`run.WatchStreamAsync()` 回傳 `IAsyncEnumerable<WorkflowEvent>`，你可以用 `await foreach` 來即時接收事件。每個事件都是 `WorkflowEvent` 的子類別：

```mermaid
flowchart TD
    WE["WorkflowEvent\n（基底類別）"]
    WE --> EI["ExecutorInvokedEvent\n代理開始處理"]
    WE --> EC["ExecutorCompletedEvent\n代理完成處理"]
    WE --> EF["ExecutorFailedEvent\n代理處理失敗"]
    WE --> ARU["AgentResponseUpdateEvent\n代理串流輸出（逐字）"]
    WE --> WO["WorkflowOutputEvent\n工作流程輸出"]
    WE --> WErr["WorkflowErrorEvent\n工作流程錯誤"]
    WE --> SSS["SuperstepStartedEvent\n超步開始"]
    WE --> SSC["SuperstepCompletedEvent\n超步完成"]

    style WE fill:#E8F0FE,stroke:#4A90D9,color:#333
    style ARU fill:#D4EDDA,stroke:#28A745,color:#333
    style WO fill:#FFF3CD,stroke:#FFC107,color:#333
```

---

## 執行結果範例

```text
=== 旅行服務中心（Multi-Agent）===

使用者：我跟女朋友想去峇里島度假，大概五天四夜，想要放鬆但也想體驗當地文化

--- 工作流程執行中 ---

[代理啟動] FrontDesk

📋 需求摘要：
- 目的地：峇里島（印尼）
- 旅行天數：5 天 4 夜
- 旅伴：情侶（2 人）
- 旅行風格：度假放鬆 + 文化體驗
- 預算：未指定（建議中等價位）
- 特殊需求：無

[代理完成] FrontDesk

[代理啟動] Concierge

🌴 峇里島五天四夜度假行程建議

很高興為您和女朋友規劃這趟峇里島之旅！以下是兼顧放鬆
與文化體驗的行程建議...

（詳細的行程規劃內容，包含景點、美食、交通、預算等）

[代理完成] Concierge

--- 工作流程完成 ---

✅ 所有代理已完成工作！
```

---

## 工作流程的訊息傳遞機制

理解 Multi-Agent 工作流程中訊息如何傳遞非常重要：

```mermaid
sequenceDiagram
    participant User as 使用者
    participant WF as Workflow Engine
    participant FD as FrontDesk 代理
    participant CG as Concierge 代理

    User->>WF: "我想去峇里島..."
    WF->>FD: ChatMessage(User, "我想去峇里島...")
    Note over FD: 理解需求<br/>整理摘要
    FD-->>WF: "📋 需求摘要：目的地=峇里島..."
    WF->>CG: ChatMessage(Assistant, "📋 需求摘要：...")
    Note over CG: 根據摘要<br/>產生旅行建議
    CG-->>WF: "🌴 峇里島行程建議..."
    WF-->>User: 最終輸出（來自 Concierge）
```

1. 使用者的訊息先送到**起始節點**（FrontDesk）
2. FrontDesk 處理完後，輸出透過 Edge 傳遞給 Concierge
3. Concierge 收到的是 FrontDesk 的輸出，而非原始使用者訊息
4. 被標記為 `WithOutputFrom` 的代理的輸出，就是整個工作流程的最終結果

---

## 延伸練習

### 練習 1：加入第三個代理

在 Concierge 之後加入一個「品質審核代理」，檢查行程建議是否合理：

```csharp
var reviewer = chatClient.AsAIAgent("""
    你是旅行計畫的品質審核員。
    檢查行程建議是否有以下問題：
    - 行程是否過於緊湊
    - 預算分配是否合理
    - 是否遺漏了重要的旅行建議（簽證、保險等）
    如果發現問題，請指出並提供改善建議。
    如果沒有問題，請確認計畫品質良好。
    """);

var workflow = new WorkflowBuilder(frontDesk)
    .AddEdge(frontDesk, concierge)
    .AddEdge(concierge, reviewer)     // 旅行顧問 → 品質審核
    .WithOutputFrom(reviewer)          // 最終輸出來自審核員
    .Build();
```

### 練習 2：為不同代理使用不同模型

嘗試為前台代理使用較便宜的模型，為顧問代理使用較強的模型：

```csharp
// 前台用 GPT-4o-mini（節省成本）
IChatClient frontDeskClient = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o-mini").AsIChatClient();

// 顧問用 GPT-4o（確保品質）
IChatClient conciergeClient = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o").AsIChatClient();

var frontDesk = frontDeskClient.AsAIAgent("你是前台接待...");
var concierge = conciergeClient.AsAIAgent("你是資深旅行顧問...");
```

### 練習 3：結合 Tools 與 Multi-Agent

讓旅行顧問代理掛載工具，在工作流程中呼叫外部 API：

```csharp
var weatherTool = AIFunctionFactory.Create(
    (string city) => $"{city} 目前天氣：28°C，晴天",
    "GetWeather",
    "取得指定城市的天氣資訊"
);

var concierge = chatClient.AsAIAgent(new AIAgentOptions
{
    Instructions = "你是一位資深旅行顧問...",
    Tools = [weatherTool]
});
```

---

## 從入門到進階的銜接

本章展示的是最基本的**序列式（Sequential）** Multi-Agent 工作流程。Microsoft Agent Framework 的工作流程引擎還支援更多進階模式，這些將在後續的進階篇中詳細介紹：

| 模式 | 說明 | 適用場景 |
|------|------|----------|
| **Sequential** | 代理依序執行（本章範例） | 流水線式處理 |
| **Concurrent** | 多個代理同時執行 | 平行處理獨立任務 |
| **Handoff** | 代理之間動態轉交控制權 | 客服路由、專家諮詢 |
| **Group Chat** | 多個代理在群組中討論 | 腦力激盪、多觀點分析 |
| **Graph-based** | 複雜的有向圖拓撲 | 進階業務流程 |

此外，進階篇還會涵蓋：

- **A2A（Agent-to-Agent）協定**：跨服務的代理間通訊
- **MCP（Model Context Protocol）**：標準化的外部工具整合
- **AG-UI（Agent-User Interaction）協定**：代理與使用者介面的標準化互動
- **ASP.NET Core 託管**：將代理部署為 Web API 服務
- **可觀測性**：使用 OpenTelemetry 監控代理行為

---

## 小結

Multi-Agent 工作流程的核心概念：

1. **每個代理專注單一職責**：透過明確的 Instructions 讓代理各司其職
2. **WorkflowBuilder 建構拓撲**：使用 `AddEdge()` 定義代理間的有向連線
3. **StreamingRun 監控執行**：透過 `WatchStreamAsync()` 即時追蹤每個代理的狀態
4. **WorkflowEvent 事件驅動**：用 pattern matching 處理不同類型的工作流程事件

掌握了這個基本模式，你就有了足夠的基礎去理解更複雜的多代理協作架構。

---

> **返回目錄**：[README](README.md) | **上一章**：[09 — 範例實作：Planning Pattern](./09-example-planning.md) | **下一章**：[11 — ASP.NET Core WebAPI 整合](./11-aspnetcore-webapi.md)
