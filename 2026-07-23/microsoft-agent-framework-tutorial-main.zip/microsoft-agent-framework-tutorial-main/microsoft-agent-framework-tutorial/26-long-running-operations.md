# 26 — Long-Running Operations（長時間執行操作）

> 本章介紹 Agent Framework 對長時間執行操作的支援。當代理需要處理複雜任務（程式碼生成、文件處理、大規模資料分析）時，傳統的同步 request-response 模式不再適用。
>
> 對應官方決策：[ADR 0009 — Support Long-Running Operations](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0009-support-long-running-operations.md)（Accepted, 2025-10-15）

---

## 為什麼需要 Long-Running Operations

在前面的章節中，我們使用的 `RunAsync` / `RunStreamingAsync` 都是**同步等待**模式——呼叫後就阻塞直到回應完成。這在簡單問答場景沒問題，但許多真實場景的任務可能需要數分鐘甚至數小時：

- 大型程式碼庫的分析與重構建議
- 多文件的批次摘要或翻譯
- 需要多輪工具呼叫的複雜研究任務
- 等待外部系統回應的整合流程

Long-Running Operations 讓你可以**提交任務、追蹤進度、稍後取回結果**，而不需要持續佔用連線。

---

## 核心架構

```mermaid
sequenceDiagram
    participant Client as 呼叫端
    participant Agent as AIAgent
    participant LLM as LLM / 外部服務

    Client->>Agent: StartAsyncRunAsync（提交任務）
    Agent-->>Client: AsyncRunResult（含 RunId）
    Note over Client: 可以去做其他事

    loop 輪詢或等待通知
        Client->>Agent: GetAsyncRunStatusAsync（RunId）
        Agent-->>Client: AsyncRunResult（InProgress / Completed / ...）
    end

    Client->>Agent: GetAsyncRunResultAsync（RunId）
    Agent-->>Client: AgentResponse（完整回應）
```

---

## IAsyncChatClient 介面

Long-Running Operations 的核心是 `IAsyncChatClient` 介面，它是一個獨立的介面，由支援非同步長時間操作的提供者實作：

```csharp
using Microsoft.Agents.AI;

public interface IAsyncChatClient
{
    Task<AsyncRunResult> StartAsyncRunAsync(
        IList<ChatMessage> messages,
        RunOptions? options = null,
        CancellationToken ct = default);

    Task<AsyncRunResult> GetAsyncRunStatusAsync(
        string runId,
        CancellationToken ct = default);

    Task<AsyncRunResult> GetAsyncRunResultAsync(
        string runId,
        CancellationToken ct = default);

    Task<AsyncRunResult> CancelAsyncRunAsync(
        string runId,
        CancellationToken ct = default);

    Task<AsyncRunResult> DeleteAsyncRunAsync(
        string runId,
        CancellationToken ct = default);
}
```

### 取得 IAsyncChatClient

```csharp
// IAsyncChatClient 透過 GetService<T>() 模式取得
var asyncClient = chatClient.GetService<IAsyncChatClient>();

if (asyncClient is null)
{
    Console.WriteLine("此提供者不支援 Long-Running Operations");
    return;
}
```

### 支援的提供者

| 提供者 | 支援方式 |
|--------|---------|
| Azure AI Foundry Agents | 原生 async run |
| OpenAI Responses API | Background mode |
| A2A Protocol | Task 狀態輪詢 |

---

## AsyncRunResult 與 AsyncRunStatus

### AsyncRunResult

代表一次非同步執行的元資料：

```csharp
public class AsyncRunResult
{
    /// <summary>執行的唯一識別碼</summary>
    public string RunId { get; }

    /// <summary>目前的執行狀態</summary>
    public AsyncRunStatus Status { get; }

    /// <summary>是否已完成（Completed / Failed / Cancelled / Expired）</summary>
    public bool IsCompleted { get; }

    /// <summary>預估完成時間（如果提供者支援）</summary>
    public DateTimeOffset? EstimatedCompletionTime { get; }
}
```

### AsyncRunStatus

追蹤操作的生命週期狀態：

```csharp
public enum AsyncRunStatus
{
    Queued,         // 已排入佇列，等待處理
    InProgress,     // 正在執行中
    Completed,      // 已完成，可取得結果
    Failed,         // 執行失敗
    Cancelled,      // 已被取消
    Expired         // 已過期
}
```

---

## 使用模式：提交 → 輪詢 → 取得結果

### 基本流程

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

var asyncClient = chatClient.GetService<IAsyncChatClient>()
    ?? throw new InvalidOperationException("提供者不支援 Long-Running Operations");

var messages = new List<ChatMessage>
{
    new(ChatRole.User, "請分析這份 500 頁的技術文件，摘要每個章節的重點")
};

// ============================================================
// 步驟 1：提交長時間任務
// ============================================================

AsyncRunResult runResult = await asyncClient.StartAsyncRunAsync(messages);

Console.WriteLine($"任務已提交，RunId：{runResult.RunId}");
Console.WriteLine($"狀態：{runResult.Status}");

// ============================================================
// 步驟 2：輪詢狀態
// ============================================================

while (!runResult.IsCompleted)
{
    await Task.Delay(TimeSpan.FromSeconds(5)); // 等待 5 秒後再檢查

    runResult = await asyncClient.GetAsyncRunStatusAsync(runResult.RunId);
    Console.WriteLine($"狀態：{runResult.Status}");
}

// ============================================================
// 步驟 3：取得結果
// ============================================================

if (runResult.Status == AsyncRunStatus.Completed)
{
    AsyncRunResult finalRun = await asyncClient.GetAsyncRunResultAsync(runResult.RunId);
    Console.WriteLine($"任務完成，RunId：{finalRun.RunId}");
    // finalRun 包含完整回應內容
}
else
{
    Console.WriteLine($"任務未成功完成，狀態：{runResult.Status}");
}
```

### 透過 AIAgent 的高階存取

若直接使用 `AIAgent`，當代理判斷任務需要長時間執行時，會透過 `AgentResponse.AgentRun` 傳回訊號（`ChatFinishReason.LongRunning`）：

```csharp
using Microsoft.Agents.AI;

// RunAsync 回傳 AgentResponse
AgentResponse response = await agent.RunAsync(
    "請分析這份 500 頁的技術文件");

// AgentRun 不為 null 表示任務正在背景執行
if (response.AgentRun != null)
{
    Console.WriteLine($"任務正在背景執行，RunId：{response.AgentRun.RunId}");

    // 輪詢直到完成
    while (!response.AgentRun.IsCompleted)
    {
        await Task.Delay(TimeSpan.FromSeconds(5));
        response = await agent.GetRunResultAsync(response.AgentRun.RunId);
        Console.WriteLine($"狀態：{response.AgentRun?.Status}");
    }

    Console.WriteLine($"結果：{response.Text}");
}
else
{
    // 任務已同步完成（提供者不支援或任務夠快）
    Console.WriteLine($"同步結果：{response.Text}");
}
```

---

## 取消長時間任務

透過 `IAsyncChatClient` 可以取消正在執行的任務：

```csharp
// 使用 IAsyncChatClient 取消
await asyncClient.CancelAsyncRunAsync(runResult.RunId);
Console.WriteLine("任務已取消");

// 使用 AIAgent 取消
await agent.CancelRunAsync(response.AgentRun.RunId);
Console.WriteLine("任務已取消");
```

---

## 與 Durable Agents 的關係

| 面向 | Long-Running Operations | Durable Agents |
|------|------------------------|----------------|
| 層級 | `IAsyncChatClient` 介面層 | `AIAgent` 層級 |
| 持久化 | 由提供者管理（通常在雲端） | 明確使用 Durable Task Scheduler |
| 適用場景 | 單次長時間 LLM 呼叫 | 多步驟有狀態的代理對話 |
| 恢復機制 | 透過 `RunId` 輪詢 | 透過 Checkpoint 恢復 |
| 典型用途 | OpenAI Batch API、大文件分析 | 跨天的審批流程、多代理編排 |

兩者可以搭配使用：Durable Agent 的某一步可能就是發起一個 Long-Running Operation，等待其完成後再繼續下一步。

---

## 小結

Long-Running Operations 為 Agent Framework 提供了處理耗時任務的標準化模式：

1. **提交任務**：透過 `IAsyncChatClient.StartAsyncRunAsync()` 啟動，取得含 `RunId` 的 `AsyncRunResult`
2. **追蹤進度**：透過 `GetAsyncRunStatusAsync(RunId)` 輪詢 `AsyncRunStatus`
3. **取得結果**：完成後用 `GetAsyncRunResultAsync(RunId)` 取得最終回應
4. **取消任務**：透過 `CancelAsyncRunAsync(RunId)` 中止執行
5. **AIAgent 整合**：透過 `AgentResponse.AgentRun`（`ChatFinishReason.LongRunning`）感知長時間操作

### 延伸閱讀：官方 ADR 參考

- [ADR 0009 — Support Long-Running Operations](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0009-support-long-running-operations.md)：完整的設計決策過程，`IAsyncChatClient` 獨立介面設計，三步驟非同步操作模式

---

> **返回目錄**：[README](README.md) | **上一章**：[25 — MCP 整合](./25-mcp-integration.md) | **下一章**：[27 — Feature Collections](./27-feature-collections.md)
