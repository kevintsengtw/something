# 14 — Context Providers 深度：代理記憶體管理

> 本章深入介紹 `AIContextProvider`——Agent Framework 的記憶體注入機制。透過自訂 Context Provider，代理可以在對話中累積使用者資訊、注入動態背景知識，實現真正的個人化互動體驗。

---

## 什麼是 Context Provider

在 06 章中我們簡單提到 Context Providers 的概念。現在來深入理解它的設計：

**Context Provider 解決的問題**：LLM 本身是無狀態的，它只能看到傳入的訊息。如果你想讓代理「記住」使用者的姓名、偏好、過去的互動，你需要主動把這些資訊注入到每次對話中。

`AIContextProvider` 是 Agent Framework 提供的抽象基底類別，讓你可以在兩個關鍵時機插入邏輯：

```text
使用者輸入
    ↓
【StoreAIContextAsync】← 分析訊息，提取並儲存資訊
    ↓
【ProvideAIContextAsync】← 把已知資訊注入 System Prompt
    ↓
LLM 呼叫（帶有注入的上下文）
    ↓
代理回應
```

---

## AIContextProvider 抽象類別

```csharp
// Microsoft.Agents.AI 命名空間
public abstract class AIContextProvider
{
    /// <summary>
    /// LLM 呼叫完成後被呼叫。
    /// 分析本輪的訊息，提取並儲存有用資訊（如使用者姓名）。
    /// context.RequestMessages 包含本輪對話訊息；context.Session 存取對話狀態。
    /// </summary>
    protected virtual ValueTask StoreAIContextAsync(
        InvokedContext context,
        CancellationToken cancellationToken = default)
        => ValueTask.CompletedTask;

    /// <summary>
    /// 在 LLM 呼叫前被呼叫（StoreAIContextAsync 之後）。
    /// 回傳 AIContext，其 Instructions 屬性的內容將作為額外 System 指令注入到 LLM 請求中。
    /// context.Session 存取對話狀態；context.RequestMessages 包含目前對話訊息。
    /// </summary>
    protected abstract ValueTask<AIContext> ProvideAIContextAsync(
        InvokingContext context,
        CancellationToken cancellationToken = default);

    // Provider 狀態的 key 清單，用於 SerializeSessionAsync 時包含此 provider 的狀態
    public virtual IReadOnlyList<string> StateKeys => [];
}
```

**重點**：`ProvideAIContextAsync` 回傳的 `AIContext.Instructions` 字串會作為額外 System 指令插入到傳給 LLM 的訊息中，但**不會儲存進 AgentSession 的對話歷史**。這讓注入的上下文保持動態，每次呼叫都可以是最新的資訊。

---

## 實作一：UserInfoMemory（使用者資訊記憶）

這是官方範例中示範的最典型 Context Provider——在對話中學習使用者的個人資訊，並在後續互動中主動使用。

### 定義記憶體資料結構

```csharp
// Models/UserInfo.cs
public record UserInfo(
    string? Name = null,
    int? Age = null,
    string? Preferences = null
);
```

### 實作 AIContextProvider

```csharp
// Memory/UserInfoMemory.cs
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

public class UserInfoMemory : AIContextProvider
{
    // ProviderSessionState<T>：讓狀態跟著 session 走，並支援序列化
    private readonly ProviderSessionState<UserInfo> _sessionState;

    public UserInfoMemory()
    {
        _sessionState = new ProviderSessionState<UserInfo>(
            stateInitializer: _ => new UserInfo(),
            stateKey: this.GetType().Name);
    }

    // 供 SerializeSessionAsync / DeserializeSessionAsync 使用
    public override IReadOnlyList<string> StateKeys => [_sessionState.StateKey];

    // ── StoreAIContextAsync：LLM 回應後，分析訊息並儲存使用者資訊 ───────
    protected override async ValueTask StoreAIContextAsync(
        InvokedContext context,
        CancellationToken cancellationToken = default)
    {
        var state = _sessionState.GetOrInitializeState(context.Session);
        var lastUserMessage = context.RequestMessages
            .LastOrDefault(m => m.Role == ChatRole.User)?.Text ?? "";

        // 簡單的關鍵字提取（正式環境可用 LLM 解析）
        if (lastUserMessage.Contains("我叫") || lastUserMessage.Contains("我是"))
        {
            var name = ExtractName(lastUserMessage);
            if (name is not null)
                state = state with { Name = name };
        }

        if (lastUserMessage.Contains("歲") || lastUserMessage.Contains("年齡"))
        {
            var age = ExtractAge(lastUserMessage);
            if (age is not null)
                state = state with { Age = age };
        }

        _sessionState.SaveState(context.Session, state);
        await ValueTask.CompletedTask;
    }

    // ── ProvideAIContextAsync：LLM 呼叫前，把已知的使用者資訊注入 ──────────────
    protected override ValueTask<AIContext> ProvideAIContextAsync(
        InvokingContext context,
        CancellationToken cancellationToken = default)
    {
        var state = _sessionState.GetOrInitializeState(context.Session);

        if (state.Name is null && state.Age is null)
            return ValueTask.FromResult(new AIContext());

        var contextText = BuildContextText(state);
        return ValueTask.FromResult(new AIContext
        {
            Instructions = $"[已知的使用者資訊]\n{contextText}"
        });
    }

    // ── 公開方法：手動設定使用者資訊（如從資料庫載入）──────────
    public void SetUserInfo(AgentSession session, UserInfo userInfo)
        => _sessionState.SaveState(session, userInfo);

    public UserInfo GetUserInfo(AgentSession session)
        => _sessionState.GetOrInitializeState(session);

    // ── 私有輔助方法 ─────────────────────────────────────────────
    private static string BuildContextText(UserInfo state)
    {
        var parts = new List<string>();
        if (state.Name is not null) parts.Add($"姓名：{state.Name}");
        if (state.Age is not null) parts.Add($"年齡：{state.Age} 歲");
        if (state.Preferences is not null) parts.Add($"偏好：{state.Preferences}");
        return string.Join("\n", parts);
    }

    private static string? ExtractName(string text)
    {
        var patterns = new[] { "我叫", "我是", "名字是" };
        foreach (var pattern in patterns)
        {
            var idx = text.IndexOf(pattern, StringComparison.OrdinalIgnoreCase);
            if (idx >= 0)
            {
                var after = text[(idx + pattern.Length)..].Trim().Split(' ', '，', ',')[0];
                if (after.Length is > 0 and < 10) return after;
            }
        }
        return null;
    }

    private static int? ExtractAge(string text)
    {
        var match = System.Text.RegularExpressions.Regex.Match(text, @"(\d+)\s*歲");
        return match.Success ? int.Parse(match.Groups[1].Value) : null;
    }
}
```

### 建立並使用帶有記憶體的代理

```csharp
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI;

var endpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
var deployment = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME")!;

// 1. 建立記憶體提供者
var memory = new UserInfoMemory();

// 2. 建立代理（掛載 Context Provider）
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deployment)
    .AsAIAgent(new ChatClientAgentOptions
    {
        ChatOptions = new() { Instructions = "你是一個個人助理，請根據使用者資訊提供個人化回應。" },
        AIContextProviders = [memory],  // ← 注入 Context Provider
    });
// 建立代理名稱可透過 ChatClientAgentOptions.Name 設定

var session = await agent.CreateSessionAsync();

// 第一輪：代理學習使用者姓名
Console.WriteLine(await agent.RunAsync("你好！我叫小明，我今年 28 歲。", session));
// 輸出：「你好，小明！很高興認識你，28 歲正值青春...」

// 第二輪：代理使用已學到的資訊
Console.WriteLine(await agent.RunAsync("你記得我的名字嗎？", session));
// 輸出：「當然記得，你是小明！...」
```

---

## 實作二：DynamicSystemPrompt（動態系統提示）

當系統提示需要根據執行時期的資料動態產生時（如從資料庫拉取使用者角色），這個模式很實用：

```csharp
// Memory/RoleBasedContextProvider.cs
public class RoleBasedContextProvider : AIContextProvider
{
    private readonly IUserRoleRepository _roleRepo;

    public RoleBasedContextProvider(IUserRoleRepository roleRepo)
        => _roleRepo = roleRepo;

    protected override async ValueTask<AIContext> ProvideAIContextAsync(
        InvokingContext context,
        CancellationToken cancellationToken = default)
    {
        // 從 session 中取得使用者 ID（由外部設定，存入 AdditionalProperties）
        var userId = context.Session.AdditionalProperties.GetValueOrDefault("user_id") as string;
        if (userId is null) return new AIContext();

        var roles = await _roleRepo.GetUserRolesAsync(userId, cancellationToken);
        var permissions = string.Join("、", roles);

        return new AIContext
        {
            Instructions = $"當前使用者 ID：{userId}\n" +
                           $"使用者角色：{permissions}\n" +
                           "請根據使用者角色調整回應內容，對管理員顯示更詳細的資訊。"
        };
    }
}
```

---

## 實作三：SessionSummaryProvider（對話摘要壓縮）

當對話歷史過長時，可用摘要取代完整歷史，節省 Token：

```csharp
// Memory/SessionSummaryProvider.cs
public class SessionSummaryProvider : AIContextProvider
{
    private const int SummaryThreshold = 20; // 超過 20 則訊息才摘要
    private readonly ProviderSessionState<string?> _summaryState;

    public SessionSummaryProvider()
    {
        _summaryState = new ProviderSessionState<string?>(
            _ => null,
            this.GetType().Name);
    }

    public override IReadOnlyList<string> StateKeys => [_summaryState.StateKey];

    protected override async ValueTask StoreAIContextAsync(
        InvokedContext context,
        CancellationToken cancellationToken = default)
    {
        if (context.RequestMessages.Count < SummaryThreshold) return;

        // 只在尚未有摘要時才建立（避免每輪都摘要）
        var existing = _summaryState.GetOrInitializeState(context.Session);
        if (existing is not null) return;

        // 實際應用中，這裡呼叫 LLM 產生摘要
        var summary = $"[對話摘要] 至今共 {context.RequestMessages.Count} 則訊息，主要討論了...";
        _summaryState.SaveState(context.Session, summary);

        await ValueTask.CompletedTask;
    }

    protected override ValueTask<AIContext> ProvideAIContextAsync(
        InvokingContext context,
        CancellationToken cancellationToken = default)
    {
        var summary = _summaryState.GetOrInitializeState(context.Session);
        if (summary is null) return ValueTask.FromResult(new AIContext());

        return ValueTask.FromResult(new AIContext { Instructions = summary });
    }
}
```

---

## 多個 Context Provider 組合

代理可以同時掛載多個 Context Provider，它們會依序執行：

```csharp
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    ChatOptions = new() { Instructions = "你是企業內部助理" },
    AIContextProviders = [
        new UserInfoMemory(),                        // 使用者個人資訊
        new RoleBasedContextProvider(roleRepo),      // 角色與權限
        new SessionSummaryProvider(),                // 對話摘要
    ],
});
```

**執行順序**：

1. 依序呼叫每個 provider 的 `StoreAIContextAsync`
2. 依序呼叫每個 provider 的 `ProvideAIContextAsync`
3. 收集所有 `AIContext.Instructions` 並合併注入到 LLM 請求的 System 訊息中

---

## Session 序列化與跨程序持久化

`AgentSession` 連同所有 `ProviderSessionState<T>` 的狀態，可透過代理的序列化 API 完整儲存與還原：

```csharp
using System.Text.Json;

// 序列化 session（包含所有 Context Provider 的狀態）
JsonElement sessionElement = await agent.SerializeSessionAsync(session);
var serialized = sessionElement.GetRawText();
await redis.SetAsync($"session:{userId}", serialized);

// 下次請求時還原（自動還原所有 Provider 狀態）
var json = await redis.GetAsync($"session:{userId}");
using var doc = JsonDocument.Parse(json!);
var restoredSession = await agent.DeserializeSessionAsync(doc.RootElement);

// 跨 Session 共用記憶體（如使用者從不同裝置登入）
var userInfo = memory.GetUserInfo(previousSession);
var newSession = await agent.CreateSessionAsync();
memory.SetUserInfo(newSession, userInfo);
```

> **注意**：Context Provider 的狀態必須透過 `ProviderSessionState<T>` 管理，且 Provider 需覆寫 `StateKeys` 屬性，序列化才能正確包含其狀態。直接寫入 `session.AdditionalProperties` 的資料仍可使用 `JsonSerializer.Serialize(session)` 序列化，但 Provider 狀態的序列化/還原推薦使用代理的 API。

---

## Context Provider vs Middleware 的選擇

| 情境 | 建議使用 |
|------|----------|
| 需要在 LLM 呼叫前**注入動態資訊** | `AIContextProvider` |
| 需要**攔截並修改** LLM 請求/回應 | `IAgentMiddleware` |
| 需要**記錄日誌、計時**等橫切關注點 | `IAgentMiddleware` |
| 需要實作**個人化記憶**或**角色注入** | `AIContextProvider` |
| 需要**工具呼叫前的權限檢查** | `IFunctionMiddleware` |

---

### 延伸閱讀：官方 ADR 參考

- [ADR 0017 — AdditionalProperties](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0017-agent-additional-properties.md)：`AgentWithMetadata` 外部容器模式，metadata 與 per-run 擴展的區分設計

---

> **返回目錄**：[README](README.md) | **上一章**：[13 — Docker 部署](./13-docker-deployment.md) | **下一章**：[15 — 結構化輸出](./15-structured-output.md)
