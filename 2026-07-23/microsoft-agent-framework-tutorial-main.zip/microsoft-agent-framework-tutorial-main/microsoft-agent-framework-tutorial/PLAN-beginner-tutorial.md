# Microsoft Agent Framework C# 入門教學 — 製作計畫

> 建立日期：2026-03-28
> 最後更新：2026-04-16
> 目標語言：繁體中文
> 開發語言：C# / .NET
> 框架版本：Microsoft Agent Framework **1.1.0（穩定版，2026-04-10）**

---

## 專案目標

將 Microsoft Agent Framework 的英文資源整理為一套結構化的**繁體中文入門教學文件**，以 C# 開發者為目標讀者，涵蓋從概念認識到範例實作的完整學習路徑。

**範圍界定：** 僅涵蓋 Microsoft Agent Framework（核心開源框架），不包含 Microsoft 365 Agents SDK 與 Microsoft Foundry Agent Service。

**教學定位：** 入門教學。進階主題（MCP、A2A、Graph-based Workflows、ASP.NET Core 託管、可觀測性等）規劃於後續的進階篇中撰寫。

---

## 參考資源

### 官方儲存庫

| 資源 | 網址 | 用途 |
|------|------|------|
| 主儲存庫 | https://github.com/microsoft/agent-framework | 原始碼、架構、.NET 實作 |
| 範例儲存庫 | https://github.com/microsoft/Agent-Framework-Samples | C# 範例程式碼（00.ForBeginners 為主） |
| 社群彙整 | https://github.com/webmaxru/awesome-microsoft-agent-framework | 社群資源、教學、工具 |

### 官方文件

| 資源 | 網址 | 用途 |
|------|------|------|
| Framework Overview | https://learn.microsoft.com/en-us/agent-framework/overview/ | 架構概念、核心元件 |
| Quick Start | https://learn.microsoft.com/en-us/agent-framework/tutorials/quick-start | 快速入門教學 |
| Agent Types | https://learn.microsoft.com/en-us/agent-framework/agents/ | 代理類型說明 |
| Agent Framework Blog | https://devblogs.microsoft.com/agent-framework/ | 最新消息與深度文章 |
| AI Agents for Beginners | https://microsoft.github.io/ai-agents-for-beginners/14-microsoft-agent-framework/ | 初學者教程 |

### 範例對應（Agent-Framework-Samples/00.ForBeginners）

本教學的範例實作章節，以官方 `00.ForBeginners` 目錄下的範例為骨幹：

| 範例目錄 | 對應教學章節 | 學習重點 |
|----------|-------------|----------|
| Basic Agent | 04 建立你的第一個 Agent | 最基本的代理建立與對話 |
| Tool Use | 05 工具（Tools）基礎 | AIFunctionFactory、自訂工具 |
| Design Patterns | 06 Middleware 與 Context 基礎 | Middleware、Context Providers |
| Travel Agent | 07 範例實作：Travel Agent | 綜合應用、工具整合 |
| RAG Search | 08 範例實作：RAG Search | 檢索增強生成模式 |
| Planning | 09 範例實作：Planning Pattern | 代理規劃與推理能力 |
| Multi-Agent | 10 範例實作：Multi-Agent 初探 | 多代理協作入門 |

### NuGet 套件

| 套件名稱 | 用途 |
|----------|------|
| `Microsoft.Agents.AI` | 核心介面與抽象 |
| `Microsoft.Agents.AI.OpenAI` | OpenAI / Azure OpenAI 支援 |
| `Microsoft.Agents.AI.Workflows` | 工作流程編排 |
| `Microsoft.Agents.AI.Workflows.Declarative` | 宣告式工作流程定義 |
| `Microsoft.Agents.AI.Hosting` | ASP.NET Core 託管支援 |

---

## 章節規劃與製作進度

### 第一部分：認識框架

| # | 章節 | 檔案名稱 | 狀態 |
|---|------|----------|------|
| 01 | 什麼是 Microsoft Agent Framework | `01-what-is-agent-framework.md` | ✅ 已完成 |
| 02 | 核心概念總覽 | `02-core-concepts.md` | ✅ 已完成 |

**章節 01 — 什麼是 Microsoft Agent Framework**

- 框架定位與背景
  - 為什麼 Microsoft 要推出 Agent Framework
  - Semantic Kernel + AutoGen → Agent Framework 的整合脈絡
  - 與其他 AI Agent 框架的定位差異
- 核心設計哲學
  - AutoGen 的簡潔抽象 + Semantic Kernel 的企業級功能
  - 開源（MIT License）與開放標準
- 版本狀態與發展時程
  - 目前 RC 版本資訊
  - GA 預計時間
- 適用場景
  - 什麼情境適合使用 Agent Framework
  - 入門篇 vs 進階篇的學習路徑說明

**章節 02 — 核心概念總覽**

- AIAgent — 代理的核心抽象
  - 什麼是 AIAgent
  - Agent 的組成：名稱、指令、工具
- AgentThread — 對話上下文與狀態管理
  - 對話歷史的管理方式
  - Session 與狀態持久化
- Tools / Functions — 代理可執行的動作
  - 工具的角色與意義
  - `AIFunctionFactory` 概念預覽
- ChatClient — 底層聊天介面抽象
  - ChatClient 是什麼
  - 支援的 LLM 提供者
- Middleware — 三層中介軟體架構
  - Agent Middleware / Function Middleware / Chat Middleware
  - 各層的作用時機
- 各概念之間的關係圖

---

### 第二部分：環境建置與快速開始

| # | 章節 | 檔案名稱 | 狀態 |
|---|------|----------|------|
| 03 | 開發環境準備 | `03-dev-environment.md` | ✅ 已完成 |
| 04 | 建立你的第一個 Agent | `04-first-agent.md` | ✅ 已完成 |

**章節 03 — 開發環境準備**

- .NET SDK 版本需求
- NuGet 套件安裝指令（逐一說明每個套件的用途）
- LLM 提供者設定
  - Azure OpenAI 設定方式
  - OpenAI API Key 設定方式
  - GitHub Models 設定方式（免費入門選項）
- IDE 建議
  - Visual Studio 2022+ 設定
  - VS Code + C# Dev Kit + AI Toolkit
- 建立專案範本
  - `dotnet new console` 基本設定
  - 專案結構建議

**章節 04 — 建立你的第一個 Agent**

> 對應範例：`00.ForBeginners/BasicAgent`

- 最簡範例：建立一個基本對話代理
  - 完整程式碼與逐行說明
  - 理解 `AsAIAgent()` 擴充方法
- 與代理進行基本對話
  - `InvokeAsync` 的使用方式
  - 對話迴圈的實作
- 使用串流回應（Streaming）
  - 為什麼需要串流
  - Streaming API 的使用方式
- 使用不同的 LLM 提供者
  - 切換 Azure OpenAI / OpenAI / GitHub Models
- 完整可執行範例程式碼

---

### 第三部分：工具與 Middleware

| # | 章節 | 檔案名稱 | 狀態 |
|---|------|----------|------|
| 05 | 工具（Tools）基礎 | `05-tools-basics.md` | ✅ 已完成 |
| 06 | Middleware 與 Context 基礎 | `06-middleware-and-context.md` | ✅ 已完成 |

**章節 05 — 工具（Tools）基礎**

> 對應範例：`00.ForBeginners/ToolUse`

- 什麼是代理工具
  - 工具讓代理能「做事」而不只是「說話」
  - Function Calling 的概念
- 使用 `AIFunctionFactory` 建立工具
  - 將 C# 方法轉換為代理可呼叫的工具
  - 方法屬性（Attribute）的使用
  - 參數描述與型別對應
- 自訂工具的完整實作
  - 定義工具方法
  - 註冊工具到代理
  - 代理自動判斷何時呼叫工具
- 內建工具類型介紹
  - Vision（視覺分析）
  - Code Interpreter（程式碼解譯）
  - Bing Grounding（搜尋增強）
  - File Search（檔案搜尋）
- 工具呼叫的生命週期與執行流程
- 完整可執行範例程式碼

**章節 06 — Middleware 與 Context 基礎**

> 對應範例：`00.ForBeginners/DesignPatterns`

- Middleware 管線概念
  - 三種 Middleware 類型及各自的作用時機
    - Agent Middleware — 攔截代理執行
    - Function Middleware — 攔截工具呼叫
    - Chat Middleware — 攔截 LLM 請求
  - Middleware 鏈的串接順序與執行流程
- 實作自訂 Middleware
  - 日誌記錄 Middleware 範例
  - Middleware 的註冊方式
- Context Providers 基礎
  - 上下文提供者的概念
  - 為代理注入額外知識或背景資訊
- 完整可執行範例程式碼

---

### 第四部分：範例實作

| # | 章節 | 檔案名稱 | 狀態 |
|---|------|----------|------|
| 07 | 範例實作：Travel Agent | `07-example-travel-agent.md` | ✅ 已完成 |
| 08 | 範例實作：RAG Search | `08-example-rag-search.md` | ✅ 已完成 |
| 09 | 範例實作：Planning Pattern | `09-example-planning.md` | ✅ 已完成 |
| 10 | 範例實作：Multi-Agent 初探 | `10-example-multi-agent.md` | ✅ 已完成 |

**章節 07 — 範例實作：Travel Agent**

> 對應範例：`00.ForBeginners/TravelAgent`

- 範例情境說明
  - 一個能協助旅行規劃的 AI 代理
- 專案結構解析
- 代理定義與指令設計
- 工具設計與整合
  - 航班查詢工具
  - 飯店搜尋工具
  - 天氣查詢工具
- 對話流程示範
- 程式碼逐段解析
- 自行擴充的建議方向

**章節 08 — 範例實作：RAG Search**

> 對應範例：`00.ForBeginners/RAGSearch`

- RAG（Retrieval-Augmented Generation）概念說明
  - 為什麼代理需要外部知識
  - RAG 的運作原理
- 範例情境說明
- File Search 工具的使用方式
- 知識文件的準備與上傳
- 程式碼逐段解析
- RAG 效果的比較（有 vs 無外部知識）

**章節 09 — 範例實作：Planning Pattern**

> 對應範例：`00.ForBeginners/Planning`

- Planning Pattern 概念說明
  - 代理如何拆解複雜任務
  - 計畫（Plan）與執行（Execute）的分離
- 範例情境說明
- 代理的推理與規劃流程
- 程式碼逐段解析
- 適用場景與限制

**章節 10 — 範例實作：Multi-Agent 初探**

> 對應範例：`00.ForBeginners/MultiAgent`

- 多代理概念說明
  - 為什麼需要多個代理協作
  - 代理間的職責分工
- 範例情境說明
- 多個代理的定義與角色分配
- 代理間的通訊與協作流程
- 程式碼逐段解析
- 從入門到進階的銜接指引
  - 預告進階篇內容（A2A、Graph-based Workflows、AG-UI 等）

---

### 附錄

| # | 章節 | 檔案名稱 | 狀態 |
|---|------|----------|------|
| A | NuGet 套件參考表 | `appendix-a-nuget-packages.md` | ✅ 已完成 |
| B | 從 Semantic Kernel / AutoGen 遷移 | `appendix-b-migration-guide.md` | ✅ 已完成 |
| C | 學習資源與社群連結 | `appendix-c-resources.md` | ✅ 已完成 |

**附錄 A — NuGet 套件參考表**

- 所有相關套件的名稱、版本、用途
- 套件之間的依賴關係
- 安裝指令速查

**附錄 B — 從 Semantic Kernel / AutoGen 遷移**

- Semantic Kernel 使用者：Kernel/Plugin → Agent/Tool 對應
- AutoGen 使用者：AssistantAgent → ChatAgent 對應
- 概念對照表
- 遷移注意事項

**附錄 C — 學習資源與社群連結**

- 官方文件連結彙整
- GitHub 儲存庫
- 社群頻道（Discord、Reddit）
- 推薦影片與部落格文章
- 進階篇預告與學習路徑建議

---

## 進階篇（未來製作）

以下主題不在本次入門教學的範圍內，規劃於後續進階篇中撰寫：

| 主題 | 說明 |
|------|------|
| MCP（Model Context Protocol）整合 | 將代理暴露為 MCP 工具、連接外部 MCP Server |
| A2A（Agent-to-Agent）協定 | 跨框架的代理間通訊與發現 |
| AG-UI 協定 | 透過 HTTP + SSE 連接代理與 Web UI |
| Graph-based Workflows | Sequential、Concurrent、Conditional、Handoff 進階編排 |
| 宣告式工作流程（Declarative Workflows） | 使用設定檔定義工作流程 |
| ASP.NET Core 託管 | DI 整合、Agent Hosting 模式 |
| 可觀測性 | OpenTelemetry、.NET Aspire、DevUI |
| Durable Agent Orchestration | 搭配 Azure Durable Functions + SignalR |
| Checkpointing 與 Time Travel | 狀態檢查點、時光旅行除錯 |

---

## 寫作規範

### 語言風格

- 使用**繁體中文**撰寫
- 技術專有名詞保留英文（如 Agent、Middleware、Streaming），首次出現時附中文說明
- 程式碼註解使用繁體中文
- 語氣親切但專業，適合中高階 C# 開發者

### 程式碼規範

- 所有範例使用 **C# 最新穩定語法**（top-level statements、file-scoped namespaces 等）
- 每個範例需可獨立編譯執行
- 包含必要的 `using` 陳述式與 NuGet 套件引用
- 關鍵步驟附有中文註解

### 內容原則

- 篇幅依據實際內容需要決定，不設人為頁數限制
- 概念說明要充分，程式碼解析要完整
- 每個範例章節都要有完整可執行的程式碼
- 理論與實作並重，避免純概念堆砌

### 文件格式

- 使用 Markdown 格式
- 每個章節為獨立 `.md` 檔案
- 程式碼區塊使用 ```csharp 語法標記
- 重要概念使用圖表或表格輔助說明

---

## 製作優先順序

| 優先順序 | 章節 | 說明 |
|----------|------|------|
| 🔴 第一批 | 01 ~ 04 | 認識框架 + 環境建置 + 第一個 Agent，讓讀者能跑起來 |
| 🟡 第二批 | 05 ~ 06 | Tools 與 Middleware，掌握核心開發能力 |
| 🟢 第三批 | 07 ~ 10 | 四個範例實作，透過實際專案加深理解 |
| 🔵 第四批 | 附錄 A ~ C | 參考資料與遷移指南 |
