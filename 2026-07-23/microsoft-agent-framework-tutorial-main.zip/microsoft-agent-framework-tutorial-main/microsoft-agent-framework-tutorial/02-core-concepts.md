# 02 — 核心概念總覽

> 本章介紹 Microsoft Agent Framework 的核心抽象與概念。在動手寫程式之前，先建立對框架整體架構的理解，後續的實作會更加順暢。

---

## 概念全景圖

Microsoft Agent Framework 的設計圍繞著幾個核心抽象，它們各自負責不同的職責，彼此協作構成完整的代理運作機制：

```mermaid
flowchart TD
    Input["使用者輸入"] --> Agent

    subgraph Agent["AIAgent (代理核心抽象)"]
        direction LR
        Name["name"]
        Instructions["instructions"]
        Tools_inner["tools"]
    end

    Agent --> Thread["AgentSession\n(對話狀態)"]
    Agent --> Tools["Tools\n(工具)"]
    Agent --> MW["Middleware\n(中介軟體)"]

    Tools --> Client["ChatClient\n(LLM 通訊介面)"]
    Thread --> Client
    MW --> Client

    Client --> LLM["LLM 提供者\n(OpenAI, Azure OpenAI, etc.)"]

    style Agent fill:#4A90D9,color:#fff,stroke:#2C5F8A
    style Client fill:#50B5A9,color:#fff,stroke:#2E7D72
    style LLM fill:#F5A623,color:#fff,stroke:#C47D0E
```

接下來逐一介紹每個核心概念。

---

## AIAgent — 代理的核心抽象

`AIAgent` 是框架中最重要的抽象，代表一個 AI 代理。你可以把它想像成一個有名字、有專長、有工具的 AI 助理。

### 組成要素

一個 AIAgent 由三個核心要素組成：

| 要素 | 說明 | 範例 |
|------|------|------|
| **Name** | 代理的名稱，用於識別與日誌記錄 | `"TravelAgent"`, `"HaikuBot"` |
| **Instructions** | 代理的系統指令，定義它的行為與個性 | `"你是一個友善的旅行顧問"` |
| **Tools** | 代理可以呼叫的工具，賦予它「做事」的能力 | 查詢天氣、搜尋航班、存取資料庫 |

### 建立方式

在 C# 中，建立一個 AIAgent 最簡潔的方式是透過 `AsAIAgent()` 擴充方法：

```csharp
using Microsoft.Agents.AI;

// 透過 OpenAI 建立代理
var agent = new OpenAIClient("<your-api-key>")
    .GetChatClient("gpt-4o-mini")
    .AsAIAgent(
        name: "HaikuBot",
        instructions: "你是一個擅長寫俳句的助理。"
    );
```

也可以使用 `ChatClientAgent` 類別直接建立：

```csharp
using Microsoft.Agents.AI;

var agent = new ChatClientAgent(
    chatClient,
    name: "HaikuBot",
    instructions: "你是一個擅長寫俳句的助理。"
);
```

### 執行代理

建立代理後，透過 `RunAsync` 方法與它對話：

```csharp
// 發送訊息並取得回應
var response = await agent.RunAsync("用 Microsoft Agent Framework 為主題寫一首俳句。");
Console.WriteLine(response.Text);
```

### 回應物件

`RunAsync` 回傳的 `AgentResponse` 物件包含：

| 屬性 | 型別 | 說明 |
|------|------|------|
| `Text` | `string` | 代理的完整回應文字 |
| `Messages` | `IReadOnlyList<ChatMessage>` | 對話中的所有訊息（可查看 `Count`） |
| `AgentId` | `string` | 代理的識別碼 |
| `ResponseId` | `string` | 本次回應的識別碼 |

---

## AgentSession — 對話上下文與狀態管理

AI 代理的一個關鍵能力是**記住對話脈絡**。在 Agent Framework 中，`AgentSession` 負責管理對話的上下文與狀態。

### 為什麼需要 AgentSession

考慮以下對話：

```text
使用者：我叫小明，我想去日本旅行。
代理：  小明你好！日本是個很棒的旅行目的地，你想什麼時候出發呢？
使用者：下個月。
代理：  好的，我幫你查一下下個月到日本的航班...
```

代理之所以能在第二輪回應中知道「下個月」是指去日本，是因為 `AgentSession` 保存了先前的對話歷史。

### 使用方式

```csharp
// 建立新的對話 Session
AgentSession session = await agent.CreateSessionAsync();

// 第一輪對話
var response1 = await agent.RunAsync(
    "我叫小明，我想去日本旅行。",
    session
);
Console.WriteLine(response1.Text);

// 第二輪對話 — 代理記得之前的上下文
var response2 = await agent.RunAsync(
    "下個月出發，有什麼推薦的地方嗎？",
    session
);
Console.WriteLine(response2.Text);
```

### 不使用 AgentSession 的情況

如果你不傳入 `AgentSession`，每次呼叫 `RunAsync` 都是獨立的對話，代理不會記住之前的內容：

```csharp
// 沒有傳入 session，每次對話都是獨立的
var response1 = await agent.RunAsync("我叫小明。");
var response2 = await agent.RunAsync("我叫什麼名字？"); // 代理不會知道
```

### 狀態持久化

`AgentSession` 內部使用 `AgentSessionStateBag` 儲存狀態，支援標準 JSON 序列化，你可以將對話狀態儲存到資料庫或檔案系統：

```csharp
using System.Text.Json;

// 序列化 — 儲存對話狀態
var json = JsonSerializer.Serialize(session);
// 儲存到資料庫、Blob Storage 或檔案系統

// 反序列化 — 載入先前的對話狀態
var restored = JsonSerializer.Deserialize<AgentSession>(json);
```

這在需要跨請求保持對話連續性的場景中特別有用，例如客服系統中使用者可能隔天再回來繼續對話。若需要更完整的持久化方案，可參考第 20-21 章的 Durable Agents。

---

## Tools / Functions — 代理可執行的動作

一個只能聊天的代理，功能是有限的。**工具（Tools）** 讓代理能夠「做事」— 查詢資料庫、呼叫 API、處理文件、搜尋網路等。

### 概念說明

工具的運作方式：

1. 開發者定義一組工具（C# 方法）並註冊到代理
2. 使用者發送訊息給代理
3. LLM 分析使用者意圖，**自行判斷**是否需要呼叫工具、呼叫哪個工具
4. 框架執行工具並將結果回傳給 LLM
5. LLM 根據工具結果生成最終回應

```mermaid
sequenceDiagram
    participant User as 使用者
    participant Agent as AIAgent
    participant LLM as LLM
    participant Tool as GetWeather()

    User->>Agent: "東京明天天氣如何？"
    Agent->>LLM: 發送使用者訊息
    LLM-->>Agent: 判斷需要呼叫 GetWeather
    Agent->>Tool: GetWeather("東京")
    Tool-->>Agent: "晴天，25°C"
    Agent->>LLM: 傳入工具結果
    LLM-->>Agent: 生成最終回應
    Agent-->>User: "東京明天預計是晴天，氣溫約 25°C，很適合戶外活動！"
```

### AIFunctionFactory

`AIFunctionFactory` 是 Agent Framework 中將 C# 方法轉換為代理工具的核心工具類別。它位於 `Microsoft.Extensions.AI` 命名空間。

```csharp
using Microsoft.Extensions.AI;
using System.ComponentModel;

// 定義一個工具方法
[Description("取得指定城市的天氣資訊")]
static string GetWeather(
    [Description("城市名稱")] string city)
{
    return $"{city} 目前天氣晴朗，氣溫 25°C。";
}

// 將 C# 方法轉換為 AIFunction
AIFunction weatherTool = AIFunctionFactory.Create(GetWeather);
```

### 將工具註冊到代理

```csharp
// 建立代理時直接傳入工具
var agent = new ChatClientAgent(
    chatClient,
    name: "WeatherBot",
    instructions: "你是一個天氣查詢助理。",
    tools: [AIFunctionFactory.Create(GetWeather)]
);
```

### 工具支援的類型

`AIFunctionFactory` 支援多種 C# 方法形式：

- **靜態方法（Static Methods）**
- **實例方法（Instance Methods）**
- **Lambda 運算式**
- **區域函式（Local Functions）**
- **非同步方法（`Task<T>` 或 `ValueTask<T>`）**

工具的詳細使用方式會在 [第 05 章](./05-tools-basics.md) 深入介紹。

> 💡 **v1.1.0 新增**：自 Microsoft Agent Framework v1.1.0（2026-04-10）起，除了單一函式的 Tools 外，還支援以 **C# 類別**定義 **Skill**，將多個相關工具、資源（Resources）與腳本（Scripts）打包在一個類別中，並透過反射自動註冊。詳見附錄 D [ADR 0021](./appendix-d-proposed-adrs.md#3-agent-skills-多來源架構adr-0021) 與[附錄 A — v1.1.0 變更摘要](./appendix-a-nuget-packages.md#v110-主要變更從-100-升級)。

---

## ChatClient — 底層聊天介面抽象

`ChatClient` 是框架與 LLM 提供者之間的**通訊橋樑**。它是 `Microsoft.Extensions.AI` 定義的標準介面 `IChatClient` 的實作。

### 設計理念

Agent Framework 的一個重要設計原則是**不綁定特定的 LLM 提供者**。無論你使用 OpenAI、Azure OpenAI、Anthropic Claude 還是本地模型，都可以透過 `IChatClient` 介面統一操作。

### 支援的提供者

| 提供者 | Client 類別 | 說明 |
|--------|------------|------|
| **OpenAI** | `OpenAIClient` | Chat Completions、Responses API |
| **Azure OpenAI** | `AzureOpenAIClient` | Azure 代管的 OpenAI 模型 |
| **Azure AI Foundry** | `AIProjectClient` | 企業級代管代理服務 |
| **Anthropic Claude** | `AnthropicClient` | Claude 模型系列 |
| **GitHub Models** | `OpenAIClient`（替換 Endpoint） | 免費使用多種模型 |
| **Ollama** | `OllamaApiClient` | 本地模型（Llama、Mistral 等） |
| **Google Gemini** | `GeminiClient` | Gemini 模型系列 |

> 完整的多提供者整合教學請參考 [第 17 章](./17-llm-providers.md)。

### 建立 ChatClient 的方式

**OpenAI：**
```csharp
var chatClient = new OpenAIClient("<api-key>")
    .GetChatClient("gpt-4o-mini");
```

**Azure OpenAI：**
```csharp
var chatClient = new AzureOpenAIClient(
    new Uri("https://<resource>.openai.azure.com/"),
    new AzureCliCredential())
    .GetChatClient("<deployment-name>");
```

### Client 類型

OpenAI / Azure OpenAI 提供三種 Client 類型，各有不同用途：

| Client 方法 | API | 適用場景 |
|-------------|-----|----------|
| `GetChatClient()` | Chat Completions | 最廣泛支援，推薦入門使用 |
| `GetResponsesClient()` | Responses API | 較新的 API，支援更多功能 |
| `GetAssistantsClient()` | Assistants API | 需要伺服器端狀態管理的場景 |

對於入門學習，建議從 `GetChatClient()` 開始。

---

## Middleware — 中介軟體管線

Middleware（中介軟體）是一個在代理執行過程中**攔截與處理**請求的機制。如果你有 ASP.NET Core 的經驗，這個概念會很熟悉 — 就像 HTTP Request Pipeline，只是作用對象從 HTTP 請求變成了代理的行為。

### 三層 Middleware

Agent Framework 提供三種不同層級的 Middleware，各自作用於代理執行的不同階段：

```mermaid
flowchart TD
    Input["使用者輸入"] --> AM

    subgraph AM["Agent Middleware（最外層：攔截代理執行）"]
        direction TB
        subgraph FM["Function Middleware（中間層：攔截工具呼叫）"]
            direction TB
            subgraph CM["Chat Middleware（最內層：攔截 LLM 請求）"]
                direction TB
                LLM["LLM 呼叫"]
            end
        end
    end

    AM --> Output["代理回應"]

    style AM fill:#E8F0FE,stroke:#4A90D9,color:#333
    style FM fill:#D4EDDA,stroke:#28A745,color:#333
    style CM fill:#FFF3CD,stroke:#FFC107,color:#333
```

| Middleware 類型 | 作用時機 | 典型用途 |
|----------------|----------|----------|
| **Agent Middleware** | 整個代理的 `RunAsync` 執行前後 | 日誌記錄、計時、例外處理 |
| **Function Middleware** | 工具/函式被呼叫時 | 權限檢查、參數驗證、呼叫記錄 |
| **Chat Middleware** | 向 LLM 發送請求時 | Token 計量、回應快取、內容過濾 |

### 為什麼需要三層

不同的攔截需求需要不同的粒度。例如：

- 你想記錄每次代理被呼叫的總耗時 → **Agent Middleware**
- 你想在代理呼叫「刪除資料」工具前進行權限檢查 → **Function Middleware**
- 你想在每次 LLM 請求前記錄 Token 使用量 → **Chat Middleware**

Middleware 的詳細實作方式會在 [第 06 章](./06-middleware-and-context.md) 深入介紹。

---

## Context Providers — 上下文提供者

Context Providers（上下文提供者）是一個讓你**動態注入額外資訊**到代理對話中的機制。

### 使用場景

假設你的代理需要知道當前使用者的姓名、所在部門、偏好語言等資訊，但這些資訊不是從對話中得到的，而是從你的系統（例如資料庫或 Session）中取得。Context Providers 就是用來處理這種情況。

### 與 Tools 的差異

| 特性 | Tools | Context Providers |
|------|-------|-------------------|
| 觸發方式 | LLM 自行判斷是否需要呼叫 | 每次代理執行時自動注入 |
| 用途 | 代理主動「做事」 | 被動提供背景資訊 |
| 範例 | 查詢天氣、搜尋資料 | 注入使用者資訊、系統狀態 |

Context Providers 的實作會在 [第 06 章](./06-middleware-and-context.md) 一併介紹。

---

## 串流回應（Streaming）

Agent Framework 原生支援串流回應，讓代理的回應可以**逐段傳送**到使用者端，而不需要等整個回應生成完畢。

### 為什麼需要串流

LLM 生成一段完整回應可能需要數秒鐘。如果等全部生成完再顯示，使用者體驗會很差。串流讓每個 Token 生成後就立即傳送，使用者可以即時看到回應逐字出現。

### 使用方式

```csharp
// 非串流 — 等待完整回應
var response = await agent.RunAsync("說一個故事。");
Console.WriteLine(response.Text);

// 串流 — 逐段接收回應
await foreach (var update in agent.RunStreamingAsync("說一個故事。"))
{
    Console.Write(update.Text);  // 逐段輸出，不換行
}
```

串流回應的 `AgentResponseUpdate` 物件包含：

| 屬性 | 說明 |
|------|------|
| `Text` | 本次更新的文字片段 |
| `Contents` | 詳細的內容項目 |
| `ContinuationToken` | 用於中斷後恢復串流的令牌 |

---

## 核心概念之間的關係

最後，讓我們用一個完整的程式碼範例來展示這些概念如何協作：

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using System.ComponentModel;

// 1. 定義工具（Tools）
[Description("取得指定城市的天氣")]
static string GetWeather([Description("城市名稱")] string city)
    => $"{city}：晴天，25°C";

// 2. 建立 ChatClient（連接 LLM）
var chatClient = new OpenAIClient("<api-key>")
    .GetChatClient("gpt-4o-mini");

// 3. 建立 AIAgent（組合所有元件）
var agent = chatClient.AsAIAgent(
    name: "WeatherBot",
    instructions: "你是一個天氣查詢助理，請用繁體中文回答。",
    tools: [AIFunctionFactory.Create(GetWeather)]
);

// 4. 建立 AgentSession（管理對話狀態）
var session = await agent.CreateSessionAsync();

// 5. 與代理對話
var response = await agent.RunAsync("東京天氣如何？", session);
Console.WriteLine(response.Text);

// 6. 繼續對話（代理記得上下文）
var response2 = await agent.RunAsync("那大阪呢？", session);
Console.WriteLine(response2.Text);
```

在這個範例中：

- **ChatClient** 負責與 OpenAI 的 LLM 通訊
- **AIAgent** 整合了指令、工具，定義了代理的行為
- **Tools**（GetWeather）賦予代理查詢天氣的能力
- **AgentSession** 讓代理在多輪對話中保持上下文

---

## 小結

| 概念 | 職責 | 類比 |
|------|------|------|
| **AIAgent** | 代理的核心，整合所有元件 | 一位員工 |
| **AgentSession** | 管理對話上下文與狀態 | 員工的筆記本 |
| **Tools** | 代理可執行的動作 | 員工的工具箱 |
| **ChatClient** | 與 LLM 提供者的通訊介面 | 員工的大腦（AI） |
| **Middleware** | 攔截與處理代理行為 | 公司的流程規範 |
| **Context Providers** | 動態注入額外資訊 | 公司的內部知識庫 |
| **Streaming** | 即時回傳部分回應 | 員工邊想邊說 |

下一章我們將開始動手 — 設定開發環境，準備好所有需要的工具與套件。

---

### 延伸閱讀：官方 ADR 參考

- [ADR 0001 — Agent Run Response](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0001-agent-run-response.md)：`AgentResponse.Text` 只聚合主要內容（TextContent），次要更新使用非文字內容類型的設計決策
- [ADR 0018 — AgentSession Serialization](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0018-agentthread-serialization.md)：`AgentThread` → `AgentSession` 重新設計，`AgentSessionStateBag` 狀態與行為分離架構

---

> **返回目錄**：[README](README.md) | **上一章**：[01 — 什麼是 Microsoft Agent Framework](./01-what-is-agent-framework.md) | **下一章**：[03 — 開發環境準備](./03-dev-environment.md)
