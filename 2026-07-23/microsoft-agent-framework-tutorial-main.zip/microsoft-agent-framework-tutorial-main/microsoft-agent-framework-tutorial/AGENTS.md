# 繁中教學文件補充規範

本目錄是正式教學產物。沿用工作區根 `AGENTS.md`，並遵守以下規範：

- 讀者是具備 C#／.NET 基礎、首次接觸 Agent Framework 的開發者。
- 敘述使用台灣繁體中文；API、程式碼、套件與協定名稱保留官方英文。
- 延續既有章節結構、標題層級、提示框與程式碼風格；只修改任務明確涉及的內容。
- API 範例先以 codebase-memory-mcp 或上游 samples/tests 驗證，不從 release notes 推測簽名。
- 新章節與附錄永遠先輸出到根目錄 `outputs/`，經人工確認後才能移入本目錄。
- 更新章節或附錄後，檢查本目錄 `README.md` 的 TOC，並執行 `python3 ../scripts/validate_workspace.py`。
- 不把「lint 通過」寫成「範例已成功編譯」，除非實際建立專案並執行 build/test。
