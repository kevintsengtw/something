# 附錄 A — NuGet 套件參考

> 本附錄整理 Microsoft Agent Framework 相關的 NuGet 套件，方便查詢各套件的用途與安裝方式。

---

## 核心套件

| 套件名稱 | 用途 | 本教學使用章節 |
|----------|------|---------------|
| `Microsoft.Agents.AI` | 核心介面與抽象（AIAgent、AgentSession 等） | 全部章節 |
| `Microsoft.Agents.AI.OpenAI` | OpenAI / Azure OpenAI 提供者整合 | 全部章節 |
| `Microsoft.Agents.AI.Workflows` | 工作流程編排（WorkflowBuilder、StreamingRun 等） | 第 10 章 |

## Microsoft.Extensions.AI 套件

Microsoft Agent Framework 建構於 `Microsoft.Extensions.AI` 抽象層之上，這些套件提供了與 LLM 互動的基礎介面。

| 套件名稱 | 用途 |
|----------|------|
| `Microsoft.Extensions.AI` | AI 抽象層核心（IChatClient、ChatOptions 等） |
| `Microsoft.Extensions.AI.Abstractions` | AI 抽象介面定義 |
| `Microsoft.Extensions.AI.OpenAI` | OpenAI 的 IChatClient 實作 |

## LLM 提供者套件

根據你選擇的 LLM 提供者，安裝對應的套件：

### OpenAI

```bash
dotnet add package OpenAI
dotnet add package Microsoft.Extensions.AI.OpenAI
```

### Azure OpenAI

```bash
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

### GitHub Models（免費）

```bash
# GitHub Models 使用 OpenAI 相容的 API，使用相同套件
dotnet add package OpenAI
dotnet add package Microsoft.Extensions.AI.OpenAI
```

---

## 進階套件（本教學未涵蓋）

以下套件在進階篇中會用到：

| 套件名稱 | 用途 |
|----------|------|
| `Microsoft.Agents.AI.Workflows.Declarative` | 宣告式工作流程定義（YAML/JSON 設定檔）；v1.9.0 起轉 stable，安裝不需 `--prerelease` |
| `Microsoft.Agents.AI.Hosting` | ASP.NET Core 託管支援，將代理部署為 Web API |
| `Microsoft.Agents.AI.Foundry` | Azure AI Foundry 整合（Hosted Tools、Vector Store）<br>※ v1.0.0 起由 `Microsoft.Agents.AI.AzureAI` 改名而來 |
| `Microsoft.Agents.AI.Hyperlight` | CodeAct 整合（v1.4.0 GA）：LLM 生成程式碼在 Hyperlight 沙盒中隔離執行 |
| `Microsoft.Agents.AI.Tools.Shell` | Shell 命令工具（`LocalShellExecutor`、`DockerShellExecutor`）；v1.6.1 新增，請見第 05 章 |

---

## 安裝指令快速參考

### 入門教學最小安裝（使用 OpenAI）

```bash
dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.OpenAI
dotnet add package OpenAI
dotnet add package Microsoft.Extensions.AI.OpenAI
```

### 入門教學最小安裝（使用 Azure OpenAI）

```bash
dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.OpenAI
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

### 包含工作流程支援

```bash
# 在上述基礎上加入：
dotnet add package Microsoft.Agents.AI.Workflows
```

---

## 版本說明

Microsoft Agent Framework 的最新版本資訊：

- **目前版本**：`1.15.0`（穩定版）
- **v1.15.0 發佈日期**：2026 年 7 月 22 日
- **v1.14.0 發佈日期**：2026 年 7 月 21 日
- **v1.13.0 發佈日期**：2026 年 7 月 3 日
- **v1.12.0 發佈日期**：2026 年 7 月 2 日
- **v1.11.1 發佈日期**：2026 年 6 月 26 日
- **v1.11.0 發佈日期**：2026 年 6 月 24 日
- **v1.10.0 發佈日期**：2026 年 6 月 11 日
- **v1.9.0 發佈日期**：2026 年 6 月 3 日
- **v1.8.0 發佈日期**：2026 年 5 月 28 日
- **v1.7.0 發佈日期**：2026 年 5 月 26 日
- **v1.6.1 發佈日期**：2026 年 5 月 14 日
- **v1.4.0 發佈日期**：2026 年 5 月 5 日
- **v1.3.0 發佈日期**：2026 年 4 月 24 日
- **v1.2.0 發佈日期**：2026 年 4 月 21 日
- **v1.1.0 發佈日期**：2026 年 4 月 10 日
- **v1.0.0 GA 發佈日期**：2026 年 4 月 2 日
- **最低 .NET 版本**：.NET 8.0
- **授權**：MIT License

由於已是正式版，套件安裝時**不需要** `--prerelease` 旗標：

```bash
dotnet add package Microsoft.Agents.AI
```

或在 `.csproj` 中明確指定版本：

```xml
<PackageReference Include="Microsoft.Agents.AI" Version="1.15.0" />
```

### v1.15.0 主要變更（從 1.14.0 升級）

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 新功能 | `OpenAIResponses` / `OpenAIResponsesRunRequest`（PR #7000） | app-owned OpenAI Responses request/response mapping；應用程式自行掌控 route、認證、授權與 storage。**ch11 已補版本提示** |
| 新功能 | `HostedWorkflowState` / `HostedWorkflowRunResult`（PR #7000） | 支援 checkpoint-based workflow run-or-resume 狀態管理 |
| 🔴 Breaking（教學未示範） | `AgentSessionStore.DeleteSessionAsync` 成為 abstract（PR #7000） | 自訂 session store 實作者必須補上刪除方法；教學未實作自訂 store |

> v1.15.0 對既有教學程式碼無新增破壞性影響；新增 hosting helpers 已在 ch11 記錄。

### v1.14.0 主要變更（從 1.13.0 升級，含破壞性變更）

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 🔴 Breaking | AG-UI server API 重新命名 | 舊 `Microsoft.Agents.AI.AGUI` 拆分為外部 `AGUI.*` packages；ASP.NET Core 整合仍為 `Microsoft.Agents.AI.Hosting.AGUI.AspNetCore`，改用 `AddAGUIServer()` / `MapAGUIServer()`。**影響 ch11、ch15、ch16、ch24、附錄 F/I，均已更新** |
| 🔴 Breaking + 穩定化 | Message injection 轉 stable（PR #7044） | `EnqueueMessages` / `GetPendingMessages` 改為 `EnqueueMessagesAsync` / `GetPendingMessagesAsync`。**影響 ch06，已更新** |
| 🔴 Breaking + 穩定化 | `ToolApprovalAgent` 轉 stable（PR #7107） | 自動核可規則改收 `ToolAutoApprovalRuleContext`，函式呼叫位於 `context.FunctionCallContent`。**影響 ch16，已更新** |
| 🔴 Breaking | 核可 bypass / response binding 改為預設啟用（PR #7111） | 改名為 `UseApprovalNotRequiredFunctionBypassing`，可用 `DisableApprovalNotRequiredFunctionBypassing` / `DisableApprovalResponseBinding` opt out。**影響 ch16、ch29，已更新** |
| 🔴 Breaking（教學未示範） | Harness FileAccess 改為明確 opt-in（PR #7093） | 使用檔案工具前必須提供 `FileAccessStore` |
| 穩定化 | `HarnessAgent`、FileMemory、Todo/AgentMode providers 轉 stable | 移除 experimental 標記；教學未直接示範這些 surface |

> v1.14.0 的四組教學偏移均已依目前原始碼更新；舊 API 名稱只保留於歷史變更說明。

### v1.13.0 主要變更（從 1.12.0 升級）

> **對本教學無新增破壞性影響；含 Agent Skills 穩定化與細緻核可增強（第 29 章）**：PR #6861 將 Agent Skills API 移除 `[Experimental]` 標記，正式轉為穩定 API；PR #6843 新增細緻核可控制。兩項官方 Breaking 皆在教學未示範的子系統。第 29 章已同步補充。

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 穩定化 | Skills API 移除 `[Experimental]`（PR #6861） | `AgentSkillsProvider` 等正式轉穩定；skills source 類別改 public（PR #6838）。**影響 ch29（正向）** |
| 增強 | 技能核可選項 + 自動核可規則（PR #6843） | `AgentSkillsProviderOptions` 新增 `DisableLoadSkillApproval`/`DisableReadSkillResourceApproval`/`DisableRunSkillScriptApproval`；`AgentSkillsProvider.ReadOnlyToolsAutoApprovalRule`/`AllToolsAutoApprovalRule`。**影響 ch29（增強）** |
| 增強 | `AgentSkillsSourceContext` + source 改 disposable（PR #6797/#6827） | `AgentSkillsSource.GetSkillsAsync` 新增 context 參數、`AgentSkillsSource : IDisposable`；僅影響自訂 source |
| 🔴 Breaking（教學未示範） | 檔案編輯工具 + FileAccess/FileMemory store API 對齊（PR #6807） | Harness FileAccess/FileMemory 子系統（`[Experimental]`） |
| 🔴 Breaking（教學未示範） | OpenAI Hosting OptionsMapping 預設不透傳 options（PR #6855） | hosting 層內部映射；ch17 用戶端 `AzureOpenAIClient`/`GetOpenAIResponseClient` 建構**不受影響** |
| 相依更新 | `Azure.AI.Projects` → 2.1.0-beta.4（#6795） | Foundry hosting 相依 |

> v1.13.0 對本教學核心 API 無破壞性影響。ch29 已補充：技能快取（v1.12.0）、細緻核可（v1.13.0）與 Skills API 穩定化。

### v1.12.0 主要變更（從 1.11.1 升級，含破壞性變更）

> **⚠️ 對本教學有破壞性影響（第 29 章）**：PR #6768 將技能快取自 `AgentSkillsProvider` 抽離為獨立裝飾器 `CachingAgentSkillsSource`（`Microsoft.Agents.AI.Skills.Decorators`），並**移除 `AgentSkillsProviderOptions.DisableCaching` 屬性**。第 29 章原本在進階選項範例與小結列出 `DisableCaching`，已同步更新。其餘 Breaking 集中於 Foundry.Hosting，教學未示範。

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 🔴 Breaking | 快取抽離 + `DisableCaching` 移除（PR #6768） | 快取改由 source 端以 `CachingAgentSkillsSource` 裝飾器組合。**影響 ch29** |
| 🔴 Breaking（教學未示範） | Foundry.Hosting 實驗性旗標對齊 MAAI001（PR #6743） | hosting 診斷 ID 對齊 |
| 🔴 Breaking（教學未示範） | `Azure.AI.AgentServer` → 2.0.0 協定 + Foundry.Hosting 遷移（PR #6800） | hosting 相依協定升級 |
| 增強 | `BackgroundTaskCompletionLoopEvaluator`（PR #6736） | Harness 背景代理迴圈完成評估器（非 ch28 Evaluation 框架） |
| 增強 | skill body resource/script `description` 屬性（PR #6759） | SKILL.md 資源/腳本可帶說明文字 |

> v1.12.0 含一項影響教學的 Agent Skills Breaking（`DisableCaching` 移除）；其餘為 Foundry.Hosting 與 Harness 進階主題。

### v1.11.1 主要變更（從 1.11.0 升級，含破壞性變更）

> **⚠️ 對本教學有破壞性影響（第 29 章）**：PR #6729 將所有 `AgentSkillsProvider` 技能工具改為**預設需人工核可**，並移除 `AgentSkillsProviderOptions.ScriptApproval` 屬性與 `AgentSkillsProviderBuilder.UseScriptApproval(bool)` 方法；PR #6706 移除 `SkillsInstructionPrompt` 範本的 `{resource_instructions}`/`{script_instructions}` 佔位符。第 29 章已同步更新。這是自 v1.4.0 以來首個影響教學程式碼的破壞性變更。

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 🔴 Breaking | 技能工具預設需核可（PR #6729） | 移除 `ScriptApproval`/`UseScriptApproval`；`load_skill`/`read_skill_resource`/`run_skill_script` 一律以 `ApprovalRequiredAIFunction` 包裝，核可走標準 HITL 機制（ch16）。**影響 ch29** |
| 🔴 Breaking | 移除 `{resource_instructions}`/`{script_instructions}` 佔位符（PR #6706） | `SkillsInstructionPrompt` 範本現只需 `{skills}`；資源/腳本清單改由 `available_resources`/`available_scripts` 區塊自動輸出。**影響 ch29** |
| 增強 | `IncludeDetailedErrors` 選項（PR #6680） | `AgentSkillsProviderOptions.IncludeDetailedErrors`：腳本失敗時是否把例外細節回傳給模型（預設 `false`） |
| 增強 | `DeclarativeWorkflowJsonOptions`（PR #6745） | 宣告式工作流程的 AOT-safe checkpoint 序列化選項 |
| 增強 | archive 型 MCP 技能（PR #6631） | `AgentMcpSkillsSource` 支援壓縮封存技能 + `AgentMcpSkillsSourceOptions`（含 decompression-bomb 防護） |
| 增強 | `FoundryAITool.CreateMcpTool` `projectConnectionId` 多載（PR #6703） | .NET Foundry MCP 工具建立 |
| Bug 修復 | hosted agent 工具呼叫後崩潰（PR #6231/#6714） | `FileSystemAgentSessionStore` 改 root 於 `$HOME`；checkpoint 恢復修復（#6670）、技能目錄遞迴修復（#6686）、MCP metadata 修復（#6656） |
| 相依更新 | .NET SDK → 10.0.301（#6730） | MEAI 10.6.0 / MCP 1.2.0 維持不變 |

> v1.11.1 為 patch 修補釋出，但含一項影響教學的 Agent Skills 安全性 Breaking（腳本審批由「opt-in」改為「預設全部需核可」）。其餘新增能力（archive MCP 技能、`DeclarativeWorkflowJsonOptions`）為進階主題。

### v1.11.0 主要變更（從 1.10.0 升級）

> **對本教學無破壞性影響**：release notes 標為 Breaking 的三項經 codebase-memory-mcp 驗證，對教學公開 API 皆無影響——`FileAccessProvider` 工具核可（#6521）與 FileAccess 工具對齊 Python（#6474）皆在 Harness 的 `Microsoft.Agents.AI.Harness.FileAccess` 子系統（`[Experimental]`，教學未示範）、`SessionConfig.Streaming` 複製為內部修復（#6463）。

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 新套件 | `Microsoft.Agents.AI.LocalCodeAct`（PR #6105） | `LocalCodeActProvider`/`LocalCodeActProviderOptions`：於本機執行 Python（CodeAct 本機沙盒選項，相對於 Hyperlight 沙盒） |
| 增強 | `LoopAgent`（PR #6384） | `Microsoft.Agents.AI.Harness.Loop.LoopAgent`/`LoopAgentOptions`（`[Experimental]`）：以評估器驅動把被包裝代理放進迴圈反覆執行；`MaxIterations`/`FreshContextPerIteration` 等選項 |
| 增強 | MCP 每次執行可刷新驗證標頭（PR #6624） | MCP 連線支援 per-run 可刷新的驗證標頭 |
| 增強 | Sequential Orchestration 傳遞模式（PR #6554） | 可選擇傳遞整段對話或僅前一步輸出 |
| 行為變更 | A2A session store 預設改為 `NoopAgentSessionStore`（PR #6635） | A2A hosting 預設不持久化 session；需持久化者請明確註冊自訂 `AgentSessionStore` |
| 相依更新 | `Anthropic.Foundry` 0.5.0 → 0.6.0（#6057）、`Azure.AI.Projects` → 2.1.0-beta.3（#6542）、`MessagePack` → 3.1.7（#6497） | 相依套件升級；MEAI 10.6.0 / MCP 1.2.0 自 1.10.0 起未變 |
| Bug 修復 | OpenTelemetry span 位置（#6667）、結構化輸出僅取最後訊息（#6499）、Durable workflow 端點路由（#6608）、AI Search 引用 URL（#6649）等 | 行為修復，公開 API 不變 |

> v1.11.0 為維護 + 增強釋出；新增能力以 `LocalCodeAct` 本機 Python 執行與 `LoopAgent` Harness 迴圈為主，皆為 Harness/新套件層級，未變更教學示範的核心 API。

### v1.10.0 主要變更（從 1.9.0 升級）

> **對本教學無破壞性影響**：release notes 標為 Breaking 的三項經 codebase-memory-mcp 驗證，對教學公開 API 皆無影響——GitHub Copilot SDK 遷移（教學未涵蓋此 provider）、hosting 內部修復、`ToolApprovalAgent` 自動核可規則（純新增 additive 能力）。

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 增強 | `ToolApprovalAgent` 自動核可規則（PR #6335） | 當時為 `[Experimental]`；v1.14.0 已轉 stable，規則輸入改為 `ToolAutoApprovalRuleContext` |
| 增強 | 允許儲存自動核可的函式（PR #4950） | 當時名稱為 `UseNonApprovalRequiredFunctionBypassing`；v1.14.0 更名為 `UseApprovalNotRequiredFunctionBypassing` 並改為預設啟用 |
| 增強 | `HarnessAgent` token compaction 改 opt-in（PR #6409） | `MaxContextWindowTokens`/`MaxOutputTokens` 改為可選；in-loop 壓縮僅在兩者皆提供時才啟用 |
| 增強 | ChatClientAgent ChatOptions 合併加入 Reasoning（PR #5463） | 合併 `ChatOptions` 時納入 `reasoning` 參數 |
| 相依更新 | `Microsoft.Extensions.AI` → 10.6.0（#6148）、`ModelContextProtocol` 1.1.0 → 1.2.0（#6239）、GitHub Copilot SDK → v1.0.0（#6381） | 相依套件升級 |
| Bug 修復 | Magentic 跨團隊共享代理回覆（#6222）、skill script schemas XML 重構（#6343）、保留 AG-UI session 歷史（#5904）、宣告式工作流程值解包/foreach 保留（#6367, #6208） | 行為修復，公開 API 不變 |

> v1.10.0 為維護 + 增強釋出；多數變更為相依升級與 Python-only 修復。

### v1.9.0 主要變更（從 1.8.0 升級）

> **對本教學無破壞性影響**：以下變更皆經 codebase-memory-mcp 驗證，教學範例不需修改。

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 狀態變更 | **Orchestrations 移除 `[Experimental]`**（PR #6164） | Magentic / Handoff / GroupChat 編排轉正式；公開入口 `MagenticWorkflowBuilder` 不再標 Experimental，`MagenticOrchestrator`/`MagenticManager` 改為 `internal` 實作型別 |
| 狀態變更 | **`Microsoft.Agents.AI.Workflows.Declarative` 轉 stable**（PR #6254） | 宣告式工作流程套件由 prerelease/RC 轉正式版，安裝不再需要 `--prerelease` |
| 增強 | Workflow Outputs Overhaul（PR #6045） | 工作流程輸出支援 tagging 與 filtering agent 輸出（`WithOutputFrom`/`WithIntermediateOutputFrom`） |
| 增強 | `GroupChatManager` 語意對齊 Orchestration patterns（PR #6140） | — |
| 增強 | `HarnessAgent` 建構子加入 `ILoggerFactory`/`IServiceProvider`（PR #6273） | 皆為可選參數，擴充 DI 整合 |
| Bug 修復 | Foundry Hosting `function_call_output` 缺 id（#6246）、宣告式工作流程 `InvokeMcpTool` 核准路徑（#6177）、AGUI hosting 與 workflows（#6311） | — |

> v1.9.0 多數變更為 Python-only（`McpSkillsSource`、progressive tool exposure、`AgentFileStore`/`FileAccessProvider`、Bedrock structured output、Mistral embedding 等），不影響 .NET 教學。

### v1.8.0 主要變更（從 1.7.0 升級）⚠️ 含破壞性變更

> **兩個 `[Breaking]` 對本教學皆無影響**：教學未使用被移除的 Declarative code-gen，也未使用 `AgentFileSkillsSource` 被重構的目錄白名單選項。

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| **[Breaking]** | 移除 Declarative Workflows 的 code-gen 支援（PR #6095） | 宣告式工作流程改為純執行期解譯；教學未示範 code-gen，無影響 |
| **[Breaking]** | 重構 `AgentFileSkillsSource` 為 depth-based discovery + 述詞過濾（PR #6109） | `AgentFileSkillsSourceOptions` 由目錄白名單（`ResourceDirectories`/`ScriptDirectories`）改為 `SearchDepth`/`ResourceFilter`/`ScriptFilter`；未自訂 `fileOptions` 的呼叫（如 `new AgentSkillsProvider(path, runner)`）不受影響，預設深度 2 |
| 新功能 | MCP-based skills（skill-md 類型，`AgentMcpSkill`/`AgentMcpSkillsSource`，PR #6108） | 以 MCP 提供技能 |
| 新功能 | `ForeachExecutor` 迭代狀態跨 checkpoint 持久化（PR #6051） | — |
| 新功能 | `ClaimsIdentity`-based agent session scoping（PR #5696） | 多租戶/多身分 session 隔離 |
| 新功能 | Handoff Orchestration 與 Python 對齊（PR #6138） | — |

### v1.7.0 主要變更（從 1.6.1 升級）⚠️ 含破壞性變更

> **`[Breaking]` 對本教學無影響**：第 29 章 Agent Skills 的範例使用「撰寫端」API，未受影響。

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| **[Breaking]** | base `AgentSkill` 消費端 API 改為非同步（PR #6030） | 由同步成員（`Content`/`Resources`/`Scripts`）改為 `GetContentAsync`/`GetResourceAsync(name)`/`GetScriptAsync(name)`。**撰寫端不變**：`AgentClassSkill<T>`（`override Frontmatter`/`Instructions` + `[AgentSkillResource]`/`[AgentSkillScript]`）、`AgentInlineSkill`（`AddResource`/`AddScript`）、`AgentSkillsProvider` 公開 API 全部保留，第 29 章程式碼仍可編譯 |
| 新功能 | MCP 長時間任務支援（MCP client tools，PR #5994） | — |
| 新功能 | Magentic Orchestration 範例（PR #5823） | `dotnet/samples/03-workflows/Orchestration/Magentic` |
| 新功能 | Hosted-AgentSkills（Foundry Skills）範例（PR #6013） | — |

### v1.6.1 主要變更（從 1.5.0 升級）⚠️ 含破壞性變更

> **從 v1.5.0 直接跳至 v1.6.1（無 v1.6.0 公開發佈）。本版本有 2 個破壞性變更，請務必閱讀。**

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| **[Breaking]** | `OpenTelemetryAgent` 自動包裝 `ChatClient` | `OpenTelemetryAgent`（`.UseOpenTelemetry()` 建立）現在自動將內部 `ChatClient` 包裝為 `OpenTelemetryChatClient`；若已手動在 ChatClient 層加 OTel，需移除以避免**雙重儀器化** |
| **[Breaking]** | Foundry Toolbox server-side tools 完整移除 | `AIProjectClient.GetToolboxAsync()`、`FoundryToolbox` 型別已移除；改用 `AIFunctionFactory.Create()` 定義 client-side 工具（見[第 05 章](./05-tools-basics.md)） |
| 新功能 | `MessageInjectingChatClient`（當時為 `[Experimental]`） | 在代理函數呼叫迴圈期間動態排隊 `ChatMessage`；透過 `ChatClientAgentOptions.EnableMessageInjection` 啟用；v1.14.0 轉 stable 並將佇列方法改為 async |
| 新功能 | Shell Tool | 允許代理執行本地 shell 命令（僅限受控環境） |
| 新功能 | `AgentSessionFiles` SDK | 工作階段內的檔案上傳與存取管理 |
| 新功能 | A2A `input-request` 支援 | A2A 協定支援 human-in-the-loop 工作流程暫停 |
| 新功能 | Harness Agent 套件 | Managed Agent 測試與封裝工具鏈 |

### v1.5.0 主要變更（從 1.4.0 升級）

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 實驗性新功能 | Magentic Orchestration（PR #5595, #5704） | 多代理 LLM 驅動任務分解編排，公開入口 `MagenticWorkflowBuilder`；v1.5.0 標注 Experimental，**v1.9.0（PR #6164）起移除 Experimental 轉正式**，`MagenticOrchestrator` 已改為 internal |
| 新功能 | AG-UI Reasoning Events（PR #4953） | AG-UI Protocol 支援推理過程事件串流 |
| 新功能 | WebBrowsingTool Allow Listing（PR #5605） | 可設定 WebBrowsingTool 允許存取的網域清單 |
| Bug 修復 | YAML block scalar 解析（PR #5610） | 修復宣告式工作流程 YAML 中 block scalar 語法解析問題 |
| 相依更新 | MEAI 10.5.1（PR #5652） | Microsoft.Extensions.AI 更新至 10.5.1 |
| 相依更新 | GitHub Copilot SDK 1.0.0-beta.2（PR #5699） | 更新 GitHub Copilot 整合依賴 |

> **v1.5.0 無破壞性變更**，從 v1.4.0 升級只需更新套件版本號。

### v1.4.0 主要變更（從 1.3.0 升級）⚠️ 含破壞性變更

> **檔案式 Skill 腳本使用者請注意**：v1.4.0 包含 file-based skill scripts 引數格式的破壞性變更，詳見下表。

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| **[Breaking]** | file-based skill scripts 引數改為 `string[]`（PR #5475） | 外部腳本（Python/Bash）收到的引數格式改為陣列；使用 `SubprocessScriptRunner` 的腳本需更新取用方式（Python 改用 `sys.argv[1:]`） |
| 新套件 | `Microsoft.Agents.AI.Hyperlight`（PR #5329） | CodeAct .NET 整合 GA；LLM 生成程式碼在 Hyperlight 沙盒中隔離執行 |
| 新功能 | 宣告式工作流程 `HttpRequestAction`（PR #5474） | 可直接在 YAML 工作流程定義中設定 HTTP 呼叫步驟 |
| 新功能 | Durable Workflow HTTP trigger 回傳執行結果（PR #5321） | HTTP trigger endpoint 不再只回傳 202 Accepted，可直接取得工作流程結果 |
| 相依更新 | OpenTelemetry packages（PR #5478） | 升級至 1.15.3 |

### v1.3.0 主要變更（從 1.2.0 升級）⚠️ 含破壞性變更

> **A2A 使用者請注意**：v1.3.0 包含 A2A 相關的 **破壞性 API 變更**，詳見下表。

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| **[Breaking]** | A2A SDK 升級（PR #5423） | `A2A SDK 0.3.4-preview → 1.0.0-preview2`；`EndpointRouteBuilderExtensions`（A2A）移除，改用 `A2AEndpointRouteBuilderExtensions`；`AIAgentExtensions`（A2A 部分）移除，改用 `A2AServerServiceCollectionExtensions`；`AddA2AServer()` 現需明確傳入含 `AgentCard` 的 options |
| **[Breaking]** | Azure.AI.AgentServer.Responses beta.4（PR #5450） | `FunctionToolCallOutputResource` → `OutputItemFunctionToolCallOutput`；`AzureAIAgentServerResponsesModelFactory` 改為 internal |
| 新功能 | `A2AAgentHandler` Streaming（PR #5427） | A2A Server 支援 `RunStreamingAsync`，依 `context.StreamingResponse` 自動路由 |
| ~~新功能~~ （⚠️ **v1.6.1 Breaking：已移除**）| Foundry Toolbox（PR #5450） | ~~`FoundryToolbox` + `AIProjectClientToolboxExtensions`（`Microsoft.Agents.AI.Foundry.Hosting`）；支援 server-side Toolbox 工具~~ → v1.6.1 完整移除，改用 `AIFunctionFactory.Create()` |
| 新套件 | `Microsoft.Agents.AI.Hosting.Aspire` | Aspire 整合 preview 套件（跨服務代理部署） |
| Bug 修復 | `StreamingRunEventStream.RunLoopAsync` 競態條件（PR #5412） | 修復 RunStatus 在 streaming 結尾可能錯誤的問題 |

### v1.2.0 主要變更（從 1.1.0 升級）

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 新功能 | Foundry Hosted Agents .NET GA（PR #5312） | Azure AI Foundry 托管代理完整 .NET 支援 |
| 新功能 | Handoff HITL 支援（PR #5174） | 多代理 Handoff 可在決策點插入人工審批 |
| 新功能 | DevUI + Aspire 整合（PR #3771） | DevUI 整合 .NET Aspire，代理執行可視化 |
| Bug 修復 | Foundry 無 description Handoff 崩潰（PR #5311） | 修復缺少 description 時 Handoff 錯誤 |
| Bug 修復 | Handoff-hosted Agents session（PR #5280） | 修復 session 傳遞問題 |

### v1.1.0 主要變更（從 1.0.0 升級）

| 類別 | 變更項目 | 說明 |
|------|----------|------|
| 新功能 | **Skill as class**（PR #5027） | 支援以 C# 類別定義 Skill，並透過反射自動註冊 |
| 新功能 | **Reflection-based discovery**（PR #5183） | 自動偵測類別內的 Resources 與 Scripts |
| 新功能 | **Custom types in skill functions**（PR #5152） | Skill 函式參數／回傳值支援自訂型別 |
| 新功能 | Align skill folder discovery（PR #5078） | 資料夾式 Skill 探索方式對齊規格 |
| 標準化 | **Directory 術語統一**（PR #5205） | 舊「file skills」統一改稱 "directory" |
| 標準化 | Executor Callbacks（PR #5081） | Message Delivery Callback 新增多載 |
| 標準化 | FoundryAgent Session（PR #5144） | `CreateSessionAsync(conversationId)` 新增多載 |
| Bug 修復 | 壓縮歷史重複（PR #5149） | 修復 compaction 時 chat history 可能重複 |
| Bug 修復 | Checkpoint 還原（PR #5085） | 修復還原時 input signal 處理不正確 |
| Bug 修復 | Handoff Context（PR #5136） | 修復 handoff workflow context 傳遞 |
| Bug 修復 | Entity Key（PR #5179） | 加強 entity key 驗證 |
| 相依更新 | Anthropic SDK（PR #5055） | 12.8.0 → 12.11.0 |
| 模型支援 | 新模型（PR #5080） | 新增 `gpt-5.4-mini` 支援 |

> v1.1.0 與 v1.2.0 對教學核心 API 均**無破壞性變更**。**v1.3.0 的 A2A 相關 API 有破壞性變更**，若使用 A2A 功能請參考 [第 23 章](./23-a2a-protocol.md) 的更新範例。**v1.4.0 的 file-based skill scripts 引數格式有破壞性變更**，若使用 `SubprocessScriptRunner` 執行外部腳本，請參考 [第 05 章](./05-tools-basics.md) 的升級說明。**v1.5.0 無破壞性變更**，直接更新套件版本即可。**v1.6.1 有 2 個破壞性變更**，請見上方 [v1.6.1 段落](#v161-主要變更從-150-升級-含破壞性變更)。**v1.7.0~v1.9.0 的 `[Breaking]`（AgentSkill async #6030、AgentFileSkillsSource depth-based #6109、Declarative code-gen 移除 #6095）經驗證對本教學範例皆無影響**；v1.9.0 並將 Orchestrations 移除 `[Experimental]`、Workflows.Declarative 轉 stable。**v1.10.0 為維護 + 增強釋出，標為 Breaking 的三項（Copilot SDK 遷移、hosting 修復、ToolApprovalAgent 自動核可規則）對教學亦無影響。** **v1.11.0 同為維護 + 增強釋出，標為 Breaking 的三項（FileAccessProvider 工具核可 #6521、FileAccess 對齊 Python #6474、SessionConfig.Streaming 複製 #6463）集中於 Harness FileAccess 子系統與內部修復，對教學亦無影響；新增 `LocalCodeAct` 套件與 `LoopAgent`。** **⚠️ v1.11.1 有破壞性變更影響教學（第 29 章）**：所有 `AgentSkillsProvider` 技能工具改為預設需人工核可，`ScriptApproval`/`UseScriptApproval`（#6729）與 `{resource_instructions}`/`{script_instructions}` 佔位符（#6706）已移除——這是自 v1.4.0 以來首個影響教學程式碼的破壞性變更，第 29 章已同步更新。**⚠️ v1.12.0 再有一項影響教學的 Breaking（第 29 章）**：技能快取抽離為 `CachingAgentSkillsSource` 裝飾器、移除 `AgentSkillsProviderOptions.DisableCaching`（#6768）。**v1.13.0 對教學無新增破壞性影響**：Agent Skills API 移除 `[Experimental]` 正式轉穩定（#6861）、新增細緻核可選項（#6843），兩項官方 Breaking（FileAccess/FileMemory #6807、OpenAI Hosting OptionsMapping #6855）皆在教學未示範的子系統。

> **⚠️ v1.14.0 的破壞性更名會影響教學**：AG-UI、Message injection、`ToolApprovalAgent` context 與 approval bypass 寫法均已更新。**v1.15.0 對既有範例無新增破壞性影響**；app-owned OpenAI Responses helpers 已補入第 11 章。

### v1.0.0 主要變更（從 1.0.0-rc5 升級時注意）

| 變更項目 | 說明 |
|----------|------|
| **套件改名** | `Microsoft.Agents.AI.AzureAI` → `Microsoft.Agents.AI.Foundry` |
| **不再需要 `--prerelease`** | 1.0.0 已是 GA，所有套件直接安裝即可 |
| **依賴版本** | `Azure.AI.Projects` 升級至 2.0.0 GA |
| **Handoff Orchestrations** | 標記為 experimental，未來 API 可能調整 |
| **移除類別** | `OpenAIAssistantClientExtensions` 已移除 |
| **類別改名** | `ServiceStoredSimulatingChatClient` → `PerServiceCallChatHistoryPersistingChatClient` |

> 本教學使用的核心 API（`AIAgent`、`AgentSession`、`AIFunctionFactory`、`WorkflowBuilder`、`ChatResponseFormat.ForJsonSchema` 等）在 v1.0.0 ~ v1.15.0 中維持相容；受 v1.14.0 破壞性更名影響的 AG-UI、Message injection 與核可 middleware 範例均已更新。A2A 相關範例（第 23 章）已依 v1.3.0 API 更新。若使用 file-based skill 外部腳本，請留意 v1.4.0 的引數格式變更；若使用 `AgentSkillsProvider`，請留意 **v1.11.1** 已將技能工具改為預設需核可並移除 `ScriptApproval`/`UseScriptApproval`、**v1.12.0** 移除 `DisableCaching`（快取抽離為 `CachingAgentSkillsSource`）、**v1.13.0** 新增細緻核可選項並將 Skills API 轉穩定（第 29 章已更新）。
>
> ⚠️ **v1.6.1 有 2 個破壞性變更**：（1）`OpenTelemetryAgent` 自動包裝 ChatClient，手動雙層包裝會造成雙重儀器化（第 22 章已更新）；（2）Foundry Toolbox `GetToolboxAsync()` 已移除，改用 `AIFunctionFactory.Create()`（第 17 章已更新）。
>
> ℹ️ **v1.7.0~v1.9.0 的破壞性變更皆不影響本教學**：base `AgentSkill` 消費端改非同步（#6030）但撰寫端 API 保留，第 29 章範例不受影響；`AgentFileSkillsSource` 改 depth-based（#6109）但教學未用被移除的目錄白名單選項；Declarative code-gen 移除（#6095）但教學未示範 code-gen。v1.9.0 另將 Orchestrations 移除 `[Experimental]`（Magentic 經 `MagenticWorkflowBuilder` 轉正式）、`Microsoft.Agents.AI.Workflows.Declarative` 轉 stable。v1.10.0 為維護 + 增強釋出（`ToolApprovalAgent` 自動核可規則、HarnessAgent token compaction 改 opt-in、MEAI 10.6.0、MCP 1.2.0），對教學公開 API 無影響。v1.11.0 為維護 + 增強釋出（新增 `Microsoft.Agents.AI.LocalCodeAct` 本機 Python 執行、`LoopAgent` Harness 迴圈、MCP per-run 可刷新驗證標頭、A2A 預設 `NoopAgentSessionStore`），標為 Breaking 的三項集中於 Harness FileAccess 子系統與內部修復，對教學公開 API 無影響。**v1.11.1 為 patch 釋出，但含一項影響教學的 Agent Skills 安全性 Breaking**：`AgentSkillsProvider` 技能工具改為預設需人工核可、移除 `ScriptApproval`/`UseScriptApproval`（#6729）與 `{resource_instructions}`/`{script_instructions}` 佔位符（#6706），第 29 章已同步更新；其餘為 `DeclarativeWorkflowJsonOptions`、archive 型 MCP 技能等進階增強與 Bug 修復。**v1.12.0 含一項影響教學的 Breaking**：技能快取抽離為 `CachingAgentSkillsSource` 裝飾器、移除 `AgentSkillsProviderOptions.DisableCaching`（#6768），第 29 章已更新；其餘 Breaking（Foundry.Hosting MAAI001 #6743、`Azure.AI.AgentServer` 2.0.0 #6800）集中於 hosting 子系統。**v1.13.0 對教學無新增破壞性影響**：Agent Skills API 移除 `[Experimental]` 正式轉穩定（#6861）、新增技能核可選項與自動核可規則（#6843）、`AgentSkillsSourceContext` + source 改 `IDisposable`（#6797/#6827），兩項官方 Breaking（FileAccess/FileMemory 檔案編輯工具 #6807、OpenAI Hosting OptionsMapping #6855）分別在 Harness `[Experimental]` 與 hosting 層，教學未示範。
>
> **v1.14.0**：教學涉及的 AG-UI、Message injection 與核可 middleware 已完成遷移；FileAccess opt-in 等其餘 breaking 不在教學範圍。**v1.15.0**：自訂 `AgentSessionStore` 的新 abstract 方法不影響現有範例，新增 OpenAI Responses hosting helpers 已記錄於 ch11。

---

> **返回目錄**：[README](README.md) | **上一章**：[28 — Agent Evaluation](./28-agent-evaluation.md) | **下一篇**：[附錄 B — 從 SK / AutoGen 遷移](./appendix-b-migration-guide.md)
