# 13 — Docker 部署

> 本章介紹如何將 Microsoft Agent Framework Web API 容器化，包含多階段 Dockerfile 建立、`docker-compose` 本機開發設定、環境變數與 Secret 管理，以及適合生產環境的建置最佳實踐。

---

## 為什麼容器化 Agent API

將 Agent 應用容器化帶來幾個關鍵好處：

- **環境一致性**：開發、測試、生產執行相同的映像檔，消除「在我機器上可以跑」的問題
- **快速部署**：一個 `docker pull` + `docker run` 即可啟動完整服務
- **水平擴展**：容器可輕易在 Kubernetes 或 Azure Container Apps 上複製多個實例
- **資源隔離**：不同代理應用之間不互相干擾

---

## 專案結構（預設從上一章延伸）

```text
MyAgentApi/
├── MyAgentApi.csproj
├── Program.cs
├── appsettings.json
├── appsettings.Development.json
├── Dockerfile                    ← 本章新增
├── .dockerignore                 ← 本章新增
├── docker-compose.yml            ← 本章新增（本機開發用）
├── docker-compose.override.yml   ← 本章新增（本機設定覆寫）
└── Agents/
    └── CustomerSupportAgent.cs
```

---

## Dockerfile（多階段建置）

多階段建置（Multi-stage Build）的核心概念：用「建置階段」編譯程式，再用「執行階段」只打包執行所需的最小內容，大幅縮小最終映像檔大小。

```dockerfile
# ── 階段一：建置（Build Stage）───────────────────────────────────
FROM mcr.microsoft.com/dotnet/sdk:9.0 AS build
WORKDIR /src

# 先複製 .csproj 並還原套件（利用 Docker layer cache 加速後續建置）
COPY ["MyAgentApi/MyAgentApi.csproj", "MyAgentApi/"]
RUN dotnet restore "MyAgentApi/MyAgentApi.csproj"

# 複製其餘原始碼並發佈
COPY . .
WORKDIR "/src/MyAgentApi"
RUN dotnet publish "MyAgentApi.csproj" \
    -c Release \
    -o /app/publish \
    --no-restore

# ── 階段二：執行（Runtime Stage）────────────────────────────────
FROM mcr.microsoft.com/dotnet/aspnet:9.0 AS runtime
WORKDIR /app

# 建立非 root 使用者（安全最佳實踐）
RUN adduser --disabled-password --gecos "" appuser && chown -R appuser /app
USER appuser

# 從建置階段複製發佈結果
COPY --from=build /app/publish .

# 設定環境變數預設值（可在執行時被覆寫）
ENV ASPNETCORE_ENVIRONMENT=Production
ENV ASPNETCORE_HTTP_PORTS=8080

# 暴露連接埠（文件用途，實際映射在 docker run 或 compose 中設定）
EXPOSE 8080

# 健康檢查（需配合應用程式的 /health 端點）
HEALTHCHECK --interval=30s --timeout=10s --start-period=15s --retries=3 \
    CMD curl -f http://localhost:8080/health || exit 1

ENTRYPOINT ["dotnet", "MyAgentApi.dll"]
```

### Dockerfile 關鍵設計說明

**為什麼先 COPY .csproj 再 COPY . ？**

Docker 建置的 Layer Cache 機制：若 `.csproj` 沒有變動，`dotnet restore` 那一層會直接使用快取，不重新下載 NuGet 套件，可節省大量建置時間。

**為什麼用非 root 使用者？**

容器預設以 root 執行，若容器被攻破，攻擊者將取得 root 權限。建立 `appuser` 並切換，遵循最小權限原則。

**為什麼用 `aspnet` 而非 `sdk` 作為執行映像？**

`sdk` 映像包含完整的 .NET SDK（約 800MB），`aspnet` 映像只包含 ASP.NET Core 執行時期（約 200MB），正式環境不需要 SDK。

---

## .dockerignore

確保不必要的檔案不進入 Docker 建置上下文，加快建置速度並避免洩漏敏感資訊：

```dockerignore
# Git
.git
.gitignore

# .NET 建置輸出
**/bin/
**/obj/

# 測試專案
**/*.Tests/
**/*.Test/

# IDE 設定
.vs/
.vscode/
*.user
*.suo

# Docker 本身（避免循環）
Dockerfile*
docker-compose*
.dockerignore

# 本機設定（絕對不進容器）
appsettings.Development.json
**/secrets.json
**/.env
**/*.env

# 文件
*.md
docs/
```

---

## docker-compose.yml（本機開發）

`docker-compose` 用於在本機同時啟動多個相關服務（Agent API + Redis Session Store 等），模擬接近生產的環境。

```yaml
# docker-compose.yml
version: '3.9'

services:
  agent-api:
    build:
      context: .
      dockerfile: Dockerfile
    image: my-agent-api:latest
    ports:
      - "8080:8080"
    environment:
      - ASPNETCORE_ENVIRONMENT=Development
      - ASPNETCORE_HTTP_PORTS=8080
      # Azure OpenAI 設定（由 .env 檔或環境變數提供）
      - AzureOpenAI__Endpoint=${AZURE_OPENAI_ENDPOINT}
      - AzureOpenAI__Deployment=${AZURE_OPENAI_DEPLOYMENT:-gpt-4o-mini}
      # Redis Session Store（如有啟用）
      - Redis__ConnectionString=redis:6379
    depends_on:
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 15s
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    command: redis-server --appendonly yes
    volumes:
      - redis-data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 3

volumes:
  redis-data:
```

### docker-compose.override.yml（本機覆寫設定）

此檔案由每個開發者在本機維護，**不要提交到 Git**：

```yaml
# docker-compose.override.yml（加入 .gitignore）
version: '3.9'

services:
  agent-api:
    environment:
      - ASPNETCORE_ENVIRONMENT=Development
      # 本機使用 OpenAI（非 Azure）
      - OpenAI__ApiKey=${OPENAI_API_KEY}
      - OpenAI__Model=gpt-4o-mini
    volumes:
      # 掛載 User Secrets（本機開發時方便使用）
      - ~/.microsoft/usersecrets:/root/.microsoft/usersecrets:ro
```

---

## 環境變數與 Secret 管理

### 本機開發：.env 檔

建立 `.env` 檔（**絕對不要提交到 Git**）：

```bash
# .env（加入 .gitignore）
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4o-mini
```

啟動時 docker-compose 會自動讀取同目錄的 `.env`：

```bash
docker compose up
```

或明確指定：

```bash
docker compose --env-file .env.local up
```

### 提供 .env.example 範本

讓團隊成員知道需要哪些設定：

```bash
# .env.example（提交到 Git 作為範本）
AZURE_OPENAI_ENDPOINT=https://YOUR_RESOURCE.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4o-mini
# OPENAI_API_KEY=sk-...（若使用 OpenAI 直接呼叫）
```

### 生產環境：避免在映像中埋入 Secret

永遠不要把 API Key 寫進 `Dockerfile` 或 `appsettings.json` 並 bake 進映像。正確做法：

| 平台 | 建議做法 |
|------|----------|
| **Azure Container Apps** | Managed Identity + Azure Key Vault |
| **Azure Kubernetes Service** | Workload Identity + Key Vault CSI Driver |
| **Docker Swarm** | `docker secret` |
| **本機 / CI** | 環境變數注入 |

---

## 常用 Docker 指令

### 建置映像

```bash
# 建置（在 Dockerfile 所在目錄執行）
docker build -t my-agent-api:latest .

# 建置並加標籤（版本號）
docker build -t my-agent-api:1.0.0 -t my-agent-api:latest .

# 建置特定平台（Apple Silicon 部署到 Linux 時需要）
docker build --platform linux/amd64 -t my-agent-api:latest .
```

### 執行容器

```bash
# 基本執行
docker run -p 8080:8080 \
  -e AzureOpenAI__Endpoint="https://your-resource.openai.azure.com/" \
  -e AzureOpenAI__Deployment="gpt-4o-mini" \
  my-agent-api:latest

# 背景執行 + 自動重啟
docker run -d \
  --name agent-api \
  --restart unless-stopped \
  -p 8080:8080 \
  --env-file .env \
  my-agent-api:latest
```

### docker compose 操作

```bash
# 啟動所有服務（前景）
docker compose up

# 啟動所有服務（背景）
docker compose up -d

# 重新建置並啟動
docker compose up --build

# 停止並移除容器（保留 Volume）
docker compose down

# 停止並移除容器 + Volume（清除所有資料）
docker compose down -v

# 查看即時 Log
docker compose logs -f agent-api

# 進入執行中的容器
docker compose exec agent-api sh
```

---

## 映像大小優化

執行以下指令查看各層的大小：

```bash
docker history my-agent-api:latest
```

### 優化技巧

**使用 Alpine 基底映像（選用）**：

```dockerfile
# 若相容性無問題，可改用 Alpine 版本（更小）
FROM mcr.microsoft.com/dotnet/aspnet:9.0-alpine AS runtime
```

> 注意：Alpine 使用 `musl libc`，部分 NuGet 套件可能不相容，使用前需驗證。

**Self-contained 發佈（進階）**：

```dockerfile
# 將 .NET runtime 一起打包，映像不需要 aspnet 執行時期
RUN dotnet publish "MyAgentApi.csproj" \
    -c Release \
    -r linux-x64 \
    --self-contained true \
    -p:PublishSingleFile=true \
    -o /app/publish

# 執行階段可用更小的基底映像
FROM mcr.microsoft.com/dotnet/runtime-deps:9.0 AS runtime
```

---

## CI/CD 整合（GitHub Actions 範例）

```yaml
# .github/workflows/docker-publish.yml
name: Build and Push Docker Image

on:
  push:
    branches: [main]
    tags: ['v*']

jobs:
  build-and-push:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      packages: write

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Login to GitHub Container Registry
        uses: docker/login-action@v3
        with:
          registry: ghcr.io
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Extract metadata
        id: meta
        uses: docker/metadata-action@v5
        with:
          images: ghcr.io/${{ github.repository }}/agent-api

      - name: Build and push
        uses: docker/build-push-action@v5
        with:
          context: .
          platforms: linux/amd64,linux/arm64
          push: true
          tags: ${{ steps.meta.outputs.tags }}
          labels: ${{ steps.meta.outputs.labels }}
          # 使用 GitHub Actions cache 加速建置
          cache-from: type=gha
          cache-to: type=gha,mode=max
```

---

## 完整啟動驗證

部署後執行以下驗證，確認服務正常運作：

```bash
# 1. 確認容器狀態為 healthy
docker compose ps

# 2. 測試健康檢查端點
curl http://localhost:8080/health

# 3. 測試代理 API
curl -X POST http://localhost:8080/api/agent/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "你好，請自我介紹"}'

# 4. 確認無錯誤日誌
docker compose logs agent-api | grep -i error
```

---

## 本章小結

| 主題 | 關鍵要點 |
|------|----------|
| **Dockerfile** | 多階段建置（build + runtime）、非 root 使用者、健康檢查 |
| **docker-compose** | 本機多服務編排、`.env` 注入環境變數、Volume 持久化 |
| **Secret 管理** | 永不 bake 進映像、生產用 Managed Identity / Key Vault |
| **CI/CD** | GitHub Actions 建置 + 推送至 Container Registry |

---

> **返回目錄**：[README](README.md) | **上一章**：[12 — 測試策略](./12-testing-strategy.md) | **下一章**：[14 — Context Providers 深度](./14-context-providers.md)
