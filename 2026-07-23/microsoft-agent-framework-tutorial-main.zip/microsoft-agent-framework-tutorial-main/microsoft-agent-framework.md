# Microsoft Agent Framework 全面研究報告

> 最後更新：2026 年 3 月 27 日

---

## 目錄

1. [概述](#概述)
2. [Microsoft 生態系中的三大代理開發工具](#microsoft-生態系中的三大代理開發工具)
3. [Microsoft Agent Framework（核心框架）](#microsoft-agent-framework核心框架)
4. [Microsoft 365 Agents SDK（通道與對話管理）](#microsoft-365-agents-sdk通道與對話管理)
5. [Microsoft Foundry Agent Service（雲端託管服務）](#microsoft-foundry-agent-service雲端託管服務)
6. [架構與核心元件](#架構與核心元件)
7. [支援的開放協定](#支援的開放協定)
8. [GitHub 儲存庫一覽](#github-儲存庫一覽)
9. [官方文件與學習資源](#官方文件與學習資源)
10. [最新更新（2025 年底 ~ 2026 年初）](#最新更新2025-年底--2026-年初)
11. [從 Semantic Kernel / AutoGen 遷移](#從-semantic-kernel--autogen-遷移)
12. [定價模式](#定價模式)

---

## 概述

Microsoft 在 AI 代理（Agent）開發領域推出了一套完整的工具鏈，涵蓋從底層框架、通道管理 SDK 到雲端託管平台。這些工具共同構成了 Microsoft 的「代理生態系」，讓開發者能夠使用 .NET 或 Python 建構、編排、部署企業級 AI 代理。

核心定位是：**將 Semantic Kernel 的企業級穩定性與 AutoGen 的多代理編排能力統一整合為一個開源框架**。

---

## Microsoft 生態系中的三大代理開發工具

Microsoft 的代理開發工具可以分為三個層次，各自承擔不同的職責：

| 工具 | 定位 | 核心職責 |
|------|------|----------|
| **Microsoft Agent Framework** | 底層開源框架 | 建構代理邏輯、AI 編排、多代理工作流程 |
| **Microsoft 365 Agents SDK** | 通道與對話管理 | 處理與 Teams、Copilot、Web 等通道的連接與對話管理 |
| **Microsoft Foundry Agent Service** | 雲端託管平台 | 代理的託管、擴展、安全性、可觀測性 |

這三者可以獨立使用，也可以組合使用以建構完整的端到端代理解決方案。

---

## Microsoft Agent Framework（核心框架）

### 簡介

Microsoft Agent Framework 是一個開源框架（MIT 授權），用於建構、編排和部署 AI 代理及多代理工作流程，支援 Python 和 .NET。它是 **Semantic Kernel 和 AutoGen 的直接繼承者**，結合了兩者的優點：

- **AutoGen** 的簡潔抽象：單代理與多代理模式
- **Semantic Kernel** 的企業級功能：Session 狀態管理、型別安全、過濾器、遙測、廣泛的模型與嵌入支援

### 核心建構模組

- **Model Clients**：聊天補全（Chat Completions）與回應（Responses）API 客戶端
- **Agent Session**：代理的狀態管理機制
- **Context Providers**：代理記憶體的上下文提供者
- **Middleware**：攔截代理行為的中介軟體管線
- **MCP Clients**：透過 Model Context Protocol 整合外部工具
- **Graph-based Workflows**：基於圖形的工作流程，支援串流、檢查點、Human-in-the-Loop 與時光旅行功能

### 支援語言

- **Python**（主要開發語言之一）
- **C# / .NET**（主要開發語言之一）

### 支援的 LLM 提供者

框架支援多種 LLM 提供者，包括 Azure OpenAI、OpenAI、Anthropic 等，並持續新增更多提供者。

---

## Microsoft 365 Agents SDK（通道與對話管理）

### 簡介

Microsoft 365 Agents SDK 專注於**對話管理、通道/客戶端管理和驗證功能**。它簡化了代理部署到不同通道的實作，包括：

- Microsoft 365 Copilot
- Microsoft Teams
- Web 與自訂應用程式
- 其他第三方訊息通道

### 核心功能

- 處理與各通道之間的通訊協定
- 對話狀態管理
- 身份驗證與授權
- 可搭配 Azure AI Foundry SDK、Semantic Kernel 和其他供應商的 AI 元件使用

### 與 Agent Framework 的關係

Agents SDK 是建構代理的基礎平台，提供通道管理和編排能力。開發者可以在 Agents SDK 中整合 Agent Framework 來實作代理的 AI 邏輯。

### 開發工具

**Microsoft 365 Agents Toolkit** 是一套工具組，用於建構跨 Microsoft 365 Copilot、Teams、Office、Web 及其他第三方訊息通道的企業級代理與應用程式。

### 從 Bot Framework SDK 遷移

Microsoft 365 Agents SDK 是 Azure Bot Framework SDK 的演進版本，官方提供了完整的遷移指南。

---

## Microsoft Foundry Agent Service（雲端託管服務）

### 簡介

Microsoft Foundry Agent Service（前稱 Azure AI Agent Service）是一個完全託管的平台，用於建構、部署和擴展 AI 代理。它於 **2026 年 3 月 16 日正式 GA（正式發佈）**。

### 核心功能

- **任何框架支援**：支援 Agent Framework、LangGraph 或自訂程式碼
- **無程式碼代理**：在 Foundry Portal 中建立基於提示的代理
- **程式碼代理**：使用 SDK 和 REST API 部署自訂代理
- **託管與擴展**：自動處理代理的託管與水平擴展
- **企業安全**：內建身份驗證、私有網路、安全性功能
- **可觀測性**：內建 OpenTelemetry 分散式追蹤與監控

### 進階功能

- **Memory（公開預覽）**：託管的長期記憶體儲存，支援跨代理 Session 的自動擷取、彙整與檢索
- **Multi-Agent Workflows**：多代理工作流程編排，用於複雜的多步驟業務流程
- **Durable Agent Orchestration**：搭配 Azure Durable Functions 和 SignalR 實現持久化代理編排

---

## 架構與核心元件

### 整體架構層次

```
┌─────────────────────────────────────────┐
│          使用者介面 / 通道               │
│   (Teams, Copilot, Web, Custom Apps)    │
├─────────────────────────────────────────┤
│       Microsoft 365 Agents SDK          │
│   (通道管理、對話管理、身份驗證)          │
├─────────────────────────────────────────┤
│       Microsoft Agent Framework         │
│   (代理邏輯、AI 編排、多代理工作流程)     │
├─────────────────────────────────────────┤
│      Microsoft Foundry Agent Service    │
│   (託管、擴展、安全性、可觀測性)          │
├─────────────────────────────────────────┤
│           LLM 提供者                     │
│   (Azure OpenAI, OpenAI, Anthropic...) │
└─────────────────────────────────────────┘
```

### Agent Framework 內部架構

- **ChatAgent**：核心代理抽象，負責處理對話與推理
- **Tool Abstractions**：工具定義與呼叫的統一介面
- **Middleware Pipeline**：請求/回應處理的中介軟體管線
- **Graph-based Orchestration**：基於圖形的多代理編排引擎
- **Checkpointing**：狀態檢查點機制，支援恢復與時光旅行
- **Streaming**：支援串流回應與漸進式內容更新

---

## 支援的開放協定

Microsoft Agent Framework 積極擁抱開放標準，支援以下協定：

### MCP（Model Context Protocol）

- 讓代理能夠動態發現並呼叫外部工具或資料伺服器
- 處理代理與工具之間的通訊
- 支援雙向工具整合

### A2A（Agent-to-Agent Protocol）

- 開放標準，用於代理之間透過 HTTP 進行發現與通訊
- 代理可以跨不同執行環境使用結構化、協定驅動的訊息進行協作
- 支援跨框架的多代理工作流程

### AG-UI（Agent-to-User Interface）

- 連接代理與終端使用者的協定
- 處理代理與 UI 之間的互動

### 協定堆疊層次

```
代理協調 (A2A) → 工具整合 (MCP) → 執行環境 (AG-UI) → 使用者介面
```

---

## GitHub 儲存庫一覽

### Microsoft Agent Framework

| 儲存庫 | 說明 | 網址 |
|--------|------|------|
| **microsoft/agent-framework** | 主儲存庫（Python + .NET） | https://github.com/microsoft/agent-framework |
| **microsoft/Agent-Framework-Samples** | 範例程式碼 | https://github.com/microsoft/Agent-Framework-Samples |

### Microsoft 365 Agents SDK

| 儲存庫 | 說明 | 網址 |
|--------|------|------|
| **microsoft/Agents** | 主儲存庫 | https://github.com/microsoft/Agents |
| **microsoft/Agents-for-net** | .NET SDK 元件 | https://github.com/microsoft/Agents-for-net |
| **microsoft/Agents-for-python** | Python SDK 元件 | https://github.com/microsoft/Agents-for-python |
| **microsoft/Agents-for-js** | JavaScript SDK 元件 | https://github.com/microsoft/Agents-for-js |

### 相關工具與範例

| 儲存庫 | 說明 | 網址 |
|--------|------|------|
| **OfficeDev/microsoft-365-agents-toolkit** | Agents Toolkit 開發工具 | https://github.com/OfficeDev/microsoft-365-agents-toolkit |
| **microsoft/Agent365-Samples** | Agent 365 範例 | https://github.com/microsoft/Agent365-Samples |
| **webmaxru/awesome-microsoft-agent-framework** | 社群資源彙整 | https://github.com/webmaxru/awesome-microsoft-agent-framework |

---

## 官方文件與學習資源

### Microsoft Learn 文件

- **Microsoft Agent Framework 概述**：https://learn.microsoft.com/en-us/agent-framework/overview/
- **Microsoft 365 Agents SDK 概述**：https://learn.microsoft.com/en-us/microsoft-365/agents-sdk/agents-sdk-overview
- **Microsoft 365 Agents SDK 文件首頁**：https://learn.microsoft.com/en-us/microsoft-365/agents-sdk/
- **Microsoft Foundry Agent Service 概述**：https://learn.microsoft.com/en-us/azure/foundry/agents/overview
- **Agent Framework 中的代理類型**：https://learn.microsoft.com/en-us/agent-framework/agents/
- **在 Agents SDK 中使用 Semantic Kernel 和 Agent Framework**：https://learn.microsoft.com/en-us/microsoft-365/agents-sdk/using-semantic-kernel-agent-framework
- **從 Bot Framework SDK 遷移指南**：https://learn.microsoft.com/en-us/microsoft-365/agents-sdk/bf-migration-guidance
- **JavaScript API 參考**：https://learn.microsoft.com/en-us/javascript/api/overview/agents-overview
- **Microsoft Agent 365 概述**：https://learn.microsoft.com/en-us/microsoft-agent-365/overview
- **Microsoft Agent 365 SDK 與 CLI**：https://learn.microsoft.com/en-us/microsoft-agent-365/developer/

### 部落格與公告

- **Microsoft Agent Framework 官方部落格**：https://devblogs.microsoft.com/agent-framework/
- **Semantic Kernel 團隊部落格文章**：https://devblogs.microsoft.com/semantic-kernel/semantic-kernel-and-microsoft-agent-framework/
- **Foundry 團隊公告**：https://devblogs.microsoft.com/foundry/introducing-microsoft-agent-framework-the-open-source-engine-for-agentic-ai-apps/
- **Agent Framework RC 公告**：https://devblogs.microsoft.com/foundry/microsoft-agent-framework-reaches-release-candidate/
- **Foundry Agent Service GA 公告**：https://devblogs.microsoft.com/foundry/foundry-agent-service-ga/

### 教學與實作

- **Copilot Developer Camp 實作教學**：https://microsoft.github.io/copilot-camp/pages/custom-engine/agents-sdk/02-agent-with-agents-sdk/
- **AI Agents for Beginners 教程**：https://microsoft.github.io/ai-agents-for-beginners/14-microsoft-agent-framework/
- **實戰範例（Agent Framework + Foundry + MCP + Aspire）**：https://developer.microsoft.com/blog/build-a-real-world-example-with-microsoft-agent-framework-microsoft-foundry-mcp-and-aspire

### 定價資訊

- **Foundry Agent Service 定價頁面**：https://azure.microsoft.com/en-us/pricing/details/foundry-agent-service/
- **Microsoft Foundry 整體定價**：https://azure.microsoft.com/en-us/pricing/details/microsoft-foundry/

---

## 最新更新（2025 年底 ~ 2026 年初）

### 2025 年 10 月

- **Agent Framework 公開預覽**：Microsoft Agent Framework 以 MIT 授權在 GitHub 上發佈公開預覽版，統一 Semantic Kernel 和 AutoGen。

### 2025 年 11 月（Ignite 2025）

- **Foundry Agent Service** 在 Ignite 2025 上展示重大更新，主題為「簡單建構、強力部署、可信運營」。

### 2025 年 12 月 ~ 2026 年 1 月

- Foundry 生態系更新，包含多項代理服務的改善。

### 2026 年 2 月

- **Agent Framework 達到 Release Candidate（RC）**：
  - Python `1.0.0rc1` 於 2026 年 2 月 19 日發佈
  - .NET 版本同步達到 RC 狀態
  - API 表面穩定且功能完整，目標 1.0 版本
- **Python API 重大變更**：
  - ChatClient pipeline 排序變更：FunctionInvocation 現在是最外層
  - 串流 Code-Interpreter 現在支援漸進式程式碼更新
- **新模式**：Durable Agent Orchestration（搭配 Azure Durable Functions + SignalR）
- **AI Toolkit for VS Code v0.30.0**：引入 Tool Catalog、Agent Inspector（F5 偵錯）和重新設計的 Agent Builder

### 2026 年 3 月

- **Foundry Agent Service 正式 GA**（2026 年 3 月 16 日）：
  - 支援私有網路
  - Voice Live 功能
  - 企業級評估工具
  - 生產就緒的 REST API
- **Agent Framework Python `1.0.0rc5`**（2026 年 3 月 20 日）：
  - 多項 Bug 修復與改善
  - 預計 GA 時間：2026 年 3 月底

---

## 從 Semantic Kernel / AutoGen 遷移

### Semantic Kernel 使用者

- 將 `Kernel` 和 `Plugin` 模式替換為新的 `Agent` 和 `Tool` 抽象
- 大部分概念可直接對應，遷移路徑相對平滑

### AutoGen 使用者

- 將 `AssistantAgent` 對應到新的 `ChatAgent`
- 可享受檢查點、簡化的訊息傳遞和更強的持久性功能

---

## 定價模式

### Foundry Agent Service

- **代理建立與執行**：使用提示和工作流程建立的 Foundry 原生代理**不額外收費**
- **模型消耗**：透過 Foundry Models 的 Token 消耗會產生費用
- **工具與連接器**：Foundry Tools 和 Foundry IQ 連接有獨立的收費與授權
- **預購方案**：Microsoft Agent 預購計畫允許預先購買 Agent Commit Units（ACUs），享有折扣優惠，可靈活用於各種 Microsoft 服務

### 整體定價策略

採用**消費制（Pay-as-you-go）**模式，按實際使用量付費，而非固定的服務費用。

---

## 總結

Microsoft Agent Framework 生態系為開發者提供了一套完整的工具鏈：

1. **Agent Framework**（開源）負責代理的核心 AI 邏輯與多代理編排
2. **365 Agents SDK** 處理與各種通道的連接與對話管理
3. **Foundry Agent Service** 提供企業級的雲端託管、安全性與可觀測性

這三者結合開放協定（MCP、A2A、AG-UI），讓開發者能夠建構跨平台、跨框架的企業級 AI 代理解決方案。框架目前正處於 RC 階段，預計 2026 年 3 月底至 4 月正式 GA。
