#!/usr/bin/env python3
"""Deterministic validation for the tutorial, KB, Codex setup, and upstream baseline."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import tomllib
from pathlib import Path
from urllib.parse import unquote


ROOT = Path(__file__).resolve().parents[1]
KB = ROOT / "agent-framework-kb"
WIKI = KB / "wiki"
CONCEPTS = WIKI / "concepts"
TUTORIAL = ROOT / "microsoft-agent-framework-tutorial"
UPSTREAM = ROOT / "agent-framework"

REQUIRED_FRONTMATTER = {
    "title",
    "api_name",
    "namespace",
    "since",
    "current_version",
    "updated",
    "tags",
    "tutorial_chapters",
    "sources",
}
EXPECTED_SKILLS = {
    "compile",
    "draft-appendix",
    "draft-chapter",
    "drift-check",
    "extract-facts",
    "lint",
    "regenerate-toc",
    "release-summary",
    "save-qa",
    "snapshot-knowledge",
    "sync-upstream",
    "update-tutorial",
    "wiki-query",
}


class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.checks = 0

    def check(self, condition: bool, message: str) -> None:
        self.checks += 1
        if not condition:
            self.errors.append(message)

    def warn(self, condition: bool, message: str) -> None:
        self.checks += 1
        if not condition:
            self.warnings.append(message)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def frontmatter(text: str) -> tuple[dict[str, str], str]:
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text
    try:
        end = lines.index("---", 1)
    except ValueError:
        return {}, text
    fields: dict[str, str] = {}
    for line in lines[1:end]:
        match = re.match(r"^([A-Za-z_][A-Za-z0-9_-]*):\s*(.*)$", line)
        if match:
            fields[match.group(1)] = match.group(2).strip()
    return fields, "\n".join(lines[end + 1 :])


def validate_layout(report: Report) -> None:
    for relative in (
        "AGENTS.md",
        ".codex/config.toml",
        ".agents/skills",
        "agent-framework-kb/AGENTS.md",
        "agent-framework-kb/UPSTREAM-REF.md",
        "agent-framework-kb/wiki/INDEX.md",
        "microsoft-agent-framework-tutorial/AGENTS.md",
    ):
        report.check((ROOT / relative).exists(), f"缺少必要 Codex artifact：{relative}")

    config_path = ROOT / ".codex/config.toml"
    if config_path.exists():
        try:
            config = tomllib.loads(read_text(config_path))
            server = config.get("mcp_servers", {}).get("codebase-memory-mcp", {})
            report.check(server.get("command") == "codebase-memory-mcp", "Codex MCP command 未正確設定")
            report.check(server.get("required") is True, "codebase-memory-mcp 應設定 required = true")
        except (tomllib.TOMLDecodeError, OSError) as exc:
            report.check(False, f".codex/config.toml 無法解析：{exc}")


def validate_skills(report: Report) -> None:
    skills_root = ROOT / ".agents/skills"
    if not skills_root.exists():
        return
    actual = {path.name for path in skills_root.iterdir() if path.is_dir()}
    report.check(actual == EXPECTED_SKILLS, f"Codex skills 集合不一致：actual={sorted(actual)}")
    for name in sorted(EXPECTED_SKILLS & actual):
        skill = skills_root / name / "SKILL.md"
        metadata = skills_root / name / "agents/openai.yaml"
        report.check(skill.exists(), f"{name} 缺少 SKILL.md")
        report.check(metadata.exists(), f"{name} 缺少 agents/openai.yaml")
        if skill.exists():
            fields, _ = frontmatter(read_text(skill))
            report.check(fields.get("name", "").strip('"\'') == name, f"{name} frontmatter name 不符")
            report.check(bool(fields.get("description", "").strip('"\'')), f"{name} 缺少 description")
            content = read_text(skill)
            report.check("MANUAL MIGRATION REQUIRED" not in content, f"{name} 仍含 manual migration block")
            report.check("source-command-" not in content, f"{name} 仍含 generated source-command 名稱")
        if metadata.exists():
            metadata_text = read_text(metadata)
            report.check(f"${name}" in metadata_text, f"{name} openai.yaml default prompt 未引用 skill 名稱")


def validate_json(report: Report) -> None:
    json_paths = sorted((KB / "raw/facts").glob("*.json"))
    graph_dir = WIKI / ".understand-anything"
    json_paths.extend(path for path in (graph_dir / "knowledge-graph.json", graph_dir / "meta.json") if path.exists())
    for path in json_paths:
        try:
            json.loads(read_text(path))
        except (json.JSONDecodeError, OSError) as exc:
            report.check(False, f"JSON 無法解析：{path.relative_to(ROOT)}：{exc}")
        else:
            report.check(True, "")


def validate_concepts(report: Report) -> None:
    concept_paths = sorted(CONCEPTS.glob("*.md"))
    report.check(len(concept_paths) == 42, f"concept 數量應為 42，實際為 {len(concept_paths)}")
    names = {path.stem for path in concept_paths}
    index_text = read_text(WIKI / "INDEX.md")

    for path in concept_paths:
        fields, body = frontmatter(read_text(path))
        missing = sorted(REQUIRED_FRONTMATTER - fields.keys())
        report.check(not missing, f"{path.name} 缺少 frontmatter：{', '.join(missing)}")
        report.check(f"[[{path.stem}]]" in index_text, f"INDEX.md 未列出 concept：{path.name}")
        tags = fields.get("tags", "")
        alternate = any(tag in tags for tag in ("deprecated", "devops", "migration", "testing-pattern"))
        if not alternate:
            for heading in ("概述", "目前 API 簽名", "變更歷史", "教學章節對應"):
                report.warn(f"## {heading}" in body, f"{path.name} 缺少標準段落：{heading}")

        for target in re.findall(r"\[\[([^\]]+)\]\]", body):
            normalized = target.split("|", 1)[0].split("#", 1)[0].strip()
            report.check(normalized in names, f"{path.name} 含斷裂 wikilink：[[{target}]]")

        lines = read_text(path).splitlines()
        in_sources = False
        for line in lines:
            if line.startswith("sources:"):
                in_sources = True
                continue
            if in_sources and re.match(r"^[A-Za-z_][A-Za-z0-9_-]*:", line):
                break
            if in_sources:
                match = re.match(r"^\s+-\s+(.+?)\s*$", line)
                if not match:
                    continue
                source = match.group(1).strip('"\'')
                if source.startswith("raw/"):
                    report.check((KB / source).exists(), f"{path.name} 的來源不存在：{source}")


def validate_markdown_links(report: Report) -> None:
    link_pattern = re.compile(r"(?<!!)\[[^\]]+\]\(([^)]+)\)")
    active_docs = [
        ROOT / "README.md",
        ROOT / "SETUP.md",
        KB / "README.md",
        KB / "QuickStart.md",
        KB / "PLAYBOOK-version-update.md",
    ]
    paths = sorted(TUTORIAL.glob("*.md")) + active_docs
    for path in paths:
        text = read_text(path)
        for raw_target in link_pattern.findall(text):
            target = raw_target.strip().split(maxsplit=1)[0].strip("<>")
            if not target or target.startswith(("#", "http://", "https://", "mailto:")):
                continue
            target = unquote(target.split("#", 1)[0].split("?", 1)[0])
            if not target:
                continue
            report.check((path.parent / target).resolve().exists(), f"{path.name} 的連結不存在：{raw_target}")


def validate_release_summaries(report: Report) -> None:
    root_readme = read_text(ROOT / "README.md")
    fact_pattern = re.compile(r"^dotnet-(\d+\.\d+\.\d+)-verified-changes\.json$")
    for fact_path in sorted((KB / "raw/facts").glob("dotnet-*-verified-changes.json")):
        match = fact_pattern.match(fact_path.name)
        if not match:
            continue
        version = match.group(1)
        summary_name = f"v{version}-update-summary.md"
        report.check((ROOT / summary_name).exists(), f"verified release v{version} 缺少版本摘要：{summary_name}")
        report.check(
            f"(./{summary_name})" in root_readme,
            f"根 README 未連結 verified release v{version} 的版本摘要：{summary_name}",
        )


def validate_toc(report: Report) -> None:
    readme = read_text(TUTORIAL / "README.md")
    chapters = sorted(TUTORIAL.glob("[0-9][0-9]-*.md"))
    appendices = sorted(TUTORIAL.glob("appendix-*.md"))
    report.check(len(chapters) == 30, f"正式章節數應為 30，實際為 {len(chapters)}")
    report.check(len(appendices) == 9, f"正式附錄數應為 9，實際為 {len(appendices)}")
    for path in chapters + appendices:
        report.check(path.name in readme, f"教學 README TOC 未列出：{path.name}")


def validate_graph(report: Report) -> None:
    graph_path = WIKI / ".understand-anything/knowledge-graph.json"
    meta_path = WIKI / ".understand-anything/meta.json"
    if not graph_path.exists() or not meta_path.exists():
        report.check(False, "UA knowledge graph 或 meta.json 不存在")
        return
    try:
        graph = json.loads(read_text(graph_path))
        meta = json.loads(read_text(meta_path))
    except json.JSONDecodeError:
        return
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])
    article_nodes = sum(1 for node in nodes if node.get("type") == "article")
    report.check(bool(nodes) and bool(edges), "UA graph nodes 或 edges 為空")
    report.check(meta.get("analyzedFiles") == article_nodes, "UA meta analyzedFiles 與 article node 數不一致")
    root_readme = read_text(ROOT / "README.md")
    match = re.search(r"\*\*(\d+) nodes、(\d+) edges", root_readme)
    report.check(bool(match), "根 README 缺少 UA graph 統計")
    if match:
        report.check((int(match.group(1)), int(match.group(2))) == (len(nodes), len(edges)), "根 README 的 UA graph 統計已過時")


def current_version_and_commit(report: Report) -> tuple[str | None, str | None]:
    text = read_text(KB / "UPSTREAM-REF.md")
    version_match = re.search(r"知識庫基準版本\*\*\s*\|\s*v(\d+\.\d+\.\d+)", text)
    commit_match = re.search(r"Commit Hash\*\*\s*\|\s*`([0-9a-f]{40})`", text)
    report.check(bool(version_match), "UPSTREAM-REF.md 無法解析基準版本")
    report.check(bool(commit_match), "UPSTREAM-REF.md 無法解析 commit hash")
    version = version_match.group(1) if version_match else None
    commit = commit_match.group(1) if commit_match else None
    if version:
        root_readme = read_text(ROOT / "README.md")
        report.check(f"v{version}" in root_readme.splitlines()[2], "根 README 基準版本與 UPSTREAM-REF 不一致")
        tutorial_readme = read_text(TUTORIAL / "README.md")
        report.check(f"**{version}（穩定版）**" in tutorial_readme, "教學 README 框架版本與 UPSTREAM-REF 不一致")
        drift = read_text(WIKI / "drift-report.md")
        report.check(f"v{version}" in drift, "drift-report baseline 與 UPSTREAM-REF 不一致")
    return version, commit


def git(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["git", *args], cwd=ROOT, text=True, capture_output=True, check=False)


def validate_upstream(report: Report, require: bool, clean: bool, version: str | None, commit: str | None) -> None:
    if not UPSTREAM.exists():
        if require:
            report.check(False, "缺少 agent-framework/ 上游 clone")
        else:
            report.warn(False, "未檢查上游：agent-framework/ 不存在")
        return
    inside = git("-C", str(UPSTREAM), "rev-parse", "--is-inside-work-tree")
    report.check(inside.returncode == 0, "agent-framework/ 不是有效 git worktree")
    if inside.returncode != 0:
        return
    head = git("-C", str(UPSTREAM), "rev-parse", "HEAD")
    if commit:
        report.check(head.stdout.strip() == commit, f"上游 HEAD 與 UPSTREAM-REF 不一致：{head.stdout.strip()}")
    if version:
        tag = git("-C", str(UPSTREAM), "describe", "--tags", "--exact-match", "HEAD")
        report.check(tag.stdout.strip() == f"dotnet-{version}", f"上游 tag 應為 dotnet-{version}，實際為 {tag.stdout.strip() or 'none'}")
    if clean:
        status = git("-C", str(UPSTREAM), "status", "--porcelain")
        report.check(not status.stdout.strip(), "agent-framework/ 上游工作樹不是 clean")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--require-upstream", action="store_true", help="Fail when the local upstream clone is absent")
    parser.add_argument("--check-upstream-clean", action="store_true", help="Fail when the upstream worktree is dirty")
    args = parser.parse_args()

    report = Report()
    validate_layout(report)
    validate_skills(report)
    validate_json(report)
    validate_concepts(report)
    validate_markdown_links(report)
    validate_release_summaries(report)
    validate_toc(report)
    validate_graph(report)
    version, commit = current_version_and_commit(report)
    validate_upstream(report, args.require_upstream, args.check_upstream_clean, version, commit)

    for warning in report.warnings:
        print(f"WARN  {warning}")
    for error in report.errors:
        print(f"ERROR {error}")
    print(f"\nWorkspace validation: {report.checks} checks, {len(report.errors)} errors, {len(report.warnings)} warnings")
    return 1 if report.errors else 0


if __name__ == "__main__":
    sys.exit(main())
