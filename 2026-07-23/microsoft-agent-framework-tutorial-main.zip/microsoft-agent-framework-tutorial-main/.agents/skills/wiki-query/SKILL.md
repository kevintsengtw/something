---
name: "wiki-query"
description: "Answer Agent Framework questions from the local structured wiki, changelog, index, QA sessions, and verified facts with file citations. Use for concept explanations, API usage, version changes, and tutorial chapter lookup without modifying files."
---

# Wiki Query — 查詢知識庫

在 `agent-framework-kb/wiki/concepts/` 與 `agent-framework-kb/wiki/api-changelog.md` 中搜尋與使用者問題相關的結構化知識。

## 使用方式

`$wiki-query <問題或關鍵字>`

範例：
- `$wiki-query AgentSession 的建立方式`
- `$wiki-query Middleware 的三層架構`
- `$wiki-query v1.13.0 有哪些 breaking change`

## 執行步驟

1. **解析查詢意圖**
   - 判斷查詢類型：概念說明、API 用法、版本變更、教學對應

2. **搜尋知識庫**
   - 在 `agent-framework-kb/wiki/concepts/` 找出相關條目（依 title、api_name、tags 匹配）
   - 在 `agent-framework-kb/wiki/api-changelog.md` 找出相關版本變更
   - 在 `agent-framework-kb/wiki/INDEX.md` 找出分類位置
   - 在 `agent-framework-kb/brainstorming/qa-sessions/` 搜尋相關 QA 記錄

3. **組合回答**
   - 繁體中文回答
   - 引用具體的 wiki/concepts/ 條目
   - 附上對應教學章節連結（如有）
   - 若 wiki/ 資訊不足，提示需先 `$sync-upstream` + `$compile`

4. **顯示來源**
   - 列出 wiki/ 檔案路徑
   - 列出對應 raw/ 原始素材路徑

## 注意事項

- 此指令是**純讀取**，只搜尋 kb 內容，不修改任何檔案
- 對深入語意問題，可改用 UA 原生 `/understand-chat`
- 對結構性問題（call graph、依賴），改用 `mcp__codebase-memory-mcp__get_code_snippet` 或 `trace_path`
