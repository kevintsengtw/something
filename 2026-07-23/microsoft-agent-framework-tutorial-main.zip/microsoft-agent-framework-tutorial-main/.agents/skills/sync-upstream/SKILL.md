---
name: "sync-upstream"
description: "Synchronize official Agent Framework release notes, ADRs, Learn material, samples, and the local upstream tag without editing upstream source. Use when a new .NET or Python release appears or before starting a version-maintenance cycle."
---

# Sync Upstream — 同步上游素材與索引

從 Microsoft Agent Framework 的 GitHub 儲存庫與 Microsoft Learn 抓取最新素材，放入 `agent-framework-kb/raw/`，並對 `agent-framework/` 確認 codebase-memory-mcp 索引已同步。

開始前執行 `git -C agent-framework status --short`；若不是 clean，停止。不要使用會合併分支的 `git pull`。先 `git -C agent-framework fetch --tags origin`，確認目標 release tag，再以 detached HEAD checkout 該 tag。結束時再次確認上游 clean，更新 `UPSTREAM-REF.md`，並以 `list_projects`／`index_status` 驗證索引。

## 執行步驟

1. **檢查 raw/ 現有內容**
   - 列出 `agent-framework-kb/raw/` 各子目錄的現有檔案
   - 記錄最後更新日期（從檔案的 YAML frontmatter 或檔名中取得）

2. **抓取 ADR 文件**
   - 來源：`https://github.com/microsoft/agent-framework/tree/main/docs/decisions/`
   - 使用可用的網頁讀取工具或 `gh api` 取得每個 ADR 的 raw 內容
   - 存入 `agent-framework-kb/raw/adrs/`，檔名保持原名
   - 只抓取新增或更新的 ADR

3. **抓取 Release Notes**
   - 來源：`https://github.com/microsoft/agent-framework/releases`
   - 抓取最新的 .NET 與 Python release notes
   - 存入 `agent-framework-kb/raw/release-notes/`，檔名格式：`dotnet-{version}.md`

4. **抓取 API Surface 摘要**
   - 來源：NuGet 套件公開 API 或 GitHub 原始碼的 public class/interface
   - 更新 `agent-framework-kb/raw/api-surface/` 中的套件 API 摘要

5. **抓取 Microsoft Learn 文件**
   - 來源：`https://learn.microsoft.com/en-us/agent-framework/`
   - 抓取概覽、快速入門、代理類型等核心文件
   - 存入 `agent-framework-kb/raw/learn/`

6. **檢查官方 Samples 範例庫更新**
   - 讀取 `agent-framework-kb/raw/samples/README.md` frontmatter 中的 `fetched` 日期與 `last_sync_version`
   - 用 `gh api` 取得 samples repo 最新 commit：
     ```bash
     gh api "repos/microsoft/Agent-Framework-Samples/commits?per_page=5" \
       --jq '.[] | {sha: .sha[0:7], date: .commit.committer.date, message: (.commit.message | split("\n")[0])}'
     ```
   - 比對最新 commit 日期與 `fetched` 日期：
     - 若 **無新 commit**（日期相同或更早）：記錄「Samples repo 無更新」，跳過後續步驟
     - 若 **有新 commit**：繼續以下步驟
   - 列出自上次同步以來有變動的目錄：
     ```bash
     gh api "repos/microsoft/Agent-Framework-Samples/contents" \
       --jq '[.[] | select(.type == "dir") | .name]'
     ```
   - 對有變動的目錄，抓取其 README.md 內容作為摘要素材：
     ```bash
     gh api "repos/microsoft/Agent-Framework-Samples/contents/<dir>/README.md" \
       --jq '.content' | base64 -d
     ```
   - 重點關注：
     - 新增的 .NET 範例（與 SDK release 對應）
     - API 用法模式變更（新的類別/方法出現在範例中）
     - 與最新 SDK 版本不匹配的範例（可能已過時）
   - 更新 `agent-framework-kb/raw/samples/README.md`：
     - frontmatter 的 `fetched` 更新為今日日期
     - `last_sync_version` 更新為本次同步的 SDK 版本
     - 新增或更新受影響目錄的說明段落

7. **更新上游 SDK 原始碼與 codebase-memory-mcp 索引**
   - `git -C agent-framework fetch --tags origin` 取得最新 tags
   - 確認 release tag 後，以 `git -C agent-framework checkout --detach <tag>` 對齊；不要 merge 或修改上游檔案
   - **首次使用**需執行：
     ```
     mcp__codebase-memory-mcp__index_repository
       repo_path: "agent-framework"
     ```
     完成後用 `list_projects` 依 `root_path` 確認 project 名稱
   - **後續同步**：先用 `index_status` 與查詢抽樣確認 file watcher 已同步；若索引數值或 commit 證據不符，才重跑 `index_repository`

8. **codebase-memory-mcp 新 API 存在性確認**
   - 從本次 release notes/ADR 找出新增或改名的 API 名稱
   - 使用 `search_graph` 逐一確認是否已存在於圖譜：
     ```
     mcp__codebase-memory-mcp__search_graph
       project: "<由 list_projects 依 root_path 解析>"
       name_pattern: "<新 API 名稱>"
     ```
   - 有結果代表上游原始碼已包含此 API，記錄確認清單作為 `$extract-facts` 的重點線索
   - 若查無節點，記錄警告（可能文件超前於原始碼，或 API 名稱有誤）

9. **產出同步摘要**
   - 列出本次新增/更新的檔案清單
   - 標記哪些是新的 breaking change 相關素材
   - 附上步驟 8 的 API 存在性確認結果
   - 建議接下來執行 `$extract-facts <new-version>`

## 注意事項
- 新舊比對以 `agent-framework-kb/raw/` 的實際檔案為唯一基準，不參考對話歷史
- raw/ 是唯讀基準層，同步後不做任何修改
- `agent-framework/` 內任何檔案**不可改動**——它是上游唯讀基準層
- 教學目錄 `microsoft-agent-framework-tutorial/` 不在同步範圍內
- 此指令**不呼叫 LLM 寫敘述**，純素材搬運與索引確認
