---
name: "compile"
description: "Compile new or changed verified Agent Framework source material into the structured wiki. Use when raw release notes, verified facts, ADRs, samples, or saved QA need to update wiki concepts, the API changelog, schema, or index."
---

# Compile — 編譯素材為結構化知識

讀取 `agent-framework-kb/raw/` 與 `agent-framework-kb/raw/facts/` 中的素材，編譯（新增或更新）`agent-framework-kb/wiki/concepts/` 條目與相關索引。

**核心原則**：frontmatter 結構欄位（api_name、namespace、since、current_version）**必須來自 raw/facts/*.json 的已驗證事實**，敘述（## 概述、## 變更歷史）由 LLM 撰寫但受事實清單約束。

開始前先執行 `python3 scripts/validate_workspace.py`。需要 MCP 時，先以 `list_projects` 找出 `root_path` 結尾為 `/agent-framework` 的實際 project name；下方範例中的 project placeholder 都必須替換成該名稱。

## 執行步驟

1. **掃描素材變更**
   - 讀取 `agent-framework-kb/wiki/INDEX.md` 中的 `last_compile` 時間戳
   - 列出 `agent-framework-kb/raw/` 比 last_compile 更新的檔案
   - 列出 `agent-framework-kb/raw/facts/` 中所有 JSON（事實清單）
   - 列出 `agent-framework-kb/brainstorming/qa-sessions/` 中 `promoted_to_wiki: false` 的記錄
   - 標記 [NEW] 與 [UPDATED] 素材
   - 若無變更，報告「無新素材需要編譯」並結束

2. **載入事實清單**

   讀取 `agent-framework-kb/raw/facts/*.json`（由 `$extract-facts` 產出）：
   - 建立「API 名稱 → 已驗證事實」對照表
   - 此對照表是 wiki frontmatter 的**唯一可信來源**

3. **編譯概念條目**

   對每個 [NEW] / [UPDATED] 素材涉及的核心概念：

   - 建立或更新 `agent-framework-kb/wiki/concepts/<concept-name>.md`
   - 概念名稱使用 kebab-case
   - 遵循 `agent-framework-kb/AGENTS.md` 的條目格式

   **frontmatter 填寫規則（嚴格）**：
   - `api_name`、`namespace`、`since`、`current_version`：**僅引用 raw/facts/ JSON 已驗證值**
   - `sources`：列出對應的 raw/ 檔案路徑
   - 若該 API 不在事實清單，不寫 frontmatter，改用 `<!-- 待驗證 -->` 註解

   **敘述部分（LLM 撰寫但受約束）**：
   - 概述 / 變更歷史 / 教學章節對應 可用 LLM 自然語言
   - **不得**在敘述中宣告 API 簽名或方法存在
   - 若需要程式碼範例，呼叫 `get_code_snippet` 取上游實際 snippet

   **取上游使用範例**（必做）
   ```
   mcp__codebase-memory-mcp__search_graph
     project: "<由 list_projects 依 root_path 解析>"
     name_pattern: "<API 名稱>"

   mcp__codebase-memory-mcp__get_code_snippet
     project: "<由 list_projects 依 root_path 解析>"
     qualified_name: "<完整 qualified name>"

   mcp__codebase-memory-mcp__search_code
     project: "<由 list_projects 依 root_path 解析>"
     pattern: "<API 名稱>"
   ```
   - `search_code` 找到的上游 tests/samples 檔案路徑列入 `sources`（格式：`agent-framework/dotnet/...`）

   **廢棄處理**：若事實清單標記 `deprecation_complete: true`，wiki 條目 tags 加上 `deprecated`，改用 `## ⛔ 廢棄通知` 段落結構。

4. **更新 API Changelog**
   - 讀取 [NEW]/[UPDATED] 的 raw/release-notes/ 版本
   - 更新 `agent-framework-kb/wiki/api-changelog.md`
   - 標記 breaking / non-breaking（依事實清單 kind 欄位）

5. **更新主索引**
   - 更新 `agent-framework-kb/wiki/INDEX.md`
   - 更新已修改條目列表與 last_compile 時間戳

6. **更新 SCHEMA**
   - 若有新概念類別，更新 `agent-framework-kb/wiki/SCHEMA.md`

7. **產出編譯摘要**
   - 列出本次新增/更新的 wiki 條目
   - 列出尚未涵蓋的 raw/ 素材
   - 列出 frontmatter 未填寫（待驗證）的條目
   - 建議接下來執行 `$snapshot-knowledge` 與 `$drift-check`

## 編譯規則

### 概念粒度
- 每個獨立的 C# 類別或介面 → 一個條目
- 設計模式或架構概念 → 一個條目
- 配置或工作流程 → 一個條目

### 來源追溯
- `sources` 必須列出對應的 raw/ 檔案路徑
- 若概念橫跨多個 ADR，全部列出
- brainstorming/qa-sessions/ 補充也列入
- `search_code` 找到的上游 tests/samples 檔案路徑列入

### 增量編譯
- 只處理 [NEW] 與 [UPDATED] 素材
- 首次執行為全量編譯
- 所有判斷基於當下檔案狀態，不參考對話歷史

## 注意事項

- 此指令是事實層與敘述層的**唯一交會點**：frontmatter 受事實約束，敘述自由
- LLM 不得在編譯時即興宣告 API 存在或不存在
- 若事實清單與 release notes 衝突，**以事實清單為準**
