---
name: "drift-check"
description: "Compare the verified Agent Framework wiki against the Traditional Chinese tutorial and rebuild the drift report. Use for release maintenance, removed or renamed API detection, outdated guidance review, and enhancement discovery."
---

# Drift Check — 偵測教學內容與上游 API 的偏移

比對 `agent-framework-kb/wiki/concepts/` 中的最新 API 定義與 `microsoft-agent-framework-tutorial/` 中的教學內容，產出偏移報告。

**事實層判決者**：codebase-memory-mcp 決定 🔴 Breaking（API 是否真的不存在）；敘述層由文字比對處理 🟡 Outdated 與 🟢 Enhancement。

先執行 `python3 scripts/validate_workspace.py`，再以 `list_projects` 依 `root_path` 解析實際 MCP project name。只有 MCP 或原始碼證據確認的項目才能列為 🔴 Breaking；文字差異本身最多列為候選。

## 執行步驟

1. **載入基準**
   - 讀取 `agent-framework-kb/wiki/concepts/` 中所有條目
   - 建立「最新 API 名稱 → 簽名 → 命名空間」對照表
   - 讀取 `agent-framework-kb/wiki/api-changelog.md`

2. **掃描教學內容**
   - 讀取 `microsoft-agent-framework-tutorial/` 中所有 .md 檔
   - 擷取所有 C# 程式碼區塊
   - 擷取所有行內程式碼參考
   - 擷取所有 NuGet 套件版本參考

3. **codebase-memory-mcp API 存在性查驗**（🔴 Breaking 判定）

   對 wiki/concepts/ 對照表中的每個核心 API：
   ```
   mcp__codebase-memory-mcp__query_graph
     project: "<由 list_projects 依 root_path 解析>"
     query: "MATCH (n {name: '<API 名稱>'}) RETURN n.name, n.filePath, labels(n)"
   ```
   - 圖譜查無 → 🔴 Breaking 候選
   - 進一步用 `get_code_snippet` 確認是命名空間差異還是拼字問題

   對教學 `using` 命名空間用：
   ```
   mcp__codebase-memory-mcp__query_graph
     project: "<由 list_projects 依 root_path 解析>"
     query: "MATCH (n:Class {name: '<ClassName>'}) RETURN n.namespace"
   ```
   - namespace 不符 → 🔴 Breaking

4. **codebase-memory-mcp 官方用法比對**（🟡 Outdated 輔助）

   ```
   mcp__codebase-memory-mcp__search_code
     project: "<由 list_projects 依 root_path 解析>"
     pattern: "<API 名稱>"
   ```
   - 若教學的初始化/呼叫方式與上游 tests/samples 明顯不同 → 🟡 Outdated（非最佳實踐）
   - 上游有更簡潔的新寫法 → 🟢 Enhancement

5. **比對偵測**

   ### 🔴 Breaking
   - 教學使用的類別已不存在於最新 API（文字比對 + 圖譜雙重確認）
   - 方法參數數量或型別不符
   - using 命名空間已變更或移除
   - NuGet 套件名稱改名
   - 已移除類別仍被參考

   ### 🟡 Outdated
   - 描述使用舊名稱
   - 版本號落後 2+ minor
   - 「未來製作」描述但功能已完成
   - 提及 --prerelease 但已 GA
   - 程式碼可運作但有更佳替代

   ### 🟢 Enhancement
   - wiki/concepts/ 有教學未涵蓋的新概念
   - 新的官方範例可作為素材
   - 新模型支援未提及
   - 新 ADR 被 Accepted 但教學未反映

6. **產出報告**

   **每次執行均為全量比對，完整覆寫 `agent-framework-kb/wiki/drift-report.md`**：

   ```markdown
   ---
   generated: YYYY-MM-DD
   indexed_commit: <agent-framework HEAD hash>
   baseline: wiki/concepts/ (N 條目, vX.Y.Z) vs tutorial/ (M 檔案)
   ---

   # 偏移報告

   ## 摘要
   | 等級 | 數量 | 說明 |
   |------|------|------|
   | 🔴 Breaking | X | 教學範例可能無法編譯 |
   | 🟡 Outdated | Y | 內容過時但可運作 |
   | 🟢 Enhancement | Z | 可選補充 |

   ## 🔴 Breaking
   ### B-NNN: <問題描述>
   - **影響檔案**：`XX-chapter-name.md` L行號
   - **現況**：<教學中的寫法>
   - **正確**：<最新 API 的寫法>
   - **圖譜證據**：<query 結果 / namespace>
   - **來源 wiki**：<wiki/concepts/xxx.md>
   - **建議修正**：<具體修改建議>
   ```

7. **摘要輸出**
   - 終端顯示簡短摘要
   - 提示完整報告位置

## 注意事項

- 每次執行均基於當下檔案，不參考對話歷史或舊報告
- drift-check 基於文字比對 + 圖譜查驗，不等於 `dotnet build`
- AG-UI Protocol 的 `thread_id` 是協定層級欄位，不算偏移
- 教學中標註「⚠️ 提案中的 API」的程式碼不標 🔴
- codebase-memory-mcp 索引對象是 `agent-framework/`；tutorial 與 kb 未索引
