---
name: "release-summary"
description: "Create or refresh one root-level vX.Y.Z-update-summary.md per verified Agent Framework release and update the root README version table. Use near the end of version maintenance, after the final drift-check and before lint, including consecutive multi-version updates."
---

# Release Summary — 產生版本維護摘要

為每個已完成維護的 .NET release 建立獨立的
`v<version>-update-summary.md`，並在根目錄 `README.md` 的版本追蹤表加入連結。
摘要是導覽文件，不是狀態來源。

## 使用方式

```text
$release-summary <version> [<version> ...]
```

範例：

```text
$release-summary 1.15.0
$release-summary 1.14.0 1.15.0
```

連續同步多個版本時，仍須為每個版本分別產生一份摘要，不得合併成單一檔案或 README 列。

## 前置條件

1. 執行 `git -C agent-framework status --short`；若非 clean，停止並回報。
2. 確認每個版本都有：
   - `agent-framework-kb/raw/release-notes/dotnet-<version>.md`
   - `agent-framework-kb/raw/facts/dotnet-<version>-verified-changes.json`
3. 確認下列最終狀態文件已反映本輪維護：
   - `agent-framework-kb/UPSTREAM-REF.md`
   - `agent-framework-kb/wiki/INDEX.md`
   - `agent-framework-kb/wiki/drift-report.md`
4. 確認教學修改後的第二次 `$drift-check` 已完成。若仍有未處理的 Breaking 或 Outdated，先回到 `$update-tutorial`。

## 事實與敘述來源

| 內容 | 唯一依據 |
|------|----------|
| API 名稱、簽名、namespace、breaking 判定 | `raw/facts/dotnet-<version>-verified-changes.json` |
| 發佈日期、PR、變更意圖 | `raw/release-notes/dotnet-<version>.md` |
| 上游 tag、commit、索引規模 | `UPSTREAM-REF.md` |
| Wiki 編譯內容 | `wiki/INDEX.md` |
| 教學影響與最終偏移 | `wiki/drift-report.md` |
| 實際修改檔案 | 當前 git diff 與上述文件 |

不得從既有摘要推導新事實，也不得把摘要寫成另一份目前狀態來源。結構性宣告若不在 verified facts 中，省略或標示尚未驗證。

## 執行步驟

### 1. 蒐集每版資料

逐版讀取 release notes 與 verified facts。再讀一次三份狀態文件與當前 diff，分開記錄：

- 該版本本身的主要變更
- 直接影響教學的 Breaking
- 教學未示範但升級者需注意的 Breaking
- 已納入的 Enhancement
- 本輪實際修改的 wiki 與教學檔案
- 最終驗證結果

不得把連續同步中另一版本的變更錯列到本版。

### 2. 建立或更新獨立摘要

目標路徑固定為工作區根：

```text
v<version>-update-summary.md
```

若檔案已存在，先讀取並作增量更新，不得無條件覆寫人工補充。摘要至少包含：

1. 版本資訊：發佈日期、tag、commit、升級性質
2. 主要變更：只寫 verified facts 支援的結構事實
3. 對本教學的影響：引用最終 drift report 與實際修改
4. 知識庫同步記錄：只宣告實際完成的 pipeline 階段
5. 升級檢查清單

文件開頭連結前一版本摘要；若下一版本摘要已存在，也加入下一版本連結。內文必須連結該版 release notes、verified facts，以及三份狀態來源。

若 `$snapshot-knowledge` 只完成 Codex preflight、尚未由 Claude Code plugin 重建 UA graph，明確標示未完成，不得寫成已重建。

### 3. 更新根 README

在 `README.md` 的「版本追蹤」表中為每個版本建立獨立列：

```markdown
| v<version> | <發佈日期> | <教學更新日期> | [摘要](./v<version>-update-summary.md)：<一句話摘要> |
```

- 依 semantic version 排序。
- 不把多個已具 verified facts 的版本合併成一列。
- 一句話摘要不得取代完整檔案。
- README 的基準版本仍以 `UPSTREAM-REF.md` 為準。

### 4. 驗證

執行：

```bash
python3 scripts/validate_workspace.py --require-upstream --check-upstream-clean
```

確認：

- 每個 `raw/facts/dotnet-<version>-verified-changes.json` 都有對應的根目錄摘要。
- README 對每份摘要都有明確連結。
- 所有新連結有效。
- `git diff --check` 通過。
- `git -C agent-framework status --short` 在結束時仍為 clean。

完成後執行 `$lint` 作為版本維護的最終驗收。

## 輸出摘要

回報：

- 建立或更新的 `v<version>-update-summary.md`
- README 新增或更新的版本列
- validator 結果
- 尚未完成或無法由來源證明的項目
