# Microsoft Agent Framework 繁體中文教學

> 基準版本：**Microsoft Agent Framework v1.15.0**（2026-07-22；唯一狀態來源見 [`agent-framework-kb/UPSTREAM-REF.md`](./agent-framework-kb/UPSTREAM-REF.md)）
> 最後同步：2026-07-05（以 [`agent-framework-kb/UPSTREAM-REF.md`](./agent-framework-kb/UPSTREAM-REF.md) 為準）

以繁體中文撰寫的 Microsoft Agent Framework 完整教學，涵蓋 30 章 + 9 附錄，從環境準備到 A2A/AG-UI/MCP 協定整合、Durable Agents、CodeAct、Magentic 編排等進階主題。內建 LLM Wiki 知識庫，透過自訂指令自動追蹤上游 API 變更並偵測教學內容偏移。

---

## 目錄結構

```text
agent-framework-tutorial/
├── microsoft-agent-framework-tutorial/   ← 教學本體（30 章 + 9 附錄）
├── agent-framework-kb/                   ← LLM Wiki 知識庫
│   ├── raw/                              ← 上游素材（ADR、release notes、samples）
│   ├── wiki/concepts/                    ← 41 個結構化概念條目
│   ├── wiki/.understand-anything/        ← Understand-Anything 知識圖譜
│   └── brainstorming/                    ← 問答記錄
├── .claude/commands/                     ← 12 個 slash commands（Pipeline A/B/D）
├── .agents/skills/                       ← 13 個 Codex repo skills
├── .codex/config.toml                    ← Codex 專案 MCP 設定
├── AGENTS.md                             ← Codex 工作區主導指引
├── CLAUDE.md                             ← Claude Code 相容指引
├── SETUP.md                              ← 新機器環境設定指南
└── .mcp.json                             ← MCP server 設定（codebase-memory-mcp）
```

> `agent-framework/`（Microsoft 官方 SDK git clone）不含在本 repo 中，各台機器請自行 clone：
> `git clone https://github.com/microsoft/agent-framework.git`

---

## 教學章節

| 章節 | 主題 |
|------|------|
| 第 01–04 章 | 框架概念、核心架構、環境準備、第一個代理 |
| 第 05–06 章 | 工具基礎（Tools）、Middleware 與 Context |
| 第 07–10 章 | 範例實作（旅遊代理、RAG、規劃、多代理） |
| 第 11–13 章 | ASP.NET Core 整合、測試策略、Docker 部署 |
| 第 14–17 章 | Context Providers、結構化輸出、HITL、LLM 提供者 |
| 第 18–21 章 | Workflows（基礎 + 進階）、Durable Agents |
| 第 22–25 章 | OpenTelemetry、A2A Protocol、AG-UI Protocol、MCP 整合 |
| 第 26–29 章 | 長時間運算、Feature Collections、Agent Evaluation、Agent Skills |
| 第 30 章 | Magentic Orchestration（管理員驅動多代理編排） |
| 附錄 A–I | NuGet 套件、遷移指南、資源參考、ADR 提案、官方範例導覽 |

---

## LLM Wiki 知識庫

`agent-framework-kb/` 是基於 [Karpathy LLM Wiki](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) 概念設計的知識管理系統。Codex 以 repo skills 維護；既有 Claude slash commands 暫時保留相容性：

```
$sync-upstream        ← 抓取最新 ADR、release notes、SDK tag
$extract-facts        ← 從 release notes 抽取 API 事實，以 codebase-memory-mcp 逐筆驗證
$compile              ← 編譯 wiki/concepts/ 條目（frontmatter 受事實清單約束）
$drift-check          ← 比對 wiki 與教學內容，產出 🔴/🟡/🟢 偏移報告
$update-tutorial      ← 修正已驗證偏移
$release-summary      ← 每個 verified release 產生獨立版本摘要並更新根 README
$lint                 ← deterministic validator + MCP 抽樣
$snapshot-knowledge   ← UA 混合流程：Codex 前後驗證、Claude plugin 生成
```

---

## 知識圖譜 Dashboard（Understand-Anything）

本 repo 內含預先產出的 UA 知識圖譜：

```
agent-framework-kb/wiki/.understand-anything/knowledge-graph.json
```

目前快照包含 **121 nodes、310 edges、20 個分類層**，其中 45 個 article nodes 涵蓋 42 個核心概念與索引文件。實際統計以 graph JSON 與 `meta.json` 為準。

### 啟動 Dashboard

```bash
# 安裝依賴（首次）
UA_ROOT=~/.claude/plugins/cache/understand-anything/understand-anything/<installed-version>
cd "$UA_ROOT/packages/core"
npx tsc

cd "$UA_ROOT/packages/dashboard"
pnpm install

# 啟動（GRAPH_DIR 指向本 repo 的 wiki 目錄）
GRAPH_DIR=/path/to/agent-framework-kb/wiki npx vite --host 127.0.0.1
```

Dashboard 啟動後，開啟終端機輸出的 `http://127.0.0.1:5173/?token=<TOKEN>` 即可互動探索知識圖譜。

> 知識圖譜為靜態 JSON，**不需要 Claude** 即可使用 Dashboard，Codex 等其他 AI 工具可直接讀取 `knowledge-graph.json`。

---

## 前置需求

| 用途 | 需求 |
|------|------|
| 閱讀教學 | 無（純 Markdown） |
| 執行範例程式碼 | .NET 8.0+ SDK、LLM API Key（OpenAI / Azure OpenAI / Anthropic） |
| 知識庫維護 | Codex + codebase-memory-mcp + `agent-framework/` clone |
| UA 圖譜重建 | Claude Code + Understand-Anything（暫時的混合步驟） |
| Dashboard | Node.js 18+、pnpm |

---

## 版本追蹤

| 框架版本 | 發佈日期 | 教學更新日期 | 摘要 |
|---------|----------|------------|------|
| v1.0.0 GA | 2026-04-02 | 2026-04-12 | 教學初版（28 章 + 4 附錄） |
| v1.1.0 | 2026-04-10 | 2026-04-16 | [摘要](./v1.1.0-update-summary.md)：Skill as class、6 章補強 |
| v1.2.0–v1.3.0 | 2026-04-21/24 | 2026-04-24 | A2A SDK 1.0、Foundry Toolbox、SSE 重連 |
| v1.4.0 | 2026-05-05 | 2026-05-06 | [摘要](./v1.4.0-update-summary.md)：CodeAct GA、FIDES |
| v1.5.0 | 2026-05-08 | 2026-05-08 | [摘要](./v1.5.0-update-summary.md)：Magentic Orchestration（Experimental）、ch29 新增 |
| v1.6.1 | 2026-05-14 | 2026-05-27 | [摘要](./v1.6.1-update-summary.md)：OTel Breaking、Shell Tool、MessageInjector、wiki 校正 |
| v1.7.0 | 2026-05-26 | 2026-06-06 | [摘要](./v1.7.0-update-summary.md)：AgentSkill 改非同步消費端（#6030，撰寫端不變）、MCP 長時間任務、Magentic 範例 |
| v1.8.0 | 2026-05-28 | 2026-06-06 | [摘要](./v1.8.0-update-summary.md)：高階編排 Builder（Sequential/Concurrent）、MCP-based skills（第 4 來源）、AgentFileSkillsSource depth-based（#6109）、ClaimsIdentity session 隔離 |
| v1.9.0 | 2026-06-03 | 2026-06-06 | [摘要](./v1.9.0-update-summary.md)：**Orchestrations 移除 [Experimental]（Magentic 轉正式 #6164）**、Workflows.Declarative 轉 stable（#6254）、Workflow Outputs Overhaul。經 codebase-memory-mcp 驗證 breaking 皆不影響教學（E-002 false positive 關閉） |
| v1.10.0 | 2026-06-11 | 2026-06-14 | [摘要](./v1.10.0-update-summary.md)：維護 + 增強釋出。**ToolApprovalAgent 自動核可規則（#6335）**、HarnessAgent token compaction 改 opt-in（#6409）、ChatOptions Reasoning 合併（#5463）、MEAI 10.6.0 / MCP 1.2.0。官方標 Breaking 三項經驗證皆不影響教學 |
| v1.11.0 | 2026-06-24 | 2026-06-25 | [摘要](./v1.11.0-update-summary.md)：維護 + 增強釋出。**新增 `Microsoft.Agents.AI.LocalCodeAct`（本機 Python 執行 #6105）**、`LoopAgent` Harness 迴圈（#6384）、MCP per-run 可刷新驗證標頭（#6624）、A2A 預設 `NoopAgentSessionStore`（#6635）。官方標 Breaking 三項（FileAccessProvider 核可、FileAccess 對齊、SessionConfig.Streaming）集中於 Harness 子系統，經驗證皆不影響教學 |
| v1.11.1 | 2026-06-26 | 2026-06-28 | [摘要](./v1.11.1-update-summary.md)：patch 釋出，**含影響教學的 Agent Skills Breaking**。`AgentSkillsProvider` 技能工具改為**預設需人工核可**（移除 `ScriptApproval`/`UseScriptApproval` #6729）、移除 `{resource_instructions}`/`{script_instructions}` 佔位符（#6706）——自 v1.4.0 以來首個影響教學程式碼的破壞性變更，ch29 已同步更新。另含 `DeclarativeWorkflowJsonOptions`（#6745）、archive 型 MCP 技能（#6631）、`CreateMcpTool projectConnectionId`（#6703） |
| v1.12.0 | 2026-07-02 | 2026-07-05 | [摘要](./v1.12.0-update-summary.md)：`DisableCaching` 移除，技能快取抽離為 `CachingAgentSkillsSource`，ch29 已同步 |
| v1.13.0 | 2026-07-03 | 2026-07-05 | [摘要](./v1.13.0-update-summary.md)：Skills API 穩定化、細緻核可選項、`AgentSkillsSourceContext`；完整 Pipeline A 已通過 |
| v1.14.0 | 2026-07-21 | 2026-07-23 | [摘要](./v1.14.0-update-summary.md)：AG-UI package/API migration、message injection async、tool approval context、approval bypass 預設語意；4 組教學 Breaking 已修正 |
| v1.15.0 | 2026-07-22 | 2026-07-23 | [摘要](./v1.15.0-update-summary.md)：OpenAI Responses hosting helpers、`HostedWorkflowState`、`AgentSessionStore.DeleteSessionAsync`；對既有教學無新增 Breaking |

---

## 新機器設定

Clone 本 repo 並完成環境設定的步驟，請見 **[SETUP.md](./SETUP.md)**。

---

## 參考資料

- [microsoft/agent-framework](https://github.com/microsoft/agent-framework) — SDK 原始碼
- [microsoft/Agent-Framework-Samples](https://github.com/microsoft/Agent-Framework-Samples) — 官方範例
- [Karpathy LLM Wiki Pattern](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) — 知識庫設計參考

---

## 授權

本教學內容為個人學習與分享用途，非官方資源。Microsoft Agent Framework 本身採用 MIT License。
