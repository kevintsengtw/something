# Microsoft Agent Framework 繁中教學工作區

本工作區用來建立與維護 Microsoft Agent Framework 的繁體中文教學。所有說明與報告使用繁體中文；API、型別、方法、套件與命令保留英文原名。

## 目錄角色與寫入邊界

| 路徑 | 角色 | 寫入規則 |
| --- | --- | --- |
| `agent-framework/` | Microsoft 官方 SDK 的本機上游 clone | 唯讀基準；除受控的 `git fetch`／`git checkout <tag>` 外不可修改 |
| `agent-framework-kb/raw/` | ADR、release notes、samples、Learn 等來源鏡像 | 只由 `$sync-upstream` 更新，不改寫來源內容 |
| `agent-framework-kb/raw/facts/` | 經原始碼驗證的版本事實 | 只由 `$extract-facts` 建立或更新 |
| `agent-framework-kb/wiki/` | 結構化知識庫與 drift report | 由 `$compile`、`$drift-check`、`$snapshot-knowledge` 維護 |
| `microsoft-agent-framework-tutorial/` | 正式教學文件 | 只在明確要求或 `$update-tutorial`／`$regenerate-toc` 中修改 |
| `outputs/` | 新章節與附錄草稿 | 草稿只能先寫入這裡，不可直接加入正式教學 |

開始與結束涉及上游的工作時，都執行 `git -C agent-framework status --short`。若上游有非預期變更，停止並回報；不得清除或覆蓋既有變更。

## 事實層與敘述層

- `codebase-memory-mcp` 是 API 名稱、簽名、namespace、繼承與使用位置的結構事實來源。
- release notes、ADR 與 Microsoft Learn 是變更意圖與敘述來源，不能單獨證明 API 存在。
- 任何結構性宣告寫入 facts、wiki 或教學前，必須以 codebase-memory-mcp 或上游原始碼驗證。
- 外部套件型別可能不在 `agent-framework` 圖譜中；遇到 `Microsoft.Extensions.*`、`Azure.*` 等型別時，搜尋上游使用端並清楚標示外部來源。

使用 MCP 前先呼叫 `list_projects`，以 `root_path` 結尾為 `/agent-framework` 的項目取得實際 project name。不要硬編碼 `agent-framework`，因為 project name 會依本機絕對路徑產生。使用 `search_graph` 找到完整 `qualified_name` 後，再呼叫 `get_code_snippet` 或 `trace_path`。

## 目前狀態的唯一來源

- 上游 tag、commit、索引規模：`agent-framework-kb/UPSTREAM-REF.md`
- Wiki 最後同步與編譯：`agent-framework-kb/wiki/INDEX.md`
- 最近偏移判定：`agent-framework-kb/wiki/drift-report.md`

README、SETUP 與版本摘要不得自行成為另一份狀態來源；更新時應引用上述文件。

## Codex skills

重複工作使用 `.agents/skills/` 中的 repo skills：

- 版本維護：`$sync-upstream` → `$extract-facts` → `$compile` → `$snapshot-knowledge` → `$drift-check` → `$update-tutorial` → `$drift-check` → `$release-summary` → `$lint`
- 查詢與記錄：`$wiki-query`、`$save-qa`
- 教學建立：`$draft-chapter`、`$draft-appendix`、`$regenerate-toc`

`$snapshot-knowledge` 目前是混合流程：Codex 負責前置與產物驗證，Understand-Anything 圖譜重建仍由 Claude Code plugin 執行。不可假裝已在 Codex 中完成 UA 生成。

## 驗證

- 一般文件或知識庫修改後：`python3 scripts/validate_workspace.py`
- 要求完整本機基線時：`python3 scripts/validate_workspace.py --require-upstream --check-upstream-clean`
- 修改 Codex artifacts 後：執行 migrate-to-codex validator 與每個 skill 的 `quick_validate.py`
- 修改教學 API 或程式碼範例後：除了 deterministic validator，還要以 MCP 抽樣核對受影響 API。

不要把 `/lint` 或 `/drift-check` 的文字判斷宣稱為編譯保證；教學內多數範例不是獨立可建置專案。

## 重要禁止事項

- 不修改或清理 `agent-framework/` 的原始碼工作樹。
- 不在未驗證的情況下宣告 API 簽名或 namespace。
- 不把新章節或附錄草稿直接寫入正式教學目錄。
- 不把 `agent-framework-kb/wiki/.understand-anything/intermediate/` 或 diff overlay 納入版本控制。
- 不依賴固定的 Claude plugin cache 版本路徑作為可攜式設定。
