# Agent Framework 知識庫（LLM Wiki）

Microsoft Agent Framework 繁體中文教學的知識管理系統。基於 [Karpathy LLM Wiki](https://karpathy.ai/) 概念，透過 Codex repo skills 追蹤上游 API 變更、偵測教學內容偏移，並整合 **codebase-memory-mcp** 進行 API 結構化查驗。**Understand-Anything** 暫時以 Claude Code plugin 產生視覺化快照。

---

## 整體專案結構

本知識庫是整個教學專案的子目錄之一。三個目錄並列在工作區根下，各自扮演不同角色：

```
agent-framework-tutorial/                        # 工作區根（指令入口點）
├── AGENTS.md                                    # Codex master orchestration
├── .agents/skills/                              # 12 個 Codex repo skills
├── CLAUDE.md / .claude/commands/                # Claude Code 相容層
│
├── agent-framework/                             # 上游原始碼（Microsoft Agent Framework SDK）
│   └── （由 codebase-memory-mcp 索引）
│
├── agent-framework-kb/                          # 本知識庫（LLM Wiki）← 你在這裡
│   ├── raw/                                     # 從 agent-framework 抓取的素材鏡像
│   ├── wiki/                                    # LLM 編譯的結構化知識
│   └── ...                                      # 詳見下方目錄結構
│
└── microsoft-agent-framework-tutorial/          # 繁體中文教學文件（30 章 + 9 附錄）
```

**三者關係**：

| 目錄 | 角色 | 與本 kb 的關係 |
|------|------|---------------|
| `agent-framework/` | 上游原始碼（唯讀） | codebase-memory-mcp 索引對象；`$sync-upstream` 從其 GitHub 抓取素材 |
| `agent-framework-kb/` | 知識管理中樞 | 本目錄 |
| `microsoft-agent-framework-tutorial/` | 教學產出 | `$drift-check` 比對對象；`$update-tutorial` 修正，`$draft-*` 只先寫 outputs |

---

## 知識庫目錄結構

```
agent-framework-kb/
├── AGENTS.md                       # Codex kb 補充指引
├── CLAUDE.md                       # Claude Code 相容指引
├── README.md                       # 本檔案（人工閱讀）
├── QuickStart.md                   # 快速操作指南
├── UPSTREAM-REF.md                 # 上游 commit 對齊記錄（跨機同步用）
├── WORKFLOW-DESIGN-v2.md           # 工作流設計文件（v2，2026-05-26）
├── PLAYBOOK-version-update.md      # 版本更新操作手冊
├── MIGRATION-LOG.md                # 三次決策歷程記錄
│
├── raw/                            # 上游原始素材（唯讀）
│   ├── adrs/                       #   ADR 決策記錄（26 份 + 索引）
│   ├── release-notes/              #   版本發佈說明（目前同步至 .NET v1.13.0）
│   ├── devblogs/                   #   官方部落格摘要
│   ├── learn/                      #   Microsoft Learn 文件摘要
│   ├── samples/                    #   官方範例庫摘要
│   └── facts/                      #   每版本事實清單 JSON（由 $extract-facts 產出）
│
├── wiki/                           # LLM 編譯產出
│   ├── concepts/                   #   概念條目（41 個，基準 v1.13.0）
│   ├── INDEX.md                    #   分類索引 + 章節反查表
│   ├── SCHEMA.md                   #   編譯規則定義
│   ├── api-changelog.md            #   API 變更時間線
│   └── drift-report.md             #   最近一次偏移檢查報告
│
│   └── .understand-anything/       #   UA 知識圖譜產出（由 $snapshot-knowledge 協調）
│       └── knowledge-graph.json    #   commit；其餘 intermediate/ gitignore
│
└── brainstorming/                  # 品質稽核、章節規劃記錄
    └── qa-sessions/                #   wiki-query 問答記錄
```

**注意**：本目錄**不再有 `.claude/` 子目錄**——slash commands 入口點已上移到工作區根 `../.claude/commands/`。

---

## 前置需求

- macOS（Windows 已退場，見 [`./WORKFLOW-DESIGN-v2.md`](./WORKFLOW-DESIGN-v2.md) §0）
- Codex CLI、IDE extension 或 Codex app
- [codebase-memory-mcp](https://github.com/DeusData/codebase-memory-mcp)：`npm install -g codebase-memory-mcp`
- UA 圖譜重建才需要 Claude Code + [Understand-Anything](https://github.com/Lum1104/Understand-Anything)

完整安裝步驟見 [`./QuickStart.md`](./QuickStart.md)。

---

## 工具角色分工

兩工具職責**嚴格不交叉**：

| 層別 | 工具 | 職責 | 性質 |
|------|------|------|------|
| **事實層** | **codebase-memory-mcp** | 原始碼結構性事實的 ground truth | Deterministic（tree-sitter parser） |
| **敘述層** | **Understand-Anything + LLM** | 概念敘述、關係抽取、視覺化、Onboarding | LLM-based（語意理解） |

### codebase-memory-mcp 整合

[codebase-memory-mcp](https://github.com/DeusData/codebase-memory-mcp)（DeusData）是以 C 語言實作的高效能程式碼知識圖譜 MCP 伺服器，透過 tree-sitter AST 解析將原始碼建構為持久化知識圖譜：

- **支援語言**：155 種，C# 支援度 Good 等級（75–89%）
- **索引速度**：平均 repo 僅需數秒，RAM-first + LZ4 壓縮
- **MCP 工具**：14 個，涵蓋索引、查詢、呼叫鏈追蹤、Cypher 查詢等

在本知識庫中，codebase-memory-mcp 索引的是 **上游 `../agent-framework/` 原始碼**，提供「API 名稱是否真的存在、命名空間為何、廢棄是否徹底」等結構化事實，補強純文字比對的不確定性。

**MCP 工具使用對照**：

| 工具 | 用途 | 在本 kb 的使用步驟 |
|------|------|-------------------|
| `search_graph` | 依名稱搜尋 symbol 節點（namespace、filePath） | sync-upstream、extract-facts、compile、update-tutorial、lint |
| `get_code_snippet` | 取得指定 symbol 的完整程式碼片段 | extract-facts、compile |
| `trace_path` | 追蹤呼叫鏈（inbound = 誰呼叫我；outbound = 我呼叫誰） | extract-facts、compile、update-tutorial |
| `query_graph` | Cypher 語法圖查詢（讀取專用） | drift-check |
| `search_code` | 在原始碼中以 pattern 搜尋實際使用範例 | compile、drift-check、draft-chapter |
| `index_repository` | 首次建立索引 | 一次性，跨機切換時重跑 |
| `list_projects` | 查看已索引的 project | 維護用 |

### Understand-Anything 整合

[Understand-Anything](https://github.com/Lum1104/Understand-Anything)（Lum1104）是 Claude Code Plugin，提供：

- `/understand-knowledge` —— 對 `wiki/` 跑 Karpathy LLM Wiki pattern 分析，產出視覺化知識圖譜
- `/understand-chat`、`/understand-explain`、`/understand-diff`、`/understand-onboard`、`/understand-domain` —— 對 wiki 與 tutorial 的互動探索

**用途定位**：UA 是敘述層工具——產出由 LLM 抽取，不是 ground truth；用於發現概念間的隱性關係、提供互動 dashboard、繁中導覽。

---

## 工作流程概觀

### Pipeline A：版本更新（自動化）

```
$sync-upstream → $extract-facts <version> → $compile → $snapshot-knowledge
                  → $drift-check → $update-tutorial breaking → $drift-check → $lint
```

完整版見 [`./PLAYBOOK-version-update.md`](./PLAYBOOK-version-update.md)。

### Pipeline B：互動探索

```
/wiki-query <關鍵字>                 ← 查 wiki
/understand-chat <自然語言問題>        ← UA 對話
/save-qa                            ← 保存問答到 brainstorming/
```

### Pipeline C：Onboarding

```
/understand-onboard                  ← UA 新人導覽
```

### Pipeline D：教學文件建立

```
$draft-chapter <wiki-concept>        ← 草擬新章節到 outputs/
$draft-appendix <topic>              ← 草擬新附錄到 outputs/
/regenerate-toc                      ← 重建 README TOC
```

---

## 整合 codebase-memory-mcp 前後的差異

這裡比較的是**本知識庫**在加入程式碼圖譜工具前後的工作流程差異。

### 整合前（純文字驅動）

```
raw/（文件素材）→ $compile（LLM 理解） → wiki/（結構化知識） → $drift-check（文字比對） → 教學
```

所有知識均來自 ADR、Release Notes 等**文件**。如果文件寫錯或遺漏 API 細節，wiki 跟著錯。只靠文字比對無法驗證 API 是否真的存在於原始碼。

### 整合後（結構事實 + 文字雙軌）

```
raw/（文件素材）+ raw/facts/（已驗證事實）→ $compile
                    ├─ LLM 寫敘述
                    └─ search_graph / trace_path 查驗結構 → wiki/（事實 + 敘述）

wiki/ → $drift-check
          ├─ Grep 比對教學文字
          └─ query_graph 驗證 API 存在性 → drift-report（更可靠）
```

| 面向 | 整合前 | 整合後 |
|------|--------|--------|
| API 簽名來源 | ADR / Release Notes 文字 | 原始碼圖譜（事實） |
| 廢棄確認方式 | 相信 ADR 說廢棄了 | `trace_path` 確認上游無呼叫者 |
| 教學 API 存在性 | 靠 Grep 找文字 | `query_graph` 查圖譜節點 |
| 命名空間正確性 | 靠人工核對 | `query_graph` 直接讀 `n.namespace` |
| 替換方向確認 | 靠 drift-report 描述 | `search_graph` + `trace_path` 確認新名稱 |

**核心效益**：從「相信文件說什麼」提升為「從原始碼事實驗證」，減少因文件不準確導致的誤報或漏報。

---

## 設計文件導覽

| 文件 | 用途 |
|------|------|
| [`../AGENTS.md`](../AGENTS.md) | Codex 工作區根主導文件 |
| [`./AGENTS.md`](./AGENTS.md) | Codex kb 補充指引（條目格式、編譯規則） |
| [`../CLAUDE.md`](../CLAUDE.md)／[`./CLAUDE.md`](./CLAUDE.md) | Claude Code 相容指引 |
| [`./WORKFLOW-DESIGN-v2.md`](./WORKFLOW-DESIGN-v2.md) | 工作流設計（三層架構、四條 pipeline、檔案衝擊清單） |
| [`./MIGRATION-LOG.md`](./MIGRATION-LOG.md) | 三次決策歷程（入口點上移、Pipeline D、工具選擇） |
| [`./PLAYBOOK-version-update.md`](./PLAYBOOK-version-update.md) | 版本更新操作步驟 + 歷次執行記錄 |
| [`./QuickStart.md`](./QuickStart.md) | 快速操作指南 |
| [`./UPSTREAM-REF.md`](./UPSTREAM-REF.md) | 上游 commit 對齊記錄 |
| [`./raw/facts/codebase-memory-mcp-validation.md`](./raw/facts/codebase-memory-mcp-validation.md) | macOS 可用性驗證範本（首次必跑） |

---

## 授權

本知識庫內容為個人學習與分享用途。Microsoft Agent Framework 本身採用 MIT License。
