# Agent Framework 知識庫補充規範

本檔補充工作區根 `AGENTS.md`，適用於 `agent-framework-kb/`。

## 寫入規則

- `raw/` 是來源鏡像，只能由 `$sync-upstream` 新增或同步；不要改寫已抓取內容。
- `raw/facts/` 只保存逐筆驗證結果。每個結構性事實都要含可追溯的 MCP 或原始碼 evidence。
- `wiki/concepts/` 由 `$compile` 維護；所有內容使用繁體中文，API 名稱維持英文。
- `wiki/drift-report.md` 由 `$drift-check` 完整重建，不在其他工作中順手修改。
- `brainstorming/qa-sessions/` 是探索性資料；只有明確使用 `$save-qa` 時才新增。

## Concept frontmatter

每個 `wiki/concepts/*.md` 必須包含：

`title`、`api_name`、`namespace`、`since`、`current_version`、`updated`、`tags`、`tutorial_chapters`、`sources`。

`api_name`、`namespace`、`since`、`current_version` 必須來自 `raw/facts/*.json` 或當次 codebase-memory-mcp 驗證。無法驗證時保留 `<!-- 待驗證 -->`，不可推測。

標準段落為：`概述`、`目前 API 簽名`、`變更歷史`、`教學章節對應`、`相關概念`。deprecated、devops、migration、testing-pattern 類條目可使用相符的替代段落。

## 參照與一致性

- `[[concept-name]]` 必須對應存在的 `wiki/concepts/concept-name.md`。
- `sources` 中的 `raw/` 路徑相對於本目錄，且必須存在。
- `tutorial_chapters` 必須能對應正式教學章節或附錄。
- UA 正式產物固定在 `wiki/.understand-anything/knowledge-graph.json` 與 `meta.json`。
- 修改後執行 `python3 ../scripts/validate_workspace.py`。
