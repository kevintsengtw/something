---
updated: 2026-07-05
total_concepts: 41
last_compile: 2026-07-05 — dotnet-1.12.0 + 1.13.0 連續同步：更新 agent-skills（🔴 v1.12.0 快取抽離為 CachingAgentSkillsSource decorator、移除 DisableCaching #6768；🟢 v1.13.0 技能核可選項 DisableLoadSkillApproval/DisableReadSkillResourceApproval/DisableRunSkillScriptApproval + AgentSkillsProvider.ReadOnlyToolsAutoApprovalRule/AllToolsAutoApprovalRule #6843、AgentSkillsSource.GetSkillsAsync 新增 AgentSkillsSourceContext + source IDisposable + 內建 source 改 public #6797/#6827/#6838、Skills API 移除 [Experimental] #6861）、nuget-packages（current → 1.13.0，補 1.11.1/1.12.0/1.13.0 列）；api-changelog 新增 v1.12.0 + v1.13.0 段落
last_sync: 2026-07-05 — sync-upstream：新增 raw/release-notes/dotnet-1.12.0.md + dotnet-1.13.0.md；重新索引 agent-framework@7ca73c064（dotnet-1.13.0 tag）59,042 nodes / 257,614 edges；codebase-memory-mcp 驗證 AgentSkillsProviderOptions（DisableCaching 已移除、新增三個 Disable*Approval）、CachingAgentSkillsSource（Skills/Decorators）、AgentSkillsSource（: IDisposable、GetSkillsAsync(AgentSkillsSourceContext)）、AgentSkillsSourceContext、AgentSkillsProvider.ReadOnly/AllToolsAutoApprovalRule、BackgroundTaskCompletionLoopEvaluator（Harness.Loop）、OptionsMapping（無公開節點 = hosting 內部）✓
---

# Wiki 概念索引

> 自動產生自 `wiki/concepts/` 目錄。依分類排列，每個條目標示 API 名稱與對應教學章節。

## 核心概念（Core）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[ai-agent]] | `AIAgent` | ch01, ch02, ch04, ch07–ch10 |
| [[agent-session]] | `AgentSession` | ch02, ch04, ch14, ch20, ch21 |
| [[agent-response]] | `AgentResponse` | ch04, ch15 |
| [[run-async]] | `AIAgent.RunAsync` / `RunStreamingAsync` | ch04 |
| [[chat-client]] | `IChatClient` | ch02, ch03, ch04, ch17 |
| [[tools-ai-function]] | `AIFunctionFactory` | ch02, ch05, ch07–ch10 |
| [[middleware-pipeline]] | `AgentMiddlewareContext` / `AgentMiddlewareDelegate` | ch06, ch11, ch12 |
| [[context-providers]] | `AIContextProvider` | ch06, ch14 |

## LLM 請求設定（LLM Options）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[chat-options]] | `ChatOptions` (Microsoft.Extensions.AI) | ch03, ch04, ch06, ch17 |

## 輸出與結構化（Output）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[structured-output]] | `ChatResponseFormat.ForJsonSchema<T>` | ch15 |

## 工作流程（Workflow）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[workflows]] | `WorkflowBuilder` / `Executor` | ch18, ch19 |
| [[orchestration-builders]] | `SequentialWorkflowBuilder` / `ConcurrentWorkflowBuilder` / `GroupChatWorkflowBuilder` | ch18, ch19, ch30 |
| [[declarative-workflow]] | `DeclarativeWorkflow` | ch19 |
| [[durable-agents]] | `ConfigureDurableAgents` / `DurableTaskScheduler` | ch20, ch21 |
| [[long-running-operations]] | `IAsyncChatClient` / `AsyncRunResult` / `HarnessAgent` | ch26 |
| [[magentic-orchestration]] | `MagenticWorkflowBuilder`（v1.9.0 轉正式） | ch30 |

## 安全與人工介入（Safety）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[human-in-the-loop]] | `ApprovalRequiredAIFunction` / `ToolApprovalAgent` | ch16, ch19, ch21 |

## 協定與互通（Protocol & Interop）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[ag-ui-protocol]] | `AGUIAgent` / `MapAGUI` | ch11, ch24 |
| [[a2a-protocol]] | `A2AServerServiceCollectionExtensions` / `A2AEndpointRouteBuilderExtensions` / `AgentCard` | ch23 |
| [[mcp-integration]] | `McpServerTool` / `MapMcpServer` | ch25 |

## 進階執行（Advanced Execution）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[agent-run-context]] | `AgentRunContext` / `AIAgent.CurrentRunContext` | ch06, ch14 |
| [[codeact-integration]] | `HyperlightCodeActProvider` / `execute_code` | — (v1.4.0 GA) |

## 安全（Security）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[prompt-injection-defense]] | `LabelTrackingFunctionMiddleware` / `PolicyEnforcementFunctionMiddleware` / `ContentVariableStore` | — (Proposed) |
| [[hosted-session-context]] | `HostedSessionContext` / `HostedSessionIsolationKeyProvider` | — (post-1.6.1, ADR Accepted) |

## 技能系統（Skills） — v1.1.0 新增

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[agent-skills]] | `AgentClassSkill<T>` / `AgentInlineSkill` / `AgentSkillsProvider` / `AgentSkillsProviderBuilder` | ch05, ch29, appendix-d |
| [[feature-collections]] | `AgentRunOptions.Features` / `AdditionalProperties` | ch27 |
| [[agent-additional-properties]] | `AgentWithMetadata` / `AdditionalPropertiesDictionary` | — |

## 訊息注入（Message Injection） — v1.6.1 新增

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[chat-message-injector]] | `MessageInjectingChatClient` | ch06 |

## 檔案管理（File Management） — v1.6.1 新增

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[agent-session-files]] | `AgentSessionFiles` | ch08, appendix-a |

## Shell 工具（Shell Tools） — v1.6.1 新增

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[shell-tool]] | `ShellExecutor` / `LocalShellExecutor` / `DockerShellExecutor` | — (v1.6.1 新增，需撰寫) |

## 廢棄（Deprecated）

| 條目 | API 名稱 | 廢棄版本 |
|------|----------|---------|
| [[foundry-toolbox]] | `AIProjectClientToolboxExtensions` / `GetToolboxAsync`（已移除） | v1.6.1 |

## 狀態與持久化（State & Persistence）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[provider-session-state]] | `ProviderSessionState<T>` | ch14 |
| [[chat-history-persistence]] | `PerServiceCallChatHistoryPersistingChatClient` | ch14, ch21 |

## 可觀測性與品質（Observability & Quality）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[opentelemetry]] | `AddAgentFrameworkInstrumentation` | ch22 |
| [[agent-evaluation]] | `IAgentEvaluator` | ch28 |
| [[testing-strategy]] | N/A（測試模式） | ch12 |

## 基礎建設與部署（Infra & Deployment）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[llm-providers]] | `IChatClient`（各提供者實作） | ch17 |
| [[nuget-packages]] | `Microsoft.Agents.AI` 及相關套件 | ch03, appendix-a |
| [[aspnet-core-hosting]] | `MapAGUI` / `AddAgentFramework` | ch11 |
| [[docker-deployment]] | N/A（DevOps） | ch13 |

## 遷移指南（Migration）

| 條目 | API 名稱 | 教學章節 |
|------|----------|----------|
| [[migration-from-sk-autogen]] | N/A（遷移） | appendix-b |

---

## 按教學章節反查

| 章節 | 相關概念 |
|------|----------|
| ch01 | [[ai-agent]] |
| ch02 | [[ai-agent]], [[agent-session]], [[chat-client]], [[tools-ai-function]] |
| ch03 | [[chat-client]], [[nuget-packages]], [[chat-options]] |
| ch04 | [[ai-agent]], [[agent-session]], [[agent-response]], [[run-async]], [[chat-client]], [[chat-options]] |
| ch05 | [[tools-ai-function]], [[agent-skills]] |
| ch06 | [[middleware-pipeline]], [[context-providers]], [[agent-run-context]], [[chat-options]], [[chat-message-injector]] |
| ch07–ch10 | [[ai-agent]], [[tools-ai-function]] |
| ch08 | [[agent-session-files]] |
| ch11 | [[ag-ui-protocol]], [[middleware-pipeline]], [[aspnet-core-hosting]] |
| ch12 | [[middleware-pipeline]], [[testing-strategy]] |
| ch13 | [[docker-deployment]] |
| ch14 | [[agent-session]], [[context-providers]], [[provider-session-state]], [[chat-history-persistence]] |
| ch15 | [[agent-response]], [[structured-output]] |
| ch16 | [[human-in-the-loop]] |
| ch17 | [[chat-client]], [[llm-providers]] |
| ch18 | [[workflows]], [[orchestration-builders]] |
| ch19 | [[workflows]], [[orchestration-builders]], [[declarative-workflow]] |
| ch20 | [[durable-agents]] |
| ch21 | [[durable-agents]], [[chat-history-persistence]] |
| ch22 | [[opentelemetry]] |
| ch23 | [[a2a-protocol]] |
| ch24 | [[ag-ui-protocol]] |
| ch25 | [[mcp-integration]] |
| ch26 | [[long-running-operations]] |
| ch27 | [[feature-collections]] |
| ch28 | [[agent-evaluation]] |
| ch29 | [[agent-skills]] |
| ch30 | [[magentic-orchestration]], [[orchestration-builders]] |
| appendix-a | [[nuget-packages]], [[agent-session-files]] |
| appendix-b | [[migration-from-sk-autogen]] |
| appendix-d | [[agent-skills]], [[agent-run-context]] |

---

## brainstorming/qa-sessions 記錄

| 檔案 | 主題 | 相關概念 | promoted |
|------|------|----------|---------|
| `2026-04-17-middleware-prompt-interception.md` | Middleware Prompt Rewriting | middleware-pipeline | ✅ true |
| `2026-04-23-chatoptions-temperature.md` | ChatOptions.Temperature 定義、影響與使用方式 | chat-options, middleware-pipeline, run-async | ✅ true |
| `2026-05-20-microsoft-extensions-ai-testing.md` | Microsoft.Extensions.AI.Testing 不存在；FakeChatClient 正確測試模式 | testing-strategy | ✅ true |