---
title: AG-UI Protocol — 代理使用者互動協定
api_name: AddAGUIServer / MapAGUIServer
namespace: Microsoft.Agents.AI.Hosting.AGUI.AspNetCore
since: 1.0.0-preview
current_version: 1.15.0
updated: 2026-07-23
tags: [protocol, streaming, sse, frontend]
tutorial_chapters: [ch11, ch24]
sources:
  - raw/adrs/0010-ag-ui-support.md
  - raw/release-notes/dotnet-1.5.0.md
  - raw/release-notes/dotnet-1.14.0.md
  - raw/facts/dotnet-1.14.0-verified-changes.json
  - dotnet/src/Microsoft.Agents.AI.Hosting.AGUI.AspNetCore/AGUIServerServiceCollectionExtensions.cs
  - dotnet/src/Microsoft.Agents.AI.Hosting.AGUI.AspNetCore/AGUIEndpointRouteBuilderExtensions.cs
---

## 概述

AG-UI（Agent-User Interaction）Protocol 是代理與前端應用之間的標準化串流協定，基於 SSE（Server-Sent Events）。自 v1.14.0 起，舊 `Microsoft.Agents.AI.AGUI` 套件拆分為外部 `AGUI.Client`、`AGUI.Server`、`AGUI.Abstractions`、`AGUI.Protobuf` 與 `AGUI.Formatting`；本 repo 保留 ASP.NET Core hosting 整合，伺服端使用 `AddAGUIServer` 與 `MapAGUIServer`。注意：`thread_id` 是 AG-UI 協定層級欄位，與 `AgentSession` 的命名無關。

## 目前 API 簽名

```csharp
// ASP.NET Core 伺服端
builder.Services.AddAGUIServer();
app.MapAGUIServer("/api/agent", agent);

// 亦可依已註冊的 agent name 或 HostedAgentBuilder 映射端點
app.MapAGUIServer("/api/assistant", "assistant");

// SSE 事件類型
// RunStarted, RunFinished, RunError
// TextMessageStart, TextMessageContent, TextMessageEnd
// ToolCallStart, ToolCallEnd
// StateSnapshotStart, StateSnapshotContent, StateSnapshotEnd
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025-10 | ADR 0010 定義 |
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.5.0 | 2026-05-08 | 新增推理事件（Reasoning Events）串流支援（PR #4953）|
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |
| 1.14.0 | 2026-07-21 | **[Breaking]** 舊 `Microsoft.Agents.AI.AGUI` 拆分至外部 `AGUI.*` packages；伺服端 `AddAGUI`／`MapAGUI` 改名為 `AddAGUIServer`／`MapAGUIServer` |
| 1.15.0 | 2026-07-22 | 相容性驗證：AG-UI server hosting API 未再變更 |

## 教學章節對應

- 第 11 章：ASP.NET Core WebAPI 整合（`AddAGUIServer`／`MapAGUIServer` 用法）
- 第 24 章：AG-UI Protocol 深度（事件類型、State Management、前後端工具）

## 相關概念

- [[aspnet-core-hosting]]
- [[structured-output]]
- [[a2a-protocol]]
