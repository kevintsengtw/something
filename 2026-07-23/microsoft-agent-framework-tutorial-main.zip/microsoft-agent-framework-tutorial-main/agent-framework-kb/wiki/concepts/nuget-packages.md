---
title: NuGet 套件總覽
api_name: Microsoft.Agents.AI (及相關套件)
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.13.0
updated: 2026-07-05
tags: [packages, installation, setup]
tutorial_chapters: [ch03, appendix-a]
sources:
  - raw/release-notes/dotnet-1.0.0.md
  - raw/release-notes/dotnet-1.1.0.md
  - raw/release-notes/dotnet-1.2.0.md
  - raw/release-notes/dotnet-1.3.0.md
  - raw/release-notes/dotnet-1.4.0.md
  - raw/release-notes/dotnet-1.5.0.md
  - raw/release-notes/dotnet-1.6.1.md
  - raw/release-notes/dotnet-1.7.0.md
  - raw/release-notes/dotnet-1.8.0.md
  - raw/release-notes/dotnet-1.9.0.md
  - raw/release-notes/dotnet-1.10.0.md
  - raw/release-notes/dotnet-1.11.0.md
  - raw/facts/dotnet-1.11.0-verified-changes.json
  - raw/release-notes/dotnet-1.12.0.md
  - raw/facts/dotnet-1.12.0-verified-changes.json
  - raw/release-notes/dotnet-1.13.0.md
  - raw/facts/dotnet-1.13.0-verified-changes.json
---

## 概述

Agent Framework 的 .NET 實作分為多個 NuGet 套件，核心為 `Microsoft.Agents.AI`。自 v1.0.0 GA 起不需要 `--prerelease` 旗標。目前最新穩定版為 **1.13.0（2026-07-03）**；`Microsoft.Agents.AI.Workflows.Declarative` 系列自 v1.9.0 起亦轉為 stable，安裝不再需要 `--prerelease`。底層相依 `Microsoft.Extensions.AI` 為 10.6.0、`ModelContextProtocol` 為 1.2.0。v1.11.0 新增 `Microsoft.Agents.AI.LocalCodeAct` 套件（本機 Python 執行）。v1.13.0 起 Agent Skills API 移除 `[Experimental]` 標記，正式轉為穩定 API。

## 套件清單

| 套件 | 用途 |
|------|------|
| `Microsoft.Agents.AI` | 核心抽象（AIAgent、AgentSession、Middleware） |
| `Microsoft.Agents.AI.OpenAI` | OpenAI / Azure OpenAI 整合 |
| `Microsoft.Agents.AI.Workflows` | 工作流程編排（WorkflowBuilder、Executor） |
| `Microsoft.Agents.AI.Workflows.Declarative` | 宣告式 YAML 工作流程 |
| `Microsoft.Agents.AI.Hosting` | ASP.NET Core 託管（MapAGUI） |
| `Microsoft.Agents.AI.Hosting.A2A` | A2A server hosting（v1.3.0：A2AAgentHandler、A2AServerServiceCollectionExtensions） |
| `Microsoft.Agents.AI.A2A` | A2A client（v1.3.0：升級至 A2A SDK 1.0.0-preview2） |
| `Microsoft.Agents.AI.Foundry` | Azure AI Foundry 整合（v1.0.0 起由 AzureAI 改名） |
| `Microsoft.Agents.AI.Foundry.Hosting` | Foundry Hosted Agent 支援（v1.3.0：新增 FoundryToolbox） |
| `Microsoft.Agents.AI.Anthropic` | Anthropic Claude 整合（prerelease） |
| `Microsoft.Agents.AI.Hosting.Aspire` | .NET Aspire 整合（v1.3.0：preview 狀態） |
| `Microsoft.Agents.AI.Hyperlight` | CodeAct 整合（v1.4.0 GA，Hyperlight 沙盒） |
| `Microsoft.Agents.AI.LocalCodeAct` | CodeAct 本機 Python 執行（v1.11.0 新增，`LocalCodeActProvider`） |

## 安裝

```bash
dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.OpenAI
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

## 目前 API 簽名

不適用（本條目為套件參考表，無單一核心 API 簽名；各套件的 API 定義見對應的 wiki 條目）。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-rc5 | 2026-03 | AzureAI → Foundry 改名 |
| 1.0.0 | 2026-04-02 | GA；移除 `OpenAIAssistantClientExtensions` 類別 (PR #5058) |
| 1.1.0 | 2026-04-10 | Anthropic SDK 12.8.0 → 12.11.0；新增 gpt-5.4-mini |
| 1.2.0 | 2026-04-21 | Foundry Hosted Agents、Foundry Evals、Handoff 重構 |
| 1.3.0 | 2026-04-24 | **[Breaking]** A2A SDK v1 遷移；A2A streaming；Foundry Toolbox（.NET）；新增 `Microsoft.ML.Tokenizers` 依賴 |
| 1.4.0 | 2026-05-05 | **[Breaking]** file-based skill scripts 參數改為 `string[]`；新增 `Microsoft.Agents.AI.Hyperlight`（CodeAct GA）；OpenTelemetry 升級至 1.15.3 |
| 1.5.0 | 2026-05-08 | 新增 Magentic Orchestration（Experimental）；AG-UI Reasoning Events；WebBrowsingTool allow listing；MEAI 10.5.1；**本版本無 Breaking Changes** |
| 1.6.1 | 2026-05-14 | **[Breaking]** `OpenTelemetryAgent` 自動包裝 `ChatClient`；Foundry Toolbox server-side tools 移除；新增 `IChatMessageInjector`、Shell Tool、`AgentSessionFiles`；A2A input-request 支援；跳過 1.6.0（patch 直發） |
| 1.7.0 | 2026-05-26 | base `AgentSkill` 消費端 API 改非同步（#6030，撰寫端不變）；MCP 長時間任務；Magentic 範例 |
| 1.8.0 | 2026-05-28 | `AgentFileSkillsSource` depth-based 重構（#6109）；移除 Declarative code-gen（#6095）；MCP-based skills（第 4 來源）；高階編排 Builder（Sequential/Concurrent） |
| 1.9.0 | 2026-06-03 | **Orchestrations 移除 `[Experimental]`**（#6164，Magentic 轉正式）；`Microsoft.Agents.AI.Workflows.Declarative` 轉 stable（#6254）；Workflow Outputs Overhaul（#6045） |
| 1.10.0 | 2026-06-11 | 維護 + 增強：`Microsoft.Extensions.AI` → 10.6.0（#6148）、`ModelContextProtocol` 1.1.0 → 1.2.0（#6239）、GitHub Copilot SDK → v1.0.0（#6381）；`ToolApprovalAgent` 自動核可規則（#6335）；HarnessAgent token compaction 改 opt-in（#6409）。無教學影響的 Breaking |
| 1.11.0 | 2026-06-24 | 維護 + 增強：新增 `Microsoft.Agents.AI.LocalCodeAct`（本機 Python 執行，#6105）；`LoopAgent` Harness 迴圈（#6384）；`FileAccessProvider` 工具核可 + 目錄探索（#6521、#6474）；A2A 預設 `NoopAgentSessionStore`（#6635）。相依：`Anthropic.Foundry` 0.5.0 → 0.6.0（#6057）、`Azure.AI.Projects` → 2.1.0-beta.3（#6542）、`MessagePack` → 3.1.7（#6497）。無教學影響的 Breaking |
| 1.11.1 | 2026-06-26 | **[Breaking]** 技能工具預設需核可（#6729，移除 `ScriptApproval`/`UseScriptApproval`）+ 移除 `{resource_instructions}`/`{script_instructions}` 佔位符（#6706）——**影響 ch29**。新增 `IncludeDetailedErrors`（#6680）、archive 型 MCP 技能（#6631）、`DeclarativeWorkflowJsonOptions`（#6745）。.NET SDK → 10.0.301（#6730） |
| 1.12.0 | 2026-07-02 | **[Breaking]** 技能快取抽離為 `CachingAgentSkillsSource`、移除 `DisableCaching`（#6768）——**影響 ch29 小結**。**[Breaking]** Foundry.Hosting MAAI001 旗標對齊（#6743）、`Azure.AI.AgentServer` → 2.0.0（#6800）。新增 `BackgroundTaskCompletionLoopEvaluator`（#6736，Harness）。skill resource/script `description` 屬性（#6759） |
| 1.13.0 | 2026-07-03 | **[穩定化]** Skills API 移除 `[Experimental]`（#6861）。技能核可選項 + 自動核可規則（#6843）；`AgentSkillsSourceContext` + source `IDisposable` + 內建 source 改 public（#6797/#6827/#6838）。**[Breaking，教學未示範]** FileAccess/FileMemory 檔案編輯工具（#6807）、OpenAI Hosting OptionsMapping（#6855）。相依：`Azure.AI.Projects` → 2.1.0-beta.4（#6795） |

## 教學章節對應

- 第 03 章：開發環境準備（安裝套件）
- 附錄 A：NuGet 套件參考表

## 相關概念

- [[chat-client]]
- [[llm-providers]]
