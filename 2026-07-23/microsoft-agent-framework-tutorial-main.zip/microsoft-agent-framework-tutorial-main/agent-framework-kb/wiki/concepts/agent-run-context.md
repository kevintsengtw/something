---
title: AgentRunContext — 代理執行期環境上下文
api_name: AgentRunContext / AIAgent.CurrentRunContext
namespace: Microsoft.Agents.AI
since: Proposed
current_version: 1.6.1
updated: 2026-05-20
tags: [core, context, async-local, middleware, tools]
tutorial_chapters: [ch06, ch14]
sources:
  - raw/adrs/0015-agent-run-context.md
  - brainstorming/qa-sessions/2026-04-17-middleware-prompt-interception.md
---

## 概述

`AgentRunContext` 封裝單次代理執行的完整上下文（執行中的 agent、session、request messages、run options），透過 `AsyncLocal<T>` 儲存於靜態屬性 `AIAgent.CurrentRunContext`，自動隨 async/await 呼叫鏈流動。ADR 0015（Proposed）設計此機制，讓 middleware、工具函式、巢狀呼叫等深層元件不需逐層傳參即可存取執行上下文。

## 目前 API 簽名

```csharp
// AgentRunContext 型別（不可變）
public class AgentRunContext
{
    public AIAgent Agent { get; }
    public AgentSession? Session { get; }
    public IReadOnlyCollection<ChatMessage> RequestMessages { get; }
    public AgentRunOptions? RunOptions { get; }
}

// 從任意 async 呼叫鏈中存取
var ctx = AIAgent.CurrentRunContext;

// 常見使用情境

// 1. 在工具函式中讀取原始 prompt
var prompt = AIAgent.CurrentRunContext?
    .RequestMessages
    .LastOrDefault(m => m.Role == ChatRole.User)
    ?.Text;

// 2. 在子代理工具中傳播父代理的 session
public static AIFunction AsAIFunctionWithSessionPropagation(this ChatClientAgent agent)
{
    async Task<string> InvokeAgentAsync(string query, CancellationToken ct)
    {
        // 從父代理上下文取得 session，傳給子代理
        var parentSession = AIAgent.CurrentRunContext?.Session;
        var response = await agent.RunAsync(query, session: parentSession, ct);
        return response.Text;
    }
    return AIFunctionFactory.Create(InvokeAgentAsync);
}

// 3. 在 middleware 中存取（通常直接用 context.Messages，但 CurrentRunContext 也可用）
.Use(async (context, next) =>
{
    // context.Messages 與 AIAgent.CurrentRunContext?.RequestMessages 相同來源
    var agentName = AIAgent.CurrentRunContext?.Agent.Name;
    await next(context);
})
```

### 設計原則

- **所有屬性唯讀**：`AgentRunContext` 不可變，避免在執行中途意外修改
- **AsyncLocal 流動**：自動跨越 `await` 邊界，無需手動傳參
- **外部元件使用**：framework 內部元件仍以顯式參數傳遞；`CurrentRunContext` 供外部元件（tool、第三方 middleware）使用
- **巢狀代理**：當子代理呼叫 `RunAsync` 時，會建立新的 `AgentRunContext` 覆寫目前值

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| — | 2026-01 | ADR 0015 Proposed |
| 1.1.0 | 2026-04-10 | 尚未 GA（ADR 仍 Proposed） |
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，ADR 0015 Proposed 狀態維持，相容 v1.6.1 |

## 教學章節對應

- 第 06 章：Middleware 與 Context 基礎（可補充 CurrentRunContext 說明）
- 第 14 章：Context Providers 深度（與 ProviderSessionState 的互補關係）

## 相關概念

- [[middleware-pipeline]]
- [[context-providers]]
- [[agent-session]]
- [[run-async]]
