---
title: LLM Providers — 多提供者整合
api_name: IChatClient (各提供者實作)
namespace: Microsoft.Extensions.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-15
tags: [providers, openai, azure, anthropic, ollama, gemini, foundry-hosted-agents, foundry-toolbox]
tutorial_chapters: [ch17]
sources:
  - raw/release-notes/dotnet-1.1.0.md
  - raw/release-notes/dotnet-1.2.0.md
  - raw/release-notes/dotnet-1.3.0.md
  - raw/devblogs/github-readme-overview.md
  - raw/adrs/0004-foundry-sdk-extensions.md
  - raw/adrs/0011-create-get-agent-api.md
  - raw/adrs/0020-foundry-agent-type-naming.md
  - raw/adrs/0021-provider-leading-clients.md
  - raw/adrs/0025-foundry-toolbox-support.md
  - raw/samples/README.md
  - raw/samples/dotnet-sdk-samples.md
---

## 概述

Agent Framework 透過 `IChatClient` 介面支援 7 種以上 LLM 提供者：Azure AI Foundry、Azure OpenAI、OpenAI、Anthropic Claude、GitHub Models、Ollama、Google Gemini。每個提供者有對應的 NuGet 套件與 Client 類別。

**v1.2.0 新增：** Azure AI Foundry 托管代理（Hosted Agents）完整 .NET 支援。
**v1.3.0 新增：** Foundry Toolbox server-side tools（`FoundryToolbox` + `AIProjectClientToolboxExtensions`）；Azure.AI.AgentServer.Responses SDK 升至 beta.4（含 breaking change）。
**v1.6.1 變更：** `FoundryToolbox` 與 `GetToolboxAsync()` **完整移除**（Breaking Change），詳見 [[foundry-toolbox]]。新增 `FoundryAgent` 型別作為直接建立 Foundry 代理的推薦方式。

## 支援的提供者

| 提供者 | Client 類別 | NuGet 套件 | 特色 |
|--------|------------|-----------|------|
| Azure AI Foundry | AIProjectClient | Microsoft.Agents.AI.Foundry | 企業級代管 |
| Azure AI Foundry Hosted Agents | — | Microsoft.Agents.AI.Foundry | v1.2.0 GA（.NET） |
| Azure AI Foundry Toolbox | `FoundryToolbox` / `AIProjectClientToolboxExtensions` | Microsoft.Agents.AI.Foundry.Hosting | v1.3.0 GA（.NET）；server-side tools |
| Azure OpenAI | AzureOpenAIClient | Azure.AI.OpenAI | Azure 整合 |
| OpenAI | OpenAIClient | OpenAI | 最新模型 |
| Anthropic | AnthropicClient | Microsoft.Agents.AI.Anthropic | 長上下文 |
| GitHub Models | OpenAIClient (替換 endpoint) | OpenAI | 免費評估 |
| Ollama | OllamaApiClient | Microsoft.Extensions.AI.Ollama | 本地模型 |
| Gemini | GeminiClient | 對應套件 | 多模態（Python GA v1.2.0） |

## 目前 API 簽名

```csharp
// Azure OpenAI
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(options);

// Azure AI Foundry（標準模式）
AIAgent agent = new AIProjectClient(new Uri(endpoint), new DefaultAzureCredential())
    .AsAIAgent(options);

// OpenAI
AIAgent agent = new OpenAIClient(apiKey)
    .GetChatClient(modelId)
    .AsAIAgent(options);

// Anthropic
AIAgent agent = new AnthropicClient(apiKey)
    .AsAIAgent(options);

// GitHub Models
AIAgent agent = new OpenAIClient(
    new ApiKeyCredential(token),
    new OpenAIClientOptions { Endpoint = new Uri("https://models.inference.ai.azure.com") })
    .GetChatClient(modelId)
    .AsAIAgent(options);

// Ollama
AIAgent agent = new OllamaApiClient(new Uri("http://localhost:11434"), modelId)
    .AsAIAgent(options);

// FoundryAgent（v1.6.1 推薦，直接建立不依賴 Toolbox）
FoundryAgent agent = new FoundryAgent(
    new Uri(endpoint),
    new AzureCliCredential(),
    model: "gpt-5.4-mini",
    instructions: "You are good at telling jokes.",
    name: "JokerAgent");

// 或透過 AIProjectClient 擴充方法
FoundryAgent agent = new AIProjectClient(new Uri(endpoint), new DefaultAzureCredential())
    .AsAIAgent(
        model: deploymentName,
        instructions: "...",
        name: "JokerAgent");
// 環境變數：AZURE_AI_PROJECT_ENDPOINT、AZURE_AI_MODEL_DEPLOYMENT_NAME
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA：IChatClient 各提供者整合 |
| 1.1.0 | 2026-04-10 | 新增 gpt-5.4-mini 模型 |
| 1.2.0 | 2026-04-21 | Foundry Hosted Agents .NET 支援（PR #5312）；修正 Foundry 無 description Handoff 崩潰（#5311）；修正 Handoff-hosted Agents session（#5280） |
| 1.3.0 | 2026-04-24 | **[Breaking]** Azure.AI.AgentServer.Responses beta.3→beta.4：`FunctionToolCallOutputResource` → `OutputItemFunctionToolCallOutput`，`AzureAIAgentServerResponsesModelFactory` 改為 internal（PR #5450）；新增 `FoundryToolbox` + `AIProjectClientToolboxExtensions`（server-side Toolbox，PR #5450） |
| 1.6.1 | 2026-05-14 | **[Breaking]** 移除 `FoundryToolbox` + `GetToolboxAsync()`；新增 `FoundryAgent` 型別（直接建立 Foundry 代理）；Microsoft.Extensions.AI 升至 10.6.0 |

## 教學章節對應

- 第 17 章：7 種 LLM 提供者的完整整合教學
- 官方範例：`Agent-Framework-Samples/03.ExploerAgentFramework` — Azure OpenAI、GitHub Models、Foundry、Foundry Local 實作範例

## 相關概念

- [[chat-client]]
- [[ai-agent]]
- [[middleware-pipeline]]