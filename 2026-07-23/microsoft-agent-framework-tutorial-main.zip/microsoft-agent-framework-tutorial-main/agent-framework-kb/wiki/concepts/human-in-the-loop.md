---
title: Human-in-the-Loop — 人工介入確認
api_name: ToolApprovalAgent / ToolApprovalRequestContentExtensions
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.10.0
updated: 2026-06-14
tags: [safety, approval, hitl, v1.10.0]
tutorial_chapters: [ch16, ch19, ch21]
sources:
  - raw/adrs/0006-userapproval.md
  - raw/release-notes/dotnet-1.2.0.md
  - raw/release-notes/dotnet-1.6.1.md
  - raw/release-notes/dotnet-1.10.0.md
  - raw/facts/dotnet-1.10.0-verified-changes.json
---

## 概述

Human-in-the-Loop（HITL）讓代理在執行敏感操作前暫停等待人工確認。ADR 0006（Accepted）定義了標準的 `UserInputRequestContent` / `UserInputResponseContent` 型別體系，取代舊版 `IsApproved` 原地修改模式。`FunctionInvokingChatClient` 攔截需要確認的函式呼叫並自動產生 `FunctionApprovalRequestContent`，代理以 `AgentResponse.UserInputRequests` 聚合屬性回傳給呼叫端。

## 目前 API 簽名

```csharp
// 1. 標記需要確認的工具（工具層）
var tool = AIFunctionFactory.Create(TransferMoney);
var approvalTool = new ApprovalRequiredAIFunction(tool);

var agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Tools = [approvalTool],
});

// 2. 執行迴圈（ADR 0006 模式）
var response = await agent.RunAsync("將 $500 轉給 Alice", thread);

while (response.UserInputRequests.Any())
{
    var messages = new List<ChatMessage>();
    foreach (var req in response.UserInputRequests)
    {
        if (req is FunctionApprovalRequestContent approval)
        {
            // 向使用者顯示 approval.FunctionCall?.Arguments
            bool userApproved = AskUserForApproval(approval);

            messages.Add(new ChatMessage(ChatRole.User,
                userApproved
                    ? approval.CreateApproval()
                    : approval.CreateRejection()));
        }
    }
    // 傳入確認結果繼續執行
    response = await agent.RunAsync(messages, thread);
}

Console.WriteLine(response.Text);
```

### 核心型別（ADR 0006）

```csharp
// 基底型別
class UserInputRequestContent : AIContent { public string Id { get; set; } }
class UserInputResponseContent : AIContent { public string Id { get; set; } }

// 函式呼叫確認（最常用）
class FunctionApprovalRequestContent : UserInputRequestContent
{
    public FunctionCallContent FunctionCall { get; set; }
    public FunctionApprovalResponseContent CreateApproval() => ...;
    public FunctionApprovalResponseContent CreateRejection() => ...;
}

// AgentResponse 聚合屬性
class AgentResponse
{
    public IEnumerable<UserInputRequestContent> UserInputRequests { get; set; }
}
```

### Handoff HITL（v1.2.0 新增）

v1.2.0 引入 Handoff 型 HITL：工作流程中的代理可在特定條件下暫停並移交控制權給人工，人工審核後再繼續。與 `ApprovalRequiredAIFunction` 不同，Handoff 模式適合整個工作流程節點的暫停，而非單一工具呼叫的確認。

```csharp
// Workflow 中的 Handoff HITL（Durable 模式）
// 代理回傳 HandoffContent 時，框架暫停執行並等待外部事件
var response = await agent.RunAsync(messages, session);

if (response.FinishReason == ChatFinishReason.Handoff)
{
    // 通知人工審核（e.g., 發送 email 或 Slack 通知）
    await NotifyHumanReviewerAsync(response);

    // 等待人工繼續（可等待數小時）
    await session.WaitForResumeAsync();
}
```

### ToolApprovalAgent 自動核可規則（v1.10.0 新增）

除了 ADR 0006 的逐次 `FunctionApprovalRequestContent` 流程，框架另提供 **`ToolApprovalAgent`** middleware（`Microsoft.Agents.AI`，Harness 套件，`[Experimental]`），以 `AIAgentBuilder.UseToolApproval()` 掛載，支援「don't ask again」的常駐核可（standing rules）。v1.10.0（PR #6335）為其加入**啟發式自動核可規則** `AutoApprovalRules`，可在不打擾使用者的情況下放行符合條件的工具呼叫。

```csharp
using Microsoft.Agents.AI;

// AutoApprovalRules：一組啟發式函式，回傳 true 即自動核可該工具呼叫
var options = new ToolApprovalAgentOptions
{
    AutoApprovalRules =
    [
        // 範例：唯讀查詢類工具一律自動核可
        call => new ValueTask<bool>(call.Name.StartsWith("get_", StringComparison.OrdinalIgnoreCase)),
    ],
};

AIAgent agent = innerAgent
    .AsBuilder()
    .UseToolApproval(options)   // 掛載工具核可 middleware
    .Build();
```

**評估順序**（`ToolApprovalAgent` 內部）：

1. **Standing rules**：由先前使用者回傳 `AlwaysApproveToolApprovalResponseContent`（「don't ask again」）衍生的常駐核可；
2. **AutoApprovalRules**：依序評估，第一個回傳 `true` 者自動核可；
3. 皆未命中 → 提示使用者（浮現 `ToolApprovalRequestContent`）。

> Standing rule **優先於** auto-approval rule（上游測試 `RunAsync_StandingRuleTakesPrecedenceOverAutoApprovalRuleAsync` 驗證）。

#### 儲存自動核可的函式（v1.10.0，PR #4950）

`ChatClientBuilderExtensions.UseNonApprovalRequiredFunctionBypassing` 會把「不需核可」的函式呼叫自動核可並持久化於 session 狀態，當它們與需核可工具一同回傳時，**只把真正需要人工核可的工具浮現給呼叫端**。Harness 場景預設啟用，可用 `HarnessAgentOptions.DisableNonApprovalRequiredFunctionBypassing = true` 關閉。

> 此 `ToolApprovalAgent` 路線與上方 ADR 0006 的 `FunctionApprovalRequestContent` 逐次流程是兩條並行的核可機制：前者偏向 agent pipeline middleware + 常駐/啟發式核可，後者偏向呼叫端逐次審批。

### A2A input-request（v1.6.1 新增）

v1.6.1 A2A Protocol 新增 `input-request` 內容型別，讓代理在 A2A 對話中請求人工輸入：

```csharp
// A2A 代理回傳 input-request（v1.6.1）
// A2AAgentHandler 自動將 UserInputRequestContent 轉換為 A2A input-request 訊息
// 呼叫端 A2A Client 收到後需回傳 input-response 繼續執行
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025 Q3 | 初始設計：`ApprovalRequiredAIFunction` + `IsApproved` 模式 |
| 1.0.0 | 2026-04-02 | ADR 0006 Accepted：`UserInputRequestContent` / `FunctionApprovalRequestContent` 型別體系 |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.2.0 | 2026-04-21 | 新增 Handoff HITL Orchestration 支援：工作流程節點層級的人工介入移交 |
| 1.3.0 | 2026-04-24 | 無變更 |
| 1.4.0 | 2026-05-05 | 無變更 |
| 1.5.0 | 2026-05-08 | 無變更 |
| 1.6.1 | 2026-05-20 | A2A Protocol 新增 `input-request` 內容型別，HITL 流程可跨 A2A 邊界傳遞 |
| 1.10.0 | 2026-06-11 | `ToolApprovalAgent` 加入 `AutoApprovalRules` 啟發式自動核可（PR #6335）；`UseNonApprovalRequiredFunctionBypassing` 持久化不需核可的函式呼叫（PR #4950）。皆為 additive，不影響既有 ADR 0006 流程 |

## 教學章節對應

- 第 16 章：HITL 完整教學（Console、Web API、AG-UI 三種確認模式）
- 第 19 章：Workflow 版 HITL（`WaitForExternalEventAsync`）
- 第 21 章：Durable HITL 持久化

## 相關概念

- [[tools-ai-function]]
- [[middleware-pipeline]]
- [[ag-ui-protocol]]
- [[agent-response]]
