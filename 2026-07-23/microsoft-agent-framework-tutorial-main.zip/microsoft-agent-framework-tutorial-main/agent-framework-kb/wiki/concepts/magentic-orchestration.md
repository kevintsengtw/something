---
title: Magentic Orchestration — 磁性多代理編排
api_name: MagenticWorkflowBuilder
namespace: Microsoft.Agents.AI.Workflows
since: 1.5.0
current_version: 1.10.0
updated: 2026-06-14
tags: [orchestration, multi-agent, workflows, magentic, v1.5.0, v1.9.0-stable]
tutorial_chapters: [ch30]
sources:
  - raw/release-notes/dotnet-1.5.0.md
  - raw/release-notes/dotnet-1.7.0.md
  - raw/release-notes/dotnet-1.9.0.md
  - raw/release-notes/dotnet-1.10.0.md
  - raw/facts/dotnet-1.9.0-verified-changes.json
---

## 概述

Magentic Orchestration 是 v1.5.0 引入的多代理編排機制，基於管理員驅動（manager-driven）的規劃迴圈。相較於 Graph-based Workflows 需手動定義路由圖，Magentic 讓一個 AI 管理員代理自行規劃任務分配，並動態路由到適當的執行代理，實現「任務解決團隊」（task-solving teams）模式。

> **狀態（v1.9.0 起）**：.NET Orchestrations 已於 v1.9.0 移除 `[Experimental]` 標記（PR #6164），公開入口 `MagenticWorkflowBuilder` 轉為穩定 API。內部編排型別 `MagenticOrchestrator`、`MagenticManager`（`Microsoft.Agents.AI.Workflows.Specialized.Magentic`）已改為 `internal`，使用者不直接建構。

## 目前 API 簽名

```csharp
// 公開入口：MagenticWorkflowBuilder（Microsoft.Agents.AI.Workflows）
using Microsoft.Agents.AI.Workflows;

public class MagenticWorkflowBuilder(AIAgent managerAgent)
    : OrchestrationBuilderBase<MagenticWorkflowBuilder>
{
    public MagenticWorkflowBuilder AddParticipants(params IEnumerable<AIAgent> agents);
    public MagenticWorkflowBuilder WithMaxRounds(int? maxRounds = null);   // null = 無限
    public MagenticWorkflowBuilder WithMaxResets(int? maxResets = null);   // null = 無限
    public MagenticWorkflowBuilder WithMaxStalls(int maxStalls = 3);       // 連續無進展上限
    public MagenticWorkflowBuilder RequirePlanSignoff(bool requirePlanSignoff = true); // 預設需人工核可計畫
    public Workflow Build();
}
```

### 組裝並執行 Magentic 工作流程

```csharp
using Microsoft.Agents.AI.Workflows;

// managerAgent 負責規劃；participants 為執行團隊
Workflow workflow = new MagenticWorkflowBuilder(managerAgent)
    .AddParticipants(researchAgent, writerAgent, reviewAgent)
    .WithMaxRounds(20)
    .WithMaxStalls(3)
    .RequirePlanSignoff(false)   // 設 true 可在計畫產生時插入人工審批（HITL）
    .Build();

// 以一般 Workflow 方式執行（MagenticOrchestrator 為內部編排節點）
await using Run run = await InProcessExecution.RunAsync(
    workflow, "研究並撰寫一份關於 AI 代理趨勢的報告");
```

## 設計概念

### 與 Graph-based Workflows 的差異

| 面向 | Graph-based Workflows | Magentic Orchestration |
|------|----------------------|----------------------|
| 路由定義 | 手動（開發者定義節點與邊） | 自動（AI 管理員動態規劃） |
| 適用場景 | 確定性流程、有副作用步驟 | 開放性任務、需創意規劃 |
| 可預測性 | 高 | 低（AI 決策） |
| Checkpointing | 支援 | 支援（`MagenticOrchestrator` 內部以 `OnCheckpointingAsync`/`OnCheckpointRestoredAsync` 持久化 task context） |
| 狀態管理 | 自訂 shared states | `MagenticProgressLedger`（內部） |

### 管理員驅動規劃迴圈

```
① Manager 接收任務目標
② Manager 規劃執行步驟（建立 Progress Ledger）
③ Orchestrator 依計畫路由到對應 Executor 代理
④ Executor 回報結果，Manager 更新 Ledger
⑤ 若任務未完成，Manager 動態調整計畫
⑥ 重複直到任務完成
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.5.0 | 2026-05-08 | 首次引入（Experimental）：`MagenticOrchestrator`、`MagenticManager`、`MagenticProgressLedger`、`MagenticTaskContext`、`MagenticWorkflowBuilder`（PR #5595, #5704） |
| 1.6.1 | 2026-05-20 | 驗證相容性：Experimental API 未變更，相容 v1.6.1 |
| 1.7.0 | 2026-05-26 | 新增 Magentic Orchestration 範例（PR #5823，`dotnet/samples/03-workflows/Orchestration/Magentic`） |
| 1.9.0 | 2026-06-03 | **移除 `[Experimental]` 標記**（PR #6164）：`MagenticWorkflowBuilder` 轉穩定公開 API；`MagenticOrchestrator`/`MagenticManager` 改為 `internal`。Workflow Outputs Overhaul（PR #6045）使 builder 以 `WithOutputFrom`/`WithIntermediateOutputFrom` 標註輸出 |
| 1.10.0 | 2026-06-11 | **[Bug Fix]** 修正 Magentic 跨團隊共享代理回覆的行為（PR #6222）：執行團隊成員現可正確看見彼此回覆。`MagenticWorkflowBuilder` 公開 API 簽名不變 |

## 教學章節對應

- **第 30 章：Magentic Orchestration** — `MagenticWorkflowBuilder` 完整教學（規劃迴圈、事件觀測、計畫審批 HITL、輸出標註、模式選擇）

相關進階主題：
- [[orchestration-builders]]（編排建構器家族 — ch18, ch19, ch30）
- [[workflows]]（Graph-based Workflows — ch18, ch19）
- [[durable-agents]]（Durable Agent Orchestration — ch20, ch21）

## 相關概念

- [[orchestration-builders]]（同屬 `OrchestrationBuilderBase` 編排家族）
- [[workflows]]
- [[durable-agents]]
- [[agent-run-context]]
- [[human-in-the-loop]]（`MagenticPlanReviewRequest` 可搭配人工審批）
