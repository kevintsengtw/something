---
title: Long-Running Operations — 長時間非同步操作
api_name: IAsyncChatClient / AgentRun / AsyncRunResult
namespace: Microsoft.Agents.AI
since: 1.0.0
current_version: 1.11.0
updated: 2026-06-25
tags: [advanced, async, long-running]
tutorial_chapters: [ch26]
sources:
  - raw/adrs/0009-support-long-running-operations.md
  - raw/release-notes/dotnet-1.3.0.md
  - raw/release-notes/dotnet-1.4.0.md
  - raw/release-notes/dotnet-1.10.0.md
  - raw/facts/dotnet-1.10.0-verified-changes.json
  - raw/release-notes/dotnet-1.11.0.md
  - raw/facts/dotnet-1.11.0-verified-changes.json
---

## 概述

Long-Running Operations 支援需要數分鐘到數小時的代理任務（程式碼生成、複雜推論、大型文件處理）。`IAsyncChatClient` 介面提供完整的非同步操作生命週期：提交、查詢狀態、取得結果、取消。代理端透過 `AgentResponse.AgentRun`（非 null 時 `ChatFinishReason.LongRunning`）向呼叫方信號「需輪詢」。

## 目前 API 簽名

```csharp
// IAsyncChatClient 介面（由支援長時間操作的 provider 實作）
public interface IAsyncChatClient
{
    Task<AsyncRunResult> StartAsyncRunAsync(
        IList<ChatMessage> messages,
        RunOptions? options = null,
        CancellationToken ct = default);

    Task<AsyncRunResult> GetAsyncRunStatusAsync(
        string runId, CancellationToken ct = default);

    Task<AsyncRunResult> GetAsyncRunResultAsync(
        string runId, CancellationToken ct = default);

    Task<AsyncRunResult> CancelAsyncRunAsync(
        string runId, CancellationToken ct = default);

    Task<AsyncRunResult> DeleteAsyncRunAsync(
        string runId, CancellationToken ct = default);
}

// 呼叫端使用模式
AgentResponse response = await agent.RunAsync(messages, session);

if (response.AgentRun != null)  // ChatFinishReason.LongRunning
{
    // 輪詢直到完成
    while (!response.AgentRun.IsCompleted)
    {
        await Task.Delay(TimeSpan.FromSeconds(5));
        response = await agent.GetRunResultAsync(response.AgentRun.RunId);
    }
}

Console.WriteLine(response.Text);

// 取消
await agent.CancelRunAsync(response.AgentRun.RunId);
```

### 支援長時間操作的提供者

| 提供者 | 支援方式 |
|--------|---------|
| Azure AI Foundry Agents | 原生 async run |
| OpenAI Responses API | Background mode |
| A2A Protocol | Task 狀態輪詢 |

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| — | 2025-10 | ADR 0009 設計定案 |
| 1.0.0 | 2026-04-02 | GA；`IAsyncChatClient`、`AgentRun`、`AsyncRunResult` 定型 |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.2.0 | 2026-04-21 | 無變更 |
| 1.3.0 | 2026-04-24 | **[Bug Fix]** 修正 `StreamingRunEventStream.RunLoopAsync` 中 `RunStatus` off-thread race：`GetStatusAsync` 在 `ResumeAsync` halt 後可能誤回傳 Running（PR #5412） |
| 1.4.0 | 2026-05-05 | Durable Workflow HTTP trigger endpoint 支援回傳執行結果（PR #5321）：不再只回傳 202 Accepted，呼叫端可直接取得最終回應 |
| 1.5.0 | 2026-05-08 | 無變更 |
| 1.6.1 | 2026-05-20 | 驗證相容性：`IAsyncChatClient` API 未變更，相容 v1.6.1 |
| 1.9.0 | 2026-06-03 | `HarnessAgent` 建構子加入 `ILoggerFactory`/`IServiceProvider`（皆可選，PR #6273） |
| 1.10.0 | 2026-06-11 | `HarnessAgent` 移除必填 token 參數（PR #6409）：`HarnessAgentOptions.MaxContextWindowTokens`/`MaxOutputTokens` 改為可選（`int?`），in-loop context-window 壓縮改為 **opt-in**——僅當兩者皆提供且未設自訂 `CompactionStrategy`、`DisableCompaction=false` 時，才建構預設 `ContextWindowCompactionStrategy` |
| 1.11.0 | 2026-06-24 | 新增 `LoopAgent`（`Microsoft.Agents.AI.Harness.Loop`，`[Experimental]`，PR #6384）：以 `LoopEvaluator` 驅動把被包裝代理放進迴圈反覆執行，`LoopAgentOptions` 提供 `MaxIterations`（安全上限）、`FreshContextPerIteration`、`NonStreamingReturnsLastResponseOnly` 等選項。Harness `FileAccessProvider`（`Microsoft.Agents.AI.Harness.FileAccess`，`[Experimental]`）所暴露工具改為需明確核可 + 自動核可規則（PR #6521），並加入目錄探索 + 遞迴搜尋對齊 Python（PR #6474） |

## 教學章節對應

- 第 26 章：Long-Running Operations 完整教學（輪詢、取消、AG-UI streaming 整合）

## 相關概念

- [[durable-agents]]
- [[workflows]]
- [[a2a-protocol]]
