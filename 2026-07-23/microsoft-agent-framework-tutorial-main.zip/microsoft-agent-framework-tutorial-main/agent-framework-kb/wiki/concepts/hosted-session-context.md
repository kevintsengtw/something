---
title: HostedSessionContext — Foundry 託管的每用戶 Session 隔離
api_name: HostedSessionContext
namespace: Microsoft.Agents.AI.Foundry.Hosting
since: post-1.6.1
current_version: post-1.6.1
updated: 2026-05-24
tags: [foundry, hosting, security, session, identity, isolation]
tutorial_chapters: []
sources:
  - raw/adrs/0026-hosted-session-identity-context.md
---

## 概述

`HostedSessionContext` 是 Foundry 託管代理的每用戶 Session 隔離機制。Foundry 平台在每個 Responses 請求上注入 `x-agent-user-isolation-key` 和 `x-agent-chat-isolation-key` 標頭，`HostedSessionContext` 將這兩個隔離鍵封裝後存入 `AgentSessionStateBag`，讓 `AIContextProvider` 實作可讀取用戶身份以分隔記憶體等每用戶狀態。

> ⚠️ **狀態**：ADR 已 Accepted（2026-05-07），但尚未出現在任何 .NET 穩定版 Release Notes（截至 v1.6.1）。此功能預計在下一個 .NET 次要版本中落地。

## 目前 API 簽名

```csharp
// 在 Microsoft.Agents.AI.Foundry.Hosting 命名空間

// 身份容器（不可變，兩個欄位均必填且非空白）
public sealed class HostedSessionContext
{
    public string UserId { get; }
    public string ChatId { get; }
}

// 讀取 accessor（供 AIContextProvider 使用）
public static class HostedSessionContextExtensions
{
    public static HostedSessionContext? GetHostedContext(this AgentSession session);
    // SetHostedContext 為 internal，由 Hosting 組件在 session 建立時寫入
}

// DI 工廠抽象（可替換實作）
public abstract class HostedSessionIsolationKeyProvider
{
    public abstract ValueTask<HostedSessionContext?> GetKeysAsync(
        ResponseContext context,
        CreateResponse request,
        CancellationToken cancellationToken);
}

// 預設實作（internal，對應 platform 注入的 IsolationContext headers）
internal sealed class PlatformHostedSessionIsolationKeyProvider
    : HostedSessionIsolationKeyProvider { }

// 本機開發用（platform headers 不存在時的暫時替代）
public sealed class DevTemporaryLocalSessionIsolationKeyProvider
    : HostedSessionIsolationKeyProvider { }
```

## 使用方式

```csharp
// 在 AIContextProvider 中讀取用戶身份
public class PerUserMemoryProvider : AIContextProvider
{
    public override ValueTask ProvideAIContextAsync(
        AIContextProviderContext context,
        CancellationToken cancellationToken)
    {
        var hosted = context.Session.GetHostedContext();
        if (hosted is null) return default;

        // 用 hosted.UserId 為每個用戶分隔記憶
        var userKey = hosted.UserId;
        // ...
        return default;
    }
}

// 本機開發：在 DI 中替換 provider（platform headers 不存在）
services.AddSingleton<HostedSessionIsolationKeyProvider,
    DevTemporaryLocalSessionIsolationKeyProvider>();
```

## 運作機制

```
Foundry Platform
  x-agent-user-isolation-key: <UserId>
  x-agent-chat-isolation-key: <ChatId>
          ↓
AgentFrameworkResponseHandler.CreateAsync()
  1. 解析 HostedSessionIsolationKeyProvider（DI 或 default）
  2. 呼叫 GetKeysAsync(context, request, ct)
  3. 依 session 狀態處理：
     - session 不存在 → 略過
     - session 未 stamp → 寫入身份（SetHostedContext, internal）
     - session 已 stamp → 嚴格比對；不符回傳 403
          ↓
AgentSession.StateBag["HostedSessionContext"]
  → session.GetHostedContext() 讀取
  → AIContextProvider 使用
```

## 安全設計

| 特性 | 說明 |
|------|------|
| 身份來源 | `ResponseContext.Isolation`（平台注入），不信任 caller 設定的 `request.User` |
| 寫入限制 | `SetHostedContext` 為 `internal`，`AIContextProvider` 只能讀取 |
| Session 恢復保護 | 嚴格相等比對：UserId/ChatId 不符 → `ResponsesApiException(403)` |
| 本機開發 | `DevTemporaryLocalSessionIsolationKeyProvider` 提供替代實作 |

## 為何使用 StateBag 而非繼承

ADR 評估了四種方案：

| 方案 | 否決原因 |
|------|---------|
| `HostedAgentSession : AgentSession` 繼承 | `ChatClientAgentSession` 是 sealed，需大量重構 |
| `AgentSession` 新增屬性 | 洩漏 Foundry-only 語意到通用抽象 |
| AsyncLocal middleware | 無法強制 read-only，每個 provider 需重實作橋接 |
| **StateBag（選用）** | 隔離 Foundry 語意，序列化自動包含，identity read-only |

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| post-1.6.1 | 2026-05-07 (ADR accepted) | 首次引入 `HostedSessionContext`、`GetHostedContext()`、`HostedSessionIsolationKeyProvider` |

## 教學章節對應

— 尚無對應教學章節（功能尚未在 .NET 穩定版發佈）

建議：功能 GA 後，可補充至 ch17（LLM Providers / Foundry）或新建 appendix-f（Foundry 進階托管）。

## 相關概念

- [[agent-session]]
- [[context-providers]]
- [[llm-providers]]
- [[provider-session-state]]
