---
title: OpenAI Responses Hosting — 應用程式自管協定轉換
api_name: OpenAIResponses / OpenAIResponsesRunRequest / HostedWorkflowState / AgentSessionStore
namespace: Microsoft.Agents.AI.Hosting.OpenAI / Microsoft.Agents.AI.Hosting
since: 1.15.0
current_version: 1.15.0
updated: 2026-07-23
tags: [hosting, openai-responses, protocol, session, workflow]
tutorial_chapters: [ch11]
sources:
  - raw/adrs/0032-dotnet-hosting-protocol-helpers.md
  - raw/release-notes/dotnet-1.15.0.md
  - raw/facts/dotnet-1.15.0-verified-changes.json
  - dotnet/src/Microsoft.Agents.AI.Hosting.OpenAI/OpenAIResponses.cs
  - dotnet/src/Microsoft.Agents.AI.Hosting.OpenAI/OpenAIResponsesRunRequest.cs
  - dotnet/src/Microsoft.Agents.AI.Hosting/AgentSessionStore.cs
  - dotnet/src/Microsoft.Agents.AI.Hosting/HostedWorkflowState.cs
  - dotnet/samples/04-hosting/af-hosting/local_responses/Server/Program.cs
  - dotnet/samples/04-hosting/af-hosting/local_responses_workflow/Server/Program.cs
---

## 概述

v1.15.0 新增 `OpenAIResponses`，提供無 I/O、無副作用的 OpenAI Responses wire protocol 轉換 helpers。適合應用程式自行掌控 HTTP route、authentication、authorization、middleware 與 storage，只重用 Agent Framework 的 request/response mapping。`HostedWorkflowState` 則提供以 checkpoint 為基礎的 workflow run-or-resume 狀態管理。

## 目前 API 簽名

```csharp
public static class OpenAIResponses
{
    public static OpenAIResponsesRunRequest ToAgentRunRequest(
        JsonElement body,
        OpenAIResponsesMapOptions? mapOptions = null);

    public static JsonElement WriteResponse(
        AgentResponse response,
        string responseId,
        string? conversationId = null);

    public static IAsyncEnumerable<string> WriteResponseStreamAsync(
        IAsyncEnumerable<AgentResponseUpdate> updates,
        string responseId,
        string? conversationId = null,
        CancellationToken cancellationToken = default);

    public static string? GetSessionStoreId(OpenAIResponsesRunRequest request);
    public static string CreateResponseId();
}

public abstract class AgentSessionStore
{
    public abstract ValueTask DeleteSessionAsync(
        AIAgent agent,
        string sessionStoreId,
        CancellationToken cancellationToken = default);
}

public sealed class HostedWorkflowState
{
    public ValueTask<HostedWorkflowRunResult> RunOrResumeAsync<TInput>(
        string sessionId,
        TInput input,
        CancellationToken cancellationToken = default);

    public IAsyncEnumerable<WorkflowEvent> RunOrResumeStreamingAsync<TInput>(
        string sessionId,
        TInput input,
        CancellationToken cancellationToken = default);
}
```

`OpenAIResponses.GetSessionStoreId` 回傳的 `previous_response_id` 或 `conversation` id 是未受信任的候選 key；應用程式必須先將它與已驗證的 caller identity 綁定並授權，才能用作 session 或 checkpoint key。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.15.0 | 2026-07-22 | 新增 `OpenAIResponses`、`OpenAIResponsesRunRequest`、`HostedWorkflowState`、`HostedWorkflowRunResult`；`AgentSessionStore` 新增 abstract `DeleteSessionAsync`，自訂 store 實作者必須補實作（PR #7000） |

## 教學章節對應

- 第 11 章目前涵蓋 ASP.NET Core hosting 與 AG-UI；本概念列為可選 enhancement，尚未加入 app-owned OpenAI Responses route 實作。

## 相關概念

- [[aspnet-core-hosting]]
- [[agent-session]]
- [[workflows]]
- [[chat-history-persistence]]
