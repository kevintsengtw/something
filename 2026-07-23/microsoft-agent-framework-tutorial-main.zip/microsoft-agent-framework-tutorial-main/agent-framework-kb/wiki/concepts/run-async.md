---
title: RunAsync / RunStreamingAsync — 代理執行方法
api_name: AIAgent.RunAsync / AIAgent.RunStreamingAsync
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [core, execution, streaming, a2a]
tutorial_chapters: [ch04]
sources:
  - raw/adrs/0001-agent-run-response.md
  - raw/release-notes/dotnet-1.3.0.md
---

## 概述

`RunAsync` 與 `RunStreamingAsync` 是代理的兩個核心執行方法。`RunAsync` 回傳完整的 `AgentResponse`（適合後端處理），`RunStreamingAsync` 回傳 `IAsyncEnumerable<AgentResponseUpdate>`（適合即時 UI）。兩者皆接受 `AgentSession` 管理對話狀態、`AgentRunOptions` 控制執行行為。**v1.3.0：** A2A `A2AAgentHandler` 現在依 `context.StreamingResponse` 自動路由至 `RunStreamingAsync`（A2A streaming 支援）。

## 目前 API 簽名

```csharp
// 非串流
Task<AgentResponse> RunAsync(
    IEnumerable<ChatMessage> messages,
    AgentSession? session = null,
    AgentRunOptions? options = null,
    CancellationToken cancellationToken = default);

// 簡化用法（字串輸入）
AgentResponse response = await agent.RunAsync("你好");
Console.WriteLine(response.Text);

// 串流
IAsyncEnumerable<AgentResponseUpdate> RunStreamingAsync(
    IEnumerable<ChatMessage> messages,
    AgentSession? session = null,
    AgentRunOptions? options = null,
    CancellationToken cancellationToken = default);

// 串流用法
await foreach (var update in agent.RunStreamingAsync("你好"))
{
    Console.Write(update.Text);
}
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025-07 | ADR 0001 定義回傳型別 |
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.3.0 | 2026-04-24 | `RunStreamingAsync` 被 `A2AAgentHandler` 採用：`context.StreamingResponse = true` 時自動走串流路徑（PR #5427）；核心 API 簽名無變更 |
| 1.6.1 | 2026-05-20 | 驗證相容性：RunAsync / RunStreamingAsync API 未變更，相容 v1.6.1 |

## 教學章節對應

- 第 04 章：建立第一個 Agent（RunAsync 與 RunStreamingAsync 完整範例）

## 相關概念

- [[ai-agent]]
- [[agent-response]]
- [[agent-session]]
