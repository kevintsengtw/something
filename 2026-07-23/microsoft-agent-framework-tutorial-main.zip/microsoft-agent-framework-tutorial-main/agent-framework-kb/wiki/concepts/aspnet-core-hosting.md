---
title: ASP.NET Core 託管 — Hosting Library
api_name: MapAGUIServer / AddAGUIServer / OpenAIResponses
namespace: Microsoft.Agents.AI.Hosting.AGUI.AspNetCore / Microsoft.Agents.AI.Hosting.OpenAI
since: 1.0.0-preview
current_version: 1.15.0
updated: 2026-07-23
tags: [hosting, webapi, aspnet, deployment, session-isolation]
tutorial_chapters: [ch11]
sources:
  - raw/release-notes/dotnet-1.8.0.md
  - raw/facts/dotnet-1.8.0-verified-changes.json
  - raw/adrs/0027-hosting-channels.md
  - raw/adrs/0032-dotnet-hosting-protocol-helpers.md
  - raw/release-notes/dotnet-1.14.0.md
  - raw/facts/dotnet-1.14.0-verified-changes.json
  - raw/release-notes/dotnet-1.15.0.md
  - raw/facts/dotnet-1.15.0-verified-changes.json
---

## 概述

`Microsoft.Agents.AI.Hosting` 提供 ASP.NET Core 整合，讓代理透過 HTTP 端點對外提供服務。v1.14.0 的 AG-UI hosting 以 `AddAGUIServer`／`MapAGUIServer` 建立 AG-UI SSE 端點；v1.15.0 另提供 `OpenAIResponses` app-owned protocol helpers，讓應用程式自行掌控 HTTP route、authentication、middleware 與 storage。

## 目前 API 簽名

```csharp
// Program.cs
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddAGUIServer();

var app = builder.Build();

// AG-UI 端點
app.MapAGUIServer("/api/agent", agent);

// 健康檢查
app.MapHealthChecks("/health");

app.Run();
```

## ClaimsIdentity Session 隔離（v1.8.0，PR #5696）

多租戶/多使用者場景下，可依目前使用者身分（`ClaimsIdentity`）為 agent session 產生隔離鍵，避免不同使用者共用同一 session。`Microsoft.Agents.AI.Hosting.AspNetCore` 提供擴充方法：

```csharp
using Microsoft.Agents.AI.Hosting.AspNetCore;

builder.Services.AddHttpContextAccessor();   // 必要前置（擴充方法依賴 IHttpContextAccessor）

// 註冊以使用者 claims 產生 session 隔離鍵的 SessionIsolationKeyProvider
builder.Services.UseClaimsBasedSessionIsolation();

// 可選：自訂要用哪些 claim 組成隔離鍵
builder.Services.UseClaimsBasedSessionIsolation(new ClaimsIdentitySessionIsolationKeyProviderOptions
{
    // ... 依需求設定要採用的 claim
});
```

相關型別：`ClaimsIdentitySessionIsolationKeyProvider`、`ClaimsIdentitySessionIsolationKeyProviderOptions`、`SessionIsolationKeyProvider`（基底）、`IsolationKeyScopedAgentSessionStore`（依隔離鍵 scope 的 session store）。

> 與 [[hosted-session-context]]（Foundry 託管的 `HostedSessionContext`）為**不同**機制：此處為 ASP.NET Core 自管 hosting 的 session 隔離，前者為 Foundry 託管環境的每用戶 context。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |
| 1.8.0 | 2026-05-28 | 新增 `UseClaimsBasedSessionIsolation`（`ClaimsIdentity`-based agent session scoping，PR #5696）；`IsolationKeyScopedAgentSessionStore` |
| 1.9.0 | 2026-06-03 | 相容性驗證：相容 v1.9.0 |
| 1.14.0 | 2026-07-21 | **[Breaking]** AG-UI server API 改為 `AddAGUIServer`／`MapAGUIServer`；protocol types 移至外部 `AGUI.*` packages |
| 1.15.0 | 2026-07-22 | 新增 `OpenAIResponses`／`OpenAIResponsesRunRequest` app-owned protocol helpers；`AgentSessionStore` 新增 abstract `DeleteSessionAsync`；新增 `HostedWorkflowState` |

## 教學章節對應

- 第 11 章：ASP.NET Core WebAPI 整合完整教學

## 相關概念

- [[ag-ui-protocol]]
- [[docker-deployment]]
- [[middleware-pipeline]]
- [[hosted-session-context]]（Foundry 託管的 session 隔離對照）
