---
title: ProviderSessionState — 跨輪對話狀態
api_name: ProviderSessionState<T>
namespace: Microsoft.Agents.AI
since: 1.0.0
current_version: 1.6.1
updated: 2026-05-15
tags: [state, session, context-provider, persistence]
tutorial_chapters: [ch14]
sources:
  - raw/adrs/0018-agentthread-serialization.md
  - raw/samples/dotnet-sdk-samples.md
---

## 概述

`ProviderSessionState<T>` 讓 Context Providers 在 AgentSession 中儲存跨輪對話的狀態，同時保持 Provider 本身無狀態（stateless）。這是 ADR 0018 的核心設計：狀態屬於 Session，行為屬於 Provider。Session 序列化（`SerializeSessionAsync`/`DeserializeSessionAsync`）會自動包含所有 Provider 的狀態。

## 目前 API 簽名

```csharp
public class UserInfoMemory : AIContextProvider
{
    // 1. 宣告 ProviderSessionState<T>，提供初始化器和唯一 state key
    private readonly ProviderSessionState<UserInfo> _sessionState;

    public UserInfoMemory()
    {
        _sessionState = new ProviderSessionState<UserInfo>(
            stateInitializer: _ => new UserInfo(),
            stateKey: this.GetType().Name);
    }

    // 2. 公開 StateKeys 供序列化使用
    public override IReadOnlyList<string> StateKeys => [_sessionState.StateKey];

    // 3. 在 StoreAIContextAsync 中讀取並更新狀態
    protected override async ValueTask StoreAIContextAsync(
        InvokedContext context, CancellationToken ct = default)
    {
        // GetOrInitializeState：取得現有狀態或用初始化器建立
        var info = _sessionState.GetOrInitializeState(context.Session);
        info.UserName = "Alice";  // 更新
        // SaveState：將更新後的狀態存回 session
        _sessionState.SaveState(context.Session, info);
    }

    // 4. 在 ProvideAIContextAsync 中讀取狀態並注入到對話
    protected override ValueTask<AIContext> ProvideAIContextAsync(
        InvokingContext context, CancellationToken ct = default)
    {
        var info = _sessionState.GetOrInitializeState(context.Session);
        return ValueTask.FromResult(new AIContext
        {
            Instructions = $"User name: {info.UserName ?? "unknown"}."
        });
    }

    // 5. 外部可取得特定 session 的狀態
    public UserInfo GetUserInfo(AgentSession session)
        => _sessionState.GetOrInitializeState(session);

    public void SetUserInfo(AgentSession session, UserInfo info)
        => _sessionState.SaveState(session, info);
}

public sealed class UserInfo
{
    public string? UserName { get; set; }
    public int? UserAge { get; set; }
}
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-rc | 2026-02 | ADR 0018 定義 |
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | 無變更 |

## 教學章節對應

- 第 14 章：Context Providers 深度（ProviderSessionState 完整教學）

## 相關概念

- [[context-providers]]
- [[agent-session]]
