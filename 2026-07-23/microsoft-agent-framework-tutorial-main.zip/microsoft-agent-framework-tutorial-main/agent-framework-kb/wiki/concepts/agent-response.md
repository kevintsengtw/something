---
title: AgentResponse — 代理回應型別
api_name: AgentResponse
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [core, response, streaming]
tutorial_chapters: [ch04, ch15]
sources:
  - raw/adrs/0001-agent-run-response.md
---

## 概述

`AgentResponse` 與 `AgentResponseUpdate` 是代理執行後的回應型別。`RunAsync` 回傳 `AgentResponse`（非串流），`RunStreamingAsync` 回傳 `IAsyncEnumerable<AgentResponseUpdate>`（串流）。兩者皆提供 `.Text` 屬性快速取得文字回應。

## 目前 API 簽名

```csharp
// 非串流
AgentResponse response = await agent.RunAsync("你好");
Console.WriteLine(response.Text);

// 串流
await foreach (var update in agent.RunStreamingAsync("你好"))
{
    Console.Write(update.Text);
}

// AgentResponse 結構
class AgentResponse
{
    public string Text { get; }
    public IList<ChatMessage> Messages { get; set; }
    public string? ResponseId { get; set; }
    public UsageDetails? Usage { get; set; }
}

// AgentResponseUpdate 結構
class AgentResponseUpdate
{
    public string Text { get; }
    public IList<AIContent> Contents { get; set; }
    public string? ResponseId { get; set; }
}

// 結構化輸出
response.TryParseStructuredOutput<T>(out var result);
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025-07 | ADR 0001 定義，獨立於 MEAI 的自訂回應型別 |
| 1.0.0 | 2026-04-02 | GA 釋出 |
| 1.1.0 | 2026-04-10 | 無變更 |
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |

## 教學章節對應

- 第 04 章：RunAsync / RunStreamingAsync 基本用法
- 第 15 章：結構化輸出 TryParseStructuredOutput

## 相關概念

- [[ai-agent]]
- [[structured-output]]
- [[run-async]]
