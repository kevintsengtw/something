---
title: 從 Semantic Kernel / AutoGen 遷移
api_name: N/A (Migration)
namespace: N/A
since: 1.0.0
current_version: 1.6.1
updated: 2026-05-20
tags: [migration, semantic-kernel, autogen]
tutorial_chapters: [appendix-b]
sources: []
---

## 概述

Microsoft Agent Framework 統一了 Semantic Kernel（SK）與 AutoGen 的核心能力。SK 的 Kernel + Plugins 對應為 AIAgent + Tools，AutoGen 的 GroupChat 對應為 AgentWorkflowBuilder.CreateGroupChatBuilder。遷移指南涵蓋概念對照、API 對應表與漸進式遷移步驟。

## 概念對照

| Semantic Kernel | AutoGen | Agent Framework |
|----------------|---------|----------------|
| Kernel | — | AIAgent |
| Plugin / Function | — | AIFunction / AIFunctionFactory |
| — | ConversableAgent | AIAgent |
| — | GroupChat | AgentWorkflowBuilder.CreateGroupChatBuilder |
| ChatCompletionService | ChatCompletionClient | IChatClient |
| KernelArguments | — | AgentRunOptions |

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA 釋出，遷移指南定稿 |
| 1.6.1 | 2026-05-20 | 驗證相容性：概念對照未變更，相容 v1.6.1 |

## 教學章節對應

- 附錄 B：從 SK / AutoGen 遷移完整指南

## 相關概念

- [[ai-agent]]
- [[tools-ai-function]]
- [[workflows]]
