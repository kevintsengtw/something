---
title: CodeAct 整合 — 程式碼驅動的代理執行
api_name: HyperlightCodeActProvider / AIContextProvider (execute_code)
namespace: Microsoft.Agents.AI.Hyperlight
since: 1.4.0
current_version: 1.11.0
updated: 2026-06-25
tags: [advanced, codeact, sandbox, hyperlight, context-provider, v1.4.0]
tutorial_chapters: []
sources:
  - raw/adrs/0024-codeact-integration.md
  - raw/release-notes/dotnet-1.4.0.md
  - raw/release-notes/dotnet-1.11.0.md
  - raw/facts/dotnet-1.11.0-verified-changes.json
---

## 概述

CodeAct 是讓 LLM 生成可執行程式碼（而非固定 function-call JSON）來協調工具呼叫的模式。v1.4.0 以獨立套件 **`Microsoft.Agents.AI.Hyperlight`** GA 發布（PR #5329），後端為 Hyperlight 沙盒。CodeAct 不影響 core；框架貢獻 `execute_code` 工具，LLM 生成程式碼在隔離的沙盒中執行，並可透過 `call_tool(...)` 呼叫已配置的工具。

v1.11.0 新增 **`Microsoft.Agents.AI.LocalCodeAct`** 套件（PR #6105），提供 `LocalCodeActProvider`/`LocalCodeActProviderOptions`，於**本機**執行 Python 程式碼，作為 Hyperlight 沙盒之外的本機後端選項。同版亦讓 Hyperlight 沙盒在工具登錄更新後自動重建（PR #6523）。

## 目前 API 簽名

```csharp
// 使用 CodeAct（可選套件，具體型別名稱為 Proposed）
var codeActProvider = new HyperlightCodeActProvider(options =>
{
    // 配置在 CodeAct 沙盒內可用的工具
    options.AllowedTools = [searchTool, calculatorTool];
    options.WorkspaceRoot = "/tmp/sandbox";     // 可選檔案存取
    options.AllowedOutboundTargets = ["api.example.com"]; // 可選網路
});

ChatClientAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    // CodeAct provider 在模型呼叫前注入 execute_code 工具與指令
    AIContextProviders = [codeActProvider],
    // 直接工具（不進入沙盒）與 CodeAct 工具是獨立的
    Tools = [directOnlyTool],
});

// 呼叫方式與一般 agent 相同
var response = await agent.RunAsync("計算這組資料的統計摘要並篩選前10筆");
```

### CodeAct 與一般 Tool Calling 的差異

| | 一般 Tool Calling | CodeAct |
|---|---|---|
| LLM 輸出 | FunctionCallContent（JSON 結構） | 可執行程式碼字串 |
| 執行環境 | 主程序（in-process） | Hyperlight 沙盒（隔離） |
| 多步邏輯 | 多輪 LLM 呼叫 | 單次沙盒執行 |
| 延遲 | 每步一次 LLM round-trip | 單次 LLM + 沙盒執行 |
| Token 消耗 | 較高（多輪） | 較低（單輪） |

### 確認模式（Approval Mode）

```csharp
// execute_code 的確認由 provider 配置
options.ApprovalMode = ApprovalMode.AlwaysRequire;  // 每次執行前確認
options.ApprovalMode = ApprovalMode.NeverRequire;   // 依 provider 工具決定
```

### 每次執行隔離保證

- 每次 `execute_code` 呼叫從乾淨狀態開始（無跨呼叫的記憶體狀態）
- 持久化透過 WorkspaceRoot 掛載的檔案
- 並行安全：provider 為每次 run 快照工具配置

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| — | 2026-04-07 | ADR 0024 Proposed |
| 1.1.0 | 2026-04-10 | 尚未 GA（ADR 仍 Proposed） |
| 1.4.0 | 2026-05-05 | **GA**：`Microsoft.Agents.AI.Hyperlight` 套件正式發布，CodeAct .NET 整合（PR #5329） |
| 1.6.1 | 2026-05-20 | Hyperlight 後端更新（build-only 層，套件公開 API 未變更），相容 v1.6.1 |
| 1.11.0 | 2026-06-24 | 新增 `Microsoft.Agents.AI.LocalCodeAct` 套件（`LocalCodeActProvider`/`LocalCodeActProviderOptions`，本機 Python 執行，PR #6105）；Hyperlight 沙盒於工具登錄更新後自動重建（PR #6523）。Hyperlight 後端撰寫端 API 不變 |

## 教學章節對應

- 目前無對應教學章節（v1.4.0 GA，尚未納入教學）
- 建議未來納入附錄 D 或新增進階章節

## 相關概念

- [[context-providers]]
- [[tools-ai-function]]
- [[human-in-the-loop]]
- [[agent-run-context]]
