---
title: MessageInjectingChatClient — 函數迴圈訊息注入
api_name: MessageInjectingChatClient
namespace: Microsoft.Agents.AI
since: 1.6.1
current_version: 1.15.0
updated: 2026-07-23
tags: [core, function-loop, injection, middleware, stable, v1.14.0-breaking]
tutorial_chapters: [ch06]
sources:
  - raw/release-notes/dotnet-1.6.1.md
  - raw/release-notes/dotnet-1.14.0.md
  - raw/facts/dotnet-1.14.0-verified-changes.json
  - dotnet/src/Microsoft.Agents.AI/ChatClient/MessageInjectingChatClient.cs
  - dotnet/src/Microsoft.Agents.AI/ChatClient/ChatClientAgentOptions.cs
  - dotnet/src/Microsoft.Agents.AI/ChatClient/ChatClientBuilderExtensions.cs
  - dotnet/tests/Microsoft.Agents.AI.UnitTests/ChatClient/MessageInjectingChatClientTests.cs
---

## 概述

`MessageInjectingChatClient` 是 v1.6.1 新增的 `DelegatingChatClient`，允許在代理執行函數呼叫迴圈（function loop）期間動態注入額外的 `ChatMessage`。v1.14.0 移除 `[Experimental]` 並把 queue 操作改為非同步方法。典型用途包括在工具呼叫之間插入系統提示補充、加入稽核訊息，或在特定條件下插入約束指令。

> ⚠️ **wiki 舊版本錯誤記錄**：此 API 原本依 release notes 描述記錄為 `IChatMessageInjector`（interface），但實際 C# 原始碼為 `MessageInjectingChatClient`（sealed class）。已於 2026-05-23 依原始碼更正。

## 目前 API 簽名

```csharp
// 類別定義（v1.14.0 起為 stable）
public sealed class MessageInjectingChatClient : DelegatingChatClient
{
    public MessageInjectingChatClient(IChatClient innerClient);

    // 注入訊息（執行緒安全，可在工具委派中呼叫）
    public Task EnqueueMessagesAsync(
        AgentSession session,
        IEnumerable<ChatMessage> messages,
        CancellationToken cancellationToken = default);

    // 取得目前待注入的訊息快照
    public Task<IReadOnlyList<ChatMessage>> GetPendingMessagesAsync(
        AgentSession session,
        CancellationToken cancellationToken = default);
}

// 啟用方式一：透過 ChatClientAgentOptions
var agent = chatClient.AsAIAgent(
    name: "MyAgent",
    instructions: "...",
    options: new ChatClientAgentOptions { EnableMessageInjection = true });

// 啟用方式二：手動加入 pipeline
chatBuilder.UseMessageInjection();

// 取得實例並注入訊息（在工具委派中）
var injector = agent.GetService<MessageInjectingChatClient>();
await injector.EnqueueMessagesAsync(session, [
    new ChatMessage(ChatRole.System, $"[Audit] 工具呼叫時間：{DateTime.UtcNow:u}")
]);
```

## 運作機制

訊息注入器位於 `FunctionInvokingChatClient` 和底層 `IChatClient` 之間：

```
FunctionInvokingChatClient
  → MessageInjectingChatClient   ← 此處
    → [PerServiceCallChatHistoryPersistingChatClient]
      → leaf IChatClient
```

每次工具呼叫結束後：
1. 若有待注入訊息 → 自動再次呼叫底層 client（包含新訊息）
2. 若無待注入訊息 → 回傳結果給 `FunctionInvokingChatClient`

待注入的訊息佇列儲存在 `AgentSession.StateBag`，每個 session 隔離。

## 使用場景

| 場景 | 說明 |
|------|------|
| 稽核追蹤 | 每次工具呼叫前注入時間戳與追蹤 ID |
| 動態約束 | 根據執行狀態在迴圈中加入額外系統指令 |
| 注意力刷新 | 長對話中重新強調核心指令，防止 LLM「遺忘」 |

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.6.1 | 2026-05-14 | 首次引入 `MessageInjectingChatClient`；透過 `ChatClientAgentOptions.EnableMessageInjection` 或 `UseMessageInjection()` 啟用 |
| 1.14.0 | 2026-07-21 | **[Breaking]** 移除 `[Experimental]`；`EnqueueMessages`／`GetPendingMessages` 改為 `EnqueueMessagesAsync`／`GetPendingMessagesAsync`，並加入 `CancellationToken` |
| 1.15.0 | 2026-07-22 | 相容性驗證：API 未再變更 |

## 教學章節對應

- 第 06 章：Middleware and Context — `## v1.6.1 新增：MessageInjectingChatClient` 小節（L624），涵蓋啟用方式、與 Context Provider 的差異、程式碼範例

## 相關概念

- [[middleware-pipeline]]
- [[agent-run-context]]
- [[run-async]]
- [[chat-client]]
