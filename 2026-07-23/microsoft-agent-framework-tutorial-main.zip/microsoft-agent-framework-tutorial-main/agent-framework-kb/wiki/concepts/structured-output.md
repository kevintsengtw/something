---
title: 結構化輸出 — ForJsonSchema / RunAsync\<T\>
api_name: ChatResponseFormat.ForJsonSchema<T> / AIAgent.RunAsync<T>
namespace: Microsoft.Extensions.AI / Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-20
tags: [output, json, schema, structured]
tutorial_chapters: [ch15]
sources:
  - raw/adrs/0001-agent-run-response.md
  - raw/adrs/0014-feature-collections.md
  - raw/adrs/0016-structured-output.md
---

## 概述

結構化輸出讓代理回傳可預測的 JSON 格式。ADR 0016（Proposed）定義兩種互補方式：（1）`ResponseFormat` 屬性設定 schema，適合不確定型別、串流、宣告式代理；（2）泛型 `RunAsync<T>` 直接回傳強型別 `AgentResponse<T>`，框架處理 schema 生成與反序列化，並支援基本型別與集合（不受根必須為 JSON 物件的限制）。

## 目前 API 簽名

```csharp
// 方式一：ResponseFormat + Deserialize（適合不確定型別、串流、AIProjectClient）
public record OrderIntent(string Product, int Quantity, string Action);

// 建立時設定（適合固定輸出型別的代理）
var agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Instructions = "解析使用者的訂單意圖",
    ResponseFormat = ChatResponseFormat.ForJsonSchema<OrderIntent>(),
});

AgentResponse response = await agent.RunAsync("我要買 3 本書", session);
if (response.TryParseStructuredOutput<OrderIntent>(out var intent))
{
    Console.WriteLine($"{intent.Action}: {intent.Quantity} x {intent.Product}");
}

// 執行時設定
response = await agent.RunAsync("我要訂 5 份餐點", session,
    new AgentRunOptions
    {
        ResponseFormat = ChatResponseFormat.ForJsonSchema<OrderIntent>()
    });

// 方式二：RunAsync<T>（ADR 0016 Proposed — 框架處理 schema 包裝）
// 適合編譯時已知型別、基本型別、集合
AgentResponse<OrderIntent> typedResponse =
    await agent.RunAsync<OrderIntent>("我要買 3 本書");
Console.WriteLine($"結果：{typedResponse.Result.Product}");

// 支援基本型別和集合（框架自動包裝 JSON object）
AgentResponse<List<string>> items =
    await agent.RunAsync<List<string>>("列出5種常見程式語言");
// 方式一無法直接支援此情況（OpenAI 要求根為 JSON object）
```

### 方式選擇指引

| 情境 | 推薦方式 |
|------|---------|
| 型別在編譯時已知 | ✅ `RunAsync<T>` |
| 基本型別或集合 | ✅ `RunAsync<T>`（框架處理包裝） |
| 串流回應 | ✅ `ResponseFormat` |
| 型別在執行時才確定 | ✅ `ResponseFormat` |
| `AIProjectClient` 等代管代理 | ✅ `ResponseFormat`（建立時設定） |
| 套用 `OpenTelemetryAgent` 等裝飾器 | ✅ `RunAsync<T>`（在 AIAgent 基底，不被裝飾器遮蔽） |

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025 Q3 | `ResponseFormat` 方式設計 |
| 1.0.0 | 2026-04-02 | GA；`TryParseStructuredOutput<T>` 定型 |
| 1.1.0 | 2026-04-10 | 無變更 |
| — | ADR 0016 | `RunAsync<T>` 移至 AIAgent 基底類別（Proposed） |
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |

## 教學章節對應

- 第 15 章：完整結構化輸出教學（Schema 設計、多輪對話、AG-UI State Snapshots）

## 相關概念

- [[agent-response]]
- [[feature-collections]]
- [[ag-ui-protocol]]
