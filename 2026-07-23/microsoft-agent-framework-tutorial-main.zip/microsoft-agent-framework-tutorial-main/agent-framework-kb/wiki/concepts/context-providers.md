---
title: Context Providers — 動態上下文注入
api_name: AIContextProvider
namespace: Microsoft.Agents.AI
since: 1.0.0-preview
current_version: 1.6.1
updated: 2026-05-15
tags: [core, context, memory, state]
tutorial_chapters: [ch06, ch14]
sources:
  - raw/adrs/0018-agentthread-serialization.md
  - raw/adrs/0016-python-context-middleware.md
  - raw/samples/dotnet-sdk-samples.md
---

## 概述

`AIContextProvider` 讓代理在每次執行時動態注入額外的上下文資訊（系統時間、使用者偏好、外部資料等），無需手動修改 messages。Context Providers 是無狀態的，透過 `ProviderSessionState<T>` 在 AgentSession 中儲存跨輪對話的狀態。有兩個可覆寫方法：`StoreAIContextAsync`（觀察每次對話後存入狀態）和 `ProvideAIContextAsync`（每次呼叫前提供指令或上下文）。

## 目前 API 簽名

```csharp
// 自訂帶狀態的 Context Provider
public class UserInfoMemory : AIContextProvider
{
    private readonly ProviderSessionState<UserInfo> _sessionState;

    public UserInfoMemory()
    {
        _sessionState = new ProviderSessionState<UserInfo>(
            _ => new UserInfo(),         // 狀態初始化器
            this.GetType().Name);        // state key（用於序列化）
    }

    public override IReadOnlyList<string> StateKeys => [_sessionState.StateKey];

    // 每次工具呼叫後：觀察對話並更新狀態
    protected override async ValueTask StoreAIContextAsync(
        InvokedContext context,
        CancellationToken cancellationToken = default)
    {
        var userInfo = _sessionState.GetOrInitializeState(context.Session);
        // 從 context.RequestMessages 分析並更新 userInfo
        _sessionState.SaveState(context.Session, userInfo);
    }

    // 每次 RunAsync 前：將狀態轉為指令注入到對話
    protected override ValueTask<AIContext> ProvideAIContextAsync(
        InvokingContext context,
        CancellationToken cancellationToken = default)
    {
        var userInfo = _sessionState.GetOrInitializeState(context.Session);
        return new ValueTask<AIContext>(new AIContext
        {
            Instructions = $"The user's name is {userInfo.UserName}."
        });
    }
}

// 註冊
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    AIContextProviders = [new UserInfoMemory(chatClient.AsIChatClient())],
});

// 從代理取得已附加的 Provider 實例
var memory = agent.GetService<UserInfoMemory>();
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-preview | 2025 Q3 | 初始設計 |
| 1.0.0-rc | 2026-02 | ADR 0018：Providers 改為無狀態，狀態存入 ProviderSessionState |
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | 無變更 |

## 教學章節對應

- 第 06 章：Context Provider 基礎介紹
- 第 14 章：Context Providers 深度（ProviderSessionState、持久化）

## Python 對照（參考）

Python SDK 統一為 `ContextPlugin` / `ContextProvider` 階層（ADR-0016）：

| .NET 概念 | Python 對應 |
|-----------|------------|
| `AIContextProvider` | `ContextProvider`（Python Protocol） |
| `AgentSession.GetProviderState<T>()` | `ContextProvider.invoking()` / `invoked()` hooks |
| `AIContextProviders = [...]` | `context_providers=[...]` 建構參數 |

## 相關概念

- [[agent-session]]
- [[provider-session-state]]
- [[middleware-pipeline]]
- [[agent-skills]]
- [[chat-history-persistence]]
