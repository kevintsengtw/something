---
title: Chat History Persistence — 對話歷史持久化
api_name: PerServiceCallChatHistoryPersistingChatClient
namespace: Microsoft.Agents.AI
since: 1.0.0
current_version: 1.6.1
updated: 2026-05-20
tags: [persistence, history, middleware, decorator]
tutorial_chapters: [ch14, ch21]
sources:
  - raw/adrs/0022-chat-history-persistence-consistency.md
  - raw/adrs/0016-python-context-middleware.md
  - raw/adrs/0019-python-context-compaction-strategy.md
---

## 概述

Chat History Persistence 控制代理對話歷史的儲存時機。預設為 per-run（執行結束時一次性儲存），可透過 `RequirePerServiceCallChatHistoryPersistence` 選項切換為 per-service-call（每次 LLM 呼叫後儲存）。後者透過 `PerServiceCallChatHistoryPersistingChatClient` decorator 實現。

## 目前 API 簽名

```csharp
// 預設 per-run（原子性、簡單）
var agent = chatClient.AsAIAgent(options);

// opt-in per-service-call（更即時、可恢復中間狀態）
var agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    RequirePerServiceCallChatHistoryPersistence = true,
});

// 搭配 DI（Per-Run ChatMessageStore 覆寫）
var response = await agent.RunAsync(userInput, session,
    new AgentRunOptions
    {
        Features = new AgentFeatureCollection()
            .WithFeature<ChatMessageStore>(myStore)
    });
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0-rc5 | 2026-03 | ServiceStoredSimulatingChatClient → PerServiceCallChatHistoryPersistingChatClient（改名） |
| 1.0.0 | 2026-04-02 | GA |
| 1.1.0 | 2026-04-10 | Compaction 重複修復 (PR #5149) |
| 1.6.1 | 2026-05-20 | 驗證相容性：API 未變更，相容 v1.6.1 |

## 教學章節對應

- 第 14 章：Context Providers 中的持久化說明
- 第 21 章：Durable Agents 搭配持久化

## Python 對照（參考）

Python SDK 在此領域有不同設計（ADR-0016、ADR-0019）：

| .NET 概念 | Python 對應 |
|-----------|------------|
| `PerServiceCallChatHistoryPersistingChatClient` | `HistoryProvider`（`ContextProvider` 子類別） |
| `IChatReducer`（ADR 未正式定義，可參考 Compaction 實作） | `CompactionStrategy`（Protocol，ADR-0019）|
| `RequirePerServiceCallChatHistoryPersistence` | `HistoryProvider` 建構時的 `store_inputs` / `store_responses` 選項 |
| `ChatReducerTriggerEvent` | `compaction_strategy` 參數（pre-write / in-run） |

> 詳見 `raw/adrs/0019-python-context-compaction-strategy.md` 的 .NET Comparison 章節。

## 相關概念

- [[agent-session]]
- [[durable-agents]]
- [[context-providers]]
