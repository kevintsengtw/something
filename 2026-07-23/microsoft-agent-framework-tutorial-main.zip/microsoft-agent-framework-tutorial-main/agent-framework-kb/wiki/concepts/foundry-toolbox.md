---
title: Foundry Toolbox — server-side tools（已廢棄）
api_name: AIProjectClientToolboxExtensions / GetToolboxAsync
namespace: Microsoft.Agents.AI.Foundry.Hosting
since: 1.3.0
current_version: DEPRECATED
updated: 2026-05-14
tags: [foundry, toolbox, deprecated, breaking]
tutorial_chapters: []
sources:
  - raw/adrs/0025-foundry-toolbox-support.md
  - raw/release-notes/dotnet-1.3.0.md
  - raw/release-notes/dotnet-1.6.1.md
  - raw/samples/README.md
---

## ⛔ 廢棄通知（v1.6.1）

> **此功能已於 v1.6.1 完整移除（Breaking Change）。**
>
> `AIProjectClient.GetToolboxAsync()` 及相關 server-side tools API 不再可用。
> 所有使用此 API 的程式碼在升級後**無法編譯**。

## 遷移方式

改用 client-side 工具定義，透過 `AIFunctionFactory.Create()` 直接在代理端定義工具：

```csharp
// ❌ v1.3.0–v1.5.0（已移除）
IReadOnlyList<AIFunction> toolboxTools =
    await aiProjectClient.GetToolboxAsync("my-toolbox-name");

AIAgent agent = foundryClient.AsAIAgent(new ChatClientAgentOptions
{
    Tools = [.. toolboxTools],
});

// ✅ v1.6.1+ 替代方案
[Description("取得天氣資訊")]
static string GetWeather(string city) => $"{city} 晴天";

AIAgent agent = foundryClient.AsAIAgent(new ChatClientAgentOptions
{
    Tools = [AIFunctionFactory.Create(GetWeather)],
});
```

## 歷史背景

Foundry Toolbox 在 v1.3.0（2026-04-24）引入，目標是讓代理可直接從 Azure AI Foundry 取得預定義的 server-side tools，減少 client 端重複定義工具的負擔。但因架構複雜性與維護成本，在 v1.6.1 中決定移除，統一回歸 client-side 工具模式。

## 受影響的範例

- `Agent_Step25_ToolboxServerSideTools`（`02-agents/AgentSkills/`）— 此範例已廢棄

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.3.0 | 2026-04-24 | 引入 `FoundryToolbox` + `AIProjectClientToolboxExtensions` |
| 1.6.1 | 2026-05-14 | **[Breaking]** 完整移除 server-side tools 支援 |

## 相關概念

- [[tools-ai-function]]
- [[llm-providers]]
