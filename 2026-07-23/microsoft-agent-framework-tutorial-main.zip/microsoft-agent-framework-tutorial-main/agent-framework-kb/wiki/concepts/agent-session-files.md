---
title: AgentSessionFiles — 代理工作階段檔案管理
api_name: AgentSessionFiles
namespace: Azure.AI.Projects
since: 1.6.1
current_version: 1.6.1
updated: 2026-05-25
tags: [files, session, hosted-files, rag, azure-ai-projects]
tutorial_chapters: [ch08, appendix-a]
sources:
  - raw/release-notes/dotnet-1.6.1.md
  - raw/samples/README.md
  - dotnet/samples/04-hosting/FoundryHostedAgents/responses/Hosted-Files/Program.cs
  - dotnet/tests/Foundry.Hosting.IntegrationTests/SessionFilesHostedAgentTests.cs
---

## 概述

`AgentSessionFiles` 是 v1.6.1 引入的 Azure AI Projects SDK 客戶端類別（`Azure.AI.Projects` 套件），與 agent-framework 的 hosted-files 機制整合，支援在代理工作階段中上傳、存取及管理檔案。

> ⚠️ **注意**：`AgentSessionFiles` 來自外部 Azure AI Projects SDK（`Azure.AI.Projects` namespace），**不是** `Microsoft.Agents.AI` 的一部分。codebase-memory-mcp 在 agent-framework 原始碼中查無此類別節點（已於 2026-05-25 確認）。

## 目前 API 簽名

```csharp
// AgentSessionFiles 來自 Azure.AI.Projects SDK（非 Microsoft.Agents.AI）
// 客戶端用來將檔案上傳至 session sandbox

// 上傳檔案到工作階段（sessionStoragePath 指定遠端路徑）
await agentSessionFiles.UploadSessionFileAsync(
    sessionStoragePath: "report.pdf",
    localFilePath: "/path/to/local/report.pdf");

// 代理端（hosted agent）讀取 session 檔案（via AIFunction 工具）
// （在 Hosted-Files 範例中）
[Description("List the names of files uploaded into the current session sandbox by the user " +
             "(e.g., via AgentSessionFiles.UploadSessionFileAsync).")]
string ListSessionFiles() => SafeListNames(sessionRoot);

[Description("Read the full text contents of a file uploaded into the current session by name.")]
string ReadSessionFile(string fileName) => SafeRead(sessionRoot, fileName, scope: "session files");
```

## 使用場景

| 場景 | 說明 |
|------|------|
| 文件 RAG | 上傳使用者文件，讓代理在對話中檢索內容 |
| 程式碼審查 | 上傳原始碼檔案，代理進行分析與建議 |
| 資料處理 | 上傳 CSV/Excel，代理執行資料分析工具 |

## 與 File Search 的差異

| 特性 | `AgentSessionFiles` | File Search（Foundry） |
|------|--------------------|-----------------------|
| 範圍 | 工作階段（session）內 | 持久化索引（跨對話） |
| 上傳方式 | 即時上傳 | 預建索引 |
| 適合場景 | 動態文件處理 | 大規模知識庫 RAG |

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.6.1 | 2026-05-14 | 首次引入 `AgentSessionFiles`；配套 hosted-files 整合測試範例 |

## 教學章節對應

- 第 08 章：RAG Search — `## v1.6.1 新增：AgentSessionFiles` 小節（L395），含與 HostedFileSearchTool 的比較
- 附錄 A（appendix-a）：v1.6.1 Breaking Changes 說明

## 相關概念

- [[agent-session]]
- [[tools-ai-function]]
- [[llm-providers]]
