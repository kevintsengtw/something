---
generated: 2026-07-05
indexed_commit: 7ca73c0645ad057c986cc7072d4a2d9e3f1cc6f3
indexed_tag: dotnet-1.13.0
baseline: wiki/concepts/ (41 條目, v1.13.0) vs tutorial/ (30 章 + 9 附錄)
---

# 偏移報告

> 本輪為 dotnet-1.12.0 + 1.13.0 連續同步（baseline 1.11.1）。事實層以 codebase-memory-mcp @ `7ca73c064`（59,042 nodes / 257,614 edges）驗證。

## 摘要

| 等級 | 數量 | 說明 |
|------|------|------|
| 🔴 Breaking | 1 → 0（已修正） | ch29 小結與進階選項範例使用已移除的 `AgentSkillsProviderOptions.DisableCaching`（v1.12.0 #6768 抽離為 `CachingAgentSkillsSource`） |
| 🟡 Outdated | 2 → 0（已修正） | appendix-a 版本號（1.11.1 → 1.13.0）、ch01 時間軸缺 v1.12.0/v1.13.0 |
| 🟢 Enhancement | 1（已納入 ch29） | v1.13.0 技能核可選項（per-tool `Disable*Approval` + `ReadOnlyToolsAutoApprovalRule`/`AllToolsAutoApprovalRule`）、Skills API 移除 `[Experimental]`、`AgentSkillsSourceContext` |

---

## 🔴 Breaking（已修正）

### B-119: ch29 `AgentSkillsProviderOptions.DisableCaching` 已移除（v1.12.0 #6768）

- **影響檔案**：`29-agent-skills.md`（進階選項程式碼範例、小結）
- **現況（修正前）**：教學以 `DisableCaching = true` 示範停用技能快取
- **事實層驗證**：`search_graph name_pattern='.*DisableCaching.*' file_pattern='dotnet/src/.*'` → 0 節點；`get_code_snippet(AgentSkillsProviderOptions)` 確認目前屬性為 `SkillsInstructionPrompt`/`IncludeDetailedErrors`/`DisableLoadSkillApproval`/`DisableReadSkillResourceApproval`/`DisableRunSkillScriptApproval`（無 `DisableCaching`）。快取移至 `Microsoft.Agents.AI.Skills.Decorators.CachingAgentSkillsSource`
- **修正**：移除範例中的 `DisableCaching`、加入 v1.12.0 Breaking 說明；小結改列新選項；補 v1.12.0/v1.13.0 條目

---

## 🟡 Outdated（已修正）

### O-121: appendix-a 版本號落後

- **影響檔案**：`appendix-a-nuget-packages.md`
- **修正**：目前版本 1.11.1 → 1.13.0；`.csproj` → 1.13.0；新增 v1.12.0 + v1.13.0 變更段落；相容性總結延伸至 v1.13.0

### O-122: ch01 時間軸缺新版本

- **影響檔案**：`01-what-is-agent-framework.md`
- **修正**：新增 v1.12.0（2026-07-02）、v1.13.0（2026-07-03）兩列；「目前最新版」標記移至 v1.13.0

---

## 🟢 Enhancement（已納入 ch29）

### E-123: v1.13.0 細緻技能核可 + Skills API 穩定化

- **來源**：#6843（核可選項 + 自動核可規則）、#6861（移除 `[Experimental]`）、#6797/#6827/#6838（`AgentSkillsSourceContext` + source `IDisposable` + public）
- **處置**：ch29 新增「細緻核可控制（v1.13.0）」小節（per-tool `Disable*Approval`、`ReadOnlyToolsAutoApprovalRule`/`AllToolsAutoApprovalRule`、`EnableNonApprovalRequiredFunctionBypassing`）+ Skills API 穩定化說明

---

## 教學未示範、無偏移的上游變更（記錄備查）

| 變更 | PR | 所在子系統 | 判定 |
|------|-----|-----------|------|
| 檔案編輯工具 + FileAccess/FileMemory store API（Breaking） | #6807 | Harness FileAccess（`[Experimental]`） | 教學未示範 |
| OpenAI Hosting OptionsMapping 預設不透傳 options（Breaking） | #6855 | Hosting 層內部映射 | ch17 用戶端建構不受影響 |
| Foundry.Hosting MAAI001 旗標 / AgentServer 2.0.0（Breaking） | #6743/#6800 | Foundry.Hosting | 教學未示範 |
| BackgroundTaskCompletionLoopEvaluator | #6736 | Harness.Loop | 非 ch28 Evaluation 框架 |

---

## 驗證結論

- 🔴 Breaking：**0**（ch29 已不再使用被移除的 `DisableCaching`；removed API 僅存在於破壞性變更說明文字）
- 🟡 Outdated：**0**
- 教學核心 API（`AIAgent`/`AgentSession`/`AIFunctionFactory`/`WorkflowBuilder` 等）在 v1.0.0 ~ v1.13.0 無破壞性變更
