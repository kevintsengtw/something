---
generated: 2026-07-23
indexed_commit: 2d34deeb8269ebaa2c27332e1bbf80726fa48b32
indexed_tag: dotnet-1.15.0
baseline: wiki/concepts/ (42 條目, v1.15.0) vs tutorial/ (30 章 + 9 附錄)
---

# 偏移報告

> 本輪從 dotnet-1.13.0 連續同步至 dotnet-1.15.0。結構事實以 codebase-memory-mcp 專案 `Users-tsengweihua-Documents-agent-framework-tutorial-agent-framework` @ `2d34deeb826`（61,044 nodes / 265,384 edges）驗證。

## 摘要

| 等級 | 數量 | 說明 |
|------|------|------|
| 🔴 Breaking | 4 → 0（已修正） | AG-UI server API、Message injection async、`ToolAutoApprovalRuleContext`、approval bypass opt-out 語意 |
| 🟡 Outdated | 2 → 0（已修正） | .NET / Python 版本基線與 stable API 狀態 |
| 🟢 Enhancement | 1（已納入 ch11） | v1.15.0 app-owned OpenAI Responses protocol helpers |

---

## 🔴 Breaking（已修正）

### B-124: AG-UI server package 與 endpoint API 重新命名（v1.14.0）

- **影響檔案**：`11-aspnetcore-webapi.md`、`15-structured-output.md`、`16-human-in-the-loop.md`、`24-agui-protocol-deep-dive.md`、`appendix-f-sdk-samples-agents.md`、`appendix-i-sdk-samples-end-to-end.md`
- **事實層驗證**：舊名稱在目前圖譜為 0 節點；新 API 位於 `Microsoft.Agents.AI.Hosting.AGUI.AspNetCore`。具名代理 overload 為 `(endpoints, agentName, pattern)`，直接代理 overload 為 `(endpoints, pattern, aiAgent)`。
- **修正**：改用 `AddAGUIServer()` / `MapAGUIServer()`；具名代理範例改為 `app.MapAGUIServer("ChatAgent", "/chat/agent")`。

### B-125: `MessageInjectingChatClient` 佇列 API 改為 async（v1.14.0）

- **影響檔案**：`06-middleware-and-context.md`
- **事實層驗證**：目前 API 為 `EnqueueMessagesAsync(AgentSession, IEnumerable<ChatMessage>, CancellationToken = default)`；舊同步方法在圖譜為 0 節點。
- **修正**：null check 後 `await injector.EnqueueMessagesAsync(...)`，並更新 API 表與 stable 狀態。

### B-126: 自動核可規則改用 `ToolAutoApprovalRuleContext`（v1.14.0）

- **影響檔案**：`16-human-in-the-loop.md`
- **事實層驗證**：規則輸入已改為 `ToolAutoApprovalRuleContext`，函式呼叫位於 `context.FunctionCallContent`。
- **修正**：lambda 改讀取 `context.FunctionCallContent.Name`，並標示 `ToolApprovalAgent` 自 v1.14.0 起轉 stable。

### B-127: approval bypass API 重新命名並改為預設啟用（v1.14.0）

- **影響檔案**：`16-human-in-the-loop.md`、`29-agent-skills.md`、`appendix-a-nuget-packages.md`
- **事實層驗證**：舊名稱在目前圖譜為 0 節點；目前 API 為 `UseApprovalNotRequiredFunctionBypassing`，由 `ChatClientAgentOptions.DisableApprovalNotRequiredFunctionBypassing` 選擇停用。
- **修正**：現行指引改用新名稱與 opt-out 語意；附錄歷史表保留舊名並清楚標示 v1.14.0 更名。

---

## 🟡 Outdated（已修正）

### O-128: 教學版本基線更新至 v1.15.0

- **影響檔案**：`README.md`、`01-what-is-agent-framework.md`、`appendix-a-nuget-packages.md`
- **修正**：.NET 目前版本改為 v1.15.0（2026-07-22）、Python 改為 v1.12.0（2026-07-21）；加入 v1.14.0 / v1.15.0 時間軸、套件與相容性摘要。

### O-129: v1.14.0 stable API 狀態已反映

- **影響檔案**：`06-middleware-and-context.md`、`16-human-in-the-loop.md`、`appendix-a-nuget-packages.md`
- **修正**：`MessageInjectingChatClient` 與 `ToolApprovalAgent` 現行段落改為 stable；歷史版本表保留當時 experimental 狀態並補上 v1.14.0 轉換說明。

---

## 🟢 Enhancement（已納入）

### E-130: OpenAI Responses hosting protocol helpers（v1.15.0）

- **處置**：`11-aspnetcore-webapi.md` 新增 app-owned hosting 選項說明，涵蓋 `OpenAIResponses` / `OpenAIResponsesRunRequest`、應用程式自管 route / authentication / authorization / storage，以及不可直接信任外部 conversation/session id 的安全邊界。

---

## 教學未示範、無直接偏移的上游變更（記錄備查）

| 變更 | 版本 | 判定 |
|------|------|------|
| File access 改為透過 `FileAccessStore` 明確 opt-in | v1.14.0 | 教學未示範 Harness FileAccess store |
| `AgentSessionStore.DeleteSessionAsync` 成為必要抽象方法 | v1.15.0 | 教學未實作自訂 `AgentSessionStore` |
| `HostedWorkflowState` / `HostedWorkflowRunResult` | v1.15.0 | 新增 workflow hosting surface，既有 workflow 教學不受影響 |

## 驗證結論

- 🔴 Breaking：**0**（舊 API 僅保留於明確標示的歷史變更說明）
- 🟡 Outdated：**0**
- 🟢 Enhancement：**已納入**
- `python3 scripts/validate_workspace.py`：**1001 checks，0 errors，0 warnings**
