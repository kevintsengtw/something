---
updated: 2026-07-23
---

# API 變更日誌

---

## v1.15.0（2026-07-22）

> 性質：**Hosting 功能 + Breaking 釋出**。官方 breaking 集中於 OpenAI Responses hosting 與自訂 `AgentSessionStore` 實作者，目前正式教學未示範。Tag commit `2d34deeb8`；索引規模 61,044 nodes / 265,384 edges。

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| `OpenAIResponses`／`OpenAIResponsesRunRequest`（PR #7000） | [[openai-responses-hosting]], [[aspnet-core-hosting]] | app-owned routing 的 request/response protocol helpers；應用程式自行掌控 route、authentication、authorization 與 storage |
| `HostedWorkflowState`／`HostedWorkflowRunResult`（PR #7000） | [[openai-responses-hosting]], [[workflows]] | checkpoint-based run-or-resume state，含 streaming API |
| **[Breaking]** `AgentSessionStore.DeleteSessionAsync`（PR #7000） | [[openai-responses-hosting]] | abstract method；自訂 store 實作者必須補實作，且 `GetSessionAsync` 每次需回傳獨立 session instance |

---

## v1.14.0（2026-07-21）

> 性質：**穩定化 + 多項 Breaking 釋出**。四組已確認直接影響教學：AG-UI server API、message injection async、tool auto-approval context、approval bypassing naming。

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| **[Breaking]** AG-UI package split；`AddAGUI`／`MapAGUI` → `AddAGUIServer`／`MapAGUIServer` | [[ag-ui-protocol]], [[aspnet-core-hosting]], [[nuget-packages]] | 舊 `Microsoft.Agents.AI.AGUI` 移至外部 `AGUI.*` packages；伺服端 hosting 留在本 repo |
| **[Breaking]** `EnqueueMessages`／`GetPendingMessages` → async | [[chat-message-injector]] | 改為 `EnqueueMessagesAsync`／`GetPendingMessagesAsync`，加入 `CancellationToken` |
| **[Breaking]** `AutoApprovalRules` 改收 `ToolAutoApprovalRuleContext` | [[human-in-the-loop]] | tool call 位於 `context.FunctionCallContent`；另提供 agent/session/request/options context |
| **[Breaking]** approval bypassing API 改名 + response binding | [[human-in-the-loop]], [[agent-skills]] | `ApprovalNotRequired*` 命名取代 `NonApprovalRequired*`；新增 `UseApprovalResponseBinding` |
| **[Breaking]** Harness FileAccess 改 opt-in | [[long-running-operations]] | 只有設定 `HarnessAgentOptions.FileAccessStore` 才加入 provider |
| API 穩定化 | [[long-running-operations]], [[human-in-the-loop]], [[chat-message-injector]] | `HarnessAgent`、`FileMemoryProvider`、`ToolApprovalAgent`、message injection、todo/mode providers 移除 class-level `[Experimental]` |

---

## v1.13.0（2026-07-03）

> 性質：**功能 + 穩定化釋出**。對教學**無新增破壞性影響**。兩項官方 Breaking（FileAccess/FileMemory 檔案編輯工具 #6807 於 Harness `[Experimental]` 子系統、OpenAI Hosting OptionsMapping #6855 於 hosting 層）教學皆未示範。Tag commit `7ca73c064`。索引規模 59,042 nodes / 257,614 edges。

**分類：API 狀態變更（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| Skills API 移除 `[Experimental]`（PR #6861） | [[agent-skills]] | `AgentSkillsProvider`/`AgentSkillsProviderBuilder`/`AgentSkill` 等正式轉為穩定 API |
| skills source 類別改為 public（PR #6838） | [[agent-skills]] | `AgentInMemorySkillsSource`/`AggregatingAgentSkillsSource`/`FilteringAgentSkillsSource`/`DeduplicatingAgentSkillsSource`/`CachingAgentSkillsSource` |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| 技能核可選項 + 自動核可規則（PR #6843） | [[agent-skills]] | `DisableLoadSkillApproval`/`DisableReadSkillResourceApproval`/`DisableRunSkillScriptApproval` + `AgentSkillsProvider.ReadOnlyToolsAutoApprovalRule`/`AllToolsAutoApprovalRule`。🟢 ch29 增強 |
| `AgentSkillsSource.GetSkillsAsync` 新增 `AgentSkillsSourceContext` 參數（PR #6797） | [[agent-skills]] | source 可依 `AIAgent`/`AgentSession` 回傳不同技能；source 同時改 `IDisposable`（#6827）。僅影響自訂 source |
| Foundry Hosting per-user session isolation + Responses v2 fast-fail（PR #6832） | [[hosted-session-context]] | ADR 0026 實作方向；hosting 子系統 |

**分類：Breaking（.NET，教學未示範）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| 檔案編輯工具 + FileAccess/FileMemory store API 對齊（PR #6807） | （Harness FileAccess，無對應教學條目） | `[Experimental]` 子系統 |
| OpenAI Hosting OptionsMapping 預設不透傳 options（PR #6855） | （hosting，無對應教學條目） | 內部映射；ch17 用戶端建構不受影響 |

**分類：相依（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| Azure.AI.Projects | → 2.1.0-beta.4 | #6795 |

---

## v1.12.0（2026-07-02）

> 性質：**功能 + Breaking 釋出**。一項 Breaking 影響 ch29 敘述（`DisableCaching` 移除）。Tag commit `e7c7f74`。

**分類：Breaking（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| 技能快取抽離為 `CachingAgentSkillsSource`，移除 `AgentSkillsProviderOptions.DisableCaching`（PR #6768） | [[agent-skills]] | decorator 型別（`Microsoft.Agents.AI.Skills.Decorators`）。**🔴 影響 ch29 小結** |
| Foundry.Hosting 實驗性旗標對齊 MAAI001（PR #6743） | （hosting，無對應教學條目） | 診斷 ID 對齊 |
| Azure.AI.AgentServer 升 2.0.0 協定 + Foundry.Hosting 遷移（PR #6800） | （hosting，無對應教學條目） | 相依協定升級 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| `BackgroundTaskCompletionLoopEvaluator`（PR #6736） | （Harness Loop，無對應教學條目） | 背景代理迴圈完成評估器（非 ch28 Evaluation 框架） |
| skill body resource/script 加 `description` 屬性（PR #6759） | [[agent-skills]] | 技能定義敘述增強 |

**分類：相依（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| Azure.AI.AgentServer | → 2.0.0 | #6800 |

---

## v1.13.0 補充（已落地）

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| 新增 `HostedSessionContext`：Foundry 託管代理的每用戶 Session 隔離 | [[hosted-session-context]] | ADR 0026 Accepted（2026-05-07）；`GetHostedContext()` 供 AIContextProvider 讀取；`SetHostedContext()` 為 internal；Session 恢復時身份不符回傳 403 |
| 新增 `HostedSessionIsolationKeyProvider` 抽象類別 | [[hosted-session-context]] | 可替換 DI 工廠；`DevTemporaryLocalSessionIsolationKeyProvider` 供本機開發使用 |

---

## v1.11.1（2026-06-26）

> 性質：**patch 修補釋出，含一項影響教學的 Agent Skills 安全性 Breaking**。Tag commit `d9ec5eaab`（2026-06-25），release 發佈日 2026-06-26。索引規模 58,178 nodes / 256,312 edges。

**分類：Breaking（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| 所有 `AgentSkillsProvider` 工具預設皆需核可（PR #6729） | [[agent-skills]] | 移除 `AgentSkillsProviderOptions.ScriptApproval` 與 `AgentSkillsProviderBuilder.UseScriptApproval(bool)`；`load_skill`/`read_skill_resource`/`run_skill_script` 一律以 `ApprovalRequiredAIFunction` 包裝。**🔴 影響 ch29** |
| 移除 `{resource_instructions}`/`{script_instructions}` 佔位符（PR #6706） | [[agent-skills]] | `SkillsInstructionPrompt` 範本現只需 `{skills}`；資源/腳本清單改由 `available_resources`/`available_scripts` 區塊輸出。**🔴 影響 ch29** |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| 新增 `DeclarativeWorkflowJsonOptions`（PR #6745） | [[declarative-workflow]] | AOT-safe declarative workflow checkpoint 序列化選項 |
| 新增 `IncludeDetailedErrors` 選項（PR #6680） | [[agent-skills]] | `AgentSkillsProviderOptions.IncludeDetailedErrors`：腳本失敗時是否把例外細節回傳給模型（預設 false） |
| `FoundryAITool.CreateMcpTool` 新增 `projectConnectionId` 多載（PR #6703） | [[mcp-integration]] | .NET Foundry |
| `AgentMcpSkillsSource` 支援 archive 型技能（PR #6631） | [[agent-skills]], [[mcp-integration]] | 新增 `AgentMcpSkillsSourceOptions` + `Skills/Loaders/*`；含 decompression-bomb 防護 |

**分類：Bug 修復（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| hosted agent 工具呼叫後崩潰修復（PR #6231 / #6714） | [[a2a-protocol]] | `FileSystemAgentSessionStore` 改 root 於 `$HOME` |
| 套件版本升級後恢復 checkpoint 修復（PR #6670） | [[declarative-workflow]] | — |
| `SearchDirectoriesForSkills` 找到 `SKILL.md` 後停止遞迴（PR #6686） | [[agent-skills]] | 內部探索行為修復 |
| MCP metadata 與工具名稱處理修復（PR #6656） | [[mcp-integration]] | — |

**分類：相依（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| .NET SDK | → 10.0.301 | #6730 |

---

## v1.11.0（2026-06-24）

> 性質：**維護 + 增強釋出**。官方標為 Breaking 的三項（FileAccessProvider 工具核可、FileAccess 工具對齊 Python、SessionConfig.Streaming 複製修復）經 codebase-memory-mcp 驗證，集中於 Harness 的 `FileAccess` 子系統與內部修復，對教學公開 API **皆無破壞性影響**。
> Tag commit `1109d0bf`（2026-06-23），release 發佈日 2026-06-24。

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| 新增 `Microsoft.Agents.AI.LocalCodeAct` 套件（PR #6105） | [[codeact-integration]], [[nuget-packages]] | `LocalCodeActProvider`/`LocalCodeActProviderOptions`：於本機執行 Python（CodeAct 本機沙盒選項，相對於 Hyperlight） |
| 新增 `LoopAgent`（PR #6384） | [[long-running-operations]] | `Microsoft.Agents.AI.Harness.Loop.LoopAgent`/`LoopAgentOptions`（`[Experimental]`）：評估器驅動的反覆執行迴圈；`MaxIterations`/`FreshContextPerIteration` 等選項 |
| MCP 每次執行可刷新驗證標頭（PR #6624） | [[mcp-integration]] | MCP 連線支援 per-run 可刷新驗證標頭 |
| Sequential Orchestration 傳遞模式（PR #6554） | [[orchestration-builders]] | 可選擇傳遞整段對話或僅前一步輸出 |
| Skill 明確輸出 available_resources/scripts（PR #6672） | [[agent-skills]] | `AgentInlineSkillContentBuilder.BuildAvailableResourcesBlock`/`BuildAvailableScriptsBlock`；撰寫端 API 不變 |

**分類：行為變更（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| `FileAccessProvider` 工具改為需核可 + 自動核可規則（PR #6521） | [[long-running-operations]], [[human-in-the-loop]] | Harness `Microsoft.Agents.AI.Harness.FileAccess`（`[Experimental]`）；同版加入目錄探索 + 遞迴搜尋對齊 Python（PR #6474） |
| A2A session store 預設改為 `NoopAgentSessionStore`（PR #6635） | [[a2a-protocol]] | `Microsoft.Agents.AI.Hosting`：A2A hosting 預設不持久化 session |

**分類：相依套件更新（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| Anthropic.Foundry | 0.5.0 → 0.6.0 | #6057 |
| Azure.AI.Projects | → 2.1.0-beta.3 | #6542 |
| MessagePack | → 3.1.7 | #6497 |

> Microsoft.Extensions.AI（10.6.0）與 ModelContextProtocol（1.2.0）自 1.10.0 起未變。

---

## v1.10.0（2026-06-11）

> 性質：**維護 + 增強釋出**。官方標為 Breaking 的三項（GitHub Copilot SDK v1.0.0 遷移、hosting 修復、ToolApprovalAgent 自動核可規則）經 codebase-memory-mcp 驗證，對教學公開 API **皆無破壞性影響**。

**分類：增強（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| `ToolApprovalAgent` 自動核可規則（PR #6335） | [[human-in-the-loop]] | `ToolApprovalAgentOptions.AutoApprovalRules`（`IEnumerable<Func<FunctionCallContent, ValueTask<bool>>>`）：啟發式自動核可；於 standing rules 之後、提示使用者之前評估；`[Experimental]` |
| 允許儲存自動核可的函式（PR #4950） | [[human-in-the-loop]] | `ChatClientBuilderExtensions.UseNonApprovalRequiredFunctionBypassing`：不需核可的函式呼叫持久化於 session 狀態，只浮現真正需人工核可者；`HarnessAgentOptions.DisableNonApprovalRequiredFunctionBypassing` 可關閉 |
| `HarnessAgent` token compaction 改 opt-in（PR #6409） | [[long-running-operations]], [[orchestration-builders]] | `MaxContextWindowTokens`/`MaxOutputTokens` 改為可選（`int?`）；僅當兩者皆提供且未設自訂 `CompactionStrategy`、`DisableCompaction=false` 時才啟用 in-loop 壓縮 |
| ChatClientAgent ChatOptions 合併加入 Reasoning（PR #5463） | [[chat-options]] | 合併 `ChatOptions` 時支援 `reasoning` 參數（型別來自 Microsoft.Extensions.AI 外部套件） |

**分類：相依套件更新（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| Microsoft.Extensions.AI | → 10.6.0 | #6148 |
| ModelContextProtocol | 1.1.0 → 1.2.0 | #6239 |

**分類：Bug 修復（.NET）**

| 問題 | 影響的概念 | PR |
|------|-----------|-----|
| Magentic 跨團隊共享代理回覆 | [[magentic-orchestration]] | #6222 |
| 重構 skill script schemas XML | [[agent-skills]] | #6343 |
| 保留 AG-UI session 歷史 | [[ag-ui-protocol]] | #5904 |
| 宣告式工作流程單欄值解包 / 保留 foreach record 值 | [[declarative-workflow]] | #6367, #6208 |
| reasoning 被剝除時丟棄 hosted MCP 呼叫 | [[mcp-integration]] | #6210 |
| 遷移 GitHub Copilot SDK 至 v1.0.0（含測試修復） | [[llm-providers]] | #6381, #6424 |

> 維護項：移除失效 Atomic Agents 文件連結（#6442）、更新 logo/品牌（#6378, #6380）。多數 release 變更為相依升級與 Python-only 修復，不影響 .NET 教學公開 API。

---

## v1.9.0（2026-06-03）

**分類：API 狀態變更（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| **移除 .NET Orchestrations 的 `[Experimental]` 標記**（PR #6164） | [[magentic-orchestration]], [[workflows]] | `MagenticWorkflowBuilder` 轉穩定公開 API；`MagenticOrchestrator`/`MagenticManager` 改為 `internal`。Magentic/Handoff/GroupChat 皆轉正式 |
| **`Microsoft.Agents.AI.Workflows.Declarative` 套件轉 stable**（PR #6254） | [[declarative-workflow]] | 安裝不再需要 `--prerelease` |

**分類：增強（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| Workflow Outputs Overhaul：支援 tagging/filtering agent 輸出（PR #6045） | [[workflows]] | `WithOutputFrom`/`WithIntermediateOutputFrom` |
| `GroupChatManager` 語意對齊 Orchestration patterns（PR #6140） | [[workflows]], [[magentic-orchestration]] | — |
| `HarnessAgent` 建構子加入 `ILoggerFactory`/`IServiceProvider`（PR #6273） | — | 皆為可選參數，擴充 DI 整合 |
| 跨工作流程保留並傳遞 `CreatedAt`（PR #3930） | [[workflows]] | — |

**分類：Bug 修復（.NET）**：Foundry Hosting `function_call_output` 缺 id（#6246）、宣告式工作流程 `InvokeMcpTool` 核准路徑（#6177）、AGUI hosting 與 workflows（#6311）。

> 多數 v1.9.0 變更為 Python-only（`McpSkillsSource`、progressive tool exposure、`AgentFileStore`/`FileAccessProvider`、Bedrock structured output、Mistral embedding 等），不影響 .NET 教學。

---

## v1.8.0（2026-05-28）

**分類：Breaking Changes（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| **[Breaking]** 移除 Declarative Workflows 的 code-gen 支援（PR #6095） | [[declarative-workflow]] | 改為純執行期解譯；教學未使用 code-gen，無影響 |
| **[Breaking]** 重構 `AgentFileSkillsSource` 為 depth-based discovery + 述詞過濾（PR #6109） | [[agent-skills]] | `AgentFileSkillsSourceOptions` 改用 `SearchDepth`/`ResourceFilter`/`ScriptFilter`；未自訂 `fileOptions` 的呼叫不受影響 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| MCP-based skills（skill-md 類型，`AgentMcpSkill`/`AgentMcpSkillsSource`，PR #6108） | [[agent-skills]], [[mcp-integration]] | — |
| `ForeachExecutor` 迭代狀態跨 checkpoint 持久化（PR #6051） | [[declarative-workflow]], [[workflows]] | — |
| `ClaimsIdentity`-based agent session scoping（PR #5696） | [[agent-session]] | hosting 場景；教學未涵蓋 |
| Handoff Orchestration 與 Python 對齊（PR #6138） | [[workflows]] | — |
| 移除 FoundryAgent 等的 responses experimental flag（PR #6121） | [[llm-providers]] | — |

---

## v1.7.0（2026-05-26）

**分類：Breaking Changes（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| **[Breaking]** base `AgentSkill` 消費端 API 改為非同步（`GetContentAsync`/`GetResourceAsync(name)`/`GetScriptAsync(name)`，PR #6030） | [[agent-skills]] | 撰寫端 `AgentClassSkill<T>`/`AgentInlineSkill`/`AgentSkillsProvider` 保留；ch29 教學程式碼**不受影響**（修正先前 E-002 預測） |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| MCP 長時間任務支援（MCP client tools，PR #5994） | [[mcp-integration]] | — |
| Magentic Orchestration 範例（PR #5823） | [[magentic-orchestration]] | `dotnet/samples/03-workflows/Orchestration/Magentic` |
| Hosted-AgentSkills（Foundry Skills）範例（PR #6013） | [[agent-skills]] | — |

---

## v1.6.1（2026-05-14）

> 注意：本版本從 v1.5.0 直接跳至 v1.6.1（無 v1.6.0 公開發佈）。

**分類：Breaking Changes（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| **[Breaking]** `OpenTelemetryAgent` 自動包裝 `ChatClient` 為 `OpenTelemetryChatClient` | [[opentelemetry]] | 手動雙重包裝將造成重複儀器化；移除既有手動 `.WithOpenTelemetry()` 呼叫 |
| **[Breaking]** Foundry Toolbox server-side tools 完整移除（`GetToolboxAsync()` 不再可用） | [[foundry-toolbox]], [[tools-ai-function]] | 改用 `AIFunctionFactory.Create()` client-side 工具定義 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | 說明 |
|------|-----------|------|
| 新增 `MessageInjectingChatClient`（sealed class，`[Experimental]`）：函數迴圈期間動態注入訊息 | [[chat-message-injector]] | 透過 `ChatClientAgentOptions.EnableMessageInjection = true` 啟用；適用稽核日誌、動態約束、注意力刷新 |
| 新增 Shell Tool（`LocalShellExecutor`、`DockerShellExecutor`）：允許代理執行本地或 Docker shell 命令 | [[shell-tool]] | 預設啟用 `ApprovalRequiredAIFunction` 安全審批；僅限受控環境 |
| 新增 `AgentSessionFiles` SDK：工作階段檔案管理 | [[agent-session-files]] | 支援上傳文件給代理即時處理 |
| A2A 協定新增 `input-request` 內容類型支援（human-in-the-loop） | [[a2a-protocol]], [[human-in-the-loop]] | 多代理工作流程可在執行期暫停等待人工輸入 |
| 新增 Harness Agent 套件 | — | Managed Agent 測試與封裝工具鏈 |
| Hyperlight 加入 release solution filter | [[codeact-integration]] | 改善建置整合 |

**分類：改進（.NET）**

| 變更 | 影響的概念 |
|------|-----------|
| FoundryAgent 嚴格 URL 路由處理修正 | [[llm-providers]] |
| `ClientHeadersScope` 使用 `AsyncLocal` 還原機制簡化 | — |
| DevUI HTTP 介面新增可配置存取控制選項 | [[opentelemetry]] |
| Anthropic Extensions AI 版本對齊更新 | [[llm-providers]] |

**分類：Bug 修復（.NET）**

| 變更 | 影響的概念 |
|------|-----------|
| 修正 handoff `FunctionResult` 無法正確傳遞至代理 | [[workflows]] |
| 修正 `OpenAIResponsesAgentClient` endpoint path 錯誤 | [[llm-providers]] |
| 防止 handoff 過程中訊息 role 被意外修改 | [[a2a-protocol]], [[workflows]] |

**分類：Breaking Changes（Python 僅）**

| 變更 | 說明 |
|------|------|
| DevUI 存取控制與 CORS 政策收緊 | 預設不再允許跨來源請求 |
| File skill 資料夾探索對齊 agentskills.io 規範 | 影響 file-based skills 目錄結構 |

---

## v1.5.0（2026-05-08）

**分類：實驗性新功能（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| **[Experimental]** Magentic Orchestration：`MagenticOrchestrator`、`MagenticManager`、`MagenticProgressLedger`、`MagenticTaskContext`、`MagenticWorkflowBuilder`（命名空間：`Microsoft.Agents.AI.Workflows.Specialized.Magentic`） | [[magentic-orchestration]] | #5595, #5704 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| AG-UI 新增推理事件（Reasoning Events）串流支援 | [[ag-ui-protocol]] | #4953 |
| 訊息過濾：排除不可攜帶的內容類型（non-portable content types） | [[agent-response]] | #5410 |
| `WebBrowsingTool` 新增 allow listing（限制可瀏覽網域） | [[tools-ai-function]] | #5605 |
| Todo 多執行緒支援與注入訊息列表 | — | #5655 |

**分類：Bug 修復（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| **[Bug Fix]** `SKILL.md` frontmatter YAML block scalar（`\|` / `>`）解析修正 | [[agent-skills]] | #5610 |
| MultiPartyConversation JSON 序列化修正 | — | #5653 |
| QuestionExecutor GotoAction 重新進入無限迴圈修正 | — | #5635 |
| 序列號生成執行緒安全修正（防止重複/亂序 ID） | — | #5320 |
| `function_call_output.output` 改為 JSON 字串格式 | — | #5705 |
| Workflows 缺少 Shared 來源檔案修正 | [[workflows]] | #5656 |

**分類：相依更新（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| MEAI 10.5.1 | 新增 Foundry 每次呼叫 x-client 標頭 | #5652 |
| GitHub Copilot SDK 1.0.0-beta.2 | 版本更新 | #5699 |

**本版本無 Breaking Changes。**

---

## v1.4.0（2026-05-05）

**分類：Breaking Changes（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| **[Breaking]** file-based skill scripts 引數型別改為 `string[]`（原為單一字串） | [[agent-skills]] | #5475 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| 新套件 `Microsoft.Agents.AI.Hyperlight`：CodeAct .NET 整合 GA | [[codeact-integration]], [[nuget-packages]] | #5329 |
| 宣告式工作流程新增 `HttpRequestAction` 步驟型別 | [[declarative-workflow]] | #5474 |
| Durable Workflow HTTP trigger endpoint 支援回傳執行結果（不再只回傳 202） | [[durable-agents]] | #5321 |
| Hosted-agent 對外 HTTP 請求自動附加 User-Agent 標頭 | [[aspnet-core-hosting]] | #5453 |
| Harness 功能合併進主線（agent 測試輔助機制） | [[testing-strategy]] | #5310 |
| Hosting 層更新：整合 HttpRequestAction 與回傳結果機制 | [[declarative-workflow]] | #5589 |

**分類：相依更新（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| OpenTelemetry packages | 升級至 1.15.3 | #5478 |

**分類：ADR 新增**

| ADR | 概念 | 狀態 |
|-----|------|------|
| 0024-prompt-injection-defense | [[prompt-injection-defense]] — FIDES 確定性 Prompt Injection 防禦 | Proposed |

---

## v1.3.0（2026-04-24）

**分類：Breaking Changes（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| **[Breaking]** A2A SDK 0.3.4-preview → 1.0.0-preview2：`EndpointRouteBuilderExtensions` 移除（→ `A2AEndpointRouteBuilderExtensions`）、`AIAgentExtensions` 移除（→ `A2AServerServiceCollectionExtensions`）| [[a2a-protocol]], [[aspnet-core-hosting]] | #5423 |
| **[Breaking]** Azure.AI.AgentServer.Responses SDK beta.3→beta.4：`FunctionToolCallOutputResource` → `OutputItemFunctionToolCallOutput`，`AzureAIAgentServerResponsesModelFactory` 改為 internal | [[llm-providers]] | #5450 |

**分類：新功能（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| A2A SSE stream reconnection（continuation token 機制） | [[a2a-protocol]] | #5423 |
| `A2AAgentHandler` 新增 streaming 支援（`RunStreamingAsync` 路徑） | [[a2a-protocol]], [[run-async]] | #5427 |
| Server-side Foundry Toolbox（`FoundryToolbox` + `AIProjectClientToolboxExtensions`） | [[llm-providers]], [[tools-ai-function]] | #5450 |
| 新增型別：`A2AAgentHandler`, `A2AServerRegistrationOptions`, `A2AServerServiceCollectionExtensions`, `A2AEndpointRouteBuilderExtensions` | [[a2a-protocol]] | #5423 |
| A2A samples 重新分類：`04-hosting/A2A/` → `02-agents/A2A/` | [[a2a-protocol]] | #5423 |

**分類：Bug 修復（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| 修正 `StreamingRunEventStream.RunLoopAsync` 中 RunStatus off-thread race（`GetStatusAsync` 在 halt 後誤回傳 Running） | [[durable-agents]], [[long-running-operations]] | #5412 |

**分類：相依更新（.NET）**

| 套件 | 變更 | PR |
|------|------|----|
| `Microsoft.ML.Tokenizers` | 新增依賴 ≥ 2.0.0 | — |
| `Microsoft.Agents.AI.Hosting.Aspire` | 改為 preview 套件 | #5444 |

---

## v1.2.0（2026-04-21）

**分類：重大新功能（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Foundry Hosted Agents Support（13 PR 合併） | [[llm-providers]], [[ai-agent]] | #5312 |
| Foundry Evals Integration for .NET（已 GA） | [[agent-evaluation]] | #4914, #5269 |
| Handoff Orchestration 重構 + HITL 支援 | [[workflows]], [[human-in-the-loop]] | #5174 |
| DevUI Aspire Integration | [[opentelemetry]] | #3771 |
| AGUI service 支援 session storage | [[ag-ui-protocol]], [[agent-session]] | #5193 |

**分類：Bug 修復（.NET）**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Duplicate CallIds 導致 Handoff Message Filtering 失敗 | [[workflows]] | #5359 |
| 修正 Declarative resume edge predicates（checkpoint 還原後）| [[declarative-workflow]] | #5323 |
| Declarative workflows — 代理無回應時的優雅處理 | [[declarative-workflow]] | #5376 |
| Handoff-hosted Agents session 支援 | [[llm-providers]], [[agent-session]] | #5280 |
| Foundry Agents 無 description 時 Handoff 崩潰 | [[llm-providers]] | #5311 |
| In-process workflow checkpoint-restore race condition | [[durable-agents]] | #5134 |
| A2A metadata 使用 namespaced key 傳播 | [[a2a-protocol]] | #5256 |

**分類：相依更新（.NET）**

| 套件 | 新版 | PR |
|------|------|----|
| Microsoft.Extensions.AI | 10.5.0 | #5269 |
| OpenAI | 2.10.0 | #5269 |
| Anthropic SDK | 12.13.0 | #5279 |
| Anthropic.Foundry | 0.5.0 | #5279 |

**分類：Python 重點（僅供參考）**

| 變更 | PR |
|------|-----|
| Foundry hosted agent V2 | #5379 |
| Foundry Toolboxes 支援 | #5346 |
| GeminiChatClient（Gemini API + Vertex AI）| #5258, #4847 |
| finish_reason 支援 AgentResponse/AgentResponseUpdate | #5211 |
| Hyperlight CodeAct 套件與文件 | #5185 |

---

---

## python-1.0.1（2026-04-09）

**分類：Breaking Changes**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| `FileCheckpointStorage` 預設使用受限 unpickler（需透過 `allowed_checkpoint_types` 明確允許自訂型別） | [[durable-agents]] | #4941 |
| Handoff workflow 上下文管理修復（breaking） | [[workflows]] | #5136 |

**分類：新增**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Cosmos DB NoSQL checkpoint storage（`agent-framework-azure-cosmos`） | [[durable-agents]] | #4916 |

**分類：Bug 修復**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| `response_format` 背景輪詢空文字崩潰 | [[structured-output]] | #5146 |
| `FoundryAgent` 傳入 `agent_reference` 時多餘的 tools 剝除 | [[llm-providers]] | #5101 |

---

> 以版本為主軸，記錄 Microsoft Agent Framework .NET SDK 的 API 層面變更。
> 供 `/drift-check` 與 `/compile` 交叉參考。

---

## v1.1.0（2026-04-10）

**分類：新功能**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| 新增 `AgentClassSkill<T>` 泛型基底類別（⚠️ 非 `AgentClassSkill`） | [[agent-skills]] | #5027 |
| 新增 `AgentInlineSkill`（Code-Defined Skills，GA） | [[agent-skills]] | — |
| 新增 `AgentSkillsProviderBuilder`（混合多來源） | [[agent-skills]] | — |
| 新增 `AgentFileSkillsSourceOptions`（自訂資源/腳本探索規則） | [[agent-skills]] | — |
| 新增 `AgentSkillsProviderOptions`（ScriptApproval / DisableCaching） | [[agent-skills]] | — |
| 反射式資源/腳本探索（`[AgentSkillResource]` / `[AgentSkillScript]` 屬性） | [[agent-skills]] | #5183 |
| 技能函式支援自訂型別 | [[agent-skills]] | #5152 |
| 檔案技能資料夾探索對齊 | [[agent-skills]] | #5078 |
| 目錄術語標準化 | [[agent-skills]] | #5205 |
| ADR 0017 Accepted：`AgentWithMetadata` 外部包裝器模式 | [[agent-additional-properties]] | — |

**分類：Bug 修復**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Message Delivery Callback | [[workflows]] | #5081 |
| Handoff 上下文修復 | [[workflows]] | #5136 |
| Checkpoint 修復 | [[durable-agents]] | #5085 |
| Chat Completion 空 content 處理 | [[agent-response]] | #5139 |
| Session 壓縮邏輯修復 | [[durable-agents]] | #5094 |
| Chat history compaction 重複修復 | [[chat-history-persistence]] | #5149 |
| Entity key 驗證修復 | [[durable-agents]] | #5179 |

**分類：相依更新**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Anthropic SDK 12.8.0 → 12.11.0 | [[llm-providers]] | #5055 |
| 新增 gpt-5.4-mini 模型對應 | [[llm-providers]] | — |

**分類：標準化**

| 變更 | 影響的概念 | PR |
|------|-----------|-----|
| Entity key 格式統一 | [[durable-agents]] | #5088 |
| FoundryAgent session ID 統一 | [[durable-agents]] | #5120 |
| FoundryAgent.CreateSessionAsync(conversationId) 新多載 | [[agent-session]] | #5144 |

---

## v1.0.0 GA（2026-04-02）

**分類：正式釋出**

| 變更 | 影響的概念 |
|------|-----------|
| 首個穩定版釋出 | 所有概念 |
| `AIAgent` 正式 API 定案 | [[ai-agent]], [[run-async]] |
| `AgentSession`（原 `AgentThread`）正式命名 | [[agent-session]], [[provider-session-state]] |
| `AgentResponse` / `AgentResponseUpdate` 定案 | [[agent-response]] |
| `AgentMiddlewareContext` / `AgentMiddlewareDelegate` 定案 | [[middleware-pipeline]] |
| AG-UI Protocol 支援（ADR 0010） | [[ag-ui-protocol]], [[aspnet-core-hosting]] |
| Chat History Persistence 一致性（ADR 0022） | [[chat-history-persistence]] |
| Feature Collections（ADR 0014） | [[feature-collections]] |
| AgentSession Serialization — StateBag 設計（ADR 0018） | [[agent-session]] |

---

## v1.0.0-preview 系列（2025-11 ~ 2026-03）

**分類：預覽里程碑**

| 變更 | 影響的概念 |
|------|-----------|
| 初始 `AIAgent` 抽象設計 | [[ai-agent]] |
| `AgentThread` → `AgentSession` 重新命名（ADR 0018） | [[agent-session]] |
| 基於裝飾器模式的 Middleware 管線（ADR 0007） | [[middleware-pipeline]] |
| Unified Tools Abstraction 討論啟動（ADR 0002） | [[tools-ai-function]] |
| A2A / MCP 協定初始支援 | [[a2a-protocol]], [[mcp-integration]] |

---

## 待追蹤（Proposed ADRs，尚未釋出）

| ADR | 概念 | 狀態 |
|-----|------|------|
| 0002 | [[tools-ai-function]] — Unified Abstraction | Proposed |
| 0007 | [[middleware-pipeline]] — Filtering Middleware | Proposed |
| 0021 | [[agent-skills]] — Aggregating / Caching / Deduplicating Sources | 仍為 Proposed（v1.1.0 已實作三種 authoring 方式） |
| 0025 | Foundry Toolbox Support (`get_toolbox`) | Python: v1.2.0 已實作；.NET: v1.3.0 已實作，**v1.6.1 已移除**（見 [[foundry-toolbox]]） |
