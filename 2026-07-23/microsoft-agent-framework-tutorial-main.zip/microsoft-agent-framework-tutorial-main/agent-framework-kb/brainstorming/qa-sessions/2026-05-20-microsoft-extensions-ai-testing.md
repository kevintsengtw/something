---
date: 2026-05-20
question: Microsoft.Extensions.AI.Testing 套件的功能、API 與 Agent Framework 整合方式
answered_by: wiki-query + autoresearch:learn
sources:
  - https://learn.microsoft.com/microsoft-365/agents-sdk/unit-testing-agents-dotnet
  - https://learn.microsoft.com/en-us/dotnet/ai/microsoft-extensions-ai
  - https://learn.microsoft.com/en-us/dotnet/ai/ichatclient
  - NuGet.org（搜尋確認套件不存在）
---

## 問題

知識庫與教學文件對於 `Microsoft.Extensions.AI.Testing` 這個測試用套件的內容很少，需要了解其功能、API 與和 Agent Framework 的整合方式。

## 關鍵發現

### `Microsoft.Extensions.AI.Testing` 不存在

經過完整研究（NuGet.org、GitHub dotnet/extensions、Microsoft Learn），**確認此套件不存在**。這是一個常見的混淆點，原因如下：

1. `Microsoft.Extensions.AI` 的官方文件只提到可以「實作 IChatClient 進行測試」，並無獨立測試套件
2. `FakeChatClient` 存在於 dotnet/extensions 的內部測試程式碼（`src/tests/`），但**未公開發佈為 NuGet 套件**
3. 類似名稱的 `Microsoft.Agents.Builder.Testing` 屬於**不同產品**（Microsoft 365 Agents SDK）

### 正確的替代方案

| 方案 | 適用情境 |
|------|---------|
| 自行實作 `IChatClient` | 推薦：完全可控、可記錄呼叫 |
| Moq Mock `IChatClient` | 快速驗證簡單場景 |
| `Microsoft.Extensions.AI.Evaluation` | 品質評估，非單元測試替身 |
| `WebApplicationFactory` + DI 替換 | 整合測試 |

### Microsoft.Agents.Builder.Testing 澄清

此套件屬於 **Microsoft 365 Agents SDK**（處理 Teams/M365 訊息的對話型代理），與 `microsoft/agent-framework`（AI Agent Framework，基於 IChatClient 的 AI 代理）是**完全不同的產品**：

- `AgentTestHost`、`TestAdapter`、`TestFlow`、`SemanticValidator`
- 只適用於 `Microsoft.Agents.Builder` 系列套件

### 正確的 Agent Framework 測試方式

```csharp
// 推薦：自訂 FakeChatClient 實作 IChatClient
public sealed class FakeChatClient : IChatClient
{
    public List<IEnumerable<ChatMessage>> ReceivedMessages { get; } = [];
    // ... 完整實作見 wiki/concepts/testing-strategy.md
}

// 使用方式
var fakeClient = new FakeChatClient("預設回應");
var agent = new ChatClientBuilder(fakeClient)
    .UseFunctionInvocation()
    .Build()
    .AsAIAgent("TestAgent");
```

## 結論

「Microsoft.Extensions.AI.Testing」這個套件不存在。Agent Framework 的正確測試方式是自行實作 `IChatClient` 作為測試替身（或使用 Moq），搭配三層測試架構（工具單元測試、代理行為測試、WebApplicationFactory 整合測試）。

## Wiki 更新

- 更新：`wiki/concepts/testing-strategy.md`（版本標記為 1.6.1，補充完整說明）
