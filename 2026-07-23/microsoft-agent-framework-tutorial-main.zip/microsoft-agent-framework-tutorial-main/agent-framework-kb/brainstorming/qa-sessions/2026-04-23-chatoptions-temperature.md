---
date: 2026-04-23
topic: ChatOptions.Temperature 定義、影響與 Agent Framework 中的使用方式
related_concepts: [chat-options, middleware-pipeline, run-async, structured-output]
promoted_to_wiki: true
---

## 問題 1

`/wiki-query Temperature 相關資訊`

## 回答 1

wiki/concepts/ 中**沒有** Temperature 的專屬條目。  
唯一出現的 "temperature" 是 `agent-skills.md` 中的 `temperatureConverter` 示範技能名稱，與 LLM 參數無關。  
Temperature 屬於 `Microsoft.Extensions.AI.ChatOptions`（MEAI 層），不是 Agent Framework 的專屬 API，因此知識庫中缺少此條目。

## 關鍵發現 1

- wiki 缺少 `chat-options.md` 概念條目，應在下次 `/compile` 補充
- `ChatOptions` 屬於 `Microsoft.Extensions.AI`，是 Agent Framework 使用的底層 MEAI 抽象

---

## 問題 2

確認 `Microsoft.Extensions.AI.ChatOptions.Temperature` 的最新定義

## 回答 2

**來源**：Microsoft Learn 官方文件（已驗證）  
**Package**：`Microsoft.Extensions.AI.Abstractions v10.4.1`  
**Assembly**：`Microsoft.Extensions.AI.Abstractions.dll`

```csharp
// 命名空間：Microsoft.Extensions.AI
public float? Temperature { get; set; }
```

說明：控制模型生成回應的隨機性。數值越低越確定，數值越高越隨機。

**`ChatOptions` 完整屬性（v10.4.1）**：

| 屬性 | 型別 | 說明 |
|------|------|------|
| `Temperature` | `float?` | 隨機性控制 |
| `TopP` | `float?` | Nucleus sampling |
| `TopK` | `int?` | 最高機率 token 數量 |
| `MaxOutputTokens` | `int?` | 最大輸出 token |
| `FrequencyPenalty` | `float?` | 重複懲罰（頻率） |
| `PresencePenalty` | `float?` | 重複懲罰（存在） |
| `Seed` | `long?` | 可重現性種子 |
| `StopSequences` | `IList<string>?` | 停止序列 |
| `ModelId` | `string?` | 覆寫模型 ID |
| `ResponseFormat` | `ChatResponseFormat?` | 回應格式 |
| `Tools` | `IList<AITool>?` | 工具清單 |
| `ToolMode` | `ChatToolMode?` | 工具呼叫模式 |
| `Instructions` | `string?` | 每次請求的額外指令 |
| `Reasoning` | `ChatReasoningOptions?` | 推論選項（CoT） |
| `ConversationId` | `string?` | 對話識別碼 |
| `ContinuationToken` | `object?` | 非同步接續 Token |
| `AllowMultipleToolCalls` | `bool?` | 允許多個工具呼叫 |
| `AllowBackgroundResponses` | `bool?` | 允許背景非同步回應 |
| `AdditionalProperties` | `AdditionalPropertiesDictionary?` | 提供者專屬額外屬性 |

**在 Agent Framework 中設定 Temperature**：
- Temperature 屬於 IChatClient 層（`ChatOptions`），不屬於 AIAgent 層（`AgentRunOptions`）
- Per-run 控制需透過 Chat Middleware 注入：

```csharp
var client = chatClient
    .AsBuilder()
    .Use(async (messages, options, next, ct) =>
    {
        options ??= new ChatOptions();
        options.Temperature = 0.2f;
        return await next(messages, options, ct);
    })
    .Build();
```

## 關鍵發現 2

- `AgentRunOptions` 沒有直接的 `Temperature` 屬性，只能在 `IChatClient` 層設定
- `ChatOptions` 有 `ContinuationToken` 屬性（不是 `RunId`），對應 Long-Running Operations 的接續機制
- `AllowBackgroundResponses` 是 v10.4.1 新增屬性，可能對應 Long-Running 背景執行模式

---

## 問題 3

Temperature 設定為 1.6f，是什麼呢？

## 回答 3

`1.6f` 屬於極高溫區間，遠超實際應用建議範圍。

**機率分布原理**：
```
P(token_i) = exp(logit_i / T) / Σ exp(logit_j / T)
```
T=1.6 使分布趨於平坦，低機率 token 被選中的機會大幅增加。

**各溫度段的建議用途**：

| Temperature | 適用場景 |
|-------------|---------|
| `0.0 – 0.2` | 結構化輸出、程式碼生成、Evaluation |
| `0.3 – 0.5` | 工具呼叫（Tool Use）、事實問答 |
| `0.5 – 0.7` | 一般問答、客服對話 |
| `0.8 – 1.2` | 創意寫作、腦力激盪 |
| `> 1.2` | 實驗性用途，不建議生產使用 |
| `1.6` | **極端值**，生產環境幾乎無合理使用場景 |

**注意**：官方不建議同時調整 Temperature 和 Top-P，交互作用難以預測。

## 關鍵發現 3

- Temperature > 1.2 在生產環境幾乎沒有合理理由，看到 `1.6f` 很可能是測試遺留或設定錯誤
- Evaluation 場景建議設定 `Temperature = 0.0f` 以確保可重現性

---

## 來源

- Microsoft Learn 官方文件：https://learn.microsoft.com/dotnet/api/microsoft.extensions.ai.chatoptions?view=net-10.0-pp
- Microsoft Learn 官方文件：https://learn.microsoft.com/dotnet/api/microsoft.extensions.ai.chatoptions.temperature?view=net-10.0-pp
- wiki/concepts/ 全目錄搜尋（Temperature 無既有條目）
