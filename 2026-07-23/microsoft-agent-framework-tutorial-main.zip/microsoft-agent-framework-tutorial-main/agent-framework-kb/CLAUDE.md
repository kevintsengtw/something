# Agent Framework 知識庫（LLM Wiki）— 補充指引

> **重要**：本檔是工作區根 [`../CLAUDE.md`](../CLAUDE.md) 的**補充指引**，不是主導文件。
> 工具二分原則、指令入口點、版本更新流程等基本規範請見工作區根 CLAUDE.md。
> 設計依據：[`./WORKFLOW-DESIGN-v2.md`](./WORKFLOW-DESIGN-v2.md)

---

## 1. 本目錄角色

| 子目錄 | 用途 | 規則 |
|------|------|------|
| `raw/` | 上游素材（ADR、Release Notes、DevBlog、Samples、Learn） | **唯讀**，不修改原始內容 |
| `raw/facts/` | `/extract-facts` 產出的事實清單 JSON（per-version verified changes） | 由指令自動寫入 |
| `wiki/concepts/` | LLM 編譯的結構化知識 | 由 `/compile` 產生與更新 |
| `wiki/INDEX.md` | 分類索引 + 章節反查表 | 由 `/compile` 維護 |
| `wiki/api-changelog.md` | API 變更時間線 | 由 `/compile` 維護 |
| `wiki/drift-report.md` | 偏移檢查報告 | 由 `/drift-check` 每次完整覆寫 |
| `.understand-anything/` | Understand-Anything 知識圖譜產出 | 由 `/snapshot-knowledge` 維護 |
| `brainstorming/qa-sessions/` | `/wiki-query` 問答記錄 | 由 `/save-qa` 產生，`/compile` 會掃描 |

**指令入口點**：所有 slash commands 都住在 `../.claude/commands/`（工作區根），不在本目錄內。

---

## 2. 語言規範

- 所有 `wiki/` 產出使用**繁體中文**
- 概念條目中的 API 名稱、類別名稱、方法簽名保持英文原名
- frontmatter 欄位名稱使用英文

---

## 3. wiki/concepts/ 條目格式

每個條目必須包含：

```markdown
---
title: <概念名稱（繁體中文）>
api_name: <C# 類別或介面名稱>
namespace: <命名空間>
since: <首次出現版本，如 1.0.0-rc1>
current_version: <目前版本，如 1.6.1>
updated: <最後更新日期 YYYY-MM-DD>
tags: [tag1, tag2]
tutorial_chapters: [ch02, ch04, ch14]
sources:
  - raw/adrs/0018-xxx.md
  - raw/release-notes/dotnet-1.1.0.md
  - raw/facts/dotnet-1.6.1-verified-changes.json
---

## 概述
<1-3 句概念說明>

## 目前 API 簽名
\```csharp
// 目前正式版 API
public class Xxx { ... }
\```

## 變更歷史
| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-04-02 | GA 釋出 |
| 1.1.0 | 2026-04-10 | ... |

## 教學章節對應
- 第 XX 章：<使用情境說明>

## 相關概念
- [[concept-name]]
```

**frontmatter 嚴格規範**：
- `api_name`、`namespace`、`since`、`current_version` **必須來自 `raw/facts/*.json` 的已驗證事實**
- 若該 API 未經 `/extract-facts` 驗證，frontmatter 留空並改用 `<!-- 待驗證 -->` 註解
- LLM 不得在條目敘述中即興宣告 API 簽名或方法存在

---

## 4. drift-check 偵測規則

### 🔴 Breaking（教學範例會編譯失敗）
- tutorial/ 中的 C# 類別名稱在最新 API 中已不存在（codebase-memory-mcp `search_graph` 確認）
- 方法簽名（參數型別、回傳型別）不匹配（`get_code_snippet` 確認）
- using namespace 已變更
- NuGet 套件名稱已改名

### 🟡 Outdated（內容不反映最新實作）
- 描述文字使用舊名稱
- 章節提及「未來製作」但內容已完成
- NuGet 套件版本過時（落後 2+ minor 版本）
- 範例程式碼可運作但不是最佳實踐

### 🟢 Enhancement（可選的新功能補充）
- 上游新增了教學未涵蓋的功能
- 有新的官方範例可參考
- 新模型支援可補充

---

## 5. 工具呼叫慣例（kb 範圍內）

工具二分原則見工作區根 CLAUDE.md。本檔只列 kb 流程中具體的工具呼叫方式：

| 場景 | 工具 | 用途 |
|------|------|------|
| 確認 API 存在 | `mcp__codebase-memory-mcp__search_graph` | 取得節點與基本資訊 |
| 取簽名與位置 | `mcp__codebase-memory-mcp__get_code_snippet` | 取得 namespace、file_path、signatures |
| Cypher 查詢 | `mcp__codebase-memory-mcp__query_graph` | namespace 核對、屬性查詢 |
| 廢棄確認 | `mcp__codebase-memory-mcp__trace_path` direction: inbound | 結果為空 → 廢棄徹底 |
| 取上游使用範例 | `mcp__codebase-memory-mcp__search_code` | 從上游 tests/samples 找實際用法 |
| 取依賴鏈 | `mcp__codebase-memory-mcp__trace_path` direction: outbound | 確認新 API 的依賴結構 |
| wiki 知識圖譜 | `/understand-knowledge agent-framework-kb/wiki --language zh-TW` | UA plugin 原生指令，由 `/snapshot-knowledge` 包裝 |
| 對話探索 | `/understand-chat` | UA plugin 原生指令，直接呼叫 |

---

## 6. 重要禁止事項

- ❌ 不要在 wiki/concepts/ 條目中即興宣告 API 簽名——必須來自 raw/facts/ 或 codebase-memory-mcp
- ❌ 不要呼叫 GitNexus 工具——本專案已決定不導入 GitNexus
- ❌ 不要在 raw/ 目錄修改任何上游素材——它是唯讀基準層
- ❌ 不要在本目錄新增 `.claude/` 子目錄——指令入口點已上移到工作區根
- ❌ 不要在 wiki/ 中製造未經 `/lint` 驗證的交叉引用（`[[xxx]]`）

---

## 7. 參考連結

- 工作區根主導文件：[`../CLAUDE.md`](../CLAUDE.md)
- 工作流設計：[`./WORKFLOW-DESIGN-v2.md`](./WORKFLOW-DESIGN-v2.md)
- 版本更新操作手冊：[`./PLAYBOOK-version-update.md`](./PLAYBOOK-version-update.md)
- 跨機 commit 對齊：[`./UPSTREAM-REF.md`](./UPSTREAM-REF.md)
- 快速操作指南：[`./QuickStart.md`](./QuickStart.md)
