# 上游原始碼對齊記錄

MacBook / 跨機環境下，每台機器需獨立 clone `agent-framework`（不從其他機器複製索引），對齊到此處記錄的 commit，再在 Claude Code 中執行 `mcp__codebase-memory-mcp__index_repository` 重建索引。`agent-framework-kb/` 與 `microsoft-agent-framework-tutorial/` 則可直接從其他機器複製過去。

---

## 目前對齊版本

| 項目 | 值 |
|------|-----|
| **Commit Hash** | `2d34deeb8269ebaa2c27332e1bbf80726fa48b32` |
| **Commit 日期** | 2026-07-23（tag commit `2d34deeb8`） |
| **訊息** | `Reduce workflow credential exposure (#7270)`（dotnet-1.15.0 tag） |
| **知識庫基準版本** | v1.15.0（發佈日 2026-07-22；連續同步 1.14.0→1.15.0） |
| **最後更新** | 2026-07-23 |
| **索引規模** | 61,044 nodes / 265,384 edges |

---

## 切換機器時的對齊指令

```bash
cd agent-framework
git fetch
git checkout dotnet-1.15.0   # = 2d34deeb8269ebaa2c27332e1bbf80726fa48b32

# 重建 codebase-memory-mcp 索引（不從另一台機器搬移，各機獨立重建）
# 在 Claude Code 中執行：
#   mcp__codebase-memory-mcp__index_repository
#     repo_path: "<絕對路徑>/agent-framework"
# project 名稱自動從路徑產生，完成後用 list_projects 確認
```

---

## codebase-memory-mcp 索引同步策略

| 場景 | 動作 |
|------|------|
| 同機 `git pull` 後 | 無需動作。codebase-memory-mcp 的 file watcher 會自動偵測檔案變更並增量更新索引 |
| 跨機初次設定 | 對該機器執行 `index_repository` 重建索引（索引存於 `~/.codebase-memory-mcp/`，**不跨機共享**） |
| 工具版本升級後 | 視情況可選擇重跑 `index_repository`，若 schema 有變化更需要 |
| 索引疑似失準 | 重跑 `index_repository`；不影響 wiki/、tutorial/ 等其他資料 |

**為何索引不 commit**：
- 體積大（agent-framework 索引曾達 70K+ 節點 / 150K+ 邊）
- 路徑為機器絕對路徑，跨機不可移植
- 可隨時從 source 重建，且重建成本低（首次幾分鐘到十幾分鐘）

---

## 歷史記錄

| 日期 | Commit | 說明 |
|------|--------|------|
| 2026-05-24 | `793403f` | 初始建立此記錄，macOS 遷移前的 Windows 基準 |
| 2026-05-25 | `793403f` | 執行完整版本更新流程（sync/compile/drift-check/update-tutorial/lint），確認仍為最新（無新 .NET 版本） |
| 2026-05-26 | `793403f` | 工作流重組為 v2（入口點上移、新增 Pipeline D、保留 codebase-memory-mcp）；本檔對齊新流程描述 |
| 2026-05-26 | `793403f` | ✅ **codebase-memory-mcp macOS 驗證通過（6/7）**：macOS 26.5、Node.js v24.15.0、codebase-memory-mcp v0.6.1；索引 44,650 nodes / 180,686 edges。詳見 [`./raw/facts/codebase-memory-mcp-validation.md`](./raw/facts/codebase-memory-mcp-validation.md) |
| 2026-05-26 | `08541ee` | git pull 成功（修復 index.lock + staged deletions）；4 個新 commit 含 **[Breaking] AgentSkill API async 重構**（PR #6030）；重新索引 44,788 nodes / 181,851 edges |
| 2026-06-06 | `afa7834` | **三版同步 dotnet-1.7.0→1.9.0**：checkout dotnet-1.9.0 tag（清理 LFS dirty tree 後），重新索引 53,875 nodes / 224,834 edges。完整 Pipeline A：extract-facts ×3、compile（magentic-orchestration/agent-skills/declarative-workflow/workflows）、snapshot-knowledge（121 nodes / 328 edges）、drift-check（🔴=0）、update-tutorial（appendix-a + ch01）、lint。**關鍵發現：#6030 等 breaking 經 codebase-memory-mcp 驗證後皆不影響教學程式碼，E-002 為 false positive 正式關閉** |
| 2026-06-14 | `dd29f9aa` | **單版同步 dotnet-1.10.0**（維護 + 增強釋出）：checkout dotnet-1.10.0 tag（working tree clean），重新索引 54,766 nodes / 224,245 edges。完整 Pipeline A：extract-facts ×1、compile（human-in-the-loop/long-running-operations/chat-options/nuget-packages/mcp-integration/magentic-orchestration/agent-skills）、snapshot-knowledge（135 nodes / 364 edges）、drift-check（🔴=0）、update-tutorial（appendix-a + ch01 + ch16 ToolApprovalAgent 自動核可規則）、lint。**官方標 Breaking 三項（Copilot SDK 遷移、hosting 修復、ToolApprovalAgent 自動核可規則）經驗證皆不影響教學程式碼** |
| 2026-06-25 | `1109d0bf` | **單版同步 dotnet-1.11.0**（維護 + 增強釋出；tag commit 2026-06-23、release 發佈日 2026-06-24）：checkout dotnet-1.11.0 tag（working tree clean），重新索引 57,059 nodes / 255,033 edges。完整 Pipeline A：extract-facts ×1、compile（nuget-packages/codeact-integration/long-running-operations/mcp-integration/a2a-protocol/orchestration-builders/agent-skills）、snapshot-knowledge（164 nodes / 389 edges）、drift-check（🔴=0）、update-tutorial（appendix-a + ch01）、lint。**官方標 Breaking 三項（FileAccessProvider 工具核可 #6521、FileAccess 對齊 Python #6474、SessionConfig.Streaming 複製 #6463）集中於 Harness FileAccess 子系統與內部修復，經驗證皆不影響教學程式碼。新增能力：`Microsoft.Agents.AI.LocalCodeAct` 套件、`LoopAgent` Harness 迴圈** |
| 2026-06-28 | `d9ec5eaab` | **單版同步 dotnet-1.11.1**（patch 釋出，**含影響教學的 Breaking**；tag commit 2026-06-25、release 發佈日 2026-06-26）：checkout dotnet-1.11.1 tag（working tree clean），重新索引 58,178 nodes / 256,312 edges。完整 Pipeline A：extract-facts ×1、compile（agent-skills/mcp-integration/declarative-workflow/a2a-protocol）、snapshot-knowledge（171 nodes / 405 edges）、drift-check（🔴=1）、update-tutorial（**ch29 重寫** + appendix-a + ch01）、再 drift-check（🔴=0）、lint。**官方標 Breaking 四項，其中 `AgentSkillsProvider` 工具預設需核可（#6729，移除 `ScriptApproval`/`UseScriptApproval`）與移除 `{resource_instructions}`/`{script_instructions}` 佔位符（#6706）經 codebase-memory-mcp 驗證確實影響 ch29——這是自 v1.4.0 以來首個影響教學程式碼的破壞性變更，ch29 已重寫。新增能力：`DeclarativeWorkflowJsonOptions`（AOT-safe checkpoint #6745）、archive 型 MCP 技能（#6631）、`CreateMcpTool projectConnectionId` 多載（#6703）** |
| 2026-07-23 | `2d34deeb8` | **連續同步 dotnet-1.14.0→1.15.0**：checkout dotnet-1.15.0 tag（working tree clean），重建索引 61,044 nodes / 265,384 edges。同步 release notes、ADR 0032、Learn 核心頁面與 Samples；後續 facts／compile／drift／tutorial／lint 結果見本次維護提交。 |
