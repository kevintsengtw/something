# QuickStart — Codex 維護指南

> 完整環境設定見 [`../SETUP.md`](../SETUP.md)。目前上游版本與 commit 只以 [`UPSTREAM-REF.md`](./UPSTREAM-REF.md) 為準。

## 啟動與 preflight

從工作區根啟動 Codex：

```bash
cd <workspace>/agent-framework-tutorial
python3 scripts/validate_workspace.py --require-upstream --check-upstream-clean
codex
```

需要 codebase-memory-mcp 時，先 `list_projects`，以 `root_path` 結尾為 `/agent-framework` 的項目取得實際 project name，再確認 `index_status` 為 ready。

## 版本更新 Pipeline A

依序完成，每一步檢查 diff 與上游 clean 狀態後再繼續：

```text
$sync-upstream
$extract-facts <version>
$compile
$snapshot-knowledge
$drift-check
$update-tutorial breaking
$drift-check
$lint
```

若還有確認要處理的 outdated 項目：

```text
$update-tutorial outdated
$drift-check
$lint
```

`$snapshot-knowledge` 是混合步驟：Codex 執行 preflight；Claude Code 的 Understand-Anything plugin 生成 graph；Codex 再執行 postflight validator。完整手冊見 [`PLAYBOOK-version-update.md`](./PLAYBOOK-version-update.md)。

## 教學建立 Pipeline D

```text
$draft-chapter <wiki-concept> [chapter-number]
# 只產生 outputs/draft-<concept>.md

$draft-appendix <topic> [appendix-letter]
# 只產生 outputs/draft-appendix-<topic>.md
```

人工 review 草稿後才移入正式教學，接著執行：

```text
$regenerate-toc
$lint
```

## 查詢與探索

```text
$wiki-query AgentSession 怎麼建立
$wiki-query v1.13.0 breaking change
$save-qa <topic>
```

Codex 可直接搜尋 `wiki/.understand-anything/knowledge-graph.json`；UA 的 `/understand-chat`、`/understand-explain` 與 `/understand-onboard` 仍屬 Claude plugin 相容流程。

## 日常驗證

```bash
# 可攜式 deterministic 檢查
python3 scripts/validate_workspace.py

# 完整本機基線，包含上游 tag/commit 與 clean 狀態
python3 scripts/validate_workspace.py --require-upstream --check-upstream-clean
```

`$lint` 在上述檢查後再做 MCP API 抽樣。`$drift-check` 只有在 MCP 或上游原始碼證據支持時，才能把候選差異列為 🔴 Breaking。

## 上游安全規則

- `agent-framework/` 是唯讀基準。
- 更新使用 `fetch --tags` 與 detached checkout；不要 merge 或修改檔案。
- 開始與結束都確認 `git -C agent-framework status --short` 為空。
- 不執行會清除未預期變更的 reset、checkout path 或 clean。
