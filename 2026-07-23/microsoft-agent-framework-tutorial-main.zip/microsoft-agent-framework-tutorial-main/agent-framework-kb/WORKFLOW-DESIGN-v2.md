# Workflow Design v2 — codebase-memory-mcp + Understand-Anything

> **歷史設計快照（2026-05-26）**：本文保留 v2 架構決策與當時的 v1.6.1 驗證數據，不代表目前版本或操作入口。現行 Codex 規範見工作區根 `AGENTS.md`，目前 upstream 見 `UPSTREAM-REF.md`，操作步驟見 `PLAYBOOK-version-update.md`。

> 版本：v2（設計階段，未實作）
> 撰寫日期：2026-05-26
> 取代：v1（位於 `agent-framework-kb/.claude/` 的舊指令集，已刪除）
> 狀態：⚠️ 設計草案 — 待 codebase-memory-mcp 在 macOS 上首次驗證通過後實作
> 唯一目標環境：**macOS**（Windows 已退場）

---

## 0. 設計演進三次決策

本設計在 2026-05-26 同日經歷三次重要決定，最終定案：

1. **入口點上移到工作區根** `agent-framework-tutorial/.claude/commands/` —— 跨三層子目錄統一管理（取代 v1 的 `agent-framework-kb/.claude/`）
2. **工作流範圍擴張** —— 從只做「KB 維護」延伸到「教學文件的建立與更新」，新增 Pipeline D
3. **事實層工具保留為 codebase-memory-mcp** —— 曾評估改用 GitNexus，但因 GitNexus 在 macOS 上的 C# 準度未驗證、使用成本高於現有工具，決定維持 codebase-memory-mcp（Windows 上已實戰驗證；macOS 仍需首次驗證）

---

## 1. 設計原則（Philosophy）

工具二分，不交叉：

| 層別 | 工具 | 職責 | 性質 |
|------|------|------|------|
| **事實層** | **codebase-memory-mcp** | 原始碼結構性事實的 ground truth | Deterministic（tree-sitter parser） |
| **敘述層** | **Understand-Anything + LLM** | 概念敘述、關係抽取、視覺化、Onboarding、教學撰寫 | LLM-based（語意理解） |

核心約束：
- 任何結構性宣告（API 名稱、簽名、namespace）**必須先經 codebase-memory-mcp 驗證**，再交給 LLM 寫敘述
- LLM 不得擅自宣告 API 存在或不存在
- 若 codebase-memory-mcp 在 macOS 上無法運作或 C# 解析品質不足，整個架構失效，需另尋方案（純 grep + WebFetch 上游 GitHub 的退化方案）

**端點目標**：建立、維護、擴充 `microsoft-agent-framework-tutorial/`（29 章 + 5 附錄）。

---

## 2. 前置條件（codebase-memory-mcp macOS 可用性驗證）

> ✅ **驗證已通過 — 2026-05-26（6/7）**
> 詳細結果與已知限制見 [`./raw/facts/codebase-memory-mcp-validation.md`](./raw/facts/codebase-memory-mcp-validation.md)
> 驗證環境：macOS 26.5、Node.js v24.15.0、codebase-memory-mcp v0.6.1、agent-framework commit `793403f3`
> 索引規模：44,650 nodes / 180,686 edges

### 驗證結果摘要

| 探測 | 結果 | 備註 |
|------|------|------|
| 1. `IChatClient` 使用端 | ✅ 調整通過 | `IChatClient` 是外部 NuGet（`Microsoft.Extensions.AI`）；找到 55 個使用端 |
| 2. `AIAgent.RunAsync` 簽名 | ✅ 通過 | 2+ overload，含 `Task<AgentResponse>` |
| 3. `AgentSession` 繼承鏈 | ✅ 通過 | 76 個 Class 節點含 base + 多個 derived |
| 4. `AgentMiddlewareDelegate` | ❌ 失敗 | 該型別在 v1.6.1 已不存在，middleware 架構已演進為 `DelegatingAIAgent` |
| 5. `AIFunctionFactory.Create` | ✅ 調整通過 | 外部套件型別；改用 `AIAgentExtensions.AsAIFunction()`（in_degree=22） |
| 6. callers 連結度 | ⚠️ 部分通過 | `trace_path` 短名稱模糊時受限；用 `search_graph` 的 in_degree 替代確認 |
| 7. Namespace 一致性 | ✅ 通過 | 20 筆抽樣全部正確分類 |

**通過數**：6/7（其中 1 失敗為**規格過時**而非工具問題）。

### 驗證發現的工具使用慣例（必讀）

1. **外部依賴不索引**：`IChatClient`、`AIFunctionFactory`、`ChatOptions` 等 `Microsoft.Extensions.AI.*` 型別來自外部 NuGet，**不在 agent-framework 圖譜中**。要查詢它們應改用「找使用端」（in_degree > 0）的方式。
2. **qualified_name 含路徑前綴**：圖譜的 `qualified_name` 格式為 `<repo-path>.dotnet.src.Microsoft.Agents.AI.<...>.<name>`，不是純 C# namespace。呼叫 `get_code_snippet` 時必須**先用 `search_graph` 找到正確 qualified_name**。
3. **`trace_path` 短名稱限制**：當短名稱對應多個節點時 `trace_path` 回傳空集。應優先用 `search_graph` 的 in_degree 欄位確認連結度，或傳入完整 qualified_name。
4. **探測規格修訂**（已記錄在驗證檔 §7）：未來重跑驗證時，採用以下修訂版本：
   - 探測 1：找 `AGUIChatClient`、`ChatClientAgentSession` 等實作節點
   - 探測 4：改為 `search_graph("DelegatingAIAgent")` 或 `search_graph("FunctionInvocationDelegatingAgent")`
   - 探測 5：改為 `search_graph("AsAIFunction")` → 確認 in_degree ≥ 10
   - 探測 6：傳入完整 qualified_name（如 `AIAgentExtensions.AsAIFunction`）

### 重跑驗證的時機

- 切換到新 macOS 機器
- codebase-memory-mcp 主要版本升級
- 上游 `agent-framework` 切換 commit 跨越 minor 版本

---

## 3. 架構（Workspace-Root Entry Point）

```
agent-framework-tutorial/                      ← 工作區根（入口點）
├── CLAUDE.md                                  ← master orchestration
├── .mcp.json                                  ← codebase-memory-mcp stdio 設定
├── .gitignore                                 ← 排除 UA scratch
├── .claude/
│   ├── settings.local.json                    ← macOS 版權限
│   └── commands/                              ← 12 個 slash commands
│       ├── sync-upstream.md                   ← Pipeline A.1+A.2
│       ├── extract-facts.md                   ← Pipeline A.3
│       ├── compile.md                         ← Pipeline A.4
│       ├── snapshot-knowledge.md              ← Pipeline A.5
│       ├── drift-check.md                     ← Pipeline A.6
│       ├── update-tutorial.md                 ← Pipeline A.7
│       ├── lint.md                            ← Pipeline A.8（含 tutorial-lint）
│       ├── wiki-query.md                      ← Pipeline B
│       ├── save-qa.md                         ← Pipeline B
│       ├── draft-chapter.md                   ← Pipeline D.1
│       ├── draft-appendix.md                  ← Pipeline D.2
│       └── regenerate-toc.md                  ← Pipeline D.3
├── README.md
│
├── agent-framework/                           ← Layer 1（事實層，codebase-memory-mcp 索引對象）
│   └── （上游 SDK 原始碼，唯讀）
│
├── agent-framework-kb/                        ← Layer 2（敘述層）
│   ├── CLAUDE.md                              ← kb 補充指引（已降位）
│   ├── WORKFLOW-DESIGN-v2.md                  ← 本檔
│   ├── wiki/concepts/                         ← LLM 編譯產出（39 條目）
│   ├── .understand-anything/                  ← UA 產出（snapshot-knowledge 後存在）
│   ├── raw/                                   ← 上游素材鏡像
│   │   └── facts/                             ← 每版本事實清單 JSON
│   └── brainstorming/qa-sessions/
│
└── microsoft-agent-framework-tutorial/        ← Layer 3（教學產出）
    ├── README.md
    └── (01-..29-, appendix-a-..i-).md
```

**索引位置**：codebase-memory-mcp 通常將 LadybugDB 索引存於 `~/.codebase-memory-mcp/` 全域目錄，**不在工作區內**——所以本工作區的 `.gitignore` 不需要排除任何 codebase-memory-mcp 產出。

**資料流方向**：
- 上游 commit → Layer 1（codebase-memory-mcp 索引，file watcher 自動同步）→ raw/facts/（事實 JSON）
- raw/ 素材 + raw/facts/ → Layer 2 wiki/concepts/（敘述 + frontmatter）
- Layer 2 → UA → `.understand-anything/`（知識圖譜）
- Layer 1 + Layer 2 → drift-check → Layer 3 修正或新增章節

---

## 4. 四條 Pipeline

### Pipeline A：版本更新（Version Update）

**觸發**：Microsoft Agent Framework 發佈新版本。

| 階段 | 指令 | 工具 | 角色 |
|------|------|------|------|
| A.1 上游同步 | `/sync-upstream` | git + sync 腳本 | 抓 raw/ 素材 |
| A.2 索引同步 | `/sync-upstream`（同指令尾段） | codebase-memory-mcp（file watcher 自動） | git pull 後自動同步 |
| A.3 事實清單 | `/extract-facts <version>` | codebase-memory-mcp（主導） | 抽 release-notes → 逐筆 `search_graph` 驗證 → 寫 raw/facts/v1.x.y.json |
| A.4 KB 編譯 | `/compile` | codebase-memory-mcp（事實）+ LLM（敘述） | frontmatter 必須引用 A.3 facts，敘述由 LLM 撰寫 |
| A.5 知識圖快照 | `/snapshot-knowledge` | UA（`/understand-knowledge --language zh-TW`） | 對 wiki/ 跑視覺化，commit JSON |
| A.6 偏移檢查 | `/drift-check` | codebase-memory-mcp（API 存在性）+ grep（文字定位） | 產 wiki/drift-report.md，🔴/🟡/🟢 分類 |
| A.7 教學自動修正 | `/update-tutorial breaking` | codebase-memory-mcp（替換方向確認）+ Edit | 處理 🔴 Breaking |
| A.8 驗證 | `/drift-check` + `/lint` | codebase-memory-mcp + grep | 確認 🔴 = 0 |

### Pipeline B：互動探索（On-Demand Exploration）

**觸發**：撰寫時查詢、稽核既有內容、回答技術問題。

| 場景 | 指令 | 工具 |
|------|------|------|
| 查特定 wiki 概念 | `/wiki-query <concept>` | Read + Grep wiki/ |
| 對 wiki 提問（語意） | `/understand-chat`（UA 原生） | UA |
| 深入解析 wiki 條目或教學章節 | `/understand-explain <file>`（UA 原生） | UA |
| 看大改寫的影響範圍 | `/understand-diff`（UA 原生） | UA |
| 查 C# API callers/dependencies | 直接呼叫 `mcp__codebase-memory-mcp__trace_path` / `get_code_snippet` | codebase-memory-mcp |
| 儲存有價值的問答 | `/save-qa` | Write 到 brainstorming/qa-sessions/ |

UA 原生指令直接使用，不再包裝。

### Pipeline C：Onboarding

**觸發**：新讀者第一次進入專案。

- 開啟既有 dashboard：`.understand-anything/dashboard/`（A.5 後已存在）
- 產生新人導覽：`/understand-onboard`（UA 原生）

### Pipeline D：教學文件建立（NEW）

**觸發**：新章節、新附錄、TOC 重建、教學側 lint。

| 階段 | 指令 | 工具 | 角色 |
|------|------|------|------|
| D.1 新章節草稿 | `/draft-chapter <wiki-concept> [chapter-number]` | codebase-memory-mcp + UA + LLM | 步驟見下方 |
| D.2 新附錄草稿 | `/draft-appendix <topic>` | codebase-memory-mcp + LLM | 類似 D.1 但格式為附錄 |
| D.3 TOC 重建 | `/regenerate-toc` | 純文字處理 | 掃描 tutorial/*.md，重建 README 章節表 |

**D.1 `/draft-chapter` 內部流程**：
1. 讀取 `agent-framework-kb/wiki/concepts/<concept>.md`（敘述層 source of truth）
2. 對 wiki 條目 frontmatter 與內文中的每個 API 名稱：
   - **codebase-memory-mcp 驗證存在**（`search_graph`）
   - **codebase-memory-mcp 取簽名與位置**（`get_code_snippet`）
   - **codebase-memory-mcp 找上游使用範例**（`search_code`）
3. UA：查 `.understand-anything/knowledge-graph.json` 找此概念的相關概念，作為「相關概念」段落來源
4. LLM 依照 `microsoft-agent-framework-tutorial/PLAN-beginner-tutorial.md` 的風格規約撰寫章節
5. 草稿先輸出至 `outputs/draft-<concept>.md` 供審閱，**不直接寫入 tutorial/**

**D.2 `/draft-appendix`**：類似 D.1，但 reference SDK samples、NuGet packages、migration guides。

**D.3 `/regenerate-toc`**：
- 掃描 `microsoft-agent-framework-tutorial/*.md` 標題
- 重建 README.md 的章節表格與附錄表格
- 比對既有內容差異後寫入

**為何 lint 不獨立成 D**：tutorial-side 的一致性檢查（內部連結、code block 語言標籤、API 存在性、Markdown 風格、frontmatter）整併到 A.8 的 `/lint` 指令，避免雙軌。

---

## 5. Slash Commands 總覽

| 指令 | Pipeline | 主要工具 | 一句話 |
|------|---------|---------|--------|
| `/sync-upstream` | A.1+A.2 | git + codebase-memory-mcp（file watcher） | 拉上游 + 索引自動同步 |
| `/extract-facts` | A.3 | codebase-memory-mcp | release notes → 事實 JSON |
| `/compile` | A.4 | codebase-memory-mcp + LLM | 編譯 wiki，引用事實 JSON |
| `/snapshot-knowledge` | A.5 | UA | 對 wiki/ 跑 /understand-knowledge |
| `/drift-check` | A.6 | codebase-memory-mcp + grep | 偏移檢查 |
| `/update-tutorial` | A.7 | codebase-memory-mcp + Edit | 自動修正 🔴 Breaking |
| `/lint` | A.8 + tutorial-side | grep + codebase-memory-mcp | wiki 與 tutorial 一致性檢查 |
| `/wiki-query` | B | Read + Grep | 查特定 wiki 概念 |
| `/save-qa` | B | Write | 存問答到 brainstorming/ |
| `/draft-chapter` | D.1 | codebase-memory-mcp + UA + LLM | 從 wiki 概念 draft 新章節 |
| `/draft-appendix` | D.2 | codebase-memory-mcp + LLM | draft 新附錄 |
| `/regenerate-toc` | D.3 | 文字處理 | 重建 README TOC |

**UA 原生指令不包裝**：`/understand-chat`、`/understand-explain`、`/understand-diff`、`/understand-onboard`、`/understand-knowledge`、`/understand-domain` 直接以 UA plugin 形式使用。

---

## 6. 已執行的清理（2026-05-26）

以下檔案在實作前已清理完畢：

| 路徑 | 狀態 |
|------|------|
| `agent-framework-kb/.claude/`（舊指令入口） | ✅ 已刪除 |
| `agent-framework-kb/.mcp.json`（含 Windows `.cmd` 路徑） | ✅ 已刪除（工作區根 .mcp.json 接手） |
| `agent-framework-kb/ARCH-cross-platform.md`（雙平台策略） | ✅ 已刪除（macOS 唯一） |
| `agent-framework/.gitnexus/`（失敗 GitNexus 安裝殘留） | ✅ 已刪除 |
| `agent-framework/CLAUDE.md`（GitNexus 注入殘留，untracked） | ✅ 已刪除 |
| `agent-framework/AGENTS.md`（GitNexus 注入殘留，untracked） | ✅ 已刪除 |
| `agent-framework-kb/CTemp*`（4 個暫存檔） | ✅ 已由使用者清除 |

---

## 7. 仍待整理（後續處理）

| 路徑 | 狀態 |
|------|------|
| `agent-framework-kb/README.md` | 含 codebase-memory-mcp 整合說明的舊段落，內容仍可用但需對齊新流程 |
| `agent-framework-kb/PLAYBOOK-version-update.md` | A.3 與 A.5 是新階段，PLAYBOOK 需擴充 |
| `agent-framework-kb/QuickStart.md` | macOS 安裝步驟需更新 |
| `agent-framework-kb/UPSTREAM-REF.md` | 不需動，但可補充 codebase-memory-mcp 跨機同步策略 |
| `agent-framework-kb/MIGRATION-from-codebase-memory-mcp.md` | 計畫名稱已失效（實際沒有「遷出」）；可改寫為 `MIGRATION-LOG.md` 記錄這次決策歷程 |
| 工作區根 `EVAL-llm-wiki-feasibility.md`、`GUIDE-llm-wiki-setup.md` | 4 月初版文件，可能已過時，待人工檢視 |

---

## 8. JSON / 索引 commit 策略

| 產物 | 是否 commit | 理由 |
|------|------------|------|
| codebase-memory-mcp 索引 | ❌ 不在工作區內 | 存於 `~/.codebase-memory-mcp/` 全域目錄 |
| `agent-framework-kb/.understand-anything/knowledge-graph.json` | ✅ commit | 跨平台共享、PR 審查、Onboarding 即用 |
| `agent-framework-kb/.understand-anything/intermediate/` | ❌ gitignore | 本地 scratch（UA 官方建議） |
| `agent-framework-kb/.understand-anything/diff-overlay.json` | ❌ gitignore | 本地 scratch（UA 官方建議） |
| `agent-framework-kb/raw/facts/*.json` | ✅ commit | 事實審計憑證 |

---

## 9. 風險矩陣

| 風險 | 機率 | 影響 | 緩解 |
|------|------|-----|-----|
| codebase-memory-mcp 在 macOS 上無法運作（Windows 才驗證過） | 中 | 致命 | §2 驗證閘門；不通過則退化純 grep 方案 |
| codebase-memory-mcp 在 72K nodes 規模效能/穩定性 | 低 | 中 | Windows 已驗證可運作；macOS 環境跑時可能異於預期 |
| UA 對 39 個 wiki 條目產出品質不佳 | 低 | 中 | 試跑評估；調整 wiki frontmatter |
| `/draft-chapter` 產出風格偏離 PLAN-beginner-tutorial.md | 中 | 中 | 草稿先進 outputs/ 不直寫 tutorial/，人工 review |
| 教學引用的 API 在 codebase-memory-mcp 圖譜上 false negative | 低 | 中 | drift-check 對 🔴 結果加人工複核步驟 |

---

## 10. 下一步路線圖

1. ⚠️ **codebase-memory-mcp macOS 驗證**（§2）：在 macOS 上安裝、首次 `index_repository`、跑 7 項探測查詢，產出 `agent-framework-kb/raw/facts/codebase-memory-mcp-validation.md`
2. 驗證通過 → 跑一次完整 Pipeline A（在當前 v1.6.1 基準上模擬），確認流程通順
3. 跑 Pipeline D 的 `/draft-chapter` 對某個既有概念做試作，比對與既有教學品質
4. 整理 §7 列出的後續文件
5. 撰寫 MIGRATION-LOG.md 記錄三次決策歷程

---

## 11. 對 v1 設計的重要變更

| 面向 | v1（舊） | v2（新） |
|------|---------|---------|
| 入口點 | `agent-framework-kb/.claude/commands/` | `agent-framework-tutorial/.claude/commands/`（工作區根） |
| Master CLAUDE.md | `agent-framework-kb/CLAUDE.md` | `agent-framework-tutorial/CLAUDE.md`（新增） |
| 事實層工具 | codebase-memory-mcp（同） | codebase-memory-mcp（同，曾評估 GitNexus 後決定保留） |
| 敘述層工具 | 無 | Understand-Anything（新增） |
| Pipeline 數 | 1（KB 維護） | 4（A 版本更新 / B 探索 / C Onboarding / D 教學建立） |
| 教學文件建立指令 | 無（只有 update-tutorial） | `/draft-chapter`、`/draft-appendix`、`/regenerate-toc` |
| 事實提取階段 | 隱含在 /compile | 獨立為 `/extract-facts` |
| 知識圖視覺化 | 無 | `/snapshot-knowledge` |
| 跨平台策略 | macOS 主 + Windows 備援 | **唯 macOS** |
| .mcp.json 路徑硬編碼 | 是（Windows `.cmd` 絕對路徑） | 否（macOS PATH 上的 `codebase-memory-mcp` 命令） |
