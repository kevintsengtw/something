# NEXT-STEPS — 接班指引（Cowork → Claude Code CLI）

> **歷史執行清單**：本文記錄 v1.6.1 階段的導入與試跑規劃，已不作為目前待辦或版本基準。現行流程見 `QuickStart.md` 與 `PLAYBOOK-version-update.md`。

> 撰寫日期：2026-05-26
> 目的：把所有待辦工作從本次 Cowork 會話交接到 Claude Code CLI（macOS）繼續執行
> 環境：本檔之後的所有工作建議在 macOS Claude Code CLI 進行（codebase-memory-mcp MCP server 在那邊正常運作）

---

## 0. 目前狀態快照

| 面向 | 狀態 |
|------|------|
| v2 工作流架構 | ✅ 完成（工作區根入口點、12 個 slash commands、4 條 pipeline） |
| 文件對齊 | ✅ 完成（CLAUDE.md、WORKFLOW-DESIGN-v2、PLAYBOOK、QuickStart、UPSTREAM-REF、kb README、MIGRATION-LOG） |
| codebase-memory-mcp macOS 驗證 | ✅ 通過 6/7（2026-05-26） |
| Understand-Anything | ✅ 已安裝可用 |
| 殘留檔清理 | ✅ 完成（agent-framework/.gitnexus/、.claude/skills/gitnexus/、注入版 CLAUDE.md/AGENTS.md、舊 kb/.claude/） |
| **Pipeline A 完整試跑** | ⏳ 待執行（本接班文件 §2 的主任務） |
| 12 個 slash commands 細節調校 | ⏳ 待執行（本接班文件 §3） |
| `/draft-chapter` 試作 | ⏳ 待執行（本接班文件 §4） |
| 舊文件人工檢視 | ⏳ 待執行（本接班文件 §5） |

---

## 1. 驗證發現的工具使用慣例（所有後續工作都受影響）

這三條已寫入 [`../CLAUDE.md`](../CLAUDE.md) §6 與 [`./WORKFLOW-DESIGN-v2.md`](./WORKFLOW-DESIGN-v2.md) §2，但 12 個 slash command 內容**尚未對齊**——這是 §3 的工作。

### 慣例 1：外部依賴不索引

`IChatClient`、`AIFunctionFactory`、`ChatOptions`、`ChatMessage` 等 `Microsoft.Extensions.AI.*` 型別來自外部 NuGet 套件，**不在 agent-framework 圖譜中**。

**錯誤做法**：
```
mcp__codebase-memory-mcp__search_graph
  name_pattern: "IChatClient"
# 期待找到介面節點 → 結果是只有實作節點
```

**正確做法**：找使用端（implementations / usages），用 in_degree 確認連結度：
```
mcp__codebase-memory-mcp__search_graph
  name_pattern: "AGUIChatClient"    # 或其他實作
# 然後檢查回傳節點的 in_degree 欄位
```

判斷一個型別是否為外部依賴：`namespace` 不以 `Microsoft.Agents` 開頭就視為外部（例如 `Microsoft.Extensions.AI`、`Azure.AI.Projects`）。

### 慣例 2：qualified_name 含路徑前綴

圖譜的 `qualified_name` 格式不是純 C# namespace，而是含 repo 路徑前綴：
```
Users-tsengweihua-Documents-agent-framework-tutorial-agent-framework.dotnet.src.Microsoft.Agents.AI.Abstractions.AIAgent.AIAgent.RunAsync
```

**呼叫 `get_code_snippet` 必須兩步驟**：

1. 先用 `search_graph` 找到正確 qualified_name：
   ```
   mcp__codebase-memory-mcp__search_graph
     name_pattern: "RunAsync"
   # 從回傳結果取得 qualified_name 欄位
   ```

2. 再用該完整 qualified_name 呼叫 `get_code_snippet`：
   ```
   mcp__codebase-memory-mcp__get_code_snippet
     qualified_name: "<上一步取得的完整字串>"
   ```

### 慣例 3：trace_path 短名稱限制

`trace_path` 在短名稱（如 `AsAIFunction`）對應多個節點時會回傳空集——這是工具限制，不是索引品質問題。

**錯誤做法**：
```
mcp__codebase-memory-mcp__trace_path
  function_name: "AsAIFunction"
  direction: "inbound"
# 對應多個節點 → 回傳空集
```

**正確做法（擇一）**：

A. 傳完整 qualified_name：
```
mcp__codebase-memory-mcp__trace_path
  function_name: "<完整 qualified_name>"
  direction: "inbound"
```

B. 用 `search_graph` 看 in_degree 替代：
```
mcp__codebase-memory-mcp__search_graph
  name_pattern: "AsAIFunction"
# 從回傳結果讀 in_degree 欄位（呼叫者數量）
```

---

## 2. 任務一：Pipeline A 在 v1.6.1 基準上模擬跑一輪

**目的**：驗證完整工作流通順度，發現指令內容需要修補的地方。
**預估時間**：60–90 分鐘
**前置條件**：已通過 §1 的工具使用慣例

### 執行順序

```
/sync-upstream
/extract-facts 1.6.1
/compile
/snapshot-knowledge
/drift-check
/lint
```

**注意**：不執行 `/update-tutorial`，因為 wiki 已是最新（v1.6.1 是當前基準），跑也不會有 🔴 Breaking。**這次是驗證流程通順，不是真的修教學**。

### 各階段的成功標準

#### `/sync-upstream`
- ✅ 終端顯示 raw/ 各子目錄的檢查結果
- ✅ 顯示 codebase-memory-mcp 索引狀態（已 indexed、commit 對齊）
- ✅ 不會因為「無新版本」而報錯（v1.6.1 已是最新）
- ⚠️ 注意：若指令內容假設一定有新檔案，可能需要修正

#### `/extract-facts 1.6.1`
- ✅ 讀取 `raw/release-notes/dotnet-1.6.1.md`
- ✅ 對其中提到的每個 API 用 `search_graph` 驗證
- ✅ 產出 `raw/facts/dotnet-1.6.1-verified-changes.json`
- ✅ 已驗證 / 未驗證項目數合理（v1.6.1 release notes 應該大部分 API 都驗證得到）
- ⚠️ 注意：可能會遇到「IChatClient 屬於外部套件」這類已知限制，指令應該正確處理

#### `/compile`
- ✅ 偵測 raw/ 已是 last_compile 之後狀態（若無變更應提示「無新素材」並結束）
- ✅ 若決定跑全量編譯，frontmatter 應引用 `raw/facts/dotnet-1.6.1-verified-changes.json`
- ⚠️ 注意：指令內容假設「LLM 不得即興宣告 API 簽名」，但 wiki 既有條目可能不完全符合這個新規約

#### `/snapshot-knowledge`
- ✅ 呼叫 UA `/understand-knowledge agent-framework-kb/wiki --language zh-TW`
- ✅ 產出 `.understand-anything/knowledge-graph.json`
- ✅ 報告節點數 ≈ wiki/concepts/ 條目數（39）
- ⚠️ 注意：UA 第一次跑可能需要較長時間（多 agent pipeline）

#### `/drift-check`
- ✅ 對 wiki/concepts/ 每個條目掃描 tutorial/
- ✅ 對每個 API 名稱用 `search_graph` 驗證存在性
- ✅ 產出 `wiki/drift-report.md`
- ✅ 預期 🔴 = 0（既然 wiki 是 v1.6.1 基準）
- ⚠️ 注意：可能會誤把外部套件型別當成 Breaking，需用慣例 1 排除

#### `/lint`
- ✅ Part 1（wiki 一致性）：條目格式、api_name 圖譜查驗、索引完整性、交叉引用、來源追溯
- ✅ Part 2（tutorial 一致性）：內部連結、code block 語言標籤、API 抽樣查驗、README 章節索引
- ✅ 報告無重大問題（或列出可接受的小問題）

### 完成後的產出

- `agent-framework-kb/raw/facts/dotnet-1.6.1-verified-changes.json`（新增）
- `agent-framework-kb/.understand-anything/knowledge-graph.json`（新增）
- `agent-framework-kb/wiki/drift-report.md`（更新）
- `agent-framework-kb/wiki/INDEX.md`（last_compile 時間戳更新）

### 若遇到問題

- **指令邏輯與實際工具行為不符** → 記錄問題到 §3 的指令調校清單
- **codebase-memory-mcp 回傳意外結果** → 重跑 `index_repository`（無需重啟，file watcher 自動）
- **UA 跑不起來** → 確認 `/plugin install understand-anything` 完成、Claude Code 已重啟

---

## 3. 任務二：根據驗證發現更新 7 個 slash commands

**目的**：把 §1 的三條工具使用慣例落到指令層級，避免每次跑都靠 master CLAUDE.md 提醒。
**預估時間**：60 分鐘
**前置條件**：建議在跑完 §2 Pipeline A 之後做，把試跑遇到的真實問題也一併納入

### 需要修改的指令清單

| 指令 | 主要修改點 |
|------|----------|
| `extract-facts.md` | (a) 對「圖譜查無此節點」要區分「外部 NuGet 套件」與「真正不存在」；(b) 取 qualified_name 必須先 search_graph |
| `compile.md` | (a) `get_code_snippet` 呼叫前要先 `search_graph` 取 qualified_name；(b) 外部套件型別不寫進 frontmatter 的 namespace 欄位（標記為外部） |
| `drift-check.md` | (a) `query_graph` 的 Cypher 對 namespace 比對時，外部套件節點本來就不在圖譜，不應標 🔴；(b) `search_code` 對外部套件名稱搜尋也可能無結果 |
| `update-tutorial.md` | (a) 替換方向確認時，若新 API 是外部套件，圖譜查無不應視為「找不到新名稱」 |
| `lint.md` | (a) api_name 圖譜查驗：明確排除外部套件（namespace 不以 `Microsoft.Agents` 開頭）；(b) 教學側 API 抽樣同理 |
| `draft-chapter.md` | (a) GitNexus 結構性驗證的三步（search → context → impact）要先確認 qualified_name；(b) 對外部套件 API，標記為「外部依賴」而非「待人工驗證」 |
| `draft-appendix.md` | 同 draft-chapter |

### 修改方式範本

每個指令在工具呼叫範例旁加註：

```markdown
**注意（外部依賴）**：若 `name_pattern` 對應的型別屬於外部 NuGet 套件
（namespace 不以 `Microsoft.Agents` 開頭，如 `Microsoft.Extensions.AI.*`），
圖譜查無屬正常現象，不應視為錯誤。改用「找實作/使用端」並看 in_degree。

**注意（qualified_name 取得）**：呼叫 `get_code_snippet` 前必須先用
`search_graph` 找到完整 qualified_name（含路徑前綴），不可直接用短名稱。

**注意（trace_path 限制）**：若 `function_name` 短名稱對應多個節點，trace_path
會回傳空集。改傳完整 qualified_name，或改用 `search_graph` 的 in_degree。
```

把上面三條「注意」段落作為標準附錄，加進對應的指令裡。

### 不需修改的 5 個指令

- `sync-upstream.md` — 不直接呼叫 search_graph 以外的工具
- `snapshot-knowledge.md` — 走 UA 不走 codebase-memory-mcp
- `wiki-query.md` — 純 Read/Grep
- `save-qa.md` — 純 Write
- `regenerate-toc.md` — 純文字處理

---

## 4. 任務三：`/draft-chapter` 試作

**目的**：驗證 Pipeline D 的旗艦指令是否能產出有用的章節草稿。
**預估時間**：30–45 分鐘
**前置條件**：§2 完成（特別是 `/snapshot-knowledge` 已產出 UA 知識圖譜）

### 試作對象選擇

從 wiki/concepts/ 39 個條目中挑一個**已有對應教學章節的**概念跑 draft-chapter，**比對與既有章節品質**。建議候選：

| 候選 wiki 概念 | 對應既有教學 | 為何適合試作 |
|---------------|------------|------------|
| `magentic-orchestration` | 暫無（v1.5.0 Experimental） | 是 v1.5.0 新功能，wiki 有但教學沒有，最能體現 Pipeline D 價值 |
| `agent-skills` | ch29 | 已有教學可對照，看 draft-chapter 產出是否合理 |
| `chat-message-injector` | ch06 內提及 | wiki 有獨立條目，教學是融入式描述，draft 出來可看是否能獨立成章 |

**建議起手用 `agent-skills`**，因為對應教學成熟，比對基準明確。

### 執行

```
/draft-chapter agent-skills 29-draft
```

（指定編號 `29-draft` 以便輸出檔名與既有 29 章區分）

### 成功標準

- ✅ 草稿輸出到 `outputs/draft-agent-skills.md`，**不寫入** `microsoft-agent-framework-tutorial/`
- ✅ 草稿章節結構符合 PLAN-beginner-tutorial.md 風格
- ✅ 草稿中提到的所有 API 名稱都經 codebase-memory-mcp 驗證（外部依賴有標記）
- ✅ 「相關概念」段落引用了 UA 知識圖譜的鄰居節點
- ✅ 與既有 29-agent-skills.md 比對：核心概念覆蓋度 ≥ 80%，但敘事可不同

### 比對既有教學

跑完之後做 diff 比對：
```bash
diff -u microsoft-agent-framework-tutorial/29-agent-skills.md outputs/draft-agent-skills.md | less
```

紀錄發現：
- draft 漏掉的內容（既有有但 draft 無）
- draft 多出來的內容（draft 有但既有無）
- 風格差異

這些發現可用來改進 draft-chapter.md 指令本身。

---

## 5. 任務四：人工檢視舊文件

**目的**：確認 4 月份的兩份初版文件是否仍然有效，或需要更新/退役。
**預估時間**：15–20 分鐘
**前置條件**：無

### 對象

- `/Users/tsengweihua/Documents/agent-framework-tutorial/EVAL-llm-wiki-feasibility.md`（2026-04-12，10446 bytes）
- `/Users/tsengweihua/Documents/agent-framework-tutorial/GUIDE-llm-wiki-setup.md`（2026-04-12，13042 bytes）

### 檢視重點

| 檢查項 | 處理方式 |
|--------|---------|
| 內容是否還反映目前 v2 工作流？ | 否 → 加標題前綴 `[ARCHIVE]` 或退役 |
| 是否提到已退役的工具/流程？ | 是 → 加註「2026-05-26 後已過時」 |
| 是否有獨特觀點仍值得保留？ | 是 → 萃取進 MIGRATION-LOG.md 或新增章節到 README |

### 可選動作

如果兩份都已過時，可以：
- 移到 `agent-framework-kb/docs/archive/` 目錄（保留歷史但不顯眼）
- 或直接刪除（git 歷史仍可追溯）

---

## 6. 任務五（可選）：對 `microsoft-agent-framework-tutorial/` 也跑 UA

**目的**：把教學本體（29 章 + 5 附錄）也視覺化成知識圖，作為讀者導覽。
**預估時間**：20–30 分鐘
**優先級**：低（不影響工作流，純加值）

### 執行

```
/understand-knowledge microsoft-agent-framework-tutorial --language zh-TW
```

注意：UA 的 `/understand-knowledge` 預設假設目標是 Karpathy LLM Wiki，但教學目錄不完全是這種格式。可能需要額外調整或改用 `/understand` 走 codebase-style 分析（但教學不是程式碼，效果未必好）。

### 評估

- 若產出合理 → 加進 Pipeline C Onboarding 的標準流程
- 若不合理 → 紀錄為已嘗試但不採用

---

## 7. 任務六（長期）：建立 `/snapshot-knowledge` 與 `/extract-facts` 的 baseline

完成 §2 試跑後，把 v1.6.1 基準下產出的 facts JSON 與 knowledge-graph.json 視為「**金標準**」，下一個版本更新時可以 diff 比對：

```bash
# 假設下一版是 v1.7.0
diff agent-framework-kb/raw/facts/dotnet-1.6.1-verified-changes.json \
     agent-framework-kb/raw/facts/dotnet-1.7.0-verified-changes.json
```

可以快速看到「v1.7.0 相對 v1.6.1 多了哪些 verified API」。

---

## 8. 順序建議

最謹慎的執行順序：

1. **§5 舊文件檢視**（先，15 分鐘，無依賴）
2. **§2 Pipeline A 試跑**（核心，60–90 分鐘）
3. **§3 指令調校**（根據 §2 試跑發現的問題微調，60 分鐘）
4. **§4 `/draft-chapter` 試作**（30–45 分鐘）
5. **§6 教學側 UA 可選試作**（20–30 分鐘）
6. **§7 baseline 建立**（自動進行，無需動作）

**總計**：約 3–4 小時可完成所有後續工作。

---

## 9. 給接班 Claude 的提醒

如果你（接班的 Claude Code CLI Claude）正在讀這份檔，請依以下原則行動：

1. **先讀完工作區根 `CLAUDE.md`** 與 [`./WORKFLOW-DESIGN-v2.md`](./WORKFLOW-DESIGN-v2.md)，建立對 v2 架構的整體理解
2. **§1 的三條工具使用慣例必須內化**，不要只看 slash command 內容而忽略這些慣例
3. **不要回頭改變大架構決策**（入口點位置、工具二分原則、Pipeline 數量）——這些已經透過三次決策定案
4. **若試跑發現問題**，記錄在 MIGRATION-LOG 的後續進度區，而非靜默修改
5. **`/draft-chapter` 與 `/draft-appendix` 草稿永遠進 `outputs/`**，絕不直接寫入 tutorial/
6. **編譯時 LLM 不得即興宣告 API 簽名**——所有結構性宣告來自 `raw/facts/*.json`
7. **memory 系統**（用 Read/Write 存取本機 home 下的 memory 目錄）保留了三條重要 feedback：
   - `feedback-gitnexus-windows-incompatibility`
   - `feedback-kb-tool-division-philosophy`
   - `feedback-tool-choice-pragmatism-over-novelty`
   - `feedback-workspace-root-entry-point`
   讀這些前先看 `project_agent-framework-tutorial` 取得完整脈絡

---

## 10. 連結

- [工作區根主導文件](../CLAUDE.md)
- [kb 補充指引](./CLAUDE.md)
- [工作流設計 v2](./WORKFLOW-DESIGN-v2.md)
- [Pipeline A 操作手冊](./PLAYBOOK-version-update.md)
- [遷移歷程](./MIGRATION-LOG.md)
- [驗證記錄](./raw/facts/codebase-memory-mcp-validation.md)
- [快速操作指南](./QuickStart.md)
- [上游 commit 對齊](./UPSTREAM-REF.md)
