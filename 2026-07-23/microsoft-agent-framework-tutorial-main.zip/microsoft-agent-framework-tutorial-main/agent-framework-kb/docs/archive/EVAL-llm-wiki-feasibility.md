# LLM Wiki 模式應用於 Agent Framework 教學的可行性評估

> ⚠️ **[ARCHIVED 2026-05-26]** 本文件已封存。決策已落地為 v2 工作流（WORKFLOW-DESIGN-v2.md）。
> 移至 `agent-framework-kb/docs/archive/` 保留歷史推論。後續操作請見 QuickStart.md。

> 評估日期：2026-04-12
> 評估對象：Karpathy LLM Wiki、gatelynch/llm-knowledge-base、notoriouslab/vault-search
> 應用場景：Microsoft Agent Framework 繁體中文教學（28 章 + 4 附錄，約 43 萬字元）

---

## 一、Karpathy LLM Wiki 核心概念

Karpathy 在 2026 年 4 月提出的 LLM Wiki 模式，核心是一個「編譯器類比」：

```
raw/（原始素材） → LLM 編譯 → wiki/（結構化知識）
```

三層架構：

| 層級 | 用途 | 特性 |
|------|------|------|
| `raw/` | 未處理的原始素材（文章、文件、筆記） | 唯讀，不修改 |
| `wiki/` | LLM 編譯後的結構化知識（摘要、概念條目、交叉索引） | 由 LLM 生成與維護 |
| `schema` | 定義結構規則與編譯指引 | 控制編譯品質 |

關鍵操作：`ingest`（攝入新素材）→ `compile`（編譯為 wiki）→ `lint`（偵測矛盾、缺口、過時內容）

與 RAG 的關鍵差異在於：LLM Wiki 是**有狀態的**，知識在編譯階段累積結構化，查詢時直接使用乾淨的摘要與索引；RAG 則每次查詢都從原始文件重新檢索，無累積效果。

---

## 二、你的教學專案現狀分析

### 專案特性

| 項目 | 數值 |
|------|------|
| 檔案數量 | 36 個 Markdown 檔 |
| 總字元數 | ~434,000 |
| 章節結構 | 28 章 + 4 附錄，已有完整目錄與導航 |
| 知識來源 | 官方 GitHub、ADR 文件、DevBlog、範例程式碼 |
| 核心痛點 | 框架 API 快速迭代，教學內容易過時 |

### 已遭遇的具體問題（本次品質檢查為例）

- `AgentThread` → `AgentSession` 全面更名（ADR 0018）
- `RunAsync` 回傳型別變更（`AgentResponse` vs `IAsyncEnumerable`）
- Middleware 簽名變更（`AgentMiddlewareContext` + `AgentMiddlewareDelegate`）
- 章節間導航斷鏈與格式不一致

這些問題的共同特徵是：**上游變更未同步到下游教學內容**。

---

## 三、各工具適配性評估

### 3.1 Karpathy LLM Wiki（原始概念）

**適配度：⭐⭐⭐☆☆（中等）**

Karpathy 的原始情境是「散亂的個人研究筆記 → 結構化 wiki」，你的情境是「已結構化的教學內容 → 需要與上游保持同步」。方向不同，但核心機制可借用。

可行的應用方式：

```
raw/                          ← 上游素材（唯讀）
├── adrs/                     ← Agent Framework ADR 文件
├── github-samples/           ← 官方範例程式碼
├── devblogs/                 ← Microsoft DevBlog 文章
├── api-reference/            ← NuGet 套件 API 摘要
└── release-notes/            ← 版本發行說明

wiki/                         ← LLM 編譯產出
├── index.md                  ← 主索引
├── changelog.md              ← 偵測到的變更摘要
├── concepts/                 ← 概念條目（AgentSession, Middleware, etc.）
└── drift-report.md           ← 教學內容與上游的偏移報告

tutorial/                     ← 你現有的 28 章教學（手動維護）
```

**優勢**：
- `compile` 可自動偵測上游 API 變更
- `lint` 可比對 wiki/ 與 tutorial/ 找出過時內容
- 概念條目提供快速查詢的中間層

**限制**：
- 你的教學已經是高度結構化的最終產物，不是「需要被編譯」的原始素材
- LLM Wiki 的 `compile` 產出的是百科式條目，不是教學敘事
- 需要自行設計 schema 來定義「偏移偵測」規則
- 原始概念未涵蓋「程式碼正確性驗證」

### 3.2 gatelynch/llm-knowledge-base

**適配度：⭐⭐⭐⭐☆（高）**

這是 Karpathy 概念的完整實作，且增加了 `brainstorming/` 和 `artifacts/` 兩層。

```
raw/           → 原始素材
wiki/          → LLM 編譯知識
brainstorming/ → 探索記錄、品質稽核
artifacts/     → 最終作品（= 你的教學章節）
```

四層架構與你的需求高度吻合：

| 層級 | 對應你的需求 |
|------|-------------|
| `raw/` | 官方 ADR、範例、DevBlog |
| `wiki/` | 概念索引、API 變更追蹤 |
| `brainstorming/` | 品質檢查報告（像 REVIEW-beginner-chapters-vs-adr.md） |
| `artifacts/` | 28 章教學本身 |

**已有的實用命令**：
- `/compile` — 處理新的上游素材
- `/health-check` — 稽核 wiki 一致性與缺口
- `/thinking-partner` — 對話式探索（適合規劃新章節）
- `/write-partner` — 基於研究的寫作輔助

**優勢**：
- 為 Claude Code 原生設計，與你的工作流相容
- 四層分離清楚，教學內容歸 artifacts/ 不會被 compile 覆蓋
- `/health-check` 可定期偵測上游偏移
- 支援繁體中文

**限制**：
- 仍需自訂 schema 才能精準偵測 C# API 層級的變更
- 無法自動拉取 GitHub 變更（需手動更新 raw/）
- 缺乏 dotnet build 級的程式碼驗證

### 3.3 notoriouslab/vault-search

**適配度：⭐⭐☆☆☆（低，但可互補）**

這是 Obsidian 語意搜尋外掛，解決的是「在大量筆記中找到相關內容」的問題。

**優勢**：
- 本地 AI embeddings（Ollama），完全離線
- 支援繁體中文（qwen3-embedding）
- Hot/Cold 分析可找出孤立章節
- 語意搜尋比關鍵字搜尋更適合跨概念查找

**限制**：
- 只是搜尋工具，不做知識編譯
- 36 個檔案的規模，Ctrl+F 就夠用
- 無法偵測 API 變更或內容過時
- 需要 Obsidian 環境

**定位**：如果教學擴展到 100+ 檔案，或你有大量個人筆記需要與教學交叉參考，vault-search 可以作為 LLM Wiki 的互補工具。

---

## 四、我的建議方案

你的核心痛點不是「知識散亂需要整理」，而是「教學內容與快速迭代的框架 API 脫節」。純粹的 LLM Wiki 概念需要改造才能真正解決這個問題。

### 推薦方案：混合架構

結合 gatelynch/llm-knowledge-base 的結構 + 自訂的 drift detection 機制：

```
agent-framework-kb/
│
├── raw/                              ← 上游素材（唯讀基準）
│   ├── adrs/                         ← git submodule 或定期同步
│   │   ├── 0018-agentthread-serialization.md
│   │   └── ...
│   ├── api-surface/                  ← dotnet 公開 API 摘要
│   │   └── Microsoft.Agents.AI.md
│   ├── samples/                      ← 官方範例關鍵片段
│   └── release-notes/
│
├── wiki/                             ← LLM 編譯層
│   ├── index.md                      ← 主索引
│   ├── concepts/                     ← 概念條目
│   │   ├── agent-session.md
│   │   ├── middleware-pipeline.md
│   │   └── ...
│   ├── api-changelog.md              ← API 變更時間線
│   └── drift-report.md               ← 教學偏移報告
│
├── brainstorming/                    ← 品質稽核
│   ├── quality-reviews/
│   └── chapter-planning/
│
└── tutorial/                         ← 現有教學（artifacts）
    ├── 01-what-is-agent-framework.md
    ├── ...
    └── appendix-d-proposed-adrs.md
```

### 關鍵自訂工作流

#### 1. `/sync-upstream`（定期執行）

```
1. 拉取最新 ADR 文件（git pull 或手動下載）
2. 擷取 NuGet 套件公開 API 摘要（dotnet public API diff）
3. 抓取最新 Release Notes
4. 放入 raw/ 對應目錄
```

#### 2. `/compile`（素材變更後執行）

```
1. 讀取 raw/ 中的新/修改檔案
2. 更新 wiki/concepts/ 條目
3. 更新 wiki/api-changelog.md
4. 產出差異摘要
```

#### 3. `/drift-check`（核心創新）

```
1. 比對 wiki/concepts/ 中的最新 API 定義
   與 tutorial/ 中的程式碼範例
2. 偵測：
   - 已棄用的類別/方法名稱
   - 簽名不匹配
   - 缺少的新概念
3. 輸出 wiki/drift-report.md：
   - 🔴 breaking：教學範例會編譯失敗
   - 🟡 outdated：內容不反映最新實作
   - 🟢 enhancement：可選的新功能補充
```

#### 4. `/fix-drift`（根據 drift-report 修正）

```
1. 讀取 drift-report.md
2. 逐項修正教學中的程式碼與說明
3. 更新導航與交叉引用
4. 產出修正摘要
```

### 為什麼不直接用純 LLM Wiki？

| 純 LLM Wiki | 混合架構 |
|-------------|---------|
| 把原始素材編譯成 wiki 條目 | 把原始素材編譯成 wiki + **偏移偵測** |
| 產出是百科式知識 | 產出包含針對教學的行動項目 |
| 無程式碼驗證 | 可整合 `dotnet build` 驗證 |
| 被動查詢 | 主動偵測 + 建議修正 |

---

## 五、實作建議與優先順序

### Phase 1：最小可行版（1-2 天）

直接使用 gatelynch/llm-knowledge-base 的框架：

1. Fork llm-knowledge-base
2. 將現有教學放入 artifacts/（或保持現有位置，以 symlink 連結）
3. 將官方 ADR 文件放入 raw/adrs/
4. 撰寫 schema 定義編譯規則（聚焦 C# API 名稱與方法簽名）
5. 執行第一次 `/compile` 建立 wiki/concepts/

### Phase 2：Drift Detection（3-5 天）

1. 撰寫 `/drift-check` 自訂命令
2. 定義偏移規則（類別名稱、方法簽名、NuGet 版本）
3. 建立 CI/CD 或 Scheduled Task 定期執行
4. 整合到你現有的 dotnet-testing-monitor skill

### Phase 3：自動化（可選）

1. GitHub Actions 監控 agent-framework repo 的 ADR 變更
2. 自動觸發 `/sync-upstream` + `/compile` + `/drift-check`
3. 偵測到 🔴 breaking 時發送 Gmail 通知（複用你的 dotnet-testing-monitor 機制）

---

## 六、結論

| 工具 | 建議 | 理由 |
|------|------|------|
| Karpathy LLM Wiki（概念） | ✅ 採用核心架構 | 三層分離 + 編譯模式適合管理上游素材 |
| gatelynch/llm-knowledge-base | ✅ 作為基礎框架 | 最成熟的實作，四層結構與 Claude Code 原生整合 |
| notoriouslab/vault-search | ⏸️ 暫不需要 | 36 檔規模下 grep 已足夠，未來擴展再引入 |
| 自訂 drift-check 機制 | ✅ 必須加入 | 這是你真正的痛點，現成工具都沒有覆蓋 |

**一句話總結**：用 gatelynch/llm-knowledge-base 的骨架管理上游素材，但真正要解決的問題需要自訂一個 `drift-check` 工作流來主動偵測教學內容與框架 API 的偏移。這不是 LLM Wiki 原始設計要解決的問題，但它的架構提供了很好的基礎。
