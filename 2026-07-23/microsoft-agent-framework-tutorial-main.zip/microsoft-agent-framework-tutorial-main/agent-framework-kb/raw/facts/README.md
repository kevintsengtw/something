# raw/facts/ — 事實清單存放區

本目錄存放由 `/extract-facts` 指令產出的「每版本 API 驗證事實 JSON」，以及一次性的工具驗證記錄。

## 檔案命名規則

| 用途 | 檔名格式 | 範例 |
|------|---------|------|
| 每版本事實清單（自動產生） | `dotnet-<version>-verified-changes.json` | `dotnet-1.7.0-verified-changes.json` |
| 工具驗證記錄（人工填寫） | `<tool-name>-validation.md` | `codebase-memory-mcp-validation.md` |
| Python 版（未來） | `python-<version>-verified-changes.json` | `python-2.0.0-verified-changes.json` |

## 為何要 commit 這些檔

1. **審計憑證**：每次 `/compile` 產出的 wiki frontmatter 必須引用某個 facts JSON。Git 紀錄可追溯「這個 API 的事實是哪一天、由哪個工具版本驗證的」。
2. **跨機一致性**：事實層在多機器之間能保持同步；新機器拿到 repo 後不必重跑驗證即可知道事實層的當前狀態。
3. **回退依據**：若 codebase-memory-mcp 工具有 bug，事實清單可作為「當時相信什麼」的歷史記錄。

## 何時產生

- `/extract-facts <version>` —— 上游發布新版本後立即執行（Pipeline A.3）
- 手動執行驗證 —— 首次使用工具、切換 OS、工具版本升級時

## 不 commit 的例外

- 暫時的探測結果（非正式發布版本）—— 改用 `tmp-` 前綴並加入 `.gitignore`
