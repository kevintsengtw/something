---
source: https://github.com/microsoft/agent-framework
fetched: 2026-04-17
type: overview
---

# Microsoft Agent Framework — GitHub README 摘要

## 定位

Comprehensive multi-language framework for building, orchestrating, and deploying AI agents.
支援 .NET 與 Python 雙平台。

## 五大核心功能

1. **Graph-based Workflows** — agents + functions 以資料流連結，支援 streaming、checkpointing、human-in-the-loop、time-travel
2. **AF Labs** — 實驗性套件（benchmarking、reinforcement learning、research）
3. **DevUI** — 互動式開發者介面，用於建構、測試、除錯 workflows
4. **Multi-Language Support** — Python / C# 一致 API
5. **Observability** — 整合 OpenTelemetry 分散式追蹤與監控
6. **Multiple LLM Providers** — 支援多種 LLM 提供者
7. **Middleware System** — 彈性的請求/回應處理管線

## 安裝

```bash
# Python
pip install agent-framework

# .NET
dotnet add package Microsoft.Agents.AI
```

## 統計（截至 2026-04-17）

- 9.5k stars / 1.6k forks / 72 releases
- 語言組成：Python 50.6%, C# 45.3%, TypeScript 3.6%
