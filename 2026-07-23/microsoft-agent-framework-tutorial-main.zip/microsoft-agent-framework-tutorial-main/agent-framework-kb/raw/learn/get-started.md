<!-- source: https://github.com/MicrosoftDocs/semantic-kernel-docs/blob/main/agent-framework/get-started/index.md; fetched: 2026-07-23 -->

---
title: Get started with Agent Framework
description: A step-by-step tutorial to build your first agent and progressively add tools, conversations, memory, workflows, and hosting.
author: eavanvalkenburg
ms.topic: tutorial
ms.author: edvan
ms.date: 07/08/2026
ms.service: agent-framework
---

# Get started with Agent Framework

This tutorial walks you through building an AI agent from scratch, adding one concept at a time. Each step builds on the previous one.

| Step | What you'll learn |
|------|-------------------|
| [Step 1: Your First Agent](your-first-agent.md) | Create an agent, invoke it, and stream the response |
| [Step 2: Add Tools](add-tools.md) | Give the agent a function tool it can call |
| [Step 3: Multi-Turn Conversations](multi-turn.md) | Maintain conversation state with sessions |
| [Step 4: Memory & Persistence](memory.md) | Inject persistent context via context providers |
| [Step 5: Workflows](workflows.md) | Compose a multi-step workflow |
| [Step 6: Agent Harness](harness.md) | Create a harness agent that plans and tracks multi-step tasks |
| [Step 7: Host Your Agent](hosting.md) | Expose the agent via hosting infrastructure |

> [!IMPORTANT]
> The Agent Framework for Go is in public preview. Declarative agents, RAG, CodeAct, and functional workflows are not yet available. File issues on GitHub (https://github.com/microsoft/agent-framework-go/issues).

## Next steps

> [!div class="nextstepaction"]
> [Step 1: Your First Agent](your-first-agent.md)
