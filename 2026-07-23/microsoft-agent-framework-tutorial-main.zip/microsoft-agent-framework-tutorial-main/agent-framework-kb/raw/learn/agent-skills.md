---
source: https://learn.microsoft.com/en-us/agent-framework/agents/skills?pivots=programming-language-csharp
fetched: 2026-04-23
updated_at: 2026-04-22
author: SergeyMenshykh
ms.date: 2026-04-10
---

# Agent Skills — Microsoft Learn 官方文件

## 概述

Agent Skills 是可攜式的指令、腳本與資源套件，賦予代理專業能力與領域知識。Skills 遵循開放規格，實作漸進式揭露（Progressive Disclosure）模式，讓代理只在需要時載入所需內容。

**適用情境：**
- 打包領域專業知識為可重用的可攜式套件
- 在不修改核心指令的情況下擴展代理能力
- 將多步驟任務轉為可重複、可稽核的工作流程
- 在不同 Agent Skills 相容產品間重用同一個 Skill

## Skill 目錄結構

```
expense-report/
├── SKILL.md                          # 必要 — frontmatter + 指令
├── scripts/
│   └── validate.py                   # 代理可執行的腳本
├── references/
│   └── POLICY_FAQ.md                 # 按需載入的參考文件
└── assets/
    └── expense-report-template.md    # 範本與靜態資源
```

### SKILL.md 格式

```yaml
---
name: expense-report
description: File and validate employee expense reports according to company policy.
license: Apache-2.0
compatibility: Requires python3
metadata:
  author: contoso-finance
  version: "2.1"
---
```

| 欄位 | 必要 | 說明 |
|------|------|------|
| `name` | 是 | 最多 64 字元，小寫字母、數字、連字號，必須與父目錄名稱相符 |
| `description` | 是 | 技能用途與使用時機，最多 1024 字元 |
| `license` | 否 | 授權名稱或授權檔案路徑 |
| `compatibility` | 否 | 最多 500 字元，環境需求說明 |
| `metadata` | 否 | 任意 key-value 對應 |
| `allowed-tools` | 否 | 技能可使用的預核准工具（實驗性） |

## 漸進式揭露模式（四階段）

1. **Advertise**（~100 tokens/技能）— 技能名稱與描述在每次 run 開始時注入 system prompt
2. **Load**（建議 < 5000 tokens）— 代理呼叫 `load_skill` 取得完整 SKILL.md
3. **Read resources**（按需）— 代理呼叫 `read_skill_resource` 取得補充資源
4. **Run scripts**（按需）— 代理呼叫 `run_skill_script` 執行技能腳本

> 注意：`load_skill` 一律在 advertise 中，`read_skill_resource` 僅當有資源時，`run_skill_script` 僅當有腳本時。

## 三種技能來源

`AgentSkillsProvider`（C#）支援三種技能來源：
- **File-based** — 從 `SKILL.md` 檔案目錄探索
- **Code-defined** — 透過 `AgentInlineSkill` 在程式碼中內聯定義
- **Class-based** — 繼承 `AgentClassSkill<T>` 的 C# 類別（僅 C#）

---

## C# — File-Based Skills

```csharp
// 單一目錄
var skillsProvider = new AgentSkillsProvider(
    Path.Combine(AppContext.BaseDirectory, "skills"));

// 多個目錄
var skillsProvider = new AgentSkillsProvider(
    [
        Path.Combine(AppContext.BaseDirectory, "company-skills"),
        Path.Combine(AppContext.BaseDirectory, "team-skills"),
    ]);

// 自訂資源探索
var fileOptions = new AgentFileSkillsSourceOptions
{
    AllowedResourceExtensions = [".md", ".txt"],
    ResourceDirectories = ["docs", "templates"],
};
var skillsProvider = new AgentSkillsProvider(
    Path.Combine(AppContext.BaseDirectory, "skills"),
    fileOptions: fileOptions);

// 啟用腳本執行
var skillsProvider = new AgentSkillsProvider(
    Path.Combine(AppContext.BaseDirectory, "skills"),
    SubprocessScriptRunner.RunAsync);

// 自訂腳本探索
var fileOptions = new AgentFileSkillsSourceOptions
{
    AllowedScriptExtensions = [".py"],
    ScriptDirectories = ["scripts", "tools"],
};
```

**SubprocessScriptRunner 內部等效：**
```csharp
static async Task<string> RunAsync(AgentSkill skill, AgentSkillScript script, IDictionary<string, object?>? args)
{
    var psi = new ProcessStartInfo("python3") { RedirectStandardOutput = true, UseShellExecute = false };
    psi.ArgumentList.Add(Path.Combine(skill.Path, script.Path));
    if (args != null)
        foreach (var (key, value) in args)
            if (value is not null) { psi.ArgumentList.Add($"--{key}"); psi.ArgumentList.Add(value.ToString()!); }
    using var process = Process.Start(psi)!;
    string output = await process.StandardOutput.ReadToEndAsync();
    await process.WaitForExitAsync();
    return output.Trim();
}
```

> **警告：** `SubprocessScriptRunner` 僅供示範。生產環境請加入沙箱、資源限制、輸入驗證與稽核日誌。

探索深度：最多兩層。預設資源副檔名：`.md`、`.json`、`.yaml`、`.yml`、`.csv`、`.xml`、`.txt`（在 `references` 和 `assets` 子目錄）。預設腳本副檔名：`.py`、`.js`、`.sh`、`.ps1`、`.cs`、`.csx`（在 `scripts` 子目錄）。

---

## C# — Code-Defined Skills (AgentInlineSkill)

```csharp
// 靜態資源
var codeStyleSkill = new AgentInlineSkill(
    name: "code-style",
    description: "Coding style guidelines and conventions for the team",
    instructions: """
        Use this skill when answering questions about coding style.
        1. Read the style-guide resource for the full set of rules.
        """)
    .AddResource(
        "style-guide",
        """
        # Team Coding Style Guide
        - Use 4-space indentation (no tabs)
        - Maximum line length: 120 characters
        """);

var skillsProvider = new AgentSkillsProvider(codeStyleSkill);

// 動態資源（每次讀取時呼叫 factory）
var projectInfoSkill = new AgentInlineSkill(
    name: "project-info",
    description: "Project status and configuration information",
    instructions: "Use this skill for questions about the current project.")
    .AddResource("environment", () =>
    {
        string env = Environment.GetEnvironmentVariable("APP_ENV") ?? "development";
        string region = Environment.GetEnvironmentVariable("APP_REGION") ?? "us-east-1";
        return $"Environment: {env}, Region: {region}";
    });

// 內聯腳本（in-process，不需 script runner）
var unitConverterSkill = new AgentInlineSkill(
    name: "unit-converter",
    description: "Convert between common units using a conversion factor",
    instructions: """
        Use this skill when the user asks to convert between units.
        1. Review the conversion-table resource to find the correct factor.
        2. Use the convert script, passing the value and factor from the table.
        """)
    .AddResource(
        "conversion-table",
        """
        # Conversion Tables
        Formula: **result = value × factor**
        | From       | To         | Factor   |
        |------------|------------|----------|
        | miles      | kilometers | 1.60934  |
        | kilometers | miles      | 0.621371 |
        | pounds     | kilograms  | 0.453592 |
        | kilograms  | pounds     | 2.20462  |
        """)
    .AddScript("convert", (double value, double factor) =>
    {
        double result = Math.Round(value * factor, 4);
        return JsonSerializer.Serialize(new { value, factor, result });
    });

var skillsProvider = new AgentSkillsProvider(unitConverterSkill);
```

---

## C# — Class-Based Skills (AgentClassSkill\<T\>)

```csharp
using System.ComponentModel;
using System.Text.Json;
using Microsoft.Agents.AI;

internal sealed class UnitConverterSkill : AgentClassSkill<UnitConverterSkill>
{
    public override AgentSkillFrontmatter Frontmatter { get; } = new(
        "unit-converter",
        "Convert between common units using a multiplication factor.");

    protected override string Instructions => """
        Use this skill when the user asks to convert between units.
        1. Review the conversion-table resource to find the correct factor.
        2. Use the convert script, passing the value and factor from the table.
        3. Present the result clearly with both units.
        """;

    [AgentSkillResource("conversion-table")]
    [Description("Lookup table of multiplication factors for common unit conversions.")]
    public string ConversionTable => """
        # Conversion Tables
        Formula: **result = value × factor**
        | From       | To         | Factor   |
        |------------|------------|----------|
        | miles      | kilometers | 1.60934  |
        | kilometers | miles      | 0.621371 |
        | pounds     | kilograms  | 0.453592 |
        | kilograms  | pounds     | 2.20462  |
        """;

    [AgentSkillScript("convert")]
    [Description("Multiplies a value by a conversion factor and returns the result as JSON.")]
    private static string ConvertUnits(double value, double factor)
    {
        double result = Math.Round(value * factor, 4);
        return JsonSerializer.Serialize(new { value, factor, result });
    }
}

// 註冊
var skill = new UnitConverterSkill();
var skillsProvider = new AgentSkillsProvider(skill);
```

> **注意：** `AgentClassSkill<T>` 也支援覆寫 `Resources` 和 `Scripts` 集合，適用於不適合屬性探索的情境。

---

## C# — AgentSkillsProviderBuilder（混合多來源）

```csharp
// 混合三種來源
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "skills"))  // file-based
    .UseSkill(volumeConverterSkill)                                  // AgentInlineSkill
    .UseSkill(temperatureConverter)                                  // AgentClassSkill
    .UseFileScriptRunner(SubprocessScriptRunner.RunAsync)            // file scripts runner
    .Build();

// 技能過濾
var approvedSkillNames = new HashSet<string> { "expense-report", "code-style" };
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "skills"))
    .UseFilter(skill => approvedSkillNames.Contains(skill.Frontmatter.Name))
    .Build();
```

---

## C# — Script Approval（腳本執行人工審批）

```csharp
// 透過建構子
var skillsProvider = new AgentSkillsProvider(
    skillPath: Path.Combine(AppContext.BaseDirectory, "skills"),
    options: new AgentSkillsProviderOptions
    {
        ScriptApproval = true,
    });

// 透過 Builder
var skillsProvider = new AgentSkillsProviderBuilder()
    .UseFileSkill(Path.Combine(AppContext.BaseDirectory, "skills"))
    .UseScriptApproval(true)
    .Build();
```

---

## C# — Dependency Injection

```csharp
// 服務註冊
ServiceCollection services = new();
services.AddSingleton<ConversionService>();
IServiceProvider serviceProvider = services.BuildServiceProvider();

// 傳入 agent
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetResponsesClient()
    .AsAIAgent(
        options: new ChatClientAgentOptions { ... AIContextProviders = [skillsProvider] },
        model: deploymentName,
        services: serviceProvider);

// AgentInlineSkill 使用 DI
var distanceSkill = new AgentInlineSkill(...)
    .AddResource("distance-table", (IServiceProvider sp) =>
    {
        return sp.GetRequiredService<ConversionService>().GetDistanceTable();
    })
    .AddScript("convert", (double value, double factor, IServiceProvider sp) =>
    {
        return sp.GetRequiredService<ConversionService>().Convert(value, factor);
    });

// AgentClassSkill<T> 使用 DI（透過參數注入）
internal sealed class WeightConverterSkill : AgentClassSkill<WeightConverterSkill>
{
    [AgentSkillResource("weight-table")]
    [Description("...")]
    private static string GetWeightTable(IServiceProvider serviceProvider)
        => serviceProvider.GetRequiredService<ConversionService>().GetWeightTable();

    [AgentSkillScript("convert")]
    [Description("...")]
    private static string Convert(double value, double factor, IServiceProvider serviceProvider)
        => serviceProvider.GetRequiredService<ConversionService>().Convert(value, factor);
}

// 透過建構子注入（需在 ServiceCollection 中註冊技能類別）
services.AddSingleton<WeightConverterSkill>();
var weightSkill = serviceProvider.GetRequiredService<WeightConverterSkill>();
```

---

## C# — 其他選項

### 自訂 System Prompt

```csharp
var skillsProvider = new AgentSkillsProvider(
    skillPath: Path.Combine(AppContext.BaseDirectory, "skills"),
    options: new AgentSkillsProviderOptions
    {
        SkillsInstructionPrompt = """
            You have skills available. Here they are:
            {skills}
            {resource_instructions}
            {script_instructions}
            """
    });
```

> 必須包含 `{skills}`、`{resource_instructions}`、`{script_instructions}` 佔位符。大括號需用 `{{` 和 `}}` 跳脫。

### 停用快取

```csharp
var skillsProvider = new AgentSkillsProvider(
    Path.Combine(AppContext.BaseDirectory, "skills"),
    options: new AgentSkillsProviderOptions
    {
        DisableCaching = true,  // 開發期間使用
    });
```

---

## Skills vs. Workflows 選擇指引

| 考量面向 | Agent Skills | Workflows |
|---------|-------------|-----------|
| **控制** | AI 決定執行方式（創意、適應性） | 明確定義執行路徑（確定性） |
| **韌性** | 單一 agent turn，失敗需整個重試 | 支援 checkpointing，可從上次成功步驟恢復 |
| **副作用** | 適合冪等或低風險操作 | 適合有副作用的步驟（發 email、付款） |
| **複雜度** | 單一領域的聚焦任務 | 多步驟業務流程、多代理協調 |

**決策原則：** 想讓 AI 決定「如何」完成任務 → 用 Skills。需要保證「哪些步驟」以何種順序執行 → 用 Workflows。

---

## 安全最佳實踐

- **使用前審查** — 讀取所有技能內容（SKILL.md、腳本、資源），確認腳本行為與宣稱一致
- **來源信任** — 只安裝來自可信作者或已審查內部貢獻者的技能
- **沙箱執行** — 在隔離環境中執行含腳本的技能
- **稽核與記錄** — 記錄哪些技能被載入、哪些資源被讀取、哪些腳本被執行
