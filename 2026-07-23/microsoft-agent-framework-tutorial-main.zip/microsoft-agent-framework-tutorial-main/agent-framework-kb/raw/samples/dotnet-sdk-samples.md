---
source: https://github.com/microsoft/agent-framework/tree/main/dotnet/samples
fetched: 2026-05-15
last_sync_version: dotnet-1.6.1
---

# Agent Framework SDK 內建範例（dotnet/samples）

> 來源：`microsoft/agent-framework` 主 SDK 儲存庫 `dotnet/samples/`
> 授權：MIT
> 注意：此目錄不同於 `microsoft/Agent-Framework-Samples`（獨立示範儲存庫）

## 頂層目錄結構

```
dotnet/samples/
├── 01-get-started/     ← 6 個漸進式入門範例（Program.cs 為主）
├── 02-agents/          ← 17 個代理功能示範目錄
├── 03-workflows/       ← 14 個工作流程示範目錄
├── 04-hosting/         ← 3 個代理部署與主機整合目錄
└── 05-end-to-end/      ← 9 個完整端對端整合範例
```

---

## 01-get-started — 入門六步驟

> 每個範例以 `Program.cs` 為主體，無 README，核心概念皆在程式碼內。

### 01_hello_agent — 建立第一個代理

```csharp
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(instructions: "You are good at telling jokes.", name: "Joker");

// 非串流
Console.WriteLine(await agent.RunAsync("Tell me a joke about a pirate."));

// 串流
await foreach (var update in agent.RunStreamingAsync("..."))
    Console.WriteLine(update);
```

**重點**：`AsAIAgent(instructions:, name:)` 是最簡建立 AIAgent 的擴充方法；支援 `RunAsync`（返回字串）與 `RunStreamingAsync`（IAsyncEnumerable）。

### 02_add_tools — 加入工具（Function Calling）

```csharp
static string GetWeather(string location) => $"The weather in {location} is cloudy.";

AIAgent agent = chatClient.AsAIAgent(
    instructions: "You are a helpful assistant",
    tools: [AIFunctionFactory.Create(GetWeather)]);
```

**重點**：`AIFunctionFactory.Create()` 將普通靜態函式包裝為 AI 工具；`tools:` 陣列直接傳入代理。

### 03_multi_turn — 多輪對話 + Session

```csharp
AIAgent agent = chatClient.AsAIAgent(instructions: "...", name: "Joker");

AgentSession session = await agent.CreateSessionAsync();
Console.WriteLine(await agent.RunAsync("Tell me a joke.", session));
Console.WriteLine(await agent.RunAsync("Add some emojis to the joke.", session));
```

**重點**：`CreateSessionAsync()` 建立 session；在 `RunAsync` 中傳入 session 保持對話脈絡。

### 04_memory — 自訂記憶體元件（AIContextProvider）

```csharp
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    ChatOptions = new() { Instructions = "Always address the user by their name." },
    AIContextProviders = [new UserInfoMemory(chatClient.AsIChatClient())]
});

// Session 序列化與還原
AgentSession session = await agent.CreateSessionAsync();
JsonElement sessionElement = await agent.SerializeSessionAsync(session);
var restored = await agent.DeserializeSessionAsync(sessionElement);

// 透過 GetService<T> 存取記憶體元件
var memory = agent.GetService<UserInfoMemory>();
```

**重點**：
- `AIContextProvider` 抽象類別：覆寫 `StoreAIContextAsync`（儲存觀察到的上下文）與 `ProvideAIContextAsync`（在每次呼叫前提供指令）
- `ProviderSessionState<T>`：跨 session 維護型別安全的狀態，`GetOrInitializeState(session)` / `SaveState(session, value)` / `StateKey` 用於序列化
- `agent.SerializeSessionAsync(session)` 與 `agent.DeserializeSessionAsync(element)` 支援 session 完整序列化，包含記憶體元件狀態
- `agent.GetService<T>()` 從代理取得已附加的服務元件

### 05_first_workflow — 第一個工作流程

```csharp
// 建立執行器
var uppercase = ((Func<string, string>)(s => s.ToUpperInvariant()))
    .BindAsExecutor("UppercaseExecutor");
var reverse = new ReverseTextExecutor();

// 建構工作流程
WorkflowBuilder builder = new(uppercase);
builder.AddEdge(uppercase, reverse).WithOutputFrom(reverse);
var workflow = builder.Build();

// 執行
await using Run run = await InProcessExecution.RunAsync(workflow, "Hello, World!");
foreach (WorkflowEvent evt in run.NewEvents)
{
    if (evt is ExecutorCompletedEvent executorComplete)
        Console.WriteLine($"{executorComplete.ExecutorId}: {executorComplete.Data}");
}
```

**重點**：
- `WorkflowBuilder` 組裝 Executor 與 Edge
- `Executor<TInput, TOutput>` 為自訂執行器基底，覆寫 `HandleAsync`
- `Func<T, T>.BindAsExecutor(name)` 將 Lambda 包裝為執行器
- `InProcessExecution.RunAsync(workflow, input)` 在進程內執行工作流程
- `WorkflowEvent` / `ExecutorCompletedEvent` 用於監聽執行進度
- `Run.NewEvents` 迭代所有產生的事件

### 06_host_your_agent — Azure Functions 代理主機

```csharp
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(instructions: "You are a helpful assistant.", name: "HostedAgent");

using IHost app = FunctionsApplication.CreateBuilder(args)
    .ConfigureFunctionsWebApplication()
    .ConfigureDurableAgents(options => options.AddAIAgent(agent, timeToLive: TimeSpan.FromHours(1)))
    .Build();
app.Run();
```

**重點**：
- `FunctionsApplication.CreateBuilder(args)` 建立 Azure Functions 主機
- `.ConfigureDurableAgents(options => options.AddAIAgent(agent, timeToLive:))` 將代理注入為持久化 Durable Agent
- 自動產生 HTTP API 端點（`POST /api/agents/{agentName}/run`）
- NuGet：`Microsoft.Agents.AI.Hosting.AzureFunctions`

---

## 02-agents — 代理功能示範

### Agents — 20 步驟代理功能系列

| 步驟 | 目錄 | 示範重點 |
|------|------|---------|
| Step01 | `Agent_Step01_UsingFunctionToolsWithApprovals` | 工具呼叫需人工審核（HITL 工具層） |
| Step02 | `Agent_Step02_StructuredOutput` | 結構化輸出（JSON Schema） |
| Step03 | `Agent_Step03_PersistedConversations` | 對話歷史持久化與重載 |
| Step04 | `Agent_Step04_3rdPartyChatHistoryStorage` | 第三方儲存後端（如 Redis、Cosmos DB） |
| Step05 | `Agent_Step05_Observability` | 代理可觀察性基礎（OTel） |
| Step06 | `Agent_Step06_DependencyInjection` | DI 容器注入與解析代理 |
| Step07 | `Agent_Step07_AsMcpTool` | 將代理公開為 MCP 工具 |
| Step08 | `Agent_Step08_UsingImages` | 多模態圖片輸入 |
| Step09 | `Agent_Step09_AsFunctionTool` | 將代理公開為函式工具 |
| Step10 | `Agent_Step10_BackgroundResponsesWithToolsAndPersistence` | 背景回應 + 工具呼叫 + 狀態持久化 |
| Step11 | `Agent_Step11_Middleware` | 使用 Middleware 攔截器 |
| Step12 | `Agent_Step12_Plugins` | Plugin 系統整合 |
| Step13 | `Agent_Step13_ChatReduction` | 對話歷史壓縮（長對話管理） |
| Step14 | `Agent_Step14_BackgroundResponses` | 背景長時間回應（輪詢 + 斷點續傳） |
| Step15 | `Agent_Step15_DeepResearch` | Deep Research Tool（多步驟深度研究） |
| Step16 | `Agent_Step16_Declarative` | 宣告式代理定義 |
| Step17 | `Agent_Step17_AdditionalAIContext` | 多個 AIContextProvider 同時注入 |
| Step18 | `Agent_Step18_CompactionPipeline` | 對話壓縮 Pipeline（有效管理長 context） |
| Step19 | `Agent_Step19_InFunctionLoopCheckpointing` | 函數迴圈內 Checkpointing（崩潰恢復） |
| Step20 | `Agent_Step20_DynamicFunctionTools` | 動態函式工具擴展（`FunctionInvocationContext`） |

**重要模式：**
- `Step13_ChatReduction`：本地維護的對話歷史壓縮策略
- `Step18_CompactionPipeline`：Pipeline 形式的對話壓縮，適合長 session
- `Step19_InFunctionLoopCheckpointing`：每次工具呼叫後持久化，支援崩潰恢復
- `Step20_DynamicFunctionTools`：透過 ambient `FunctionInvocationContext` 在函數迴圈中動態擴充工具清單

### AGUI — AG-UI 協定

- **Server**：`MapAGUI` 建立 SSE 端點，接受 `RunInput`，串流回 AG-UI 事件
- **Client**：`AGUIChatClient` 作為客戶端，`RunStreamingAsync` 接收 SSE 事件流
- 示範 thread 管理、彩色 console 輸出、互動/自動兩種模式

### A2A — Agent-to-Agent 協定（4 個模式）

| 範例 | 說明 |
|------|------|
| `A2AAgent_AsFunctionTools` | 將 A2A 代理的 Skill 對應為函式工具，供其他代理呼叫 |
| `A2AAgent_PollingForTaskCompletion` | 以 continuation token 輪詢長時間任務完成 |
| `A2AAgent_StreamReconnection` | 以 continuation token 在串流中斷後自動重連 |
| `A2AAgent_ProtocolSelection` | `A2AClientOptions` 選擇 HTTP+JSON vs JSON-RPC 協定綁定 |

### AgentOpenTelemetry — OTel + .NET Aspire

- 整合 .NET Aspire Dashboard（Docker）作為 OTel 視覺化後端
- 可選 Application Insights 生產環境監控
- 展示完整追蹤鏈：User Request → Agent Reasoning → Tool Call → Response

### AgentProviders — 各提供者配置

- 針對每種 AIAgent 類型的配置範例

### AgentSkills — 技能系統（5 步驟）

> 已在 `raw/samples/README.md` 中記錄

### AgentWithAnthropic — Anthropic 整合

- 使用 Anthropic Claude 作為 AI 提供者

### AgentWithCodeAct — CodeAct / Hyperlight

| 步驟 | 說明 |
|------|------|
| `Step01_Interpreter` | `HyperlightCodeActProvider` 純 Python 解譯模式（無主機工具） |
| `Step02_ToolEnabled` | 提供者擁有的工具，guest 程式碼透過 `call_tool(...)` 呼叫；含需審核工具 |
| `Step03_ManualWiring` | `HyperlightExecuteCodeFunction` 直接作為代理工具（固定沙箱配置） |

環境變數：`HYPERLIGHT_PYTHON_GUEST_PATH`（Hyperlight Python guest module 路徑）

### AgentWithMemory — 記憶體元件

- 與 `01-get-started/04_memory` 類似但更完整的記憶體範例

### AgentWithOpenAI — OpenAI Exchange 型別

- 使用 OpenAI 原生交換型別（非 MEAI 包裝層）

### AgentWithRAG — RAG 檢索增強

- 代理整合向量資料庫的 RAG 模式

### AgentsWithFoundry — Foundry 代理

```csharp
// 直接建立 FoundryAgent
FoundryAgent agent = new(
    new Uri(endpoint),
    new AzureCliCredential(),
    model: "gpt-5.4-mini",
    instructions: "You are good at telling jokes.",
    name: "JokerAgent");

// 透過 AIProjectClient 建立
FoundryAgent agent = new AIProjectClient(new Uri(endpoint), new DefaultAzureCredential())
    .AsAIAgent(model: deploymentName, instructions: "...", name: "JokerAgent");
```

環境變數：`AZURE_AI_PROJECT_ENDPOINT`、`AZURE_AI_MODEL_DEPLOYMENT_NAME`

### DeclarativeAgents — YAML 宣告式代理

- 從 YAML 配置載入並執行代理

### DevUI — 開發者 UI

- 互動式瀏覽器 UI，用於開發期間測試與除錯代理

### Evaluation — 代理評估

- 代理評測框架整合

### Harness — 代理 Harness（管理代理架構）

- 展示如何建立 Agent Harness，包含內建 planning、todo、mode management 工具

### ModelContextProtocol — MCP 整合

| 範例 | 說明 |
|------|------|
| `Agent_MCP_Server` | 使用 MCP 伺服器工具與代理 |
| `Agent_MCP_Server_Auth` | 受保護 MCP 伺服器（含認證） |
| `ResponseAgent_Hosted_MCP` | Hosted MCP Tool 與 Responses Service（服務端直接呼叫 MCP 工具） |

---

## 03-workflows — 工作流程示範

### _StartHere — 基礎概念（必讀 7 步驟）

| 步驟 | 目錄 | 核心概念 |
|------|------|---------|
| 01 | `01_Streaming` | 工作流程串流事件（`IAsyncEnumerable<WorkflowEvent>`） |
| 02 | `02_AgentsInWorkflows` | 在工作流程中使用 AIAgent 作為 Executor |
| 03 | `03_AgentWorkflowPatterns` | 常見代理工作流程模式（Reflection、自我批評等） |
| 04 | `04_MultiModelService` | 同一工作流程中使用多個 AI 服務 |
| 05 | `05_SubWorkflows` | Sub-Workflow（子工作流程作為 Executor 嵌入） |
| 06 | `06_MixedWorkflowAgentsAndExecutors` | Agent + Executor 混合模式（Adapter 型別轉換） |
| 07 | `07_WriterCriticWorkflow` | 迭代精煉模式：最大迭代保護、多訊息 Handler、條件路由回饋 |

### Agents — 進階代理工作流程

| 目錄 | 說明 |
|------|------|
| `FoundryAgent` | Microsoft Foundry 代理在工作流程中的整合 |
| `CustomAgentExecutors` | 自訂 Agent Executor（複雜場景） |
| `WorkflowAsAnAgent` | 工作流程封裝為代理 |
| `GroupChatToolApproval` | 多代理群聊 + 工具審核（HITL） |

### Checkpoint — 工作流程 Checkpointing

- 工作流程狀態的持久化與恢復

### Concurrent — 並行執行

- Fan-Out / Fan-In 平行處理模式

### ConditionalEdges — 條件邊

| 目錄 | 說明 |
|------|------|
| `01_EdgeCondition` | 基礎條件邊（根據輸出動態路由） |
| `02_SwitchCase` | Switch-Case 多路路由 |
| `03_MultiSelection` | 多選路由（一個 Executor 觸發多個下游） |

### HumanInTheLoop — 工作流程 HITL

- 工作流程中的人工審核節點

### Loop — 迴圈工作流程

- 在工作流程中建立迴圈

### Observability — 工作流程可觀察性

- 工作流程追蹤與監控

### Orchestration — 編排模式

- `Handoff` 交接編排模式（Multi-Agent Handoff）

### SharedStates — 共享狀態

- Executor 間的共享狀態協調

### Visualization — 工作流程視覺化

- 工作流程圖形視覺化

---

## 04-hosting — 代理主機整合

### DurableAgents — 持久化代理主機

```
DurableAgents/
├── AzureFunctions/     ← Azure Functions 主機（對應 01-get-started/06_host_your_agent）
└── ConsoleApps/        ← Console App 中的 Durable Agents 示範
```

**Azure Functions 關鍵 API**：
- `FunctionsApplication.CreateBuilder(args).ConfigureDurableAgents(opt => opt.AddAIAgent(agent, timeToLive:))`
- NuGet：`Microsoft.Agents.AI.Hosting.AzureFunctions`
- 自動生成 REST API 端點供外部呼叫

### DurableWorkflows — 持久化工作流程主機

- 工作流程的持久化主機整合

### FoundryHostedAgents — Foundry 雲端主機

- 在 Microsoft Foundry 服務上託管代理

---

## 05-end-to-end — 端對端整合範例

### A2AClientServer — A2A 完整客戶端與伺服器

- 三個 A2A 伺服器實例（Invoice、Policy、Logistics 代理）
- A2A 客戶端 CLI 透過 A2A 協定呼叫遠端代理
- 支援 ChatCompletion 代理或 Azure AI Foundry 代理
- 使用官方 A2A C# SDK

### AGUIClientServer — AG-UI 完整示範

```
AGUIClientServer/
├── AGUIClient/         ← AG-UI 客戶端
├── AGUIDojoServer/     ← AG-UI 示範伺服器
└── AGUIServer/         ← AG-UI 伺服器
```

### AGUIWebChat — AG-UI Web Chat UI

- 完整的網頁聊天 UI 整合

### AgentWebChat — 代理網頁聊天

- 代理的網頁 Chat UI

### AgentWithPurview — Azure Purview 整合

- 代理整合 Azure Purview（資料治理）

### AspNetAgentAuthorization — ASP.NET 認證授權

- 代理端點的認證與授權配置

### DevUIAspireIntegration — DevUI + Aspire

- Dev UI 與 .NET Aspire 的整合（分散式追蹤）

### Evaluation — 端對端評測

- 完整代理系統的評測場景

### M365Agent — Microsoft 365 代理

- Teams、Copilot 等 M365 產品的代理整合

---

## 與 wiki/concepts 的對應關係

| 範例中的 API / 模式 | 對應 wiki 概念 |
|---------------------|---------------|
| `AsAIAgent()` / `RunAsync()` / `RunStreamingAsync()` | [[ai-agent]], [[run-async]] |
| `AIFunctionFactory.Create()` | [[tools-ai-function]] |
| `CreateSessionAsync()` | [[agent-session]] |
| `SerializeSessionAsync()` / `DeserializeSessionAsync()` | [[agent-session]], [[chat-history-persistence]] |
| `AIContextProvider` / `ProviderSessionState<T>` | [[context-providers]], [[provider-session-state]] |
| `GetService<T>()` | [[ai-agent]] |
| `WorkflowBuilder` / `Executor<T,T>` / `InProcessExecution` | [[workflows]] |
| `FunctionsApplication.ConfigureDurableAgents()` | [[durable-agents]] |
| `FoundryAgent` / `AIProjectClient.AsAIAgent()` | [[llm-providers]] |
| `HyperlightCodeActProvider` | [[codeact-integration]] |
| `MapAGUI` / `AGUIChatClient` | [[ag-ui-protocol]] |
| A2A ProtocolSelection / StreamReconnection | [[a2a-protocol]] |
| OTel + Aspire Dashboard | [[opentelemetry]] |
| MCP Hosted Tool (Responses Service) | [[mcp-integration]] |
| `Step13/18` 對話壓縮 | [[chat-history-persistence]] |
| `Step19` In-function-loop Checkpointing | [[durable-agents]], [[tools-ai-function]] |
| `Step20` Dynamic Function Tools | [[tools-ai-function]] |
| `Step15` Deep Research Tool | [[tools-ai-function]] |
| AGUI WebChat / WebChat end-to-end | [[ag-ui-protocol]] |
| A2A end-to-end ClientServer | [[a2a-protocol]] |

## 已在 raw/samples/README.md 中記錄的項目（不重複）

- `AgentSkills`（5 步驟技能系統）
- `DynamicToolExpansion`（動態工具擴展）
- `hosted-files`（AgentSessionFiles）
- `03-workflows/Declarative/InvokeHttpRequest`（HttpRequestAction）
- `06.RAGs/AzureAISearch`（Azure AI Search RAG）
