---
source: https://github.com/microsoft/Agent-Framework-Samples
fetched: 2026-05-14
last_sync_version: dotnet-1.6.1
---

# Agent Framework Samples 官方範例庫

> 來源：`microsoft/Agent-Framework-Samples`
> 授權：MIT

## 範例目錄總覽

| 目錄 | 主題 | .NET | Python | 對應教學章節 |
|------|------|------|--------|-------------|
| 00.ForBeginners | 入門範例（Travel Agent、Tool Use、RAG、Multi-Agent） | — | ✅ | ch01, ch05, ch07–ch10 |
| 01.AgentFoundation | 代理基礎概念（文件說明） | — | — | ch01, ch02 |
| 02.CreateYourFirstAgent | 建立第一個 Travel Agent | ✅ | ✅ | ch04 |
| 03.ExploerAgentFramework | 多提供者整合（Azure OpenAI、GitHub Models、Foundry、Foundry Local） | ✅ | ✅ | ch03, ch17 |
| 04.Tools | Vision、Code Interpreter、Bing Grounding、File Search | ✅ | ✅ | ch05, ch08 |
| 05.Providers | MCP 整合、A2A 通訊 | ✅ | ✅ | ch23, ch25 |
| 06.RAGs | File Search RAG | ✅ | ✅ | ch08 |
| 07.Workflow | Basic、Sequential、Concurrent、Conditional 四種工作流程 | ✅ | ✅ | ch18, ch19 |
| 08.EvaluationAndTracing | DevUI 視覺化、Observability、Aspire Tracer | ✅ | ✅ | ch22, ch28 |
| 09.Cases | 實戰案例（Marketing、Travel、FoundryLocal Pipeline、Harness） | ✅ | ✅ | 進階綜合 |

## 各範例詳細說明

### 03.ExploerAgentFramework — 多提供者整合

四種 AI 服務的連線方式：

1. **Azure OpenAI Service**：`AzureOpenAIClient` + `AzureCliCredential`，透過 `CreateAIAgent` 擴充方法建立代理
2. **GitHub Models**：OpenAI 相容端點，使用 `OpenAIClient` + token 認證
3. **Azure AI Foundry**：`PersistentAgentsClient` 建立持久化有狀態代理，對話透過 thread 管理
4. **Foundry Local**：本地 OpenAI 相容伺服器（`http://localhost:5272/v1`）

### 04.Tools — 工具整合

四種 Azure AI Foundry 工具：

1. **Vision（gpt-4o）**：圖片解析與建議
2. **Code Interpreter**：程式碼執行（Fibonacci 等數學計算）
3. **Bing Search**：即時網路資訊（需 `BING_CONNECTION_ID`）
4. **File Search**：文件 RAG 檢索

### 05.Providers — MCP 與 A2A

- **MCP（Model Context Protocol）**：標準化工具發現與互動協定，Agent 可動態發現外部工具端點
- **A2A（Agent-to-Agent）**：代理間通訊，支援 Manager/Worker 階層、專家諮詢、協作問題解決

#### v1.3.0 A2A 範例更新（原 `04-hosting/A2A/` → `02-agents/A2A/`）

| 範例 | 說明 |
|------|------|
| `A2AAgent_ProtocolSelection`（新增） | 示範 A2A 協定選擇（HTTP vs SSE） |
| `A2AAgent_StreamReconnection`（新增） | 示範 SSE 串流中斷後以 continuation token 自動重連 |
| `A2AClientServer`（更新） | 使用新 A2A v1 SDK API |
| `AgentWebChat`（更新） | 使用新 A2A v1 SDK API |
| `A2AAgent_PollingForTaskCompletion`（更新） | 使用新 A2A v1 SDK API |

### 07.Workflow — 工作流程編排

四種工作流程模式：

1. **Basic Sequential**：FrontDesk → Concierge 直線傳遞
2. **Multi-Step Sequential**：Sales → Price → Quote 三階段流水線
3. **Concurrent**：Researcher + Planner 平行 fan-out → fan-in 彙整
4. **Conditional**：ContentReviewer 根據結果動態分支（Publisher / 退回修改）

核心架構：Executors（處理單元）+ Edges（訊息路徑，含條件）+ Workflow（編排引擎）

### 08.EvaluationAndTracing — 評估與追蹤

- **DevUI**：瀏覽器即時視覺化，追蹤 Session、訊息、Tool Calls、LLM 回應
- **Observability**：整合標準 logging，捕獲 User Request → Agent Reasoning → Tool Invocation → Final Response
- **Aspire Tracer**：分散式追蹤整合

### 09.Cases — 實戰案例

1. **AgenticMarketingContentGen**：多階段行銷內容生成（策略 → 文案 → 多媒體素材）
2. **GHModel.AI**：雙代理旅遊助理（FrontDesk + Concierge）+ DevUI 視覺除錯
3. **FoundryLocalPipeline**：本地模型深度研究 + Red Teaming 評估
4. **MicrosoftFoundryWithAITKAndMAF**：從 Foundry 低程式碼設計 → VS Code 同步 → MAF 部署
5. **maf_harness_managed_agent**：Managed Agent 架構（Harness + SessionLog + Sandbox）

## 與教學的關鍵對應

## 02-agents/AgentSkills — 五步驟技能系統範例

> 來源：`https://github.com/microsoft/agent-framework/tree/main/dotnet/samples/02-agents/AgentSkills`
> 抓取：2026-04-23

| 步驟 | 目錄 | 示範重點 |
|------|------|---------|
| Step 01 | `Agent_Step01_FileBasedSkills` | `SKILL.md` 檔案式技能 + 參考文件，unit-converter 範例 |
| Step 02 | `Agent_Step02_CodeDefinedSkills` | `AgentInlineSkill` 內聯技能，靜態/動態資源與腳本 |
| Step 03 | `Agent_Step03_ClassBasedSkills` | 繼承 `AgentClassSkill<T>` 的類別式技能 |
| Step 04 | `Agent_Step04_MixedSkills` | `AgentSkillsProviderBuilder` 混合三種來源 |
| Step 05 | `Agent_Step05_SkillsWithDI` | DI 整合（`AgentInlineSkill` + `AgentClassSkill<T>`） |
| Step 25 | `Agent_Step25_ToolboxServerSideTools`（v1.3.0 新增；**v1.6.1 已移除**） | ~~Foundry Toolbox server-side tools 整合，使用 `AIProjectClient.GetToolboxAsync()`~~ 此 API 於 v1.6.1 移除，範例已廢棄 |

共用工具：`SubprocessScriptRunner.cs`（檔案式腳本以 subprocess 執行）

## 02-agents/DynamicToolExpansion（v1.3.0 新增）

示範如何透過另一個工具呼叫動態擴展可用工具清單。適合需要在執行期動態增加工具的場景。

## 02-agents/hosted-files（v1.6.1 新增）

> 對應功能：`AgentSessionFiles` SDK 整合 + 整合測試

示範在代理工作階段中使用 `AgentSessionFiles` 進行檔案上傳與存取管理（hosted files 機制）。

## 06.RAGs/AzureAISearch（v1.6.1 新增）

> 對應功能：RAG + Azure AI Search 整合

使用 Azure AI Search 作為知識庫的 RAG 實作範例，展示如何在代理中整合向量搜尋檢索。

## 03-workflows/Declarative/InvokeHttpRequest（v1.4.0 新增）

> 來源：`https://github.com/microsoft/agent-framework/tree/main/dotnet/samples/03-workflows/Declarative/InvokeHttpRequest`
> 對應功能：PR #5474（`HttpRequestAction`）、PR #5572（範例）

宣告式工作流程中使用 `HttpRequestAction` 步驟型別，直接在 YAML/JSON 定義中配置 HTTP 呼叫，無需撰寫 C# 工具程式碼。

## 02-agents/AgentSkills — v1.4.0 Breaking Change

`file-based skill scripts`（`Agent_Step01_FileBasedSkills`）的參數型別改為 `string[]`。原先以單一字串傳入參數的腳本呼叫需改為陣列形式（PR #5475 Breaking）。

## 與教學的關鍵對應

| 範例中的 API 用法 | 對應 wiki 概念 |
|-------------------|---------------|
| `chatClient.AsAIAgent()` / `CreateAIAgent` | [[ai-agent]] |
| `AzureOpenAIClient` / `OpenAIClient` | [[chat-client]], [[llm-providers]] |
| `PersistentAgentsClient` | [[llm-providers]]（Foundry） |
| `AIFunctionFactory.Create()` | [[tools-ai-function]] |
| `WorkflowBuilder` + Executors + Edges | [[workflows]] |
| MCP tool discovery | [[mcp-integration]] |
| A2A agent communication | [[a2a-protocol]] |
| DevUI + Observability | [[opentelemetry]], [[agent-evaluation]] |
| File Search RAG | [[tools-ai-function]]（retrieval） |
| `AgentSkillsProvider` / `AgentSkillsProviderBuilder` | [[agent-skills]] |
| `AgentClassSkill<T>` / `AgentInlineSkill` | [[agent-skills]] |
