---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.6.1
fetched: 2026-05-14
release_date: 2026-05-14
version: 1.6.1
---

# .NET Agent Framework v1.6.1（2026-05-14）

## 重大變更（Breaking Changes）

### 1. OpenTelemetryAgent 自動包裝 ChatClient

`OpenTelemetryAgent` 現在會自動將 `ChatClient` 以 `OpenTelemetryChatClient` 包裝。若既有程式碼已手動加入 OpenTelemetry 儀器化，可能導致雙重儀器化（double instrumentation）。

**影響範圍：** 使用 `OpenTelemetryAgent` 且手動配置 `OpenTelemetryChatClient` 的 .NET 專案。

---

### 2. Foundry Toolbox server-side tools 支援移除

移除 Foundry Toolbox 的 server-side tools 支援，相關 API（`AIProjectClient.GetToolboxAsync()`）不再可用。

**影響範圍：** 使用 Foundry Toolbox server-side tools 的專案（對應 samples 的 `Agent_Step25_ToolboxServerSideTools`）。

**因應方式：** 改用 client-side tool 定義方式，透過 `AIFunctionFactory.Create()` 自行定義工具。

---

### 3. DevUI 存取控制與 CORS 政策收緊（Python）

**影響範圍：** Python 僅

DevUI HTTP 介面的存取控制與 CORS 設定更嚴格，預設不再允許跨來源請求。

---

### 4. File Skill 資料夾探索對齊 agentskills.io 規範（Python）

**影響範圍：** Python 僅

File-based skills 的目錄探索行為改為符合 [agentskills.io](https://agentskills.io) 規範。

---

## 新功能

### IChatMessageInjector — 函數迴圈訊息注入介面

**命名空間：** `Microsoft.Agents.AI`

新介面 `IChatMessageInjector`，允許在代理執行函數呼叫迴圈（function loop）期間動態注入額外訊息。

**典型使用場景：** 在工具呼叫之間插入系統提示補充、加入追蹤訊息、實作稽核日誌。

---

### Shell Tool（.NET）

新增 .NET 端的 Shell Tool 功能，允許代理執行本地 shell 命令作為工具呼叫。

---

### A2A input-request 內容支援（Human-in-the-loop）

A2A（Agent-to-Agent）協定新增 `input-request` 內容類型支援，代理可以在工作流程執行期間暫停並請求人工輸入（human-in-the-loop），改善互動式多代理場景的彈性。

---

### AgentSessionFiles — 代理工作階段檔案管理

新增 `AgentSessionFiles` SDK 配套功能，與 hosted-files 機制整合，支援在代理工作階段中上傳、存取、管理檔案。

---

### Harness Agent 套件

新增 Harness Agent 套件（`maf_harness_managed_agent` 相關），完善 Managed Agent 的測試與封裝工具鏈。

---

## 改進

| 項目 | 說明 |
|------|------|
| FoundryAgent URL 路由 | 修正嚴格 URL 路由處理，解決端點配置問題 |
| MSBuild 並行輸出 | 消除 Foundry.Hosting 整合測試中的 race condition |
| ClientHeadersScope | 使用 `AsyncLocal` 還原機制簡化標頭範圍管理 |
| 每服務輸入持久化 | 修正串流錯誤時的輸入持久化問題 |
| DevUI 存取控制 | HTTP 介面新增可配置的存取控制選項 |
| Anthropic Extensions AI | 版本對齊更新 |
| Harness 主控台渲染 | 重構主控台輸出渲染邏輯 |

---

## Bug 修復

| 問題 | 說明 |
|------|------|
| Handoff FunctionResult 傳遞 | 修正合成的 handoff `FunctionResult` 無法正確傳遞至代理的問題 |
| OpenAIResponsesAgentClient 端點路徑 | 修正 endpoint path 錯誤 |
| Handoff 訊息 role 變異 | 防止 handoff 過程中訊息 role 被意外修改 |
| DevUI CA1873 建置警告 | 修正 DevUI 的 CA1873 程式碼分析警告 |

---

## 新增範例（Samples）

| 範例 | 說明 |
|------|------|
| `hosted-files`（新增） | `AgentSessionFiles` SDK 整合，含整合測試 |
| RAG + Azure AI Search（新增）| 使用 Azure AI Search 的 RAG 實作範例 |

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 | 嚴重性 |
|------|---------------|--------|
| OpenTelemetryAgent 自動包裝 ChatClient | `agent-opentelemetry`、`chat-client` | 🔴 Breaking |
| Foundry Toolbox server-side tools 移除 | `foundry-toolbox`（需標記廢棄） | 🔴 Breaking |
| IChatMessageInjector 新介面 | 需新建 `chat-message-injector` 條目 | 🟢 新功能 |
| Shell Tool | `tools-ai-function` | 🟢 新功能 |
| A2A input-request 支援 | `a2a-protocol` | 🟢 Enhancement |
| AgentSessionFiles | 需新建 `agent-session-files` 條目 | 🟢 新功能 |
| RAG + Azure AI Search 範例 | `tools-ai-function`（retrieval） | 🟢 Enhancement |

---

## 貢獻者

本版本共 29 項更新，由 @westey-m 主導發佈。
