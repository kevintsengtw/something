---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.0.0
fetched: 2026-04-17
type: release-notes
version: 1.0.0
platform: dotnet
---

# dotnet-1.0.0（GA）

**Release Date:** 2026-04-02
**Released by:** @dmytrostruk
**Commit:** c798cb7

## Key Changes（from RC5）

- **Handoff Orchestrations marked experimental** ([#5065](https://github.com/microsoft/agent-framework/pull/5065))
- **Azure.AI.Projects bumped to 2.0.0 GA** ([#5060](https://github.com/microsoft/agent-framework/pull/5060))
- **Google.GenAI compatibility** updated for M.E.AI 10.4.0+ ([#5061](https://github.com/microsoft/agent-framework/pull/5061))
- **InputWait timeout removed** from OffThread execution ([#4996](https://github.com/microsoft/agent-framework/pull/4996))

## Breaking Changes

- **Package rename**: `Microsoft.Agents.AI.AzureAI` → `Microsoft.Agents.AI.Foundry` ([#5042](https://github.com/microsoft/agent-framework/pull/5042))
- **Class removed**: `OpenAIAssistantClientExtensions` ([#5058](https://github.com/microsoft/agent-framework/pull/5058))
- **Class renamed**: `ServiceStoredSimulatingChatClient` → `PerServiceCallChatHistoryPersistingChatClient` ([#4993](https://github.com/microsoft/agent-framework/pull/4993))

## Samples & Documentation

- Updated samples to use Microsoft Foundry ([#5032](https://github.com/microsoft/agent-framework/pull/5032))
- Unified devui samples ([#5025](https://github.com/microsoft/agent-framework/pull/5025))
- Added verify-samples tool and skill ([#5005](https://github.com/microsoft/agent-framework/pull/5005))
- Added Neo4j GraphRAG samples ([#4994](https://github.com/microsoft/agent-framework/pull/4994))
- Updated branding from Semantic Kernel to Agent Framework ([#5001](https://github.com/microsoft/agent-framework/pull/5001))
- Enhanced README with architecture overview ([#5002](https://github.com/microsoft/agent-framework/pull/5002))

## Bug Fixes

- Telemetry sample bug ([#5037](https://github.com/microsoft/agent-framework/pull/5037))
- RequestInfoEvent loss during checkpoint resumption ([#4955](https://github.com/microsoft/agent-framework/pull/4955))
- Azure AI Search initialization ([#5021](https://github.com/microsoft/agent-framework/pull/5021))
