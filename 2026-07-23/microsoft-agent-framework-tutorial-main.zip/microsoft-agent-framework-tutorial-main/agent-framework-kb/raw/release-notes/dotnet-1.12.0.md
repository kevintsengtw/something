---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.12.0
fetched: 2026-07-05
release_date: 2026-07-02
version: 1.12.0
tag_commit: e7c7f74
---

# .NET Agent Framework v1.12.0（2026-07-02）

## Breaking Changes（.NET）

### 1. Foundry.Hosting 實驗性旗標對齊 MAAI001

**PR：** [#6743](https://github.com/microsoft/agent-framework/pull/6743)

MAF 專屬的 Foundry.Hosting API 的 `[Experimental]` 診斷 ID 統一改為 `MAAI001`。屬 Foundry hosting 子系統，教學未示範。

### 2. 從 AgentSkillsProvider 抽離快取為 CachingAgentSkillsSource

**PR：** [#6768](https://github.com/microsoft/agent-framework/pull/6768)

原本內建於 `AgentSkillsProvider` 的技能快取邏輯，抽離為獨立的 decorator 型別 `CachingAgentSkillsSource`（`Microsoft.Agents.AI.Skills.Decorators`）。**`AgentSkillsProviderOptions.DisableCaching` 屬性已移除**——快取改由 source 端組合。**影響第 29 章**（第 29 章原本在小結列出 `DisableCaching` 為進階選項）。

### 3. Azure.AI.AgentServer 升至 2.0.0 協定 + Foundry.Hosting 遷移

**PR：** [#6800](https://github.com/microsoft/agent-framework/pull/6800)

`Azure.AI.AgentServer` 相依升至 2.0.0 協定，並遷移 Foundry.Hosting。屬 hosting 子系統，教學未示範。

---

## 新功能與增強（.NET）

| 項目 | PR | 說明 |
|------|-----|------|
| `BackgroundTaskCompletionLoopEvaluator` | [#6736](https://github.com/microsoft/agent-framework/pull/6736) | Harness 背景代理的迴圈完成評估器（`Microsoft.Agents.AI.Harness.Loop`）。教學未示範 Harness loop |
| Foundry hosted-agent toolbox OAuth consent | [#6718](https://github.com/microsoft/agent-framework/pull/6718) | Foundry hosting 子系統 |
| Skill body 的 resource/script 元素加入 description 屬性 | [#6759](https://github.com/microsoft/agent-framework/pull/6759) | SKILL.md 資源/腳本可帶說明文字 |
| GitHub Copilot provider 以 OnPreToolUse hook 強制 ApprovalRequiredAIFunction | [#6674](https://github.com/microsoft/agent-framework/pull/6674) | Copilot provider 內部 |
| Aspire DevUI 後端優先採 HTTPS | [#6772](https://github.com/microsoft/agent-framework/pull/6772) | DevUI |
| NuGet 套件圖示更新為新 Microsoft Agent Framework logo | [#6812](https://github.com/microsoft/agent-framework/pull/6812) | 包裝 |

---

## Bug 修復（.NET）

| 問題 | PR | 說明 |
|------|-----|------|
| workflow outputs 參數 XML 文件錯字 | [#6326](https://github.com/microsoft/agent-framework/pull/6326) | 文件修正（@marcominerva 首次貢獻） |
| DevUI aggregator proxy target 驗證改善 | [#6771](https://github.com/microsoft/agent-framework/pull/6771) | DevUI |
| GitHubCopilotAgent CA1873（改用 LoggerMessage sourcing） | [#6814](https://github.com/microsoft/agent-framework/pull/6814) / [#6815](https://github.com/microsoft/agent-framework/pull/6815) | 分析器修正 |
| 停用失敗的 DurableTask 與 AzureFunctions 整合測試 | [#6774](https://github.com/microsoft/agent-framework/pull/6774) | 測試 |
| Sample 修正 | [#6773](https://github.com/microsoft/agent-framework/pull/6773) | 範例 |

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 | 嚴重性 |
|------|---------------|--------|
| CachingAgentSkillsSource 抽離、`DisableCaching` 移除 | `agent-skills` | 🔴 Breaking（影響 ch29 小結） |
| skill resource/script description 屬性 | `agent-skills` | 🟢 Enhancement |
| BackgroundTaskCompletionLoopEvaluator | （Harness，無對應教學條目） | 🟢 Enhancement |
| Foundry.Hosting MAAI001 / AgentServer 2.0.0 | （hosting，無對應教學條目） | 🟢 內部 |
