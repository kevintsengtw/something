---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.5.0
fetched: 2026-05-08
release_date: 2026-05-08
version: 1.5.0
---

# .NET Agent Framework v1.5.0（2026-05-08）

## 重大變更（Breaking Changes）

本版本無明確列出的 Breaking Changes。

---

## 新功能

### Magentic Orchestration（實驗性，PR #5595、#5704）

**命名空間：** `Microsoft.Agents.AI.Workflows.Specialized.Magentic`

**標記：** Experimental（`[Experimental]` 屬性）

實作以管理員驅動（manager-driven）的規劃迴圈，讓多個代理組成「任務解決團隊」。核心設計：由中央 Orchestrator 進行智慧任務規劃，並動態路由到適當的代理。

新增類別：

| 類別 | 說明 |
|------|------|
| `MagenticOrchestrator` | 核心編排迴圈，管理規劃與執行 |
| `MagenticManager` | 管理員代理，負責建立計畫與更新帳本 |
| `MagenticProgressLedger` | 任務進度狀態管理 |
| `MagenticTaskContext` | 任務狀態匯出（含計數器與限制） |
| `MagenticWorkflowBuilder` | 流式 API，組裝 Magentic 工作流程 |
| `MagenticOrchestratorEvent` | 編排事件型別 |
| `MagenticPlanReviewRequest/Response` | 計畫審閱請求/回應 |

**特性：** 比 Graph-based Workflows 更高層次的抽象；AI 自行規劃任務分配，無需手動定義路由圖。

---

### AG-UI 支援推理事件（PR #4953）

AG-UI 協定新增推理事件（Reasoning Events）支援，代理在推理過程中可以透過 AG-UI 串流推理步驟。

---

### 訊息過濾（PR #5410）

新增機制，過濾並排除不可攜帶的內容類型（non-portable content types）。

---

### WebBrowsingTool 白名單（PR #5605）

`WebBrowsingTool` 新增 allow listing 功能，可限制代理可瀏覽的網域範圍。

---

### Todo 多執行緒支援（PR #5655）

改善 Todo 的多執行緒安全性，並支援將 Todo 注入訊息列表。

---

## Bug 修復

### YAML block scalar 解析修正（File Skills，PR #5610）

**重要性：** 影響 Agent Skills 的 File-Based 技能使用者

**修復前**：`SKILL.md` frontmatter 中使用 `|`（literal）或 `>`（folded）多行值時，解析器只讀取符號本身，實際內容被丟棄。

**修復後**：正確解析所有 YAML block scalar 語法：
- `|`（literal）：保留換行符
- `>`（folded）：將換行符折疊為空格
- `|-`、`|+`、`>-`、`>+`：正確處理尾端換行（chomping）

**影響範圍：** 只影響在 frontmatter 中使用多行 block scalar 語法的技能。標準的單行 `description: "..."` 格式不受影響。本修復為 bug fix，無 API 變更。

**示例（修復後可正常使用）：**
```yaml
---
name: hr-leave
description: |
  Answer questions about company leave policy
  including annual leave, sick leave, and special leave.
license: MIT
---
```

---

### 其他 Bug 修復

| PR | 問題 |
|----|------|
| #5653 | MultiPartyConversation 的 JSON 序列化問題 |
| #5635 | QuestionExecutor 在 GotoAction 重新進入後的無限迴圈 |
| #5320 | 序列號生成的執行緒安全問題（防止重複/亂序 ID） |
| #5705 | `function_call_output.output` 在網路層改為 JSON 字串格式 |
| #5656 | Workflows 缺少 Shared 來源檔案 |

---

## 基礎架構更新

| 更新 | 說明 |
|------|------|
| MEAI 10.5.1（PR #5652） | 新增 Foundry 每次呼叫的 x-client 標頭支援 |
| GitHub Copilot SDK 1.0.0-beta.2（PR #5699） | 更新 Copilot SDK 依賴 |
| 新增 Foundry.Hosting.IntegrationTests（PR #5598） | 整合測試套件 |
| 新增 hosted agent 可觀測性範例（PR #5660） | 可觀測性示範 |

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 | 嚴重性 |
|------|---------------|--------|
| Magentic Orchestration（新命名空間） | 需新建 `magentic-orchestration` 條目 | 🟢 新功能 |
| YAML block scalar 解析修正 | `agent-skills` | 🟢 Bug Fix（無 API 變更） |
| AG-UI 推理事件 | `ag-ui-protocol` | 🟢 Enhancement |
| WebBrowsingTool allow listing | `tools-ai-function` | 🟢 Enhancement |
| MEAI 10.5.1 | `llm-providers`、`chat-client` | 🟡 版本更新 |

---

## 貢獻者

本版本共 11 位貢獻者，含 5 位首次貢獻者。共合併約 21 個 PR。
