---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.1.0
fetched: 2026-04-17
type: release-notes
version: 1.1.0
platform: dotnet
---

# dotnet-1.1.0

**Release Date:** 2026-04-10
**Released by:** @dmytrostruk
**Commit:** 3e864cd

## Core Features

- **Skill as class** ([#5027](https://github.com/microsoft/agent-framework/pull/5027)): Support defining Skills as C# classes inheriting `AgentClassSkill`
- **Reflection-based discovery** ([#5183](https://github.com/microsoft/agent-framework/pull/5183)): Auto-discover resources and scripts in class-based skills via reflection
- **Custom types in skill functions** ([#5152](https://github.com/microsoft/agent-framework/pull/5152)): Skill resource/script functions can accept and return custom types
- **Align skill folder discovery** ([#5078](https://github.com/microsoft/agent-framework/pull/5078)): Align file skill folder discovery with spec
- **Version bump** ([#5204](https://github.com/microsoft/agent-framework/pull/5204)): .NET framework version bumped to 1.1.0

## Standardization

- **Directory terminology** ([#5205](https://github.com/microsoft/agent-framework/pull/5205)): Standardized file skills language to use "directory" consistently
- **Message Delivery Callback Overloads** ([#5081](https://github.com/microsoft/agent-framework/pull/5081)): New overloads for Executor message delivery callbacks
- **FoundryAgent CreateSessionAsync** ([#5144](https://github.com/microsoft/agent-framework/pull/5144)): Added `CreateSessionAsync(conversationId)` overload for FoundryAgent

## Bug Fixes

- Chat history compaction duplication ([#5149](https://github.com/microsoft/agent-framework/pull/5149))
- Checkpoint restoration input signal ([#5085](https://github.com/microsoft/agent-framework/pull/5085))
- Handoff workflow context ([#5136](https://github.com/microsoft/agent-framework/pull/5136))
- Entity key validation ([#5179](https://github.com/microsoft/agent-framework/pull/5179))
- Concurrent workflow sample fix ([#5090](https://github.com/microsoft/agent-framework/pull/5090))

## Dependencies

- Anthropic SDK: 12.8.0 → 12.11.0 ([#5055](https://github.com/microsoft/agent-framework/pull/5055))
- Model: gpt-5.4-mini support ([#5080](https://github.com/microsoft/agent-framework/pull/5080))

## Breaking Changes

None documented.
