---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.4.0
fetched: 2026-05-06
date: 2026-05-05
nuget: https://www.nuget.org/packages/Microsoft.Agents.AI/1.4.0
---

# .NET Agent Framework v1.4.0（2026-05-05）

## 重大變更（Breaking Changes）

### [Breaking] file-based skill scripts 支援 string[] 參數（PR #5475）

**套件：** `Microsoft.Agents.AI`（Skills 子系統）

file-based skill scripts 的參數型別由原先的單一字串改為支援 `string[]`，呼叫端傳入方式需對應調整。

#### 影響範圍

- 使用 file-based skill scripts 且傳遞單一字串引數的場景需更新為陣列形式
- 相關 ADR：尚未對應到個別 ADR

---

## 新功能

### CodeAct 整合（PR #5329）

**新套件：** `Microsoft.Agents.AI.Hyperlight`

新增 CodeAct 代理模式的官方整合套件，允許代理動態生成並執行程式碼以解決任務。對應 ADR-0024（codeact-integration）。

### Durable Workflow HTTP Trigger 端點回傳結果（PR #5321）

**套件：** `Microsoft.Agents.AI`（Workflow 子系統）

Durable workflow 的 HTTP trigger endpoint 現在支援回傳工作流程執行結果，不再只回傳 202 Accepted。

### HttpRequestAction 支援宣告式工作流程（PR #5474）

**套件：** `Microsoft.Agents.AI`（Declarative Workflow）

宣告式工作流程新增 `HttpRequestAction` 步驟型別，可直接在 YAML/JSON 工作流程定義中設定 HTTP 呼叫。

- 新增對應範例：`declarative-http-request-action`（PR #5572）

### Hosted-Agent User-Agent 標頭補充（PR #5453）

**套件：** `Microsoft.Agents.AI.Hosting`

所有從 hosted agent 發出的對外 HTTP 請求會自動附加 `User-Agent` 標頭補充資訊，方便伺服器端識別呼叫來源。

### Harness 功能分支合併（PR #5310）

**套件：** `Microsoft.Agents.AI`

Harness 功能（agent 測試框架輔助機制）正式合併進主線。

### Hosting 更新：宣告式工作流程（PR #5589）

**套件：** `Microsoft.Agents.AI.Hosting`

宣告式工作流程的 Hosting 層更新，與新的 `HttpRequestAction` 及回傳結果機制整合。

---

## 套件更新

| 套件 | 變更 |
|------|------|
| OpenTelemetry packages | 升級至 1.15.3（PR #5478） |

---

## Samples 異動

| 樣本路徑 | 變更 |
|---------|------|
| `declarative-http-request-action`（新增） | 示範宣告式工作流程中使用 HttpRequestAction |

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 | 嚴重性 |
|------|---------------|--------|
| file-based skill scripts string[] 參數（Breaking） | `agent-skills` | 🔴 Breaking |
| CodeAct 整合（Hyperlight 套件） | `codeact` | 🟢 Enhancement |
| HttpRequestAction 宣告式工作流程 | `declarative-workflow` | 🟢 Enhancement |
| Durable Workflow HTTP trigger 回傳結果 | `durable-agents`, `long-running-operations` | 🟡 Outdated |
| Harness 功能合併 | `agent-testing` | 🟡 Outdated |
