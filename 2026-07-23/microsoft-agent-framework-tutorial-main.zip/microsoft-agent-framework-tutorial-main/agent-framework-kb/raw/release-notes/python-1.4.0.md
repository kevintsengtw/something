---
source: https://github.com/microsoft/agent-framework/releases/tag/python-1.4.0
fetched: 2026-05-25
type: release-notes
version: 1.4.0
platform: python
---

# python-1.4.0

**Release Date:** 2026-05-06

## Breaking Changes

- **`SkillFrontmatter` 結構異動**（[#5448](https://github.com/microsoft/agent-framework/pull/5448)）：
  `SkillFrontmatter` schema 有不相容變更，現有 skill YAML 定義需更新。

- **A2A SDK 升級至 v1.0（正式版）**（[#5423](https://github.com/microsoft/agent-framework/pull/5423)）：
  Python SDK 的 Agent-to-Agent (A2A) 整合改用 `a2a-sdk v1.0`（GA），與 .NET 保持一致。舊版 A2A 整合不相容。

## Changed

- **DevUI 安全性強化**（[#5452](https://github.com/microsoft/agent-framework/pull/5452)）：
  開發用 UI 工具預設限制存取來源，降低本地開發時的安全風險。

## Fixed

- 多項穩定性與相容性修正
