---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.9.0
fetched: 2026-06-06
release_date: 2026-06-03
version: 1.9.0
---

# .NET Agent Framework v1.9.0（2026-06-03）

## API 狀態變更（Promotions / 移除 Experimental）

### 1. 移除 .NET Orchestrations 的 [Experimental] 標記

**PR：** [#6164](https://github.com/microsoft/agent-framework/pull/6164)

.NET 端的 Orchestrations（含 Magentic、Handoff、GroupChat 等編排）移除 `[Experimental]` 標記，正式轉為穩定 API。使用這些編排不再需要抑制 experimental 警告。

**影響範圍：** 教學/文件中對 Orchestration 標注「Experimental / 實驗性」的描述需更新。

### 2. Workflows.Declarative 套件轉 stable

**PR：** [#6254](https://github.com/microsoft/agent-framework/pull/6254)

`Microsoft.Agents.AI.Workflows.Declarative` 系列套件由 prerelease/RC 轉為 stable 正式版。安裝時不再需要 `--prerelease`。

---

## 新功能（.NET）

### HarnessAgent 建構子加入 ILoggerFactory 與 IServiceProvider

**PR：** [#6273](https://github.com/microsoft/agent-framework/pull/6273)

`HarnessAgent` 建構子新增 `ILoggerFactory` 與 `IServiceProvider` 參數，擴充其 DI 整合能力。

### Hosted-ToolboxMcpSkills 範例

**PR：** [#6175](https://github.com/microsoft/agent-framework/pull/6175)

新增展示 hosted 場景下 MCP skill 整合的範例。

---

## 新功能（Python — 僅供對照）

| 功能 | PR |
|------|-----|
| MCP-based skills discovery（`McpSkillsSource`） | [#6169](https://github.com/microsoft/agent-framework/pull/6169) |
| Progressive tool exposure（`FunctionInvocationContext`） | [#6233](https://github.com/microsoft/agent-framework/pull/6233) |
| Background agent support（harness agent） | [#6155](https://github.com/microsoft/agent-framework/pull/6155) |
| `AgentFileStore` 與 `FileAccessProvider` | [#6099](https://github.com/microsoft/agent-framework/pull/6099) |
| agent-framework-declarative 套件 promote 至 RC | [#6256](https://github.com/microsoft/agent-framework/pull/6256) |

---

## 增強（Enhancements）

### .NET

| 項目 | PR | 說明 |
|------|-----|------|
| Workflow Outputs Overhaul | [#6045](https://github.com/microsoft/agent-framework/pull/6045) | 工作流程輸出支援 tagging 與 filtering agent outputs |
| GroupChatManager 語意對齊 Orchestration | [#6140](https://github.com/microsoft/agent-framework/pull/6140) | `GroupChatManager` 語意與 Orchestration patterns 對齊 |
| 跨工作流程保留 CreatedAt | [#3930](https://github.com/microsoft/agent-framework/pull/3930) | 保留並傳遞 `CreatedAt` 通過工作流程 |

### Python（僅供對照）

| 項目 | PR |
|------|-----|
| Bedrock 原生 structured output（Converse API） | [#6052](https://github.com/microsoft/agent-framework/pull/6052) |
| Foundry Adaptive Evals（rubric-generation） | [#6101](https://github.com/microsoft/agent-framework/pull/6101) |
| Mistral AI embedding client 套件 | [#5480](https://github.com/microsoft/agent-framework/pull/5480) |
| A2A `supported_protocol_bindings` 可配置 | [#6098](https://github.com/microsoft/agent-framework/pull/6098) |

---

## Bug 修復

### .NET

| 問題 | PR | 說明 |
|------|-----|------|
| Foundry Hosting function_call_output 缺少 id | [#6246](https://github.com/microsoft/agent-framework/pull/6246) | 修正 `function_call_output` 缺少 id |
| Declarative workflows 的 InvokeMcpTool approval path | [#6177](https://github.com/microsoft/agent-framework/pull/6177) | 修正 MCP 工具核准路徑 |
| AGUI hosting 與 workflows | [#6311](https://github.com/microsoft/agent-framework/pull/6311) | 多項 AGUI hosting 與工作流程修正 |

### Python（僅供對照）

| 問題 | PR |
|------|-----|
| FoundryAgent 從 PromptAgent 請求剝除 model | [#5526](https://github.com/microsoft/agent-framework/pull/5526) |
| OTLP HTTP base-endpoint 遺失 `/v1/{signal}` | [#5913](https://github.com/microsoft/agent-framework/pull/5913) |
| core observability 不安全序列化 | [#6026](https://github.com/microsoft/agent-framework/pull/6026) |
| A2A `AgentResponseUpdate` 設定 message_id | [#6163](https://github.com/microsoft/agent-framework/pull/6163) |
| MCP reliability 修正彙整 | [#6145](https://github.com/microsoft/agent-framework/pull/6145) |
| 跳過 orphan anthropic thinking signatures | [#5784](https://github.com/microsoft/agent-framework/pull/5784) |

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 | 嚴重性 |
|------|---------------|--------|
| Orchestrations 移除 [Experimental] | `magentic-orchestration`、`workflows` | 🟡 Outdated（移除實驗性警語） |
| Workflows.Declarative 轉 stable | `workflows`、`declarative-workflows` | 🟡 Outdated（移除 prerelease） |
| Workflow Outputs Overhaul | `workflows` | 🟢 Enhancement |
| GroupChatManager 語意對齊 | `magentic-orchestration`、`workflows` | 🟡 Enhancement |
| HarnessAgent ILoggerFactory/IServiceProvider | `harness-agent` | 🟢 新功能 |
| CreatedAt 跨工作流程保留 | `workflows` | 🟢 Enhancement |
