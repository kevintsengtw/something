---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.10.0
fetched: 2026-06-14
release_date: 2026-06-11
version: 1.10.0
---

# .NET Agent Framework v1.10.0（2026-06-11）

> 性質：**維護 + 增強釋出**。release notes 標為 Breaking 的項目實為相依套件遷移與內部 hosting 修復，對教學公開 API 無破壞性影響。新增能力以 `ToolApprovalAgent` 自動核可規則為主。

## Breaking Changes（依官方分類，對教學程式碼無破壞性）

### 1. 遷移 .NET GitHub Copilot SDK 至 v1.0.0

**PR：** [#6381](https://github.com/microsoft/agent-framework/pull/6381)

GitHub Copilot 相依套件升級至 v1.0.0。僅影響使用 GitHub Copilot provider 的程式（教學未涵蓋此 provider）。配套測試修復見 [#6424](https://github.com/microsoft/agent-framework/pull/6424)。

### 2. 修復 hosting 問題

**PR：** [#6388](https://github.com/microsoft/agent-framework/pull/6388)

修正數項 hosting 相關問題，屬內部行為修復。

### 3. ToolApprovalAgent 加入自動核可規則

**PR：** [#6335](https://github.com/microsoft/agent-framework/pull/6335)

`ToolApprovalAgentOptions` 新增 `AutoApprovalRules` —— 一組啟發式函式，可在不打擾使用者的情況下自動核可符合條件的工具呼叫。屬**新增能力**（additive），不破壞既有核可流程。

---

## 新功能與增強（.NET）

| 項目 | PR | 說明 |
|------|-----|------|
| Hosted Agent 範例 — Toolbox with various Auth | [#6018](https://github.com/microsoft/agent-framework/pull/6018) | hosted agent 範例加入多種驗證的工具箱 |
| ChatClientAgent ChatOptions 合併加入 Reasoning | [#5463](https://github.com/microsoft/agent-framework/pull/5463) | `ChatOptions` 合併時支援 `reasoning` 參數 |
| Foundry 部署文件加入 HA 範例 README | [#6365](https://github.com/microsoft/agent-framework/pull/6365) | 擴充 Foundry 部署情境文件 |
| 允許儲存自動核可的函式 | [#4950](https://github.com/microsoft/agent-framework/pull/4950) | 不需核可的函式呼叫可持久化於 session 狀態（`UseNonApprovalRequiredFunctionBypassing`），只把真正需要人工核可的工具浮現給呼叫端 |
| ModelContextProtocol 1.1.0 → 1.2.0 | [#6239](https://github.com/microsoft/agent-framework/pull/6239) | MCP 相依套件升級 |

---

## Bug 修復（.NET）

| 問題 | PR | 說明 |
|------|-----|------|
| Copilot 整合測試對齊 SDK v1.0.0 | [#6424](https://github.com/microsoft/agent-framework/pull/6424) | 修復 SDK 遷移後的測試 |
| HarnessAgent 移除必填 token 參數 | [#6409](https://github.com/microsoft/agent-framework/pull/6409) | token 壓縮（compaction）改為 opt-in；`MaxContextWindowTokens`/`MaxOutputTokens` 為可選 |
| Magentic 跨團隊共享代理回覆 | [#6222](https://github.com/microsoft/agent-framework/pull/6222) | 修正 Magentic 編排中代理回覆的共享行為 |
| 保留 AG-UI session 歷史 | [#5904](https://github.com/microsoft/agent-framework/pull/5904) | 修正 session 資料遺失 |
| 宣告式工作流程單欄值解包 | [#6367](https://github.com/microsoft/agent-framework/pull/6367) | 修正資料擷取錯誤 |
| 保留 foreach record 值 | [#6208](https://github.com/microsoft/agent-framework/pull/6208) | 修正工作流程迴圈中的值遺失 |
| reasoning 被剝除時丟棄 hosted MCP 呼叫 | [#6210](https://github.com/microsoft/agent-framework/pull/6210) | 避免 reasoning 移除後的孤兒 MCP 呼叫 |
| 重構 skill script schemas XML | [#6343](https://github.com/microsoft/agent-framework/pull/6343) | 精煉 XML 結構與資源處理 |

---

## 維護與相依套件更新

| 項目 | PR |
|------|-----|
| Microsoft.Extensions.AI 套件更新至 10.6.0 | [#6148](https://github.com/microsoft/agent-framework/pull/6148) |
| 移除失效的 Atomic Agents 文件連結 | [#6442](https://github.com/microsoft/agent-framework/pull/6442) |
| 更新 logo 與品牌標誌 | [#6378](https://github.com/microsoft/agent-framework/pull/6378)、[#6380](https://github.com/microsoft/agent-framework/pull/6380) |
| 改善 PR 相依處理 | [#6317](https://github.com/microsoft/agent-framework/pull/6317) |

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 | 嚴重性 |
|------|---------------|--------|
| ToolApprovalAgent 自動核可規則（#6335、#4950） | `human-in-the-loop` | 🟢 Enhancement（新增 opt-in 能力） |
| HarnessAgent token compaction 改 opt-in（#6409） | `long-running-operations`、`orchestration-builders` | 🟢 Enhancement |
| ChatOptions Reasoning 合併（#5463） | `chat-options` | 🟢 Enhancement |
| ModelContextProtocol 1.2.0（#6239） | `mcp-integration`、`nuget-packages` | 🟡 Outdated（套件版本） |
| Microsoft.Extensions.AI 10.6.0（#6148） | `nuget-packages` | 🟡 Outdated（套件版本） |
| Magentic 跨團隊共享回覆修復（#6222） | `magentic-orchestration` | 🟢 修復（行為正確化） |
| skill script schemas XML 重構（#6343） | `agent-skills` | 🟢 修復（內部 XML 結構） |
| AG-UI session 歷史保留（#5904） | `ag-ui-protocol` | 🟢 修復 |
</content>
</invoke>
