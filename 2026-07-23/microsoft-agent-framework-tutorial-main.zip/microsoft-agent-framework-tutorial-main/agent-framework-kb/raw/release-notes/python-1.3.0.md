---
source: https://github.com/microsoft/agent-framework/releases/tag/python-1.3.0
fetched: 2026-05-25
type: release-notes
version: 1.3.0
platform: python
---

# python-1.3.0

**Release Date:** 2026-04-24

## Breaking Changes

- **Multi-source skills architecture**（[#5297](https://github.com/microsoft/agent-framework/pull/5297)）：
  Skills 現在支援多個 source 定義。已使用單一 source 的現有 skill 實作需遷移至新的多 source 格式。

## Added

- **`ClassSkill`**（[#5297](https://github.com/microsoft/agent-framework/pull/5297)）：
  新的 skill 類別，可將 Python class 作為 skill 定義單元，與 .NET 的 `AgentClassSkill<T>` 對應。

- **`InvokeMcpTool`（Python parity）**（[#5312](https://github.com/microsoft/agent-framework/pull/5312)）：
  Python SDK 新增 `InvokeMcpTool` activity，與 .NET SDK 功能對應。

- **`HttpRequestAction`（Python parity）**（[#5298](https://github.com/microsoft/agent-framework/pull/5298)）：
  Python SDK 新增 `HttpRequestAction`，與 .NET 的 `HttpRequestAction` 對應。

## Changed

- 依賴項更新、文件修正
