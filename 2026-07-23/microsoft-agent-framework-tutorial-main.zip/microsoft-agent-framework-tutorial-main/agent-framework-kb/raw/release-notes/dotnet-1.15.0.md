---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.15.0
fetched: 2026-07-23
release_date: 2026-07-22
version: 1.15.0
platform: dotnet
tag_commit: 2d34deeb82
---

# .NET Agent Framework v1.15.0（2026-07-22）

## What's Changed
* Python: Add MCPStreamableHTTPTool security guidance for custom http client by @TaoChenOSU in https://github.com/microsoft/agent-framework/pull/7245
* Harden workflow credential selection by @moonbox3 in https://github.com/microsoft/agent-framework/pull/7249
* Python: preserve Gemini 3 thought_signature across function-call replays by @giles17 in https://github.com/microsoft/agent-framework/pull/7095
* .NET: [BREAKING] Hosting OpenAI Responses protocol helpers and optional execution state by @rogerbarreto in https://github.com/microsoft/agent-framework/pull/7000
* .NET: Fix declarative autosend output by @alliscode in https://github.com/microsoft/agent-framework/pull/7217
* .NET: Updating dotnet version for release. by @alliscode in https://github.com/microsoft/agent-framework/pull/7265
* .NET: Added GettingStarted example demonstrating Dapr as an agent provider by @WhitWaldo in https://github.com/microsoft/agent-framework/pull/1615
* Python: Support prompt cache breakpoints for GPT-5.6 models in OpenAI clients by @Mordris in https://github.com/microsoft/agent-framework/pull/7163
* .NET: Fix expensive logging by @alliscode in https://github.com/microsoft/agent-framework/pull/7268
* Python: Fix stateless replay of reasoning-paired tool calls by @moonbox3 in https://github.com/microsoft/agent-framework/pull/7233
* Reduce workflow credential exposure by @moonbox3 in https://github.com/microsoft/agent-framework/pull/7270

## New Contributors
* @WhitWaldo made their first contribution in https://github.com/microsoft/agent-framework/pull/1615
* @Mordris made their first contribution in https://github.com/microsoft/agent-framework/pull/7163

**Full Changelog**: https://github.com/microsoft/agent-framework/compare/python-1.12.0...dotnet-1.15.0
