---
version: 1.11.1
release_date: 2026-06-26
tag_commit: d9ec5eaab4918612ae0f7ddf11499576bdb510bf
tag_commit_date: 2026-06-25
upstream_tag: dotnet-1.11.1
kind: patch（含 breaking — Agent Skills 預設核可）
min_dotnet: 8.0
---

# Microsoft Agent Framework — dotnet-1.11.1 Release Notes

> 來源：<https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.11.1>
> 上一版本：[dotnet-1.11.0](./dotnet-1.11.0.md)
> 性質：patch 修補釋出，但含一項影響教學的 **Agent Skills 安全性 Breaking**（所有技能工具預設需核可）。

---

## Breaking Changes

| 項目 | PR | 影響面 |
|------|-----|--------|
| **所有 `AgentSkillsProvider` 工具預設皆需核可** | #6729 | 移除 `AgentSkillsProviderOptions.ScriptApproval` 屬性與 `AgentSkillsProviderBuilder.UseScriptApproval(bool)` 方法；`load_skill`/`read_skill_resource`/`run_skill_script` 全部以 `ApprovalRequiredAIFunction` 包裝。**直接影響 ch29** |
| `AgentMcpSkillsSource` 支援 archive 型技能 | #6631 | 新增 `AgentMcpSkillsSourceOptions` 與 `Skills/Loaders/*`（`ArchiveEntryLoader`/`SkillMdEntryLoader`/`IMcpSkillEntryLoader`/`ArchiveFormat`/`AgentMcpSkillArchiveExtractor`）；MCP 技能來源行為擴充 |
| `FileSkillsSource` depth-based discovery + 述詞過濾 | #6488 / #6109 | 延續 1.8.0 的 depth-based 重構再對齊；`AgentFileSkillsSource` 微調 |
| 移除 `{resource_instructions}` 與 `{script_instructions}` 佔位符機制 | #6706 | `AgentSkillsProviderOptions.SkillsInstructionPrompt` 範本現只需 `{skills}`；資源/腳本清單改由 `available_resources`/`available_scripts` 區塊（1.11.0 #6672）自動輸出。**直接影響 ch29** |

## 新功能與增強

| 項目 | PR | 說明 |
|------|-----|------|
| `DeclarativeWorkflowJsonOptions`（AOT-safe declarative workflow checkpointing） | #6745 | 宣告式工作流程檢查點序列化選項，支援 AOT 安全情境（`Microsoft.Agents.AI.Workflows.Declarative`） |
| `IncludeDetailedErrors` 選項（skill script execution） | #6680 / #6304 | `AgentSkillsProviderOptions.IncludeDetailedErrors`：腳本失敗時是否把例外細節回傳給模型（預設 `false`，交由 `FunctionInvokingChatClient` 政策處理） |
| `CreateMcpTool` 加入 `projectConnectionId` overload（.NET Foundry） | #6703 | `FoundryAITool.CreateMcpTool` 新增可帶 `projectConnectionId` 的多載 |

## Bug 修復

| 項目 | PR |
|------|-----|
| 修正套件版本升級後恢復 checkpoint 的問題 | #6670 |
| 修正 hosted agent 工具呼叫後崩潰：session store 改 root 於 `$HOME`（`FileSystemAgentSessionStore`） | #6231 / #6714 |
| 修正 `SearchDirectoriesForSkills` 找到 `SKILL.md` 後仍遞迴的行為 | #6686 / #6683 |
| 修正 MCP metadata 與工具名稱處理 | #6656 |
| Purview：使用者識別優先採 token principal | #6693 |

## 基礎建設與相依

- .NET SDK 升級至 10.0.301（#6730）
- 多項相依更新（HuggingFace Hub、Google GenAI、FastAPI；多為 Python 側）
- 停用會失敗的 durable function 整合測試（#6731）
- .NET 範例遷移為 Foundry-first `AIProjectClient`（#6557）

## 文件 / 其他

- 新增 Python session identity ADR（#6630）

---

## 影響概念對照

| wiki 概念 | 影響 | 變更 |
|-----------|------|------|
| `agent-skills` | 🔴 Breaking | `ScriptApproval`/`UseScriptApproval` 移除；預設全部需核可；`{resource_instructions}`/`{script_instructions}` 佔位符移除；新增 `IncludeDetailedErrors` |
| `mcp-integration` | 🟢 增強 | `AgentMcpSkillsSource` archive 型技能 + `AgentMcpSkillsSourceOptions`；`FoundryAITool.CreateMcpTool` `projectConnectionId` 多載 |
| `declarative-workflow` | 🟢 增強 | 新增 `DeclarativeWorkflowJsonOptions`（AOT-safe checkpointing） |
| `a2a-protocol` / hosting | 🟢 修復 | `FileSystemAgentSessionStore` 改 root 於 `$HOME`，修復 hosted agent 崩潰 |

> 影響教學的 Breaking 集中在 **ch29 Agent Skills**：腳本審批由「opt-in（`ScriptApproval`）」改為「預設全部需核可」。
