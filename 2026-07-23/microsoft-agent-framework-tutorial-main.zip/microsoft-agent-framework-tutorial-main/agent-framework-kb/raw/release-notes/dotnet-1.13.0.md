---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.13.0
fetched: 2026-07-05
release_date: 2026-07-03
version: 1.13.0
tag_commit: 7ca73c064
---

# .NET Agent Framework v1.13.0（2026-07-03）

## Breaking Changes（.NET）

### 1. 新增檔案編輯工具 + 對齊 FileAccess/FileMemory store API

**PR：** [#6807](https://github.com/microsoft/agent-framework/pull/6807)

於 Harness FileAccess/FileMemory 子系統新增檔案編輯工具，並對齊 store API。屬 `Microsoft.Agents.AI.Harness` FileAccess 子系統（`[Experimental]`），教學未示範。

### 2. 重構 OpenAI Hosting OptionsMapping，預設不允許傳遞 options

**PR：** [#6855](https://github.com/microsoft/agent-framework/pull/6855)

OpenAI **Hosting** 層的 OptionsMapping 重構為預設不透傳 options。屬 hosting 子系統的內部映射，**不影響**第 17 章示範的用戶端 `AzureOpenAIClient` / `GetOpenAIResponseClient` 建構寫法。

---

## API 狀態變更

### 移除 Skills API 的 [Experimental] 標記

**PR：** [#6861](https://github.com/microsoft/agent-framework/pull/6861)

`Microsoft.Agents.AI` 的 Skills API（`AgentSkillsProvider`、`AgentSkillsProviderBuilder`、`AgentSkill` 等）移除 `[Experimental]` 標記，正式轉為穩定 API。使用技能不再需要抑制 experimental 警告。**影響第 29 章**（可移除任何實驗性警語，但第 29 章原本未加警語）。

### Skills source 類別改為 public（含 Experimental 標記）→ 隨後於 #6861 一併穩定

**PR：** [#6838](https://github.com/microsoft/agent-framework/pull/6838)

`AgentInMemorySkillsSource`、`AggregatingAgentSkillsSource`、`FilteringAgentSkillsSource`、`DeduplicatingAgentSkillsSource`、`CachingAgentSkillsSource` 等 skills source 類別改為 public，可自訂組合。

---

## 新功能與增強（.NET）

| 項目 | PR | 說明 |
|------|-----|------|
| `AgentSkillsSource.GetSkillsAsync` 新增 `AgentSkillsSourceContext` 參數 | [#6797](https://github.com/microsoft/agent-framework/pull/6797) | 抽象基底 `AgentSkillsSource` 的 `GetSkillsAsync(AgentSkillsSourceContext context, CancellationToken)`；context 帶 `AIAgent Agent` + `AgentSession? Session`。**影響自訂 source（教學未示範自訂 source）** |
| 技能核可選項（skill approval options） | [#6843](https://github.com/microsoft/agent-framework/pull/6843) | `AgentSkillsProviderOptions` 新增 `DisableLoadSkillApproval` / `DisableReadSkillResourceApproval` / `DisableRunSkillScriptApproval`；搭配 `AgentSkillsProvider.ReadOnlyToolsAutoApprovalRule` / `AllToolsAutoApprovalRule` 靜態規則。**影響 ch29（增強核可段落）** |
| 整併 skill-source 快取 + skill sources 改為 disposable | [#6827](https://github.com/microsoft/agent-framework/pull/6827) | `AgentSkillsSource : IDisposable`（含 `Dispose(bool)`） |
| Foundry Hosting per-user session isolation + Responses v2 fast-fail | [#6832](https://github.com/microsoft/agent-framework/pull/6832) | Foundry hosting 子系統 |
| Foundry Hosting 本機執行時容忍缺少 user identity | [#6870](https://github.com/microsoft/agent-framework/pull/6870) | Foundry hosting 子系統 |
| 預設核可 harness 功能可設定 + 可自訂 shell 工具 | [#6880](https://github.com/microsoft/agent-framework/pull/6880) | Harness |
| .NET 範例改善 | [#6869](https://github.com/microsoft/agent-framework/pull/6869) | 範例 |

---

## Bug 修復與維護（.NET）

| 問題 | PR | 說明 |
|------|-----|------|
| dotnet-format workflow shell 處理強化 | [#6796](https://github.com/microsoft/agent-framework/pull/6796) | CI |
| pin patched OpenAPI 相依以解除 NU1903 | [#6853](https://github.com/microsoft/agent-framework/pull/6853) | 相依安全 |
| `AddFoundryToolboxes` 要求明確 TokenCredential | [#6877](https://github.com/microsoft/agent-framework/pull/6877) | Foundry hosting |
| Azure.AI.Projects 升至 2.1.0-beta.4 | [#6795](https://github.com/microsoft/agent-framework/pull/6795) | 相依 |

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 | 嚴重性 |
|------|---------------|--------|
| Skills API 移除 [Experimental]（穩定化） | `agent-skills` | 🟡 Outdated（可移除實驗性描述） |
| 技能核可選項（Disable*Approval + auto-approval rules） | `agent-skills` | 🟢 Enhancement（ch29 核可段落擴充） |
| `AgentSkillsSourceContext` 參數 + source 可 dispose/public | `agent-skills` | 🟢 Enhancement（進階：自訂 source） |
| FileAccess/FileMemory 檔案編輯工具 | （Harness，無對應教學條目） | 🟢 內部 |
| OpenAI Hosting OptionsMapping | （hosting，無對應教學條目） | 🟢 內部 |
