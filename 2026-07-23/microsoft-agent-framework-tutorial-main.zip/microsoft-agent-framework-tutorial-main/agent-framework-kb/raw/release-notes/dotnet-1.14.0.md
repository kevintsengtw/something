---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.14.0
fetched: 2026-07-23
release_date: 2026-07-21
version: 1.14.0
platform: dotnet
tag_commit: d08200d00e
---

# .NET Agent Framework v1.14.0（2026-07-21）

## What's Changed
* .NET: Fix CosmosChatHistoryProvider: omit ttl when MessageTtlSeconds is nul… by @TheovanKraay in https://github.com/microsoft/agent-framework/pull/7030
* .NET: Fix CompactionMessageIndex.IsSummaryMessage by @pwoosam in https://github.com/microsoft/agent-framework/pull/7042
* .NET: Fix workflow session bug by @peibekwe in https://github.com/microsoft/agent-framework/pull/7032
* .NET: Enable Valkey NuGet package publishing by @westey-m with @Copilot in https://github.com/microsoft/agent-framework/pull/7059
* .NET: [BREAKING] Graduate message injection out of experimental by @westey-m in https://github.com/microsoft/agent-framework/pull/7044
* .NET: [BREAKING] Graduate todo and agent mode providers out of experimental by @westey-m in https://github.com/microsoft/agent-framework/pull/7052
* Update issue triage by @moonbox3 in https://github.com/microsoft/agent-framework/pull/7098
* .NET: Add name collision warnings for auto-approvals by @westey-m in https://github.com/microsoft/agent-framework/pull/7089
* .NET: Update Microsoft Foundry branding by @nicholasdbrady in https://github.com/microsoft/agent-framework/pull/6999
* .NET: [BREAKING] Harness: Switch FileAccess to opt-in by @westey-m in https://github.com/microsoft/agent-framework/pull/7093
* fix typos in XML doc comments, ADR docs, and test comments by @rinceyuan in https://github.com/microsoft/agent-framework/pull/7085
* .NET: [BREAKING] Graduate ToolApprovalAgent and add ToolAutoApprovalRuleContext by @westey-m in https://github.com/microsoft/agent-framework/pull/7107
* Harden manual integration test trust boundary by @moonbox3 in https://github.com/microsoft/agent-framework/pull/7081
* CI: resolve PR author in community team check by @rogerbarreto in https://github.com/microsoft/agent-framework/pull/7129
* Fix message ordering in workflow-hosted agents by @peibekwe in https://github.com/microsoft/agent-framework/pull/7123
* .NET: [BREAKING] Graduate FileMemoryProvider by @westey-m in https://github.com/microsoft/agent-framework/pull/7114
* .NET: Preserve UTF-8 order in HeadTailBuffer by @jstar0 in https://github.com/microsoft/agent-framework/pull/7128
* .NET: [Feature]: .NET Improve ChatClientAgentSession constructor by @feiyun0112 in https://github.com/microsoft/agent-framework/pull/7142
* .NET: Fix LocalCodeAct validation and package checks by @eavanvalkenburg in https://github.com/microsoft/agent-framework/pull/7138
* samples: add AgentMemory (Neo4j-agent memory reimplemented in NET ) shopping assistant sample by @joslat in https://github.com/microsoft/agent-framework/pull/7096
* .NET: Honor terminal workflow outputs in Workflow.AsAIAgent responses by @ssccinng in https://github.com/microsoft/agent-framework/pull/6212
* .NET: Refactor Workflows MessageMerger to preserve message order and structure by @marcominerva in https://github.com/microsoft/agent-framework/pull/6826
* .NET: Populate AgentResponse metadata in CopilotStudioAgent by @anneheartrecord in https://github.com/microsoft/agent-framework/pull/6791
* .NET: [BREAKING] Bind tool-approval responses to surfaced approval requests by @rogerbarreto in https://github.com/microsoft/agent-framework/pull/7111
* .NET: [BREAKING] Graduate HarnessAgent by @westey-m in https://github.com/microsoft/agent-framework/pull/7119
* .NET: Version bump for .net release by @westey-m in https://github.com/microsoft/agent-framework/pull/7237
* .NET: Cover source-type-agnostic toolbox consent parsing (a2a_preview) by @rogerbarreto in https://github.com/microsoft/agent-framework/pull/7229
* [BREAKING] Python: add Responses conversation ID helper by @eavanvalkenburg in https://github.com/microsoft/agent-framework/pull/7234
* The legacy .NET package Microsoft.Agents.AI.AGUI has been split into external AG-UI SDK packages: AGUI.Client, AGUI.Server, AGUI.Abstractions, AGUI.Protobuf (optional transport), and AGUI.Formatting. The ASP.NET Core hosting integration remains in this repository as Microsoft.Agents.AI.Hosting.AGUI.AspNetCore, now layered on top of AGUI.Server. If you are upgrading, replace Microsoft.Agents.AI.AGUI with the relevant AGUI.* packages and rename AddAGUI()/MapAGUI() to AddAGUIServer()/MapAGUIServer().

**Full Changelog**: https://github.com/microsoft/agent-framework/compare/python-1.11.0...dotnet-1.14.0
