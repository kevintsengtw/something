---
source: https://github.com/microsoft/agent-framework/releases/tag/python-devui-1.0.0b260414
fetched: 2026-04-17
type: release-notes
version: 1.0.0b260414
platform: python-devui
---

# python-devui-1.0.0b260414

**Release Date:** 2026-04-15
**Latest DevUI release**

## Fixed

- **Streaming memory growth in DevUI frontend** ([#5221](https://github.com/microsoft/agent-framework/pull/5221)):
  Fixes a memory leak in the DevUI frontend when handling streaming agent responses.

## Notes

DevUI is the interactive developer interface for building, testing, and debugging Agent Framework
workflows. This is a prerelease (`b` = beta). Installed via `pip install agent-framework-devui`.
