---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.2.0
fetched: 2026-04-23
date: 2026-04-21
released_by: dmytrostruk
commit: f2b215a2f6d4767fd37b17dd33195100ea2e498f
---

# .NET Agent Framework v1.2.0（2026-04-21）

## 重大新功能

### Foundry Hosted Agents Support（.NET）
PR #5312（合併 13 個 PR：#5091, #5287, #5278, #5281, #5316, #5336, #5341, #5367, #5368, #5371, #5374, #5406, #5408）

Azure AI Foundry 托管代理支援，是本版本最主要的功能。

### Foundry Evals Integration for .NET
PR #4914, #5269 — 評估框架整合至 .NET

### DevUI Aspire Integration
PR #3771 — DevUI 與 .NET Aspire 整合

### Handoff 編排重構 + HITL 支援
PR #5174 — Refactor Handoff Orchestration，新增 Human-in-the-Loop 支援

## .NET 變更清單

### 新功能
| PR | 說明 | 影響概念 |
|----|------|---------|
| #5312 | Foundry Hosted Agents Support（13 PR 合併） | llm-providers, ai-agent |
| #4914, #5269 | Foundry Evals integration for .NET | agent-evaluation |
| #3771 | DevUI Aspire integration | opentelemetry |
| #5174 | Refactor Handoff Orchestration + HITL support | workflows, human-in-the-loop |
| #5193 | Update AGUI service to support session storage | ag-ui-protocol, agent-session |
| #5245 | Add Handoff sample | workflows |
| #5014 | Add Code Interpreter container file download samples | tools-ai-function |

### Bug 修復
| PR | 說明 | 影響概念 |
|----|------|---------|
| #5359 | Duplicate CallIds cause Handoff Message Filtering to fail | workflows |
| #5323 | Fix declarative resume edge predicates（direct + PortableValue-wrapped after checkpoint） | declarative-workflow, durable-agents |
| #5376 | Declarative workflows - Gracefully handle agent scenarios when no response is returned | declarative-workflow |
| #5280 | Add session support for Handoff-hosted Agents | llm-providers, agent-session |
| #5311 | Foundry Agents without description in Handoff | llm-providers |
| #5134 | Fix intermittent checkpoint-restore race in in-process workflow runs | durable-agents |
| #5256 | Propagate A2A metadata with namespaced key in additional_properties | a2a-protocol |

### 工具改善
| PR | 說明 |
|----|------|
| #5390 | Expand Workflow Unit Test Coverage |
| #5175 | Add error checking to workflow samples |
| #5266 | Improve local release build perf |

### 相依更新
| 套件 | 舊版 | 新版 | PR |
|------|------|------|----|
| Microsoft.Extensions.AI | — | 10.5.0 | #5269 |
| OpenAI | — | 2.10.0 | #5269 |
| Anthropic SDK | 12.13.0 | 12.13.0 | #5279 |
| Anthropic.Foundry | — | 0.5.0 | #5279 |

## Python 變更摘要（供參考）

| PR | 說明 |
|----|------|
| #5379 | Foundry hosted agent V2 |
| #5346 | Add support for Foundry Toolboxes |
| #5258, #4847 | Fix/Add GeminiChatClient for Gemini API and Vertex AI |
| #5185 | Add Hyperlight CodeAct package and docs |
| #5211 | Add finish_reason support to AgentResponse and AgentResponseUpdate |
| #5221 | Fix DevUI streaming memory growth |
| #5220 | Fix HandoffBuilder dropping function-level middleware when cloning agents |
| #5264 | Expose forwardedProps to agents and tools via session metadata |
| #5248 | Add experimental file history provider |
| #5202 | Add allowed_checkpoint_types support to CosmosCheckpointStorage |
| #5201 | AG-UI deterministic state updates from tool results |
| #5137 | Fix OpenAIEmbeddingClient to use AsyncOpenAI for /openai/v1 endpoints |
| #5234 | feat(evals): add ground_truth support for similarity evaluator |
