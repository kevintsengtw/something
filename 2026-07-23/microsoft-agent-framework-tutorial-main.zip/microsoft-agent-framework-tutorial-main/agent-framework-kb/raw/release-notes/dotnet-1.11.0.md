---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.11.0
fetched: 2026-06-25
release_date: 2026-06-24
version: 1.11.0
---

# .NET Agent Framework v1.11.0（2026-06-24）

> 性質：**維護 + 增強釋出**。release notes 標為 Breaking 的三項集中在 Harness 的 FileAccess 子系統與內部 SessionConfig 修復，皆非教學以具體程式碼示範的公開 API。新增能力以 `LoopAgent`（Harness 迴圈）、`Microsoft.Agents.AI.LocalCodeAct` 新套件（本機 Python 執行）、`FileAccessProvider` 工具核可、MCP 每次執行可刷新驗證標頭為主。
>
> Tag commit `1109d0bf`（2026-06-23），release 發佈日 2026-06-24。

## Breaking Changes（依官方分類，對教學程式碼無破壞性）

### 1. FileAccessProvider 工具需明確核可

**PR：** [#6521](https://github.com/microsoft/agent-framework/pull/6521)

Harness 的 `FileAccessProvider`（`Microsoft.Agents.AI.Harness.FileAccess`，`[Experimental]`）所暴露的檔案存取工具現在需要明確核可，並提供自動核可規則（對應測試 `AllToolsAutoApprovalRule_ApprovesAllFileAccessToolsAsync`）。教學未以具體程式碼示範 Harness FileAccess 工具。

### 2. FileAccess 工具對齊 Python（目錄探索 + 遞迴搜尋）

**PR：** [#6474](https://github.com/microsoft/agent-framework/pull/6474)

`FileAccessProvider` 加入目錄探索與遞迴搜尋能力，與 Python 實作對齊。屬 Harness 子系統能力擴充。

### 3. 修正 SessionConfig.Streaming 複製

**PR：** [#6463](https://github.com/microsoft/agent-framework/pull/6463)

修正 session 設定之間 `SessionConfig.Streaming` 值未正確複製的問題。屬內部行為修復。

---

## 新功能與增強（.NET）

| 項目 | PR | 說明 |
|------|-----|------|
| `Microsoft.Agents.AI.LocalCodeAct` 新套件 | [#6105](https://github.com/microsoft/agent-framework/pull/6105) | 新增 `LocalCodeActProvider` / `LocalCodeActProviderOptions`，於本機執行 Python 程式碼（CodeAct 模式的本機沙盒選項） |
| `LoopAgent`（Harness 迴圈代理） | [#6384](https://github.com/microsoft/agent-framework/pull/6384) | `Microsoft.Agents.AI.Harness.Loop.LoopAgent` / `LoopAgentOptions`（`[Experimental]`）：把被包裝的代理放進評估器驅動的迴圈中反覆執行，支援 `MaxIterations`、`FreshContextPerIteration`、`NonStreamingReturnsLastResponseOnly` 等選項 |
| MCP 每次執行可刷新驗證標頭 | [#6624](https://github.com/microsoft/agent-framework/pull/6624) | MCP 連線支援 per-run 可刷新的驗證標頭 |
| Foundry 自適應評估（Adaptive Evals） | [#6267](https://github.com/microsoft/agent-framework/pull/6267) | Foundry 支援自適應評估 |
| Sequential Orchestration 傳遞模式 | [#6554](https://github.com/microsoft/agent-framework/pull/6554) | 可選擇傳遞整段對話或僅前一步輸出 |
| Skill 內容明確輸出 available_resources / available_scripts | [#6672](https://github.com/microsoft/agent-framework/pull/6672) | `AgentInlineSkillContentBuilder.BuildAvailableResourcesBlock` / `BuildAvailableScriptsBlock` 明確輸出可用資源與腳本清單；撰寫端公開 API 不變 |
| A2A session store 預設改為 `NoopAgentSessionStore` | [#6635](https://github.com/microsoft/agent-framework/pull/6635) | `Microsoft.Agents.AI.Hosting.NoopAgentSessionStore`：A2A hosting 預設不再持久化 session |
| Skill scripts 自訂引數封送 | [#6498](https://github.com/microsoft/agent-framework/pull/6498) | 支援自訂引數處理的 skill scripts |
| Hyperlight 沙盒於工具註冊更新後自動重建 | [#6523](https://github.com/microsoft/agent-framework/pull/6523) | CodeAct/Hyperlight 在工具登錄變更後自動重建沙盒 |
| GitHub Copilot agent 串流投影 ToolExecution 事件 | [#6228](https://github.com/microsoft/agent-framework/pull/6228) | 將 ToolExecution 事件投影為 `FunctionCallContent`/`FunctionResultContent` |

---

## Bug 修復（.NET）

| 問題 | PR | 說明 |
|------|-----|------|
| OpenTelemetry `execute_tool` span 位置 | [#6667](https://github.com/microsoft/agent-framework/pull/6667) | 修正 span 發射位置 |
| 以一般檔案項目取代 symlink index 項目 | [#6687](https://github.com/microsoft/agent-framework/pull/6687) | 修正 index 項目 |
| Fan-in checkpoint 邊狀態強化 | [#6491](https://github.com/microsoft/agent-framework/pull/6491) | 強化 workflow 邊狀態處理 |
| `InProcessRunnerContext` workflow 情境修復 | [#6551](https://github.com/microsoft/agent-framework/pull/6551) | 修正 in-process runner |
| Durable workflows status/respond 端點按 workflow 名稱限定 | [#6608](https://github.com/microsoft/agent-framework/pull/6608) | 修正路由範圍 |
| MCP thread 綁定至當前 agent | [#6531](https://github.com/microsoft/agent-framework/pull/6531) | 守護跨 agent session 派送 |
| AI Search 串流回應的引用 URL | [#6649](https://github.com/microsoft/agent-framework/pull/6649) | 修正 citation URL 發射 |
| ClientHeaders ambient scope 還原 | [#6517](https://github.com/microsoft/agent-framework/pull/6517) | 非串流執行之間還原 ambient scope |
| 結構化輸出僅取最後一則訊息 | [#6499](https://github.com/microsoft/agent-framework/pull/6499) | 修正 structured output |
| Filesystem checkpoint index 按 session 過濾 | [#6132](https://github.com/microsoft/agent-framework/pull/6132) | 修正 checkpoint index |
| 封存解壓路徑包含性守護 | [#6565](https://github.com/microsoft/agent-framework/pull/6565) | 強化 path containment |
| GitHub Copilot SDK build targets 觸及傳遞消費者 | [#6457](https://github.com/microsoft/agent-framework/pull/6457) | 修正 build targets |

---

## 維護與相依套件更新

| 項目 | 變更 | PR |
|------|------|-----|
| Anthropic.Foundry | 0.5.0 → 0.6.0 | [#6057](https://github.com/microsoft/agent-framework/pull/6057) |
| Azure.AI.Projects | → 2.1.0-beta.3 | [#6542](https://github.com/microsoft/agent-framework/pull/6542) |
| MessagePack | → 3.1.7 | [#6497](https://github.com/microsoft/agent-framework/pull/6497) |

> `Microsoft.Extensions.AI`（10.6.0）與 `ModelContextProtocol`（1.2.0）自 1.10.0 起未變。

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 | 嚴重性 |
|------|---------------|--------|
| `LocalCodeAct` 新套件（#6105） | `nuget-packages`、`codeact`（若有） | 🟢 Enhancement / 🟡 套件清單需補 |
| `LoopAgent`（#6384） | `long-running-operations` | 🟢 Enhancement（新 Harness 能力） |
| `FileAccessProvider` 核可 + 對齊（#6521、#6474） | `human-in-the-loop`、`long-running-operations` | 🟢 Enhancement（Harness 子系統） |
| MCP 每次執行可刷新驗證標頭（#6624） | `mcp-integration` | 🟢 Enhancement |
| A2A `NoopAgentSessionStore` 預設（#6635） | `a2a-protocol` | 🟢 行為變更（hosting 預設） |
| Skill available_resources/scripts 輸出（#6672） | `agent-skills` | 🟢 修復/增強（撰寫端 API 不變） |
| Sequential Orchestration 傳遞模式（#6554） | `orchestration-builders` | 🟢 Enhancement |
| Anthropic.Foundry 0.6.0 / Azure.AI.Projects 2.1.0-beta.3 / MessagePack 3.1.7 | `nuget-packages` | 🟡 Outdated（套件版本） |
