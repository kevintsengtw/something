---
source: https://github.com/microsoft/agent-framework/releases/tag/dotnet-1.7.0
fetched: 2026-06-06
release_date: 2026-05-26
version: 1.7.0
---

# .NET Agent Framework v1.7.0（2026-05-26）

## 重大變更（Breaking Changes）

### 1. AgentSkill API 改為 async resource / script lookup

**PR：** [#6030](https://github.com/microsoft/agent-framework/pull/6030)（@SergeyMenshykh）

重構 `AgentSkill` 系列 API，將原本以同步屬性（property getter）暴露的資源與腳本取得方式，改為 **async 查找方法**：

- 舊：`Content`（string getter）、`Resources`（完整列表屬性）、`Scripts`（完整列表屬性）
- 新：`GetContentAsync(CancellationToken)`、`HasResources` + `GetResourceAsync(name, ct)`、`HasScripts` + `GetScriptAsync(name, ct)`

`AgentClassSkill<TSelf>` 保留 virtual 的 `Resources`/`Scripts` 屬性供 reflection-based 探索，並 seal 新的 `HasResources`/`HasScripts`/`GetResourceAsync`/`GetScriptAsync` 覆寫。

**影響範圍：** 自訂繼承 `AgentClassSkill<T>`、`AgentInlineSkill`、檔案式 skill 的 .NET 專案，以及任何直接讀取 skill 資源/腳本屬性的程式碼。

---

## 新功能

### MCP 長時間任務支援（MCP client tools）

**PR：** [#5994](https://github.com/microsoft/agent-framework/pull/5994)（@peibekwe）

MCP（Model Context Protocol）client 工具新增 long-running task 操作支援。

### Magentic Orchestration 範例

**PR：** [#5823](https://github.com/microsoft/agent-framework/pull/5823)

新增 Magentic Orchestration 編排範例。

### Hosted-AgentSkills 範例（Foundry Skills 整合）

**PR：** [#6013](https://github.com/microsoft/agent-framework/pull/6013)（@rogerbarreto）

新增整合 Foundry Skills 的 hosted agent skills 範例。

---

## Bug 修復

| 問題 | PR | 說明 |
|------|-----|------|
| A2AAgent MessageId | [#6043](https://github.com/microsoft/agent-framework/pull/6043) | 修正從 `TaskStatusUpdateEvent` 取得 MessageId 的指派錯誤 |
| AGUI 平行工具呼叫渲染 | [#6009](https://github.com/microsoft/agent-framework/pull/6009) | 修正 AGUI 轉譯層中平行 tool call 的顯示問題 |
| HarnessConsole 渲染效能 | [#6014](https://github.com/microsoft/agent-framework/pull/6014) | 改善主控台渲染效率、減少畫面閃爍 |

---

## 維運

| 項目 | PR | 說明 |
|------|-----|------|
| Release solution 納入 Shell tool 專案 | [#6092](https://github.com/microsoft/agent-framework/pull/6092) | 建置調整 |
| 版本號更新至 1.7.0 | [#6093](https://github.com/microsoft/agent-framework/pull/6093) | Version bump |

---

## 影響概念對照

| 變更 | 影響的 wiki 條目 | 嚴重性 |
|------|---------------|--------|
| AgentSkill API → async resource/script lookup | `agent-skills`、`agent-class-skill`、`agent-inline-skill` | 🔴 Breaking |
| MCP 長時間任務支援 | `mcp-integration` | 🟢 新功能 |
| Magentic Orchestration 範例 | `magentic-orchestration` | 🟢 Enhancement |
| Hosted-AgentSkills（Foundry Skills） | `agent-skills` | 🟢 新功能 |
