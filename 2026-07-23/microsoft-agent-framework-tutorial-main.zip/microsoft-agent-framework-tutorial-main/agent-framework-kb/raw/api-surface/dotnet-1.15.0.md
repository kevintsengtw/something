---
source: agent-framework/dotnet/src
comparison: dotnet-1.13.0..dotnet-1.15.0
fetched: 2026-07-23
tag_commit: 2d34deeb8269ebaa2c27332e1bbf80726fa48b32
---

# .NET 1.15.0 API Surface 差異摘要

> 此檔為同步階段的候選摘要；正式 namespace、簽名與移除判定以 `raw/facts/dotnet-1.14.0-verified-changes.json` 與 `dotnet-1.15.0-verified-changes.json` 為準。

## 新增或改名的公開 API 候選

- AG-UI hosting：`AddAGUIServer`、`MapAGUIServer`。
- OpenAI Responses hosting：`OpenAIResponses`、`OpenAIResponsesRunRequest`。
- Hosted workflow：`HostedWorkflowRunResult`、`HostedWorkflowState`。
- Approval pipeline：`ApprovalNotRequiredFunctionBypassingChatClient`、`ApprovalResponseBindingChatClient`、`ToolAutoApprovalRuleContext`。
- Message injection：`EnqueueMessagesAsync`、`GetPendingMessagesAsync`。
- Harness mode/todo：`AgentModeProvider.GetModeAsync`、`SetModeAsync` 與 todo query methods。

## 移除或取代候選

- `Microsoft.Agents.AI.AGUI` 專案與舊 AG-UI model/event types 已自本 repo 移除；protocol types 改由外部 `AGUI.*` packages 提供。
- `AddAGUI`／`MapAGUI` 由 `AddAGUIServer`／`MapAGUIServer` 取代。
- `MessageInjectingChatClient.EnqueueMessages`／`GetPendingMessages` 由 async 版本取代。
- `NonApprovalRequiredFunctionBypassingChatClient`／`UseNonApprovalRequiredFunctionBypassing` 改名為 `ApprovalNotRequiredFunctionBypassingChatClient`／`UseApprovalNotRequiredFunctionBypassing`。

## 來源命令

```bash
git -C agent-framework diff --unified=0 dotnet-1.13.0..dotnet-1.15.0 -- dotnet/src
```
