---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0020-foundry-agent-type-naming.md
fetched: 2026-04-17
status: Accepted
date: 2026-03-06
contact: rogerbarreto
---

# ADR 0020: Foundry Agent Surface Stays Centered on ChatClientAgent

**Status:** Accepted
**Date:** 2026-03-06
**Contact:** rogerbarreto
**Deciders:** rogerbarreto, alliscode

## Context

The Microsoft Foundry integration supports two usage patterns:
1. Direct Responses — provide model, instructions, tools at runtime
2. Server-side versioned agents — manage `AgentVersion` resources via `AIProjectClient.Agents`

Considered adding public wrapper types `FoundryAgent`, `FoundryVersionedAgent`, `FoundryResponsesChatClient`.

## Decision

Keep the public surface centered on `ChatClientAgent`.

- Direct Responses scenarios: `AIProjectClient.AsAIAgent(...)`
- Versioned scenarios: `AIProjectClient.Agents` APIs + `AIProjectClient.AsAIAgent(version)`
- `CreateAIAgentAsync` and `GetAIAgentAsync` remain as **obsolete migration shims only**
- Public wrapper types `FoundryAgent`, `FoundryVersionedAgent`, `FoundryResponsesChatClient` **not added**

### Direct Responses

```csharp
AIProjectClient aiProjectClient = new(new Uri(endpoint), credential);

ChatClientAgent agent = aiProjectClient.AsAIAgent(
    model: deploymentName,
    instructions: "You are good at telling jokes.",
    name: "JokerAgent");
```

### Versioned Agent

```csharp
AgentVersion version = await aiProjectClient.Agents.CreateAgentVersionAsync(
    "JokerAgent",
    new AgentVersionCreationOptions(
        new PromptAgentDefinition(deploymentName)
        {
            Instructions = "You are good at telling jokes."
        }));

ChatClientAgent agent = aiProjectClient.AsAIAgent(version);
```

## Consequences

- Single agent abstraction (`ChatClientAgent`) avoids parallel type hierarchies
- `AIProjectClient` is the native Azure SDK entry point for versioned agent lifecycle
- `CreateAIAgentAsync` / `GetAIAgentAsync` are obsolete; new code should use `AsAIAgent`
