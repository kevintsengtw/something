---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0021-agent-skills-design.md
fetched: 2026-04-17
status: Proposed (partially implemented in v1.1.0)
date: 2026-03-23
contact: sergeymenshykh
---

# ADR 0021: Agent Skills Multi-Source Architecture

**Status:** Proposed (Class-based skills implemented in v1.1.0)
**Date:** 2026-03-23
**Contact:** sergeymenshykh
**Deciders:** rbarreto, westey-m, eavanvalkenburg

## Context

Agent Framework needs a unified Skills system supporting multiple sources: filesystem directories (SKILL.md), inline C# code, and reusable class libraries.

## Architecture

### Model-Facing Tools (Progressive Disclosure)

- `load_skill(skillName)` — returns full skill body
- `read_skill_resource(skillName, resourceName)` — access supplementary resources
- `run_skill_script(skillName, scriptName, arguments?)` — execute scripts

### Four Abstract Base Types

```csharp
public abstract class AgentSkill
{
    public abstract AgentSkillFrontmatter Frontmatter { get; }
    public abstract string Content { get; }
    public abstract IReadOnlyList<AgentSkillResource>? Resources { get; }
    public abstract IReadOnlyList<AgentSkillScript>? Scripts { get; }
}

public abstract class AgentSkillResource
{
    public string Name { get; }
    public string? Description { get; }
    public abstract Task<object?> ReadAsync(...);
}

public abstract class AgentSkillScript
{
    public string Name { get; }
    public string? Description { get; }
    public abstract Task<object?> RunAsync(AgentSkill skill, AIFunctionArguments arguments, ...);
}

public abstract class AgentSkillsSource
{
    public abstract Task<IList<AgentSkill>> GetSkillsAsync(...);
}
```

### Three Skill Categories

1. **File-Based Skills** (`AgentFileSkill`) — SKILL.md + resources/ + scripts/ directories
2. **Inline Skills** (`AgentInlineSkill`) — Fluent API for runtime definition
3. **Class-Based Skills** (`AgentClassSkill`) — C# class inheritance, reusable libraries

### v1.1.0 Implementation Status

- ✅ `AgentClassSkill` base class (PR #5027)
- ✅ Reflection-based resource/script discovery (PR #5183)
- ✅ Custom types in skill functions (PR #5152)
- ✅ File skill folder discovery alignment (PR #5078)
- ✅ Directory terminology standardization (PR #5205)
- ⏳ Inline skills (`AgentInlineSkill`) — still Proposed
- ⏳ Aggregating / Caching / Deduplicating sources — still Proposed
- ⏳ `AgentSkillsProviderBuilder` — still Proposed

### Class-Based Skill Example (v1.1.0)

```csharp
public class UnitConverterSkill : AgentClassSkill
{
    public override AgentSkillFrontmatter Frontmatter { get; } =
        new("unit-converter", "Converts between measurement units.");

    public override string Instructions => """
        Use this skill to convert values between metric and imperial units.
        """;

    public override IReadOnlyList<AgentSkillResource>? Resources { get; } =
    [
        new AgentInlineSkillResource("kg=2.205lb, m=3.281ft", "conversion-table"),
    ];

    public override IReadOnlyList<AgentSkillScript>? Scripts { get; } =
    [
        new AgentInlineSkillScript(Convert, "convert"),
    ];

    private static string Convert(double value, double factor)
        => JsonSerializer.Serialize(new { result = Math.Round(value * factor, 4) });
}
```

### Registration

```csharp
var source = new AgentInMemorySkillsSource([new UnitConverterSkill()]);
var provider = new AgentSkillsProvider(source);

AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    AIContextProviders = [provider],
});
```

## Decision Outcome

- Keep `AgentSkillResource` and `AgentSkillScript` (not reuse `AIFunction`)
- Make all agent skill classes internal initially (minimize public API)
- Caching at provider level (inside `AgentSkillsProvider`)
