---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0018-agentthread-serialization.md
fetched: 2026-04-17
status: Accepted
date: 2026-02-25
contact: westey-m
---

# ADR 0018: AgentSession Serialization

**Status:** Accepted
**Date:** 2026-02-25
**Contact:** westey-m
**Deciders:** sergeymenshykh, markwallace, rbarreto, dmytrostruk, westey-m, eavanvalkenburg, stephentoub

## Context and Problem Statement

Challenges with existing `SerializeSession` / `DeserializeSession` methods on AIAgent:
1. Each AgentSession implementation must create its own serialization logic → inconsistencies
2. Only one serialization format supported simultaneously
3. Batch serialization of multiple AgentSessions unsupported
4. Users may not recognize they need specialized methods

Core complication: attached behaviors with own state and external dependencies cannot be recreated through standard deserialization.

## Decision Drivers

- A: Support custom behaviors (AIContextProviders / ChatHistoryProviders)
- B: Enable standard serialization (JsonSerializer)
- C: Allow callers to access custom providers

## Considered Options

1. **Separate State from Behavior, Serialize State Only** — `[JsonIgnore]` on behavior props → "incomplete until first use"
2. **Separate State from Behavior, State-Only on AgentSession** — Generic `StateBag` property → providers become stateless ✅
3. **Maintain Current Custom Methods** — Keep existing approach

## Decision Outcome

**Option 2 selected** — cleanest separation of concerns.

Key consequences:
- Providers remain stateless across concurrent sessions
- Standard System.Text.Json compatibility
- Generic StateBag enables extensibility
- Provider access through agents (not sessions)
- Sessions valid immediately after deserialization
- Custom providers must use `ProviderSessionState<T>` (no instance field state)

## Key Rename

This ADR documents the conceptual shift from `AgentThread` to `AgentSession`:
- `AgentThread` was the original name
- Renamed to `AgentSession` to better reflect the stateful conversation concept
- All public APIs use `AgentSession` from this point forward
