---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0012-python-typeddict-options.md
fetched: 2026-05-08
---

---
status: proposed
contact: eavanvalkenburg
date: 2026-01-08
deciders: eavanvalkenburg, markwallace-microsoft, sphenry, alliscode, johanst, brettcannon
consulted: taochenosu, moonbox3, dmytrostruk, giles17
---

# Leveraging TypedDict and Generic Options in Python Chat Clients

## Context and Problem Statement

The Agent Framework Python SDK provides multiple chat client implementations for different providers (OpenAI, Anthropic, Azure AI, Bedrock, Ollama, etc.). Each provider has unique configuration options beyond the common parameters defined in `ChatOptions`. How can we provide type-safe, discoverable options for each chat client while maintaining a consistent API?

## Decision Outcome

Chosen option: **Option 2: TypedDict with Generic Type Parameters**

Each chat client is parameterized with a TypeVar bound to a provider-specific `TypedDict` that extends `ChatOptions`. This enables full type safety and IDE support.

```python
class AnthropicChatOptions(ChatOptions, total=False):
    top_k: int
    thinking: ThinkingConfig

class AnthropicChatClient(ChatClientBase[TAnthropicChatOptions]):
    ...
```

Users can extend:
```python
class MyAnthropicOptions(AnthropicChatOptions, total=False):
    custom_field: str

client = AnthropicChatClient[MyAnthropicOptions](...)
```

> **Note:** In .NET this is already achieved through overloads on `GetResponseAsync` for each provider-specific options class (e.g., `AnthropicChatOptions`, `OpenAIChatOptions`). This ADR applies to Python only.

## Key Details

- `ChatClientProtocol[TOptions]` is generic over options type, default: `ChatOptions`
- Provider TypedDicts extend `ChatOptions`
- `TProviderOptions = TypeVar("TProviderOptions", bound=TypedDict, default=ProviderChatOptions, contravariant=True)`
- Common options preserved and explicitly documented in Options class
- Extended to `ChatAgents` for proper typing of agent construction and run methods
