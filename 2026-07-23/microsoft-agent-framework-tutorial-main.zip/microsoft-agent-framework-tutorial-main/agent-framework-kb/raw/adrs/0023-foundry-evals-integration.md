---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0023-foundry-evals-integration.md
fetched: 2026-04-17
status: Accepted
date: 2026-02-27
contact: bentho
---

# ADR 0023: Agent Evaluation Architecture with Azure AI Foundry Integration

**Status:** Accepted
**Date:** 2026-02-27
**Contact:** bentho
**Deciders:** bentho, markwallace-microsoft, westey-m

## Context

Using Foundry Evals with agent-framework agents requires significant manual effort: type transformations,
tool schema mapping, data source wiring, trace ID handling. Also need to support non-Foundry evaluators
(local LLM-as-judge, RAGAS, DeepEval, Promptfoo) without provider lock-in.

## Decision

**Evaluator protocol with shared orchestration** — provider-agnostic `IAgentEvaluator` interface in
`Microsoft.Agents.AI`; Foundry implementation in Azure package.

### .NET API

```csharp
// Foundry evaluator
var evals = new FoundryEvals(
    chatConfiguration,
    FoundryEvals.Relevance,
    FoundryEvals.Coherence);

// Evaluate an agent with test queries
AgentEvaluationResults results = await agent.EvaluateAsync(
    new[] {
        "What's the weather in Seattle?",
        "Plan a weekend trip to Portland",
    },
    evals);

results.AssertAllPassed();

// Custom evaluator
public class MyEvaluator : IAgentEvaluator
{
    public Task<EvaluationResults> EvaluateAsync(
        IReadOnlyList<EvaluationItem> items,
        CancellationToken ct = default) => ...;
}
```

### IAgentEvaluator Interface

```csharp
public interface IAgentEvaluator
{
    Task<EvaluationResults> EvaluateAsync(
        IReadOnlyList<EvaluationItem> items,
        CancellationToken cancellationToken = default);
}
```

### Key Types

- `IAgentEvaluator` — core interface in `Microsoft.Agents.AI`
- `FoundryEvals` — Foundry implementation with built-in evaluators (Relevance, Coherence, TaskAdherence, ToolCallAccuracy)
- `EvaluationItem` — single query/response pair with tool call history
- `AgentEvaluationResults` — aggregated results with per-query scores

## Consequences

- Zero-friction: `agent.EvaluateAsync(queries, evaluators)` is all that's needed
- Provider-agnostic: any `IAgentEvaluator` implementation works
- Foundry results viewable in Azure AI Foundry portal
- Supports single agents, workflows, multi-turn conversations
