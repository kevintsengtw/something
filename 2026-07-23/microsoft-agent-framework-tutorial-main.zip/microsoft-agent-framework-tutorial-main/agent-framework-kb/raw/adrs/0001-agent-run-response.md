---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0001-agent-run-response.md
fetched: 2026-04-17
status: Accepted
date: 2025-07-10
contact: westey-m
---

# ADR 0001: Agent Run Responses

**Status:** Accepted
**Date:** 2025-07-10

## Context

Agent systems generate diverse outputs: text responses, structured confirmations, tool invocations, reasoning output, agent handoffs, typing indicators, long-running process references.

## Decision Outcome

Custom response types (`AgentResponse` / `AgentResponseUpdate`) that can evolve independently from MEAI types.

### API

```csharp
class AgentResponse
{
    public string Text { get; }            // TextContent aggregation
    public IList<ChatMessage> Messages { get; set; }
    public string? ResponseId { get; set; }
    public UsageDetails? Usage { get; set; }
}

class AgentResponseUpdate
{
    public string Text { get; }            // TextContent aggregation
    public IList<AIContent> Contents { get; set; }
    public string? ResponseId { get; set; }
}
```

### Key Principles

- `RunAsync` returns `AgentResponse` (non-streaming)
- `RunStreamingAsync` returns `IAsyncEnumerable<AgentResponseUpdate>` (streaming)
- Primary responses use `TextContent`, `DataContent`, `UriContent`
- Secondary content (progress) uses custom `AIContent`-derived types
- `.Text` property for simple getting-started experience
- Structured output via `response.TryParseStructuredOutput<T>()`
- Long-running support via `AgentRun` property + `ChatFinishReason.LongRunning`
