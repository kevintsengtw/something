---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0021-provider-leading-clients.md
fetched: 2026-04-17
status: Accepted
date: 2026-03-20
contact: eavanvalkenburg
---

# ADR 0021 (Python): Provider-Leading Client Design & OpenAI Package Extraction

**Status:** Accepted (Python SDK only)
**Date:** 2026-03-20
**Contact:** eavanvalkenburg

## Context

Python `agent-framework-core` bundled OpenAI/Azure OpenAI dependencies, making core heavier for
non-OpenAI users. Class naming was API-based (`OpenAIResponsesClient`) rather than provider-based.

## Decision

Extract OpenAI to a new `agent-framework-openai` package; rename classes to be provider-leading.

### Key Changes (Python)

| Old name | New name | Note |
|----------|----------|------|
| `OpenAIResponsesClient` | `OpenAIChatClient` | Responses API (recommended default) |
| `OpenAIChatClient` | `OpenAIChatCompletionClient` | Chat Completions API |
| `OpenAIAssistantsClient` | — | Deprecated |
| All `AzureOpenAI*` classes | — | Deprecated; moved to single file |

### New `FoundryChatClient` (azure-ai package)

For Azure AI Foundry Responses API access.

### .NET Impact

.NET already has separate packages. This ADR is Python-only. .NET naming (`ChatClientAgent`,
`IChatClient` extension methods per provider) is unchanged.

### Python Agent Naming

For Python, `FoundryAgent(Agent)` is introduced:

```python
from agent_framework.azure import FoundryAgent

agent = FoundryAgent(agent_name="my-agent", ...)
```

This replaces the `Agent(client=AzureAIClient(...))` pattern. The `_FoundryAgentChatClient` is internal;
`RawFoundryAgentChatClient` is public for advanced customization.

## Consequences

- Lightweight core (no OpenAI dependencies in `agent-framework-core`)
- Discoverability-first: `from agent_framework.openai import ...` surfaces all OpenAI clients
- Backward-compatible import paths via lazy-loading gateways
