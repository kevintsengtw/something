---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0008-python-subpackages.md
fetched: 2026-05-08
---

---
status: accepted
contact: eavanvalkenburg
date: 2025-09-19
deciders: eavanvalkenburg, markwallace-microsoft, ekzhu, sphenry, alliscode
consulted: taochenosu, moonbox3, dmytrostruk, giles17
---

# Python Subpackages Design

## Context and Problem Statement

The goal is to design a subpackage structure for the Python agent framework that balances ease of use, maintainability, and scalability. How can we organize the codebase to facilitate the development and integration of connectors while minimizing complexity for users?

## Decision Drivers

- Ease of use for developers
- Maintainability of the codebase
- User experience for installing and using the integrations
- Clear lifecycle management for integrations
- Minimize non-GA dependencies in the main package

## Decision Outcome

Option 7 was chosen: Subpackage existence based on status of dependencies and/or possibilities of external support.

Key rules:
- Integrations needing non-GA dependencies → subpackages
- Integrations where AF-code is still experimental/preview/RC → subpackages
- Integrations outside Microsoft where fast-following breaking changes may be difficult → subpackages
- Mature integrations with GA dependencies → moved into main package (imports stay stable)
- All subpackage imports use stable vendor-based paths (e.g., `from agent_framework.google import GoogleChatClient`)
- Subpackage naming: `<vendor>-<feature>` (e.g., `google-gemini`, `azure-purview`)

## Microsoft vs Azure packages

Azure and Microsoft are the two vendor folders: Copilot Studio → `agent_framework.microsoft`; Foundry/Azure OpenAI/other Azure services → `agent_framework.azure`.
