---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0011-create-get-agent-api.md
fetched: 2026-04-17
status: Proposed
date: 2025-12-12
contact: dmytrostruk
---

# ADR 0011: Create/Get Agent API Alignment

**Status:** Proposed
**Date:** 2025-12-12
**Contact:** dmytrostruk

## Context

Misalignment between .NET and Python create/get agent APIs. In .NET, provider-specific extension
methods handle both local and remote agent creation. Python only had `create_agent` for local instances.

## Decision

Python implements Provider object pattern (`AzureAIProjectAgentProvider`, `OpenAIAssistantProvider`).
.NET extension method approach unchanged.

### Python (new)

```python
from agent_framework.azure import AzureAIProjectAgentProvider
from azure.ai.projects import AIProjectClient

client = AIProjectClient(endpoint, credential)
provider = AzureAIProjectAgentProvider(client)

# Create new agent on service
agent = await provider.create_agent(name="MyAgent", model="gpt-4", instructions="...")
# Get existing agent by name
agent = await provider.get_agent(agent_name="MyAgent")
# Wrap already-fetched SDK object (no HTTP call)
agent = provider.as_agent(agent_ref)
```

### .NET (unchanged)

```csharp
// Local agent
ChatClientAgent agent = chatClient.AsAIAgent(options);

// Remote agents via provider-specific extension methods
var agent = await aiProjectClient.CreateAIAgentAsync(name, model, instructions, tools);
var agent = await aiProjectClient.GetAIAgentAsync(agentId);

// Note: per ADR 0020, CreateAIAgentAsync / GetAIAgentAsync are now obsolete shims
// Prefer: aiProjectClient.AsAIAgent(...)  or  aiProjectClient.AsAIAgent(agentVersion)
```

### Method Naming Convention

| Operation | Python | .NET |
|-----------|--------|------|
| Create on service | `create_agent()` | `CreateAIAgent()` (obsolete → `AsAIAgent`) |
| Get from service | `get_agent(id=...)` | `GetAIAgent(agentId)` (obsolete → `AsAIAgent`) |
| Wrap SDK object | `as_agent(reference)` | `AsAIAgent(instance)` |

## Consequences

- Python providers offer clear grouping and IDE discoverability
- Multiple agent types per package disambiguated by provider class name
- .NET .AsAIAgent() is the canonical approach going forward (per ADR 0020)
