---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0013-python-get-response-simplification.md
fetched: 2026-05-08
---

---
status: Accepted
contact: eavanvalkenburg
date: 2026-01-06
deciders: markwallace-microsoft, dmytrostruk, taochenosu, alliscode, moonbox3, sphenry
consulted: sergeymenshykh, rbarreto, dmytrostruk, westey-m
---

# Simplify Python Get Response API into a single method

## Context and Problem Statement

Currently chat clients must implement two separate methods for streaming and non-streaming responses. This adds complexity and maintenance burden. In Python (unlike .NET), proper typing with a single method is possible, and this also aligns with how the OpenAI Python client works.

## Decision Outcome

**Option 3: Consolidate + Merge Agent and Workflow Methods**

Single `get_response(stream=True/False)` method for both `ChatClient`, `Agent`, and `Workflow`.
Default: `stream=False` (maintains backward compatibility, simpler for new users).

```python
# Non-streaming
response = await client.get_response(message, tools=get_weather)
print(response.text)

# Streaming - same method, different parameter
async for chunk in client.get_response(message, tools=get_weather, stream=True):
    if chunk.text:
        print(chunk.text, end="")

# Agent usage
result = await agent.run(message, thread=thread)  # stream=False default
async for update in agent.run(message, thread=thread, stream=True):
    ...
```

## Key Impact

| Layer | Before | After |
|-------|--------|-------|
| Protocol | `get_response()` + `get_streaming_response()` | `get_response(stream=...)` |
| Agent | `run()` + `run_stream()` | `run(stream=...)` |
| Workflow | `run()` + `run_stream()` | `run(stream=...)` |

> **Note:** .NET keeps separate `RunAsync` / `RunStreamingAsync` for type clarity. This simplification is Python-only.
