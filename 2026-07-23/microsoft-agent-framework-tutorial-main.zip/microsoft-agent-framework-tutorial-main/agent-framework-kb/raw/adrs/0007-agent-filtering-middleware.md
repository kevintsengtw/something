---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0007-agent-filtering-middleware.md
fetched: 2026-04-17
status: Proposed
date: 2025-09-15
contact: rogerbarreto
---

# ADR 0007: Agent Filtering Middleware Design

**Status:** Proposed
**Date:** 2025-09-15
**Contact:** rogerbarreto

## Context

The Agent Framework lacks standardized middleware for intercepting agent execution. Developers need extensible mechanisms supporting streaming/non-streaming, DI, and handling invocation, function calls, approvals, and errors.

## Decision

**Decorator Pattern** selected over SK-style filters and dedicated processor.

### Core Context Types

```csharp
public abstract class AgentContext
{
    public AIAgent Agent { get; }
    public AgentRunOptions? Options { get; set; }
}

public class AgentRunContext : AgentContext
{
    public IList<ChatMessage> Messages { get; set; }
    public AgentResponse? Response { get; set; }
    public AgentThread? Thread { get; }
}

public class AgentFunctionInvocationContext : AgentToolContext
{
    public AIFunction Function { get; set; }
    public AIFunctionArguments Arguments { get; set; }
    public bool IsStreaming { get; set; }
}
```

### Middleware Delegate Signature

```csharp
// Context-based middleware
Func<AgentMiddlewareContext, AgentMiddlewareDelegate, Task>
```

### Builder Pattern

```csharp
var agent = client.CreateAIAgent(model)
    .AsBuilder()
    .Use(async (context, next) => {
        // pre-processing
        await next(context);
        // post-processing
    })
    .Build();
```

## Note

The current implementation in v1.0.0+ uses `AgentMiddlewareContext` and `AgentMiddlewareDelegate` as the standardized types. The ADR's `AgentRunContext` / `AgentFunctionInvocationContext` represent the design-stage naming.
