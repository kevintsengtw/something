---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0003-agent-opentelemetry-instrumentation.md
fetched: 2026-04-17
status: Proposed
date: 2025-07-14
contact: rogerbarreto
---

# ADR 0003: Agent OpenTelemetry Instrumentation

**Status:** Proposed
**Date:** 2025-07-14
**Contact:** rogerbarreto

## Context

Agent Framework lacks agent-level observability. Underlying `IChatClient` implementations may have their own telemetry, but no standardized way to capture agent-specific metrics and traces at the agent abstraction level.

## Decision

**OpenTelemetryAgent Wrapper Pattern** — follows exact `Microsoft.Extensions.AI` `OpenTelemetryChatClient` pattern.

### API

```csharp
// Create and wrap agent with telemetry
var baseAgent = chatClient.AsAIAgent(options);
using var telemetryAgent = baseAgent.WithOpenTelemetry();

// Or with TracerProvider
using var tracerProvider = Sdk.CreateTracerProviderBuilder()
    .AddSource(AgentOpenTelemetryConsts.DefaultSourceName)
    .AddConsoleExporter()
    .Build();

var response = await telemetryAgent.RunAsync(messages);
```

### Key Types

- `OpenTelemetryAgent` — delegating wrapper implementing agent interface with OTel instrumentation
- `AgentOpenTelemetryConsts` — constants for attribute names and metric definitions
- `.WithOpenTelemetry()` extension method — convenience wrapper

### Telemetry Data Captured

**Activities/Spans:** `agent.operation.name`, `agent.request.id`, `agent.request.message_count`,
`agent.request.thread_id`, `agent.response.finish_reason`, `agent.usage.input_tokens`, `agent.usage.output_tokens`

**Metrics:** Operation duration histogram, token usage histogram (input/output), request count counter

## Consequences

- Optional and non-intrusive (explicit `.WithOpenTelemetry()` wrapping required)
- Consistent with Microsoft.Extensions.AI telemetry conventions
- Agent-level traces without duplicating underlying ChatClient telemetry
