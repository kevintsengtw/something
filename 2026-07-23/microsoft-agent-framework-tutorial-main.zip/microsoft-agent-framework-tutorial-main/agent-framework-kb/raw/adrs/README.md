---
source: https://github.com/microsoft/agent-framework/tree/main/docs/decisions
fetched: 2026-04-17
last_sync: 2026-04-17
---

# Agent Framework ADR 完整清單

> 來源：`microsoft/agent-framework/docs/decisions/`

## 已收錄（raw/adrs/）

| ADR | 標題 | 狀態 |
|-----|------|------|
| 0001 | Agent Run Responses | Accepted |
| 0002 | Agent Tools Unified Abstraction | Proposed |
| 0003 | Agent OpenTelemetry Instrumentation | Proposed |
| 0006 | User Approval / UserInputRequestContent | Accepted |
| 0007 | Agent Filtering Middleware | Proposed |
| 0009 | Long-Running Operations | Accepted |
| 0010 | AG-UI Protocol Support | Accepted |
| 0011 | Create/Get Agent API Alignment | Proposed |
| 0014 | Feature Collections | Accepted |
| 0015 | AgentRunContext | Proposed |
| 0016 | Structured Output (RunAsync\<T\>) | Proposed |
| 0018 | AgentSession Serialization | Accepted |
| 0020 | Foundry Agent Type Naming (ChatClientAgent stays) | Accepted |
| 0021 | Agent Skills Multi-Source Architecture | Proposed (partially v1.1.0) |
| 0021b | Provider-Leading Clients (Python) | Accepted |
| 0022 | Chat History Persistence Consistency | Accepted |
| 0023 | Foundry Evals Integration | Accepted |
| 0024 | CodeAct Integration | Proposed |

## 未收錄（Python-specific 或範圍外）

| ADR | 標題 | 備註 |
|-----|------|------|
| 0004 | Foundry SDK Extensions | 教學 ch17 相關，待補 |
| 0017 | Agent Additional Properties | 類似 0014，待評估 |
| 0005, 0008, 0012, 0013, 0016(py), 0019 | Python-specific ADRs | 教學為 C# 專用，暫不收錄 |
