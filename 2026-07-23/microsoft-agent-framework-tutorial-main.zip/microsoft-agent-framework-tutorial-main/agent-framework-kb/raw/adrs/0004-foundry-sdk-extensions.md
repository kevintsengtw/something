---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0004-foundry-sdk-extensions.md
fetched: 2026-04-23
status: Proposed
date: 2025-08-06
contact: markwallace-microsoft
---

# ADR 0004: Azure.AI.Agents.Persistent 套件擴充方法

**Status:** Proposed
**Date:** 2025-08-06
**Contact:** markwallace-microsoft
**Deciders:** markwallace-microsoft, westey-m, quibitron, trrwilson

## Context

目標是透過建立擴充方法，將 `Azure.AI.Agents.Persistent` NuGet 套件與 Agent Framework 對齊。這些擴充方法讓開發者可以透過 `PersistentAgentsClient` 實例化或取得 `AIAgent` 實例。

## 決策結果

**選擇 Option 3：** 建立新的 `Microsoft.Extensions.AI.Azure` 套件

**理由：** 對核心 `Azure.AI.Agents.Persistent` 套件不增加傳遞性相依性，同時維持架構分離。

## 三個考慮選項

| 選項 | 說明 | 優點 | 缺點 |
|------|------|------|------|
| Option 1 | 擴充方法放在 `Azure.AI.Agents.Persistent`，變更相依性 | 擴充方法與套件同位 | 增加傳遞性相依性 |
| Option 2 | 擴充方法放在 `Azure.AI.Agents.Persistent`，不變更相依性 | 最小相依性 | 增加 abstractions 套件複雜度 |
| **Option 3** | 新建 `Microsoft.Extensions.AI.Azure` 套件 | 核心套件無新增相依性 | 需開發者明確安裝 |
