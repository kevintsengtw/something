---
source: https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0010-ag-ui-support.md
fetched: 2026-04-17
status: Accepted
date: 2025-10-29
contact: javiercn
---

# ADR 0010: AG-UI Protocol Support

**Status:** Accepted
**Date:** 2025-10-29
**Contact:** javiercn

## Context

Standardized communication between AI agents and user applications. AG-UI enables streaming support, event-driven architecture, and protocol interoperability.

## Decision

Internal event types with framework-native abstractions (not exposing AG-UI events directly).

### Implementation

- **Client-side:** `AGUIAgent` class with HTTP/SSE streaming
- **Server-side:** `MapAGUIAgent` extension for ASP.NET Core with SSE formatting
- **Focus:** Text streaming with lifecycle events (RunStarted, RunFinished, RunError)

### Key Points

1. AG-UI event types remain internal; conversions via extension methods
2. No custom content types — lifecycle via existing `ChatResponseUpdate` properties
3. Agent factory pattern for per-request multi-tenancy configuration
4. `thread_id` is a protocol-level field (AG-UI spec), not related to the old AgentThread naming

## Consequences

- .NET agents interoperate with AG-UI-compatible systems
- Protected from protocol evolution
- Symmetric client/server conversion logic
