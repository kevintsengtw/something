# 工作流遷移記錄（v1 → v2）

> **歷史決策記錄**：本文中的未勾選項目不代表目前仍待執行。Codex 接手後的操作入口為工作區根 `AGENTS.md`、`.agents/skills/` 與本目錄 `QuickStart.md`。

> 記錄 2026-05-26 同日進行的工作區重組與工具決策歷程，作為審計憑證。

---

## 摘要

| 面向 | v1（2026-04 ~ 05 中旬） | v2（2026-05-26 起） |
|------|------------------------|---------------------|
| 指令入口點 | `agent-framework-kb/.claude/commands/` | `agent-framework-tutorial/.claude/commands/`（工作區根） |
| Master CLAUDE.md | `agent-framework-kb/CLAUDE.md` | `agent-framework-tutorial/CLAUDE.md`（新增） |
| 事實層工具 | codebase-memory-mcp（Windows） | codebase-memory-mcp（macOS 待驗證） |
| 敘述層工具 | 無 | Understand-Anything plugin |
| Pipeline 條數 | 1（KB 維護） | 4（A 版本更新 / B 探索 / C Onboarding / D 教學建立） |
| 自訂指令數 | 7 | 12（新增 extract-facts、snapshot-knowledge、draft-chapter、draft-appendix、regenerate-toc） |
| 跨平台策略 | macOS 主 + Windows 備援 | **唯 macOS** |

---

## 三次決策歷程

### 決策一：指令入口點上移到工作區根（2026-05-26）

**問題**：v1 把指令入口放在 `agent-framework-kb/.claude/`，但工作流橫跨三層子目錄（agent-framework / agent-framework-kb / microsoft-agent-framework-tutorial），入口偏袒任一子目錄都顯得不對稱。

**決定**：把 `.claude/commands/` 上移到 `agent-framework-tutorial/`（工作區根）。

**結果**：
- 工作區根新增 `CLAUDE.md`（master orchestration）
- 工作區根新增 `.claude/commands/`（12 個指令檔）
- 工作區根新增 `.mcp.json`（MCP server 設定）
- 工作區根新增 `.gitignore`
- 舊 `agent-framework-kb/.claude/`、`.mcp.json`、`ARCH-cross-platform.md` 全部刪除
- `agent-framework-kb/CLAUDE.md` 降位為「kb 補充指引」

### 決策二：工作流範圍擴張到「教學文件建立」（2026-05-26）

**問題**：v1 工作流只覆蓋「知識庫維護」與「教學偏移修正」（`/update-tutorial`），沒有「從零建立新教學章節」的能力。實際使用上常需要對新概念草擬章節。

**決定**：新增 **Pipeline D：教學文件建立**，包含三個指令：
- `/draft-chapter <wiki-concept> [chapter-no]` —— 從 wiki 概念草擬新章節
- `/draft-appendix <topic>` —— 草擬新附錄
- `/regenerate-toc` —— 重建 README 章節索引

並擴張 `/lint` 涵蓋教學側一致性檢查（內部連結、code block 語言標籤、API 抽樣查驗、README TOC 一致性）。

**設計約束**：草稿永遠輸出到 `outputs/`，**不直接寫入 tutorial/**，由人工確認後手動移動。

### 決策三：事實層工具保留為 codebase-memory-mcp（2026-05-26）

**演進過程**：

1. **起點**：v1 使用 codebase-memory-mcp（在 Windows 已實戰驗證）
2. **評估期**：考慮改用 GitNexus + Understand-Anything，理由是 GitNexus 在 Claude Code 整合更原生、UA 補強了視覺化能力
3. **發現**：工作區內 `agent-framework/.gitnexus/` 與 GitNexus 注入的 `CLAUDE.md`/`AGENTS.md` 是 Windows 上**失敗安裝**的殘留——使用者實際在 Windows 上跑通的是 codebase-memory-mcp，不是 GitNexus
4. **第一版實作**：完成 12 個指令的 GitNexus 版（基於「整套設計已落地、UA 與 GitNexus 配對更原生」的推論）
5. **重新權衡**：使用者明確表示「GitNexus 的使用成本會比 codebase-memory-mcp 來得高」——換工具的不確定性（C# 準度驗證、學習成本、撞 bug 風險）大於收益
6. **反向施工**：撤銷 GitNexus 版本，把 12 個指令、`.mcp.json`、`settings.local.json`、兩份 CLAUDE.md、WORKFLOW-DESIGN-v2.md 全部對齊回 codebase-memory-mcp

**保留 Understand-Anything**：UA 與 codebase-memory-mcp 不互斥。UA 仍擔任敘述層的視覺化、`/understand-knowledge` 對 Karpathy LLM Wiki 的支援、繁中 dashboard 等職責。

**最終工具決策**：
- 事實層：**codebase-memory-mcp**
- 敘述層：**Understand-Anything**
- 不導入：GitNexus

---

## 清理動作（2026-05-26）

| 路徑 | 處置 | 原因 |
|------|------|------|
| `agent-framework-kb/.claude/` | 整個刪除 | 入口點上移到工作區根 |
| `agent-framework-kb/.mcp.json` | 刪除 | 工作區根 .mcp.json 接手 |
| `agent-framework-kb/ARCH-cross-platform.md` | 刪除 | 雙平台策略作廢，唯 macOS |
| `agent-framework-kb/CTemp*`（4 個） | 已清除 | 暫存殘留 |
| `agent-framework/.gitnexus/` | 整個刪除 | Windows 上 GitNexus 失敗安裝殘留 |
| `agent-framework/CLAUDE.md` | 刪除 | GitNexus 注入殘留，untracked |
| `agent-framework/AGENTS.md` | 刪除 | GitNexus 注入殘留，untracked |

`agent-framework/` 內真正的 SDK 原始碼（`dotnet/`、`python/` 等）**完全未動**。

---

## 學到的東西

1. **「整套設計已落地」是 sunk cost**——不應作為支持新工具的理由。決策三的反向施工花了和正向施工差不多的時間，但最終結果更可靠。

2. **「對抗幻覺要 ground truth」這類核心需求，多個工具可滿足時，選使用成本低的那個**。codebase-memory-mcp 與 GitNexus 都是 tree-sitter deterministic parser，事實層性質相同——這時候已驗證可用的工具勝過理論上更好但未驗證的。

3. **平台殘留檔不是「半部署」**。`.gitnexus/` 看起來像是 GitNexus 已部署的證據，但實際是失敗安裝的殘留。觀察工作區狀態時應該問「這個檔是怎麼來的」，而不是直接推論「已存在所以可用」。

4. **「事實層」與「敘述層」的二分必須嚴格**。LLM 不負責判斷 API 是否存在，deterministic parser 不負責生成敘述。兩個 LLM-based 工具疊起來沒有 ground truth 意義。

---

## 後續進度

- [x] **codebase-memory-mcp macOS 驗證**（2026-05-26 完成，6/7 通過）—— 環境：macOS 26.5、Node.js v24.15.0、codebase-memory-mcp v0.6.1；索引 44,650 nodes / 180,686 edges；詳見 [`./raw/facts/codebase-memory-mcp-validation.md`](./raw/facts/codebase-memory-mcp-validation.md)
  - 失敗項：探測 4 `AgentMiddlewareDelegate`（規格過時，該型別在 v1.6.1 已不存在）
  - 部分通過：探測 6 `trace_path` 短名稱模糊限制（工具特性，非索引品質問題）
  - 已記錄探測規格修訂建議（驗證檔 §7），下次重跑驗證時採用
- [ ] 跑一次完整 Pipeline A（在當前 v1.6.1 基準上模擬），確認流程通順
- [ ] 試跑 `/draft-chapter` 對某個既有概念做試作，比對品質
- [ ] 工作區根 `EVAL-llm-wiki-feasibility.md`、`GUIDE-llm-wiki-setup.md`（4 月版本）人工檢視是否仍有效

---

## 相關文件

- [`./WORKFLOW-DESIGN-v2.md`](./WORKFLOW-DESIGN-v2.md) —— v2 工作流完整設計
- [`../CLAUDE.md`](../CLAUDE.md) —— 工作區根主導文件
- [`./CLAUDE.md`](./CLAUDE.md) —— kb 補充指引
- [`./PLAYBOOK-version-update.md`](./PLAYBOOK-version-update.md) —— Pipeline A 操作手冊
