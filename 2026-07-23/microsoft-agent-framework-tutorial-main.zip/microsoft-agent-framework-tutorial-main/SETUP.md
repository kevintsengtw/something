# 新機器環境設定指南

本文說明如何在 macOS 上建立 Codex-first 的完整維護環境。Claude Code 只在重建 Understand-Anything（UA）知識圖譜時需要。

## 前置需求

| 工具 | 最低需求 | 用途 |
| --- | --- | --- |
| Codex | 可讀取 project skills 與 `.codex/config.toml` 的版本 | 主要維護入口 |
| Node.js | 18+ | codebase-memory-mcp、UA Dashboard |
| codebase-memory-mcp | 0.6.1+ | 上游原始碼結構事實 |
| Python | 3.11+ | deterministic validator 與 skill 驗證 |
| .NET SDK | 8.0+ | 執行或驗證教學範例 |
| gh | 已登入（同步工作才需要） | 讀取 GitHub release、samples 與 ADR |
| Claude Code + UA | 選用 | 只用於 `$snapshot-knowledge` 的圖譜生成階段 |

```bash
codex --version
node --version
python3 --version
dotnet --version
gh auth status
```

## 1. Clone 工作區

```bash
git clone https://github.com/kevintsengtw/microsoft-agent-framework-tutorial.git agent-framework-tutorial
cd agent-framework-tutorial
```

Codex 必須從工作區根啟動，才能載入根 `AGENTS.md`、`.agents/skills/` 與 `.codex/config.toml`。

## 2. Clone 上游 SDK

`agent-framework/` 是被 gitignore 的本機唯讀基準，固定放在工作區根內：

```bash
git clone https://github.com/microsoft/agent-framework.git agent-framework
git -C agent-framework fetch --tags origin
```

從 [`agent-framework-kb/UPSTREAM-REF.md`](./agent-framework-kb/UPSTREAM-REF.md) 讀取目前 tag 或 commit，再以 detached HEAD 對齊。例如目前基準為：

```bash
git -C agent-framework checkout --detach dotnet-1.13.0
git -C agent-framework status --short --branch
```

不要在上游 clone 內建立教學專案檔案、套用 patch 或提交變更。

## 3. 安裝並連接 codebase-memory-mcp

```bash
npm install -g codebase-memory-mcp
codebase-memory-mcp --version
```

專案已在 `.codex/config.toml` 宣告 STDIO server。信任此 project 後重新啟動 Codex，使用 `/mcp` 確認 `codebase-memory-mcp` 已啟用。

首次索引可透過 MCP `index_repository`，或直接執行 CLI：

```bash
codebase-memory-mcp cli index_repository \
  "{\"repo_path\":\"$(pwd)/agent-framework\"}"
codebase-memory-mcp cli list_projects '{}'
```

project name 會由絕對路徑產生。後續 skills 會以 `list_projects` 的 `root_path` 找出正確名稱，不應假設名稱就是 `agent-framework`。

若本機已有其他索引，不要直接執行 `codebase-memory-mcp install -y`；該安裝流程可能要求刪除並重建所有既有 index database。

## 4. 驗證 Codex 工作區

```bash
python3 scripts/validate_workspace.py --require-upstream --check-upstream-clean
```

接著在 Codex 中確認：

1. `list_projects` 能找到 `root_path` 結尾為 `/agent-framework` 的 project。
2. `index_status` 為 `ready`。
3. `search_graph` 能找到 `AgentSkillsProvider`。
4. `$wiki-query`、`$lint` 等 repo skills 可被列出或明確呼叫。

完整的 C# parser 探測規格見 [`agent-framework-kb/raw/facts/codebase-memory-mcp-validation.md`](./agent-framework-kb/raw/facts/codebase-memory-mcp-validation.md)。切換機器、MCP major version 升級或跨越重要 upstream 版本時重跑。

## 5. 啟動 Codex

```bash
codex
```

常用流程見 [`agent-framework-kb/QuickStart.md`](./agent-framework-kb/QuickStart.md)。例行修改後至少執行：

```bash
python3 scripts/validate_workspace.py
```

## 6. 選用：Understand-Anything 混合流程

Codex 可以讀取與驗證已 commit 的 UA graph，但目前不直接生成 UA graph。需要重建時，在 Claude Code 安裝 plugin：

```text
/plugin marketplace add Lum1104/Understand-Anything
/plugin install understand-anything
/understand-knowledge agent-framework-kb/wiki --language zh-TW
```

完成後回到 Codex 執行：

```bash
python3 scripts/validate_workspace.py
git diff -- agent-framework-kb/wiki/.understand-anything
```

UA 正式產物固定為：

- `agent-framework-kb/wiki/.understand-anything/knowledge-graph.json`
- `agent-framework-kb/wiki/.understand-anything/meta.json`

`intermediate/` 與 `diff-overlay.json` 不得 commit。

Dashboard 的安裝路徑會隨 UA plugin 版本改變。先用 `claude plugin list` 查版本，再從對應 plugin cache 的 `packages/dashboard` 啟動；不要把固定的 cache 版本路徑寫進自動化。
