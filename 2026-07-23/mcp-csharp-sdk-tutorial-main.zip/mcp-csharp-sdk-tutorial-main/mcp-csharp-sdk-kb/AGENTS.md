# 知識庫維護指引

本檔補充工作區根 `AGENTS.md`，適用於 `mcp-csharp-sdk-kb/` 全目錄。

## 目錄邊界

- `raw/release-notes/`、`raw/docs-conceptual/`、`raw/devblogs/`、`raw/samples/`、`raw/api-surface/` 是上游素材鏡像；只能由 `sync-upstream` 工作流更新，不做即興改寫。
- `raw/facts/` 是已驗證結構性事實與稽核證據。
- `wiki/concepts/` 是由 facts 與上游素材編譯的敘述層。
- `wiki/.understand-anything/knowledge-graph.json` 與 `meta.json` 可提交；intermediate 與 diff overlay 不提交。
- `brainstorming/` 是探索性內容，不可直接當作 ground truth。

## Facts 與 API 規則

- frontmatter 的 `api_name`、`namespace`、`package`、`since`、`current_version` 必須來自 `raw/facts/*.json` 的 verified 資料。
- 未驗證的 API 欄位保持空白並標示待驗證，不得猜測。
- API 程式碼範例先查 `codebase-memory-mcp` 的 snippet 與上游 tests/samples。
- 套件歸屬以 `csharp-sdk/src/<Package>/...` 判定。
- 每個 session 先動態解析 `<csharp-sdk-project>`；不得使用字面 `csharp-sdk` 或提交本機完整 project name。
- `trace_path` 與 `get_code_snippet` 的名稱格式不同時，先以 `search_graph` 取得可用名稱。

## Wiki 格式

- 所有 wiki 敘述使用繁體中文，API 名稱保留英文。
- concept frontmatter 與必要段落遵守 `wiki/SCHEMA.md`。
- kb 內部維持 `[[wiki-style]]` 連結；目標 concept 必須存在。
- `wiki/INDEX.md` 必須涵蓋所有 concepts，且 tutorial chapter 對應必須存在。
- `sources` 中的 raw、facts 與上游路徑必須可追溯。

## Drift 分級

- 🔴 Breaking：教學可能無法編譯；必須由 MCP/上游原始碼確認。
- 🟡 Outdated：可運作但描述、版本或最佳實務過時。
- 🟢 Enhancement：上游新增但教學尚未涵蓋的功能。

## 完成條件

- 編譯 wiki 前 facts 已驗證且 indexed commit 已記錄。
- 變更後更新 INDEX、api-changelog 或 drift-report 中相依項目。
- 執行 `node ../scripts/lint-docs.mjs` 與受影響 skill 的驗證。
- knowledge graph 更新失敗時保留上一份有效快照，不得用不完整輸出覆寫。
