# Workflow Design v1 — codebase-memory-mcp + Understand-Anything

> 版本：v1（沿用 `agent-framework-tutorial` 的 v2 工作流設計，套用至 MCP C# SDK）
> 撰寫日期：2026-06-30
> 目標環境：**macOS**
> 狀態：✅ v1.4.0 首次建庫、七項探測、完整 Pipeline 與教學 20 章＋附錄 A/B/C 均已完成

---

## 1. 設計原則（Philosophy）

工具二分，不交叉：

| 層別 | 工具 | 職責 | 性質 |
|------|------|------|------|
| **事實層** | **codebase-memory-mcp** | 原始碼結構性事實的 ground truth | Deterministic（tree-sitter parser） |
| **敘述層** | **Understand-Anything + LLM** | 概念敘述、關係抽取、視覺化、Onboarding、教學撰寫 | LLM-based（語意理解） |

核心約束：
- 任何結構性宣告（API 名稱、簽名、namespace、所屬套件）**必須先經 codebase-memory-mcp 驗證**，再交給 LLM 寫敘述
- LLM 不得擅自宣告 API 存在或不存在
- 若 codebase-memory-mcp 在 macOS 上對此 repo 的 C# 解析品質不足，退化為純 grep + WebFetch 上游 GitHub 的方案

**端點目標**：建立、維護、擴充 `mcp-csharp-sdk-guide/`。

---

## 2. 前置條件（codebase-memory-mcp macOS 可用性驗證）

> ✅ **已於 2026-06-30 驗證 7/7 通過**。切換機器、索引工具主要版本變更或 cache schema 不相容時需重建索引並重跑探測。
> 結果記錄於 `raw/facts/codebase-memory-mcp-validation.md`。

### 已知工具使用慣例（沿用 agent-framework 專案實戰）
1. **外部依賴不索引**：`Microsoft.Extensions.AI.*`（`IChatClient`、`AIFunction`、`ChatOptions`）來自外部 NuGet，不在 `csharp-sdk` 圖譜中；改找使用端（in_degree > 0）。
2. **qualified_name 含路徑前綴**：呼叫 `get_code_snippet` 前先用 `search_graph` 找正確 qualified_name。
3. **`trace_path` 短名稱限制**：短名稱對應多節點時回空集，優先用 `search_graph` in_degree 或完整 qualified_name。

---

## 3. 架構（Workspace-Root Entry Point）

```text
mcp-csharp-sdk-tutorial/                    ← 工作區根（入口點）
├── AGENTS.md / CLAUDE.md                   ← Codex / Claude Code orchestration
├── .codex/config.toml / .mcp.json          ← Codex / Claude Code MCP 設定
├── .gitignore                              ← 排除 csharp-sdk/、UA scratch、草稿
├── .agents/skills/ / .claude/commands/     ← Codex skills / Claude commands
├── README.md / SETUP.md
│
├── csharp-sdk/                             ← Layer 1（事實層，codebase-memory-mcp 索引對象，唯讀、gitignore）
│
├── mcp-csharp-sdk-kb/                      ← Layer 2（敘述層）
│   ├── CLAUDE.md / WORKFLOW-DESIGN-v1.md / PLAYBOOK / QuickStart / UPSTREAM-REF / README
│   ├── wiki/SCHEMA.md / INDEX.md / api-changelog.md / drift-report.md
│   ├── wiki/concepts/                      ← LLM 編譯產出
│   ├── wiki/.understand-anything/          ← UA 產出（snapshot-knowledge 後存在）
│   ├── raw/{release-notes,docs-conceptual,devblogs,samples,api-surface,facts}/
│   └── brainstorming/qa-sessions/
│
└── mcp-csharp-sdk-guide/                   ← Layer 3（教學產出）
    ├── README.md / PLAN-beginner-tutorial.md
    └── (01-..NN-, appendix-a-..).md
```

**資料流方向**：
- 上游 commit → Layer 1（codebase-memory-mcp 索引，file watcher 自動同步）→ raw/facts/
- raw/ 素材 + raw/facts/ → Layer 2 wiki/concepts/
- Layer 2 → UA → `.understand-anything/`（知識圖譜）
- Layer 1 + Layer 2 → drift-check → Layer 3 修正或新增章節

---

## 4. 四條 Pipeline

### Pipeline A：版本更新
`$sync-upstream` → `$extract-facts <ver>` → `$compile-knowledge` → `$snapshot-knowledge` → `$drift-check` → `$update-tutorial breaking` → `$drift-check` → `$lint-tutorial`

### Pipeline B：互動探索
`$wiki-query`、`$save-qa`；Claude Code 並存期可使用 UA 原生 `/understand-chat` / `/understand-explain` / `/understand-diff`

### Pipeline C：Onboarding
使用 repository 文件與 knowledge graph；UA 完整移植後再由對應 Codex skill 提供 onboarding/dashboard 工作流。

### Pipeline D：教學文件建立
`$draft-chapter`（→ outputs/）→ 人工 review 移入 guide/ → `$regenerate-toc` → `$lint-tutorial`；附錄走 `$draft-appendix`

---

## 5. 與 agent-framework-tutorial 的差異

| 面向 | agent-framework | 本專案 |
|------|----------------|--------|
| 索引對象 | `agent-framework/`（單一大 repo） | `csharp-sdk/`（多套件 src/） |
| project 名 | `agent-framework` | 由 `list_projects` 依 `/csharp-sdk` 路徑動態解析 |
| 外部依賴邊界 | Microsoft.Extensions.AI | 同（Microsoft.Extensions.AI） |
| frontmatter 額外欄位 | — | 新增 `package`（標 NuGet 套件） |
| 教學本體目錄 | `microsoft-agent-framework-tutorial/` | `mcp-csharp-sdk-guide/` |
| WORKFLOW 版本 | v2（曾有 v1 退役） | v1（直接採 v2 成熟設計） |

---

## 6. 後續維護路線

1. SDK 發布新版本時依 `PLAYBOOK-version-update.md` 執行 Pipeline A。
2. 結構性變更先更新 verified facts，再更新 wiki 與 guide。
3. 新章節或附錄仍先輸出至 `outputs/`，人工 review 後才移入 guide。
4. 每次正式發布前執行 deterministic lint；相關章節變更時再執行 standard/release profile。
5. 附錄 D（Samples 導覽）與 E（資源連結）列入第二輪，不阻塞目前發佈。
