---
title: ASP.NET Core 託管
api_name: MapMcp
namespace: Microsoft.AspNetCore.Builder
package: ModelContextProtocol.AspNetCore
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [hosting, aspnetcore, http, deployment]
tutorial_chapters: [ch12]
sources:
  - raw/docs-conceptual/transports.md
  - raw/docs-conceptual/stateless.md
  - raw/api-surface/ModelContextProtocol.AspNetCore.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/samples/README.md
  - csharp-sdk/src/ModelContextProtocol.AspNetCore/McpEndpointRouteBuilderExtensions.cs
---

## 概述

以 ASP.NET Core 託管 MCP server 的標準三步：`AddMcpServer()`（DI 註冊）→ `WithHttpTransport()`（啟用 HTTP 傳輸）→ `MapMcp()`（掛端點）。可與 ASP.NET Core 既有的中介軟體（驗證、CORS、log）共存，便於部署到雲端與容器。官方 `AspNetCoreMcpServer` 與 `AspNetCoreMcpPerSessionTools` sample 示範基本與進階（per-session 工具）用法。

> `MapMcp` namespace `Microsoft.AspNetCore.Builder`（套件 .AspNetCore，in_degree 78）；`AddMcpServer` namespace `Microsoft.Extensions.DependencyInjection`（套件 ModelContextProtocol，in_degree 153）；`WithHttpTransport` namespace `Microsoft.Extensions.DependencyInjection`（套件 .AspNetCore）。

## 目前 API 簽名

```csharp
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Builder;

var builder = WebApplication.CreateBuilder(args);
builder.Services
    .AddMcpServer()
    .WithHttpTransport(o => o.Stateless = true)   // 建議無狀態
    .WithToolsFromAssembly();

var app = builder.Build();
// app.UseAuthentication(); app.UseCors(); ...
app.MapMcp();      // 掛 MCP 端點到根路由
app.Run();
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版 |
| 1.2.0 | 2026-03-27 | `MapMcp()` 預設不再 map legacy SSE；偏好 stateless |
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 12 章：以 ASP.NET Core 託管 HTTP MCP server

## 相關概念
- [[streamable-http-transport]]
- [[sessions]]
- [[transport-security]]
- [[mcp-server-builder]]
- [[docker-deployment]]
