---
title: MCP Client 資源（Client Resources）
api_name: McpClientResource
namespace: ModelContextProtocol.Client
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [client, resources, primitive]
tutorial_chapters: [ch10]
sources:
  - raw/docs-conceptual/resources.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - csharp-sdk/src/ModelContextProtocol.Core/Client/McpClientResource.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Client/McpClient.Methods.cs
---

## 概述

Client 端以 `client.ListResourcesAsync()` 取得資源清單（每項為 `McpClientResource`）、`client.ReadResourceAsync(uri)` 讀取內容、`client.ListResourceTemplatesAsync()` 取得 URI 範本（對應 `McpClientResourceTemplate`）。這些方法皆為 `McpClient` 的實例方法。

> `McpClientResource` / `McpClientResourceTemplate` namespace `ModelContextProtocol.Client`、套件 .Core。讀回的內容型別為 `ResourceContents`（`TextResourceContents` / `BlobResourceContents`，namespace `ModelContextProtocol.Protocol`）。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;

var client = await McpClient.CreateAsync(transport);

// 列出資源
foreach (McpClientResource res in await client.ListResourcesAsync())
    Console.WriteLine($"{res.Uri} — {res.Name}");

// 讀取單一資源
var read = await client.ReadResourceAsync("config://app/theme");
foreach (ResourceContents content in read.Contents)
{
    if (content is TextResourceContents text)
        Console.WriteLine(text.Text);
}

// 列出 resource templates
var templates = await client.ListResourceTemplatesAsync();
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版 |
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 10 章：列出與讀取資源、resource templates

## 相關概念
- [[mcp-client]]
- [[mcp-server-resources]]
