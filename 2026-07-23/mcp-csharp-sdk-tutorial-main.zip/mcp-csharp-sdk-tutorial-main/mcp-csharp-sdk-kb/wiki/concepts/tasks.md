---
title: Tasks（長時間執行 / 持久任務）
api_name: IMcpTaskStore
namespace: ModelContextProtocol
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 1.4.0
updated: 2026-07-16
tags: [tasks, durable, advanced, server]
tutorial_chapters: [ch17]
sources:
  - raw/docs-conceptual/tasks.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/samples/README.md
  - csharp-sdk/src/ModelContextProtocol.Core/Server/IMcpTaskStore.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/CreateTaskResult.cs
---

## 概述

Tasks 是 2025-11-25 規格的「長時間執行 / 持久任務」機制：工具呼叫可立即回傳一個 task，client 之後再輪詢狀態、取結果或取消，避免長操作阻塞連線。Server 端透過 `IMcpTaskStore`（預設實作 `InMemoryMcpTaskStore`）保存任務狀態；協定型別包含 `McpTask`、`McpTaskMetadata`、`McpTasksCapability`、`CreateTaskResult` 與各 request params。官方 `LongRunningTasks` sample 示範完整流程。

> ⚠️ namespace 修正（原始檔＋編譯實測確認，2026-07-16）：`IMcpTaskStore` / `InMemoryMcpTaskStore`
> 的原始檔在 `Server/` 目錄，但 namespace 是**根 `ModelContextProtocol`**（`using ModelContextProtocol.Server;`
> 會 CS0246）。協定型別（`McpTask`、`CreateTaskResult`、`McpTasksCapability` 等）namespace
> `ModelContextProtocol.Protocol`。皆屬套件 .Core。整區 API 標記 Experimental **MCPEXP001**，
> 使用端 csproj 需 `<NoWarn>$(NoWarn);MCPEXP001</NoWarn>`（否則編譯錯誤）。

## 目前 API 簽名

```csharp
using Microsoft.Extensions.DependencyInjection;
using ModelContextProtocol.Server;     // IMcpTaskStore / InMemoryMcpTaskStore

// 註冊 task store（啟用 server 的 tasks capability）
builder.Services.AddSingleton<IMcpTaskStore, InMemoryMcpTaskStore>();
builder.Services.AddMcpServer()
    .WithHttpTransport()
    .WithToolsFromAssembly();
```

> Client 端可 list / get / cancel tasks（對應 `ListTasksRequestParams` / `GetTaskRequestParams` / `CancelMcpTaskRequestParams`）。確切方法簽名與 `CreateTaskResult` 結構以原始碼為準；端對端用法見 `LongRunningTasks` sample。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（Tasks，2025-11-25 規格）|
| 1.2.0 | 2026-03-27 | 修正 task-augmented 工具的 per-task DI scope 生命週期（#1433）|
| 1.4.0 | 2026-06-04 | 目前基準（`TaskStore` 可由 DI 自動填入）|

## 教學章節對應
- 第 17 章：長時間任務（建立、輪詢、取消、結果）

## 相關概念
- [[mcp-server-tools]]
- [[notifications-progress]]
- [[aspnetcore-hosting]]
