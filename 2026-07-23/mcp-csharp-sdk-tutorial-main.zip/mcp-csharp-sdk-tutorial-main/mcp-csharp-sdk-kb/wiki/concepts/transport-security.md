---
title: 傳輸安全（Host 驗證 / CORS / DNS rebinding）
api_name: HttpServerTransportOptions
namespace: ModelContextProtocol.AspNetCore
package: ModelContextProtocol.AspNetCore
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [security, http, cors, aspnetcore]
tutorial_chapters: [ch12, ch18]
sources:
  - raw/docs-conceptual/transports.md
  - raw/api-surface/ModelContextProtocol.AspNetCore.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/facts/v1.4.0-verified-changes.json
  - raw/release-notes/v1.3.0.md
  - raw/release-notes/v1.4.0.md
  - csharp-sdk/src/ModelContextProtocol.AspNetCore/HttpServerTransportOptions.cs
---

## 概述

HTTP MCP server 暴露於網路時需防護：**allowed hosts**（避免 DNS rebinding）、**CORS** 政策、以及 session 綁定使用者驗證。相關設定集中在 `HttpServerTransportOptions`（namespace `ModelContextProtocol.AspNetCore`、套件 .AspNetCore）。v1.3.0 補充了 allowed-hosts 與 CORS 指引文件；v1.4.0 強化 session 安全——`DELETE` 一個 Streamable HTTP session 現在要求與發起 session 相同的已驗證使用者（`HasSameUserId`），否則回 `403 Forbidden`（防止洩漏的 session ID 被用來 DoS 原擁有者）。

## 目前 API 簽名

```csharp
builder.Services.AddMcpServer()
    .WithHttpTransport(o =>
    {
        o.Stateless = true;
        // allowed hosts / CORS：依官方 transports 文件設定（防 DNS rebinding）
    });

// CORS 由 ASP.NET Core 標準管線設定
app.UseCors(/* 限定允許來源 */);
app.MapMcp();
```

v1.4.0 安全強化（驗證自 `StreamableHttpHandler.HandleDeleteRequestAsync`）：
- GET / POST / **DELETE** 三者皆執行 `session.HasSameUserId(context.User)` 檢查
- 不符 → `403 Forbidden`（不再終止 session）

> 確切屬性名稱與允許主機設定方式以 `HttpServerTransportOptions.cs` 與官方 `transports` 文件為準。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版 |
| 1.3.0 | 2026-05-08 | allowed hosts / CORS 指引文件（#1554）|
| 1.4.0 | 2026-06-04 | session DELETE 使用者驗證（#1604）；stdio 不再記錄 env vars（#1538）|

## 教學章節對應
- 第 12 章：HTTP 部署的安全設定
- 第 18 章：保護 server（與授權合併）

## 相關概念
- [[authorization]]
- [[sessions]]
- [[streamable-http-transport]]
- [[aspnetcore-hosting]]
