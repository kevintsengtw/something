---
title: 建立 MCP Client
api_name: McpClient
namespace: ModelContextProtocol.Client
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [client, transport, primitive]
tutorial_chapters: [ch10]
sources:
  - raw/docs-conceptual/getting-started.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - csharp-sdk/src/ModelContextProtocol.Core/Client/McpClient.Methods.cs
---

## 概述

MCP Client 可連接「任何」相容的 MCP server，不限於本 SDK 建立的伺服器（協定 server-agnostic）。以 `McpClient.CreateAsync(transport)` 建立並連線，之後用 `ListToolsAsync` / `CallToolAsync` / `ListResourcesAsync` 等操作伺服器。傳輸層以 `StdioClientTransport`（啟動子行程）或 HTTP client transport 提供。`McpClient` 為 `abstract partial class : McpSession`，namespace `ModelContextProtocol.Client`，屬 `ModelContextProtocol.Core` 套件。

> 入口確認：repo 已**無** `McpClientFactory`；建立入口為 `McpClient.CreateAsync`（取代舊版 `McpClientFactory.CreateAsync`）。較舊範例使用 `McpClientFactory` 是 `/drift-check` 要抓的典型 Breaking。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;

var clientTransport = new StdioClientTransport(new StdioClientTransportOptions
{
    Name = "Everything",
    Command = "npx",
    Arguments = ["-y", "@modelcontextprotocol/server-everything"],
});

var client = await McpClient.CreateAsync(clientTransport);

foreach (var tool in await client.ListToolsAsync())
    Console.WriteLine($"{tool.Name} ({tool.Description})");

var result = await client.CallToolAsync(
    "echo",
    new Dictionary<string, object?> { ["message"] = "Hello MCP!" },
    cancellationToken: CancellationToken.None);
```

驗證簽名（codebase-memory-mcp，in_degree 99）：
```csharp
public static Task<McpClient> CreateAsync(
    IClientTransport clientTransport,
    McpClientOptions? clientOptions = null,
    ILoggerFactory? loggerFactory = null,
    CancellationToken cancellationToken = default)
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（建立入口為 `McpClient.CreateAsync`）|
| 1.1.0 | 2026-03-06 | client completion details（連線結束原因）|
| 1.3.0 | 2026-05-08 | SSE/HTTP 連線失敗改以 `ClientTransportClosedException`（derives `IOException`）回報 |
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 10 章：建立 MCP Client、列出與呼叫工具、讀取資源

## 相關概念
- [[mcp-client-tools]]
- [[mcp-client-resources]]
- [[stdio-transport]]
- [[mef-ai-integration]]
