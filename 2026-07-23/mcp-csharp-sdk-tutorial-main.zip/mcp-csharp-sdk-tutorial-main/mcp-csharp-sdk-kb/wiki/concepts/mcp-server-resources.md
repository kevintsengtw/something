---
title: MCP Server 資源（Resources）
api_name: McpServerResource
namespace: ModelContextProtocol.Server
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 1.4.0
updated: 2026-07-15
tags: [server, resources, attribute, primitive, uri-template, subscription, notification]
tutorial_chapters: [ch07, ch11]
sources:
  - raw/docs-conceptual/resources.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - csharp-sdk/src/ModelContextProtocol.Core/Server/McpServerResource.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Server/McpServerResourceAttribute.cs
  - csharp-sdk/src/ModelContextProtocol/McpServerBuilderExtensions.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/ResourceContents.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/ResourceTemplate.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/ReadResourceResult.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/SubscribeRequestParams.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/ResourceUpdatedNotificationParams.cs
  - csharp-sdk/samples/EverythingServer/Resources/SimpleResourceType.cs
---

## 概述

Resources 是 MCP 的「唯讀資料」primitive，以 URI 定址供客戶端讀取（檔案、資料庫記錄、API 回應等）。定義方式：類別標 `[McpServerResourceType]`、方法標 `[McpServerResource]`，以 `WithResourcesFromAssembly()` / `WithResources<T>()` 註冊。資源內容以 `ResourceContents` 為抽象基底，具體型別為 `TextResourceContents`（文字）與 `BlobResourceContents`（二進位 base64）。資源亦支援 resource templates（URI 範本帶參數），並可讓 client 訂閱、由 server 在內容變更時送通知。

> `McpServerResource`（`abstract class : IMcpServerPrimitive`）、`McpServerResourceAttribute`、`McpServerResourceTypeAttribute` 屬 namespace `ModelContextProtocol.Server`、套件 .Core；`ResourceContents` / `TextResourceContents` / `BlobResourceContents` / `ResourceTemplate` / `ReadResourceResult` / `SubscribeRequestParams` / `ResourceUpdatedNotificationParams` 屬 namespace **`ModelContextProtocol.Protocol`**、套件 .Core。`WithResources` / `WithResourcesFromAssembly` 為 builder 擴充方法，namespace `Microsoft.Extensions.DependencyInjection`、屬 **ModelContextProtocol** 套件。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Server;
using ModelContextProtocol.Protocol;     // ResourceContents / TextResourceContents
using System.ComponentModel;

[McpServerResourceType]
public static class MyResources
{
    [McpServerResource(UriTemplate = "config://app/{key}"), Description("讀取應用設定")]
    public static TextResourceContents GetConfig(string key)
        => new() { Uri = $"config://app/{key}", MimeType = "text/plain", Text = Lookup(key) };
}

builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithResourcesFromAssembly();
```

型別階層（驗證自原始碼）：
- `public abstract class ResourceContents`
- `public sealed class TextResourceContents : ResourceContents`
- `public sealed class BlobResourceContents : ResourceContents`

---

## Resources 進階（ch07）

以下面向對應第 07 章，API 已逐筆經 codebase-memory-mcp + `csharp-sdk/src` 驗證（見 `raw/facts/v1.4.0-api-inventory.json`）。

### 1. 直接資源 vs 範本資源

`[McpServerResource]` 的 `UriTemplate` 若不含 `{param}` 即為固定 URI 的**直接資源**；含 `{param}` 則為**範本資源**（對應 protocol 層的 `ResourceTemplate : IBaseMetadata`），參數由 URI 綁定。下例取自 `SimpleResourceType.cs`：

```csharp
// 直接資源：固定 URI、回傳 string（自動包成 TextResourceContents）
[McpServerResource(UriTemplate = "test://direct/text/resource", Name = "Direct Text Resource", MimeType = "text/plain")]
[Description("A direct text resource")]
public static string DirectTextResource() => "This is a direct resource";

// 範本資源：URI 帶 {id}，並注入 RequestContext<ReadResourceRequestParams>
[McpServerResource(UriTemplate = "test://template/resource/{id}", Name = "Template Resource")]
[Description("A template resource with a numeric ID")]
public static ResourceContents TemplateResource(
    RequestContext<ReadResourceRequestParams> requestContext, int id)
{
    // 依 id 回傳 TextResourceContents 或 BlobResourceContents；requestContext.Params.Uri 可取原始 URI
}
```

### 2. 內容型別：文字 / 二進位

| 型別 | 用途 | 主要欄位 |
|------|------|---------|
| `TextResourceContents` | 文字 | `Uri`、`MimeType`、`Text` |
| `BlobResourceContents` | 二進位（base64） | `Uri`、`MimeType`、`Blob` |

回傳 `string` 時 SDK 自動包成 `TextResourceContents`；要精準控制（含二進位）就直接回傳 `ResourceContents` 子型別。read-resource 的協定結果封裝為 `ReadResourceResult : Result`（含 `IList<ResourceContents> Contents`）。

### 3. 註冊

| 擴充方法 | 用途 |
|---------|------|
| `WithResourcesFromAssembly()` | 掃描組件註冊所有 `[McpServerResourceType]`（in_degree=3） |
| `WithResources<T>()` / `WithResources(IEnumerable<Type>)` / `WithResources(IEnumerable<McpServerResource>)` | 指定類別/型別/實例（in_degree=8） |

### 4. 訂閱與變更通知

Resources 支援 client 對特定 URI 訂閱，server 於內容變更時主動送通知：

- **訂閱/取消**：client 送 `SubscribeRequestParams` / `UnsubscribeRequestParams`（`sealed class : RequestParams`）；server 需宣告 subscribe capability，handler 在 `McpServerHandlers`。
- **內容變更通知**：`NotificationMethods.ResourceUpdatedNotification`（`"notifications/resources/updated"`），參數 `ResourceUpdatedNotificationParams : NotificationParams`。
- **清單變更通知**：`NotificationMethods.ResourceListChangedNotification`（`"notifications/resources/list_changed"`）。

```csharp
using ModelContextProtocol;            // SendNotificationAsync
using ModelContextProtocol.Protocol;   // NotificationMethods / ResourceUpdatedNotificationParams

await server.SendNotificationAsync(
    NotificationMethods.ResourceUpdatedNotification,
    new ResourceUpdatedNotificationParams { Uri = "config://app/theme" });
```

> ⚠️ 主動通知需 **stateful 模式或 stdio**（見 [[sessions]]、[[notifications-progress]]）。`NotificationMethods` 常數集中於 [[notifications-progress]]。

### 5. 參數注入

與 tools/prompts 對稱：resource 方法可注入 `McpServer`、`RequestContext<ReadResourceRequestParams>`、`CancellationToken` 與 DI 服務，這些不進 URI 綁定的參數（見 [[mcp-server-tools]] 注入判定）。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（attribute 式 resources + resource templates + 訂閱/通知）|
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 07 章：定義 Resources（直接/範本）、URI 範本、文字／二進位內容（`TextResourceContents` / `BlobResourceContents`）、註冊（`WithResourcesFromAssembly` / `WithResources`）、訂閱與變更通知（`Subscribe*`/`ResourceUpdatedNotificationParams`/`NotificationMethods`）、參數注入
- 第 11 章：實作範例——直接資源 + 範本資源與 tools 同台組裝（tool 做動作、resource 給資料的分工實戰）。注意 `WithResources<T>()` 的 `T` 不可為 static class（C# CS0718，ch11 編譯實證）；方法本身可為 static

## 相關概念
- [[mcp-server-tools]]
- [[mcp-server-prompts]]
- [[mcp-client-resources]]
- [[notifications-progress]]
- [[sessions]]
