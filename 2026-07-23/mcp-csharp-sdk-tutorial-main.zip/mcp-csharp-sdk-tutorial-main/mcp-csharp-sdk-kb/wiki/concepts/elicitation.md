---
title: Elicitation（伺服器向使用者徵詢輸入）
api_name: ElicitationCapability
namespace: ModelContextProtocol.Protocol
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 1.4.0
updated: 2026-07-16
tags: [elicitation, capability, advanced]
tutorial_chapters: [ch15]
sources:
  - raw/docs-conceptual/elicitation.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/ElicitationCapability.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Server/McpServer.Methods.cs
---

## 概述

Elicitation 讓 **server 在工具執行中向使用者徵詢額外輸入**（例如缺少參數、需要確認）。Server 端在工具內呼叫 `server.ElicitAsync(...)`，client 端宣告 elicitation capability 並提供 handler 顯示表單／收集回應。這是 2025-11-25 規格的互動式 primitive。

> `ElicitationCapability` namespace `ModelContextProtocol.Protocol`、套件 .Core；`ElicitAsync` 為 `McpServer` 的實例方法（namespace `ModelContextProtocol.Server`、套件 .Core）。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Server;

[McpServerTool]
public static async Task<string> Book(McpServer server, CancellationToken ct)
{
    // 工具執行中向使用者徵詢輸入
    var result = await server.ElicitAsync(/* elicitation request */, ct);
    // 依使用者回應繼續...
    return "done";
}
```

```csharp
// Client 端：handler 掛在 Handlers（capability 由 SDK 自動宣告）
var client = await McpClient.CreateAsync(transport, new McpClientOptions
{
    Handlers = new McpClientHandlers
    {
        ElicitationHandler = (request, ct) =>
            ValueTask.FromResult(new ElicitResult { Action = "accept", /* Content = ... */ }),
    },
});
```

> v1.4.0 實況（原始檔確認，2026-07-16）：handler 型別
> `Func<ElicitRequestParams?, CancellationToken, ValueTask<ElicitResult>>`
>（`Client/McpClientHandlers.cs`）；capability 由 `McpClientImpl` 自動宣告（未細指時預設 form 模式）。
> server 端兩多載：`ElicitAsync(ElicitRequestParams, CancellationToken)` 與型別化
> `ElicitAsync<T>(string message, RequestOptions?, CancellationToken)`（由 T 公開屬性生成受限
> JSON Schema——僅 string/number/boolean/string-enum，回應自動反序列化為 T）。
> `ElicitResult.Action`：accept/decline/cancel（預設 cancel）。Mode 另有 "url"（帶外互動）。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（elicitation capability，2025-11-25 規格）|
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 15 章：Elicitation——工具執行中徵詢使用者

## 相關概念
- [[sampling]]
- [[mcp-server-tools]]
- [[notifications-progress]]
