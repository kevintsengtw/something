---
title: 授權（OAuth 2.1 / OIDC / ID-JAG）
api_name: IdentityAssertionGrantProvider
namespace: ModelContextProtocol.Authentication
package: ModelContextProtocol.Core
since: 1.4.0
current_version: 1.4.0
updated: 2026-06-30
tags: [authorization, oauth, security, authentication]
tutorial_chapters: [ch18]
sources:
  - raw/docs-conceptual/transports.md
  - raw/docs-conceptual/identity.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/api-surface/ModelContextProtocol.AspNetCore.md
  - raw/facts/v1.4.0-verified-changes.json
  - raw/facts/v1.4.0-api-inventory.json
  - raw/release-notes/v1.4.0.md
  - csharp-sdk/src/ModelContextProtocol.Core/Authentication/IdentityAssertionGrantProvider.cs
---

## 概述

MCP 的 HTTP 傳輸支援以 OAuth 2.1 / OIDC 保護 server。**Server 端**（`.AspNetCore`）以 `McpAuthenticationHandler` / `McpAuthenticationOptions`（namespace `ModelContextProtocol.AspNetCore.Authentication`）與 DI 擴充 `McpAuthenticationExtensions` 接入 ASP.NET Core 驗證管線。**Client 端**（`.Core`）以 `ClientOAuthProvider` / `ClientOAuthOptions`（namespace `ModelContextProtocol.Authentication`）執行 OAuth flow。

v1.4.0 新增 **Identity Assertion Authorization Grant（ID-JAG，SEP-990）**：`IdentityAssertionGrantProvider` 實作企業 SSO 情境——使用者在企業 IdP 驗證一次，即可存取多個 MCP server 而無須逐一授權。流程為 RFC 8693 token exchange（ID Token → JAG）接 RFC 7523 JWT bearer grant（JAG → access token）。

> 沒有獨立的 Authentication 套件：client/共用 auth 型別在 **.Core**（`ModelContextProtocol.Authentication`），server handler 在 **.AspNetCore**（`ModelContextProtocol.AspNetCore.Authentication`）。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Authentication;   // .Core

// v1.4.0：ID-JAG 企業授權（驗證簽名）
var provider = new IdentityAssertionGrantProvider(
    new IdentityAssertionGrantProviderOptions
    {
        ClientId = "mcp-client-id",
        IdpClientId = "enterprise-idp-client-id",
        IdpUrl = "https://idp.example.com",
        IdTokenCallback = async (ctx, ct) => await GetEnterpriseIdTokenAsync(ctx, ct),
    },
    httpClient);

TokenContainer tokens = await provider.GetAccessTokenAsync(
    resourceUrl: new Uri("https://mcp.example.com/"),
    authorizationServerUrl: new Uri("https://auth.example.com/"));
```

驗證簽名（codebase-memory-mcp）：
```csharp
public IdentityAssertionGrantProvider(
    IdentityAssertionGrantProviderOptions options,
    HttpClient httpClient,
    ILoggerFactory? loggerFactory = null);
public Task<TokenContainer> GetAccessTokenAsync(Uri resourceUrl, Uri authorizationServerUrl, CancellationToken cancellationToken = default);
public void InvalidateCache();
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（OAuth 2.1，含 2025-03-26 向後相容）|
| 1.3.0 | 2026-05-08 | role/identity 傳遞文件 |
| 1.4.0 | 2026-06-04 | 新增 `IdentityAssertionGrantProvider`（ID-JAG / SEP-990，#1305）|

## 教學章節對應
- 第 18 章：保護 MCP server（OAuth 2.1、ID-JAG 企業 SSO）

## 相關概念
- [[transport-security]]
- [[aspnetcore-hosting]]
- [[nuget-packages]]
