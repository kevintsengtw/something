---
title: 什麼是 MCP（Model Context Protocol）
api_name: N/A (協定概念)
namespace: N/A
package: N/A
since: N/A
current_version: 1.4.0
updated: 2026-06-30
tags: [protocol-concept, overview, mcp]
tutorial_chapters: [ch01, ch02]
sources:
  - raw/docs-conceptual/index.md
  - raw/docs-conceptual/getting-started.md
  - raw/release-notes/v1.0.0.md
  - raw/release-notes/v1.4.0.md
---

## 協定概念

MCP（Model Context Protocol）是一個開放協定，標準化應用程式如何向大型語言模型（LLM）提供 context。它讓 LLM 與各種資料源、工具之間能安全整合，解決傳統 M×N 整合爆炸問題（M 個應用 × N 個工具）。MCP 以 JSON-RPC 2.0 為基礎，透過 stdio 或 Streamable HTTP 傳輸；伺服器向客戶端宣告三種第一級 primitive：**Tools**（可執行動作）、**Resources**（唯讀資料）、**Prompts**（可重用範本）。MCP C# SDK 是官方 .NET 實作，與 Microsoft 合作維護，讓 .NET 應用能扮演 MCP server 或 client。

本知識庫基準對齊 SDK **v1.4.0**（NuGet `ModelContextProtocol` 最新穩定版），實作 MCP 規格 **2025-11-25**（含 Tasks、Elicitation、Sampling 等）。

## 目前 API 簽名

N/A — 本條目描述協定概念，非特定 C# API。SDK 入口 API 見 [[mcp-server-builder]] 與 [[mcp-client]]。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 首個穩定版（first stable release）|
| 1.1.0 | 2026-03-06 | client completion details、`AllowedValuesAttribute` 自動補全 |
| 1.2.0 | 2026-03-27 | 預設停用 legacy SSE、預設偏好 stateless |
| 1.3.0 | 2026-05-08 | `ClientTransportClosedException` 公開、傳輸診斷強化 |
| 1.4.0 | 2026-06-04 | ID-JAG 企業授權（`IdentityAssertionGrantProvider`）、`InheritEnvironmentVariables`、安全強化 |

## 教學章節對應
- 第 01 章：MCP 是什麼、為何存在、解決的 M×N 整合問題、與 SDK 三套件關係
- 第 02 章：選擇套件與安裝

## 相關概念
- [[nuget-packages]]
- [[mcp-server-builder]]
- [[mcp-client]]
