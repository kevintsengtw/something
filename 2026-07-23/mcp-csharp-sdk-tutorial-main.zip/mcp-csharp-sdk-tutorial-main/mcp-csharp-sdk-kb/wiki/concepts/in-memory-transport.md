---
title: In-Memory 傳輸層（測試）
api_name: StreamServerTransport
namespace: ModelContextProtocol.Server
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [transport, testing, in-memory]
tutorial_chapters: [ch13]
sources:
  - raw/docs-conceptual/transports.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/samples/README.md
  - csharp-sdk/src/ModelContextProtocol.Core/Server/StreamServerTransport.cs
---

## 概述

測試情境常以記憶體內的 stream 配對連接 client 與 server，不啟動子行程或開 HTTP port。Server 端用 `StreamServerTransport`（`class : TransportBase`），client 端用 `StreamClientTransport`，兩端各接一條 stream（例如以 pipe 或 `Stream` 對接）。官方 `InMemoryTransport` sample 示範此模式。

> `StreamServerTransport` namespace `ModelContextProtocol.Server`、套件 .Core；`StreamClientTransport` namespace **`ModelContextProtocol.Protocol`**（檔案位於 `Client/`，但 namespace 為 Protocol）、套件 .Core。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Server;     // StreamServerTransport
using ModelContextProtocol.Protocol;   // StreamClientTransport

// 以對接的 stream 建立兩端 transport（測試）
var serverTransport = new StreamServerTransport(serverInput, serverOutput);
var clientTransport = new StreamClientTransport(clientInput, clientOutput);

var client = await McpClient.CreateAsync(clientTransport);
// server 端用 McpServer.Create(serverTransport, options) 並啟動
```

> 確切建構子參數請以官方 `InMemoryTransport` sample 為準（`raw/samples/README.md`）。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版 |
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 13 章：測試策略（in-memory transport 不開行程做端對端測試）

## 相關概念
- [[testing-strategy]]
- [[stdio-transport]]
- [[mcp-client]]
