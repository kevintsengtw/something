---
title: Native AOT 相容性
api_name: N/A (AOT / source generation)
namespace: N/A
package: N/A
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [aot, devops, performance]
tutorial_chapters: [ch20]
sources:
  - raw/docs-conceptual/getting-started.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
---

## 概述

MCP C# SDK 以 Native AOT / trimming 相容為設計目標：JSON 序列化採用 source-generated `JsonSerializerContext`（避免反射），並隨附 `ModelContextProtocol.Analyzers` 套件在編譯期協助。要產出 AOT 應用，需在 .csproj 啟用 `PublishAot`，並為自訂型別提供 source-generated JSON context；attribute 式 primitive（tools/prompts/resources）的探索亦需注意 trimming 對反射的影響。

## 關鍵設定

```xml
<!-- .csproj -->
<PropertyGroup>
  <PublishAot>true</PublishAot>
  <InvariantGlobalization>true</InvariantGlobalization>
</PropertyGroup>
```

```bash
dotnet publish -c Release -r osx-arm64   # 產出 Native AOT 單一執行檔
```

> 確切 AOT 注意事項（哪些 API 需 source-gen JSON context、trimming warnings 抑制）以上游 `docs/` 與各套件 PACKAGE.md 為準；本條目為架構指引，無單一對應 C# API。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（source-gen JSON、analyzers 套件）|
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 20 章：Native AOT 發佈與注意事項

## 相關概念
- [[nuget-packages]]
- [[mcp-server-tools]]
- [[docker-deployment]]
