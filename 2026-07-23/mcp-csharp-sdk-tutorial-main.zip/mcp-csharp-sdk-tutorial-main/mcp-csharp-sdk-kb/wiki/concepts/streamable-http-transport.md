---
title: Streamable HTTP 傳輸層
api_name: MapMcp
namespace: Microsoft.AspNetCore.Builder
package: ModelContextProtocol.AspNetCore
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [transport, http, sse, aspnetcore]
tutorial_chapters: [ch08, ch12]
sources:
  - raw/docs-conceptual/transports.md
  - raw/docs-conceptual/stateless.md
  - raw/api-surface/ModelContextProtocol.AspNetCore.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/release-notes/v1.2.0.md
  - csharp-sdk/src/ModelContextProtocol.AspNetCore/McpEndpointRouteBuilderExtensions.cs
---

## 概述

Streamable HTTP 是遠端／網路情境的傳輸層，由 `ModelContextProtocol.AspNetCore` 套件提供。Server 端以 `AddMcpServer().WithHttpTransport()` 設定，再用 `MapMcp()` 將 MCP 端點掛到 ASP.NET Core 路由。Client 端使用 HTTP client transport（預設 `HttpTransportMode.AutoDetect`，會先嘗試 Streamable HTTP）。**自 v1.2.0 起，legacy SSE（`/sse`、`/message`）預設停用**，須以 `HttpServerTransportOptions.EnableLegacySse = true`（會觸發 `MCP9004` 警告）才會繼續服務。

> `MapMcp` namespace **`Microsoft.AspNetCore.Builder`**、套件 .AspNetCore（in_degree 78）；`WithHttpTransport` namespace `Microsoft.Extensions.DependencyInjection`、套件 .AspNetCore。

## 目前 API 簽名

```csharp
using Microsoft.Extensions.DependencyInjection;  // AddMcpServer / WithHttpTransport
using Microsoft.AspNetCore.Builder;              // MapMcp

var builder = WebApplication.CreateBuilder(args);
builder.Services
    .AddMcpServer()
    .WithHttpTransport()
    .WithToolsFromAssembly();

var app = builder.Build();
app.MapMcp();          // 預設掛在根端點（不再自動 map /sse、/message）
app.Run();
```

```csharp
// 過渡期：同時服務 Streamable HTTP 與 legacy SSE
builder.Services.AddMcpServer()
    .WithHttpTransport(o => o.EnableLegacySse = true);  // 觸發 MCP9004，需抑制
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版 |
| 1.1.0 | 2026-03-06 | transports 文件補 SSE server 範例 |
| 1.2.0 | 2026-03-27 | **Breaking 行為**：`MapMcp()` 預設不再 map `/sse`、`/message`；新增 `EnableLegacySse`（`[Obsolete]` MCP9004）|
| 1.3.0 | 2026-05-08 | 修正 stateless 傳輸誤報 listChanged capability（#1509）|
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 08 章：傳輸層選擇
- 第 12 章：ASP.NET Core HTTP server 與部署

## 相關概念
- [[aspnetcore-hosting]]
- [[sessions]]
- [[stdio-transport]]
- [[transport-security]]
