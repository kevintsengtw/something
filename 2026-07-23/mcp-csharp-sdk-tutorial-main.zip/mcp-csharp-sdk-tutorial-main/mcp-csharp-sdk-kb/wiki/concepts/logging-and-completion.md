---
title: 日誌與補全（Logging & Completion）
api_name: LoggingCapability
namespace: ModelContextProtocol.Protocol
package: ModelContextProtocol.Core
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [logging, completion, capability]
tutorial_chapters: [ch09]
sources:
  - raw/docs-conceptual/logging.md
  - raw/docs-conceptual/completions.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/LoggingCapability.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Protocol/CompletionsCapability.cs
---

## 概述

**Logging**：server 可透過 logging capability 向 client 送結構化日誌訊息（含 level），client 可設定最低 level。**Completion**：server 可為 prompt / resource template 的參數提供候選值補全（completions capability）。SDK 會**自動**為以 `AllowedValuesAttribute` 標記的字串參數產生補全（v1.1.0 起），無需手寫 handler。

> `LoggingCapability` / `CompletionsCapability` namespace `ModelContextProtocol.Protocol`、套件 .Core。`AllowedValuesAttribute` **不是 SDK 型別**——來自 .NET BCL `System.ComponentModel.DataAnnotations`；SDK 僅讀取被它標記的參數（圖譜無此節點，屬正常）。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Server;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;   // AllowedValuesAttribute（.NET BCL）

[McpServerPromptType]
public static class ThemePrompts
{
    [McpServerPrompt, Description("套用指定主題")]
    public static string ApplyTheme(
        [Description("主題名稱")]
        [AllowedValues("light", "dark", "system")] string theme)   // 自動產生 completion
        => $"theme={theme}";
}
```

> Logging：server 端注入的 `ILogger` 訊息可經 logging capability 轉送 client；level 過濾由 client 設定。確切 capability 屬性以 `LoggingCapability.cs` / `CompletionsCapability.cs` 為準。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（logging / completion capability）|
| 1.1.0 | 2026-03-06 | 自 `AllowedValuesAttribute` 自動補全 prompt/resource 參數（#1380）|
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 09 章：日誌轉送與參數補全

## 相關概念
- [[mcp-server-prompts]]
- [[mcp-server-resources]]
- [[notifications-progress]]
