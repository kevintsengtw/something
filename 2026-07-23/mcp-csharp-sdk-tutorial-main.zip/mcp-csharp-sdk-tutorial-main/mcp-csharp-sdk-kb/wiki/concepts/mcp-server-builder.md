---
title: 建立 MCP Server（Server Builder）
api_name: AddMcpServer
namespace: Microsoft.Extensions.DependencyInjection
package: ModelContextProtocol
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [server, hosting, builder, di]
tutorial_chapters: [ch03, ch04]
sources:
  - raw/docs-conceptual/getting-started.md
  - raw/api-surface/ModelContextProtocol.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - csharp-sdk/src/ModelContextProtocol/McpServerServiceCollectionExtensions.cs
  - csharp-sdk/src/ModelContextProtocol.Core/Server/McpServer.Methods.cs
---

## 概述

`AddMcpServer()` 是建立 MCP 伺服器的起點，向 `IServiceCollection` 註冊服務並回傳 `IMcpServerBuilder` 供鏈式設定傳輸層（`WithStdioServerTransport` / `WithHttpTransport`）與 primitive 來源（`WithToolsFromAssembly` / `WithTools<T>` 等）。低階情境可改用 `McpServer.Create(...)` 直接建立，自行提供 `McpServerOptions`（`ServerInfo`、`Capabilities` 與各 handler）。

> 套件／namespace 對照：`AddMcpServer` 與 `IMcpServerBuilder` 屬 **ModelContextProtocol** 套件、namespace **`Microsoft.Extensions.DependencyInjection`**；`McpServer` / `McpServerOptions` 屬 **ModelContextProtocol.Core** 套件、namespace **`ModelContextProtocol.Server`**。

## 目前 API 簽名

```csharp
// 高階（DI / hosting）— stdio server
using Microsoft.Extensions.DependencyInjection;   // AddMcpServer / WithStdioServerTransport / WithToolsFromAssembly
using Microsoft.Extensions.Hosting;

var builder = Host.CreateApplicationBuilder(args);
builder.Logging.AddConsole(o => o.LogToStandardErrorThreshold = LogLevel.Trace); // log 走 stderr
builder.Services
    .AddMcpServer()                 // IServiceCollection -> IMcpServerBuilder
    .WithStdioServerTransport()
    .WithToolsFromAssembly();
await builder.Build().RunAsync();
```

```csharp
// 低階 — 直接建立 McpServer
using ModelContextProtocol.Server;

McpServerOptions options = new()
{
    ServerInfo = new Implementation { Name = "MyServer", Version = "1.0.0" },
    Capabilities = new ServerCapabilities { /* ... */ },
};
await using McpServer server = McpServer.Create(transport, options);
```

驗證簽名（codebase-memory-mcp）：
- `public static IMcpServerBuilder AddMcpServer(this IServiceCollection services, Action<McpServerOptions>? configureOptions = null)`（in_degree 153）
- `public static McpServer Create(...)`（`McpServer` 為 `abstract partial class : McpSession`）

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版；`RunSessionHandler` 標記 `[Experimental("MCPEXP002")]` |
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 03 章：第一個 MCP Server（DI / hosting 架構）
- 第 04 章：加入第一個工具、用 stdio 跑起來

## 相關概念
- [[mcp-server-tools]]
- [[stdio-transport]]
- [[aspnetcore-hosting]]
- [[sessions]]
