---
title: 與 Microsoft.Extensions.AI 整合
api_name: N/A (外部 IChatClient / AIFunction 整合)
namespace: N/A (外部 Microsoft.Extensions.AI)
package: N/A (外部 NuGet)
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [ai-integration, protocol-concept, client]
tutorial_chapters: [ch16]
sources:
  - raw/docs-conceptual/sampling.md
  - raw/docs-conceptual/getting-started.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/samples/README.md
---

## 概述

MCP C# SDK 與 `Microsoft.Extensions.AI`（M.E.AI）深度整合，使 MCP 工具能無縫接入 LLM function calling。關鍵橋接是 `McpClientTool : AIFunction`——`ListToolsAsync` 取回的工具本身就是 `AIFunction`，可直接放進 `ChatOptions.Tools` 餵給 `IChatClient`。反向地，`AIContentExtensions.CreateSamplingHandler(chatClient)` 讓 server 的 sampling 請求由 client 的 `IChatClient` 處理。官方 `ChatWithTools` sample 示範完整 function calling 迴圈。

> ⚠️ **本條目核心型別 `IChatClient`、`AIFunction`、`ChatOptions`、`ChatMessage` 皆來自外部 NuGet `Microsoft.Extensions.AI`，不在 csharp-sdk 圖譜中**（已於 codebase-memory-mcp 驗證確認，屬正常）。SDK 側橋接型別 `McpClientTool`（套件 .Core）才是圖譜可驗證的部分。

## 目前 API 簽名

```csharp
using ModelContextProtocol.Client;
using Microsoft.Extensions.AI;        // IChatClient / ChatOptions（外部 NuGet）

var mcpClient = await McpClient.CreateAsync(transport);
IList<McpClientTool> tools = await mcpClient.ListToolsAsync();  // McpClientTool : AIFunction

IChatClient chatClient = /* OpenAI / Azure / Anthropic 等 M.E.AI client */;

var response = await chatClient.GetResponseAsync(
    "台北今天天氣如何？",
    new ChatOptions { Tools = [.. tools] });   // 直接把 MCP 工具當 AIFunction
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（`McpClientTool : AIFunction` 橋接）|
| 1.4.0 | 2026-06-04 | 目前基準（持續對齊 M.E.AI 版本）|

## 教學章節對應
- 第 16 章：MCP 工具 + `IChatClient` 做 function calling

## 相關概念
- [[mcp-client-tools]]
- [[sampling]]
- [[mcp-client]]
