---
title: Session 設計（Stateless vs Stateful）
api_name: N/A (stateless/stateful 設計)
namespace: ModelContextProtocol.AspNetCore
package: ModelContextProtocol.AspNetCore
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [protocol-concept, sessions, http, aspnetcore]
tutorial_chapters: [ch08, ch12]
sources:
  - raw/docs-conceptual/stateless.md
  - raw/api-surface/ModelContextProtocol.AspNetCore.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/release-notes/v1.2.0.md
---

## 模式對照

HTTP server 可在兩種 session 模式運作，由 `HttpServerTransportOptions.Stateless` 控制：

| 模式 | `Stateless` | 特性 | 適用 |
|------|-------------|------|------|
| **Stateful**（有狀態）| `false`（傳統）| 每連線維持 session、可推送 server-initiated 通知、支援 `listChanged`、resumability | 需要伺服器主動通知、長連線 |
| **Stateless**（無狀態）| `true`（建議預設）| 每請求獨立、易水平擴展、無 server-initiated 通知/SSE GET stream | 雲端、serverless、無狀態水平擴展 |

自 v1.2.0 起官方文件**偏好 stateless** 並預設停用 legacy SSE。相關進階選項：`ConfigureSessionOptions`（取代已標 Experimental 的 `RunSessionHandler`，MCPEXP002）、idle session 修剪（idle timeout / max idle session count）。

> 這些屬性都在 `HttpServerTransportOptions`（namespace `ModelContextProtocol.AspNetCore`、套件 .AspNetCore）。

## 目前 API 簽名

N/A — 本條目為設計概念。關鍵設定型別見 `HttpServerTransportOptions`（[[transport-security]]、[[streamable-http-transport]]）。

```csharp
builder.Services.AddMcpServer()
    .WithHttpTransport(o =>
    {
        o.Stateless = true;            // 建議：無狀態水平擴展
        // o.EnableLegacySse = false;  // 預設停用（MCP9004）
    });
```

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | `RunSessionHandler` 標記 Experimental（MCPEXP002），建議改 `ConfigureSessionOptions` |
| 1.2.0 | 2026-03-27 | 新增 stateless 文件、預設偏好 stateless、預設停用 legacy SSE |
| 1.3.0 | 2026-05-08 | 修正 stateless 誤報 listChanged capability |
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 08 章：session 模式概念
- 第 12 章：HTTP 部署的 stateless/stateful 取捨

## 相關概念
- [[streamable-http-transport]]
- [[aspnetcore-hosting]]
- [[transport-security]]
- [[notifications-progress]]
