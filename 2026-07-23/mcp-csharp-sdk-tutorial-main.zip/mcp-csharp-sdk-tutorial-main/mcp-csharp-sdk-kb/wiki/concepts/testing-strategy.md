---
title: 測試策略
api_name: N/A (測試模式)
namespace: N/A
package: N/A
since: 1.0.0
current_version: 1.4.0
updated: 2026-06-30
tags: [testing-pattern, testing, devops]
tutorial_chapters: [ch13]
sources:
  - raw/docs-conceptual/transports.md
  - raw/api-surface/ModelContextProtocol.Core.md
  - raw/facts/v1.4.0-api-inventory.json
  - raw/samples/README.md
---

## 概述

測試 MCP server/client 的核心技巧是用 **in-memory transport** 將兩端在同一行程內對接，避免啟動子行程或開 HTTP port，使端對端測試快速、可決定性。搭配 `Host.CreateApplicationBuilder` 以 Generic Host 託管 server（`TestServerWithHosting` sample），並用 `McpClient.CreateAsync` 連到記憶體 transport 後斷言 `ListToolsAsync` / `CallToolAsync` 等行為。

## 關鍵技巧

- **in-memory transport**：`StreamServerTransport` ↔ `StreamClientTransport` 對接（見 [[in-memory-transport]]、官方 `InMemoryTransport` sample）
- **Generic Host 託管**：以 DI 容器組裝 server，便於替換假服務（`TestServerWithHosting` sample）
- **端對端斷言**：用真實 `McpClient` 走完整協定握手，驗證 tool schema、回傳與錯誤（`McpException`）
- 上游測試專案（`tests/ModelContextProtocol.Tests`）本身即可作為用法範例

```csharp
// 概念示意：in-memory 端對端
var serverTransport = new StreamServerTransport(/* streams */);
var clientTransport = new StreamClientTransport(/* streams */);
// 啟動 server（McpServer.Create + RunAsync）後：
var client = await McpClient.CreateAsync(clientTransport);
var tools = await client.ListToolsAsync();
Assert.Contains(tools, t => t.Name == "echo");
```

> 本條目為測試模式指引，無單一對應 C# API；確切 stream 對接方式以 `InMemoryTransport` sample 為準。

## 變更歷史

| 版本 | 日期 | 變更內容 |
|------|------|---------|
| 1.0.0 | 2026-02-25 | 穩定版（in-memory transport 可用）|
| 1.3.0 | 2026-05-08 | 新增測試指引文件（#1507）|
| 1.4.0 | 2026-06-04 | 目前基準 |

## 教學章節對應
- 第 13 章：測試 MCP server/client（in-memory transport + hosting）

## 相關概念
- [[in-memory-transport]]
- [[mcp-client]]
- [[mcp-server-builder]]
