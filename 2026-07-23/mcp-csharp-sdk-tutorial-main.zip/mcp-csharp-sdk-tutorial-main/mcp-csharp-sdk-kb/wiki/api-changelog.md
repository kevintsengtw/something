# API 變更時間線（API Changelog）

> 由 `/compile` 維護，以版本為主軸記錄 MCP C# SDK 的 API 層面變更。
> 基準版本 v1.4.0（indexed commit `06e3604`）。結構性事實來源：`raw/release-notes/*.md` + `raw/facts/v1.4.0-verified-changes.json`（皆經 codebase-memory-mcp 驗證）。

| 版本 | 日期 | 類型 | 變更摘要 |
|------|------|------|---------|
| 1.4.0 | 2026-06-04 | ✨ Added + 🔒 Security | ID-JAG 企業授權、`InheritEnvironmentVariables`、session 安全強化 |
| 1.3.0 | 2026-05-08 | ✨ Added | `ClientTransportClosedException` 公開（: IOException）|
| 1.2.0 | 2026-03-27 | 🔴 Breaking（行為）| legacy SSE 預設停用；2-arg `RequestContext` ctor 標 Obsolete |
| 1.1.0 | 2026-03-06 | ✨ Added | `AllowedValuesAttribute` 自動補全、client completion details |
| 1.0.0 | 2026-02-25 | 🎉 Stable | 首個穩定版；`RunSessionHandler` 標 Experimental |

---

## v1.4.0（2026-06-04）

### ✨ Added
- `IdentityAssertionGrantProvider`（ns `ModelContextProtocol.Authentication`，套件 **.Core**，PR #1305 / SEP-990）— ID-JAG 企業 SSO 授權，含 `IdentityAssertionGrantProviderOptions`、`IdentityAssertionGrantContext`、`IdentityAssertionGrantException`、`IdentityAssertionGrantIdTokenCallback`
- `StdioClientTransportOptions.InheritEnvironmentVariables`（`bool`，預設 `true`，ns `ModelContextProtocol.Client`，套件 .Core，PR #1563）

### 🔒 Security
- session `DELETE` 現要求相同已驗證使用者（`HandleDeleteRequestAsync` + `HasSameUserId`，否則 403；PR #1604，套件 .AspNetCore）
- stdio 傳輸不再於 Trace log 列出子行程環境變數（PR #1538，套件 .Core）

> 無 breaking change。詳見 `raw/facts/v1.4.0-verified-changes.json`。

## v1.3.0（2026-05-08）

### ✨ Added
- `ClientTransportClosedException` 公開（derives `IOException`，PR #1467）— stdio/HTTP client 取得結構化的傳輸關閉細節
- 行為調整：SSE/HTTP 連線失敗自 `McpClient.CreateAsync` 改以 `IOException`（而非 `InvalidOperationException`）回報

## v1.2.0（2026-03-27）

### 🔴 Breaking（行為）
- `MapMcp()` 預設不再 map legacy SSE 端點 `/sse`、`/message`；以 `HttpServerTransportOptions.EnableLegacySse=true` 對應（`[Obsolete]` 診斷 **MCP9004**，PR #1468）
- `RequestContext(McpServer, JsonRpcRequest)` 2-arg ctor 標 `[Obsolete]`（診斷 **MCP9003**）；改用 3-arg `RequestContext(server, request, parameters)`（PR #1462）；`Params` 由 `TParams?` 改為 `TParams`

### ✨ Added
- 工具回傳 `CallToolResult` 時可獨立指定 output schema：`McpServerToolAttribute.OutputSchemaType`（`Type?`，ns `ModelContextProtocol.Server`，套件 .Core，PR #1425；git 首見 commit `2958a75`，earliest tag v1.2.0）；SDK 據此填入 protocol 層 `Tool.OutputSchema`

## v1.1.0（2026-03-06）

### ✨ Added
- prompt / resource 參數的 `AllowedValuesAttribute`（.NET BCL）自動產生 completion handler（PR #1380）
- client completion notification / details（PR #1368）

## v1.0.0（2026-02-25）

### 🎉 Stable
- 首個穩定版，完整 2025-11-25 MCP 規格支援

### ⚠️ Experimental
- `HttpServerTransportOptions.RunSessionHandler` 標 `[Experimental("MCPEXP002")]`（PR #1383）；建議改用 `ConfigureSessionOptions`，以 `#pragma warning disable MCPEXP002` 抑制
