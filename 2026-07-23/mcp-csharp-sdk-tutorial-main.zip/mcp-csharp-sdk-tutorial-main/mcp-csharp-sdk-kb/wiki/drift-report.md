---
generated: 2026-07-16
indexed_commit: 2b7fd35fbe58dfb9f00eae8b3393e1a7361b5e01
baseline: wiki/concepts/ (25 條目，v1.4.0 基準) vs guide/ (20 章與附錄 A/B/C)
upstream_tag: v1.4.1
status: current
---

# 偏移報告

> 本報告是 Claude → Codex 移轉切換時的 Level 1 基準快照。內容依據已結案的第二意見審查、處置記錄、文件 lint 與 codebase-memory-mcp 7/7 探測結果；不代表本輪重新執行了完整版本更新 Pipeline。

## 摘要

| 等級 | 數量 | 說明 |
|------|------|------|
| 🔴 Breaking | 0 | 未發現會使目前教學失效的 API 偏移 |
| 🟡 Outdated | 0 | 第二意見發現均已查證並處置 |
| 🟢 Enhancement | 0 | 目前發佈範圍已完成；附錄 D/E 屬另案第二輪 |

## 🔴 Breaking

**無。**

- codebase-memory-mcp 已對 `csharp-sdk/` HEAD `2b7fd35fbe58dfb9f00eae8b3393e1a7361b5e01` 重建索引。
- 外部依賴、方法簽名、繼承鏈、Attribute、Extensions、callers/trace 與 namespace 七項探測均通過。
- 上游 `v1.4.1` 相對教學基準 `v1.4.0` 的變更未造成公開 API surface 偏移。

## 🟡 Outdated

**無。**

- 教學現況為 20 章與附錄 A/B/C，不再是舊報告記載的 4 章。
- `reviews/second-opinion-resolution-2026-07-16.md` 的主要與補充發現均已完成處置並結案。
- `node scripts/lint-docs.mjs` 已驗證章節、附錄、審查文件、知識庫概念、連結、frontmatter、TOC 與 facts 結構。

## 🟢 Enhancement

**目前發佈範圍無待補項目。**

附錄 D（Samples 導覽）與附錄 E（資源連結）已明確列為第二輪工作，不屬於目前版本的 API drift 或發佈阻塞。

## Level 1 限制

Understand-Anything graph 在本次 Codex 移轉採凍結策略：

- 保留 `wiki/.understand-anything/knowledge-graph.json` 與 `meta.json`。
- graph 的 `gitCommitHash` 與本報告 `indexed_commit` 相同。
- Codex 可唯讀檢查既有 graph，但目前不能重新產生 snapshot。
- 下一次 SDK 版本更新 Pipeline 必須停在 snapshot 步驟，直到 `validation/ua-level2-follow-up.md` 完成；不得沿用舊 graph 後宣告 Pipeline 成功。

## 結論

**🔴 = 0，🟡 = 0。** 目前 20 章與附錄 A/B/C 維持具備發佈條件；本報告可作為 Codex Level 1 接手時的 current drift 基準。
