# QuickStart — 快速操作指南

> 詳細說明見工作區根 [`../AGENTS.md`](../AGENTS.md)、[`../CODEX-HANDOFF-PLAN.md`](../CODEX-HANDOFF-PLAN.md) 與 [`./WORKFLOW-DESIGN-v1.md`](./WORKFLOW-DESIGN-v1.md)
> 目標環境：**macOS**
>
> ⚠️ **project 名稱**：codebase-memory-mcp 的 project 名由絕對路徑自動產生、因機而異。下方手動查驗範例的 `project: "<csharp-sdk-project>"` 為 placeholder，以 `list_projects` 取以 `/csharp-sdk` 結尾者代入（見 `AGENTS.md` 與 `UPSTREAM-REF.md`）。

---

## 一、首次安裝（macOS）

```bash
# 1. codebase-memory-mcp
npm install -g codebase-memory-mcp
which codebase-memory-mcp

# 2. clone 上游 SDK（在工作區根內，依 UPSTREAM-REF 對齊）
git clone https://github.com/modelcontextprotocol/csharp-sdk.git
cd csharp-sdk && git checkout v1.4.1 && cd ..
```

```bash
# 3. 啟動 Codex，信任 repository，確認 MCP
codex
codex mcp list

# 4. 首次索引
codebase-memory-mcp cli index_repository \
  '{"repo_path":"<絕對路徑>/csharp-sdk"}'
codebase-memory-mcp cli list_projects '{}'

# 5. 首次驗證（7 項探測，見 validation 記錄）≥ 6/7 通過
```

---

## 二、驗證既有建庫

```text
$lint-tutorial
```

既有 repository 已包含 25 個 concepts 與 knowledge graph，不需重跑首次建庫。

---

## 三、上游發佈新版本時（Pipeline A）

```text
$sync-upstream
$extract-facts <version>
$compile-knowledge
$snapshot-knowledge
$drift-check
$update-tutorial breaking
$drift-check                  ← 驗證 🔴 = 0
$lint-tutorial
```

還有 🟡 Outdated 時：`$update-tutorial outdated` → `$drift-check`

完整版見 [`./PLAYBOOK-version-update.md`](./PLAYBOOK-version-update.md)。

---

## 四、教學文件建立（Pipeline D）

```text
$draft-chapter <wiki-concept> [chapter-no]
# 產出 outputs/draft-<concept>.md → 人工 review → 移至 mcp-csharp-sdk-guide/<NN>-<slug>.md
$regenerate-toc
$lint-tutorial
```

附錄：`$draft-appendix <topic> [letter]`（流程同上）

---

## 五、常用查詢

```text
$wiki-query <關鍵字>
# 範例：
$wiki-query McpServerTool 怎麼註冊
$wiki-query Stdio 與 Streamable HTTP 差異
$wiki-query McpClient 與 McpClientFactory 差別
```

Claude Code 並存期仍可使用 `.claude/commands/`。Codex 的 `$snapshot-knowledge` 已可執行 staging 重建、驗證、Dashboard smoke 與受保護發布；不依賴 Claude runtime。

---

## 六、codebase-memory-mcp 手動查驗

```bash
# project 為 placeholder，先 list_projects 解析實際名稱再代入
codebase-memory-mcp cli list_projects '{}'
codebase-memory-mcp cli search_graph \
  '{"project":"<csharp-sdk-project>","name_pattern":"McpServerTool","limit":20}'
codebase-memory-mcp cli query_graph \
  '{"project":"<csharp-sdk-project>","query":"MATCH (n:Class {name: '\''McpClient'\''}) RETURN n.namespace"}'
codebase-memory-mcp cli search_code \
  '{"project":"<csharp-sdk-project>","pattern":"WithToolsFromAssembly","max_results":20}'
```

---

## 七、偏移等級

| 等級 | 意義 | 處理 |
|------|------|------|
| 🔴 Breaking | 會編譯失敗 | `$update-tutorial breaking` |
| 🟡 Outdated | 過時但可運作 | `$update-tutorial outdated` |
| 🟢 Enhancement | 可選新功能 | 人工決定 |

---

## 八、注意事項
- `csharp-sdk/` 與 `mcp-csharp-sdk-guide/` 必須存在
- codebase-memory-mcp 首次使用需 `index_repository`
- `Microsoft.Extensions.AI.*` 圖譜查無屬正常（外部 NuGet）
- `$draft-*` 產出永遠進 `outputs/`，不直接寫入教學目錄
