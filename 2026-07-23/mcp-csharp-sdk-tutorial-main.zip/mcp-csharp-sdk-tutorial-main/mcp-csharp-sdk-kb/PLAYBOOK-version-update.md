# MCP C# SDK 版本更新 Playbook

> 當 MCP C# SDK 發佈新版本時，依本文步驟執行教學同步更新。對應 [`./WORKFLOW-DESIGN-v1.md`](./WORKFLOW-DESIGN-v1.md) 的 Pipeline A。

## 前置條件
- Codex CLI（主要）或 Claude Code（並存期）
- 工作區根 `mcp-csharp-sdk-tutorial/`（repository skills / commands 入口）
- 三子目錄存在：`csharp-sdk/`、`mcp-csharp-sdk-kb/`、`mcp-csharp-sdk-guide/`
- codebase-memory-mcp 已安裝且通過 macOS 驗證
- Node.js 可執行 repository 內的 deterministic graph builder、validator、publisher 與 tests
- `csharp-sdk/` 已索引（project 名由路徑自動產生、因機而異；以 `list_projects` 取以 `/csharp-sdk` 結尾者，見 `AGENTS.md` 與 `UPSTREAM-REF.md`）

---

## Step 1：同步上游素材
```text
$sync-upstream
```
確認：`raw/release-notes/` 出現新版本檔案、`raw/docs-conceptual/` 更新、samples README 更新、codebase-memory-mcp 索引同步、步驟 8 的新 API 存在性確認清單。預估 3–5 分鐘。

## Step 2：建立事實清單
```text
$extract-facts <new-version>
```
確認：`raw/facts/v<version>-verified-changes.json` 產出、終端顯示「已驗證 X / 未驗證 Y」。**事實層源頭**，後續 `$compile-knowledge` frontmatter 從此取得。預估 5–10 分鐘。

## Step 3：編譯知識庫
```text
$compile-knowledge
```
確認：wiki/concepts/ 條目清單、INDEX.md 同步、api-changelog.md 新增版本段落、所有條目 `current_version` 更新。frontmatter（api_name/namespace/package/since/current_version）來自 raw/facts/。預估 5–10 分鐘。

## Step 4：知識圖譜快照
```text
$snapshot-knowledge
```
確認：先在 repository 外 staging 重建，再以 validator 比對正式 baseline；article/entity/claim、既有語意邊不得遺失，orphan nodes 必須為零。Dashboard smoke 通過且使用者明確核准後，才以 rollback-safe publisher 更新 `.understand-anything/`；失敗時保留最後有效快照。詳細命令與閘門見 `.agents/skills/snapshot-knowledge/SKILL.md`。

## Step 5：偏移檢查
```text
$drift-check
```
確認：`wiki/drift-report.md` 重新產生、三級偏移分類。

| 等級 | 意義 | 行動 |
|------|------|------|
| 🔴 Breaking | 會編譯失敗 | 必須立即修復 |
| 🟡 Outdated | 過時但可運作 | 建議修復 |
| 🟢 Enhancement | 可選補充 | 評估決定 |

## Step 6：規劃修改範圍
優先順序：🔴 → 🟡 → 🟢。檔案多（>5）時分批。

## Step 7：教學修改
```text
$update-tutorial breaking
$update-tutorial outdated
```
替換前 codebase-memory-mcp 確認新名稱存在（**硬性規定**）。預估 10–20 分鐘。

## Step 8：驗證
```text
$drift-check    ← 確認 🔴 = 0
$lint-tutorial  ← wiki + tutorial 一致性
```

## Step 9：更新版本記錄
- `mcp-csharp-sdk-guide/README.md` — 版本資訊
- `mcp-csharp-sdk-guide/appendix-a-nuget-packages.md` — NuGet 版本號
- `mcp-csharp-sdk-kb/UPSTREAM-REF.md` — tag/commit/索引規模
- 本檔歷次執行記錄表

---

## 完整流程圖

```text
上游發佈新版本
  → $sync-upstream            （raw/ 素材 + 索引同步 + search_graph 存在性）
  → $extract-facts <ver>      （事實 JSON：search_graph + get_code_snippet + trace_path inbound）
  → $compile-knowledge        （wiki：snippet + search_code sources + 廢棄確認）
  → $snapshot-knowledge       （staging 重建 + schema/diff/Dashboard 驗證 + 安全發布）
  → $drift-check              （query_graph 存在性 + search_code usage）
  → 閱讀 drift-report
  → $update-tutorial          （search_graph 替換方向確認）
  → $drift-check              （🔴 = 0）
  → $lint-tutorial
  → 更新版本記錄
  → 完成 ✅
```

## 預估總時間
約 1–2 小時（Step 1–5 自動化 25–40 分、Step 6 規劃 5–10 分、Step 7 修改 30–60 分、Step 8–9 驗證 10–15 分）。

---

## 歷次執行記錄

| 版本 | 執行日期 | drift 結果 | 修改檔案數 | 備註 |
|------|----------|-----------|-----------|------|
| v1.4.0 | 2026-06-30 | —（guide 尚無章節，drift-check 未適用） | — | **首次建庫完成**：clone+index v1.4.0 (`06e3604`, 7084 nodes)、驗證 7/7、/sync-upstream + /extract-facts 1.4.0 + /compile 產生 25 個概念條目、/snapshot-knowledge 產生 knowledge-graph.json。事實層修正了 stub 推測（AddMcpServer ns、無獨立 Authentication 套件、McpClientFactory→McpClient）。剩 outputs/ 4 篇章節草稿待 review 移入 guide/ |
| v1.4.1 graph | 2026-07-18 | 無教學 drift；UA Level 2 工作流更新 | graph + workflow artifacts | 採 G2 路徑 C，以 deterministic wiki graph + reviewed augmentations 重建；102 nodes、228 edges、零 orphan，Dashboard 與 rollback smoke 通過。 |
