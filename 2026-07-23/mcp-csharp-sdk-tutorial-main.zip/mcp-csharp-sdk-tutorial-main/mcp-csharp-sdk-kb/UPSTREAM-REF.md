# 上游原始碼對齊記錄

每台機器需獨立 clone `csharp-sdk`（不從其他機器複製索引），對齊到此處記錄的 commit/tag，再透過 Codex MCP 或 `codebase-memory-mcp cli index_repository` 重建索引。`mcp-csharp-sdk-kb/` 與 `mcp-csharp-sdk-guide/` 可隨 root repository 取得。

---

## 目前對齊版本

| 項目 | 值 |
|------|-----|
| **Tag** | `v1.4.1` |
| **Commit Hash** | `2b7fd35fbe58dfb9f00eae8b3393e1a7361b5e01` |
| **知識庫基準版本** | v1.4.0（facts/wiki 基準；v1.4.1 為純內部 bug-fix，**API surface 與 v1.4.0 完全相同**，故 facts JSON 不需重抽） |
| **最後更新** | 2026-07-16 |
| **索引規模** | 7098 nodes / 23419 edges（codebase-memory-mcp 0.6.1；由既有完整索引增量重建 3 檔後為 `ready`） |
| **codebase-memory-mcp project 名稱** | `Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk`（⚠️ 路徑自動產生，**非** `csharp-sdk`；所有工具呼叫須用此全名） |
| **MCP 規格** | 2025-11-25 |

> ⚠️ **project 名稱規則**：codebase-memory-mcp 由絕對路徑自動命名。所有可移植工作流都使用 `<csharp-sdk-project>` placeholder，並在 session 首次查詢前以 `list_projects` 找出 root path 以 `/csharp-sdk` 結尾的 project；不可硬編碼本機名稱。
>
> ⚠️ **套件結構修正**：`src/` 下實際只有 4 個 NuGet 專案 + Analyzers：`ModelContextProtocol.Core`、`ModelContextProtocol`、`ModelContextProtocol.AspNetCore`、`ModelContextProtocol.Analyzers`（+ `Common` 共用內部碼）。**沒有獨立的 `ModelContextProtocol.Authentication` 專案**——authentication 型別併入 `ModelContextProtocol.AspNetCore`。套件歸屬一律以圖譜 `file_path` 第一段（`src/<Package>/...`）為準。

> 注意：GitHub releases 頁面曾短暫顯示 v1.3.0 為 latest，但 NuGet `ModelContextProtocol` 與官方 docs（docfx docurl）均對齊 **v1.4.0**。實際最新版以 `$sync-upstream` 查證結果為準。

---

## 切換機器 / 首次設定的對齊指令

```bash
# 在 mcp-csharp-sdk-tutorial/ 工作區根
git clone https://github.com/modelcontextprotocol/csharp-sdk.git
cd csharp-sdk
git fetch --tags
git checkout v1.4.1
cd ..

# 使用 CLI 或已設定的 Codex MCP：
codebase-memory-mcp cli index_repository '{"repo_path":"<絕對路徑>/csharp-sdk"}'
codebase-memory-mcp cli list_projects '{}'
# 取 root path 以 /csharp-sdk 結尾的 project 名稱；不要硬編碼本機值
```

---

## codebase-memory-mcp 索引同步策略

| 場景 | 動作 |
|------|------|
| 同機 `git pull` 後 | 無需動作，file watcher 自動增量更新 |
| 跨機初次設定 | 對該機器執行 `index_repository`（cache 位於使用者層，不跨機共享） |
| 工具版本升級後 | 視情況重跑 `index_repository` |
| 索引疑似失準 | 重跑 `index_repository` |

**為何索引不 commit**：體積大、路徑為機器絕對路徑不可移植、可隨時從 source 重建。

---

## 歷史記錄

| 日期 | Tag/Commit | 說明 |
|------|-----------|------|
| 2026-06-30 | `v1.4.0` | 初始建立此記錄與專案骨架。尚未 clone/index，commit hash 與索引規模待補。 |
| 2026-06-30 | `06e3604` | 首次 clone（detached HEAD @ v1.4.0）+ `index_repository` 完成：7084 nodes / 22986 edges。確認 project 名為路徑全名（非 `csharp-sdk`）；確認無獨立 Authentication 套件。 |
| 2026-07-09 | `2b7fd35` | `/sync-upstream`：checkout v1.4.1（純 bug-fix，修 `StreamableHttpServerTransport` 記憶體洩漏，**無 API 變更**）。抓取 v1.4.1 release notes；samples/docs 零變動。索引 status=ready、規模不變（7084/22986）。facts/wiki 基準維持 v1.4.0（API 等價，不需重抽）。 |
| 2026-07-13 | `2b7fd35` / 索引 `06e3604` | **閉環驗證（ch05 事實補入後）**：確認「worktree=v1.4.1、索引/基準=v1.4.0」為刻意狀態、非未受控 drift。`git diff 06e3604..2b7fd35 --stat` 僅 4 檔（`Directory.Build.props`、`StreamableHttpServerTransport.cs`、`PACKAGE.md` + 其測試）。逐檔確認本輪 ch05 驗證碰過的 9 個 src 檔（`McpException`/`McpProtocolException`/`McpErrorCode`/`CallToolResult`/`RequestContext`/`Tool`/`McpServerToolAttribute`/`ContentBlock`/`AIFunctionMcpServerTool`）在兩 commit 間 **byte-identical** → 以 v1.4.1 worktree grep 出的事實與 v1.4.0 圖譜索引完全一致。index_status=ready、7084/22986 不變。無需重建索引、無需 checkout。 |
| 2026-07-16 | `2b7fd35` | Codex 接手時以 codebase-memory-mcp 0.6.1 重建索引；status=`ready`、7098 nodes / 23419 edges，並重跑七項 C# 探測 7/7 通過。詳細證據見 `raw/facts/codebase-memory-mcp-validation.md`。 |
