---
package: ModelContextProtocol
source: csharp-sdk/src/ModelContextProtocol (v1.4.0 @ 06e3604)
fetched: 2026-06-30
note: 由 src/ 公開型別宣告 grep 產生（事實素材，非敘述）
---

# Public API Surface — ModelContextProtocol

- `public interface IMcpMessageFilterBuilder` — ns `Microsoft.Extensions.DependencyInjection` — IMcpMessageFilterBuilder.cs:8
- `public interface IMcpRequestFilterBuilder` — ns `Microsoft.Extensions.DependencyInjection` — IMcpRequestFilterBuilder.cs:8
- `public interface IMcpServerBuilder` — ns `Microsoft.Extensions.DependencyInjection` — IMcpServerBuilder.cs:19
- `public static class McpMessageFilterBuilderExtensions` — ns `Microsoft.Extensions.DependencyInjection` — McpMessageFilterBuilderExtensions.cs:9
- `public static class McpRequestFilterBuilderExtensions` — ns `Microsoft.Extensions.DependencyInjection` — McpRequestFilterBuilderExtensions.cs:10
- `public static partial class McpServerBuilderExtensions` — ns `Microsoft.Extensions.DependencyInjection` — McpServerBuilderExtensions.cs:16
- `public static class McpServerServiceCollectionExtensions` — ns `Microsoft.Extensions.DependencyInjection` — McpServerServiceCollectionExtensions.cs:11
- `public sealed partial class DistributedCacheEventStreamStore : ISseEventStreamStore` — ns `ModelContextProtocol.Server` — Server/DistributedCacheEventStreamStore.cs:26
- `public sealed class DistributedCacheEventStreamStoreOptions` — ns `ModelContextProtocol.Server` — Server/DistributedCacheEventStreamStoreOptions.cs:8
