---
package: ModelContextProtocol.AspNetCore
source: csharp-sdk/src/ModelContextProtocol.AspNetCore (v1.4.0 @ 06e3604)
fetched: 2026-06-30
note: 由 src/ 公開型別宣告 grep 產生（事實素材，非敘述）
---

# Public API Surface — ModelContextProtocol.AspNetCore

- `public static class McpAuthenticationDefaults` — ns `ModelContextProtocol.AspNetCore.Authentication` — Authentication/McpAuthenticationDefaults.cs:6
- `public class McpAuthenticationEvents` — ns `ModelContextProtocol.AspNetCore.Authentication` — Authentication/McpAuthenticationEvents.cs:6
- `public static class McpAuthenticationExtensions` — ns `Microsoft.Extensions.DependencyInjection` — Authentication/McpAuthenticationExtensions.cs:9
- `public partial class McpAuthenticationHandler : AuthenticationHandler<McpAuthenticationOptions>, IAuthenticationRequestHandler` — ns `ModelContextProtocol.AspNetCore.Authentication` — Authentication/McpAuthenticationHandler.cs:15
- `public class McpAuthenticationOptions : AuthenticationSchemeOptions` — ns `ModelContextProtocol.AspNetCore.Authentication` — Authentication/McpAuthenticationOptions.cs:9
- `public class ResourceMetadataRequestContext : HandleRequestContext<McpAuthenticationOptions>` — ns `ModelContextProtocol.AspNetCore.Authentication` — Authentication/ResourceMetadataRequestContext.cs:10
- `public static class HttpMcpServerBuilderExtensions` — ns `Microsoft.Extensions.DependencyInjection` — HttpMcpServerBuilderExtensions.cs:13
- `public class HttpServerTransportOptions` — ns `ModelContextProtocol.AspNetCore` — HttpServerTransportOptions.cs:14
- `public interface ISessionMigrationHandler` — ns `ModelContextProtocol.AspNetCore` — ISessionMigrationHandler.cs:24
- `public static class McpEndpointRouteBuilderExtensions` — ns `Microsoft.AspNetCore.Builder` — McpEndpointRouteBuilderExtensions.cs:14
