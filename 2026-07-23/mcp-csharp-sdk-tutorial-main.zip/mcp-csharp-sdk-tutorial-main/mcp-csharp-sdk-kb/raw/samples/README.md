---
fetched: 2026-07-09
last_sync_version: 1.4.1
source: https://github.com/modelcontextprotocol/csharp-sdk/tree/v1.4.1/samples
indexed_commit: 2b7fd35fbe58dfb9f00eae8b3393e1a7361b5e01
---

# 官方 Samples 摘要

> 由 `/sync-upstream` 維護。對齊 v1.4.1（`csharp-sdk/samples/`，與 v1.4.0 相同、零變動）。
> 「用到的核心 API」欄位以目錄語意與上游 `Program.cs`/README 為依據，作為 `/compile` 與 `/draft-chapter` 的素材線索；確切簽名仍以 `raw/facts/*.json` 為準。

| Sample 目錄 | 說明 | 用到的核心 API（線索） | 對應章節 |
|-------------|------|---------------|---------|
| `QuickstartWeatherServer` | 最小 stdio MCP server（天氣工具），官方 quickstart | `AddMcpServer` / `WithStdioServerTransport` / `WithToolsFromAssembly` / `[McpServerTool]` | ch03, ch04 |
| `QuickstartClient` | 最小 MCP client，連 stdio server 並呼叫工具 | `McpClient.CreateAsync` / `StdioClientTransport` / `ListToolsAsync` / `CallToolAsync` | ch10 |
| `EverythingServer` | 綜合 server，示範 tools/prompts/resources/完整 primitive | `[McpServerTool]` / `[McpServerPrompt]` / `[McpServerResource]` | ch05, ch06, ch07 |
| `FileBasedMcpServer` | 以檔案為基礎的完整 MCP server 範例 | `[McpServerResource]` / resources | ch07 |
| `AspNetCoreMcpServer` | ASP.NET Core 託管的 HTTP MCP server | `AddMcpServer` / `WithHttpTransport` / `MapMcp` | ch08, ch12 |
| `AspNetCoreMcpPerSessionTools` | per-session 動態工具（依 session 提供不同工具） | `MapMcp` / session 設定 / `WithHttpTransport` | ch08, ch12 |
| `TestServerWithHosting` | 以 Generic Host 託管的 server（測試用） | `Host.CreateApplicationBuilder` / `AddMcpServer` | ch03, ch13 |
| `InMemoryTransport` | in-memory transport，測試 client↔server 不開行程 | `StreamClientTransport` / `StreamServerTransport` | ch13 |
| `ChatWithTools` | 結合 `IChatClient`（Microsoft.Extensions.AI）以 MCP 工具做 function calling | `McpClientTool`（: `AIFunction`） / `IChatClient`（外部 NuGet） | ch16 |
| `LongRunningTasks` | 明確的 task 處理（2025-11-25 spec 的 Tasks） | `IMcpServer` / task store / CallTool-as-task | ch17 |
| `ProtectedMcpServer` | 需 OAuth 2.0 驗證的 server | `McpAuthenticationExtensions` / `McpAuthenticationOptions`（`.AspNetCore.Authentication`） | ch18 |
| `ProtectedMcpClient` | 連線受保護 server 的 client（OAuth flow） | client OAuth / `ModelContextProtocol.Authentication` | ch18 |

## 與 v1.4.0 release notes 的關聯
- `ProtectedMcpServer` / `ProtectedMcpClient` 與 v1.4.0 新增的 `IdentityAssertionGrantProvider`（ID-JAG, SEP-990）相關，但該型別本身在 `src/ModelContextProtocol.Core/Authentication/`，sample 主要示範 OAuth 2.0 基礎流程。
- `LongRunningTasks` 對應 Tasks（durable/long-running tool calls）。
