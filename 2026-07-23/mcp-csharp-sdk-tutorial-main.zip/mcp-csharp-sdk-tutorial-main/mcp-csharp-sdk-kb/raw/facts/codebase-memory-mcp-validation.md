---
validated: 2026-07-16
tool: codebase-memory-mcp 0.6.1
target_repo: csharp-sdk
target_tag: v1.4.1
indexed_commit: 2b7fd35fbe58dfb9f00eae8b3393e1a7361b5e01
project_name: Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk
index_nodes: 7098
index_edges: 23419
result: PASS (7/7)
platform: macOS
---

# codebase-memory-mcp macOS 驗證報告（csharp-sdk @ v1.4.1）

> 依工作區根 `AGENTS.md` 與 `CODEX-HANDOFF-PLAN.md` 的 7 項探測規格執行。判定門檻：≥ 6/7 通過視為可用。
> **結果：7/7 全數通過** → codebase-memory-mcp 在本機對此 repo 的 C# 解析可用，事實層 / 敘述層二分架構成立。

## 0. 索引基本資訊

| 項目 | 值 |
|------|-----|
| project 名稱 | `Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk`（⚠️ 路徑自動產生，非 `csharp-sdk`） |
| 索引模式 | `incremental`（由既有完整索引重建 3 個變更檔） |
| 節點 / 邊 | 7098 / 23419 |
| 索引 commit | `2b7fd35` (tag v1.4.1) |
| src `.cs` 檔數 | 321（全 repo 603） |
| 索引狀態 | `ready` |

## 1. 七項探測結果

| # | 探測 | 目標 | 結果 | 證據 |
|---|------|------|------|------|
| 1 | 外部依賴使用端 | `IChatClient`（Microsoft.Extensions.AI） | ✅ PASS | `search_code` 回傳 30 個結構化使用端、40 個 grep matches，涵蓋 src/tests/docs/samples；外部 NuGet 型別本體不在圖譜中，符合預期 |
| 2 | 方法簽名 | `McpClient.CreateAsync` | ✅ PASS | 圖譜節點 in_degree=99；`get_code_snippet` 取得完整簽名 `static async Task<McpClient> CreateAsync(IClientTransport, McpClientOptions?, ILoggerFactory?, CancellationToken)` |
| 3 | 繼承鏈 | `McpClientTool : AIFunction` | ✅ PASS | `search_graph` 找到 `.Core/Client/McpClientTool.cs`；`get_code_snippet` 明確回傳 `public sealed class McpClientTool : AIFunction` |
| 4 | Attribute 型別 | `McpServerToolAttribute` / `McpServerTool` | ✅ PASS | `search_graph` 找到兩個 `.Core/Server/` Class 節點，並排除 Analyzer 內同名字串常數 |
| 5 | Extension 方法 | `WithToolsFromAssembly` / `AddMcpServer` / `MapMcp` | ✅ PASS | 三者皆在 src/ 且 in_degree>0：`AddMcpServer`=153、`MapMcp`=78、`WithToolsFromAssembly`=4 |
| 6 | callers 連結度 | `AddMcpServer` 的 `trace_path` | ✅ PASS | `trace_path(function_name="AddMcpServer", direction="inbound", depth=1, include_tests=true)` 回傳大量 src/tests/docs/samples caller |
| 7 | Namespace 一致性 | 抽樣 `ModelContextProtocol.*` | ✅ PASS | `search_code("namespace ModelContextProtocol")` 回傳 499 個結構化結果、500 個 matches；抽樣 src 路徑與 namespace 對齊預期套件（見下表） |

## 2. 套件 ↔ namespace 對照（probe 7 普查，src/ 內 `namespace` 宣告計數）

| Namespace | 檔數 | 所屬 NuGet 套件（由 file_path 第一段判定） |
|-----------|------|------|
| `ModelContextProtocol.Protocol` | 117 | ModelContextProtocol.Core |
| `ModelContextProtocol.Server` | 54 | ModelContextProtocol.Core（+ 部分 ModelContextProtocol） |
| `ModelContextProtocol` | 31 | ModelContextProtocol |
| `ModelContextProtocol.Client` | 26 | ModelContextProtocol.Core |
| `ModelContextProtocol.Authentication` | 23 | **ModelContextProtocol.Core**（`src/ModelContextProtocol.Core/Authentication/`） |
| `ModelContextProtocol.AspNetCore` | 13 | ModelContextProtocol.AspNetCore |
| `Microsoft.Extensions.DependencyInjection` | 12 | ModelContextProtocol（SDK 自有的 DI 擴充方法刻意放此 ns） |
| `ModelContextProtocol.AspNetCore.Authentication` | 5 | ModelContextProtocol.AspNetCore |
| `ModelContextProtocol.Analyzers` | 5 | ModelContextProtocol.Analyzers |
| `Microsoft.AspNetCore.Builder` | 1 | ModelContextProtocol.AspNetCore（`MapMcp` 放此 ns） |

## 3. 工具使用慣例（本機實證，補強 `AGENTS.md`）

1. **project 參數必用動態解析名稱**：本次為 `Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk`，非字面 `csharp-sdk`。任何工作流若硬編碼短名稱，在本機都無效。
2. **外部依賴不索引**：`Microsoft.Extensions.AI.*`（`IChatClient`、`AIFunction`、`ChatOptions`）查無本體節點屬正常。
3. **`get_code_snippet` 用完整 qualified_name**；**`trace_path` 用「短名稱」**（傳完整 qualified_name 反而報 function not found）。兩者相反，勿混用。
4. **套件歸屬以 file_path 第一段為準**（`src/<Package>/...`），不可由 C# namespace 推測——SDK 的 DI/builder 擴充方法刻意放在 `Microsoft.*` namespace。
5. **`search_graph` 的 `name_pattern` 加 `^...$` 錨點搭配 `file_pattern` 時可能回 0**；錨點 regex 建議單獨使用，或改用不加 file_pattern 的寬鬆 pattern 再以 file_path 過濾。
6. **in_degree 為可靠連結度代理**；短名稱不明確時 `trace_path` 可能回空，優先看 in_degree。
7. **sandbox 與使用者 cache 視圖可能不同**：需要讀寫使用者層 cache 的 CLI 查驗應在相同權限視圖執行，否則可能看到舊的 0-node metadata。

## 4. 既有規劃的歷史修正（已納入 facts/wiki）

- ✅ **無獨立 `ModelContextProtocol.Authentication` NuGet 套件**。auth 型別分屬 `.Core`（`ModelContextProtocol.Authentication` ns）與 `.AspNetCore`（`ModelContextProtocol.AspNetCore.Authentication` ns）；INDEX 與相關 concepts 已依此修正。
- ✅ `mcp-server-tools.md` 的 package 已採 **ModelContextProtocol.Core**（`McpServerToolAttribute` 在 `src/ModelContextProtocol.Core/Server/`）。
- ✅ `AddMcpServer` 的 namespace 已採 **`Microsoft.Extensions.DependencyInjection`**（pkg `ModelContextProtocol`），不再使用早期推測值。
- ✅ `McpClient.CreateAsync` 確認存在（取代舊 `McpClientFactory.CreateAsync`，repo 中已無 `McpClientFactory`）；ns `ModelContextProtocol.Client`，pkg `.Core`。
