---
name: save-qa
description: Save a user-approved technical Q&A record under the KB brainstorming area. Use when the current conversation contains reusable MCP C# SDK findings and the user wants them persisted; never treat Q&A as verified ground truth.
---

# Save Q&A

將本次對話中的 `$wiki-query` 問答內容（或任何有價值的技術討論）儲存到 `mcp-csharp-sdk-kb/brainstorming/qa-sessions/`，供後續 `$wiki-query` 查詢與 `$compile-knowledge` 編譯時參考。

## 使用方式

```
$save-qa
$save-qa <主題>
```

## 執行步驟

1. **擷取問答內容**
   - 回顧當前對話，找出有價值的技術問答
   - 若使用者指定主題，聚焦該主題
   - 若無值得保存的內容，告知並結束

2. **判斷相關概念**：從問答識別涉及的 wiki/concepts/ 條目並記錄檔名

3. **建立 QA 檔案**
   - 確認 `mcp-csharp-sdk-kb/brainstorming/qa-sessions/` 存在
   - 檔名格式：`YYYY-MM-DD-<主題關鍵字>.md`
   - 同日同主題已存在則 append

4. **寫入內容**
   ```markdown
   ---
   date: YYYY-MM-DD
   topic: <主題摘要>
   related_concepts: [concept-name-1, concept-name-2]
   promoted_to_wiki: false
   ---

   ## 問題
   <使用者的問題>

   ## 回答
   <回答的重點摘要>

   ## 關鍵發現
   - <新知識或洞察>
   - <wiki/ 中尚未涵蓋的資訊>

   ## 來源
   - <wiki/concepts/ 條目>
   - <raw/ 素材>
   ```

5. **產出摘要**：顯示檔案路徑、關聯概念，若發現 wiki/ 缺漏建議下次 `$compile-knowledge` 補充

## 注意事項
- QA 記錄是探索性內容，不需符合 SCHEMA.md 嚴格格式
- 一個檔案可包含多組問答（同日同主題 append）
- `$compile-knowledge` 會掃描 `promoted_to_wiki: false` 的記錄

## Codex 執行契約

- 先 preview 要保存的問答、主題 slug、關聯 concepts 與目標檔；沒有可辨識問答時停止。
- 只可寫入 `mcp-csharp-sdk-kb/brainstorming/qa-sessions/`。
- 同日同主題既有檔可 append；保留既有內容與 frontmatter，不得覆寫其他 session。
- 完成後確認 YAML/Markdown 結構與 append diff，並標示內容尚非 verified facts。
