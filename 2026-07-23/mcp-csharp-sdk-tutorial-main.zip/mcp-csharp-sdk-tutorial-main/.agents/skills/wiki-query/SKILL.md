---
name: wiki-query
description: Answer MCP C# SDK questions from the local KB concepts, changelog, and traceable sources. Use for concept, API usage, version-change, or tutorial-mapping questions; remain read-only and escalate structural claims to MCP evidence.
---

# Wiki Query

在 `mcp-csharp-sdk-kb/wiki/concepts/` 與 `mcp-csharp-sdk-kb/wiki/api-changelog.md` 中搜尋與使用者問題相關的結構化知識。

## 使用方式

```
$wiki-query <問題或關鍵字>
```

範例：
- `$wiki-query McpServerTool 怎麼註冊`
- `$wiki-query Stdio 與 Streamable HTTP 傳輸差異`
- `$wiki-query stateless session 什麼時候用`

## 執行步驟

1. **解析查詢意圖**：概念說明、API 用法、版本變更、教學對應

2. **搜尋知識庫**
   - `mcp-csharp-sdk-kb/wiki/concepts/`（依 title、api_name、tags 匹配）
   - `mcp-csharp-sdk-kb/wiki/api-changelog.md`（版本變更）
   - `mcp-csharp-sdk-kb/wiki/INDEX.md`（分類位置）
   - `mcp-csharp-sdk-kb/brainstorming/qa-sessions/`（相關 QA）

3. **組合回答**
   - 繁體中文回答，引用具體的 wiki/concepts/ 條目
   - 附上對應教學章節連結（如有）
   - 若 wiki/ 資訊不足，提示需先 `$sync-upstream` + `$compile-knowledge`

4. **顯示來源**：列出 wiki/ 檔案路徑與對應 raw/ 原始素材路徑

## 注意事項
- 此指令是**純讀取**，只搜尋 kb 內容，不修改任何檔案
- UA 相容語意圖譜可由 Codex-native 流程重建，但只作敘述層導覽，不可當成 API ground truth
- 結構性問題（call graph、依賴）改用 codebase-memory-mcp `get_code_snippet` 或 `trace_path`

## Codex 執行契約

- 先 preview 查詢意圖與將讀取的 KB 範圍；全程唯讀，不建立或修改檔案。
- 結構性 API 主張先動態解析 MCP project，再以圖譜或 upstream source 驗證。
- 回答使用繁體中文，區分 verified facts、wiki 敘述與推論，並列出 repository 來源路徑。
- KB 資訊不足時明確說明缺口與建議工作流，不以對話記憶補完。
