---
name: lint-tutorial
description: Run and interpret the repository's deterministic documentation and knowledge-graph lint without modifying files. Use for guide, KB, graph, link, frontmatter, TOC, or release-readiness checks; do not reimplement lint rules ad hoc.
---

# Lint Tutorial

執行 repository 的 deterministic fast profile，解讀結果，但不自行複製 lint 邏輯。

## 流程

1. 從 workspace root 確認 `scripts/lint-docs.mjs` 存在；不存在即失敗並指出 Phase 6 尚未完成。
2. Preview 唯一執行命令：`node scripts/lint-docs.mjs`。
3. 執行命令並保留 exit code 與完整錯誤摘要。
4. 確認 fast profile 同時驗證正式 knowledge graph 的 schema、來源 commit、article/augmentation coverage、layers 與 orphan nodes。
5. exit code 0 時回報通過；非 0 時依腳本規則、檔案路徑與訊息分組，不修改任何檔案。
6. 若使用者要求 API 結構抽查，先由 `list_projects` 動態解析 `/csharp-sdk` project，再用 codebase-memory-mcp 補充證據；抽查不取代腳本結果。

## 邊界

- 全程唯讀，不得為了取得綠燈自動修檔。
- 不以 agent 主觀判斷宣稱「lint 全綠」。
- 不把 Docker、OAuth、AOT 或章節 build/test 混入 fast profile。
- 完成條件是可重現的命令、exit code 與錯誤清單。
