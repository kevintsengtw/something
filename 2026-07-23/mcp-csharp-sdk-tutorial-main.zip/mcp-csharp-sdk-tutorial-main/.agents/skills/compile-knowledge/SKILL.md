---
name: compile-knowledge
description: Compile verified MCP C# SDK facts and raw sources into knowledge-base concepts and indexes. Use when facts or upstream materials changed and wiki concepts must be regenerated; do not use for unverified API claims or direct guide edits.
---

# Compile Knowledge

讀取 `mcp-csharp-sdk-kb/raw/` 與 `mcp-csharp-sdk-kb/raw/facts/` 中的素材，編譯（新增或更新）`mcp-csharp-sdk-kb/wiki/concepts/` 條目與相關索引。

**核心原則**：frontmatter 結構欄位（api_name、namespace、package、since、current_version）**必須來自 raw/facts/*.json 的已驗證事實**，敘述（## 概述、## 變更歷史）由 LLM 撰寫但受事實清單約束。

> **project 名稱**：本檔所有 `<csharp-sdk-project>` 都是 placeholder。執行前以 codebase-memory-mcp `list_projects` 動態解析 root path 以 `/csharp-sdk` 結尾者；規則見根 `AGENTS.md`。

## 執行步驟

1. **掃描素材變更**
   - 讀取 `mcp-csharp-sdk-kb/wiki/INDEX.md` 中的 `last_compile` 時間戳
   - 列出 `mcp-csharp-sdk-kb/raw/` 比 last_compile 更新的檔案
   - 列出 `mcp-csharp-sdk-kb/raw/facts/` 中所有 JSON（事實清單）
   - 列出 `mcp-csharp-sdk-kb/brainstorming/qa-sessions/` 中 `promoted_to_wiki: false` 的記錄
   - 標記 [NEW] 與 [UPDATED] 素材
   - 若無變更，報告「無新素材需要編譯」並結束

2. **載入事實清單**
   - 讀取 `mcp-csharp-sdk-kb/raw/facts/*.json`（由 `$extract-facts` 產出）
   - 建立「API 名稱 → 已驗證事實」對照表
   - 此對照表是 wiki frontmatter 的**唯一可信來源**

3. **編譯概念條目**

   對每個 [NEW] / [UPDATED] 素材涉及的核心概念：

   - 建立或更新 `mcp-csharp-sdk-kb/wiki/concepts/<concept-name>.md`（kebab-case）
   - 遵循 `mcp-csharp-sdk-kb/wiki/SCHEMA.md` 的條目格式

   **frontmatter 填寫規則（嚴格）**：
   - `api_name`、`namespace`、`package`、`since`、`current_version`：**僅引用 raw/facts/ JSON 已驗證值**
   - `package`：以 file_path 第一段（`src/<Package>/...`）判定，**不可由 namespace 推測**
   - `sources`：列出對應的 raw/ 檔案路徑
   - 若該 API 不在事實清單，不寫 frontmatter，改用 `<!-- 待驗證 -->` 註解

   **敘述部分（LLM 撰寫但受約束）**：
   - 概述 / 變更歷史 / 教學章節對應 可用 LLM 自然語言
   - **不得**在敘述中宣告 API 簽名或方法存在
   - 程式碼範例呼叫 `get_code_snippet` 取上游實際 snippet

   **取上游使用範例**（必做）
   ```
   codebase-memory-mcp search_graph
     project: "<csharp-sdk-project>"
     name_pattern: "<API 名稱>"

   codebase-memory-mcp get_code_snippet
     project: "<csharp-sdk-project>"
     qualified_name: "<完整 qualified name>"

   codebase-memory-mcp search_code
     project: "<csharp-sdk-project>"
     pattern: "<API 名稱>"
   ```
   - `search_code` 找到的上游 tests/samples 路徑列入 `sources`（格式：`csharp-sdk/src/...` 或 `csharp-sdk/samples/...`）

   **廢棄/Experimental 處理**：
   - 若事實清單標記 `deprecation_complete: true`，tags 加 `deprecated`，改用 `## ⛔ 廢棄通知` 段落
   - 若標記為 Experimental（`MCPEXP###`），在概述註明診斷 ID 與抑制方式

4. **更新 API Changelog**
   - 更新 `mcp-csharp-sdk-kb/wiki/api-changelog.md`
   - 標記 breaking / non-breaking（依事實清單 kind 欄位）

5. **更新主索引**
   - 更新 `mcp-csharp-sdk-kb/wiki/INDEX.md`（修改條目列表與 last_compile 時間戳）

6. **更新 SCHEMA**
   - 若有新概念類別，更新 `mcp-csharp-sdk-kb/wiki/SCHEMA.md`

7. **產出編譯摘要**
   - 列出本次新增/更新的 wiki 條目
   - 列出尚未涵蓋的 raw/ 素材
   - 列出 frontmatter 未填寫（待驗證）的條目
   - 建議接下來執行 `$snapshot-knowledge` 與 `$drift-check`

## 編譯規則

### 概念粒度
- 每個獨立的 C# 類別/介面/attribute → 一個條目
- 設計模式或架構概念（如 stateless vs stateful session）→ 一個條目
- 配置或工作流程（如 transport 選擇）→ 一個條目

### 來源追溯
- `sources` 必須列出對應的 raw/ 檔案路徑
- conceptual docs、devblogs、samples README 全部列出
- `search_code` 找到的上游 tests/samples 路徑列入

### 增量編譯
- 只處理 [NEW] 與 [UPDATED] 素材；首次執行為全量編譯
- 所有判斷基於當下檔案狀態，不參考對話歷史

## 注意事項

- 此指令是事實層與敘述層的**唯一交會點**：frontmatter 受事實約束，敘述自由
- LLM 不得在編譯時即興宣告 API 存在或不存在
- 若事實清單與 release notes 衝突，**以事實清單為準**

## Codex 執行契約

- 從 workspace root 執行；先 preview 預計新增/更新的 concept、INDEX、SCHEMA 與 changelog，未確認前不寫入。
- `csharp-sdk/` 與 `raw/` 唯讀；只可寫入 `mcp-csharp-sdk-kb/wiki/`。
- 每個結構欄位都必須追溯到 `raw/facts/*.json` 的 verified 項目；缺證據即停止該項。
- 完成後執行 `node scripts/lint-docs.mjs`，並回報精確 diff 與未編譯項目。
