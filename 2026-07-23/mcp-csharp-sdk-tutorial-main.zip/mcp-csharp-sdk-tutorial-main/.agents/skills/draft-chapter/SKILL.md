---
name: draft-chapter
description: Draft a beginner-oriented Traditional Chinese tutorial chapter from one verified KB concept. Use when the user supplies a concept slug and optionally a chapter number; write only to outputs and never modify the reviewed guide directly.
---

# Draft Chapter

**用法**：在請求中提供 `<wiki-concept>` 與選填的 `[chapter-number]`。

範例：
- `$draft-chapter mcp-server-tools` — 自動選下一個可用章節號
- `$draft-chapter mcp-server-resources 7` — 指定章節 7

從 `mcp-csharp-sdk-kb/wiki/concepts/<concept>.md` 草擬一份新教學章節，輸出至 `outputs/draft-<concept>.md`（**不直接寫入 guide 目錄**）。

> **project 名稱**：本檔所有 `<csharp-sdk-project>` 都是 placeholder。執行前以 codebase-memory-mcp `list_projects` 動態解析 root path 以 `/csharp-sdk` 結尾者；規則見根 `AGENTS.md`。

## 設計原則

- **wiki 是 source of truth**：所有 API 名稱、簽名來自 wiki frontmatter（其又來自 raw/facts/）
- **codebase-memory-mcp 是驗證者**：草擬中提到的每個 API 名稱**都必須經圖譜驗證**才能寫入草稿
- **UA graph 僅供參考**：Codex-native UA 相容圖譜可輔助「相關概念」，但不得當作 API ground truth
- **草稿不直接落地**：產出 outputs/，避免污染 guide/

## 前置條件

- `mcp-csharp-sdk-kb/wiki/concepts/<concept>.md` 已存在
- 該條目通過 `$lint-tutorial`
- `mcp-csharp-sdk-kb/wiki/.understand-anything/knowledge-graph.json` 存在（找相關概念）

## 執行步驟

1. **讀取 wiki 條目**
   - 解析 frontmatter：title、api_name、namespace、package、tags、tutorial_chapters、sources
   - 解析內文段落

2. **codebase-memory-mcp 結構性驗證**

   對 frontmatter 與內文中的每個 API 名稱：
   ```
   codebase-memory-mcp search_graph
     project: "<csharp-sdk-project>"
     name_pattern: "<api_name>"
   ```
   - 查無 → 標記 `⚠️ 此 API 在圖譜未確認，待人工驗證`，**不寫入草稿**（外部 NuGet 型別另註）

   ```
   codebase-memory-mcp get_code_snippet
     project: "<csharp-sdk-project>"
     qualified_name: "<qualified_name>"
   ```
   - 取得 signatures、file_path，用於草稿程式碼範例

   ```
   codebase-memory-mcp search_code
     project: "<csharp-sdk-project>"
     pattern: "<api_name>"
   ```
   - 從上游 samples/tests 找實際使用範例

   ```
   codebase-memory-mcp trace_path
     project: "<csharp-sdk-project>"
     function_name: "<api_name>"
     direction: "inbound"
     depth: 1
   ```
   - 了解該 API 在上游被誰呼叫，輔助章節情境設計（`trace_path` 用短名稱）

3. **UA 相關概念查詢**
   - 讀取 `mcp-csharp-sdk-kb/wiki/.understand-anything/knowledge-graph.json`
   - 找此 concept 節點，取 strongly-connected 鄰居作為「相關概念」、同 community cluster 作為「延伸閱讀」

4. **參考既有教學風格**
   - `mcp-csharp-sdk-guide/PLAN-beginner-tutorial.md`（章節規劃原則）
   - `mcp-csharp-sdk-guide/README.md`（章節編號與分類）
   - 同類別最相近的既有章節

5. **章節結構生成**
   ```markdown
   # 第 N 章：<繁中標題>

   > 對應 wiki 概念：[[<concept>]]
   > 上游 API：`<api_name>`（`<package>`）
   > 引入版本：v<since>

   ## 本章目標
   ## 為什麼需要這個
   ## 核心概念
   ## 上手範例
   ## 進階用法
   ## 常見錯誤
   ## 相關章節
   ## 延伸閱讀
   ```

6. **判斷章節編號**
   - 若未指定：讀取既有檔名，找最大編號 NN，新章節為 NN+1，在草稿開頭以註解說明建議的編號與插入位置

7. **產出草稿**：寫入 `outputs/draft-<concept>.md`（開頭元資料區塊 + 結尾人工 review 檢查清單）

8. **產出摘要**
   - 草稿路徑、圖譜驗證通過的 API 數、標記「待人工驗證」的 API 數
   - 下一步：人工 review → 移至 `mcp-csharp-sdk-guide/<NN>-<slug>.md` → `$regenerate-toc` → `$lint-tutorial`

## 注意事項
- **草稿永遠不直接寫入 guide/**——這是設計約束
- LLM 在此扮演「寫敘述」角色，但結構性宣告仍受 codebase-memory-mcp 約束
- 若 wiki 條目格式不完整（`$lint-tutorial` 未通過），先修 wiki 再草擬

## Codex 執行契約

- 從使用者請求解析 `<wiki-concept>` 與選填 `<chapter-number>`；缺 concept 時停止並詢問。
- 先 preview concept、API 證據、章號與唯一輸出路徑；只可建立 `outputs/draft-<concept>.md`。
- `csharp-sdk/`、kb、guide 與 reviews 全部唯讀；不得直接發布草稿。
- 完成後執行草稿連結、code-fence 與引用檢查，並回報人工 review 下一步。
