---
name: draft-appendix
description: Draft a new MCP C# SDK tutorial appendix from verified repository sources. Use when the user supplies an appendix topic and optionally a letter; write only to outputs and never publish directly into the reviewed guide.
---

# Draft Appendix

**用法**：在請求中提供 `<topic>` 與選填的 `[appendix-letter]`。

範例：
- `$draft-appendix nuget-packages` — 自動選下一個可用附錄字母
- `$draft-appendix protocol-spec-mapping c` — 指定附錄 C

草擬一份新附錄，輸出至 `outputs/draft-appendix-<topic>.md`（**不直接寫入 guide 目錄**）。

> **project 名稱**：本檔所有 `<csharp-sdk-project>` 都是 placeholder。執行前以 codebase-memory-mcp `list_projects` 動態解析 root path 以 `/csharp-sdk` 結尾者；規則見根 `AGENTS.md`。

## 與 `$draft-chapter` 的差異

| 面向 | `$draft-chapter` | `$draft-appendix` |
|------|---------------|----------------|
| 編號 | NN（數字章節） | 英文字母 a–z |
| 內容類型 | 教學主題（學習路徑） | 參考資料、對照表、規格映射、SDK 範例索引 |
| 來源 | wiki/concepts/ | raw/samples/、raw/api-surface/、raw/release-notes/ |
| 風格 | 敘事 + 上手範例 | 索引 + 對照表 + 連結 |

## 適用情境（MCP C# SDK 常見附錄）

- **NuGet 套件對照**（Core / ModelContextProtocol / AspNetCore / Analyzers）
- **SDK Samples 索引**（對應 `csharp-sdk/samples/`）
- **MCP 規格映射**（2025-11-25 spec primitive ↔ C# 型別）
- **API 變更 / Migration Guide**（含 `McpClientFactory` → `McpClient` 等變更）
- **Resources（資源連結）**

## 執行步驟

1. **判斷附錄類型**：由 `<topic>` 推斷，讀取既有附錄找最相近範本

2. **收集素材**
   - **Samples 類**：讀取 `mcp-csharp-sdk-kb/raw/samples/`，對每個 sample `search_graph` 驗證用到的 API，連結到 `csharp-sdk/samples/`
   - **NuGet 套件類**：讀取 `mcp-csharp-sdk-kb/raw/api-surface/`，列出每套件 namespace、主要型別、版本（套件歸屬以 `src/<Package>/...` file_path 判定）
   - **Migration 類**：讀取 `mcp-csharp-sdk-kb/wiki/api-changelog.md`，整理 breaking changes 遷移路徑
   - **規格映射類**：對照 MCP 規格 primitive（Tool/Resource/Prompt/Sampling/Elicitation/Task）與 SDK 型別

3. **codebase-memory-mcp 驗證**
   ```
   codebase-memory-mcp search_graph
     project: "<csharp-sdk-project>"
     name_pattern: "<api_name>"
   ```
   - 查無 → 標記 `⚠️ 此 API 待人工驗證`，不寫入

4. **附錄結構生成**
   ```markdown
   # 附錄 <letter>：<繁中標題>

   > 本附錄整理 <用途說明>
   > 對應 wiki 條目：[[xxx]]、[[yyy]]
   > 最後更新：YYYY-MM-DD

   ## <分節>
   | 欄位 1 | 欄位 2 | 對應教學章節 |
   |--------|--------|------------|

   ## 詳細說明
   ## 參考連結
   ```

5. **判斷附錄字母**：若未指定，取下一個未用字母

6. **產出草稿**：寫入 `outputs/draft-appendix-<topic>.md`（元資料區塊 + 人工 review 檢查清單）

7. **產出摘要**：草稿路徑、涵蓋素材數、下一步（人工 review → 移至 `mcp-csharp-sdk-guide/appendix-<letter>-<slug>.md` → `$regenerate-toc` → `$lint-tutorial`）

## 注意事項
- 附錄草稿同樣**不直接寫入 guide/**
- 附錄含大量 hyperlink，產出後需驗證連結存活性
- 含上游 sample 路徑的附錄，務必確認該路徑在 `csharp-sdk/` 目前 commit 仍存在

## Codex 執行契約

- 從使用者請求解析 `<topic>` 與選填 `<appendix-letter>`；缺 topic 時停止並詢問。
- 寫入前 preview 預計素材、字母與唯一輸出路徑；只可建立 `outputs/draft-appendix-<topic>.md`。
- `csharp-sdk/`、kb、guide 與 reviews 全部唯讀；不得自動搬移或發布草稿。
- 完成後驗證草稿內相對連結與上游 sample 路徑，並回報人工 review 下一步。
