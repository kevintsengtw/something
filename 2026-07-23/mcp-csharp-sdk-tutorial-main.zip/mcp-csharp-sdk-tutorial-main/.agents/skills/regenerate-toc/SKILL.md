---
name: regenerate-toc
description: Rebuild only the chapter and appendix table sections in the guide README from existing files. Use when reviewed content has been moved into the guide; never create, delete, or rewrite chapter files.
---

# Regenerate TOC

掃描 `mcp-csharp-sdk-guide/*.md` 標題，重建 `mcp-csharp-sdk-guide/README.md` 中的章節表格與附錄表格。

## 用途
- 新章節由 `$draft-chapter` 草擬並人工移入後，更新 TOC
- 新附錄由 `$draft-appendix` 草擬並人工移入後，更新附錄索引
- 章節重新編號或拆分後同步
- 定期一致性維護

## 執行步驟

1. **掃描現有章節**
   - 列出 `mcp-csharp-sdk-guide/` 中所有 `NN-*.md`（01–99）與 `appendix-*-*.md`
   - 對每個檔案讀取第一行 `# <章節編號> 標題`

2. **抽取章節分類**
   - 根據 PLAN-beginner-tutorial.md 與既有 README 的分類規則分組
   - 新增章節未在原規劃中 → 標記 ⚠️ 提示需人工放入分類

3. **抽取附錄資訊**：對每個附錄檔案取得標題與描述

4. **讀取現有 README 結構**
   - 找出章節表格區塊（## 教學目錄 之後）
   - 保留非章節表格內容（前言、版本記錄、授權等）

5. **重建章節表格**
   ```markdown
   ## 教學目錄

   ### 第一部分：認識 MCP 與 SDK
   | 章節 | 標題 | 說明 |
   |------|------|------|
   | 01 | [什麼是 MCP](./01-what-is-mcp.md) | <說明> |

   ### 附錄
   | 附錄 | 標題 | 說明 |
   |------|------|------|
   | A | [NuGet 套件清單](./appendix-a-nuget-packages.md) | <說明> |
   ```

6. **寫回 README.md**：只更新章節與附錄表格區塊，保留其他內容，用 Edit 精確替換

7. **產出摘要**：新增/移除/標題變動的章節，標記未分類章節（⚠️）

## 注意事項
- 此指令**不刪除任何教學檔案**，只更新 README 索引
- 未分類章節需人工編輯 PLAN-beginner-tutorial.md
- 章節描述若 README 既有合理則保留；新章節用該章節第一段摘要
- 不修改章節檔案本身內容

## Codex 執行契約

- 先掃描並 preview 章節/附錄清單、分類與精確 README 表格 diff。
- 只可修改 `mcp-csharp-sdk-guide/README.md` 的章節與附錄表格區塊。
- 不得修改、建立或刪除章節/附錄，也不得改動 README 其他區塊。
- 完成後執行 `node scripts/lint-docs.mjs`，並回報新增、移除、標題變動與未分類項目。
