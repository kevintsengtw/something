---
name: snapshot-knowledge
description: Rebuild, validate, inspect, and safely publish the Codex-native Understand-Anything-compatible knowledge graph. Use when wiki content or verified upstream materials changed and a new graph snapshot is required.
---

# Snapshot Knowledge

G2 路徑 C 已完成：以 repository 內的 deterministic generator 重建 wiki 結構，再合併已審查的敘述層 augmentations。圖譜可供導覽與相關概念探索，但不是 API ground truth。

## 流程

1. Preview `csharp-sdk/` commit、wiki 變更、目前 graph 與 `graph-augmentations.json`；確認 upstream worktree 唯讀且 clean。
2. 建立 repository 外的暫存目錄，不直接寫入正式 snapshot。
3. 執行 `node scripts/build-knowledge-graph.mjs --wiki mcp-csharp-sdk-kb/wiki --output <staging> --augmentations mcp-csharp-sdk-kb/wiki/graph-augmentations.json`。
4. 執行 `node scripts/validate-knowledge-graph.mjs --graph-dir <staging> --wiki mcp-csharp-sdk-kb/wiki --augmentations mcp-csharp-sdk-kb/wiki/graph-augmentations.json --baseline mcp-csharp-sdk-kb/wiki/.understand-anything/knowledge-graph.json --report <report>`。
5. 人工審查 report 與 JSON diff：不得遺失 article/entity/claim、既有非分類語意邊、layer/tour coverage；orphan nodes 與 orphan concepts 必須為零。
6. 以相容 Dashboard 載入 staging JSON，確認畫面可用且瀏覽器 console 無錯誤。
7. 只有使用者明確同意發布後，執行 `node scripts/publish-knowledge-graph.mjs --from <staging> --to mcp-csharp-sdk-kb/wiki/.understand-anything --wiki mcp-csharp-sdk-kb/wiki --augmentations mcp-csharp-sdk-kb/wiki/graph-augmentations.json --baseline mcp-csharp-sdk-kb/wiki/.understand-anything/knowledge-graph.json --confirm-publish`。
8. 發布後重跑 validator、`node scripts/test-knowledge-graph.mjs` 與 `node scripts/lint-docs.mjs`，並保存審查記錄。

## 邊界

- `csharp-sdk/` 永遠唯讀；guide 不在本 skill 寫入範圍。
- 不得省略 staging、baseline comparison、Dashboard smoke 或 `--confirm-publish` 閘門。
- 發生任何 build、validation 或 publish 錯誤時，保留最後一份有效 snapshot，不得留下部分更新。
- `graph-augmentations.json` 是人工審查過的敘述層素材；API 名稱、簽名、namespace、繼承與套件歸屬仍須由 codebase-memory-mcp 或 upstream source 查證。
- 不把 Claude-only runtime 當成重建必要條件；UA Dashboard 僅作相容 viewer。
