---
name: extract-facts
description: Extract versioned API changes from local release notes and verify each item against codebase-memory-mcp. Use when a specific SDK version needs a new facts JSON; require an explicit version and never infer verified fields.
---

# Extract Facts

**用法**：在請求中提供 `<version>`（例：`$extract-facts 1.4.0`）。

從 `mcp-csharp-sdk-kb/raw/release-notes/v<version>.md` 抽取本次版本提到的所有 API 變更，**逐筆用 codebase-memory-mcp 驗證存在性、簽名、namespace**，產出結構化事實清單 JSON。

這個 skill 是 ground truth 的源頭——`$compile-knowledge` 編譯 wiki 時的 frontmatter（api_name、namespace、簽名）必須引用此清單。

> **project 名稱**：本檔所有 `<csharp-sdk-project>` 都是 placeholder。執行前以 codebase-memory-mcp `list_projects` 動態解析 root path 以 `/csharp-sdk` 結尾者；規則見根 `AGENTS.md`。

## 前置條件

- `mcp-csharp-sdk-kb/raw/release-notes/v<version>.md` 已存在（由 `$sync-upstream` 抓取）
- codebase-memory-mcp 已對 `csharp-sdk/` 建立索引（首次需 `index_repository`）

## 執行步驟

1. **讀取 release notes**
   - 讀取 `mcp-csharp-sdk-kb/raw/release-notes/v<version>.md`
   - 抽取本次版本提到的所有 API 變更，分三類：
     - `added`：新增的 class / interface / method / attribute / extension method
     - `renamed`：改名（記錄舊名 + 新名）
     - `deprecated` / `removed` / `experimental`：廢棄、移除、標記為 Experimental（如 `MCPEXP###`）

2. **逐筆 codebase-memory-mcp 驗證**

   對每個項目：

   **存在性確認**
   ```
   codebase-memory-mcp search_graph
     project: "<csharp-sdk-project>"
     name_pattern: "<API 名稱>"
   ```
   - 結果 = 1 個節點 → ✅ 正常
   - 結果 > 1 個節點 → 用 namespace 或 file_path 消歧
   - 結果 = 0 → 標記 `⚠️ release notes 提到但圖譜查無`（先確認非外部 NuGet 型別，如 `Microsoft.Extensions.AI.*`）

   **簽名與 namespace**
   ```
   codebase-memory-mcp get_code_snippet
     project: "<csharp-sdk-project>"
     qualified_name: "<完整 qualified name>"
   ```
   - 取得 namespace（如 `ModelContextProtocol.Server`、`ModelContextProtocol.Client`、`ModelContextProtocol.Protocol`）、file_path、method signatures
   - 確認所屬套件（以 `src/<Package>/...` file_path 第一段判定，**不可由 namespace 推測**）

   **取得依賴鏈與測試覆蓋**
   ```
   codebase-memory-mcp trace_path
     project: "<csharp-sdk-project>"
     function_name: "<API 名稱>"
     direction: "inbound"
     depth: 2
     include_tests: true
   ```
   - `trace_path` 用**短名稱**（與 `get_code_snippet` 的完整 qualified_name 相反）
   - 取得 callers 數量與測試/samples 引用，作為使用脈絡參考

   **廢棄確認**（針對 removed / deprecated）
   ```
   codebase-memory-mcp trace_path
     project: "<csharp-sdk-project>"
     function_name: "<舊 API 名稱>"
     direction: "inbound"
     depth: 1
   ```
   - 結果為空 → 廢棄徹底
   - 結果非空 → 上游仍有內部呼叫，標記 `[Deprecated, internal references remain]`

3. **寫入事實清單 JSON**

   產出 `mcp-csharp-sdk-kb/raw/facts/v<version>-verified-changes.json`：

   ```json
   {
     "version": "1.4.0",
     "generated": "YYYY-MM-DDTHH:MM:SSZ",
     "indexed_commit": "<csharp-sdk HEAD hash>",
     "changes": [
       {
         "kind": "added",
         "name": "<API 名稱>",
         "qualified_name": "<完整 qualified name>",
         "namespace": "<namespace>",
         "package": "ModelContextProtocol | ModelContextProtocol.Core | ModelContextProtocol.AspNetCore",
         "file_path": "<csharp-sdk/src/...>",
         "signatures": ["..."],
         "callers_in_upstream": 0,
         "verified": true,
         "source_release_note_line": "<原文引用>"
       }
     ],
     "unverified": [
       { "name": "...", "reason": "圖譜查無此節點 / 為外部 NuGet 型別" }
     ]
   }
   ```

4. **產出摘要**
   - 已驗證項目數 / 未驗證項目數
   - 列出未驗證項目並建議人工檢查（特別標示外部 NuGet 型別）
   - 建議接下來執行 `$compile-knowledge`

## 注意事項

- 此指令是事實層的源頭，**LLM 在此階段不寫敘述**
- 所有結構性宣告（namespace、簽名、所屬套件）必須來自 codebase-memory-mcp，不可由 release notes 文字推測
- 套件歸屬以 file_path 第一段（`src/<Package>/...`）為準——SDK 的 DI/builder 擴充方法刻意放在 `Microsoft.*` namespace
- `Microsoft.Extensions.AI.*`（`IChatClient`、`AIFunction`、`ChatOptions`）為外部 NuGet，圖譜查無屬正常，記入 `unverified` 並註明原因
- 未驗證項目**不直接寫入 wiki**——必須先排查原因
- 此 JSON 是 commit 對象，是後續流程的審計憑證

## Codex 執行契約

- 從使用者請求解析明確 `<version>`；缺版本、release note 或 ready index 時停止，不寫檔。
- 先 preview 版本、indexed commit、候選 API、verified/unverified 數與輸出路徑。
- 只可寫入 `mcp-csharp-sdk-kb/raw/facts/v<version>-verified-changes.json`；其餘路徑唯讀。
- 完成後驗證 JSON 可解析、schema 欄位、commit 對齊與所有 `verified: true` 證據。
