# UA Level 2 Codex-native 重建計畫

## Goal

解除 Understand-Anything graph 的 Level 1 凍結，讓 Codex 能從乾淨工作區安全重建、驗證並發布 `mcp-csharp-sdk-kb/wiki/.understand-anything/`。

## Success criteria

- 使用 repository 內建、零祕密依賴的 Node.js generator。
- 在暫存位置產生 graph，不直接覆寫最後一份有效快照。
- 保留全部 wiki article，以及既有 curated entity/claim 節點。
- 驗證 schema、edge references、layers、tour、orphan concepts 與 upstream commit。
- 相同輸入與 timestamp 產生 byte-identical JSON。
- 既有 Understand-Anything 2.7.5 Dashboard 可載入新 graph。
- 發布失敗時不破壞最後一份有效快照。
- 更新 `snapshot-knowledge`、版本更新 Playbook 與 Level 2 清單。

## Decision

採 G2 路徑 C：Codex-native deterministic generator。Claude Understand-Anything 2.7.5 僅作 schema 與 Dashboard 相容性參考，不作執行期依賴。

## Constraints

- `csharp-sdk/`、`.claude/`、`CLAUDE.md` 與 `.mcp.json` 唯讀。
- graph 不是 API ground truth；API 仍以 upstream、facts 與 codebase-memory-mcp 為準。
- 正式快照只在暫存重建、validator、差異審查與 Dashboard smoke 全部通過後發布。

## Risks

- 舊 graph 的 entity/claim 是一次性 LLM 分析，無法只靠 Markdown 完整重建。
- INDEX 文章可出現在多個分類，舊 parser 以最後分類覆蓋 primary category。
- 舊 graph 有孤立 claims；不得把它們誤判為成功重建品質。
- graph 與 meta 分檔發布時可能只更新一半。

## Verification

1. Generator/validator unit smoke。
2. 固定 timestamp 雙重建 byte comparison。
3. 新舊 graph semantic diff。
4. Dashboard HTTP load 與 JSON fetch。
5. 正式發布後重新驗證、文件 lint、skill validation、Git/upstream clean。
