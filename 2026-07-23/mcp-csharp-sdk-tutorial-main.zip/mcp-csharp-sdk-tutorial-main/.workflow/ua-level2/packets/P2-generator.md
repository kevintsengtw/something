# Packet P2 — Generator

- Objective：建立零祕密依賴、可重現的 Codex-native graph generator。
- Context：wiki 結構可 deterministic 重建；舊 entity/claim 需轉成 reviewed augmentations。
- Files / sources：`scripts/build-knowledge-graph.mjs`、`mcp-csharp-sdk-kb/wiki/graph-augmentations.json`。
- Ownership：generator 與 augmentation input，不修改正式 snapshot。
- Do：解析 Markdown/frontmatter/INDEX/wikilinks，合併 curated nodes/edges/bindings。
- Do not：直接輸出到 `.understand-anything/` 或呼叫 Claude runtime。
- Expected output：staging graph/meta。
- Verification：固定 timestamp 雙 build byte-identical，28 articles 與 64 augmentation nodes 全覆蓋。
