# Packet P1 — Schema Audit

- Objective：定義 Dashboard 相容 schema，辨識舊快照缺陷與不可遺失內容。
- Context：UA 2.7.5 僅作 schema/viewer 參考；API ground truth 在 upstream 與 codebase-memory-mcp。
- Files / sources：舊 graph/meta、UA parser/dashboard types、wiki INDEX/concepts。
- Ownership：只讀盤點與 `.workflow/ua-level2/results/schema-audit.md`。
- Do：統計 node/edge/layer/tour，找 orphan、分類覆蓋與 commit 問題。
- Do not：修改正式 graph、wiki、guide 或 upstream。
- Expected output：相容契約與 Path C 語意政策。
- Verification：所有既有 article/entity/claim 與非分類語意邊都有保存策略。
