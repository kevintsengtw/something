# Packet P4 — Integration And Release

- Objective：完成 Dashboard 相容驗證、安全發布、技能與文件整合。
- Context：使用者已明確要求立即執行 Level 2；正式發布仍需 staging 與驗證閘門。
- Files / sources：snapshot skill、Playbook、README/SETUP/QuickStart、validation 與正式 graph/meta。
- Ownership：整合文件、正式發布與結案證據。
- Do：Dashboard smoke、發布後 validator/tests/lint、更新清單。
- Do not：修改 `.claude/`、`CLAUDE.md`、`.mcp.json` 或 `csharp-sdk/`。
- Expected output：可維運的 Level 2 pipeline 與結案記錄。
- Verification：Dashboard console clean、fast lint/skill/migrator/workflow checks 全綠。
