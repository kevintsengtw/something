# Packet P3 — Validation And Safety

- Objective：建立獨立 validator、tests 與 rollback-safe publisher。
- Context：graph/meta 分檔發布不可留下半套狀態。
- Files / sources：`scripts/validate-knowledge-graph.mjs`、`scripts/test-knowledge-graph.mjs`、`scripts/publish-knowledge-graph.mjs`。
- Ownership：驗證與發布 scripts。
- Do：檢查 schema、references、coverage、commit、baseline diff、orphans、reproducibility 與 rollback。
- Do not：在 validation failure 後發布或刪除最後有效快照。
- Expected output：機器可讀 validation report 與 failure-safe publisher。
- Verification：dangling edge rejection、incomplete staging rollback、zero orphan。
