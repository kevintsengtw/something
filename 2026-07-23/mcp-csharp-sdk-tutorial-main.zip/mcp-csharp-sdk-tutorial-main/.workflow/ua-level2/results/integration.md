# Integration Result

## Accepted

- Codex-native deterministic generator + reviewed augmentations。
- Independent validator、reproducibility tests 與 rollback-safe publisher。
- Understand-Anything 2.7.5 作相容 Dashboard viewer。

## Rejected

- 直接複製 Claude agents/hooks/runtime。
- 每次 snapshot 重新呼叫 LLM 產生 entity/claim。
- Builder 直接覆寫正式 graph/meta。

## Conflicts

- 舊 graph 需保留敘述內容，但含 10 個 orphan 與錯誤 primary category；採保留 entity/claim 與語意邊、重建分類並補上 `documents` edges 的方式解決。

## Decisions

- 正式 graph/meta 只由 staging 經 rollback-safe publisher 發布。
- API ground truth 不轉移到 UA graph。

## Final Changes

- `snapshot-knowledge`、version update Playbook、README、SETUP、QuickStart 與 validation 入口已改為 Level 2 流程。
- Fast lint 已納入正式 graph schema、upstream commit、coverage、layers 與 orphan 檢查。
- Skill contract validation 已改驗 builder、validator、publisher 與 `--confirm-publish` 閘門。

## Remaining Risks

- Reviewed augmentations 仍需隨 wiki 敘述變更人工檢查。
- Dashboard viewer 未來升版時需重新做 schema/UI smoke。
- `.claude/`、`CLAUDE.md`、`.mcp.json` 與 `csharp-sdk/` 保持未修改。
