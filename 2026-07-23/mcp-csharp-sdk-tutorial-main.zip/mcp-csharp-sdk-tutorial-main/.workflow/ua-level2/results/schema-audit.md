# Schema Audit Result

## Accepted compatibility contract

- Top-level：`version`、`kind`、`project`、`nodes`、`edges`、`layers`、`tour`。
- `kind` 維持 `knowledge`；`version` 維持 `1.0.0`。
- Node 必含 `id`、`type`、`name`、`summary`、`tags`、`complexity`。
- Article 保留 `filePath` 與 `knowledgeMeta.content/wikilinks/backlinks`。
- Edge 必須引用存在 node，並保留 `type/direction/weight`。
- Layer 與 tour 只引用存在 node。

## Existing graph findings

- 28 article、10 topic、39 entity、25 claim，共 102 nodes。
- 216 edges、11 layers、10 tour steps。
- 7 claim、2 article 與 1 empty-category topic 沒有 graph edge。
- INDEX 的「按教學章節反查」重複列出所有 concepts，舊 parser 將它覆蓋成每篇文章的 primary category。
- `project.gitCommitHash` 為空，但 `meta.gitCommitHash` 正確對齊 upstream `2b7fd35f...`。

## Path C semantic policy

- Wiki 結構由 Markdown/frontmatter/INDEX/wikilinks deterministic 重建。
- 既有 entity/claim 轉成 tracked augmentation input，避免每次依賴 LLM 重新發明敘述。
- augmentation node 必須連回 article；舊 orphan claim 以 `documents` edge 修復。
- 空分類不產生孤立 topic；未分類文章放入 deterministic `Other` topic/layer。
- article 可屬多個分類，但 primary category 使用 INDEX 首次出現的分類。
