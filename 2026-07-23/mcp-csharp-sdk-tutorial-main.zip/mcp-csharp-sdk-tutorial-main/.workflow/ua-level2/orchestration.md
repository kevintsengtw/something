# UA Level 2 Orchestration

## Work packets

### P1 — Schema audit

- 來源：現有 graph/meta、UA 2.7.5 parser/merger、Dashboard type usage。
- 產出：相容欄位、舊 graph 品質問題、Path C 決策。

### P2 — Generator

- 所有權：`scripts/build-knowledge-graph.mjs`、augmentation input。
- 產出：article/topic/wikilink/category graph，加回 curated entity/claim。

### P3 — Validator and tests

- 所有權：`scripts/validate-knowledge-graph.mjs`、`scripts/test-knowledge-graph.mjs`。
- 產出：schema、reference、coverage、reproducibility、baseline diff 驗證。

### P4 — Integration and release

- 所有權：`snapshot-knowledge` skill、Playbook、Level 2 follow-up、validation evidence。
- 產出：暫存 graph、Dashboard smoke、受保護發布、解除 Level 1。

## Integration policy

- article ID、entity ID、claim ID 不得無說明遺失。
- 舊 graph 的錯誤 primary category 與孤立 claim 可修正，但差異必須記錄。
- 新 schema 欄位只能 additive；Dashboard 既有必要欄位不可移除。
- 任一驗證失敗即停止發布，保留現有 `.understand-anything/`。
