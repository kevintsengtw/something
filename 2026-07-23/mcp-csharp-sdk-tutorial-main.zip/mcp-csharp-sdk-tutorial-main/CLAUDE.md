# MCP C# SDK 繁中教學專案 — Claude 主導指引

> 本檔為**工作區根**的 master orchestration 文件，是 Claude 在本工作區做任何工作的首要指引。
> 設計依據：[`mcp-csharp-sdk-kb/WORKFLOW-DESIGN-v1.md`](./mcp-csharp-sdk-kb/WORKFLOW-DESIGN-v1.md)
> 目標環境：**macOS**
> 架構參考：本專案沿用 `agent-framework-tutorial` 的 v2 工作流設計（事實層 / 敘述層二分）。

---

## 1. 工作區角色

這是一個**繁體中文版 MCP C# SDK 教學專案**，三子目錄並列：

| 子目錄 | 角色 | Claude 可否寫入 |
|--------|------|---------------|
| `csharp-sdk/` | 上游原始碼（[modelcontextprotocol/csharp-sdk](https://github.com/modelcontextprotocol/csharp-sdk) 的 git clone） | ❌ 唯讀，僅供 codebase-memory-mcp 索引 |
| `mcp-csharp-sdk-kb/` | LLM Wiki 知識庫（Karpathy pattern）+ raw/ 上游素材鏡像 | ✅ 由 slash commands 自動維護 |
| `mcp-csharp-sdk-guide/` | 繁中教學文件本體 | ✅ 透過 `/draft-*` 與 `/update-tutorial` 修改 |

**端點目標**：建立、維護、擴充 `mcp-csharp-sdk-guide/` 的內容。

**codebase-memory-mcp project 名稱**：由絕對路徑自動產生、**因機器而異**（本機實測為 `Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk`）。指令檔一律用 placeholder `<csharp-sdk-project>`，執行前以 `list_projects` 解析實際名稱再代入。規約見 §6。

---

## 2. 工具二分原則（嚴格遵守）

| 層別 | 工具 | 職責 | 性質 |
|------|------|------|------|
| **事實層** | **codebase-memory-mcp** | 原始碼結構性事實的 ground truth | Deterministic（tree-sitter parser） |
| **敘述層** | **Understand-Anything + LLM** | 概念敘述、關係抽取、視覺化、Onboarding、教學撰寫 | LLM-based（語意理解） |

**核心約束**：
1. 事實層與敘述層**不交叉**。LLM 不負責判斷 API 是否存在；codebase-memory-mcp 不負責生成敘述。
2. 任何結構性宣告（API 名稱、簽名、namespace、繼承關係）**必須先經 codebase-memory-mcp 驗證**，再交給 LLM 寫敘述。
3. 若 codebase-memory-mcp 對 C# 的解析在 macOS 上不可用（首次驗證見 §6），整個架構失效，本指引作廢，退化為純 grep + WebFetch 上游 GitHub 的方案。

---

## 3. 指令入口點

**所有自訂 slash commands 統一住在 `mcp-csharp-sdk-tutorial/.claude/commands/`**（工作區根，本檔同層）。

12 個指令分四條 pipeline：

| Pipeline | 指令 | 用途 |
|---------|------|------|
| A 版本更新 | `/sync-upstream` | 抓 raw/ 素材 + 確認 codebase-memory-mcp 索引同步 |
| A | `/extract-facts <version>` | 從 release-notes 抽事實清單，逐筆 codebase-memory-mcp 驗證 |
| A | `/compile` | 編譯 wiki/concepts/，frontmatter 引用事實清單 |
| A | `/snapshot-knowledge` | 對 wiki/ 跑 `/understand-knowledge --language zh-TW` |
| A | `/drift-check` | 偵測 wiki vs tutorial 偏移，輸出 🔴/🟡/🟢 報告 |
| A | `/update-tutorial [breaking\|outdated\|all]` | 自動修正偏移（替換前 codebase-memory-mcp 驗證） |
| A | `/lint` | wiki + tutorial 雙側一致性檢查 |
| B 探索 | `/wiki-query <關鍵字>` | 在 wiki/ 與 brainstorming/ 查詢 |
| B | `/save-qa` | 把對話中的問答存入 brainstorming/qa-sessions/ |
| D 教學建立 | `/draft-chapter <wiki-concept> [chapter-no]` | 從 wiki 概念草擬新教學章節 |
| D | `/draft-appendix <topic>` | 草擬新附錄 |
| D | `/regenerate-toc` | 重建 README.md 章節索引 |

Pipeline C（Onboarding）直接用 UA plugin 原生指令 `/understand-onboard`，不需自訂。

---

## 4. 標準版本更新流程

MCP C# SDK 發布新版本時，依序執行：

```
/sync-upstream
    ↓
/extract-facts <new-version>      ← codebase-memory-mcp 主導，建立事實 JSON
    ↓
/compile                          ← LLM 編譯敘述，受事實清單約束
    ↓
/snapshot-knowledge               ← UA 產生知識圖譜快照
    ↓
/drift-check                      ← 比對 wiki/ vs tutorial/
    ↓
/update-tutorial breaking         ← 自動修正 🔴
    ↓
/drift-check                      ← 驗證 🔴 = 0
    ↓
/lint                             ← wiki + tutorial 一致性
```

完整版見 [`mcp-csharp-sdk-kb/PLAYBOOK-version-update.md`](./mcp-csharp-sdk-kb/PLAYBOOK-version-update.md)。

---

## 5. 教學文件建立流程（Pipeline D）

```
（前置：對應 wiki/concepts/ 條目已存在且通過 /lint）
    ↓
/draft-chapter <concept> [chapter-no]
    ↓
（草稿輸出到 outputs/draft-<concept>.md，不直接寫入 guide/）
    ↓
（人工 review + 移動至 mcp-csharp-sdk-guide/<NN>-<slug>.md）
    ↓
/regenerate-toc                   ← 更新 README 章節索引
    ↓
/lint                             ← 驗證
```

**草稿不直接寫入教學目錄**——`/draft-chapter` 永遠輸出到 `outputs/`，由人工確認後手動移動。

---

## 6. codebase-memory-mcp 驗證狀態與 project 名稱解析

> ✅ **已驗證通過（7/7）— 2026-06-30**
> 環境：macOS（Darwin 25.5.0）、csharp-sdk @ v1.4.0（commit `06e3604`）、索引 7084 nodes / 22986 edges。
> 詳細結果與實測修正：[`mcp-csharp-sdk-kb/raw/facts/codebase-memory-mcp-validation.md`](./mcp-csharp-sdk-kb/raw/facts/codebase-memory-mcp-validation.md)

### ⚠️ project 名稱解析（所有 codebase-memory-mcp 呼叫適用）

codebase-memory-mcp 的 project 名稱由**索引時的絕對路徑自動產生**，因此因機器、因 clone 位置而異。本機實測為：

```
Users-tsengweihua-Documents-mcp-csharp-sdk-tutorial-csharp-sdk
```

**約定**：
1. 所有 `.claude/commands/` 指令檔中的 codebase-memory-mcp 呼叫一律寫 `project: "<csharp-sdk-project>"`（placeholder，**不是**字面值）。
2. 每個 session 首次呼叫 codebase-memory-mcp 前，先執行 `mcp__codebase-memory-mcp__list_projects`，取路徑以 `/csharp-sdk` 結尾的 project 名稱，作為本次 session 的 `<csharp-sdk-project>` 實際值。
3. **不要**把本機的路徑全名硬寫進會 commit 的指令檔——跨機器會失效。要記錄本機名稱請寫在 `mcp-csharp-sdk-kb/UPSTREAM-REF.md` 或 validation 檔（那些是機器狀態記錄，不是跨機規範）。

### 已通過的七項探測（摘要）

| 探測 | 目標 API | 結果 |
|------|---------|------|
| 1. 外部依賴使用端 | `IChatClient`（Microsoft.Extensions.AI） | ✅ 圖譜查無本體（外部 NuGet），改找使用端 |
| 2. 方法簽名 | `McpClient.CreateAsync` | ✅ in_degree=99，`Task<McpClient>` 多載 |
| 3. 繼承鏈 | `McpClientTool : AIFunction` | ✅ base 為外部型別，正確不在圖譜 |
| 4. Attribute 型別 | `McpServerToolAttribute` | ✅ ns `ModelContextProtocol.Server`、pkg **.Core** |
| 5. Extension 方法 | `AddMcpServer`/`MapMcp`/`WithToolsFromAssembly` | ✅ in_degree 153/78/4 |
| 6. callers 連結度 | `AddMcpServer` trace_path | ✅ in_degree 為可靠代理 |
| 7. Namespace 一致性 | 抽樣 `ModelContextProtocol.*` | ✅ 全部對齊 |

### 工具使用慣例（本機實證）

1. **project 參數用解析名稱**（見上「project 名稱解析」），勿直接用字面 `csharp-sdk`。
2. **外部依賴不索引**：`Microsoft.Extensions.AI.*`（`IChatClient`、`AIFunction`、`ChatOptions`）查無本體屬正常。
3. **`get_code_snippet` 用完整 qualified_name；`trace_path` 用「短名稱」**（兩者相反，勿混用；`get_code_snippet` 前先 `search_graph` 找 qualified_name）。
4. **套件歸屬以 file_path 第一段為準**（`src/<Package>/...`），不可由 C# namespace 推測——SDK 的 DI/builder 擴充方法刻意放在 `Microsoft.*` namespace。
5. **in_degree 為可靠連結度代理**；短名稱不明確時 `trace_path` 可能回空。

### 重跨驗證時機
切換新機器、codebase-memory-mcp 主要版本升級、上游切換 commit 跨越 minor 版本。

---

## 7. 子目錄 CLAUDE.md 補充

| 路徑 | 內容 | 與本檔關係 |
|------|------|----------|
| `mcp-csharp-sdk-kb/CLAUDE.md` | kb 維護細節（條目格式、編譯規則） | 補充本檔，不主導 |
| `mcp-csharp-sdk-guide/CLAUDE.md` | （可選）教學風格指引 | 補充本檔，目前未建立 |

---

## 8. 重要禁止事項

- ❌ 不要在 `csharp-sdk/` 寫入任何檔案——它是上游唯讀基準層
- ❌ 不要把草稿章節直接寫進 `mcp-csharp-sdk-guide/`，永遠先進 `outputs/`
- ❌ 不要假設 codebase-memory-mcp 在 Windows 與 macOS 行為一致——首次在 macOS 使用需跑 §6 驗證
- ❌ 不要在 wiki/concepts/ 條目中即興宣告 API 簽名——必須來自 raw/facts/ 或 codebase-memory-mcp
- ❌ 不要在 `mcp-csharp-sdk-kb/` 內加入 `.claude/` 子目錄——指令入口點只在工作區根

---

## 9. JSON / 索引 commit 策略

| 產物 | commit? | 路徑 |
|------|---------|------|
| codebase-memory-mcp 索引 | ❌ gitignore | 存於 `~/.codebase-memory-mcp/` 全域目錄，**不在工作區內** |
| UA 知識圖譜 JSON | ✅ commit | `mcp-csharp-sdk-kb/wiki/.understand-anything/knowledge-graph.json`（含 `meta.json`） |
| UA 中間檔 | ❌ gitignore | `mcp-csharp-sdk-kb/wiki/.understand-anything/intermediate/` |
| UA diff overlay | ❌ gitignore | `mcp-csharp-sdk-kb/wiki/.understand-anything/diff-overlay.json` |
| 事實清單 JSON | ✅ commit | `mcp-csharp-sdk-kb/raw/facts/*.json` |

> UA 產出落在 `wiki/.understand-anything/`，因為 `/snapshot-knowledge` 以 `mcp-csharp-sdk-kb/wiki` 為 target 呼叫 `/understand-knowledge`，UA 一律寫入 `<TARGET_DIR>/.understand-anything/`。

---

## 10. 本專案與 agent-framework-tutorial 的對應

| agent-framework-tutorial | 本專案 | 說明 |
|--------------------------|--------|------|
| `agent-framework/` | `csharp-sdk/` | 上游 SDK clone |
| `agent-framework-kb/` | `mcp-csharp-sdk-kb/` | 知識庫 |
| `microsoft-agent-framework-tutorial/` | `mcp-csharp-sdk-guide/` | 教學本體 |
| project 名 `agent-framework` | project placeholder `<csharp-sdk-project>` | codebase-memory-mcp（名稱因機而異，見 §6） |
| 基準版本 v1.11.1 | 基準版本 v1.4.0 | SDK 版本 |

工作流、指令、SCHEMA、命名規範完全沿用，僅替換 SDK 對象與路徑。
