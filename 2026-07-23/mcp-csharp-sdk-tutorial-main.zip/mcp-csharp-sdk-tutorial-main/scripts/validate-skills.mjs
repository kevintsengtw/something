#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import process from "node:process";

const root = process.cwd();
const skillsRoot = path.join(root, ".agents", "skills");
const expected = {
  "compile-knowledge": ["raw/facts", "preview", "node scripts/lint-docs.mjs", "csharp-sdk/` 與 `raw/` 唯讀"],
  "draft-appendix": ["outputs/draft-appendix-<topic>.md", "缺 topic 時停止", "guide 與 reviews 全部唯讀"],
  "draft-chapter": ["outputs/draft-<concept>.md", "缺 concept 時停止", "guide 與 reviews 全部唯讀"],
  "drift-check": ["index_status=ready", "drift-report.md", "guide、facts、raw 與 upstream 唯讀"],
  "extract-facts": ["缺版本", "verified-changes.json", "JSON 可解析"],
  "lint-tutorial": ["node scripts/lint-docs.mjs", "全程唯讀", "exit code"],
  "regenerate-toc": ["精確 README 表格 diff", "只可修改 `mcp-csharp-sdk-guide/README.md`", "不得修改、建立或刪除章節"],
  "save-qa": ["brainstorming/qa-sessions", "append", "尚非 verified facts"],
  "snapshot-knowledge": ["build-knowledge-graph.mjs", "validate-knowledge-graph.mjs", "publish-knowledge-graph.mjs", "--confirm-publish"],
  "sync-upstream": ["預設只 preview", "csharp-sdk/` 永遠唯讀", "guide、facts、wiki 不在本 skill 寫入範圍"],
  "update-tutorial": ["缺 scope 時停止", "🟢 Enhancement", "node scripts/lint-docs.mjs"],
  "wiki-query": ["全程唯讀", "動態解析 MCP project", "repository 來源路徑"]
};
const errors = [];

function fail(skill, message) {
  errors.push(`${skill}: ${message}`);
}

function frontmatter(text) {
  const match = text.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!match) return null;
  const data = {};
  for (const line of match[1].split(/\r?\n/)) {
    const item = line.match(/^([a-z-]+):\s*(.+)$/);
    if (item) data[item[1]] = item[2].trim().replace(/^['"]|['"]$/g, "");
  }
  return data;
}

const actual = fs.readdirSync(skillsRoot, { withFileTypes: true }).filter((entry) => entry.isDirectory()).map((entry) => entry.name).sort();
const expectedNames = Object.keys(expected).sort();
if (JSON.stringify(actual) !== JSON.stringify(expectedNames)) fail("inventory", `expected ${expectedNames.join(", ")}; found ${actual.join(", ")}`);

for (const [name, requiredText] of Object.entries(expected)) {
  const file = path.join(skillsRoot, name, "SKILL.md");
  if (!fs.existsSync(file)) {
    fail(name, "missing SKILL.md");
    continue;
  }
  const text = fs.readFileSync(file, "utf8");
  const metadata = frontmatter(text);
  if (!metadata) {
    fail(name, "invalid frontmatter");
    continue;
  }
  if (metadata.name !== name) fail(name, `frontmatter name is ${metadata.name}`);
  if (!metadata.description || metadata.description.length > 1024 || /[<>]/.test(metadata.description)) fail(name, "invalid description");
  if (!/Use (when|for|only)/.test(metadata.description)) fail(name, "description lacks trigger context");
  for (const marker of ["MANUAL MIGRATION REQUIRED", "source-command-", "CLAUDE.md", "mcp__codebase", "/understand-"]) {
    if (text.includes(marker)) fail(name, `contains forbidden marker ${marker}`);
  }
  if (/^\s*\/[a-z][a-z-]*(?:\s|$)/m.test(text)) fail(name, "contains Claude slash-command invocation syntax");
  if (name === "sync-upstream" && /git -C csharp-sdk (?:pull|fetch|checkout)/.test(text)) fail(name, "can mutate the read-only upstream clone");
  for (const phrase of requiredText) {
    if (!text.includes(phrase)) fail(name, `missing contract phrase ${phrase}`);
  }
}

if (errors.length > 0) {
  console.error(`Skill validation failed with ${errors.length} error(s):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log(`Skill validation passed: ${expectedNames.length} skills, no unresolved migration markers.`);
