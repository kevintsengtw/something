#!/usr/bin/env node

import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { pathToFileURL } from "node:url";

const REQUIRED_GRAPH_KEYS = ["version", "kind", "project", "nodes", "edges", "layers", "tour"];
const REQUIRED_NODE_KEYS = ["id", "type", "name", "summary", "tags", "complexity"];
const INFRA_FILES = new Set(["index.md", "log.md", "claude.md", "agents.md", "soul.md"]);

function parseArguments(argv) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    if (!argument.startsWith("--")) throw new Error(`Unexpected argument: ${argument}`);
    const key = argument.slice(2);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for --${key}`);
    options[key] = value;
    index += 1;
  }
  if (!options["graph-dir"] || !options.wiki) {
    throw new Error("--graph-dir and --wiki are required");
  }
  return options;
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function listMarkdown(directory) {
  const files = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.name === ".understand-anything") continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...listMarkdown(fullPath));
    else if (entry.name.toLowerCase().endsWith(".md")) files.push(fullPath);
  }
  return files.sort((left, right) => left.localeCompare(right, "en"));
}

function expectedArticleIds(wikiDirectory) {
  return listMarkdown(wikiDirectory).filter((file) => {
    const relative = path.relative(wikiDirectory, file);
    return path.dirname(relative) !== "." || !INFRA_FILES.has(path.basename(relative).toLowerCase());
  }).map((file) => `article:${path.relative(wikiDirectory, file).split(path.sep).join("/").replace(/\.md$/i, "")}`);
}

function countBy(items, key) {
  const counts = {};
  for (const item of items) counts[item[key]] = (counts[item[key]] ?? 0) + 1;
  return counts;
}

function gitOutput(argumentsList, cwd) {
  try {
    return execFileSync("git", argumentsList, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
  } catch {
    return "";
  }
}

function edgeKey(edge) {
  return `${edge.source}\0${edge.target}\0${edge.type}`;
}

function reportPath(target, repositoryRoot) {
  const absolute = path.resolve(target);
  const relative = path.relative(repositoryRoot, absolute);
  if (relative && relative !== ".." && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative)) {
    return relative.split(path.sep).join("/");
  }
  return absolute;
}

function compareBaseline(current, baseline) {
  const currentNodes = new Set(current.nodes.map((node) => node.id));
  const baselineNodes = new Set(baseline.nodes.map((node) => node.id));
  const lostByType = {};
  const addedByType = {};
  for (const type of ["article", "entity", "claim", "topic"]) {
    lostByType[type] = baseline.nodes.filter((node) => node.type === type && !currentNodes.has(node.id)).map((node) => node.id);
    addedByType[type] = current.nodes.filter((node) => node.type === type && !baselineNodes.has(node.id)).map((node) => node.id);
  }
  const currentEdges = new Set(current.edges.map(edgeKey));
  const lostSemanticEdges = baseline.edges
    .filter((edge) => edge.type !== "categorized_under")
    .filter((edge) => !currentEdges.has(edgeKey(edge)))
    .map((edge) => ({ source: edge.source, target: edge.target, type: edge.type }));
  return { lostByType, addedByType, lostSemanticEdges };
}

export function validateKnowledgeGraph({ graphDirectory, wikiDirectory, augmentationFile, baselineFile, repositoryRoot = process.cwd() }) {
  const errors = [];
  const warnings = [];
  const graphFile = path.join(graphDirectory, "knowledge-graph.json");
  const metaFile = path.join(graphDirectory, "meta.json");
  if (!fs.existsSync(graphFile)) errors.push(`Missing graph file: ${graphFile}`);
  if (!fs.existsSync(metaFile)) errors.push(`Missing meta file: ${metaFile}`);
  if (errors.length > 0) return { ok: false, errors, warnings };

  let graph;
  let meta;
  try {
    graph = readJson(graphFile);
    meta = readJson(metaFile);
  } catch (error) {
    return { ok: false, errors: [`Invalid JSON: ${error.message}`], warnings };
  }

  for (const key of REQUIRED_GRAPH_KEYS) if (!(key in graph)) errors.push(`Graph missing top-level key: ${key}`);
  if (graph.version !== "1.0.0") errors.push(`Unsupported graph version: ${graph.version}`);
  if (graph.kind !== "knowledge") errors.push(`Graph kind must be knowledge, found ${graph.kind}`);
  for (const key of ["nodes", "edges", "layers", "tour"]) if (!Array.isArray(graph[key])) errors.push(`${key} must be an array`);
  if (errors.length > 0) return { ok: false, errors, warnings };

  const nodeIds = new Set();
  for (const node of graph.nodes) {
    for (const key of REQUIRED_NODE_KEYS) if (!(key in node)) errors.push(`Node ${node.id ?? "<unknown>"} missing ${key}`);
    if (nodeIds.has(node.id)) errors.push(`Duplicate node id: ${node.id}`);
    nodeIds.add(node.id);
    if (!Array.isArray(node.tags)) errors.push(`Node ${node.id} tags must be an array`);
    if (node.type === "article" && (!node.filePath || !node.knowledgeMeta?.content || !Array.isArray(node.knowledgeMeta?.wikilinks))) {
      errors.push(`Article node ${node.id} is missing filePath or knowledgeMeta`);
    }
  }

  const edgeIds = new Set();
  const degree = new Map(graph.nodes.map((node) => [node.id, 0]));
  for (const edge of graph.edges) {
    if (!nodeIds.has(edge.source)) errors.push(`Dangling edge source: ${edge.source}`);
    if (!nodeIds.has(edge.target)) errors.push(`Dangling edge target: ${edge.target}`);
    const key = edgeKey(edge);
    if (edgeIds.has(key)) errors.push(`Duplicate edge: ${edge.source} -> ${edge.target} (${edge.type})`);
    edgeIds.add(key);
    degree.set(edge.source, (degree.get(edge.source) ?? 0) + 1);
    degree.set(edge.target, (degree.get(edge.target) ?? 0) + 1);
  }

  const layerIds = new Set();
  const layerCoverage = new Map(graph.nodes.map((node) => [node.id, 0]));
  for (const layer of graph.layers) {
    if (!layer.id || !layer.name || !Array.isArray(layer.nodeIds)) errors.push(`Invalid layer: ${JSON.stringify(layer)}`);
    if (layerIds.has(layer.id)) errors.push(`Duplicate layer id: ${layer.id}`);
    layerIds.add(layer.id);
    for (const nodeId of layer.nodeIds ?? []) {
      if (!nodeIds.has(nodeId)) errors.push(`Layer ${layer.id} references missing node ${nodeId}`);
      layerCoverage.set(nodeId, (layerCoverage.get(nodeId) ?? 0) + 1);
    }
  }
  for (const [nodeId, coverage] of layerCoverage) if (coverage === 0) errors.push(`Node is not assigned to a layer: ${nodeId}`);

  const tourOrders = new Set();
  for (const step of graph.tour) {
    if (!Number.isInteger(step.order) || !step.title || !Array.isArray(step.nodeIds)) errors.push(`Invalid tour step: ${JSON.stringify(step)}`);
    if (tourOrders.has(step.order)) errors.push(`Duplicate tour order: ${step.order}`);
    tourOrders.add(step.order);
    for (const nodeId of step.nodeIds ?? []) if (!nodeIds.has(nodeId)) errors.push(`Tour step ${step.order} references missing node ${nodeId}`);
  }

  const expectedArticles = expectedArticleIds(path.resolve(wikiDirectory));
  const actualArticles = graph.nodes.filter((node) => node.type === "article").map((node) => node.id);
  for (const articleId of expectedArticles) if (!actualArticles.includes(articleId)) errors.push(`Missing article node for wiki file: ${articleId}`);
  for (const articleId of actualArticles) if (!expectedArticles.includes(articleId)) errors.push(`Article node has no wiki file: ${articleId}`);
  if (meta.analyzedFiles !== expectedArticles.length) errors.push(`meta.analyzedFiles is ${meta.analyzedFiles}; expected ${expectedArticles.length}`);

  const upstreamCommit = gitOutput(["-C", path.join(repositoryRoot, "csharp-sdk"), "rev-parse", "HEAD"], repositoryRoot);
  if (!upstreamCommit) errors.push("Unable to determine csharp-sdk commit");
  if (graph.project?.gitCommitHash !== upstreamCommit) errors.push(`graph project commit ${graph.project?.gitCommitHash} does not match ${upstreamCommit}`);
  if (meta.gitCommitHash !== upstreamCommit) errors.push(`meta commit ${meta.gitCommitHash} does not match ${upstreamCommit}`);
  if (graph.project?.analyzedAt !== meta.lastAnalyzedAt) errors.push("Graph and meta timestamps differ");
  if (Number.isNaN(Date.parse(meta.lastAnalyzedAt))) errors.push(`Invalid meta timestamp: ${meta.lastAnalyzedAt}`);
  if (graph.project?.generator?.mode !== "deterministic+curated-augmentations") errors.push("Graph generator mode is not deterministic+curated-augmentations");

  let augmentation = null;
  if (augmentationFile) {
    try {
      augmentation = readJson(augmentationFile);
      if (!Array.isArray(augmentation.nodes) || !Array.isArray(augmentation.edges) || typeof augmentation.bindings !== "object") {
        throw new Error("augmentation must contain nodes, edges, and bindings");
      }
      const augmentationIds = new Set(augmentation.nodes.map((node) => node.id));
      for (const nodeId of augmentationIds) if (!nodeIds.has(nodeId)) errors.push(`Missing augmentation node: ${nodeId}`);
      for (const [nodeId, articleId] of Object.entries(augmentation.bindings ?? {})) {
        if (!augmentationIds.has(nodeId)) errors.push(`Binding references unknown augmentation node: ${nodeId}`);
        if (!nodeIds.has(articleId)) errors.push(`Binding references missing article: ${nodeId} -> ${articleId}`);
      }
    } catch (error) {
      errors.push(`Invalid augmentation file ${augmentationFile}: ${error.message}`);
    }
  }

  let baseline = null;
  let baselineDiff = null;
  if (baselineFile) {
    try {
      baseline = readJson(baselineFile);
      baselineDiff = compareBaseline(graph, baseline);
      for (const type of ["article", "entity", "claim"]) {
        if (baselineDiff.lostByType[type].length > 0) errors.push(`Lost baseline ${type} nodes: ${baselineDiff.lostByType[type].join(", ")}`);
      }
      if (baselineDiff.lostSemanticEdges.length > 0) {
        errors.push(`Lost ${baselineDiff.lostSemanticEdges.length} baseline semantic edge(s)`);
      }
      if (baselineDiff.lostByType.topic.length > 0) warnings.push(`Replaced baseline topic nodes: ${baselineDiff.lostByType.topic.join(", ")}`);
    } catch (error) {
      errors.push(`Invalid baseline file ${baselineFile}: ${error.message}`);
    }
  }

  const orphanNodes = [...degree].filter(([, count]) => count === 0).map(([nodeId]) => nodeId);
  const orphanConcepts = orphanNodes.filter((nodeId) => nodeId.startsWith("article:concepts/"));
  if (orphanConcepts.length > 0) errors.push(`Orphan concept articles: ${orphanConcepts.join(", ")}`);
  if (orphanNodes.length > 0) errors.push(`Orphan graph nodes: ${orphanNodes.join(", ")}`);

  const report = {
    ok: errors.length === 0,
    graphDirectory: reportPath(graphDirectory, repositoryRoot),
    sourceCommit: upstreamCommit,
    counts: {
      nodes: graph.nodes.length,
      edges: graph.edges.length,
      layers: graph.layers.length,
      tourSteps: graph.tour.length,
      nodeTypes: countBy(graph.nodes, "type"),
      edgeTypes: countBy(graph.edges, "type"),
      articles: actualArticles.length,
      augmentationNodes: augmentation?.nodes.length ?? 0,
    },
    orphanNodes,
    orphanConcepts,
    baselineDiff,
    errors,
    warnings,
  };
  return report;
}

function main() {
  try {
    const options = parseArguments(process.argv.slice(2));
    const report = validateKnowledgeGraph({
      graphDirectory: path.resolve(options["graph-dir"]),
      wikiDirectory: path.resolve(options.wiki),
      augmentationFile: options.augmentations ? path.resolve(options.augmentations) : null,
      baselineFile: options.baseline ? path.resolve(options.baseline) : null,
      repositoryRoot: process.cwd(),
    });
    if (options.report) fs.writeFileSync(path.resolve(options.report), `${JSON.stringify(report, null, 2)}\n`);
    console.log(JSON.stringify(report, null, 2));
    if (!report.ok) process.exitCode = 1;
  } catch (error) {
    console.error(`Knowledge graph validation failed: ${error.message}`);
    process.exitCode = 1;
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) main();
