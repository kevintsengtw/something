#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { pathToFileURL } from "node:url";
import { validateKnowledgeGraph } from "./validate-knowledge-graph.mjs";

function parseArguments(argv) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    if (argument === "--confirm-publish") {
      options.confirm = true;
      continue;
    }
    if (!argument.startsWith("--")) throw new Error(`Unexpected argument: ${argument}`);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for ${argument}`);
    options[argument.slice(2)] = value;
    index += 1;
  }
  if (!options.from || !options.to || !options.wiki || !options.augmentations || !options.baseline || !options.confirm) {
    throw new Error("Required: --from --to --wiki --augmentations --baseline --confirm-publish");
  }
  return options;
}

export function safePublish({ sourceDirectory, targetDirectory }) {
  const filenames = ["knowledge-graph.json", "meta.json"];
  const transactionId = `${process.pid}-${Date.now()}`;
  const backups = [];
  const staged = [];
  try {
    fs.mkdirSync(targetDirectory, { recursive: true });
    for (const filename of filenames) {
      const source = path.join(sourceDirectory, filename);
      const target = path.join(targetDirectory, filename);
      const next = path.join(targetDirectory, `.${filename}.next-${transactionId}`);
      const backup = path.join(targetDirectory, `.${filename}.backup-${transactionId}`);
      fs.copyFileSync(source, next);
      staged.push(next);
      if (fs.existsSync(target)) {
        fs.renameSync(target, backup);
        backups.push({ target, backup });
      }
      fs.renameSync(next, target);
    }
    for (const { backup } of backups) fs.rmSync(backup, { force: true });
  } catch (error) {
    for (const next of staged) fs.rmSync(next, { force: true });
    for (const { target, backup } of backups.reverse()) {
      if (fs.existsSync(target)) fs.rmSync(target, { force: true });
      if (fs.existsSync(backup)) fs.renameSync(backup, target);
    }
    throw error;
  }
}

function main() {
  try {
    const options = parseArguments(process.argv.slice(2));
    const sourceDirectory = path.resolve(options.from);
    const targetDirectory = path.resolve(options.to);
    if (sourceDirectory === targetDirectory) throw new Error("Source and target directories must differ");
    const report = validateKnowledgeGraph({
      graphDirectory: sourceDirectory,
      wikiDirectory: path.resolve(options.wiki),
      augmentationFile: path.resolve(options.augmentations),
      baselineFile: path.resolve(options.baseline),
      repositoryRoot: process.cwd(),
    });
    if (!report.ok) throw new Error(`Staging validation failed:\n${report.errors.join("\n")}`);
    safePublish({ sourceDirectory, targetDirectory });
    console.log(`Published validated knowledge graph: ${report.counts.nodes} nodes / ${report.counts.edges} edges -> ${targetDirectory}`);
  } catch (error) {
    console.error(`Knowledge graph publish failed: ${error.message}`);
    process.exitCode = 1;
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) main();
