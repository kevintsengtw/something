#!/usr/bin/env node

import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { pathToFileURL } from "node:url";

const GRAPH_VERSION = "1.0.0";
const GENERATOR_NAME = "mcp-csharp-sdk-tutorial/codex-native-knowledge-graph";
const GENERATOR_VERSION = "1.0.0";
const INFRA_FILES = new Set(["index.md", "log.md", "claude.md", "agents.md", "soul.md"]);
const WIKILINK_PATTERN = /\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/g;

function usage() {
  console.error("Usage: node scripts/build-knowledge-graph.mjs --wiki <wiki-dir> --output <output-dir> [--augmentations <file>] [--timestamp <ISO>] [--source-commit <hash>]");
}

function parseArguments(argv) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    if (!argument.startsWith("--")) throw new Error(`Unexpected argument: ${argument}`);
    const key = argument.slice(2);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for --${key}`);
    options[key] = value;
    index += 1;
  }
  if (!options.wiki || !options.output) {
    usage();
    throw new Error("--wiki and --output are required");
  }
  return options;
}

function listFiles(directory, predicate) {
  const files = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.name === ".understand-anything") continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...listFiles(fullPath, predicate));
    else if (predicate(fullPath)) files.push(fullPath);
  }
  return files.sort((left, right) => left.localeCompare(right, "en"));
}

function parseScalar(value) {
  const trimmed = value.trim();
  if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
    return trimmed.slice(1, -1);
  }
  if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
    const content = trimmed.slice(1, -1).trim();
    return content ? content.split(",").map((item) => parseScalar(item)) : [];
  }
  if (trimmed === "true") return true;
  if (trimmed === "false") return false;
  return trimmed;
}

function parseFrontmatter(text) {
  const match = text.match(/^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);
  if (!match) return {};
  const result = {};
  let listKey = null;
  for (const rawLine of match[1].split(/\r?\n/)) {
    const listItem = rawLine.match(/^\s+-\s+(.+)$/);
    if (listItem && listKey) {
      result[listKey].push(parseScalar(listItem[1]));
      continue;
    }
    const item = rawLine.match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
    if (!item) {
      listKey = null;
      continue;
    }
    const [, key, value] = item;
    if (value === "") {
      result[key] = [];
      listKey = key;
    } else {
      result[key] = parseScalar(value);
      listKey = null;
    }
  }
  return result;
}

function stripFencedAndInlineCode(text) {
  const lines = text.split(/\r?\n/);
  let inFence = false;
  const withoutFences = lines.map((line) => {
    if (/^\s*```/.test(line)) {
      inFence = !inFence;
      return "";
    }
    return inFence ? "" : line;
  }).join("\n");
  return withoutFences.replace(/`[^`\n]*`/g, "");
}

function extractWikilinks(text) {
  const links = [];
  const searchable = stripFencedAndInlineCode(text);
  for (const match of searchable.matchAll(WIKILINK_PATTERN)) {
    links.push({ target: match[1].trim(), display: match[2]?.trim() ?? null });
  }
  return links;
}

function extractHeadings(text) {
  return [...stripFencedAndInlineCode(text).matchAll(/^(#{1,6})\s+(.+)$/gm)].map((match) => ({
    level: match[1].length,
    text: match[2].trim(),
  }));
}

function extractCodeLanguages(text) {
  return [...text.matchAll(/^\s*```([^\s`]*)/gm)].map((match) => match[1]).filter(Boolean);
}

function extractTitle(text, frontmatter, fallback) {
  if (typeof frontmatter.title === "string" && frontmatter.title) return frontmatter.title;
  const match = text.match(/^#\s+(.+)$/m);
  return match ? match[1].trim() : fallback;
}

function extractSummary(text) {
  const withoutFrontmatter = text.replace(/^---\r?\n[\s\S]*?\r?\n---(?:\r?\n|$)/, "");
  const lines = stripFencedAndInlineCode(withoutFrontmatter).split(/\r?\n/);
  const paragraph = [];
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line && paragraph.length > 0) break;
    if (!line || line.startsWith("#") || line.startsWith(">") || /^[-*_]{3,}$/.test(line)) continue;
    paragraph.push(line);
  }
  const summary = paragraph.join(" ");
  return summary.length > 200 ? `${summary.slice(0, 197)}...` : summary;
}

function normalizeTags(tags) {
  if (Array.isArray(tags)) return tags.map(String).map((tag) => tag.trim()).filter(Boolean);
  if (typeof tags === "string" && tags) return [tags];
  return [];
}

function relativeStem(file, wikiDirectory) {
  return path.relative(wikiDirectory, file).split(path.sep).join("/").replace(/\.md$/i, "");
}

function isArticle(file, wikiDirectory) {
  const relative = path.relative(wikiDirectory, file);
  return path.dirname(relative) !== "." || !INFRA_FILES.has(path.basename(relative).toLowerCase());
}

function buildNameMap(articleFiles, wikiDirectory) {
  const names = new Map();
  const basenameCounts = new Map();
  for (const file of articleFiles) {
    const stem = relativeStem(file, wikiDirectory);
    const basename = path.posix.basename(stem).toLowerCase();
    names.set(stem.toLowerCase(), stem);
    basenameCounts.set(basename, (basenameCounts.get(basename) ?? 0) + 1);
    names.set(basename, stem);
  }
  for (const [basename, count] of basenameCounts) {
    if (count > 1) names.delete(basename);
  }
  return names;
}

function normalizeLinkTarget(target) {
  return target.trim().replace(/^\.\//, "").replace(/\.md$/i, "").split("#")[0].toLowerCase();
}

function resolveArticleId(target, nameMap) {
  const key = normalizeLinkTarget(target);
  if (!key || key.startsWith("-")) return null;
  const exact = nameMap.get(key);
  if (exact) return `article:${exact}`;
  const matches = [...nameMap.entries()].filter(([stored]) => stored.endsWith(`/${key}`)).map(([, stem]) => stem);
  return matches.length === 1 ? `article:${matches[0]}` : null;
}

function findIndexFile(wikiDirectory) {
  const match = fs.readdirSync(wikiDirectory).find((name) => name.toLowerCase() === "index.md");
  if (!match) throw new Error(`Missing INDEX.md in ${wikiDirectory}`);
  return path.join(wikiDirectory, match);
}

function parseIndex(indexFile, nameMap) {
  const text = fs.readFileSync(indexFile, "utf8");
  const categories = [];
  let current = null;
  for (const line of text.split(/\r?\n/)) {
    const heading = line.match(/^##\s+(.+)$/);
    if (heading) {
      current = { name: heading[1].trim(), articleIds: [] };
      categories.push(current);
      continue;
    }
    if (!current) continue;
    for (const match of line.matchAll(WIKILINK_PATTERN)) {
      const articleId = resolveArticleId(match[1], nameMap);
      if (articleId && !current.articleIds.includes(articleId)) current.articleIds.push(articleId);
    }
  }
  return { text, categories };
}

function categorySlug(name) {
  return name.toLowerCase().trim().replace(/\s+/g, "-");
}

function deduplicateEdges(edges) {
  const seen = new Set();
  return edges.filter((edge) => {
    const key = `${edge.source}\0${edge.target}\0${edge.type}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function gitOutput(argumentsList, cwd) {
  try {
    return execFileSync("git", argumentsList, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
  } catch {
    return "";
  }
}

function loadAugmentations(file) {
  if (!file) return { nodes: [], edges: [], bindings: {} };
  const augmentation = readJson(file);
  if (augmentation.version !== GRAPH_VERSION) throw new Error(`Unsupported augmentation version: ${augmentation.version}`);
  if (!Array.isArray(augmentation.nodes) || !Array.isArray(augmentation.edges) || typeof augmentation.bindings !== "object") {
    throw new Error("Augmentation file must contain nodes, edges, and bindings");
  }
  return augmentation;
}

function findBinding(nodeId, bindings, articleIds, edges) {
  const explicit = bindings[nodeId];
  if (explicit && articleIds.has(explicit)) return explicit;
  const connected = edges.find((edge) => edge.source === nodeId && articleIds.has(edge.target))?.target
    ?? edges.find((edge) => edge.target === nodeId && articleIds.has(edge.source))?.source;
  if (connected) return connected;
  const parts = nodeId.split(":");
  if (parts[0] === "claim" && parts[1]) {
    return [...articleIds].find((articleId) => articleId.endsWith(`/${parts[1]}`) || articleId === `article:${parts[1]}`) ?? null;
  }
  return null;
}

export function buildKnowledgeGraph({ wikiDirectory, outputDirectory, augmentationFile, timestamp, sourceCommit, repositoryRoot = process.cwd() }) {
  const wikiRoot = path.resolve(wikiDirectory);
  const outputRoot = path.resolve(outputDirectory);
  if (!fs.statSync(wikiRoot).isDirectory()) throw new Error(`Wiki directory does not exist: ${wikiRoot}`);

  const markdownFiles = listFiles(wikiRoot, (file) => file.toLowerCase().endsWith(".md"));
  const articleFiles = markdownFiles.filter((file) => isArticle(file, wikiRoot));
  const nameMap = buildNameMap(articleFiles, wikiRoot);
  const articleIds = new Set(articleFiles.map((file) => `article:${relativeStem(file, wikiRoot)}`));
  const indexFile = findIndexFile(wikiRoot);
  const { text: indexText, categories: parsedCategories } = parseIndex(indexFile, nameMap);
  const categories = parsedCategories.filter((category) => category.articleIds.length > 0);
  const categoryByArticle = new Map();
  for (const category of categories) {
    for (const articleId of category.articleIds) {
      const articleCategories = categoryByArticle.get(articleId) ?? [];
      articleCategories.push(category.name);
      categoryByArticle.set(articleId, articleCategories);
    }
  }

  const nodes = [];
  const edges = [];
  const unresolvedWikilinks = [];
  const articleById = new Map();

  for (const file of articleFiles) {
    const content = fs.readFileSync(file, "utf8");
    const stem = relativeStem(file, wikiRoot);
    const id = `article:${stem}`;
    const frontmatter = parseFrontmatter(content);
    const wikilinks = extractWikilinks(content);
    const articleCategories = categoryByArticle.get(id) ?? [];
    const node = {
      id,
      type: "article",
      name: extractTitle(content, frontmatter, path.posix.basename(stem)),
      filePath: `${stem}.md`,
      summary: extractSummary(content),
      tags: normalizeTags(frontmatter.tags),
      complexity: "simple",
      knowledgeMeta: {
        wikilinks: wikilinks.map((link) => link.target),
        category: articleCategories[0] ?? "Other",
        categories: articleCategories.length > 0 ? articleCategories : ["Other"],
        headings: extractHeadings(content),
        codeLanguages: [...new Set(extractCodeLanguages(content))],
        frontmatter,
        content,
        backlinks: [],
      },
    };
    nodes.push(node);
    articleById.set(id, node);
    for (const wikilink of wikilinks) {
      const targetId = resolveArticleId(wikilink.target, nameMap);
      if (!targetId) {
        unresolvedWikilinks.push({ source: id, target: wikilink.target });
        continue;
      }
      if (targetId !== id) edges.push({ source: id, target: targetId, type: "related", direction: "forward", weight: 0.7 });
    }
  }

  const topicIds = new Map();
  for (const category of categories) {
    const slug = categorySlug(category.name);
    const topicId = `topic:${slug}`;
    topicIds.set(category.name, topicId);
    nodes.push({
      id: topicId,
      type: "topic",
      name: category.name,
      summary: `Category from INDEX.md: ${category.name} (${category.articleIds.length} articles)`,
      tags: ["category"],
      complexity: "simple",
    });
    for (const articleId of category.articleIds) {
      edges.push({ source: articleId, target: topicId, type: "categorized_under", direction: "forward", weight: 0.6 });
    }
  }

  const uncategorizedArticles = [...articleIds].filter((articleId) => !categoryByArticle.has(articleId));
  if (uncategorizedArticles.length > 0) {
    const topicId = "topic:other";
    topicIds.set("Other", topicId);
    nodes.push({
      id: topicId,
      type: "topic",
      name: "Other",
      summary: `Wiki infrastructure and uncategorized articles (${uncategorizedArticles.length} articles)`,
      tags: ["category", "infrastructure"],
      complexity: "simple",
    });
    for (const articleId of uncategorizedArticles) {
      edges.push({ source: articleId, target: topicId, type: "categorized_under", direction: "forward", weight: 0.6 });
    }
  }

  const augmentation = loadAugmentations(augmentationFile ? path.resolve(augmentationFile) : null);
  const nodeIds = new Set(nodes.map((node) => node.id));
  for (const originalNode of augmentation.nodes) {
    if (nodeIds.has(originalNode.id)) throw new Error(`Duplicate augmentation node: ${originalNode.id}`);
    if (!["entity", "claim"].includes(originalNode.type)) throw new Error(`Unsupported augmentation node type ${originalNode.type}: ${originalNode.id}`);
    const node = structuredClone(originalNode);
    nodes.push(node);
    nodeIds.add(node.id);
  }
  for (const edge of augmentation.edges) {
    if (!nodeIds.has(edge.source) || !nodeIds.has(edge.target)) {
      throw new Error(`Augmentation edge has dangling reference: ${edge.source} -> ${edge.target}`);
    }
    edges.push(structuredClone(edge));
  }

  const bindingByAugmentation = new Map();
  for (const node of augmentation.nodes) {
    const binding = findBinding(node.id, augmentation.bindings, articleIds, augmentation.edges);
    if (!binding) throw new Error(`Augmentation node has no article binding: ${node.id}`);
    bindingByAugmentation.set(node.id, binding);
  }

  let finalEdges = deduplicateEdges(edges);
  const degree = new Map(nodes.map((node) => [node.id, 0]));
  for (const edge of finalEdges) {
    degree.set(edge.source, (degree.get(edge.source) ?? 0) + 1);
    degree.set(edge.target, (degree.get(edge.target) ?? 0) + 1);
  }
  for (const [nodeId, articleId] of bindingByAugmentation) {
    if ((degree.get(nodeId) ?? 0) === 0) {
      finalEdges.push({ source: articleId, target: nodeId, type: "documents", direction: "forward", weight: 0.8 });
    }
  }
  finalEdges = deduplicateEdges(finalEdges);

  const backlinks = new Map([...articleIds].map((articleId) => [articleId, []]));
  for (const edge of finalEdges) {
    if (edge.type === "related" && articleIds.has(edge.source) && articleIds.has(edge.target)) {
      backlinks.get(edge.target).push(edge.source);
    }
  }
  for (const [articleId, sources] of backlinks) articleById.get(articleId).knowledgeMeta.backlinks = [...new Set(sources)];

  const layers = [];
  const layerByCategory = new Map();
  for (const category of categories) {
    const layerId = `layer:${categorySlug(category.name)}`;
    const nodeIdsForLayer = [...category.articleIds, topicIds.get(category.name)];
    layerByCategory.set(category.name, { id: layerId, nodeIds: nodeIdsForLayer });
    layers.push({
      id: layerId,
      name: category.name,
      description: `${category.name} (${nodeIdsForLayer.length} nodes)`,
      nodeIds: nodeIdsForLayer,
    });
  }
  if (topicIds.has("Other")) {
    const nodeIdsForLayer = [...uncategorizedArticles, topicIds.get("Other")];
    layerByCategory.set("Other", { id: "layer:other", nodeIds: nodeIdsForLayer });
    layers.push({ id: "layer:other", name: "Other", description: `Uncategorized nodes (${nodeIdsForLayer.length})`, nodeIds: nodeIdsForLayer });
  }

  for (const [nodeId, articleId] of bindingByAugmentation) {
    const category = articleById.get(articleId).knowledgeMeta.category;
    const layer = layerByCategory.get(category) ?? layerByCategory.get("Other");
    if (!layer) throw new Error(`No layer for augmentation node ${nodeId}`);
    if (!layer.nodeIds.includes(nodeId)) layer.nodeIds.push(nodeId);
  }
  for (const layer of layers) layer.description = `${layer.name} (${layer.nodeIds.length} nodes)`;

  const tour = categories.map((category, index) => ({
    order: index + 1,
    title: category.name,
    description: `Explore the ${category.name} section (${category.articleIds.length} articles)`,
    nodeIds: category.articleIds.slice(0, 3),
  }));

  const indexFrontmatter = parseFrontmatter(indexText);
  const projectName = extractTitle(indexText, indexFrontmatter, path.basename(wikiRoot));
  const analyzedAt = timestamp ?? new Date().toISOString();
  if (Number.isNaN(Date.parse(analyzedAt))) throw new Error(`Invalid timestamp: ${analyzedAt}`);
  const upstreamCommit = sourceCommit
    ?? gitOutput(["-C", path.join(repositoryRoot, "csharp-sdk"), "rev-parse", "HEAD"], repositoryRoot);
  if (!upstreamCommit) throw new Error("Unable to determine upstream source commit; pass --source-commit");

  const graph = {
    version: GRAPH_VERSION,
    kind: "knowledge",
    project: {
      name: projectName,
      languages: ["markdown"],
      frameworks: ["karpathy-wiki", "codex-native"],
      description: `Knowledge graph for ${projectName}`,
      analyzedAt,
      gitCommitHash: upstreamCommit,
      generator: { name: GENERATOR_NAME, version: GENERATOR_VERSION, mode: "deterministic+curated-augmentations" },
    },
    nodes,
    edges: finalEdges,
    layers,
    tour,
  };
  const meta = {
    lastAnalyzedAt: analyzedAt,
    gitCommitHash: upstreamCommit,
    version: GRAPH_VERSION,
    analyzedFiles: articleFiles.length,
    generator: { name: GENERATOR_NAME, version: GENERATOR_VERSION, mode: "deterministic+curated-augmentations" },
  };

  fs.mkdirSync(outputRoot, { recursive: true });
  fs.writeFileSync(path.join(outputRoot, "knowledge-graph.json"), `${JSON.stringify(graph, null, 2)}\n`);
  fs.writeFileSync(path.join(outputRoot, "meta.json"), `${JSON.stringify(meta, null, 2)}\n`);

  const summary = {
    outputDirectory: outputRoot,
    articles: articleFiles.length,
    topics: nodes.filter((node) => node.type === "topic").length,
    entities: nodes.filter((node) => node.type === "entity").length,
    claims: nodes.filter((node) => node.type === "claim").length,
    nodes: nodes.length,
    edges: finalEdges.length,
    layers: layers.length,
    tourSteps: tour.length,
    unresolvedWikilinks,
    sourceCommit: upstreamCommit,
  };
  return { graph, meta, summary };
}

function main() {
  try {
    const options = parseArguments(process.argv.slice(2));
    const result = buildKnowledgeGraph({
      wikiDirectory: options.wiki,
      outputDirectory: options.output,
      augmentationFile: options.augmentations,
      timestamp: options.timestamp,
      sourceCommit: options["source-commit"],
      repositoryRoot: process.cwd(),
    });
    console.log(JSON.stringify(result.summary, null, 2));
    if (result.summary.unresolvedWikilinks.length > 0) process.exitCode = 2;
  } catch (error) {
    console.error(`Knowledge graph build failed: ${error.message}`);
    process.exitCode = 1;
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) main();
