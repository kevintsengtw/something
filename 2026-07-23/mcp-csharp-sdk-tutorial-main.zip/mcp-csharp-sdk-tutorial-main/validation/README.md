# 驗證入口

## Fast

每次文件、KB、skills 或 migration artifact 變更後執行：

```bash
node scripts/lint-docs.mjs
```

Fast profile 使用 Node.js 內建模組，檢查章節、附錄、reviews、TOC、相對連結、wiki-style 連結、code fences、concept frontmatter、sources、facts JSON、教學章節映射、發布狀態，以及正式 knowledge graph 的 schema、來源 commit、coverage、layers 與 orphan nodes。命令唯讀，exit code `0` 才算通過。

修改 repository skills 時另執行：

```bash
node scripts/validate-skills.mjs
```

Knowledge graph generator 或 publisher 變更時另執行：

```bash
node scripts/test-knowledge-graph.mjs
node scripts/validate-knowledge-graph.mjs \
  --graph-dir mcp-csharp-sdk-kb/wiki/.understand-anything \
  --wiki mcp-csharp-sdk-kb/wiki \
  --augmentations mcp-csharp-sdk-kb/wiki/graph-augmentations.json
```

重建與發布必須經 `$snapshot-knowledge`：先輸出至 repository 外 staging、執行 baseline diff 與 Dashboard smoke，最後才以 `scripts/publish-knowledge-graph.mjs --confirm-publish` 進行 rollback-safe 發布。

## Standard

修改教學中的可執行 C# 範例時，依對應 `mcp-csharp-sdk-guide/reviews/review-*.md` 重建並執行該章列明的 `dotnet build` 或 `dotnet test`。只跑受影響章節，不把無關 scratch project 納入 repository。

## Release

正式發布或修改相關章節時，除 Fast 與 Standard 外執行：

- ch18：OAuth/server-client wiring 與安全設定查驗。
- ch19：Docker build/run、health 與 MCP initialize/tools/list。
- ch20：對指定 RID 執行 Native AOT publish 與自測。

Release profile 依章節 review 記錄平台、RID、容器與已知限制；未執行重型測試時不得宣稱該 profile 通過。
