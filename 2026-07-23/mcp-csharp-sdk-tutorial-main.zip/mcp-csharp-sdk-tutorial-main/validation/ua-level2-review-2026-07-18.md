# UA Level 2 實作與審查記錄

## 結論

- 日期：2026-07-18
- 決策：G2 路徑 C，建立 Codex-native deterministic knowledge graph 流程
- 結果：✅ 通過；正式 snapshot 已安全發布，完整版本更新 Pipeline 不再受 UA 阻塞
- 上游基準：`csharp-sdk/` commit `2b7fd35fbe58dfb9f00eae8b3393e1a7361b5e01`

## 實作範圍

- `scripts/build-knowledge-graph.mjs`：由 wiki Markdown、frontmatter、INDEX 分類與 wikilinks 重建 article/topic 結構，再合併 reviewed augmentations。
- `mcp-csharp-sdk-kb/wiki/graph-augmentations.json`：保存舊有效快照的 39 個 entity、25 個 claim 與已審查語意邊，避免每次依賴 LLM 重新產生敘述。
- `scripts/validate-knowledge-graph.mjs`：驗證 schema、引用完整性、article/augmentation coverage、upstream commit、layers、tour、orphans 與 baseline semantic diff。
- `scripts/publish-knowledge-graph.mjs`：要求 `--confirm-publish`，先驗證 staging，再以可回復的雙檔 transaction 發布 graph/meta。
- `scripts/test-knowledge-graph.mjs`：驗證固定輸入可重現、dangling edge 會失敗、publisher 中途失敗會回復舊快照。

## 新舊快照審查

| 項目 | 舊快照 | 新快照 | 判定 |
| --- | ---: | ---: | --- |
| articles | 28 | 28 | 無遺失 |
| topics | 10 | 10 | 空分類 topic 改為 deterministic `Other` |
| entities | 39 | 39 | 無遺失 |
| claims | 25 | 25 | 無遺失 |
| nodes | 102 | 102 | 總數不變 |
| edges | 216 | 228 | 補齊 10 個孤立節點並保留全部既有語意邊 |
| layers | 11 | 10 | 移除空分類 layer；所有節點仍有 coverage |
| tour steps | 10 | 9 | 移除空分類 tour step |
| orphan nodes | 10 | 0 | 修正完成 |
| orphan concepts | 2 | 0 | 修正完成 |

舊 parser 會讓 INDEX 最後的「按教學章節反查」覆蓋文章 primary category；新 generator 以 INDEX 首次出現分類作 primary category，同時保留多分類 membership。舊 graph 的空 `project.gitCommitHash` 也已改為實際 upstream commit。

## 驗證證據

- 暫存重建：28 articles、10 topics、39 entities、25 claims，共 102 nodes、228 edges、10 layers、9 tour steps。
- Baseline diff：article/entity/claim 遺失數皆為 0；既有非分類語意邊遺失數為 0；orphan nodes/concepts 皆為 0。
- Reproducibility：固定 timestamp 的兩次 build 產生 byte-identical JSON。
- Failure tests：dangling edge 被 validator 拒絕；不完整 staging 觸發 publisher rollback，舊 graph/meta 保持完整。
- Dashboard：Understand-Anything 2.7.5 viewer 在 `127.0.0.1:4178` 成功顯示 10 layers 與新 graph，graph/meta fetch 正常，browser console 無 warning/error。
- 正式發布：graph SHA-256 `6965720b7a429f332001f9df5ee107da66f247e781c1addbb0c0df8e97c1a2d6`；meta SHA-256 `e0e605f8881ae58c23d884afee2ef4fe73079c2983f143cd8ef3417bb7b8a05f`。
- 機器可讀報告：[`./ua-level2-graph-validation.json`](./ua-level2-graph-validation.json)。

## 安全與限制

- 正式輸出不由 builder 直接寫入；必須經 staging、validator、人工 diff、Dashboard smoke 與明確發布確認。
- `graph-augmentations.json` 是敘述層 reviewed material，不取代 codebase-memory-mcp 或 upstream source。
- Understand-Anything plugin 不是執行期依賴；目前只保留相容 Dashboard viewer。若未來 schema/viewer 改版，先在 staging 做相容性測試。
- `.claude/`、`CLAUDE.md`、`.mcp.json` 與 `csharp-sdk/` 均未修改。
