# Codex Skill Smoke Test（2026-07-16）

## 測試基準

- Codex CLI：0.144.5
- repository skills：12
- upstream：`v1.4.1` / `2b7fd35fbe58dfb9f00eae8b3393e1a7361b5e01`
- 原則：寫入型測試在 `/tmp/mcp-csharp-sdk-tutorial-skill-fixture` 執行；高風險測試採 preview、缺參數停止或現有 fixture，不修改已審查正文。

## 結果

| # | Skill | 測試方式 | 結果 |
| --- | --- | --- | --- |
| 1 | `wiki-query` | 新唯讀 Codex session 以自然語言查詢 ch09，未明確指定 skill | 自動選用 `wiki-query`，正確回覆 `notifications-progress` 與 `logging-and-completion` |
| 2 | `lint-tutorial` | 執行 `node scripts/lint-docs.mjs` | exit 0；20 章、3 附錄、24 reviews、25 concepts 通過 |
| 3 | `draft-chapter` | fixture 中明確核准 `$draft-chapter testing-strategy 21` | 只建立 `outputs/draft-testing-strategy.md`；guide/reviews 無變更 |
| 4 | `draft-appendix` | fixture 中明確核准 `$draft-appendix samples-navigation D` | 只建立 `outputs/draft-appendix-samples-navigation.md`；guide/reviews 無變更 |
| 5 | `regenerate-toc` | fixture 比對精確 diff | 只指出 guide README 的附錄 C 顯示標題差異；正式修正後 lint 通過 |
| 6 | `save-qa` | fixture 同日同主題執行兩次 | 只建立/append QA session；既有內容與 frontmatter 保留 |
| 7 | `drift-check` | 檢查 current report schema、20 章+A/B/C 基準與 indexed commit | report 更新為 2026-07-16；guide、facts、raw、upstream 無寫入 |
| 8 | `extract-facts` | 缺版本安全停止；以現有 v1.4.0 facts 做 JSON/verified schema dry-run | 無寫入；facts 由 deterministic lint 成功解析 |
| 9 | `compile-knowledge` | preview 現有 facts → concepts 關聯，執行 frontmatter/source/index lint | 無非預期寫入；25 concepts 全數通過 |
| 10 | `sync-upstream` | preview HEAD/tag、remote 狀態與索引對齊 | upstream clean；skill 不執行 pull/fetch/checkout |
| 11 | `update-tutorial` | 缺 scope 安全停止；以 current 零 drift 報告驗證 no-op | 未修改 guide；Enhancement 預設不處理 |
| 12 | `snapshot-knowledge` | 解析既有 graph/meta，要求 refresh 時套用 G2 路徑 A | 回報 `deferred/unavailable`；兩個 JSON 未改動 |

## 共通契約審查

`node scripts/validate-skills.mjs` 驗證：

- 目錄與 frontmatter `name` 精確為 12 個穩定 skill 名稱。
- `description` 含觸發情境；缺版本/scope 的高風險 skill 會停止。
- 無 `MANUAL MIGRATION REQUIRED`、`source-command-*`、Claude slash-command invocation 或 Claude-only MCP/runtime 名稱。
- `sync-upstream` 不含會修改 `csharp-sdk/` checkout 的 pull/fetch/checkout 命令。
- 每個 skill 都明列 preview、寫入/唯讀邊界與完成驗證。

## 新 Session 與巢狀指引

- 從 `mcp-csharp-sdk-kb/` 啟動的新唯讀 session 自動發現 root 與 KB 指引，並正確重述 `raw/facts/` 規則。
- 從 `mcp-csharp-sdk-guide/` 啟動的新唯讀 session 正確重述 20 章+A/B/C 發佈基準、一般相對連結政策與 `node ../scripts/lint-docs.mjs`。
- 新 session 可發現全部 12 個 repository skills；明確與 implicit trigger 均已測試。

## G2 Dashboard Smoke

以本機 Understand-Anything 2.7.5 Dashboard 暫時啟動 `127.0.0.1:4177`，`GRAPH_DIR` 指向本 repository 的 wiki 目錄：

- 首頁載入成功。
- `/knowledge-graph.json` 可解析並含 `nodes`、`edges`、`project`。
- `/meta.json` 可解析且 `gitCommitHash` 對齊 upstream commit。
- 驗證後已停止 localhost server；未重建或覆寫 graph。

## MCP 互動式 Cutover Smoke

從 repository root 啟動全新 Codex 0.144.5 唯讀互動 session，直接使用 `codebase-memory-mcp` tools，未透過 shell 代查：

- `list_projects` 找到 root path 以 `/csharp-sdk` 結尾的動態 project，索引規模為 7,098 nodes / 23,419 edges。
- `search_graph` 找到 `McpClient.CreateAsync`，來源為 `csharp-sdk/src/ModelContextProtocol.Core/Client/McpClient.Methods.cs:40`。
- `get_code_snippet` 成功讀回該 method 節點與來源位置。
- Codex 0.144.5 以逐 tool approval UI 呈現與核准 MCP 呼叫；server 與 tools 可直接發現及執行。
