# Claude Code → Codex 完整轉移執行計畫與檢查清單

> 文件狀態：Level 2 轉移完成（2026-07-18）
> 建立日期：2026-07-16
> 適用工作區：`mcp-csharp-sdk-tutorial/`
> 目前內容基準：ModelContextProtocol v1.4.0；上游 clone 對齊 v1.4.1 (`2b7fd35fbe58dfb9f00eae8b3393e1a7361b5e01`)
> 移轉原則：先建立可回復基準，再建立 Codex 原生介面；Claude Code 來源檔在穩定期內保留、不覆寫、不刪除

---

## 1. 目的與完成定義

本計畫把目前由 Claude Code 建立與維護的 MCP C# SDK 繁中教學工作區，轉為可由 Codex 安全接手、重現驗證並持續維護的專案。

移轉分成兩個完成層級：

### Level 1：內容維護可接手

Codex 能正確載入專案規約、修改 guide/kb、執行確定性的文件 lint，且所有變更都有 Git 基準與回復點。

### Level 2：完整維運可接手

除 Level 1 外，Codex 還能執行完整版本更新 Pipeline：同步上游、重建 facts、編譯 wiki、更新知識圖譜、偵測 drift、修正教學並完成驗證。

### 全案完成條件

- [x] 根工作區是 Git repository，且有移轉前 baseline tag
- [x] Codex 能從根目錄及子目錄正確載入 `AGENTS.md`
- [x] 12 個 Claude commands 都有可用的 Codex skill，且無未處理的 migration warning
- [x] `codebase-memory-mcp` 已加入 Codex 專案設定、重新索引並通過七項探測
- [x] 文件 lint 已落成可執行、可重跑、零第三方祕密依賴的命令
- [x] Understand-Anything 已完成 Codex-native 重建、驗證與安全發布流程
- [x] Codex 新 session 完成端到端 smoke test
- [x] guide 仍維持 20 章、附錄 A/B/C、24 份 reviews，第二意見結案狀態未被改動
- [x] `csharp-sdk/` 保持唯讀且工作樹無變更
- [x] 移轉後 Git working tree clean

---

## 2. 不在本次移轉範圍

- 不撰寫附錄 D（Samples 導覽）或附錄 E（資源連結）
- 不升級 MCP C# SDK 基準版本
- 不改寫已通過第二意見審查的教學內容
- 不修改或刪除 `.claude/`、`CLAUDE.md`、`.mcp.json`
- 不修改 `csharp-sdk/` 上游原始碼
- 不在移轉過程加入新的 LLM/API provider
- 不把個人 API key、token 或本機絕對祕密寫入 repository

---

## 3. 現況盤點

### 3.1 內容基準

| 項目 | 現況 |
| --- | --- |
| 教學章節 | 20 章 |
| 已完成附錄 | A/B/C，共 3 份 |
| 第二輪附錄 | D/E，尚未撰寫 |
| reviews 文件 | 24 份 |
| wiki concepts | 25 份 |
| 第二意見 | 2026-07-16 已結案 |
| guide 狀態 | 具備發佈條件 |
| 上游 clone | `csharp-sdk/`，detached HEAD @ v1.4.1 |
| 根 Git repo | 已建立；baseline `0bf9214`，tag `tutorial-v1.4.0-reviewed-2026-07-16` |

### 3.2 Claude Code → Codex 來源面

| Claude Code 來源 | 數量 | Codex 目標 | 目前風險 |
| --- | ---: | --- | --- |
| 根 `CLAUDE.md` | 1 | 根 `AGENTS.md` | 內容含 Claude 專屬語意，不可直接無條件 symlink |
| `mcp-csharp-sdk-kb/CLAUDE.md` | 1 | `mcp-csharp-sdk-kb/AGENTS.md` | 自動移轉器未納入，且含過時 project name 規則 |
| `.claude/commands/*.md` | 12 | `.agents/skills/*/SKILL.md` | 移轉器 doctor 判定 12 項全部需人工檢視 |
| `.mcp.json` | 1 server | `.codex/config.toml` | 可自動轉換，但需 trust、restart、實際查詢驗證 |
| `.claude/settings.local.json` | 1 | 無直接等價 | Codex 以 trusted project config 控制 |
| Understand-Anything plugin | v2.7.5 | Codex skill/plugin 或替代流程 | 不會自動移轉 |
| Claude memory | 供應商內部狀態 | repository 文件 | 不可攜，需把關鍵決策落地 |
| Claude hooks/subagents | 0 | 無 | 本專案沒有待移轉項目 |

### 3.3 已知阻塞與矛盾

以下是 2026-07-16 啟動 Level 1 移轉時的盤點快照；各項已由後續 phases 處置，其中 UA 能力於 2026-07-18 完成 Level 2。

- 根 `README.md` 仍寫「骨架建立中」。
- `mcp-csharp-sdk-kb/README.md` 仍寫只有 5 個 stub。
- `mcp-csharp-sdk-kb/WORKFLOW-DESIGN-v1.md` 仍寫尚未完成首次驗證。
- `SETUP.md` 仍以 Claude Code 為唯一入口，且 project name 說明已過時。
- `mcp-csharp-sdk-kb/CLAUDE.md` 仍寫 project 參數固定為字面 `csharp-sdk`。
- `mcp-csharp-sdk-kb/UPSTREAM-REF.md` 仍聲稱 command files 假設字面 `csharp-sdk`，但目前 commands 已改用 placeholder。
- 本機已安裝 `codebase-memory-mcp 0.6.1`，但現有 cache 在 `index_status` 查詢時回報「not indexed」；接手前必須重建。
- 現有 `/lint` 是 agent prompt，不是 repository 內可單獨執行的 deterministic script。
- Understand-Anything 只安裝在 Claude plugin 路徑，Codex 尚無對應能力。

---

## 4. 移轉決策閘門

每個閘門必須留下決策、日期與決策者；未決定前不得進入相依階段。

### G0：Git repository 與 remote

建議：先建立本機 root repository 與 baseline tag；remote 可稍後設定，不阻塞 Codex 本機接手。

- [x] 決定 remote hosting：暫不設定，待本機移轉驗證完成後另案處理
- [x] 確認 repository 可包含 guide、kb、reviews 與 Codex 設定
- [x] 確認 `csharp-sdk/` 持續由 `.gitignore` 排除
- 決策：`先建立本機 root repository 與 baseline tag；remote 延後設定`
- 日期／決策者：`2026-07-16／Codex（依使用者授權執行）`

### G1：Claude/Codex 並存策略

建議：至少保留兩次完整維護循環的並存期；Codex 穩定後再決定是否封存 Claude 入口。

- [x] 並存：保留 `.claude/` 與 Codex artifacts
- [ ] Codex-only：完成 burn-in 後另案移除 Claude artifacts
- 決策：`採並存策略；本輪不修改或刪除 Claude Code 來源面`
- 日期／決策者：`2026-07-16／Codex（依移轉安全原則）`

### G2：Understand-Anything 策略

Level 1 曾採路徑 A 安全凍結；2026-07-18 依使用者要求啟動 Level 2，完成路徑 C。

- [x] A：凍結現有 graph，停用 snapshot skill，Level 1 先上線（2026-07-16 歷史階段）
- [ ] B：把必要 UA skills/scripts 移植到 Codex
- [x] C：建立新的 Codex-native knowledge graph 流程
- 決策：`採路徑 C；以 deterministic wiki graph + reviewed augmentations 取代 Claude runtime，UA 2.7.5 僅作相容 viewer`
- 日期／決策者：`2026-07-18／Codex（依使用者明確要求立即執行）`

### G3：驗證自動化深度

建議：先完成 Markdown/連結/frontmatter/索引 lint；程式碼 build/test、Docker、AOT 分為標準與重型 profile。

- [x] 文件 lint only
- [ ] 文件 lint + 章節程式碼 build/test harness
- [ ] 完整含 Docker/AOT 的發布驗證
- 決策：`本輪把 fast Markdown/連結/frontmatter/索引 lint 自動化；standard/release 依受影響章節與發布需求按 review 記錄執行，不在移轉中重跑全部重型測試`
- 日期／決策者：`2026-07-16／Codex（依本輪只移轉工作流、不改正文的範圍）`

---

## 5. 執行原則

1. 先建立 Git baseline，之後每個 phase 使用獨立 commit。
2. 不直接編輯 Claude Code 來源檔；Codex artifacts 另行建立。
3. 所有自動產生檔案都必須人工檢查，不以 migrator 成功作為可用證明。
4. 先跑 read-only、dry-run，再執行 write workflow。
5. MCP 結構性查證與 LLM 敘述層維持分離。
6. 任何會覆寫 guide/kb 的 skill 都必須支援明確 scope 與 dry-run。
7. `csharp-sdk/` 永遠視為唯讀基準層。
8. 每個 phase 完成後填寫證據表並保持 working tree clean。

---

## 6. Phase 0 — 建立不可變基準與回復點

### 目標

在任何 Codex artifacts 或狀態文件被修改前，建立可追溯、可回復的專案基準。

### 執行清單

- [x] 再次確認 guide 為 20 章、3 份已完成附錄
- [x] 再次確認 reviews 為 24 份
- [x] 再次確認 wiki concepts 為 25 份
- [x] 確認第二意見結案文件存在
- [x] 確認 `csharp-sdk/` 為 v1.4.1 commit `2b7fd35...`
- [x] 確認 `csharp-sdk/` working tree clean
- [x] 執行 `git init`
- [x] 用 `git check-ignore csharp-sdk` 確認上游 clone 不會進 root repo
- [x] 檢查 `.gitignore` 是否涵蓋 outputs drafts、UA intermediate 與編輯器檔案
- [x] 建立初始 baseline commit
- [x] 建立 annotated tag：`tutorial-v1.4.0-reviewed-2026-07-16`
- [x] 若已有 remote，推送 baseline commit 與 tag（不適用：G0 決定暫不設定 remote）

### 建議命令

```bash
git init
git check-ignore csharp-sdk
git add --all
git status --short
git commit -m "chore: establish reviewed tutorial baseline"
git tag -a tutorial-v1.4.0-reviewed-2026-07-16 -m "Reviewed tutorial baseline before Codex handoff"
```

### 驗收條件

- [x] `git status --short` 無未追蹤或未提交的基準內容
- [x] tag 可解析到 baseline commit `0bf9214d0d8dd621430e749591821bb7d92ebe7f`
- [x] `git ls-files csharp-sdk` 無輸出
- [x] guide/kb/reviews 數量與移轉前一致

### 回復方式

不使用 destructive reset。若後續 phase 需取消，以 `git revert` 回復對應 migration commit；baseline tag 保持不動。

---

## 7. Phase 1 — 校正狀態文件與建立交接事實

### 目標

移除會誤導 Codex 或新維護者的歷史狀態，並把原本只存在 Claude memory 的關鍵決策寫入 repository。

### 檔案清單

- [x] 更新根 `README.md`：改為 20 章＋附錄 A/B/C、第二意見已結案、具備發佈條件
- [x] 更新 `mcp-csharp-sdk-kb/README.md`：改為 25 個 concepts 與現有 graph 狀態
- [x] 更新 `mcp-csharp-sdk-kb/WORKFLOW-DESIGN-v1.md`：標示首次 Pipeline 已完成及目前基準
- [x] 更新 `SETUP.md`：加入 Codex 安裝、trust、MCP、skills 與驗證流程
- [x] 更新 `mcp-csharp-sdk-kb/QuickStart.md`：提供 Codex skill 使用方式
- [x] 更新 `mcp-csharp-sdk-kb/PLAYBOOK-version-update.md`：把 Claude slash command 改成 provider-neutral workflow 名稱
- [x] 修正 `mcp-csharp-sdk-kb/UPSTREAM-REF.md` 的過時 project-name 說明
- [x] 將「guide 使用一般相對連結、kb 維持 wiki-style」寫成 repository 規約
- [x] 將 D/E 為第二輪工作寫成明確非阻塞事項
- [x] 將第二意見結案裁定與處置記錄列為發布前追溯來源

### 驗收條件

- [x] repository 狀態文件不再宣稱「骨架」「待首次 compile」「尚未驗證」
- [x] Claude/Codex 專屬操作與 provider-neutral 流程名稱有清楚區隔
- [x] project name 一律寫成 session 動態解析，不硬編碼本機名稱
- [x] 文件內沒有互相衝突的目前狀態

---

## 8. Phase 2 — 建立 Codex 原生指引層

### 目標

讓 Codex 在根目錄、kb 與 guide 子目錄工作時，都能載入最接近範圍的規約。

Codex 官方建議以 `AGENTS.md` 保存 repository 慣例、驗證方式與禁止事項；子目錄規則可由更接近工作目錄的 `AGENTS.md` 覆寫。參考：

- <https://learn.chatgpt.com/docs/agent-configuration/agents-md>
- <https://learn.chatgpt.com/docs/config-file/config-advanced#project-instructions-discovery>

### 2.1 根 `AGENTS.md`

必須包含：

- [x] 三層目錄角色：upstream / kb / guide
- [x] `csharp-sdk/` 唯讀規則
- [x] 事實層與敘述層二分
- [x] guide 草稿必須先進 `outputs/`
- [x] API 宣告需先查證
- [x] 目前版本、上游 commit 與協定版本
- [x] 標準 lint/test 命令
- [x] 完成定義與 review 期待
- [x] Git 操作與不可破壞既有變更原則
- [x] D/E 屬第二輪，不得誤判為當前發布阻塞
- [x] Codex skills 與 MCP 的入口位置

### 2.2 `mcp-csharp-sdk-kb/AGENTS.md`

必須包含：

- [x] frontmatter schema 與來源限制
- [x] raw/ 唯讀規則
- [x] facts JSON 是結構性事實來源
- [x] project name 必須先由 `list_projects` 動態解析
- [x] wiki-style 只保留在 kb
- [x] drift 分級規則
- [x] compile、snapshot、lint 的完成條件

### 2.3 `mcp-csharp-sdk-guide/AGENTS.md`

必須包含：

- [x] 繁體中文語言與術語規約
- [x] guide 只使用一般 Markdown 相對連結
- [x] 固定章節骨架與教學讀者設定
- [x] 程式碼驗證與版本 pin 規則
- [x] reviews 與第二意見追溯方式
- [x] 不得直接改寫已結案內容，除非有明確任務或 drift 證據
- [x] 新章節/附錄先輸出到 `outputs/`

### 驗證

- [x] 從 root 啟動新 Codex session，要求列出已載入的 instructions
- [x] 從 `mcp-csharp-sdk-kb/` 啟動，確認 root + kb 規約都載入
- [x] 從 `mcp-csharp-sdk-guide/` 啟動，確認 root + guide 規約都載入
- [x] 確認 instructions 未超過 Codex 預設大小上限；過長內容改連結至專用文件
- [x] 不接受未檢查的 `AGENTS.md -> CLAUDE.md` 自動 symlink

---

## 9. Phase 3 — 執行自動移轉與人工修訂

### 目標

使用 `migrate-to-codex` 產生初始 artifacts，再逐項消除 manual migration warnings。

### 移轉器

本機目前路徑：

```bash
MIGRATOR=/Users/tsengweihua/.codex/skills/migrate-to-codex/scripts/migrate-to-codex.py
```

其他機器若 `CODEX_HOME` 不同，必須先修正路徑。

### 執行順序

```bash
python3 "$MIGRATOR" --source . --scan-only
python3 "$MIGRATOR" --source . --target .codex --plan
python3 "$MIGRATOR" --source . --target .codex --doctor
python3 "$MIGRATOR" --source . --target .codex --dry-run
python3 "$MIGRATOR" --source . --target .codex
```

### 檢查清單

- [x] `--scan-only` 顯示 2 份 instruction surfaces（既有 `CLAUDE.md` 與新建 `AGENTS.md`）、12 commands、1 MCP
- [x] `--plan` 沒有非預期 artifacts
- [x] `--doctor` 的 collision 為 0
- [x] `--dry-run` 未修改工作區
- [x] 實際移轉後讀取 `.codex/migrate-to-codex-report.txt`
- [x] 先檢查 `AGENTS.md`
- [x] 再檢查 `.agents/skills/`
- [x] 再檢查 `.codex/config.toml`
- [x] 確認沒有意外建立 `.codex/hooks.json`
- [x] 確認沒有意外建立 `.codex/agents/`
- [x] 將每個 `## MANUAL MIGRATION REQUIRED` 區塊處理完畢
- [x] 不使用 `--replace`，除非已確認需要刪除 orphan generated artifacts

### 驗收條件

- [x] 所有產物可被 Git 追蹤
- [x] Claude 來源檔未被修改
- [x] migration report 中沒有可在 repository 內解決但仍未處理的項目

---

## 10. Phase 4 — 設定並重建 codebase-memory-mcp

### 目標

讓 Codex 可以直接查詢 `csharp-sdk/` 的結構性事實，恢復原工作流最重要的 ground truth 能力。

Codex 支援在 trusted project 的 `.codex/config.toml` 設定 STDIO MCP server。參考：<https://learn.chatgpt.com/docs/extend/mcp>

### 4.1 設定

預期 `.codex/config.toml` 至少包含等價設定：

```toml
[mcp_servers.codebase-memory-mcp]
command = "codebase-memory-mcp"
args = []
```

檢查：

- [x] 不含 token、API key 或本機私密資料
- [x] command 在 Codex CLI 的 PATH 可解析
- [x] 若 Codex desktop/IDE 找不到 NVM binary，改用經審查的穩定 wrapper 或記錄平台設定方式（本機 `codex mcp list` 可直接解析，無需 wrapper）
- [x] 專案已標示 trusted
- [x] 修改 config 後已重啟 Codex session
- [x] `codex mcp list` 顯示 server enabled
- [x] Codex 互動 session 可看到並呼叫 server tools（0.144.5 以逐 tool approval UI 驗證）

### 4.2 重建索引

現有 cache 不可視為有效索引。使用目前絕對路徑重新建立：

```bash
codebase-memory-mcp cli index_repository \
  '{"repo_path":"/Users/tsengweihua/Documents/mcp-csharp-sdk-tutorial/csharp-sdk"}'

codebase-memory-mcp cli list_projects '{}'
```

- [x] `list_projects` 找到 root path 以 `/csharp-sdk` 結尾的 project
- [x] 記錄本 session 實際 project name
- [x] `index_status` 為 ready
- [x] nodes > 0
- [x] edges > 0
- [x] indexed commit 與 `csharp-sdk` HEAD 對齊
- [x] 更新 `UPSTREAM-REF.md` 的索引工具版本、日期與規模

### 4.3 七項探測

- [x] 外部依賴使用端：`IChatClient`
- [x] 方法簽名：`McpClient.CreateAsync`
- [x] 繼承鏈：`McpClientTool : AIFunction`
- [x] Attribute：`McpServerToolAttribute`
- [x] Extensions：`AddMcpServer` / `MapMcp` / `WithToolsFromAssembly`
- [x] callers/trace：`AddMcpServer`
- [x] namespace 抽樣：`ModelContextProtocol.*`
- [x] 至少 6/7 通過；本次維持 7/7
- [x] 結果寫入或更新 `raw/facts/codebase-memory-mcp-validation.md`

### 失敗處理

- 若 project 可列出但 `index_status` 找不到：視為舊 cache/schema 不相容，重建索引。
- 若 Codex 啟動 MCP 失敗：先檢查 PATH、project trust、config TOML、server stderr，再決定是否使用絕對 command path。
- 若 C# 解析低於 6/7：停止完整 Pipeline，退化為 `rg` + 上游原始碼 + 官方文件查證，並在 `AGENTS.md` 明確標示 degraded mode。

---

## 11. Phase 5 — 轉換與驗證 12 個 Codex skills

### 共通修訂規則

每個 skill 都必須完成：

- [x] YAML frontmatter 有穩定 `name` 與精確 `description`
- [x] `description` 清楚說明何時應觸發與不應觸發
- [x] 移除對 Claude slash-command runtime 的假設
- [x] 使用者參數改為從當前請求解析，並在缺少必要參數時停止
- [x] 所有路徑以 workspace root 為基準
- [x] MCP project name 先動態解析
- [x] 寫入範圍、唯讀範圍與禁止範圍明確
- [x] 有 dry-run 或 preview 步驟
- [x] 有完成條件與驗證命令
- [x] 不依賴對話記憶判斷檔案現況
- [x] 不保留 `## MANUAL MIGRATION REQUIRED`

### Skill 對照表

| Claude command | 建議 Codex skill | 風險 | 必要驗證 |
| --- | --- | --- | --- |
| `/wiki-query` | `wiki-query` | 低 | 純讀取、來源路徑正確 |
| `/lint` | `lint-tutorial` | 低 | 呼叫 deterministic lint，零修改 |
| `/regenerate-toc` | `regenerate-toc` | 中 | 只改 guide README 的 TOC 區塊 |
| `/draft-chapter` | `draft-chapter` | 中 | 只寫 `outputs/`，不直接寫 guide |
| `/draft-appendix` | `draft-appendix` | 中 | 只寫 `outputs/`，連結可驗證 |
| `/save-qa` | `save-qa` | 中 | 只寫 QA 路徑，同主題 append 安全 |
| `/drift-check` | `drift-check` | 中 | 只覆寫 drift report，API 候選經 MCP 查證 |
| `/extract-facts` | `extract-facts` | 高 | JSON schema、verified 欄位、commit 對齊 |
| `/compile` | `compile-knowledge` | 高 | frontmatter 只取 verified facts |
| `/sync-upstream` | `sync-upstream` | 高 | 網路、git、raw 更新範圍、上游唯讀 |
| `/update-tutorial` | `update-tutorial` | 高 | scope 必填、修改前後 drift + lint |
| `/snapshot-knowledge` | `snapshot-knowledge` | 阻塞 | 依 G2 決策啟用、替代或停用 |

### 測試順序

1. [x] `wiki-query`
2. [x] `lint-tutorial`
3. [x] `draft-chapter`，使用測試 topic 並確認只寫 `outputs/`
4. [x] `draft-appendix`，使用測試 topic 並確認只寫 `outputs/`
5. [x] `regenerate-toc`，在 fixture 比對精確 diff
6. [x] `save-qa`，以測試檔驗證 append 行為後回復
7. [x] `drift-check`，確認 report schema 與 indexed commit
8. [x] `extract-facts`，先對現有版本做 dry-run/fixture
9. [x] `compile-knowledge`，先以 preview 與既有 facts/KB 驗證
10. [x] `sync-upstream`，先 preview remote/tag 差異
11. [x] `update-tutorial`，先用空 drift 驗證 scope/no-op
12. [x] `snapshot-knowledge`：2026-07-16 依路徑 A 驗證安全停止；2026-07-18 依路徑 C 驗證重建、差異、Dashboard 與 rollback

### 驗收條件

- [x] 12 個 skills 在新 Codex session 可被發現
- [x] 明確指定 skill 時能正確觸發
- [x] 至少測試一個自然語言請求的 implicit trigger
- [x] 高風險 skills 不會在缺少 scope/版本時直接寫檔
- [x] 所有測試後 working tree 只留下預期變更

---

## 12. Phase 6 — 建立 deterministic lint 與驗證入口

### 目標

把「lint 全綠」從 agent 判斷轉成任何維護者都能重跑的 repository 命令。

### 建議產物

```text
scripts/
  lint-docs.mjs
  check-links.mjs            # 若未合併進 lint-docs
  check-guide-structure.mjs  # 若未合併進 lint-docs
validation/
  README.md
  manifest.json
```

優先使用 Node.js 內建模組，避免只為 Markdown lint 引入大型依賴。

### 文件 lint 必查項目

- [x] guide 恰有 20 個 `NN-*.md`
- [x] 已完成附錄恰有 A/B/C
- [x] reviews 文件數量與索引一致
- [x] guide README 章節/附錄索引與實際檔案一致
- [x] 所有相對 Markdown 連結目標存在
- [x] guide 不含未轉換 wiki-style 連結；inline code 中的語法名稱不誤報
- [x] kb wiki-style 連結目標存在
- [x] fenced code block 都有語言標籤（現行 Codex/發布文件；保留的 Claude legacy source 不在 fast lint 範圍）
- [x] wiki frontmatter 必要欄位完整
- [x] facts 引用檔存在且 verified 規則成立
- [x] `tutorial_chapters` 指向存在章節或已完成附錄
- [x] 不出現已淘汰的「骨架階段」「待首次 compile」目前狀態（計畫中的歷史問題敘述除外）
- [x] README 狀態為具備發佈條件
- [x] 程式碼區塊不被散文標點正規化規則修改（lint 全程唯讀並驗證 fence 邊界）

### 程式碼驗證分級

| Profile | 範圍 | 預期命令/證據 |
| --- | --- | --- |
| fast | Markdown、連結、frontmatter、TOC | 每次修改必跑 |
| standard | 可保存的章節 build/test harness | guide 程式碼修改時跑 |
| release | Docker、OAuth wiring、Native AOT | 正式發布或相關章節變更時跑 |

### 驗收條件

- [x] `node scripts/lint-docs.mjs` exit code 0
- [x] 人為製造一個斷鏈時 exit code 非 0，還原後恢復 0（於 `/tmp` fixture 驗證）
- [x] inline code 的 `[[wiki-style]]` 語法名稱不被誤報（於 `/tmp` fixture 驗證）
- [x] Codex `lint-tutorial` skill 只是協調並解讀腳本，不重複實作 lint 邏輯
- [x] fast profile 可在乾淨 clone 重跑（僅需 Node.js 與依 `SETUP.md` 放置的唯讀 upstream clone）

---

## 13. Phase 7 — Understand-Anything 移植或正式延期

### 路徑 A：凍結 graph（Level 1）

- [x] 保留現有 `knowledge-graph.json` 與 `meta.json`
- [x] 在 `snapshot-knowledge` skill 標示 unavailable/deferred，不假裝成功
- [x] 在 Playbook 標示下一次版本更新前的阻塞點
- [x] Dashboard 仍可用現有 JSON 啟動
- [x] 建立 G2 後續 issue/task

### 路徑 B：完整移植（Level 2）

來源：Claude Understand-Anything plugin v2.7.5。

- [ ] 盤點必要 skills；至少 `understand-knowledge`、`understand-dashboard`
- [ ] 盤點必要 scripts、references、assets
- [ ] 盤點 9 個 Claude agents 的用途，決定轉 Codex subagents 或整併進 skill
- [ ] 檢查 Claude hooks；不直接複製不相容 lifecycle 行為
- [ ] 建立 Codex skill/plugin manifest
- [ ] 移除 Claude-only tool/agent/runtime 假設
- [ ] 在暫存輸出重建 graph
- [ ] 驗證 JSON schema 與 dashboard
- [ ] 比較節點、邊、cluster、orphan concepts
- [ ] 確認輸出只落在 `wiki/.understand-anything/`
- [ ] 更新 SETUP 與 snapshot skill

### 路徑 C：替代流程

- [x] 定義 graph 的必要功能與非必要視覺化
- [x] 以現有 wiki links + deterministic graph generator 重建結構，合併 reviewed augmentations
- [x] 定義並實作 schema 相容策略
- [x] 驗證 Understand-Anything 2.7.5 Dashboard 仍可使用
- [x] 記錄與原 UA 結果的語意差異

### 驗收條件

- [x] Pipeline 對 snapshot 能力的狀態誠實且可機器判斷
- [x] Level 2 能從乾淨狀態重新產生 graph
- [x] graph 失敗不會自動覆寫最後一份可用快照

---

## 14. Phase 8 — 新 session smoke test 與切換

### 啟動檢查

- [x] 從 repository root 開啟新的 Codex session
- [x] Codex 正確識別 project root
- [x] Codex 摘要 root `AGENTS.md` 規約正確
- [x] 從 kb/guide 子目錄確認 nested instructions
- [x] `codex mcp list` 顯示 `codebase-memory-mcp` enabled
- [x] Codex 互動 session 可看到並直接呼叫 MCP tools
- [x] 12 個 repository skills 可被發現

### 功能 smoke test

- [x] 執行 deterministic fast lint
- [x] 執行 `wiki-query` 查詢 ch09 的 `McpServerTool` 相關概念
- [x] 透過 MCP 查詢 `McpClient.CreateAsync`
- [x] 執行一個 draft skill，確認只寫 `outputs/`
- [x] 執行 dry-run drift-check 或使用 fixture
- [x] 依 G2 路徑 C 執行 snapshot rebuild、baseline diff、Dashboard 與 rollback smoke test
- [x] 檢查 `git diff --check`
- [x] 檢查 `csharp-sdk/` working tree clean

### Migrator 最終驗證

```bash
python3 "$MIGRATOR" --validate-target .codex
python3 "$MIGRATOR" --source . --target .codex --dry-run
```

- [x] `--validate-target` 無 TOML、skill frontmatter、AGENTS size、MCP command 錯誤
- [x] 再次 dry-run 無新的 repository 可處理 migration 項目（輸出僅重現已裁定的 legacy source proposals）
- [x] `.codex/migrate-to-codex-report.txt` 已納入追溯

### 切換完成

- [x] 建立 migration completion commit
- [x] 建立 annotated tag：`codex-handoff-complete-2026-07-16`
- [x] 更新根 README 的維護入口
- [x] 記錄 Level 1 與 Level 2 完成狀態
- [x] 若採並存，記錄 burn-in 結束條件

---

## 15. 建議 commit 切分

| Commit | 內容 |
| --- | --- |
| 1 | reviewed tutorial baseline + 本移轉計畫 |
| 2 | 校正 README/SETUP/KB 狀態文件 |
| 3 | 新增 root/kb/guide `AGENTS.md` |
| 4 | 新增 `.codex/config.toml` 與 MCP 接手記錄 |
| 5 | 新增 12 個 Codex skills |
| 6 | 新增 deterministic lint 與 validation manifest |
| 7 | UA 移植或延期狀態調整 |
| 8 | smoke test、migration report、切換完成記錄 |

每個 commit 前：

- [x] 檢查 staged diff
- [x] 確認沒有 `csharp-sdk/` 檔案
- [x] 確認沒有 secrets
- [x] 執行當階段適用的 lint/test
- [x] 確認 commit 訊息描述單一目的

---

## 16. 風險登錄

| ID | 風險 | 影響 | 緩解措施 | 關閉條件 |
| --- | --- | --- | --- | --- |
| R1 | 根目錄不是 Git repo | 無回復點、Codex root discovery 不穩定 | Phase 0 建 repo/tag | baseline tag 存在 |
| R2 | 自動 symlink `AGENTS.md` 到 Claude 指引 | Codex 執行錯誤 runtime 語意 | 建 provider-neutral AGENTS | 新 session 指引測試通過 |
| R3 | 12 commands 自動轉換未人工修訂 | 參數、寫入範圍或 trigger 錯誤 | 逐 skill checklist + smoke | doctor/manual blocks 清零 |
| R4 | 舊 codebase-memory cache 不可讀 | API ground truth 失效 | 重建索引、七項探測 | index ready、≥6/7 |
| R5 | NVM PATH 在 desktop/IDE 不同 | MCP server 無法啟動 | 驗證各 surface，必要時 wrapper | `/mcp` tools 可用 |
| R6 | UA 只存在 Claude plugin | snapshot Pipeline 中斷 | G2 決策與明確 degraded mode | UA 可用或延期已防誤報 |
| R7 | `/lint` 只有 prompt | 「全綠」不可重現 | deterministic script | clean clone exit 0 |
| R8 | 高風險 skill 直接覆寫內容 | 已審查教材被破壞 | dry-run、scope、Git branch | fixture/smoke 通過 |
| R9 | 狀態文件互相矛盾 | Codex 採用錯誤基準 | Phase 1 一次校正 | stale phrase lint 為 0 |
| R10 | Claude memory 未落地 | 決策在換工具後遺失 | AGENTS/README/本計畫 | 新 session 可重述決策 |
| R11 | heavy tests 太慢而被略過 | Docker/AOT 回歸未發現 | fast/standard/release profiles | 發布 checklist 明確 |
| R12 | 移轉時誤改上游 clone | ground truth 污染 | ignore + AGENTS + clean check | `csharp-sdk` clean |

---

## 17. 回復與失敗處理計畫

### 原則

- Claude artifacts 在 burn-in 期間不刪除。
- 每個 phase 使用獨立 commit，失敗時 revert 該 commit。
- 不以 `git reset --hard` 或 `git checkout --` 作為標準回復流程。
- MCP index 是可重建的機器狀態，不納入 Git。
- 最後一份有效 knowledge graph 在新 snapshot 驗證完成前不得覆寫。

### 回復層級

| 層級 | 情境 | 動作 |
| --- | --- | --- |
| L1 | 單一 skill 行為錯誤 | disable/移除該 skill 的 migration commit，使用 Claude command |
| L2 | MCP 無法使用 | 停止結構性修改，修復 config/index；不得以猜測代替查證 |
| L3 | Codex instructions 誤導 | revert AGENTS commit，重新設計最小規約 |
| L4 | guide/kb 出現非預期大量 diff | 停止 Pipeline，revert 該 phase commit，從 baseline 重跑 |
| L5 | UA 產物異常 | 保留舊 graph，將 snapshot 標記失敗，不發布新 graph |

### 回復後檢查

- [x] guide/kb/reviews 數量仍符合基準
- [x] 第二意見結案文件未改動
- [x] fast lint 通過
- [x] `csharp-sdk/` clean
- [x] Git working tree 狀態已記錄

---

## 18. 證據與簽核表

每個 phase 完成後至少填一列；命令輸出較長時，把結果存入對應 review/migration report，再在此連結。

| Phase | 日期 | 執行者 | 驗證命令/動作 | 結果 | 證據檔案或 commit | 審核者 |
| --- | --- | --- | --- | --- | --- | --- |
| 0 Baseline | 2026-07-16 | Codex | counts、結案文件、`csharp-sdk` clean、Git commit/tag | 通過 | `0bf9214`、`tutorial-v1.4.0-reviewed-2026-07-16` | Codex 自審 |
| 1 Status docs | 2026-07-16 | Codex | stale phrase、provider 命名、project-name、diff check | 通過 | 本 phase commit | Codex 自審 |
| 2 AGENTS | 2026-07-16 | Codex | 三層規約逐項核對、總量 8,012 bytes、非 symlink、新 session discovery | 通過 | `c803d48`、`validation/skill-smoke-2026-07-16.md` | Codex 自審 |
| 3 Migrator | 2026-07-16 | Codex | scan/plan/doctor/dry-run/write、人工修訂、target validation | 通過；repository 內可處理項目清零 | `10ce57d`、`.codex/migrate-to-codex-report.txt` | Codex 自審 |
| 4 MCP/index | 2026-07-16 | Codex | reindex、index_status、7 probes、`codex mcp list`、互動 tool calls | 通過 7/7；`list_projects`、`search_graph`、`get_code_snippet` 可直接呼叫 | `8668184`、`raw/facts/codebase-memory-mcp-validation.md`、`validation/skill-smoke-2026-07-16.md` | Codex 自審 |
| 5 Skills | 2026-07-16 | Codex | 12 skill contracts、explicit/implicit discovery、fixture writes、安全停止 | 通過 12/12 | `9ab65a6`、`validation/skill-smoke-2026-07-16.md` | Codex 自審 |
| 6 Lint/validation | 2026-07-16 | Codex | clean run、inline fixture、broken-link fixture | 通過；0/1 exit code 符合預期 | `scripts/lint-docs.mjs`、`validation/`、本 phase commit | Codex 自審 |
| 7 UA | 2026-07-16 | Codex | Level 1 freeze、snapshot deferred、Dashboard smoke、後續 task | 通過；Level 2 正式延期 | `acd9ff4`、`validation/ua-level2-follow-up.md` | Codex 自審 |
| 7 UA Level 2 | 2026-07-18 | Codex | deterministic rebuild、schema/baseline diff、reproducibility、rollback、Dashboard、正式發布 | 通過；102 nodes、228 edges、零 orphan，Level 1 凍結解除 | `validation/ua-level2-review-2026-07-18.md`、`.workflow/ua-level2/` | Codex 自審 |
| 8 Cutover | 2026-07-16 | Codex | 新 session、MCP、skills、lint、migrator、counts、upstream clean | 通過 | 本 completion commit、`codex-handoff-complete-2026-07-16` | Codex 自審 |

---

## 19. Master Checklist

### A. Baseline

- [x] 根 Git repo 已建立
- [x] baseline commit/tag 已建立
- [x] `csharp-sdk/` 已確認忽略且 clean
- [x] guide/kb/reviews 數量已記錄

### B. 文件與規約

- [x] 狀態文件已校正
- [x] root `AGENTS.md` 已建立
- [x] kb `AGENTS.md` 已建立
- [x] guide `AGENTS.md` 已建立
- [x] Claude memory 關鍵決策已落地
- [x] nested instruction discovery 已驗證

### C. Codex 設定

- [x] `.codex/config.toml` 已建立
- [x] project trust 已完成
- [x] MCP server enabled
- [x] migration report 已檢查
- [x] target validation 通過

### D. Ground Truth

- [x] codebase-memory 索引已重建
- [x] project name 動態解析成功
- [x] index ready、nodes/edges > 0
- [x] 七項探測 ≥ 6/7
- [x] validation 記錄已更新

### E. Skills

- [x] 12 個 skills 已建立
- [x] 12 個 skills 無 manual migration block
- [x] read-only skills 已測試
- [x] draft/write skills 已測試
- [x] 高風險 Pipeline skills 已以 preview/fixture 測試
- [x] snapshot skill 狀態符合 G2 決策

### F. 驗證

- [x] deterministic fast lint 已建立
- [x] fast lint 成功與失敗案例都已測試
- [x] standard/release profile 範圍已記錄
- [x] guide 的 inline syntax 不被誤報
- [x] knowledge graph schema、coverage、commit 與 orphan 檢查已納入 fast lint

### G. Cutover

- [x] 新 Codex session smoke test 通過
- [x] root/kb/guide instructions 均正確
- [x] MCP 與 skills 可發現
- [x] Level 1/Level 2 狀態已明確標示
- [x] Level 2 graph rebuild 與 rollback-safe publish 已通過
- [x] completion commit/tag 已建立
- [x] burn-in 與回復策略已記錄
- [x] working tree clean

---

## 20. 建議時程與優先順序

| 優先 | 階段 | 估計 |
| --- | --- | --- |
| P0 | Phase 0–2：Git、狀態文件、AGENTS | 0.5–1 工作日 |
| P0 | Phase 3–4：migrator、MCP、重建索引 | 0.5–1 工作日 |
| P1 | Phase 5：12 skills 人工修訂與測試 | 1–2 工作日 |
| P1 | Phase 6：deterministic lint/validation | 0.5–1.5 工作日 |
| P2 | Phase 7：UA Codex-native 替代流程 | 2026-07-18 完成 |
| P0 | Phase 8：smoke、validate、cutover | 0.5 工作日 |

實際結果：Level 1 於 2026-07-16 完成；UA Level 2 路徑 C 於 2026-07-18 完成。後續版本更新可依 Playbook 執行完整 Pipeline。

---

## 21. 參考資料

- Codex `AGENTS.md`：<https://learn.chatgpt.com/docs/agent-configuration/agents-md>
- Codex project instruction discovery：<https://learn.chatgpt.com/docs/config-file/config-advanced#project-instructions-discovery>
- Codex skills：<https://learn.chatgpt.com/docs/build-skills>
- Codex MCP：<https://learn.chatgpt.com/docs/extend/mcp>
- Codex config：<https://learn.chatgpt.com/docs/config-file/config-reference>
- 本工作區主指引：`CLAUDE.md`
- 知識庫補充指引：`mcp-csharp-sdk-kb/CLAUDE.md`
- 版本更新手冊：`mcp-csharp-sdk-kb/PLAYBOOK-version-update.md`
- 上游對齊記錄：`mcp-csharp-sdk-kb/UPSTREAM-REF.md`
- 第二意見：`mcp-csharp-sdk-guide/reviews/second-opinion-review-2026-07-16.md`
- 第二意見處置：`mcp-csharp-sdk-guide/reviews/second-opinion-resolution-2026-07-16.md`
