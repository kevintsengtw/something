# /snapshot-knowledge — 對 wiki/ 跑 Understand-Anything 知識圖譜分析

對 `mcp-csharp-sdk-kb/wiki/` 跑 UA 的 `/understand-knowledge`，產生視覺化知識圖譜與 dashboard。

## 用途

- 每次 `/compile` 完成後執行，產生 wiki 的結構化視覺化快照
- 提供 wiki 中**隱性關係**的抽取
- 產出可 commit 的 `knowledge-graph.json`，跨平台共享
- Onboarding 場景直接打開 dashboard

## 前置條件

- Understand-Anything 已安裝（Claude Code Plugin）
- `mcp-csharp-sdk-kb/wiki/` 已由 `/compile` 編譯到最新狀態

## 執行步驟

1. **檢查 wiki/ 是否為最新**
   - 讀取 `mcp-csharp-sdk-kb/wiki/INDEX.md` 的 last_compile 時間戳
   - 若 last_compile 早於最後的 `/sync-upstream`，提示「請先執行 `/compile`」並結束

2. **呼叫 Understand-Anything**

   執行 UA 原生指令：
   ```
   /understand-knowledge mcp-csharp-sdk-kb/wiki --language zh-TW
   ```

   UA 會自動：
   - 解析 wiki/INDEX.md 取得 wikilinks 與分類
   - 用 LLM agent 抽取概念之間的隱性關係、entities、claims
   - 產出 force-directed knowledge graph + community clustering
   - Dashboard UI 全繁體中文

3. **產出位置**

   UA 自動寫入：
   - `mcp-csharp-sdk-kb/wiki/.understand-anything/knowledge-graph.json`（commit）
   - `mcp-csharp-sdk-kb/wiki/.understand-anything/meta.json`（commit）
   - `mcp-csharp-sdk-kb/wiki/.understand-anything/intermediate/`（gitignore）
   - `mcp-csharp-sdk-kb/wiki/.understand-anything/diff-overlay.json`（gitignore）

4. **驗證快照品質**
   - 節點數 ≈ wiki/concepts/ 條目數
   - 是否有 orphan concepts
   - Community clustering 是否合理
   - 若有異常，回報但不阻斷流程

5. **產出摘要**
   - 列出節點數、邊數、cluster 數
   - 列出 orphan concepts
   - 列出新發現的隱性關係（與 INDEX.md 既有 wikilinks 差異）
   - 提示 dashboard 開啟方式：`/understand-dashboard`

## 注意事項

- 此指令是**敘述層**工具——產出由 LLM 抽取，**不是 ground truth**
- 隱性關係僅供參考，**不自動寫回 wiki/concepts/**
- 跨機共享：`knowledge-graph.json` 進 git，新環境可直接 `/understand-dashboard`
- 若 wiki 條目大幅變動（>5 個），建議重跑此指令
