# /update-tutorial — 依偏移報告更新教學目錄內容

讀取 `mcp-csharp-sdk-kb/wiki/drift-report.md`，將偵測到的偏移逐項修正至 `mcp-csharp-sdk-guide/` 中的對應教學檔案。

> **project 名稱**：本檔所有 `project: "<csharp-sdk-project>"` 為 placeholder。執行前以 `mcp__codebase-memory-mcp__list_projects` 取路徑以 `/csharp-sdk` 結尾的 project 名稱代入（名稱因機器而異，見工作區根 CLAUDE.md §6）。

## 使用方式

```
/update-tutorial              ← 處理全部項目
/update-tutorial breaking     ← 只處理 🔴 Breaking
/update-tutorial outdated     ← 只處理 🟡 Outdated
/update-tutorial all          ← 同 /update-tutorial（明確全量）
```

## 前置檢查

1. `mcp-csharp-sdk-kb/wiki/drift-report.md` 存在且非空白
2. `mcp-csharp-sdk-guide/` 目錄存在
3. drift-report 中有未修正項目

## 執行步驟

### 1. 載入偏移報告
- 讀取 `mcp-csharp-sdk-kb/wiki/drift-report.md`
- 解析所有 🔴 / 🟡 / 🟢 項目
- 建立修正工作清單，依優先排序：🔴 Breaking（P1 編譯失敗）→ 🔴（P2）→ 🟡 Outdated → 🟢 Enhancement（僅 all 模式）

### 2. 逐項修正

**a. 讀取目標檔案**：根據報告「影響檔案」讀取 `mcp-csharp-sdk-guide/<filename>.md`

**b. 套用修正**

| 偏移類型 | 修正策略 |
|---------|---------|
| API 重新命名 | 精確字串替換（如 `McpClientFactory.CreateAsync` → `McpClient.CreateAsync`） |
| 型別名稱變更 | 替換程式碼區塊內的型別宣告 |
| 方法簽名變更 | 替換完整方法呼叫 |
| 集合型別變更 | 如 `List<T>`/`T[]` → `IList<T>`，`.Length` → `.Count` |
| `--prerelease` 移除 | 移除 `dotnet add package` 中的 `--prerelease` |
| Experimental 標記 | 加上 `#pragma warning disable MCPEXP###` 說明或替代 API |
| 過時描述文字 | 更新文字說明，保留敘事連貫性 |

**修正原則**：
- 只修改報告明確指出的位置
- 不改變章節結構、標題、非偏移相關敘述
- 保留繁體中文寫作風格
- NuGet 版本號更新為 drift-report 依據的 current_version

**c. codebase-memory-mcp 替換方向確認**（API 重新命名類型，**必做**）
```
mcp__codebase-memory-mcp__search_graph
  project: "<csharp-sdk-project>"
  name_pattern: "<新 API 名稱>"
```
- 必要時 `trace_path` direction: outbound 確認依賴結構
- 若圖譜找不到新名稱，**不自動替換**，標記 `⚠️ 需人工確認`

**d. 記錄修正結果**：每項記錄「[item-id] ✅ 已修正：<簡述>」

### 3. 產出修正摘要

```
## /update-tutorial 修正摘要
**執行時間**：YYYY-MM-DD
**處理範圍**：breaking / outdated / all

### 已修正
- [B-001] ✅ <簡述>（N 個檔案，M 處）

### 跳過 / 需人工確認
- [B-002] ⚠️ <簡述>（圖譜未確認）

### 未處理（本次範圍外）
- 🟢 Enhancement 項目
```

### 4. 後續建議
```
/drift-check    ← 驗證偏移是否消除
/lint           ← 確認一致性
```

## 需人工確認的情況
- 整章程式碼需大幅改寫
- 報告標註「需驗證 SDK 實際簽名」
- 同一位置有多種可能正確寫法
- Enhancement 涉及新增段落或章節
- **codebase-memory-mcp 圖譜找不到要替換的新名稱**

## 注意事項
- 不執行 `/drift-check` 比對邏輯，只依現有 drift-report 修正
- 若 drift-report 已過時（>7 天），摘要加上提醒
- 🟢 Enhancement 預設不自動處理
- 修正後程式碼以語意正確為目標，不保證 dotnet build 通過
- 替換前圖譜驗證是**硬性規定**
