# /drift-check — 偵測教學內容與上游 API 的偏移

比對 `mcp-csharp-sdk-kb/wiki/concepts/` 中的最新 API 定義與 `mcp-csharp-sdk-guide/` 中的教學內容，產出偏移報告。

**事實層判決者**：codebase-memory-mcp 決定 🔴 Breaking（API 是否真的不存在）；敘述層由文字比對處理 🟡 Outdated 與 🟢 Enhancement。

> **project 名稱**：本檔所有 `project: "<csharp-sdk-project>"` 為 placeholder。執行前以 `mcp__codebase-memory-mcp__list_projects` 取路徑以 `/csharp-sdk` 結尾的 project 名稱代入（名稱因機器而異，見工作區根 CLAUDE.md §6）。

## 執行步驟

1. **載入基準**
   - 讀取 `mcp-csharp-sdk-kb/wiki/concepts/` 中所有條目
   - 建立「最新 API 名稱 → 簽名 → 命名空間 → 套件」對照表
   - 讀取 `mcp-csharp-sdk-kb/wiki/api-changelog.md`

2. **掃描教學內容**
   - 讀取 `mcp-csharp-sdk-guide/` 中所有 .md 檔
   - 擷取所有 C# 程式碼區塊、行內程式碼參考、NuGet 套件版本參考、`dotnet add package` 指令

3. **codebase-memory-mcp API 存在性查驗**（🔴 Breaking 判定）

   對每個核心 API：
   ```
   mcp__codebase-memory-mcp__query_graph
     project: "<csharp-sdk-project>"
     query: "MATCH (n {name: '<API 名稱>'}) RETURN n.name, n.filePath, labels(n)"
   ```
   - 圖譜查無 → 🔴 Breaking 候選（先排除外部 NuGet 型別）
   - 用 `get_code_snippet` 確認是命名空間差異還是拼字問題

   對教學 `using` 命名空間：
   ```
   mcp__codebase-memory-mcp__query_graph
     project: "<csharp-sdk-project>"
     query: "MATCH (n:Class {name: '<ClassName>'}) RETURN n.namespace"
   ```
   - namespace 不符 → 🔴 Breaking

4. **codebase-memory-mcp 官方用法比對**（🟡 Outdated 輔助）
   ```
   mcp__codebase-memory-mcp__search_code
     project: "<csharp-sdk-project>"
     pattern: "<API 名稱>"
   ```
   - 教學初始化/呼叫方式與上游 samples 明顯不同 → 🟡 Outdated
   - 上游有更簡潔的新寫法 → 🟢 Enhancement

5. **比對偵測**

   ### 🔴 Breaking
   - 教學使用的類別已不存在於最新 API（文字比對 + 圖譜雙重確認）
   - 方法參數數量或型別不符
   - using 命名空間已變更或移除
   - NuGet 套件名稱改名（如 v0.5.0 前的 profile 變更、`McpClientFactory` → `McpClient` 類變更）
   - 已移除類別仍被參考
   - API 被標為 Experimental（`MCPEXP###`）但教學未加抑制說明

   ### 🟡 Outdated
   - 描述使用舊名稱
   - 版本號落後 2+ minor
   - 提及 `--prerelease` 但已 GA
   - 程式碼可運作但非最佳實踐（如未顯式設定 `Stateless`）

   ### 🟢 Enhancement
   - wiki/concepts/ 有教學未涵蓋的新概念（如 Tasks、Elicitation 新功能）
   - 新的官方 sample 可作為素材
   - 新傳輸/驗證模式未提及

6. **產出報告**

   **每次執行均為全量比對，完整覆寫 `mcp-csharp-sdk-kb/wiki/drift-report.md`**：

   ```markdown
   ---
   generated: YYYY-MM-DD
   indexed_commit: <csharp-sdk HEAD hash>
   baseline: wiki/concepts/ (N 條目, vX.Y.Z) vs guide/ (M 檔案)
   ---

   # 偏移報告

   ## 摘要
   | 等級 | 數量 | 說明 |
   |------|------|------|
   | 🔴 Breaking | X | 教學範例可能無法編譯 |
   | 🟡 Outdated | Y | 內容過時但可運作 |
   | 🟢 Enhancement | Z | 可選補充 |

   ## 🔴 Breaking
   ### B-NNN: <問題描述>
   - **影響檔案**：`XX-chapter-name.md` L行號
   - **現況**：<教學中的寫法>
   - **正確**：<最新 API 的寫法>
   - **圖譜證據**：<query 結果 / namespace>
   - **來源 wiki**：<wiki/concepts/xxx.md>
   - **建議修正**：<具體修改建議>
   ```

7. **摘要輸出**
   - 終端顯示簡短摘要 + 完整報告位置

## 注意事項

- 每次執行均基於當下檔案，不參考對話歷史或舊報告
- drift-check 基於文字比對 + 圖譜查驗，不等於 `dotnet build`
- 教學中標註「⚠️ 提案中 / Experimental」的程式碼不直接標 🔴
- codebase-memory-mcp 索引對象是 `csharp-sdk/`；guide 與 kb 未索引
- `Microsoft.Extensions.AI.*` 型別圖譜查無屬正常，不標 🔴
