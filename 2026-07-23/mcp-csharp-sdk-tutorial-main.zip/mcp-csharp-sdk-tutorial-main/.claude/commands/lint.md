# /lint — wiki 與 tutorial 雙側一致性檢查

檢查 `mcp-csharp-sdk-kb/wiki/` 條目格式與索引完整性，**同時**檢查 `mcp-csharp-sdk-guide/` 的 markdown 一致性。

> **project 名稱**：本檔所有 `project: "<csharp-sdk-project>"` 為 placeholder。執行前以 `mcp__codebase-memory-mcp__list_projects` 取路徑以 `/csharp-sdk` 結尾的 project 名稱代入（名稱因機器而異，見工作區根 CLAUDE.md §6）。

## 執行步驟

### Part 1：wiki/ 自身一致性

1. **條目格式檢查**
   - 掃描 `mcp-csharp-sdk-kb/wiki/concepts/` 中所有 .md 檔
   - 檢查 YAML frontmatter 是否完整：title, api_name, namespace, package, since, current_version, updated, tags, tutorial_chapters, sources
   - 檢查必要段落：概述、目前 API 簽名、變更歷史、教學章節對應、相關概念
   - **例外**：tags 含 deprecated / devops / migration / testing-pattern / protocol-concept 允許替代段落結構

2. **api_name 圖譜查驗**（codebase-memory-mcp）
   ```
   mcp__codebase-memory-mcp__search_graph
     project: "<csharp-sdk-project>"
     name_pattern: "<api_name 值>"
   ```
   - 查無結果 → ⚠️（排除外部套件如 `Microsoft.Extensions.AI.*`）
   - 外部套件判斷：namespace 不以 `ModelContextProtocol` 開頭（注意 SDK 的 DI 擴充刻意放在 `Microsoft.Extensions.DependencyInjection`，屬內部，需以 file_path 判定）

3. **索引完整性**
   - 讀取 `mcp-csharp-sdk-kb/wiki/INDEX.md`
   - 確認所有 concepts/ 檔案都列在索引，且索引無指向不存在檔案的連結

4. **交叉引用驗證**
   - 掃描 `[[concept-name]]` 連結，確認目標條目存在，回報斷鏈

5. **來源追溯驗證**
   - raw/ 路徑：檢查 sources 中 raw/ 開頭路徑是否存在
   - csharp-sdk/ 路徑：檢查上游原始碼參考是否存在
   - raw/facts/ 路徑：驗證引用的事實 JSON 存在且 verified: true

6. **教學對應驗證**
   - 檢查 tutorial_chapters（ch05、appendix-a）是否真的存在於 mcp-csharp-sdk-guide/

7. **時效性檢查**
   - 列出 updated 超過 30 天的條目

### Part 2：tutorial/ 一致性

8. **內部連結驗證**
   - 掃描 mcp-csharp-sdk-guide/*.md 的 markdown 連結，檢查相對連結目標是否存在

9. **Code block 語言標籤**
   - 掃描 ``` 開頭的程式碼區塊，檢查是否有語言標籤（csharp、json、bash、xml）

10. **教學中 API 名稱抽樣查驗**
    - 從教學擷取 inline code 與 csharp block 內的類別、方法名稱
    - 對明顯的 SDK API（`McpClient`、`AddMcpServer`、`McpServerTool` 等）抽樣 `search_graph`
    - 圖譜查無 → 候選 🔴 Breaking（建議跑 `/drift-check`）

11. **README.md 章節索引一致性**
    - 讀取 `mcp-csharp-sdk-guide/README.md` 章節表
    - 比對實際存在的 NN-*.md 與 appendix-*-*.md，回報缺漏或多餘

### 12. 產出報告

```
Wiki + Tutorial Lint Report — YYYY-MM-DD

=== wiki/ ===
✅ Frontmatter 完整：X / N 條目
⚠️ 替代段落結構：Y 條目
⚠️ api_name 圖譜查無：Z 個（排除外部套件後列出）
✅ 索引一致：是/否
⚠️ 斷鏈：Z 個（列出）
✅ raw/ 來源有效：X / N
⚠️ csharp-sdk/ 來源失效：Z 個
✅ 教學章節引用：全部有效
📅 需更新（>30 天）：W 條目

=== tutorial/ ===
✅ 內部連結有效：X / N
⚠️ Code block 缺語言標籤：Z 個（列出檔案 + 行號）
⚠️ API 抽樣查驗失敗：Z 個（建議跑 /drift-check）
✅ README 章節索引一致：是/否
```

## 注意事項
- 此指令是純檢查，**不修改任何檔案**
- 教學側 lint 是抽樣，完整檢查請跑 `/drift-check`
- 若 wiki 條目大量過時（>10 條），先跑 `/sync-upstream` + `/compile`
