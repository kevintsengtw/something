# /wiki-query — 查詢知識庫

在 `mcp-csharp-sdk-kb/wiki/concepts/` 與 `mcp-csharp-sdk-kb/wiki/api-changelog.md` 中搜尋與使用者問題相關的結構化知識。

## 使用方式

```
/wiki-query <問題或關鍵字>
```

範例：
- `/wiki-query McpServerTool 怎麼註冊`
- `/wiki-query Stdio 與 Streamable HTTP 傳輸差異`
- `/wiki-query stateless session 什麼時候用`

## 執行步驟

1. **解析查詢意圖**：概念說明、API 用法、版本變更、教學對應

2. **搜尋知識庫**
   - `mcp-csharp-sdk-kb/wiki/concepts/`（依 title、api_name、tags 匹配）
   - `mcp-csharp-sdk-kb/wiki/api-changelog.md`（版本變更）
   - `mcp-csharp-sdk-kb/wiki/INDEX.md`（分類位置）
   - `mcp-csharp-sdk-kb/brainstorming/qa-sessions/`（相關 QA）

3. **組合回答**
   - 繁體中文回答，引用具體的 wiki/concepts/ 條目
   - 附上對應教學章節連結（如有）
   - 若 wiki/ 資訊不足，提示需先 `/sync-upstream` + `/compile`

4. **顯示來源**：列出 wiki/ 檔案路徑與對應 raw/ 原始素材路徑

## 注意事項
- 此指令是**純讀取**，只搜尋 kb 內容，不修改任何檔案
- 深入語意問題可改用 UA 原生 `/understand-chat`
- 結構性問題（call graph、依賴）改用 `mcp__codebase-memory-mcp__get_code_snippet` 或 `trace_path`
