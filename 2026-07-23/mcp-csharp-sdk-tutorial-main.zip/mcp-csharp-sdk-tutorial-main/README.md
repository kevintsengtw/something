# MCP C# SDK 繁體中文教學

> 基準版本：**ModelContextProtocol v1.4.0**
> 上游：[modelcontextprotocol/csharp-sdk](https://github.com/modelcontextprotocol/csharp-sdk)（與 Microsoft 合作維護，Apache-2.0）
> 狀態：✅ **具備發佈條件**——20 章＋附錄 A/B/C 已完成第二意見審查與處置；附錄 D/E 列入第二輪

以繁體中文撰寫的 MCP C# SDK 完整教學，涵蓋 MCP Server 與 Client 的建立、三大 primitive（Tools / Prompts / Resources）、傳輸層（Stdio / Streamable HTTP / In-memory）、Sessions、Sampling、Elicitation、Tasks、Authorization、ASP.NET Core 整合、測試與 Docker 部署。內建 LLM Wiki 知識庫，透過可重用工作流追蹤上游 API 變更並偵測教學內容偏移。

本專案的工作流與工具鏈沿用 [`agent-framework-tutorial`](../agent-framework-tutorial) 的 v2 設計（事實層 codebase-memory-mcp / 敘述層 Understand-Anything 二分）。

---

## 目錄結構

```text
mcp-csharp-sdk-tutorial/                  ← 工作區根（Git / agent 工作流入口）
├── csharp-sdk/                           ← 上游原始碼（自行 clone，唯讀，gitignore）
├── mcp-csharp-sdk-kb/                    ← LLM Wiki 知識庫
│   ├── raw/                              ← 上游素材（release notes、samples、docs、facts）
│   ├── wiki/concepts/                    ← 結構化概念條目
│   ├── wiki/.understand-anything/        ← 已產生的 Understand-Anything 知識圖譜
│   └── brainstorming/                    ← 問答記錄
├── mcp-csharp-sdk-guide/                 ← 教學本體（20 章＋附錄 A/B/C）
├── .agents/skills/                       ← Codex repository skills
├── .codex/config.toml                    ← Codex 專案 MCP 設定
├── .claude/commands/                     ← 保留的 Claude Code commands
├── AGENTS.md / CLAUDE.md                 ← Codex / Claude Code 工作區指引
├── SETUP.md                              ← 新機器環境設定指南
└── CODEX-HANDOFF-PLAN.md                 ← Claude Code → Codex 移轉追蹤
```

> `csharp-sdk/`（官方 SDK git clone）不含在本 repo 中，各台機器請自行 clone：
> `git clone https://github.com/modelcontextprotocol/csharp-sdk.git`

---

## SDK 套件速覽

| 套件 | 何時使用 |
|------|---------|
| **ModelContextProtocol.Core** | 只需 client 或 low-level server API、想要最少依賴 |
| **ModelContextProtocol** | 建立 client 或 **stdio** server，需要 hosting、DI、attribute 式 tool/prompt/resource 探索。**多數專案的起點** |
| **ModelContextProtocol.AspNetCore** | 建立 **HTTP** server（ASP.NET Core 託管），引用 `ModelContextProtocol` 並加上 HTTP 傳輸 |

---

## LLM Wiki 知識庫

`mcp-csharp-sdk-kb/` 是基於 [Karpathy LLM Wiki](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) 概念設計的知識管理系統。工作流目的在 Codex 與 Claude Code 中保持對應，實際入口名稱依 provider 略有不同，分別為 repository skills 與 legacy slash commands：

```text
sync-upstream        ← 抓取最新 release notes、conceptual docs、samples、SDK 原始碼
extract-facts        ← 從 release notes 抽取 API 事實，以 codebase-memory-mcp 逐筆驗證
compile-knowledge    ← 編譯 wiki/concepts/ 條目（frontmatter 受事實清單約束）
drift-check          ← 比對 wiki 與教學內容，產出 🔴/🟡/🟢 偏移報告
update-tutorial      ← 自動修正偏移（替換前以 codebase-memory-mcp 驗證）
lint-tutorial        ← wiki + tutorial 雙側一致性檢查
snapshot-knowledge   ← staging 重建、驗證並安全發布 Understand-Anything 相容圖譜
```

---

## 知識圖譜 Dashboard（Understand-Anything）

目前已產出並納入版本控制：

```text
mcp-csharp-sdk-kb/wiki/.understand-anything/knowledge-graph.json
```

### 啟動 Dashboard

```bash
# 安裝依賴（首次）
cd ~/.claude/plugins/cache/understand-anything/understand-anything/<version>/packages/core
npx tsc
cd ../dashboard
pnpm install

# 啟動（GRAPH_DIR 指向本 repo 的 wiki 目錄）
GRAPH_DIR=/path/to/mcp-csharp-sdk-kb/wiki npx vite --host 127.0.0.1
```

> 圖譜由 repository 內的 Codex-native deterministic generator 產生，**不需要 Claude**。Understand-Anything 2.7.5 Dashboard 僅作相容 viewer；API ground truth 仍以 upstream、facts 與 codebase-memory-mcp 為準。

---

## 前置需求

| 用途 | 需求 |
|------|------|
| 閱讀教學 | 無（純 Markdown） |
| 執行範例程式碼 | .NET 9.0+ SDK、（選用）LLM API Key |
| 知識庫維護 | Codex CLI（主要）或 Claude Code（並存期）+ codebase-memory-mcp + `csharp-sdk/` clone |
| Dashboard | Node.js 18+、pnpm |

---

## 新機器設定

見 **[SETUP.md](./SETUP.md)**。

Codex 轉移進度與逐項驗收見 **[CODEX-HANDOFF-PLAN.md](./CODEX-HANDOFF-PLAN.md)**。

### 維護接手入口

- Codex 工作規約：[`AGENTS.md`](./AGENTS.md)
- 環境與 MCP 設定：[`SETUP.md`](./SETUP.md)
- 文件與 skill 驗證：[`validation/README.md`](./validation/README.md)
- 完整移轉證據與清單：[`CODEX-HANDOFF-PLAN.md`](./CODEX-HANDOFF-PLAN.md)

目前已完成 **Codex Level 2**：文件、KB、12 個 repository skills、codebase-memory-mcp 與 knowledge graph 更新均可由 Codex 維護。UA 路徑 C 的決策、驗證與發布證據見 [`validation/ua-level2-review-2026-07-18.md`](./validation/ua-level2-review-2026-07-18.md)；結案清單見 [`validation/ua-level2-follow-up.md`](./validation/ua-level2-follow-up.md)。

Claude Code artifacts 在至少兩次完整維護循環的 burn-in 期間保留且不修改；兩次循環均通過 fast lint、MCP ground-truth 探測與適用的 standard/release 驗證後，再另案決定是否封存 Claude 入口。

---

## 參考資料

- [modelcontextprotocol/csharp-sdk](https://github.com/modelcontextprotocol/csharp-sdk) — SDK 原始碼
- [MCP C# SDK 概念文件](https://csharp.sdk.modelcontextprotocol.io/) — 官方 conceptual docs
- [MCP API 文件](https://csharp.sdk.modelcontextprotocol.io/api/ModelContextProtocol.html) — API reference
- [MCP 規格](https://modelcontextprotocol.io/specification/) — Protocol Specification
- [Karpathy LLM Wiki Pattern](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) — 知識庫設計參考

---

## 授權

本教學內容為個人學習與分享用途，非官方資源。MCP C# SDK 本身採用 Apache License 2.0。
