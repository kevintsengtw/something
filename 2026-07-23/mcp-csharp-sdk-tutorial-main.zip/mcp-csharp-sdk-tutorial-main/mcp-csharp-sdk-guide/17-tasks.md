# 第 17 章：Tasks——長時間執行的持久任務

> 對應 wiki 概念：[tasks](../mcp-csharp-sdk-kb/wiki/concepts/tasks.md)
> 上游 API：`IMcpTaskStore`、`McpServerOptions.TaskStore`、`McpClient.CallToolAsTaskAsync` 等（皆屬 `ModelContextProtocol.Core`）
> 引入版本：v1.0.0（2025-11-25 規格）｜ ⚠️ **實驗性功能（MCPEXP001）**

## 本章目標

- 理解 task-augmented 呼叫：長工具立即回一張「收據」，client 之後輪詢、取結果、可取消
- Server 端註冊 `IMcpTaskStore`，讓 async 工具自動獲得 task 支援
- Client 端走完 `CallToolAsTaskAsync` → `PollTaskUntilCompleteAsync` → `GetTaskResultAsync` 全流程
- 認識任務狀態機（含 sampling／elicitation 觸發的 `InputRequired`）與 durable store
- 正確面對實驗性 API：`MCPEXP001` 抑制與其含意

## 為什麼需要這個

一般的 `tools/call` 是同步等待：工具跑多久，連線就吊多久。工具要跑十分鐘的話，問題全來了——HTTP 逾時、client 斷線結果就丟、使用者盯著轉圈圈不能做別的事。

2025-11-25 規格的 **Tasks** 把這類操作改成「收據模式」：

```text
client                                server
  │ tools/call "crunch" (task 模式)     │
  │◀── McpTask { taskId, Working } ────┤  ← 立即回收據，工具在背景跑
  │                                    │
  │ tasks/get taskId    （隨時、可重複）  │
  │◀── { Status: Working } ────────────┤
  │        …工具完成…                    │
  │ tasks/result taskId                │
  │◀── CallToolResult ─────────────────┤
```

任務狀態存在 server 側的 **task store**,與連線生命週期脫鉤——client 斷線重連、甚至 server 重啟（用 durable store 時），任務照樣查得到。官方 `LongRunningTasks` sample 就是配 stateless HTTP 跑的：連 session 都不需要，每個請求帶 taskId 就好。

> ⚠️ **先說清楚：這是實驗性功能。** Tasks 在 MCP 規格與 SDK 中都標記為 experimental,對應診斷代碼 `MCPEXP001`——使用相關 API 會直接**編譯錯誤**,需在專案檔明確抑制（見上手範例）。規格演進時 API 可能變動，升級 SDK 版本時要重測本章流程。

## 核心概念

### McpTask：收據長什麼樣

| 屬性 | 意義 |
|------|------|
| `TaskId` | 任務唯一識別，之後所有操作憑它 |
| `Status` | `Working` → 終態 `Completed`／`Failed`／`Cancelled`;等待使用者時 `InputRequired` |
| `StatusMessage` | 人類可讀的狀態說明 |
| `CreatedAt`／`LastUpdatedAt` | 時間戳 |
| `TimeToLive` | 任務保存期限，過期後查不到 |
| `PollInterval` | server 建議的輪詢間隔（`PollTaskUntilCompleteAsync` 會遵循，預設 1 秒） |

`InputRequired` 值得注意：task 模式下的工具若呼叫了 sampling（第 14 章）或 elicitation（第 15 章），SDK **自動**把任務狀態切到 `InputRequired`，拿到回應再切回 `Working`——狀態機是免費的。

### 工具的 task 支援三態

每個工具對 task 模式的態度由 `ToolTaskSupport` 宣告，寫在工具的 `execution.taskSupport` 中讓 client 看見：

| 值 | 意義 |
|----|------|
| `Forbidden`（預設） | 不可用 task 模式呼叫 |
| `Optional` | 兩種模式都行 |
| `Required` | 只能用 task 模式 |

不顯式設定時 SDK 自動判斷：**server 有 task store 的前提下，async 工具方法自動 `Optional`**、同步方法 `Forbidden`（實測確認）。要強制就在 attribute 上寫 `[McpServerTool(TaskSupport = ToolTaskSupport.Required)]`。

### Task store：狀態放哪裡

`IMcpTaskStore` 是保存任務的抽象，SDK 內建 `InMemoryMcpTaskStore`（行程內、重啟即失）。**namespace 陷阱**：這兩個型別的原始檔在 `Server/` 目錄，namespace 卻是根 `ModelContextProtocol`——`using ModelContextProtocol.Server;` 找不到它們。production 場景要自己實作 durable store,官方 `LongRunningTasks` sample 附了一個 `FileBasedMcpTaskStore`（存檔案，重啟後任務仍可查詢）可作範本。

## 上手範例

### 步驟 1：抑制 MCPEXP001

專案檔（server 與 client 兩側都要）：

```xml
<PropertyGroup>
  <NoWarn>$(NoWarn);MCPEXP001</NoWarn>
</PropertyGroup>
```

這是刻意的門檻——留著這行，就等於留下「我知道這是實驗性 API」的紀錄。

### 步驟 2：server——註冊 task store,工具照常寫

```csharp
using ModelContextProtocol;          // IMcpTaskStore / InMemoryMcpTaskStore（根 namespace）
using ModelContextProtocol.Server;
using System.ComponentModel;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMcpServer(options =>
{
    options.TaskStore = new InMemoryMcpTaskStore();   // 有了它，tasks capability 才會開
})
.WithHttpTransport(o => o.Stateless = true)           // tasks 與 stateless 是好搭檔
.WithTools<CrunchTools>();

var app = builder.Build();
app.MapMcp();
app.Run();

[McpServerToolType]
public sealed class CrunchTools
{
    [McpServerTool, Description("Crunches numbers for a while and returns a report.")]
    public static async Task<string> Crunch(
        [Description("Job label.")] string label,
        CancellationToken cancellationToken)
    {
        await Task.Delay(TimeSpan.FromMinutes(5), cancellationToken);   // 模擬長工作
        return $"報告完成：{label}";
    }
}
```

工具本身**一行都不用改**——async 方法配上 task store,自動就是 `Optional`。

### 步驟 3：client——收據、輪詢、取結果

```csharp
// 1. 以 task 模式呼叫：立即拿到收據，不等工具跑完
var task = await client.CallToolAsTaskAsync("crunch",
    new Dictionary<string, object?> { ["label"] = "Q3" });
Console.WriteLine($"任務已建立：{task.TaskId}（{task.Status}）");

// 2. 輪詢直到終態（遵循 server 建議的 PollInterval）
var finished = await client.PollTaskUntilCompleteAsync(task.TaskId);

// 3. 取回結果——CallToolResult 的原始 JSON
if (finished.Status == McpTaskStatus.Completed)
{
    JsonElement result = await client.GetTaskResultAsync(task.TaskId);
    var text = result.GetProperty("content")[0].GetProperty("text").GetString();
    Console.WriteLine(text);   // 報告完成：Q3
}
```

以上流程（含 `ToolTaskSupport.Optional` 的自動宣告）在第 13 章的 in-memory 測試環境中實測通過。`GetTaskResultAsync` 回傳 `JsonElement`——就是一般 `tools/call` 會回的 `CallToolResult` JSON,自行取 `content` 解析。

## 進階用法

### 取消與列表

```csharp
var cancelled = await client.CancelTaskAsync(task.TaskId);   // 要求取消，回更新後的 McpTask

IList<McpTask> all = await client.ListTasksAsync();          // 這個 session 可見的所有任務
```

工具方法內的 `CancellationToken` 就是取消的觸角——長迴圈記得定期 `ThrowIfCancellationRequested`，不然「已取消」的任務還在背景燒 CPU。

### 狀態推播：TaskStatusHandler

不想輪詢的話，client 可掛 handler 接收狀態變更通知：

```csharp
var client = await McpClient.CreateAsync(transport, new McpClientOptions
{
    Handlers = new McpClientHandlers
    {
        TaskStatusHandler = (task, cancellationToken) =>
        {
            Console.WriteLine($"任務 {task.TaskId} → {task.Status}");
            return ValueTask.CompletedTask;
        },
    },
});
```

### Durable store：任務比行程長壽

`InMemoryMcpTaskStore` 的任務隨行程消失。`LongRunningTasks` sample 的做法：

```csharp
var taskStore = new FileBasedMcpTaskStore(
    Path.Combine(Path.GetTempPath(), "mcp-tasks"));   // sample 自帶的檔案版實作

builder.Services.AddMcpServer(options => options.TaskStore = taskStore)
    .WithHttpTransport(o => o.Stateless = true)
    .WithTools<TaskTools>();
```

`IMcpTaskStore` 介面也可以拿資料庫、Redis 來實作——關鍵語意：任務的身分與結果由 store 承載，server 行程只是執行者。搭配第 12 章的 stateless 部署，水平擴展的每個實例都查得到同一批任務（只要 store 是共享的）。

### 與 sampling / elicitation 的互動

task 模式的工具呼叫 `SampleAsync`／`ElicitAsync` 時，任務自動進 `InputRequired` 狀態——client 看到這個狀態就知道「工具在等人／等模型」，可以把介面切到對應的互動。這些行為由 SDK 內建，工具程式碼無感。

## 常見錯誤

**1. 沒抑制 MCPEXP001,直接編譯錯誤**

`error MCPEXP001: The Tasks feature is experimental...`——這不是警告，是錯誤。照上手範例在 csproj 加 `NoWarn`（或用 `#pragma warning disable MCPEXP001` 局部抑制）。

**2. `using ModelContextProtocol.Server;` 找不到 `IMcpTaskStore`（CS0246）**

它們在**根 namespace** `ModelContextProtocol`（檔案位置會騙人）。本章實測時就踩了這個。

**3. 沒註冊 task store**

沒有 `options.TaskStore`,server 不宣告 tasks capability,所有工具的 `taskSupport` 都是 `Forbidden`，`CallToolAsTaskAsync` 直接失敗。task store 是整個功能的開關。

**4. 對同步工具用 task 模式**

同步方法自動 `Forbidden`。真的需要，就改成 async 簽名或顯式 `TaskSupport = ToolTaskSupport.Optional`——但同步阻塞的工作放進 task 模式並不會神奇變快，先想想它為什麼是同步的。

**5. production 用 `InMemoryMcpTaskStore`**

重啟即失憶，多實例部署時更是各說各話。它是拿來開發與測試的；上線請實作 durable、可共享的 store。

## 相關章節

- [第 5 章：工具進階](./05-mcp-server-tools-advanced.md)——`CancellationToken` 注入
- [第 9 章：通知、進度、Logging 與 Completion](./09-notifications-logging-completion.md)——短時間回饋用進度，長時間脫鉤用 tasks
- [第 12 章：ASP.NET Core 託管 MCP Server](./12-aspnetcore-hosting.md)——stateless 部署，tasks 的最佳舞台
- [第 14 章：Sampling](./14-sampling.md)／[第 15 章：Elicitation](./15-elicitation.md)——`InputRequired` 狀態的來源
- [第 13 章：測試策略](./13-testing-strategy.md)——本章流程的實測環境

## 延伸閱讀

- 上游 `samples/LongRunningTasks`——`FileBasedMcpTaskStore` + stateless HTTP 的完整示範
- 上游 `tests/ModelContextProtocol.Tests/Server/ToolTaskSupportTests.cs`、`AutomaticInputRequiredStatusTests.cs`
- [MCP 規格 2025-11-25：Tasks](https://modelcontextprotocol.io/specification/)
- wiki 條目：[tasks](../mcp-csharp-sdk-kb/wiki/concepts/tasks.md)
