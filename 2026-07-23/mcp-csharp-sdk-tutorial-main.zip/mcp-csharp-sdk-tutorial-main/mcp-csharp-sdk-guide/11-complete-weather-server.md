# 第 11 章：實作範例——組裝一個完整的天氣 Server

> 對應 wiki 概念：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md)、[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md)
> 上游 sample：`samples/QuickstartWeatherServer`（本章程式碼基準）
> 基準版本：v1.4.0

## 本章目標

第 03 到 09 章每章給你一塊積木：builder、tools、prompts、resources、傳輸、通知。本章不引入新 API，而是把積木組裝成一個**從零建立、真的可以跑**的完整 MCP server——查詢美國國家氣象局（NWS）即時資料的天氣 server。讀完本章，你可以：

- 從 `dotnet new` 開始建立一個結構清楚的 MCP server 專案
- 在同一個 server 中同時提供 tools（查警報、查預報）與 resources（使用說明、州代碼查詢）
- 正確佈線 DI：把設定好的 `HttpClient` 注入工具方法
- 遵守 stdio server 的 logging 紀律（stdout 屬於協定，日誌走 stderr）
- 用第 10 章的 `McpClient` 寫一個煙霧測試，驗證整個 server 端到端可用

## 為什麼需要這個

單獨看每個 primitive 都不難，真正的問題出在組裝時：專案該怎麼切目錄？`HttpClient` 這種外部相依放哪裡、怎麼進到工具方法？哪些資料該做成 tool、哪些該做成 resource？寫完之後又怎麼確認整台 server 是好的？

官方 quickstart 的天氣 server 是回答這些問題的最佳範本——夠小（兩個工具、一個外部 API），又五臟俱全（DI、錯誤處理、logging、AOT）。本章以它為骨架，再加上第 07 章的 resources，讓三種決策（tool vs resource、DI 佈線、驗證方式）都在同一個專案裡現形。

## 核心概念

### 情境與設計決策

Server 對外提供四樣東西。決定「做成 tool 還是 resource」的判準只有一條：**會「做事」（呼叫外部 API、有延遲、有失敗可能）的是 tool；唯讀、可定址的資料是 resource**（第 07 章的分工表）：

| 功能 | Primitive | 理由 |
|------|-----------|------|
| 查某州的天氣警報 | Tool（`get_alerts`） | 呼叫 NWS API 的動作，由模型決定何時執行 |
| 依經緯度查天氣預報 | Tool（`get_forecast`） | 同上 |
| Server 使用說明 | Resource（`weather://usage`，直接資源） | 固定的唯讀文件 |
| 州代碼 → 州名查詢 | Resource（`weather://states/{code}`，範本資源） | 唯讀查表，以 URI 參數定址 |

### 專案結構

```text
WeatherServer/
├── WeatherServer.csproj
├── Program.cs               ← host + DI + MCP server 佈線
├── Tools/
│   ├── WeatherTools.cs      ← [McpServerToolType]：get_alerts / get_forecast
│   └── HttpClientExt.cs     ← HttpClient 小工具（讀 JSON）
└── Resources/
    └── WeatherResources.cs  ← [McpServerResourceType]：usage / states
```

依 primitive 分目錄是上游 samples 的慣例（`QuickstartWeatherServer/Tools/`、`EverythingServer/Tools|Resources|Prompts/`），小專案就用得上——每個目錄對應一種 attribute 型別，找東西不用想。

## 上手範例

### 第 1 步：建立專案

```bash
dotnet new console -n WeatherServer
cd WeatherServer
dotnet add package ModelContextProtocol   # stdio server 用主套件即可（第 02 章）
dotnet add package Microsoft.Extensions.Hosting
```

### 第 2 步：Program.cs——把所有佈線集中在一處

```csharp
// 依 samples/QuickstartWeatherServer/Program.cs，另加 WithResources 註冊
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Net.Http.Headers;
using WeatherServer.Resources;
using WeatherServer.Tools;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithTools<WeatherTools>()             // 指定類別註冊（第 04 章）
    .WithResources<WeatherResources>();    // 同一個 server 掛上 resources（第 07 章）

// stdio 模式下 stdout 屬於 JSON-RPC 協定——日誌全部導到 stderr
builder.Logging.AddConsole(options =>
{
    options.LogToStandardErrorThreshold = LogLevel.Trace;
});

// NWS API 要求請求帶 User-Agent 識別；設定好的 HttpClient 註冊成 singleton
using var httpClient = new HttpClient { BaseAddress = new Uri("https://api.weather.gov") };
httpClient.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("weather-tool", "1.0"));
builder.Services.AddSingleton(httpClient);

await builder.Build().RunAsync();
```

兩個值得停下來看的佈線決策：

- **logging 導 stderr**：`LogToStandardErrorThreshold = LogLevel.Trace` 表示「所有等級都寫到 stderr」。stdio 傳輸把 stdout 當 JSON-RPC 通道（第 08 章），任何混進 stdout 的文字都會讓 client 解析失敗。
- **singleton `HttpClient`**：與第 05 章 `IHttpClientFactory` 建構式注入的做法互補——quickstart 用「單一外部 API、設定集中」的最簡形式：把設定好 `BaseAddress` 與 `User-Agent` 的實例直接註冊進 DI，工具方法用**參數**接收。

### 第 3 步：工具——`Tools/WeatherTools.cs`

```csharp
// 取自 samples/QuickstartWeatherServer/Tools/WeatherTools.cs（原樣）
using ModelContextProtocol;
using ModelContextProtocol.Server;
using System.ComponentModel;
using System.Globalization;
using System.Text.Json;

namespace WeatherServer.Tools;

[McpServerToolType]
public sealed class WeatherTools
{
    [McpServerTool, Description("Get weather alerts for a US state.")]
    public static async Task<string> GetAlerts(
        HttpClient client,
        [Description("The US state to get alerts for. Use the 2 letter abbreviation for the state (e.g. NY).")] string state)
    {
        using var jsonDocument = await client.ReadJsonDocumentAsync($"/alerts/active/area/{state}");
        var jsonElement = jsonDocument.RootElement;
        var alerts = jsonElement.GetProperty("features").EnumerateArray();

        if (!alerts.Any())
        {
            return "No active alerts for this state.";
        }

        return string.Join("\n--\n", alerts.Select(alert =>
        {
            JsonElement properties = alert.GetProperty("properties");
            return $"""
                    Event: {properties.GetProperty("event").GetString()}
                    Area: {properties.GetProperty("areaDesc").GetString()}
                    Severity: {properties.GetProperty("severity").GetString()}
                    Description: {properties.GetProperty("description").GetString()}
                    Instruction: {properties.GetProperty("instruction").GetString()}
                    """;
        }));
    }

    [McpServerTool, Description("Get weather forecast for a location.")]
    public static async Task<string> GetForecast(
        HttpClient client,
        [Description("Latitude of the location.")] double latitude,
        [Description("Longitude of the location.")] double longitude)
    {
        var pointUrl = string.Create(CultureInfo.InvariantCulture, $"/points/{latitude},{longitude}");
        using var locationDocument = await client.ReadJsonDocumentAsync(pointUrl);
        var forecastUrl = locationDocument.RootElement.GetProperty("properties").GetProperty("forecast").GetString()
            ?? throw new McpException($"No forecast URL provided by {client.BaseAddress}points/{latitude},{longitude}");

        using var forecastDocument = await client.ReadJsonDocumentAsync(forecastUrl);
        var periods = forecastDocument.RootElement.GetProperty("properties").GetProperty("periods").EnumerateArray();

        return string.Join("\n---\n", periods.Select(period => $"""
                {period.GetProperty("name").GetString()}
                Temperature: {period.GetProperty("temperature").GetInt32()}°F
                Wind: {period.GetProperty("windSpeed").GetString()} {period.GetProperty("windDirection").GetString()}
                Forecast: {period.GetProperty("detailedForecast").GetString()}
                """));
    }
}
```

這支檔案把第 04–05 章的知識全部用上了：

- **`HttpClient client` 參數是 DI 注入，不是模型填的**——參數型別可從 DI 容器解析時，SDK 視為注入參數，不會出現在工具的 input schema（第 05 章的注入判定）。模型看到的 `get_alerts` 只有一個參數 `state`。
- **參數層 `[Description]`** 直接寫進 schema，教模型「用兩碼州代碼」——這行描述的品質決定模型第一次就填對的機率。
- **`McpException` 讓錯誤對模型可見**：NWS 沒回 forecast URL 時丟 `McpException`，SDK 包成 `IsError = true` 的工具結果、訊息原文給模型；若丟一般例外，模型只會看到通用錯誤訊息（第 05 章的兩層錯誤模型）。
- **工具名是 snake_case**：未指定 `Name` 時 `GetAlerts` 對外是 `get_alerts`、`GetForecast` 是 `get_forecast`（第 04 章）。

搭配的小工具，把「GET + 檢查狀態碼 + 解析 JSON」收成一行：

```csharp
// 取自 samples/QuickstartWeatherServer/Tools/HttpClientExt.cs（原樣）
using System.Text.Json;

namespace WeatherServer.Tools;

internal static class HttpClientExt
{
    public static async Task<JsonDocument> ReadJsonDocumentAsync(this HttpClient client, string requestUri)
    {
        using var response = await client.GetAsync(requestUri);
        response.EnsureSuccessStatusCode();
        return await JsonDocument.ParseAsync(await response.Content.ReadAsStreamAsync());
    }
}
```

### 第 4 步：資源——`Resources/WeatherResources.cs`

補上兩個 resource：一個直接資源（使用說明）、一個範本資源（州代碼查表）。這是本章自撰的部分，模式取自第 07 章驗證過的 `SimpleResourceType.cs`：

```csharp
using ModelContextProtocol;            // McpException
using ModelContextProtocol.Protocol;   // TextResourceContents
using ModelContextProtocol.Server;
using System.ComponentModel;

namespace WeatherServer.Resources;

[McpServerResourceType]
public class WeatherResources
{
    private static readonly Dictionary<string, string> States = new(StringComparer.OrdinalIgnoreCase)
    {
        ["NY"] = "New York",
        ["CA"] = "California",
        ["WA"] = "Washington",
        ["TX"] = "Texas",
        // ……其餘州略（示範用節錄——照抄本段查不到未列出的州，實作時請補齊 50 州或改查外部資料）
    };

    // 直接資源：固定 URI，回傳 string 由 SDK 自動包成 TextResourceContents
    [McpServerResource(UriTemplate = "weather://usage",
        Name = "Usage Guide", MimeType = "text/markdown")]
    [Description("How to use this weather server")]
    public static string UsageGuide() => """
        # Weather Server
        - `get_alerts`：查某州的天氣警報，state 用兩碼州代碼（見 weather://states/{code}）
        - `get_forecast`：以經緯度查天氣預報（美國境內）
        """;

    // 範本資源：URI 的 {code} 綁定到方法參數 code
    [McpServerResource(UriTemplate = "weather://states/{code}",
        Name = "State Info", MimeType = "text/plain")]
    [Description("Look up the full name of a US state by its 2-letter code")]
    public static TextResourceContents StateInfo(string code)
        => States.TryGetValue(code, out var name)
            ? new TextResourceContents
              {
                  Uri = $"weather://states/{code}",
                  MimeType = "text/plain",
                  Text = $"{code.ToUpperInvariant()} = {name}",
              }
            : throw new McpException($"Unknown state code: {code}");
}
```

注意 tool 與 resource 在這個專案裡的呼應：`get_alerts` 的 `[Description]` 提到州代碼，而 `weather://states/{code}` 正是查代碼的地方——resource 給資料、tool 做動作，兩者互相引用是設計完整 server 時常見的形狀。

> 📌 類別宣告成**一般 class（非 static）**，因為 Program.cs 用泛型 `WithResources<WeatherResources>()` 註冊，C# 不允許 static class 當型別引數（CS0718）；方法本身照樣可以是 static。

### 第 5 步：跑起來

```bash
dotnet run
```

stdio server 啟動後不會有任何「聽起來像啟動成功」的 stdout 輸出（stdout 是協定通道），只會在 stderr 看到 host 的日誌。它現在等著 client 從 stdin 送 JSON-RPC 進來。

### 第 6 步：用 client 做端到端驗證

用第 10 章的 `McpClient` 寫一個最小煙霧測試（另建一個 console 專案，或放測試專案裡）：

```csharp
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;   // TextContentBlock

var transport = new StdioClientTransport(new StdioClientTransportOptions
{
    Name = "WeatherServer",
    Command = "dotnet",
    Arguments = ["run", "--project", "/path/to/WeatherServer"],
});

await using var client = await McpClient.CreateAsync(transport);

// 1. 工具都在嗎？
foreach (var tool in await client.ListToolsAsync())
    Console.WriteLine($"{tool.Name}: {tool.Description}");
// 預期：get_alerts、get_forecast

// 2. 呼叫一次真的通嗎？
var result = await client.CallToolAsync(
    "get_alerts",
    new Dictionary<string, object?> { ["state"] = "NY" });
foreach (var block in result.Content)
    if (block is TextContentBlock text)
        Console.WriteLine(text.Text);

// 3. 資源讀得到嗎？
foreach (var res in await client.ListResourcesAsync())
    Console.WriteLine($"{res.Uri} — {res.Name}");           // weather://usage
var state = await client.ReadResourceAsync("weather://states/NY");
```

四個呼叫覆蓋了 server 的每一類出口：工具清單（schema 生成）、工具執行（DI 注入 + 外部 API）、直接資源、範本資源。這個「client 當測試器」的形狀到了第 13 章會升級成 in-memory transport 的正式整合測試。

## 進階用法

### 接上真正的 MCP host

驗證通過後，把 server 掛進任何支援 MCP 的 host（Claude Desktop、VS Code 等）都是同一組資訊：**command = `dotnet`、args = `["run", "--project", "<路徑>"]`**（或先 `dotnet publish` 再指向可執行檔，啟動更快）。各 host 的設定檔格式不同，但要填的就是煙霧測試裡 `StdioClientTransportOptions` 的那兩個欄位——host 本身就是一個 MCP client。

### Native AOT 發佈

上游 quickstart 的 csproj 開了 `<PublishAot>true</PublishAot>`——stdio server 是 AOT 的絕佳場景：單一原生執行檔、啟動快（host 每次對話都要啟動子行程）。第 20 章會講 AOT 相容的完整注意事項。

### 之後想換 HTTP？

`WithStdioServerTransport()` 換成 ASP.NET Core 的 `MapMcp` 佈線即可，tools/resources 定義完全不動（第 08 章的傳輸抽象、第 12 章實作）。但記得本 server 沒用到訂閱與主動通知，是 stateless-friendly 的形狀；若之後加上第 07 章的資源訂閱，HTTP 下就需要 stateful 模式。

## 常見錯誤

- **stdout 汙染**：在 stdio server 裡 `Console.WriteLine` 除錯，client 立刻解析失敗。日誌一律走 `ILogger` 且導 stderr（`LogToStandardErrorThreshold = LogLevel.Trace`）；要給模型看的訊息用工具回傳值。
- **忘記 User-Agent**：NWS API 拒絕匿名請求。自建 `HttpClient` 時記得 `DefaultRequestHeaders.UserAgent`——這也是「`HttpClient` 集中在 Program.cs 設定一次」的理由。
- **以為 `HttpClient` 參數是模型填的**：DI 可解析的參數型別不進 input schema，模型看不到也填不了。反過來說，若忘了 `AddSingleton(httpClient)`，工具呼叫時就會因解析不到而失敗——佈線與工具簽名要一起看。
- **煙霧測試的 `--project` 路徑寫錯**：`StdioClientTransport` 是啟動子行程，路徑相對於 client 的工作目錄；建議直接用絕對路徑，或改指向 publish 後的執行檔。
- **用方法名呼叫工具**：`CallToolAsync("GetAlerts", ...)` 找不到工具——對外名稱是 snake_case 的 `get_alerts`（第 04 章）。
- **static class 配泛型註冊**：`WithTools<T>()` / `WithResources<T>()` 的 `T` 不能是 static class——編譯期就報 CS0718。要保留 static class（如第 04 章的 `EchoTool`）就走 `WithToolsFromAssembly()` 掃描註冊；要用泛型指定類別，類別就宣告成一般 class。
- **把查表做成 tool**：州代碼查詢是唯讀資料，做成 resource 讓 client 可列出、可定址；tool 留給真正的動作。

## 相關章節

- 第 03 章：[mcp-server-builder](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-builder.md) — `AddMcpServer` 與 builder 佈線
- 第 04–05 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) — 工具定義、DI 注入、`McpException` 錯誤模型
- 第 07 章：[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md) — 直接/範本資源、`TextResourceContents`
- 第 08 章：[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md) — stdio 傳輸與 stdout 協定通道
- 第 10 章：[mcp-client](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client.md) — 本章煙霧測試的 client 寫法
- [第 13 章：測試策略](./13-testing-strategy.md) — in-memory transport 的正式整合測試

## 延伸閱讀

- 上游 sample：`samples/QuickstartWeatherServer/`（本章骨架）、`samples/EverythingServer/`（tools + resources + prompts + 訂閱的全功能示範）、`samples/QuickstartClient/`（client 端 quickstart）
- 官方概念文件：Getting Started（`raw/docs-conceptual/getting-started.md`）
