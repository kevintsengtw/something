# 第 12 章：ASP.NET Core 託管 MCP Server

> 對應 wiki 概念：[aspnetcore-hosting](../mcp-csharp-sdk-kb/wiki/concepts/aspnetcore-hosting.md)、[streamable-http-transport](../mcp-csharp-sdk-kb/wiki/concepts/streamable-http-transport.md)、[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md)
> 上游 API：`MapMcp`（`Microsoft.AspNetCore.Builder`）、`WithHttpTransport` / `HttpServerTransportOptions`（`ModelContextProtocol.AspNetCore`）
> 基準版本：v1.4.0

## 本章目標

第 11 章的天氣 server 是 stdio 的：host 啟動子行程、一對一使用。本章把**同一批 tools 與 resources 原封不動**搬上 ASP.NET Core，變成可以部署到雲端、服務多個 client 的 HTTP server。讀完本章，你可以：

- 用三步佈線（`AddMcpServer()` → `WithHttpTransport()` → `MapMcp()`）把 MCP server 掛進 ASP.NET Core
- 讓 MCP 端點與既有 middleware（CORS、驗證、OpenTelemetry）共存
- 從部署視角做 stateless / stateful 決策，並正確設定
- 用 `ConfigureSessionOptions` 做 per-session 客製（如依路由提供不同工具組）
- 認識 production 相關選項：idle session 管理、resumability、跨實例 session 遷移

## 為什麼需要這個

stdio 傳輸的天花板在第 08 章就看到了：一個 client 一個子行程、只能本機。要讓 MCP server 變成**服務**——多使用者、放在負載平衡器後面、進容器與雲端——就需要 HTTP。而 SDK 選擇把 HTTP 託管直接建在 ASP.NET Core 上，意味著你不用重學任何東西：路由、CORS、驗證、logging、health check、部署管線，全部沿用你既有的 ASP.NET Core 知識，MCP 端點只是路由表上多的一個端點。

這正是傳輸抽象的回報時刻：第 11 章的 `WeatherTools` / `WeatherResources` 一行都不用改。

## 核心概念

### 三步佈線

```csharp
using Microsoft.Extensions.DependencyInjection;  // AddMcpServer / WithHttpTransport
using Microsoft.AspNetCore.Builder;              // MapMcp

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddMcpServer()                    // ① DI 註冊（與 stdio 完全相同，第 03 章）
    .WithHttpTransport(o => o.Stateless = true)   // ② 啟用 HTTP 傳輸 + session 模式
    .WithTools<WeatherTools>();

var app = builder.Build();
app.MapMcp();                          // ③ 掛 MCP 端點到路由（預設根路徑）
app.Run();
```

與 stdio 版的差異只有兩處：host 從 `Host.CreateApplicationBuilder` 換成 `WebApplication.CreateBuilder`（需要 `dotnet new web` 專案與 **`ModelContextProtocol.AspNetCore`** 套件，第 02 章），傳輸從 `WithStdioServerTransport()` 換成 `WithHttpTransport()` + `MapMcp()`。

`MapMcp()` 可帶路由樣板（`app.MapMcp("/mcp")`），回傳值可繼續鏈 ASP.NET Core 的端點慣例（如下文的 `.RequireCors(...)`）。

### Session 模式：這裡做的是部署決策

概念與取捨表在第 08 章。部署時的判斷順序：

1. **Server 需要主動打 client 嗎**（訂閱通知、Sampling、Elicitation、Roots）？需要 → `Stateless = false`，且負載平衡要開 **session affinity**（同一 `Mcp-Session-Id` 進同一實例）。
2. **不需要** → 顯式 `Stateless = true`：每請求獨立、任意水平擴展、不用 affinity——官方建議的雲端預設。
3. 無論選哪個，**都顯式寫出來**。目前預設是 stateful（`false`），但官方文件建議不要依賴預設值。

第 11 章的天氣 server 只有 tools 與 resources 讀取、沒有訂閱，是標準的 stateless 形狀。

## 上手範例

### 把第 11 章的天氣 server 搬上 HTTP

```bash
dotnet new web -n WeatherServer.Http
cd WeatherServer.Http
dotnet add package ModelContextProtocol.AspNetCore   # 依賴主套件，會一併帶入
```

把第 11 章的 `Tools/`、`Resources/` 兩個目錄整個複製過來（一行都不改），Program.cs 換成：

```csharp
using System.Net.Http.Headers;
using WeatherServer.Resources;
using WeatherServer.Tools;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMcpServer()
    .WithHttpTransport(o => o.Stateless = true)   // 純 tools/resources，顯式無狀態
    .WithTools<WeatherTools>()
    .WithResources<WeatherResources>();

// HttpClient 佈線與第 11 章相同
using var httpClient = new HttpClient { BaseAddress = new Uri("https://api.weather.gov") };
httpClient.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("weather-tool", "1.0"));
builder.Services.AddSingleton(httpClient);

var app = builder.Build();
app.MapMcp();
app.Run();
```

注意消失的東西：stdio 版的「logging 導 stderr」紀律**不再需要**——HTTP 下 stdout 不是協定通道，ASP.NET Core 的 console logging 照常用。

### Client 端驗證

第 11 章的煙霧測試只要換傳輸（第 08、10 章的 `HttpClientTransport`）：

```csharp
using ModelContextProtocol.Client;

var transport = new HttpClientTransport(new HttpClientTransportOptions
{
    Endpoint = new Uri("http://localhost:5000"),      // dotnet run 顯示的位址
    TransportMode = HttpTransportMode.StreamableHttp, // 自己的新 server，直接鎖新協定
});
await using var client = await McpClient.CreateAsync(transport);

foreach (var tool in await client.ListToolsAsync())
    Console.WriteLine($"{tool.Name}: {tool.Description}");
// 其餘四步驗證與第 11 章相同
```

## 進階用法

### 與既有 middleware 共存：CORS 實例

瀏覽器內的 MCP client（如網頁版 host）屬跨來源請求，需要 CORS。官方 `AspNetCoreMcpServer` sample 示範了正確的最小開放：

```csharp
// 取自 samples/AspNetCoreMcpServer/Program.cs（節錄）
var allowedOrigins = builder.Configuration.GetSection("Mcp:AllowedOrigins").Get<string[]>() ?? ["http://localhost:5173"];

builder.Services.AddCors(options =>
{
    options.AddPolicy("McpBrowserClient", policy =>
    {
        policy.WithOrigins(allowedOrigins)
            .WithMethods("GET", "POST", "DELETE")
            .WithHeaders("Content-Type", "MCP-Protocol-Version", "Mcp-Session-Id")
            .WithExposedHeaders("Mcp-Session-Id");
    });
});

// ...
var app = builder.Build();
app.UseCors();
app.MapMcp().RequireCors("McpBrowserClient");
app.Run();
```

三個 MCP 特有的細節：允許標頭要含 `MCP-Protocol-Version` 與 `Mcp-Session-Id`（非 CORS safelist 標頭）；**`WithExposedHeaders("Mcp-Session-Id")`** 讓瀏覽器 client 讀得到 server 發的 session id（stateful 必要）；允許來源清單保持窄——sample 的註解特別強調寬鬆 CORS 會削弱安全。同一個 sample 也示範了 OpenTelemetry 佈線（`AddOpenTelemetry().WithTracing(...)`），MCP 端點的請求會被 ASP.NET Core instrumentation 正常追蹤。

### Per-session 客製：`ConfigureSessionOptions`

`HttpServerTransportOptions.ConfigureSessionOptions`（`Func<HttpContext, McpServerOptions, CancellationToken, Task>`）讓你在 session 初始化時拿著 `HttpContext` 客製該 session 的 `McpServerOptions`。官方 `AspNetCoreMcpPerSessionTools` sample 用它做「不同路由給不同工具組」：

```csharp
// 依 samples/AspNetCoreMcpPerSessionTools/Program.cs 節錄
builder.Services.AddMcpServer()
    .WithHttpTransport(options =>
    {
        options.Stateless = false;   // per-session 過濾需要 stateful
        options.ConfigureSessionOptions = async (httpContext, mcpOptions, cancellationToken) =>
        {
            var toolCategory = httpContext.Request.RouteValues["toolCategory"]?.ToString()?.ToLower() ?? "all";
            if (toolDictionary.TryGetValue(toolCategory, out var tools))
            {
                mcpOptions.Capabilities = new();
                mcpOptions.Capabilities.Tools = new();
                var toolCollection = mcpOptions.ToolCollection = [];
                foreach (var tool in tools)
                {
                    toolCollection.Add(tool);
                }
            }
        };
    });

var app = builder.Build();
app.MapMcp("/{toolCategory?}");   // 路由參數決定工具組：/clock、/calculator、/all
app.Run();
```

sample 中的工具組是啟動時用 `McpServerTool.Create(method, target: null, new McpServerToolCreateOptions())` 從反射建好的——這是 attribute 掃描之外**手動建構工具**的低階入口。兩個時機注意：stateful 下 callback 在 client 送 `initialize` 時每 session 跑一次；**stateless 下每個 HTTP 請求都跑一次**（每請求都是新 server context），callback 要夠便宜。

> 另有 `RunSessionHandler` 可完全接管 session 執行（第 07 章 EverythingServer 用它清訂閱表），但它標記 **Experimental（MCPEXP002）**，官方明確建議優先用 `ConfigureSessionOptions`。

### Production 選項（`HttpServerTransportOptions`，驗證自原始碼）

| 選項 | 預設 | 部署意義 |
|------|------|---------|
| `IdleTimeout` | 2 小時 | 閒置 session 回收（背景每 5 秒檢查）；被回收後 client 重連拿 404，需重建 session。client 可用開著的 GET 串流保活 |
| `MaxIdleSessionCount` | 10,000 | 記憶體閒置 session 上限；超過會記 critical error 並強制回收最舊的（即使未達 `IdleTimeout`）。有進行中請求的 session 不算閒置 |
| `EventStreamStore` | — | 設定 `ISseEventStreamStore`（.Core）啟用 **resumability**：SSE 事件存起來，client 斷線後帶 `Last-Event-ID` 重連可重播漏掉的事件。可直接設属性，或註冊進 DI 讓 server 自行解析 |
| `SessionMigrationHandler` | — | 設定 `ISessionMigrationHandler`（.AspNetCore）啟用**跨實例 session 遷移**：請求帶的 session id 在本實例查無時，先問 handler 能否從其他實例遷移過來——多實例 stateful 部署的逃生門。同樣可走 DI 解析 |
| `PerSessionExecutionContext` | `false` | 開啟後整個 session 的 handler 共用同一個 `ExecutionContext`（`AsyncLocal` 可跨請求存活），代價是 handler 內不能再用 `IHttpContextAccessor` |

### 安全：v1.4.0 的 session 使用者綁定

啟用 ASP.NET Core 驗證時，v1.4.0 起 Streamable HTTP 的 GET / POST / **DELETE** 都會檢查請求使用者與建立 session 的使用者是否相同，不符回 `403 Forbidden`——防止洩漏的 session id 被第三方拿來終止或劫持 session。allowed hosts（DNS rebinding 防護）與完整的授權配置屬第 18 章的範圍。

## 常見錯誤

- **多實例 stateful 沒開 session affinity**：第二個請求被派到另一台實例，session 查無、回 404，症狀是「時好時壞」。要嘛開 affinity、要嘛配 `SessionMigrationHandler`、要嘛改 stateless。
- **stateless 卻掛了需要回打 client 的功能**：Sampling、Elicitation、Roots、訂閱通知在 stateless 下全部停用（server 無法對 client 發請求）。這些能力（第 07、14、15 章）一律 stateful。
- **依賴 `Stateless` 預設值**：目前預設 stateful；部署前顯式寫出你要的模式。
- **CORS 忘了 expose `Mcp-Session-Id`**：瀏覽器 client 在 stateful 模式拿不到 session id，第二個請求開始全部失敗。`WithExposedHeaders("Mcp-Session-Id")` 不可省。
- **`EnableLegacySse = true` 配 `Stateless = true`**：啟動即 `InvalidOperationException`——legacy SSE 需要記憶體內 session 狀態，兩者互斥（第 08 章）。
- **在 `ConfigureSessionOptions` 裡做重活**：stateless 下它是**每請求**執行的。查資料庫、掃 assembly 這類工作放啟動時做好（像 per-session sample 的 `toolDictionary` 就是啟動時建好的）。
- **把 stdio 的 stderr logging 慣性帶過來**：HTTP 下不需要，正常用 ASP.NET Core logging 就好；反之把這章的 server 改回 stdio 時，記得把第 11 章的 stderr 紀律加回去。

## 相關章節

- 第 03 章：[mcp-server-builder](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-builder.md) — `AddMcpServer` 佈線基礎
- 第 08 章：[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md)、[streamable-http-transport](../mcp-csharp-sdk-kb/wiki/concepts/streamable-http-transport.md) — 傳輸與 session 模式的概念與取捨（本章的前置）
- 第 11 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md)、[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md) — 被本章搬上 HTTP 的天氣 server
- [第 13 章：測試策略](./13-testing-strategy.md) — in-memory transport 測試（不開 port 測 HTTP server 邏輯）
- [第 14 章：Sampling](./14-sampling.md) — 需要 stateful 的典型功能
- [第 18 章：Authorization 與傳輸安全](./18-authorization-and-security.md) — OAuth、host validation、CORS 深入
- [第 19 章：Docker 部署](./19-docker-deployment.md) — 容器化部署

## 延伸閱讀

- 上游 sample：`samples/AspNetCoreMcpServer/`（CORS + OpenTelemetry + stateful 全套）、`samples/AspNetCoreMcpPerSessionTools/`（路由參數 + per-session 工具組，README 有完整說明）
- 官方概念文件：Transports（`raw/docs-conceptual/transports.md`）、Stateless sessions（`raw/docs-conceptual/stateless.md`）
- 上游原始碼：`src/ModelContextProtocol.AspNetCore/HttpServerTransportOptions.cs`（本章選項表的直接依據，XML docs 詳盡）
