# 第 07 章：Resources（資源、URI Template、訂閱與通知）

> 對應 wiki 概念：[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md)
> 上游 API：`McpServerResource` / `[McpServerResource]` / `[McpServerResourceType]`（`ModelContextProtocol.Core`）、`WithResourcesFromAssembly` / `WithResources`（`ModelContextProtocol`）、`ResourceContents` / `TextResourceContents` / `BlobResourceContents` / `ResourceTemplate`（`ModelContextProtocol.Protocol`）
> 基準版本：v1.4.0

## 本章目標

Tools 是模型呼叫的「動作」、Prompts 是使用者挑選的「範本」，Resources 則是第三個 server primitive——以 **URI 定址的唯讀資料**（檔案、設定、資料庫記錄、API 回應）。讀完本章，你可以：

- 用 `[McpServerResourceType]` / `[McpServerResource]` 定義**直接資源**（固定 URI）與**範本資源**（URI 帶參數）
- 分辨文字（`TextResourceContents`）與二進位（`BlobResourceContents`）內容，並正確處理 base64
- 用 `WithResourcesFromAssembly()` / `WithResources<T>()` 註冊
- 讓 client 訂閱資源、在內容變更時由 server 主動送 `notifications/resources/updated` 通知
- 理解與 tools/prompts 對稱的參數注入模型

## 為什麼需要這個

回顧三個 primitive 的分工：

| Primitive | 誰決定使用 | 性質 | 典型場景 |
|-----------|-----------|------|---------|
| Tools（第 04–05 章） | **模型** 自主呼叫 | 動作、可有副作用 | 查天氣、算數、存取系統 |
| Prompts（第 06 章） | **使用者** 主動挑選 | 訊息範本 | code review、commit message 範本 |
| **Resources（本章）** | **應用/模型** 讀取 | 唯讀資料 | 檔案內容、設定值、log、資料庫記錄 |

工具「做事」，資源「給資料」。把唯讀資料做成 resource 而非 tool 的好處：client 可以**列出**所有可用資料並以一致方式讀取、資料有穩定的 URI 可引用、支援訂閱——client 對某個 URI 訂閱後，server 能在內容變更時主動通知，client 再決定要不要重新讀取。

## 核心概念

Resources 的定義方式與 tools/prompts **完全對稱**：

- 類別標 `[McpServerResourceType]`
- 方法標 `[McpServerResource]`
- 以 `WithResourcesFromAssembly()`（掃描組件）或 `WithResources<T>()`（指定類別）註冊

差別在多了 **URI 這一層**：每個 resource 由 `UriTemplate` 定址。範本不含參數（如 `config://app/version`）就是**直接資源**，client 用 `resources/list` 列得到；含 `{param}`（如 `config://app/{key}`）就是**範本資源**（對應 protocol 層的 `ResourceTemplate`），改由 `resources/templates/list` 列出，client 讀取時代入實際值，SDK 依 URI 比對並**把參數綁定到方法參數**。

> `McpServerResource`（`abstract class : IMcpServerPrimitive`）、`McpServerResourceAttribute`、`McpServerResourceTypeAttribute` 皆 namespace `ModelContextProtocol.Server`、套件 `.Core`；`ResourceContents` / `TextResourceContents` / `BlobResourceContents` / `ResourceTemplate` / `ReadResourceResult` 屬 namespace `ModelContextProtocol.Protocol`、套件 `.Core`。
>
> `[McpServerResource]` 可設定的屬性：`UriTemplate`、`Name`（預設取方法名）、`Title`、`MimeType`、`IconSource`。`UriTemplate` 若不指定，SDK 會從 `Name` 與方法參數名自動推導。

## 上手範例

### 直接資源：固定 URI、回傳 `string`

回傳 `string` 時 SDK 自動包成 `TextResourceContents`：

```csharp
// 取自 samples/EverythingServer/Resources/SimpleResourceType.cs（節錄）
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerResourceType]
public class SimpleResourceType
{
    [McpServerResource(UriTemplate = "test://direct/text/resource",
        Name = "Direct Text Resource", MimeType = "text/plain")]
    [Description("A direct text resource")]
    public static string DirectTextResource() => "This is a direct resource";
}
```

### 範本資源：URI 帶 `{id}`、精準控制內容型別

URI 中的 `{id}` 會綁定到同名方法參數；回傳 `ResourceContents` 子型別可自行決定文字或二進位：

```csharp
// 改寫自 samples/EverythingServer/Resources/SimpleResourceType.cs（二進位分支改用 FromBytes，見註解）
using ModelContextProtocol.Protocol;   // ResourceContents / TextResourceContents / BlobResourceContents
using ModelContextProtocol.Server;
using System.Text;

[McpServerResource(UriTemplate = "test://template/resource/{id}", Name = "Template Resource")]
[Description("A template resource with a numeric ID")]
public static ResourceContents TemplateResource(
    RequestContext<ReadResourceRequestParams> requestContext, int id)
{
    int index = id - 1;
    if ((uint)index >= ResourceGenerator.Resources.Count)
    {
        throw new NotSupportedException($"Unknown resource: {requestContext.Params.Uri}");
    }

    var resource = ResourceGenerator.Resources[index];
    return resource.MimeType == "text/plain" ?
        new TextResourceContents
        {
            Text = resource.Description!,
            MimeType = resource.MimeType,
            Uri = resource.Uri,
        } :
        // 原始 bytes 走 FromBytes 讓 SDK 做 base64 編碼——
        // 上游 sample 此處直接設定 Blob = Encoding.UTF8.GetBytes(...)，
        // 與 Blob「存 base64 編碼後 bytes」的文件語意矛盾，教學已改用工廠方法
        BlobResourceContents.FromBytes(
            Encoding.UTF8.GetBytes(resource.Description!),
            uri: resource.Uri,
            mimeType: resource.MimeType);
}
```

> 注意 `id` 是 `int`——URI 綁定的參數會做型別轉換；`requestContext` 是框架注入，不進 URI 綁定（見「參數注入」）。

### 註冊

```csharp
builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithResourcesFromAssembly();   // 掃描組件中所有 [McpServerResourceType]
```

## 進階用法

### 內容型別：文字 vs 二進位

`ResourceContents` 是抽象基底（`Uri`（required）、`MimeType`、`Meta` 三欄位），且建構子為 `private protected`——**你不能自訂子類別**，只有兩個密封實作：

| 型別 | 用途 | 內容欄位 |
|------|------|---------|
| `TextResourceContents` | 文字 | `required string Text` |
| `BlobResourceContents` | 二進位 | `required ReadOnlyMemory<byte> Blob`（**base64 編碼後**的 bytes） |

`BlobResourceContents.Blob` 存的是 base64 編碼結果，不是原始資料。手上是**原始 bytes** 時，用靜態工廠 `FromBytes` 讓 SDK 代勞編碼；讀取端則用 `DecodedData` 取回解碼後的原始資料（有快取）：

```csharp
byte[] imageBytes = File.ReadAllBytes("logo.png");
var blob = BlobResourceContents.FromBytes(imageBytes, uri: "images://logo", mimeType: "image/png");
// blob.Blob        → base64 編碼後的 bytes（序列化到協定用）
// blob.DecodedData → 原始 bytes
```

read-resource 的協定結果封裝為 `ReadResourceResult`（`sealed class : Result`，含 `IList<ResourceContents> Contents`）——一次讀取可回傳多段內容。

### 註冊的其他方式

| 擴充方法 | 用途 |
|---------|------|
| `WithResourcesFromAssembly()` | 掃描組件註冊所有 `[McpServerResourceType]` |
| `WithResources<T>()` | 指定單一類別 |
| `WithResources(IEnumerable<Type>)` / `WithResources(IEnumerable<McpServerResource>)` | 指定型別集合 / 實例集合 |

需要完全繞過 attribute 模型（例如資源清單來自資料庫）時，可改用低階 handler：`WithListResourcesHandler` / `WithReadResourceHandler` 直接接管 list/read 請求。

### 訂閱與變更通知

Resources 支援 client 對特定 URI 訂閱，server 在內容變更時主動通知。三個環節：

1. **client 訂閱/退訂**：送 `resources/subscribe` / `resources/unsubscribe`（參數型別 `SubscribeRequestParams` / `UnsubscribeRequestParams`）。
2. **server 接住訂閱**：SDK 不幫你記「誰訂了什麼」——用 `WithSubscribeToResourcesHandler` / `WithUnsubscribeFromResourcesHandler` 自行維護訂閱表，handler 回傳 `EmptyResult`。
3. **server 送通知**：內容變更時對訂閱中的 session 送 `NotificationMethods.ResourceUpdatedNotification`（`"notifications/resources/updated"`）。

```csharp
// 依 samples/EverythingServer/Program.cs 簡化
using ModelContextProtocol;            // McpException
using ModelContextProtocol.Protocol;   // EmptyResult / NotificationMethods / ResourceUpdatedNotificationParams
using System.Collections.Concurrent;

// 訂閱表：SessionId → 該 session 訂閱的 URI 集合
ConcurrentDictionary<string, ConcurrentDictionary<string, byte>> subscriptions = new();

builder.Services.AddMcpServer()
    .WithHttpTransport(options => options.Stateless = false)   // 主動通知需要 stateful
    .WithResources<SimpleResourceType>()
    .WithSubscribeToResourcesHandler(async (ctx, ct) =>
    {
        if (ctx.Server.SessionId is null)
        {
            throw new McpException("Cannot add subscription for server with null SessionId");
        }
        if (ctx.Params.Uri is { } uri)
        {
            // 上游原文在 RunSessionHandler 於 session 開始時先建好該 session 的字典；
            // 本簡化版未包含那段，改用 GetOrAdd 確保首次訂閱不會 KeyNotFoundException
            subscriptions.GetOrAdd(ctx.Server.SessionId, _ => new()).TryAdd(uri, 0);
        }
        return new EmptyResult();
    })
    .WithUnsubscribeFromResourcesHandler(async (ctx, ct) =>
    {
        if (ctx.Server.SessionId is null)
        {
            throw new McpException("Cannot remove subscription for server with null SessionId");
        }
        if (ctx.Params.Uri is { } uri
            && subscriptions.TryGetValue(ctx.Server.SessionId, out var sessionSubs))
        {
            sessionSubs.TryRemove(uri, out _);
        }
        return new EmptyResult();
    });
```

內容變更時，對有訂閱的 server 連線送通知：

```csharp
await server.SendNotificationAsync(
    NotificationMethods.ResourceUpdatedNotification,
    new ResourceUpdatedNotificationParams { Uri = "test://template/resource/1" },
    cancellationToken: ct);
```

另有**清單變更通知** `NotificationMethods.ResourceListChangedNotification`（`"notifications/resources/list_changed"`），在資源集合本身增減時使用。

> ⚠️ 主動通知需要 **stateful 模式（HTTP）或 stdio**——stateless HTTP 沒有可回送的 session 連線，`SessionId` 為 null。EverythingServer 也示範了在 session 結束時（`RunSessionHandler`）清掉該 session 的訂閱，避免洩漏。session 生命週期見第 08 章（[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md)）、通知機制總覽見第 09 章（[notifications-progress](../mcp-csharp-sdk-kb/wiki/concepts/notifications-progress.md)）。

### 參數注入（與 tools/prompts 對稱）

resource 方法除了 URI 綁定的參數，同樣能注入框架相依，這些**不會**出現在 URI template 中：

- `McpServer` — 當前連線的 server
- `RequestContext<ReadResourceRequestParams>` — 本次 read-resource 請求的 context（`ctx.Params.Uri` 可取原始 URI）
- `CancellationToken`
- DI 註冊的服務

判定機制與工具一致（見 [mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) 的「注入判定」）。

## 常見錯誤

- **把「做事」的東西做成 resource**：resource 是唯讀資料，讀取不應有副作用；要執行動作用 tool。
- **直接把原始 bytes 塞給 `Blob`**：`Blob` 期望的是 base64 編碼後的 bytes。原始資料請走 `BlobResourceContents.FromBytes(rawBytes, uri, mimeType)`。
- **在 stateless HTTP 下做訂閱**：`SessionId` 為 null、也沒有連線可回送通知。需要訂閱/通知就顯式 `options.Stateless = false`（或用 stdio）。
- **以為 SDK 會自動追蹤訂閱並送通知**：SDK 只幫你收 subscribe/unsubscribe 請求；訂閱表維護與變更偵測、送通知都是你的程式碼。
- **範本資源列不到**：範本資源在 `resources/templates/list`，不在 `resources/list`——client 端兩個清單都要看（見 [mcp-client-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-resources.md)）。
- **嘗試繼承 `ResourceContents`**：建構子是 `private protected`，只能用 `TextResourceContents` / `BlobResourceContents`。

## 相關章節

- 第 04–05 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) — 定義方式對稱、注入機制一致
- 第 06 章：[mcp-server-prompts](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-prompts.md) — 另一個 server primitive
- 第 08 章：[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md) — stateful vs stateless、SessionId 生命週期
- 第 09 章：[notifications-progress](../mcp-csharp-sdk-kb/wiki/concepts/notifications-progress.md) — `NotificationMethods` 常數與通知機制總覽
- 第 10 章：[mcp-client-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-resources.md) — client 端列出/讀取/訂閱資源

## 延伸閱讀

- 上游 sample：`samples/EverythingServer/Resources/SimpleResourceType.cs`（直接/範本資源）、`samples/EverythingServer/Program.cs`（訂閱表 + handler + session 清理完整示範）
- 官方概念文件：Resources（`raw/docs-conceptual/resources.md`）
