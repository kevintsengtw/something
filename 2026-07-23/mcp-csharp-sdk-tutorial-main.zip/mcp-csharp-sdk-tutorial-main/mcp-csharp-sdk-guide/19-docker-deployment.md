# 第 19 章：Docker 部署

> 對應 wiki 概念：[docker-deployment](../mcp-csharp-sdk-kb/wiki/concepts/docker-deployment.md)
> 上游 API：無新增（沿用第 12 章的 `ModelContextProtocol.AspNetCore`）
> 引入版本：不適用（DevOps 主題）

## 本章目標

- 用多階段 Dockerfile 把第 12 章的 HTTP MCP server 打包成映像
- 掌握容器化 MCP server 的四個基線：stateless、health check、非 root、正確的 port 佈局
- 用 `curl` 直接對容器打 MCP 協定請求做煙霧測試
- 知道 stdio server 什麼時候（不）需要容器化，以及怎麼讓 client 啟動容器裡的 stdio server

## 為什麼需要這個

教學到第 12 章為止，server 都跑在 `dotnet run` 裡。要交付到別人的環境——雲端、K8s、同事的機器——容器是 .NET 服務的標準載具：環境自包含、版本可釘死、orchestrator 能管生命週期。MCP server 沒有任何特殊之處讓它不適合容器，反而 stateless 模式（第 12 章）天生就是為「多副本、隨意路由」的容器化水平擴展設計的。

本章的成品經過完整實測：映像建置、容器啟動、health 探測、真實 MCP 協定往返，全部通過。

## 核心概念

### 什麼該容器化：HTTP 是主角，stdio 是例外

- **HTTP server（`.AspNetCore`）**：容器化的標準對象。一個映像，N 個副本，前面掛 load balancer。
- **stdio server**：通常**不需要**容器化——它由 client 以子行程啟動（第 4 章），生命週期跟著 client 走。要打包它的理由通常是「依賴太複雜」，做法見進階用法。

### 多階段建置：SDK 編譯，runtime 上場

.NET 官方映像分兩種：`sdk`（含編譯器，肥）與 `aspnet`（只有 runtime,瘦）。多階段建置用前者編譯、後者出貨，映像體積差好幾倍。另一個關鍵是 **layer 快取**：先只複製 `.csproj` 做 `dotnet restore`，原始碼沒動到套件清單時，重建可以跳過整個還原步驟。

### Stateless：容器化的天作之合

`Stateless = true`（第 12 章）讓每個請求自帶完整上下文，沒有 session 親和性需求——replicas 從 1 調到 10,load balancer 隨便路由都對。需要 sampling／elicitation 等雙向功能而必須 stateful 時，水平擴展就要 sticky session 或 `SessionMigrationHandler`（第 12 章 production 選項表）。

### 容器安全基線

- **非 root**：.NET 8+ 官方映像內建 `app` 使用者，一行 `USER $APP_UID` 啟用（本章實測 `whoami` 確認生效）
- **非特權 port**：容器內聽 8080（非 root 使用者綁不了 80），對外由 `-p` 或 Service 對映
- **TLS 終結在邊界**：容器內走 HTTP,TLS 交給 load balancer／反向代理；host 驗證與 CORS 依第 18 章設定

## 上手範例

### 步驟 1：讓 server 可被探測

在第 12 章的 `Program.cs` 加上 health endpoint（orchestrator 判斷「活著沒」的依據）：

```csharp
builder.Services.AddHealthChecks();

var app = builder.Build();

app.MapHealthChecks("/health");
app.MapMcp();

app.Run();
```

### 步驟 2：Dockerfile（多階段）

放在專案目錄，以下全文實測通過：

```dockerfile
# ── 建置階段：用 SDK 映像編譯與發佈 ─────────────────────────
FROM mcr.microsoft.com/dotnet/sdk:9.0 AS build
WORKDIR /src

# 先只複製專案檔還原套件——來源碼沒變時可吃 layer 快取
COPY WeatherServerHttp.csproj .
RUN dotnet restore

COPY . .
RUN dotnet publish -c Release -o /app/publish --no-restore

# ── 執行階段：只帶 ASP.NET Core runtime ────────────────────
FROM mcr.microsoft.com/dotnet/aspnet:9.0
WORKDIR /app
COPY --from=build /app/publish .

ENV ASPNETCORE_URLS=http://+:8080
EXPOSE 8080

# .NET 8+ 官方映像內建非 root 使用者
USER $APP_UID

ENTRYPOINT ["dotnet", "WeatherServerHttp.dll"]
```

### 步驟 3：建置、啟動、煙霧測試

```bash
docker build -t weather-mcp .
docker run -d --rm --name weather -p 18080:8080 weather-mcp

# 探測 health
curl http://localhost:18080/health
# → Healthy

# 直接打 MCP 協定（stateless 不需要 session 握手）
curl -X POST http://localhost:18080/ \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{
        "protocolVersion":"2025-11-25","capabilities":{},
        "clientInfo":{"name":"curl","version":"1.0"}}}'
```

實測回應（SSE 格式，Streamable HTTP 的標準回法）：

```text
event: message
data: {"result":{"protocolVersion":"2025-11-25","capabilities":{"logging":{},
"resources":{},"tools":{}},"serverInfo":{"name":"WeatherServerHttp",
"version":"1.0.0.0"}},"id":1,"jsonrpc":"2.0"}
```

（協定版本由兩端協商——SDK 也接受 `2025-06-18` 等較舊版本的請求並以同版本回應；本教學基準為 2025-11-25。）

再發 `tools/list` 可看到 `get_alerts`／`get_forecast`——第 11 章的工具原封不動地在容器裡服役。注意 `Accept` 標頭要同時帶 `application/json` 與 `text/event-stream`，這是 Streamable HTTP 的規格要求。

正式的 client 驗證與第 12 章相同：`HttpClientTransport` 指向 `http://localhost:18080/` 即可。

## 進階用法

### 組態進容器：環境變數

ASP.NET Core 組態天生支援環境變數，容器化後這是主要的組態通道：

```bash
docker run -d -p 18080:8080 \
  -e ASPNETCORE_ENVIRONMENT=Production \
  -e AllowedHosts="mcp.example.com" \
  weather-mcp
```

第 18 章的 `AllowedHosts`、CORS 允許清單這類「每個環境不同」的值，都適合走這條路，不要烤死在映像裡。

### 水平擴展的檢查清單

1. `Stateless = true`——不然要 sticky session 或 session 遷移（第 12 章）
2. 任務要跨副本可見的話，`IMcpTaskStore` 用共享的 durable 實作（第 17 章）
3. health endpoint 接上 orchestrator 的 liveness／readiness 探測
4. TLS、host 驗證、CORS 部署在正確的層（第 18 章：host 驗證做在接收原始 `Host` 標頭那層）

### 容器化 stdio server

真的要把 stdio server 裝進容器（例如它依賴一堆原生工具），關鍵是 **`-i`**（保持 stdin 開啟），由 client 把「啟動容器」當成啟動子行程：

```csharp
var transport = new StdioClientTransport(new()
{
    Command = "docker",
    Arguments = ["run", "-i", "--rm", "my-stdio-server:latest"],
    Name = "Containerized stdio server",
});
```

stdout／stdin 依然是協定通道（第 4 章的紀律不變），容器只是換了一層殼。

### 映像瘦身的下一步

`aspnet:9.0` 基底約略仍有百餘 MB。想再小，方向有 `runtime-deps` + self-contained、trimming,以及終極選項 **Native AOT**——那正是下一章（第 20 章）的主題。

## 常見錯誤

**1. Port 對不上**

三個地方要一致：`ASPNETCORE_URLS`（容器內聽誰）、`EXPOSE`（宣告）、`-p` 對映（對外）。漏設 `ASPNETCORE_URLS` 時 .NET 預設聽 8080（.NET 8+ 容器映像），但顯式寫出來最不容易錯。

**2. 測試請求缺 `Accept` 標頭**

Streamable HTTP 端點要求 `Accept: application/json, text/event-stream`。手打 `curl` 忘了它，會被 server 拒絕——這不是容器問題，是協定要求。

**3. 用 `sdk` 映像當執行環境**

單階段 Dockerfile 直接 `FROM sdk` 出貨，映像多出數百 MB 的編譯器與工具鏈。永遠多階段。

**4. stateful 模式配多副本，卻沒有 session 策略**

replica A 建的 session,請求被路由到 replica B → 404。要嘛 stateless,要嘛 sticky session／`SessionMigrationHandler`（第 12 章）。

**5. 把秘密烤進映像**

API key、連線字串進了 `docker build` 的 layer 就永遠在那裡。用環境變數或 orchestrator 的 secret 機制注入。

## 相關章節

- [第 12 章：ASP.NET Core 託管 MCP Server](./12-aspnetcore-hosting.md)——被容器化的主角；stateless 與 session 策略
- [第 17 章：Tasks](./17-tasks.md)——多副本下的共享 task store
- [第 18 章：Authorization 與傳輸安全](./18-authorization-and-security.md)——容器邊界外的 TLS／host 驗證／CORS
- [第 20 章：Native AOT 相容](./20-native-aot.md)——映像瘦身的終極選項

## 延伸閱讀

- [.NET 容器化官方文件](https://learn.microsoft.com/dotnet/core/docker/introduction)
- [.NET 容器映像與非 root 使用者](https://learn.microsoft.com/dotnet/core/docker/container-images)
- wiki 條目：[docker-deployment](../mcp-csharp-sdk-kb/wiki/concepts/docker-deployment.md)、[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md)、[transport-security](../mcp-csharp-sdk-kb/wiki/concepts/transport-security.md)
