# 第 13 章：測試策略

> 對應 wiki 概念：[testing-strategy](../mcp-csharp-sdk-kb/wiki/concepts/testing-strategy.md)、[in-memory-transport](../mcp-csharp-sdk-kb/wiki/concepts/in-memory-transport.md)
> 上游 API：`StreamServerTransport`、`StreamClientTransport`（皆屬 `ModelContextProtocol.Core`）
> 引入版本：v1.0.0

## 本章目標

- 理解 MCP server 的測試分層：工具方法的單元測試、走完整協定的整合測試
- 用 **in-memory transport**（`StreamServerTransport` ↔ `StreamClientTransport`）在同一個行程內對接 client 與 server，不開子行程、不佔 HTTP port
- 仿照上游 SDK 自己的測試基底類別，寫出可重用的 DI 版測試 fixture
- 用假的 `HttpMessageHandler` 替換外部相依，把第 11 章的天氣 Server 放上測試檯

## 為什麼需要這個

前面章節驗證 server 行為的方式，是啟動一個真的行程（第 4 章的 stdio、第 12 章的 HTTP），再用 client 去連。這在開發時很直觀，拿來當自動化測試卻很痛苦：

- **stdio**：測試要 spawn 子行程，關注點從「工具邏輯對不對」變成「行程有沒有起來、路徑對不對」
- **HTTP**：要佔用 port、要等 server ready，測試之間還可能互相干擾
- 兩者都慢，且失敗時難以分辨是環境問題還是程式問題

MCP C# SDK 的解法在第 8 章介紹過第三種傳輸：**in-memory transport**。client 與 server 在同一個行程內，透過一對記憶體中的 stream 直接對接——沒有行程、沒有網路，但走的是**完整的 MCP 協定**（初始化握手、`tools/list`、`tools/call`⋯⋯一步不少）。上游 SDK 自己的測試專案（`tests/ModelContextProtocol.Tests`）幾乎全部建立在這個模式上，是本章最好的背書。

搭配測試分層，就得到一個乾淨的策略：

| 層 | 測什麼 | 用什麼 | 速度 |
|----|--------|--------|------|
| 單元測試 | 工具方法本身的邏輯 | 直接呼叫方法（它就是普通 C# 方法） | 極快 |
| 整合測試 | 協定行為：工具名稱、schema、序列化、錯誤傳遞 | in-memory transport + 真實 `McpClient` | 快（毫秒級） |
| （選配）端對端 | 傳輸層本身：HTTP session、認證 | 真的起 server（第 12 章的方式） | 慢，少量即可 |

## 核心概念

### 工具方法就是普通方法

`[McpServerTool]` 標註的方法沒有任何魔法——它就是一個 C# 方法。第一層測試不需要 MCP 的任何基礎設施：

```csharp
Assert.Equal("Echo: hello", EchoTools.Echo("hello"));
```

工具邏輯的分支、邊界條件、例外情境，都應該在這一層用最便宜的方式測完。整合測試層只留給「協定上看得到的行為」。

### in-memory transport 的接線方式

in-memory 對接需要**兩條單向管線**（`System.IO.Pipelines.Pipe`），一條給「client → server」、一條給「server → client」。兩端 transport 各自拿到正確的讀寫端：

```text
                 clientToServerPipe
   client Writer ──────────────────▶ Reader server
                 serverToClientPipe
   client Reader ◀────────────────── Writer server
```

- **Server 端**用 `StreamServerTransport(inputStream, outputStream)`：input 接 `clientToServerPipe` 的讀端，output 接 `serverToClientPipe` 的寫端
- **Client 端**用 `StreamClientTransport(serverInput, serverOutput)`：參數名是站在「連到的那個 server」的角度——`serverInput` 是「寫進去會送到 server」的 stream（`clientToServerPipe` 的寫端），`serverOutput` 是「讀出來是 server 回應」的 stream（`serverToClientPipe` 的讀端）

一個 using 上的陷阱：兩個類別雖然都在 `ModelContextProtocol.Core` 套件，namespace 卻不同——`StreamServerTransport` 在 `ModelContextProtocol.Server`，而 `StreamClientTransport` 在 **`ModelContextProtocol.Protocol`**（原始碼檔案放在 `Client/` 目錄下，namespace 卻是 Protocol，找不到型別時先檢查這裡）。

### 兩種組裝 server 的方式

**低階組裝**：`McpServer.Create(transport, options)` 直接 new 出一個 server，工具用 `McpServerTool.Create` 從 delegate 建立，塞進 `McpServerOptions.ToolCollection`。不需要 DI 容器，適合最小化的協定測試（官方 `samples/InMemoryTransport` 用的就是這個）。

```csharp
// 圖譜驗證的簽名（src/ModelContextProtocol.Core/Server/McpServer.Methods.cs）
public static McpServer Create(
    ITransport transport,
    McpServerOptions serverOptions,
    ILoggerFactory? loggerFactory = null,
    IServiceProvider? serviceProvider = null)
```

**DI 組裝**：與正式程式相同的 `AddMcpServer()` 管線，但把 transport 換成 `WithStreamServerTransport(inputStream, outputStream)`（`ModelContextProtocol` 套件的 builder 擴充方法）。這是上游測試基底 `ClientServerTestBase` 的做法，好處是**測試環境與正式環境只差一行 transport 註冊**，DI 注入、`WithTools<T>()`、序列化行為全部原樣走一遍。

## 上手範例

### 步驟 1：建立測試專案

```bash
dotnet new xunit -n McpServerTests
cd McpServerTests
dotnet add package ModelContextProtocol --version 1.4.0
dotnet add package Microsoft.Extensions.DependencyInjection
dotnet add reference ../WeatherServer/WeatherServer.csproj   # 待測的 server 專案
```

`Microsoft.Extensions.DependencyInjection` 要明確加入——`ModelContextProtocol` 只帶進抽象介面，測試裡要用的 `ServiceCollection.BuildServiceProvider()` 與 `ServiceProvider` 型別在完整套件裡。

以下範例假設 server 專案有一個最小的工具類別（也可以直接測第 11 章的 `WeatherTools`，見進階用法）：

```csharp
using ModelContextProtocol;
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerToolType]
public sealed class EchoTools
{
    [McpServerTool, Description("Echoes the input back to the client.")]
    public static string Echo([Description("The message to echo.")] string message)
        => $"Echo: {message}";

    [McpServerTool, Description("Adds two integers.")]
    public static int Add(int a, int b) => a + b;

    [McpServerTool, Description("Always fails, for error-path testing.")]
    public static string Explode()
        => throw new McpException("boom: something went wrong");
}
```

### 步驟 2：單元測試層——直接呼叫

```csharp
public class EchoToolsUnitTests
{
    [Fact]
    public void Echo_附上前綴後原樣回傳()
    {
        Assert.Equal("Echo: hello", EchoTools.Echo("hello"));
    }

    [Theory]
    [InlineData(1, 2, 3)]
    [InlineData(-5, 5, 0)]
    public void Add_回傳兩數之和(int a, int b, int expected)
    {
        Assert.Equal(expected, EchoTools.Add(a, b));
    }
}
```

沒有 transport、沒有 client，就是方法呼叫。這層測試的量應該最大。

### 步驟 3：整合測試層——低階組裝版

把官方 `samples/InMemoryTransport` 的模式搬進 xunit：

```csharp
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;   // StreamClientTransport、TextContentBlock
using ModelContextProtocol.Server;     // McpServer、StreamServerTransport
using System.IO.Pipelines;

public class InMemoryEndToEndTests
{
    [Fact]
    public async Task 端對端_列出並呼叫Echo工具()
    {
        Pipe clientToServerPipe = new(), serverToClientPipe = new();

        // Server：input 接 client→server 的讀端，output 接 server→client 的寫端
        await using McpServer server = McpServer.Create(
            new StreamServerTransport(
                clientToServerPipe.Reader.AsStream(),
                serverToClientPipe.Writer.AsStream()),
            new McpServerOptions
            {
                ToolCollection = [McpServerTool.Create(
                    (string message) => $"Echo: {message}",
                    new() { Name = "echo" })]
            });
        _ = server.RunAsync();   // fire-and-forget：讓 server 在背景收訊息

        // Client：兩條 pipe 換成另一端
        await using McpClient client = await McpClient.CreateAsync(
            new StreamClientTransport(
                serverInput: clientToServerPipe.Writer.AsStream(),
                serverOutput: serverToClientPipe.Reader.AsStream()));

        var tools = await client.ListToolsAsync();
        Assert.Contains(tools, t => t.Name == "echo");

        var result = await client.CallToolAsync("echo",
            new Dictionary<string, object?> { ["message"] = "hello" });

        var text = Assert.IsType<TextContentBlock>(result.Content[0]);
        Assert.Equal("Echo: hello", text.Text);
    }
}
```

`McpClient.CreateAsync` 一如往常會做完整的 initialize 握手（第 10 章），只是這次訊息在記憶體裡繞了一圈就回來——整個測試毫秒級完成。

## 進階用法

### 可重用的 DI 版測試基底

一個測試類別裡每個測試都要接管線、起 server、清資源，值得抽成基底類別。上游 SDK 的 `tests/ModelContextProtocol.Tests/ClientServerTestBase.cs` 正是這個形狀，以下是去掉 xunit v3 專屬 API 後的簡化版：

```csharp
using Microsoft.Extensions.DependencyInjection;
using ModelContextProtocol.Client;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;
using System.IO.Pipelines;

public abstract class McpServerTestBase : IAsyncDisposable
{
    private readonly Pipe _clientToServerPipe = new();
    private readonly Pipe _serverToClientPipe = new();
    private readonly CancellationTokenSource _cts = new();
    private readonly ServiceProvider _serviceProvider;
    private readonly Task _serverTask;

    protected McpServerTestBase()
    {
        var services = new ServiceCollection();
        var builder = services.AddMcpServer()
            .WithStreamServerTransport(
                _clientToServerPipe.Reader.AsStream(),
                _serverToClientPipe.Writer.AsStream());

        ConfigureServices(services, builder);

        _serviceProvider = services.BuildServiceProvider(validateScopes: true);
        Server = _serviceProvider.GetRequiredService<McpServer>();
        _serverTask = Server.RunAsync(_cts.Token);
    }

    protected McpServer Server { get; }

    // 子類別在此註冊工具與（假）相依服務
    protected abstract void ConfigureServices(
        ServiceCollection services, IMcpServerBuilder builder);

    protected async Task<McpClient> CreateClientAsync()
        => await McpClient.CreateAsync(
            new StreamClientTransport(
                serverInput: _clientToServerPipe.Writer.AsStream(),
                serverOutput: _serverToClientPipe.Reader.AsStream()));

    public async ValueTask DisposeAsync()
    {
        await _cts.CancelAsync();
        _clientToServerPipe.Writer.Complete();
        _serverToClientPipe.Writer.Complete();
        await _serverTask;
        await _serviceProvider.DisposeAsync();
        _cts.Dispose();
    }
}
```

幾個設計重點：

- **與正式程式同一條組裝管線**：`AddMcpServer()` + `WithTools<T>()`，只有 transport 一行不同，測到的就是正式行為（包含第 4 章的 snake_case 命名、第 5 章的 DI 注入）
- **xunit 每個測試方法都會 new 一個測試類別實例**，所以每個測試拿到的是全新的 server 與管線，互不干擾
- **清理順序**：先取消 server 的 `RunAsync`，再 `Complete()` 兩條管線的寫端，最後等 `_serverTask` 結束——順序錯了測試會掛在 Dispose

用起來像這樣：

```csharp
public class HostedEchoServerTests : McpServerTestBase
{
    protected override void ConfigureServices(
        ServiceCollection services, IMcpServerBuilder builder)
    {
        builder.WithTools<EchoTools>();
    }

    [Fact]
    public async Task 工具名稱依預設轉為snake_case()
    {
        await using var client = await CreateClientAsync();

        var tools = await client.ListToolsAsync();

        Assert.Contains(tools, t => t.Name == "echo");
        Assert.Contains(tools, t => t.Name == "add");
    }

    [Fact]
    public async Task 工具擲出McpException_client收到IsError與訊息()
    {
        await using var client = await CreateClientAsync();

        var result = await client.CallToolAsync("explode");

        Assert.True(result.IsError);
        var text = Assert.IsType<TextContentBlock>(result.Content[0]);
        Assert.Contains("boom", text.Text);
    }
}
```

第二個測試驗證的是第 5 章介紹過的錯誤語意：工具擲出 `McpException` 時，server 不會讓連線炸掉，而是回一個 `IsError = true` 的結果，且 `McpException` 的訊息會原文送到 client（一般例外則只會得到通用錯誤訊息，不洩漏內部細節）。這種「跨越協定的行為」正是整合測試層存在的理由——單元測試只能看到例外被丟出，看不到 client 端收到什麼。

### 替換外部相依：把第 11 章的天氣 Server 放上測試檯

第 11 章的 `WeatherTools.GetAlerts(HttpClient client, string state)` 透過 DI 拿到 `HttpClient`。測試裡把 handler 換成假的，就能在不出網路的情況下端對端驗證：

```csharp
using System.Net;
using System.Text;

public class WeatherServerIntegrationTests : McpServerTestBase
{
    private const string AlertsJson = """
        {
          "features": [
            {
              "properties": {
                "event": "Severe Thunderstorm Warning",
                "areaDesc": "Jefferson, KY",
                "severity": "Severe",
                "description": "A severe thunderstorm was located near Louisville.",
                "instruction": "Move to an interior room."
              }
            }
          ]
        }
        """;

    protected override void ConfigureServices(
        ServiceCollection services, IMcpServerBuilder builder)
    {
        builder.WithTools<WeatherTools>();

        // 與第 11 章相同的註冊方式，但 handler 換成假的——測試不出網路
        services.AddSingleton(new HttpClient(new StubHttpMessageHandler(request =>
        {
            Assert.Equal("/alerts/active/area/KY", request.RequestUri?.AbsolutePath);
            return new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(AlertsJson, Encoding.UTF8, "application/json"),
            };
        }))
        {
            BaseAddress = new Uri("https://api.weather.gov"),
        });
    }

    [Fact]
    public async Task get_alerts_不出網路即可端對端驗證()
    {
        await using var client = await CreateClientAsync();

        var result = await client.CallToolAsync("get_alerts",
            new Dictionary<string, object?> { ["state"] = "KY" });

        var text = Assert.IsType<TextContentBlock>(result.Content[0]);
        Assert.Contains("Severe Thunderstorm Warning", text.Text);
        Assert.Contains("Jefferson, KY", text.Text);
    }
}

// 極簡 stub：把 HTTP 回應寫死在測試裡
public sealed class StubHttpMessageHandler(
    Func<HttpRequestMessage, HttpResponseMessage> responder) : HttpMessageHandler
{
    protected override Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request, CancellationToken cancellationToken)
        => Task.FromResult(responder(request));
}
```

這個測試同時驗證了：DI 注入把假的 `HttpClient` 送進工具方法、`GetAlerts` 對 NWS JSON 的解析邏輯、參數與回傳值走過完整的 MCP 序列化。而它跑起來只要幾毫秒，CI 上也不會因為外部 API 抖動而 flaky。

### 上游測試專案是最大的範例庫

`tests/ModelContextProtocol.Tests` 有數百個測試全數建立在這個模式上——想知道某個功能（訂閱、通知、sampling⋯⋯）「官方認可的測法」，直接去找對應的測試類別即可。注意上游用的是 xunit v3（`TestContext.Current.CancellationToken`）與 C# preview 語法（`field` 關鍵字），照抄時需要改寫成你專案的工具鏈支援的寫法（本章範例已改寫為 xunit 2.x 可用的形式）。

另外兩個官方 sample 也值得對照：

- `samples/InMemoryTransport`：本章「低階組裝版」的出處
- `samples/TestServerWithHosting`：用 `Host.CreateApplicationBuilder` + Serilog 檔案日誌託管的測試用 stdio server（第 3 章的架構加上實務 logging 配置）

## 常見錯誤

**1. 管線方向接反 → `McpClient.CreateAsync` 永遠不回來**

```csharp
// ❌ client 的 serverInput 接到了「client→server 管線的讀端」
new StreamClientTransport(
    serverInput: clientToServerPipe.Reader.AsStream(),   // 應該是 Writer
    serverOutput: serverToClientPipe.Reader.AsStream());
```

initialize 請求送進了沒人讀的 stream，握手無回應，測試卡死直到逾時。記住口訣：**client 拿兩條管線的「另一端」**——server 讀的那條 client 寫、server 寫的那條 client 讀。

**2. 忘了呼叫 `server.RunAsync()`**

`McpServer.Create` 只是建立物件，不會開始收訊息。沒有 `_ = server.RunAsync();` 這行，症狀與方向接反一樣：client 握手卡住。也不要 `await server.RunAsync()`——它會一直跑到 transport 關閉為止，直接 await 就永遠走不到 client 那行。

**3. `StreamClientTransport` 找不到——using 錯 namespace**

檔案在 `Client/` 目錄，namespace 卻是 `ModelContextProtocol.Protocol`。`using ModelContextProtocol.Client;` 是不夠的，需要 `using ModelContextProtocol.Protocol;`。

**4. `ServiceProvider` / `BuildServiceProvider` 找不到型別**

`ModelContextProtocol` 套件只透過抽象介面相依 DI，測試專案要自己 `dotnet add package Microsoft.Extensions.DependencyInjection`（本章步驟 1 已包含；漏掉時的錯誤訊息是 CS0246 找不到 `ServiceProvider`）。

**5. 測試在 Dispose 階段掛住**

清理順序必須是：取消 token → `Complete()` 兩條管線的寫端 → 等 server task。若只 cancel 不 Complete 管線，server 的讀迴圈可能還在等資料；若先等 task 再 Complete，就死鎖了。照抄本章 `DisposeAsync` 的順序即可（該順序來自上游 `ClientServerTestBase`）。

## 相關章節

- [第 3 章：第一個 MCP Server（Hosting / DI 架構）](./03-mcp-server-builder.md)——`AddMcpServer()` 管線，本章 DI 版 fixture 的基礎
- [第 5 章：工具進階](./05-mcp-server-tools-advanced.md)——DI 注入與 `McpException` 錯誤語意，本章在協定層驗證了它們
- [第 8 章：傳輸層總覽與 Sessions](./08-transports-and-sessions.md)——in-memory 在三種傳輸中的定位
- [第 10 章：建立 MCP Client](./10-mcp-client.md)——`McpClient.CreateAsync` / `ListToolsAsync` / `CallToolAsync` 的完整用法
- [第 11 章：實作範例——組裝一個完整的天氣 Server](./11-complete-weather-server.md)——本章「替換外部相依」小節的待測物

## 延伸閱讀

- 上游 `samples/InMemoryTransport`——低階組裝的最小示範
- 上游 `samples/TestServerWithHosting`——Generic Host 託管的測試用 server
- 上游 `tests/ModelContextProtocol.Tests/ClientServerTestBase.cs`——官方測試基底類別原文
- wiki 條目：[testing-strategy](../mcp-csharp-sdk-kb/wiki/concepts/testing-strategy.md)、[in-memory-transport](../mcp-csharp-sdk-kb/wiki/concepts/in-memory-transport.md)

