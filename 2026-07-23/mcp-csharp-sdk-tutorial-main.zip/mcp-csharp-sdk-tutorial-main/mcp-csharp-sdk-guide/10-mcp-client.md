# 第 10 章：建立 MCP Client

> 對應 wiki 概念：[mcp-client](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client.md)、[mcp-client-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-tools.md)、[mcp-client-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-resources.md)
> 上游 API：`McpClient` / `McpClientTool` / `McpClientResource` / `McpClientPrompt`（`ModelContextProtocol.Client`，套件 `.Core`）
> 基準版本：v1.4.0

## 本章目標

前九章都站在 server 這一側；本章換到對面，用 SDK 寫一個 **MCP client**。讀完本章，你可以：

- 用 `McpClient.CreateAsync(transport)` 連上任何相容的 MCP server（不限本 SDK 寫的）
- 列出與呼叫工具（`ListToolsAsync` / `CallToolAsync`），解讀 `CallToolResult`
- 列出、讀取、訂閱資源（`ListResourcesAsync` / `ReadResourceAsync` / `SubscribeToResourceAsync`）
- 列出與取用 prompts（`ListPromptsAsync` / `GetPromptAsync`）
- 用 `RegisterNotificationHandler` 接住 server 的清單變更等通知

## 為什麼需要這個

MCP 是協定，不是框架——client 端只認協定，**server 是誰寫的無所謂**。你可以用 C# client 連 npm 生態的 server（如 `@modelcontextprotocol/server-everything`）、Python 寫的 server、或前幾章自己寫的 server。會寫 client 也有實際用途：

- **整合**：把任意 MCP server 的工具餵給 LLM（`McpClientTool : AIFunction`，第 16 章）
- **測試**：對自己的 server 做端對端驗證（第 13 章）
- **工具鏈**：寫 CLI/服務去消費既有 MCP server 的能力

## 核心概念

### 一個入口、三步驟

1. **選傳輸**：`StdioClientTransport`（啟動子行程）或 `HttpClientTransport`（連遠端），皆實作 `IClientTransport`（第 08 章）。
2. **建立連線**：`McpClient.CreateAsync(transport)`——建立、初始化握手、能力協商一次完成。
3. **操作 primitives**：`McpClient` 的實例方法對應 server 三種 primitive。

| Server 端（你在 ch04–07 定義的） | Client 端取用方法 | 回傳項目型別 |
|--------------------------------|-----------------|-------------|
| Tools | `ListToolsAsync()` / `CallToolAsync(name, args)` | `McpClientTool` / `CallToolResult` |
| Prompts | `ListPromptsAsync()` / `GetPromptAsync(name, args)` | `McpClientPrompt` / `GetPromptResult` |
| Resources | `ListResourcesAsync()` / `ListResourceTemplatesAsync()` / `ReadResourceAsync(uri)` | `McpClientResource` / `McpClientResourceTemplate` / `ReadResourceResult` |

> 建立入口是 `McpClient.CreateAsync`——**不是** `McpClientFactory.CreateAsync`。舊版的 `McpClientFactory` 已從 SDK 移除，網路上較舊的範例還在用它，照抄會編譯失敗（[附錄 B](./appendix-b-migration.md)）。

驗證過的 `CreateAsync` 簽名：

```csharp
public static Task<McpClient> CreateAsync(
    IClientTransport clientTransport,
    McpClientOptions? clientOptions = null,
    ILoggerFactory? loggerFactory = null,
    CancellationToken cancellationToken = default)
```

## 上手範例

### 連線並列出/呼叫工具

```csharp
using ModelContextProtocol.Client;

var transport = new StdioClientTransport(new StdioClientTransportOptions
{
    Name = "Everything",
    Command = "npx",
    Arguments = ["-y", "@modelcontextprotocol/server-everything"],
});

await using var client = await McpClient.CreateAsync(transport);

// 列出工具
foreach (var tool in await client.ListToolsAsync())
    Console.WriteLine($"{tool.Name}: {tool.Description}");

// 呼叫工具
var result = await client.CallToolAsync(
    "echo",
    new Dictionary<string, object?> { ["message"] = "Hello MCP!" });
```

連 HTTP server 只是換傳輸，其餘完全相同：

```csharp
var transport = new HttpClientTransport(new HttpClientTransportOptions
{
    Endpoint = new Uri("https://my-mcp-server.example.com/mcp"),
    TransportMode = HttpTransportMode.StreamableHttp,
});
await using var client = await McpClient.CreateAsync(transport);
```

### 解讀 `CallToolResult`

工具回傳的是 content block 清單（第 05 章的 server 端視角），client 端逐塊處理：

```csharp
using ModelContextProtocol.Protocol;   // TextContentBlock

foreach (var block in result.Content)
{
    if (block is TextContentBlock text)
        Console.WriteLine(text.Text);
}
```

### 列出與讀取資源

```csharp
using ModelContextProtocol.Protocol;   // ResourceContents / TextResourceContents

// 直接資源在 resources/list
foreach (McpClientResource res in await client.ListResourcesAsync())
    Console.WriteLine($"{res.Uri} — {res.Name}");

// 範本資源在另一個清單（第 07 章的區分，client 端兩邊都要看）
foreach (McpClientResourceTemplate tpl in await client.ListResourceTemplatesAsync())
    Console.WriteLine($"{tpl.UriTemplate} — {tpl.Name}");

// 讀取（範本資源代入實際值後的 URI）
var read = await client.ReadResourceAsync("test://template/resource/1");
foreach (ResourceContents content in read.Contents)
{
    if (content is TextResourceContents text)
        Console.WriteLine(text.Text);
}
```

### 列出與取用 prompts

```csharp
foreach (McpClientPrompt prompt in await client.ListPromptsAsync())
    Console.WriteLine($"{prompt.Name}: {prompt.Description}");

var promptResult = await client.GetPromptAsync(
    "complex_prompt",
    new Dictionary<string, object?> { ["temperature"] = 1, ["style"] = "formal" });
// 注意：complex_prompt 的 temperature 參數在第 06 章定義為 int，傳浮點數會對不上 schema
// promptResult.Messages 即第 06 章 server 端組出的訊息
```

## 進階用法

### 訂閱資源與接收通知

第 07 章 server 端的訂閱機制，client 端這樣消費——`SubscribeToResourceAsync` 的多載可直接帶 handler，回傳 `IAsyncDisposable`，dispose 即退訂：

```csharp
// 取自 docs/concepts/resources/resources.md
IAsyncDisposable subscription = await client.SubscribeToResourceAsync(
    "config://app/settings",
    async (notification, cancellationToken) =>
    {
        Console.WriteLine($"Resource updated: {notification.Uri}");
        var updated = await client.ReadResourceAsync(notification.Uri, cancellationToken: cancellationToken);
        // 處理更新後的內容……
    });

// 不再需要時退訂
await subscription.DisposeAsync();
```

也可以無 handler 訂閱（`SubscribeToResourceAsync(uri)` / `UnsubscribeFromResourceAsync(uri)`），搭配全域通知處理器。

### 全域通知處理器

`RegisterNotificationHandler`（定義在 `McpSession`，client/server 皆可用）按方法名稱掛 handler，配 `NotificationMethods` 常數（第 09 章的表）：

```csharp
// 取自 docs/concepts/resources/resources.md
client.RegisterNotificationHandler(
    NotificationMethods.ResourceListChangedNotification,
    async (notification, cancellationToken) =>
    {
        var updatedResources = await client.ListResourcesAsync(cancellationToken: cancellationToken);
        Console.WriteLine($"Resource list updated. {updatedResources.Count} resources available.");
    });
```

工具/prompt 清單變更（`ToolListChangedNotification` / `PromptListChangedNotification`）同理。

### 其他實用方法

- **`CallToolAsync(..., progress: ...)`**：接收工具進度（第 09 章已示範）。
- **`PingAsync()`**：健康檢查。
- **`McpClientOptions`**：設定 `ClientInfo`（名稱/版本）等 client 身分資訊。
- **連線錯誤**：HTTP/SSE 連線失敗自 v1.3.0 起丟 `ClientTransportClosedException`（繼承 `IOException`），可精準 catch。
- **`McpClientTool : AIFunction`**：工具清單可直接放進 `Microsoft.Extensions.AI` 的 `ChatOptions.Tools` 給 `IChatClient` 做 function calling——這是第 16 章的主題，此處先埋個伏筆。

## 常見錯誤

- **照舊範例用 `McpClientFactory.CreateAsync`**：該型別已移除，入口是 `McpClient.CreateAsync`。這是本教學 drift 檢查的經典案例（[附錄 B](./appendix-b-migration.md)）。
- **忘了 `await using` / dispose client**：stdio 傳輸下 client 管理著子行程，不 dispose 會留下孤兒行程（`ShutdownTimeout` 預設 5 秒，見第 08 章）。
- **只看 `resources/list` 找不到範本資源**：範本資源在 `ListResourceTemplatesAsync()`，兩個清單要分開查（第 07 章的老朋友）。
- **對 stateless HTTP server 訂閱資源**：server 端 `SessionId` 為 null、無法回送通知，訂閱不會有效果（第 08 章的表）。
- **工具參數字典的型別對不上 schema**：`CallToolAsync` 的參數是 `Dictionary<string, object?>`，鍵名與型別要符合 `tool.JsonSchema` 宣告，錯了會拿到 `IsError = true` 的 `CallToolResult` 或協定錯誤。
- **假設 server 一定支援所有 primitive**：`ListPromptsAsync` 對沒有 prompts capability 的 server 會失敗；先看 `CreateAsync` 握手後的 server capabilities 再呼叫。

## 相關章節

- 第 04–05 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md) — 這些工具在 server 端怎麼定義
- 第 06 章：[mcp-server-prompts](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-prompts.md) — `GetPromptResult` 的 server 端來源
- 第 07 章：[mcp-server-resources](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-resources.md) — 直接/範本資源與訂閱的 server 端
- 第 08 章：[stdio-transport](../mcp-csharp-sdk-kb/wiki/concepts/stdio-transport.md)、[streamable-http-transport](../mcp-csharp-sdk-kb/wiki/concepts/streamable-http-transport.md)、[sessions](../mcp-csharp-sdk-kb/wiki/concepts/sessions.md) — client 傳輸選擇
- 第 09 章：[notifications-progress](../mcp-csharp-sdk-kb/wiki/concepts/notifications-progress.md) — 進度接收與通知常數
- 第 13 章：[testing-strategy](../mcp-csharp-sdk-kb/wiki/concepts/testing-strategy.md) — 用 in-memory transport 對自己的 server 做 client 測試
- 第 16 章：[mef-ai-integration](../mcp-csharp-sdk-kb/wiki/concepts/mef-ai-integration.md)、[mcp-client-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-tools.md) — 把工具餵給 `IChatClient`

## 延伸閱讀

- 官方概念文件：Getting Started（`raw/docs-conceptual/getting-started.md`）、Resources（`raw/docs-conceptual/resources.md`，client 訂閱段落）
- 上游 sample：`docs/concepts/progress/samples/client/`（完整可跑的 client 程式）
