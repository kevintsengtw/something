# MCP C# SDK 繁體中文教學

> 基準版本：**ModelContextProtocol v1.4.0**
> 最後更新：2026-07-16
> 狀態：✅ **具備發佈條件**——第 01–20 章＋附錄 A/B/C 已通過第二意見審查並完成處置（2026-07-16 結案，見 [reviews/](./reviews/)）；附錄 D/E 為第二輪工作，不阻塞本輪發布（見 [PLAN-beginner-tutorial.md](./PLAN-beginner-tutorial.md)）

以繁體中文撰寫的 MCP C# SDK 教學本體。新章節透過 Pipeline D（Codex `$draft-chapter`；Claude Code legacy `/draft-chapter`）草擬，人工 review 後移入本目錄。

---

## 教學目錄

> 第 01–20 章與附錄 A/B/C 均已撰寫並連結；`$regenerate-toc` 只在人工移入新內容後維護此表。

### 第一部分：認識 MCP 與 SDK
| 章節 | 標題 | 說明 |
|------|------|------|
| 01 | [什麼是 MCP（Model Context Protocol）](./01-what-is-mcp.md) | 協定概念、M×N 整合問題、三套件關係 |
| 02 | [SDK 三套件選擇與安裝](./02-nuget-packages.md) | Core / ModelContextProtocol / AspNetCore |

### 第二部分：建立 MCP Server
| 章節 | 標題 | 說明 |
|------|------|------|
| 03 | [第一個 MCP Server（Hosting / DI 架構）](./03-mcp-server-builder.md) | Hosting / DI 架構、AddMcpServer |
| 04 | [第一個工具，用 stdio 跑起來](./04-mcp-server-tools.md) | McpServerTool、WithToolsFromAssembly |
| 05 | [工具進階（DI 注入、McpServer、Schema、錯誤處理）](./05-mcp-server-tools-advanced.md) | DI 注入、`McpServer`/`RequestContext` 注入、Schema、`McpException` 錯誤處理 |
| 06 | [Prompts（可重用提示範本）](./06-mcp-server-prompts.md) | 定義 prompts、參數與 `[Description]`、補全、回傳型別、`WithPromptsFromAssembly` |
| 07 | [Resources（資源、URI Template、訂閱與通知）](./07-mcp-server-resources.md) | 直接/範本資源、`TextResourceContents`/`BlobResourceContents`、`WithResourcesFromAssembly`、訂閱與變更通知 |

### 第三部分：傳輸與通訊
| 章節 | 標題 | 說明 |
|------|------|------|
| 08 | [傳輸層總覽與 Sessions](./08-transports-and-sessions.md) | Stdio / Streamable HTTP / In-memory、stateless vs stateful、`HttpServerTransportOptions`、legacy SSE |
| 09 | [通知、進度、Logging 與 Completion](./09-notifications-logging-completion.md) | `NotificationMethods`、`IProgress` 進度回報、日誌轉送（`AsClientLoggerProvider`）、參數補全（`WithCompleteHandler`） |

### 第四部分：MCP Client 與整合實作
| 章節 | 標題 | 說明 |
|------|------|------|
| 10 | [建立 MCP Client](./10-mcp-client.md) | `McpClient.CreateAsync`、列出/呼叫工具、讀取與訂閱資源、取用 prompts、通知處理 |
| 11 | [實作範例——組裝一個完整的天氣 Server](./11-complete-weather-server.md) | QuickstartWeatherServer 骨架、tools + resources 同台組裝、DI 佈線、stderr logging、client 煙霧測試 |

### 第五部分：ASP.NET Core 與正式環境
| 章節 | 標題 | 說明 |
|------|------|------|
| 12 | [ASP.NET Core 託管 MCP Server](./12-aspnetcore-hosting.md) | 三步佈線（`WithHttpTransport` + `MapMcp`）、CORS/middleware 整合、per-session 客製、production 選項（idle/resumability/session 遷移） |
| 13 | [測試策略](./13-testing-strategy.md) | 測試分層、in-memory transport（`StreamServerTransport`/`StreamClientTransport`）、DI 版測試 fixture、假 `HttpMessageHandler` 替換外部相依 |

### 第六部分：伺服器↔客戶端進階
| 章節 | 標題 | 說明 |
|------|------|------|
| 14 | [Sampling——伺服器借用客戶端的 LLM](./14-sampling.md) | `McpServer.SampleAsync`、`SamplingHandler`/`CreateSamplingHandler`、`AsSamplingChatClient`、假 LLM 測試 |
| 15 | [Elicitation——工具執行中向使用者徵詢輸入](./15-elicitation.md) | `ElicitAsync`/`ElicitAsync<T>`、表單 schema、accept/decline/cancel、URL 模式、`ElicitationHandler` |
| 16 | [與 LLM 整合——把 MCP 工具餵給 IChatClient](./16-llm-integration.md) | `McpClientTool : AIFunction` 橋接、`UseFunctionInvocation` 自動迴圈、串流、`WithName` 裝飾、假 LLM 測試 |
| 17 | [Tasks——長時間執行的持久任務](./17-tasks.md) | `IMcpTaskStore`、`CallToolAsTaskAsync`/輪詢/取消、`ToolTaskSupport`、durable store、MCPEXP001（實驗性） |

### 第七部分：安全與部署
| 章節 | 標題 | 說明 |
|------|------|------|
| 18 | [Authorization 與傳輸安全](./18-authorization-and-security.md) | OAuth 2.1（JwtBearer + `.AddMcp()`、`ClientOAuthOptions`）、ID-JAG、`AllowedHosts`/CORS/session 綁定 |
| 19 | [Docker 部署](./19-docker-deployment.md) | 多階段 Dockerfile、stateless 水平擴展、health check、非 root、stdio 容器化 |
| 20 | [Native AOT 相容](./20-native-aot.md) | `PublishAot`、泛型 `WithTools<T>` vs 反射掃描、source-gen JSON context、命名策略陷阱、CI 自測模式 |

### 附錄
| 附錄 | 標題 | 說明 |
|------|------|------|
| A | [NuGet 套件清單與版本記錄](./appendix-a-nuget-packages.md) | 套件分工/依賴/TFM 速查、SDK 版本時間線 |
| B | [API 變更與 Migration](./appendix-b-migration.md) | McpClientFactory → McpClient 等七類遷移、診斷代碼速查、v2 preview 前瞻 |
| C | [MCP 規格映射（2025-11-25 primitive ↔ C# 型別）](./appendix-c-spec-mapping.md) | 2025-11-25 規格概念 ↔ C# 型別雙向對照 |
| D | 官方 Samples 導覽（規劃中） | csharp-sdk/samples/ |
| E | 資源連結（規劃中） | 官方文件與社群資源 |

---

## 版本記錄

| 框架版本 | 教學更新日期 | 摘要 |
|---------|------------|------|
| v1.4.0 | 2026-06-30 | 教學專案骨架與章節規劃建立 |
| v1.4.0 | 2026-07-13 | 第 05 章「工具進階」撰寫完成並移入 |
| v1.4.0 | 2026-07-13 | 第 06 章「Prompts」撰寫完成並移入 |
| v1.4.0 | 2026-07-14 | 第 07 章「Resources」撰寫完成並移入 |
| v1.4.0 | 2026-07-14 | 第 08 章「傳輸層總覽與 Sessions」撰寫完成並移入 |
| v1.4.0 | 2026-07-14 | 第 09 章「通知、進度、Logging 與 Completion」撰寫完成並移入 |
| v1.4.0 | 2026-07-14 | 第 10 章「建立 MCP Client」撰寫完成並移入 |
| v1.4.0 | 2026-07-15 | 第 11 章「實作範例——組裝一個完整的天氣 Server」撰寫完成並移入（全章程式碼經 dotnet build 驗證） |
| v1.4.0 | 2026-07-15 | 第 12 章「ASP.NET Core 託管 MCP Server」撰寫完成並移入（上手範例經 dotnet build 驗證，實證 ch11 Tools/Resources 零修改搬移） |
| v1.4.0 | 2026-07-16 | 第 13 章「測試策略」撰寫完成並移入（全章程式碼經 dotnet test 實測 8/8 通過，含 McpException→IsError 錯誤路徑） |
| v1.4.0 | 2026-07-16 | 第 14 章「Sampling」撰寫完成並移入（dotnet test 實測；同步修正 wiki sampling 條目過時的 SamplingCapability.SamplingHandler 寫法） |
| v1.4.0 | 2026-07-16 | 第 15 章「Elicitation」撰寫完成並移入（dotnet test 實測 4 情境；同步修正 wiki elicitation 條目 client 端過時寫法） |
| v1.4.0 | 2026-07-16 | 第 16 章「與 LLM 整合」撰寫完成並移入（假 LLM 驅動 UseFunctionInvocation 迴圈實測；M.E.AI 10.8.0 相容性實證） |
| v1.4.0 | 2026-07-16 | 第 17 章「Tasks」撰寫完成並移入（task 全流程 dotnet test 實測；修正 wiki tasks 條目 IMcpTaskStore namespace 錯誤） |
| v1.4.0 | 2026-07-16 | 第 18 章「Authorization 與傳輸安全」撰寫完成並移入（server/client 佈線 dotnet build 驗證；OAuth 流程本身未端對端實測） |
| v1.4.0 | 2026-07-16 | 第 19 章「Docker 部署」撰寫完成並移入（docker build/run + health + MCP initialize/tools/list 容器內全流程實測） |
| v1.4.0 | 2026-07-16 | 第 20 章「Native AOT 相容」撰寫完成並移入（osx-arm64 真 AOT publish + 10MB 原生檔自測；抓到 source-gen 命名策略陷阱）——第 01–20 章全數完成 |
| v1.4.0 | 2026-07-16 | reviews/ 審查文件補齊全 20 章（第二意見審查用）；補建過程修正 ch07 訂閱表初始化 bug（GetOrAdd）與 ch10 complex_prompt 參數型別不符 |
| v1.4.0 | 2026-07-16 | 第二意見審查處置完成（見 reviews/second-opinion-resolution）：修正 ch07 Blob raw bytes（上游 sample 同款問題）、ch04 IMcpServer×3、清理規劃中/附錄引用、ch19 協定版本改 2025-11-25（容器重測）、統一 primitive 控制權措辭與 ch11–20 標點 |
| v1.4.0 | 2026-07-16 | 附錄 A（NuGet 套件與版本）、B（Migration 與診斷代碼）、C（規格映射）撰寫完成並移入——正文的附錄引用自此生效 |
| v1.4.0 | 2026-07-16 | 發佈格式 pass：guide 全部 `[[wiki-style]]` 連結（172 個）轉為指向知識庫的一般相對連結（GitHub 可點閱）；知識庫內部維持 wiki-style |

---

## 參考資料
- [MCP C# SDK 概念文件](https://csharp.sdk.modelcontextprotocol.io/)
- [modelcontextprotocol/csharp-sdk](https://github.com/modelcontextprotocol/csharp-sdk)
- [MCP 規格](https://modelcontextprotocol.io/specification/)
