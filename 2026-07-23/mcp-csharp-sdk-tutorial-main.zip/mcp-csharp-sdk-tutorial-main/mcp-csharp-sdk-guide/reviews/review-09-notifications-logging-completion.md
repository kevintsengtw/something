# 審查說明：第 09 章「通知、進度、Logging 與 Completion」

> 對應檔案：[`../09-notifications-logging-completion.md`](../09-notifications-logging-completion.md)
> 製作時期：2026-07-14 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建——製作過程摘要為事後整理）

## 章節概要

通訊機制章：`NotificationMethods` 十常數總表（含方向）、進度回報管線（progress token、
server 注入 `IProgress<ProgressNotificationValue>`＋no-op 設計、client `CallToolAsync(progress:)`）、
日誌轉送（`logging/setLevel`、`AsClientLoggerProvider()`、`LoggingLevel` vs `LogLevel`）、
參數補全（`AllowedValues` 自動＋`WithCompleteHandler` 手動、兩種 `Ref`）、
「請求期間通知 stateless 也通」的關鍵澄清。

## 製作過程摘要（事後整理）

- 依 Pipeline D 由 wiki `notifications-progress`+`logging-and-completion` 草擬，經人工 review
  移入（草稿存檔 `outputs/draft-notifications-progress.2026-07-14.bak.md`）。
- 程式碼來源：官方 `docs/concepts/progress/` 的 server/client samples（章內有標）、
  `EverythingServer/Program.cs`（logging/completion handler,標「依…簡化」）。
- 結構宣告驗證脈絡：`NotificationMethods` 常數與字串值（原始碼）、
  `ProgressNotificationValue` 三屬性（required Progress）、`AsClientLoggerProvider`
 （kb 事實層）、`WithCompleteHandler`（wiki frontmatter）。
- **後續實測部分覆蓋**：`IProgress` 注入的存在與型別由 ch16 的 `WithProgress` 實測間接印證；
  sampling handler 簽名中的 `IProgress<ProgressNotificationValue>`（ch14 實測）同型別。
  **進度/日誌/補全的端對端流程均未實測**。

## 已知取捨與風險點（請多看一眼）

1. **「no-op `IProgress`」設計**（token 缺席時 Report 靜默）：來自原始碼分析
  （`RequestServiceProvider`/`TokenProgress`），未實測兩種情境的行為差異。這是本章
   最重要的行為宣稱，建議用 ch13 基底寫一個帶/不帶 progress 的測試驗證。
2. **「請求期間的通知走 POST 回應串流，stateless 也通」**：關鍵澄清（修正「stateless 全不能通知」
   的常見誤解），依據是傳輸實作分析；ch19 容器實測的 SSE 回應形態與此一致，但未實測
   stateless 下的進度通知本身。
3. **通知總表的「方向」欄**：S→C/C→S/雙向的分類部分來自規格、部分來自 SDK 用法，
   逐列核對成本低、價值高。
4. **`AsClientLoggerProvider` 的過濾行為**（依 client 設定等級自動過濾）：文件宣稱，未實測。
5. **completion handler 範例**：EverythingServer 簡化版，`ctx.Params!` 的 null 容忍寫法
   照搬上游，審查者可評估是否要更防禦。
6. **`TaskStatusNotification` 列入總表**：撰寫時 ch17 尚未存在，表中已前瞻標注（第 17 章）——
   現 ch17 已落地，交叉引用成立。

## 審查 checklist

### A. 結構宣告

- [ ] `NotificationMethods` 十常數的字串值逐一對照原始碼
- [ ] `ProgressNotificationValue`（required float Progress、float? Total、string? Message）
- [ ] `ProgressNotificationParams`（ProgressToken + Progress）結構
- [ ] `SetLevelRequestParams`/`LoggingMessageNotificationParams`/`CompleteResult`/`Completion` 欄位
- [ ] 兩種 `Ref` 型別名（`ResourceTemplateReference`/`PromptReference`）

### B. 程式碼

- [ ] 三段進度範例與官方 docs samples 一致
- [ ] `AsClientLoggerProvider()` 簽名與回傳型別
- [ ] completion handler 可編譯（風險點 5）

### C. 敘述

- [ ] 風險點 1/2 的行為宣稱（本章的兩根支柱）
- [ ] 「CancelledNotification 是 CancellationToken 觸發來源之一」準確
- [ ] `LoggingLevel` vs `LogLevel` 的區分無誤導

### D. 教學品質

- [ ] 四主題（通知/進度/日誌/補全）擠一章的密度是否可讀
- [ ] 常見錯誤六條是否對應真實踩坑
- [ ] 交叉引用（ch07/08/16/17）正確；繁中語感；骨架完整
