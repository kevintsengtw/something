# 審查說明：附錄 A／B／C

> 對應檔案：[`../appendix-a-nuget-packages.md`](../appendix-a-nuget-packages.md)、
> [`../appendix-b-migration.md`](../appendix-b-migration.md)、[`../appendix-c-spec-mapping.md`](../appendix-c-spec-mapping.md)
> 製作日期：2026-07-16 ｜ 基準：ModelContextProtocol v1.4.0
> 附錄性質為**彙整**（索引＋對照表），原則上不引入新結構宣稱——審查重點是「與來源的一致性」而非「宣稱本身」。三份合併一份審查文件。

## 製作過程摘要

- **A（NuGet 套件與版本）**：素材為 `raw/api-surface/*.md`（上游 src/ 公開型別 grep 產物）、
  ch02 已驗事實（TFM／依賴鏈）、`raw/release-notes/`（版本時間線）。型別速查表為 api-surface
  的人工節選。
- **B（Migration）**：素材為 `wiki/api-changelog.md`（`/compile` 維護、逐筆含 PR 編號與驗證出處）
  ＋本教學製作過程實測抓到的過時寫法（sampling handler 位置、`IMcpTaskStore` namespace、
  `McpClientFactory` 已移除等,各有實證）。診斷代碼表彙整自 ch17/ch20 與 changelog。
- **C（規格映射）**：全表出自 ch01–20 的已驗內容,無新宣稱;「協定方法名」欄（`sampling/createMessage`
  等）沿各章引用的 `RequestMethods`／`NotificationMethods` 常數。

## 已知取捨與風險點

1. **A 的型別速查表是節選**：api-surface 全量有數百型別,表中只留教學出現過的——「代表性」
   的取捨是否恰當、有無漏掉高頻型別,請掃一眼 `raw/api-surface/` 對照。
2. **A 的外部套件版本欄**：「教學實測版本」是單點事實,非相容範圍。
3. **B 的遷移條目 5（RequestContext ctor）**：本教學章節未實際用過 2-arg ctor,此條純轉錄
   changelog,無第一手驗證。
4. **B 的 v2.0.0-preview 前瞻**：轉述 release note,規格草案（2026-07-28）內容可能再變。
5. **C 的「Roots」列**：全書僅 ch08 概述級提及,server 端 API 名刻意留白（「roots 請求 API」）——
   審查者可決定是否補上 `RequestRootsAsync` 等具體名稱（需先圖譜驗證）。
6. **C 的 capabilities 表**：「註冊即自動宣告」的概括對 tools/resources/prompts 成立
  （SDK 行為）,但 `logging` 一格的宣告時機未單獨驗證。

## 審查 checklist

- [ ] A：套件總表／TFM 表與 NuGet 1.4.0 實包一致;依賴鏈方向正確
- [ ] A：版本時間線與 `raw/release-notes/` 逐列一致（尤其 1.4.1「無 API 變更」）
- [ ] B：七條遷移的「舊寫法會發生什麼」（CS0117／編譯失敗／漏接例外）逐條準確
- [ ] B：診斷代碼表的「性質」欄（編譯錯誤 vs 警告）正確——MCPEXP 系列是錯誤、MCP9003/9004 是警告,此區分很關鍵
- [ ] C：三大表的協定方法名與規格文件一致（風險點 5/6）
- [ ] C：「camelCase↔PascalCase」「snake_case 工具名」提醒與 ch04 一致
- [ ] 三份附錄的內部連結（互鏈與章節鏈）全部有效
