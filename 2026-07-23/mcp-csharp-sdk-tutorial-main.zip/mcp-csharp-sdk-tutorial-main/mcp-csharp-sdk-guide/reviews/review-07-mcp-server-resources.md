# 審查說明：第 07 章「Resources（資源、URI Template、訂閱與通知）」

> 對應檔案：[`../07-mcp-server-resources.md`](../07-mcp-server-resources.md)
> 製作時期：2026-07-14 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建——製作過程摘要為事後整理）

## 章節概要

Resources 章：直接資源 vs 範本資源（`UriTemplate` 有無 `{param}`、兩個不同的 list 端點）、
URI 參數綁定與型別轉換、`TextResourceContents`/`BlobResourceContents`（base64 語意、
`FromBytes`/`DecodedData`）、四種註冊方式與低階 handler、**訂閱與變更通知**（自行維護訂閱表、
`ResourceUpdatedNotification`、stateful 前提）、參數注入對稱性。

## 製作過程摘要（事後整理）

- 依 Pipeline D 由 wiki `mcp-server-resources` 草擬，經人工 review 移入
 （草稿存檔 `outputs/draft-mcp-server-resources.2026-07-14.bak.md`）。
- 範例來源：`EverythingServer/Resources/SimpleResourceType.cs`（直接/範本資源原文）、
  `EverythingServer/Program.cs`（訂閱 handler,章內註明「依…簡化」）。
- 結構宣告的驗證脈絡：`WithResources`（kb 驗證 in_degree=8）、`ResourceContents` 的
  `private protected` 建構子與兩個密封子類（原始碼）、`BlobResourceContents.FromBytes`/
  `DecodedData`（原始碼）。
- **後續實測部分覆蓋**：ch11 自撰的 `WeatherResources`（直接＋範本資源、`TextResourceContents`、
  URI 參數綁定、`WithResources<T>` 的 CS0718 限制）經 dotnet build 與 client 煙霧測試；
  ch12 又把同組資源搬上 HTTP 驗證。**訂閱/通知段落無執行期驗證**。

## 已知取捨與風險點（請多看一眼）

1. **訂閱機制全段未實測**：訂閱表模式、`EmptyResult` 回傳、`ResourceUpdatedNotification` 送達，
   皆為 sample 改寫＋原始碼分析。**2026-07-16 補建本文件時已查出並修正一個簡化引入的 bug**：
   上游原文在 `RunSessionHandler` 於 session 開始時先初始化該 session 的訂閱字典
  （`Program.cs` L76），章節簡化版拿掉了那段卻保留索引子讀取——首次訂閱會
   `KeyNotFoundException`。已改為 `GetOrAdd`／`TryGetValue` 並加註解說明。
   審查者請確認修正後版本的正確性，並留意通知送達路徑（`SubscriptionMessageSender`）仍未展開。
2. **「`Blob` 存 base64 編碼後的 bytes」**：對 `ReadOnlyMemory<byte>` 存 base64 這一反直覺
   語意，來自原始碼註解，未實測 wire 格式。
3. **URI 參數的型別轉換**（`{id}` → `int`）：sample 原文如此，轉換失敗時的行為未描述。
4. **「SDK 不幫你記訂閱」**：關鍵設計事實，與原始碼一致，但表述絕對——若 SDK 未來加入
   內建訂閱管理，此句會過時（drift-check 對象）。
5. **範本資源的 client 端視角**（`resources/templates/list`）：與 ch10/ch11 的 client 實測一致。

## 審查 checklist

### A. 結構宣告

- [ ] `McpServerResource` 繼承鏈、attribute 可設定屬性清單（UriTemplate/Name/Title/MimeType/IconSource）
- [ ] 「UriTemplate 不指定時由 Name 與參數自動推導」與原始碼一致
- [ ] `ResourceContents` 三欄位＋`private protected` 建構子；兩個密封子類的 required 欄位
- [ ] `FromBytes`/`DecodedData` 簽名與 base64 語意（風險點 2）
- [ ] `WithListResourcesHandler`/`WithReadResourceHandler`/`WithSubscribeToResourcesHandler` 等 handler API 存在
- [ ] `NotificationMethods.ResourceUpdatedNotification`/`ResourceListChangedNotification` 常數值

### B. 程式碼

- [ ] 上游範例與現行原始碼一致
- [ ] **訂閱範例逐行對照 `EverythingServer/Program.cs`**（風險點 1——特別是訂閱表初始化）
- [ ] `FromBytes` 自撰片段可編譯

### C. 敘述

- [ ] 直接 vs 範本資源的兩個 list 端點區分正確
- [ ] 「主動通知需要 stateful/stdio」與 ch05/08/12 一致
- [ ] 常見錯誤六條準確（特別是「繼承 ResourceContents 不可行」）

### D. 教學品質

- [ ] 「resource 唯讀無副作用」的原則是否講清
- [ ] 訂閱三環節（訂/記/送）的責任劃分是否易懂
- [ ] 交叉引用正確；繁中語感；骨架完整
