# 審查說明：第 18 章「Authorization 與傳輸安全」

> 對應檔案：[`../18-authorization-and-security.md`](../18-authorization-and-security.md)
> 製作日期：2026-07-16 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> ⚠️ **本章是安全主題，審查優先級最高**——錯誤的安全指引比沒有指引更糟。

## 章節概要

前半：MCP 的 OAuth 2.1 授權——自動發現流程（401 → PRM → 動態註冊 → PKCE → Bearer）、
server 三件套（JwtBearer + `.AddMcp()` 資源中繼資料 + `RequireAuthorization()`）、client 的
`ClientOAuthOptions`、v1.4.0 ID-JAG 企業 SSO。後半：傳輸安全三道鎖——`AllowedHosts`（DNS
rebinding）、最小化 CORS、session 使用者綁定（403）。

## 製作過程摘要

**圖譜＋原始檔驗證**：`AddMcp`／`McpAuthenticationDefaults`／`McpAuthenticationHandler`／
`McpAuthenticationOptions`（皆在 .AspNetCore 的 Authentication/ 下，圖譜有節點）；
`ClientOAuthOptions` 十個屬性逐一從原始檔列出（required `RedirectUri` 等）；
`IdentityAssertionGrantProvider` 簽名沿 wiki 條目（該條目 frontmatter 記錄其建立時已經圖譜驗證）；
session 使用者綁定沿 ch12 已驗事實（`StreamableHttpHandler.HandleDeleteRequestAsync`,#1604）；
`AllowedHosts`／CORS 指引取自官方 `raw/docs-conceptual/transports.md` L190–220。

**編譯驗證**：server 佈線以獨立 web 專案（ModelContextProtocol.AspNetCore 1.4.0 +
Microsoft.AspNetCore.Authentication.JwtBearer 9.0.6）`dotnet build` 0 警告 0 錯誤；client OAuth
片段併入測試專案編譯通過。

**⚠️ 未做執行期驗證**：OAuth 完整流程（401 → 發現 → 授權 → token → 重試）需要授權伺服器與
瀏覽器互動，本章**只驗證了佈線可編譯，未端對端跑通**。這是全書驗證強度最弱的一章，README
版本記錄有註明。

**內容來源**：wiki `authorization` + `transport-security`；上游 `samples/ProtectedMcpServer`
（server 佈線與 CORS 政策原文）、`samples/ProtectedMcpClient`（client 佈線與
AuthorizationRedirectDelegate 模式）、官方 transports 文件（安全指引）。

## 已知取捨與風險點（請多看一眼）

1. **自動發現流程圖**（為什麼需要）：401 → PRM → 註冊 → PKCE 的時序是從規格與 SDK 行為綜合而來，
   **未抓 wire 驗證**。特別檢查：`WWW-Authenticate` 的實際內容、PRM 端點路徑
  （`/.well-known/oauth-protected-resource`）是否與 SDK 實作一致。
2. **「常見錯誤 3」的宣稱**（DefaultChallengeScheme 沒設 MCP scheme → client 自動發現斷掉）：
   邏輯推論（challenge 由誰處理決定 401 形態），未實測兩種設定的差異。
3. **session 綁定描述**：「SDK 自動綁定」的前提條件（啟用驗證的 stateful server）表述是否精確，
   建議對照 `StreamableHttpHandler` 原始碼確認匿名情境的行為。
4. **ID-JAG 段落**：程式碼沿 wiki 驗證簽名，但 ID-JAG 全流程（RFC 8693 + 7523）未實測，
   `IdTokenCallback` 的 ctx 參數型別未在章節中給出。
5. **安全建議的完備性**：本章的三道鎖＋六個常見錯誤是否有遺漏的重大面向
  （如 TLS/HTTPS 的強制、token 存放安全、localhost redirect URI 的風險）——章節未提 TLS,
   值得審查者評估是否補充。
6. **`AllowAnyOrigin` + `AllowCredentials` 並用被框架禁止**：這是 ASP.NET Core 行為，
   引用自框架文件常識，未驗證具體例外訊息。

## 審查 checklist

### A. 結構宣告

- [ ] `AddMcp` 擴充方法與 `McpAuthenticationDefaults.AuthenticationScheme` 存在（.AspNetCore）
- [ ] `McpAuthenticationOptions.ResourceMetadata` 的屬性（ResourceDocumentation/AuthorizationServers/ScopesSupported）與原始碼一致
- [ ] `ClientOAuthOptions` 屬性清單與 required 修飾正確（`Authentication/ClientOAuthOptions.cs`）
- [ ] `IdentityAssertionGrantProvider` 建構子與 `GetAccessTokenAsync` 簽名（`Authentication/IdentityAssertionGrantProvider.cs`）
- [ ] PRM 端點路徑與 401 挑戰行為（風險點 1——對照 `McpAuthenticationHandler` 原始碼）

### B. 程式碼

- [ ] server 三件套範例可編譯且與 `ProtectedMcpServer` sample 本質一致（本章刪去了 CORS 與 events,確認刪減未破壞正確性）
- [ ] client 片段可編譯；`AuthorizationRedirectDelegate` 委派簽名正確
- [ ] CORS 政策程式碼與 sample 原文一致（含 `WithExposedHeaders(WWWAuthenticate)`）
- [ ] `AllowedHosts` JSON 片段語法正確

### C. 敘述（安全宣稱逐條核對）

- [ ] 「Kestrel 預設不驗證 Host 標頭」——與官方文件一致
- [ ] 「CORS 不是 host 驗證的替代品」——官方文件原意
- [ ] 「範本預設 AllowedHosts 是 *」——確認 ASP.NET Core 範本現況
- [ ] session 綁定的觸發條件與 403 行為（風險點 3）
- [ ] RFC 編號（8707/8693/7523/9728 未明說）引用正確
- [ ] 常見錯誤 6 的 audience 說明是否準確

### D. 教學品質

- [ ] 「兩層安全」的區分是否清楚有效
- [ ] 未端對端實測的事實對讀者是否透明（README 版本記錄有註；章節內是否需要再標註，請評估）
- [ ] TestOAuthServer 段落是否足以讓讀者本機起步
- [ ] 交叉引用（ch08/ch12/ch19 前瞻）正確；繁中語感與骨架完整性
