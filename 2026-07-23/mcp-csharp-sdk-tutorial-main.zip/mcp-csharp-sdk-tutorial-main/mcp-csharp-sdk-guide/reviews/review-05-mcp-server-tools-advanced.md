# 審查說明：第 05 章「工具進階（DI 注入、McpServer、Schema、錯誤處理）」

> 對應檔案：[`../05-mcp-server-tools-advanced.md`](../05-mcp-server-tools-advanced.md)
> 製作時期：2026-07-13 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建——製作過程摘要為事後整理）

## 章節概要

工具深水區：參數兩種身分（模型輸入 vs 框架注入，`IServiceProviderIsService` 判定）、
DI 建構式/參數注入、`McpServer` 與 `RequestContext<TParams>` 注入、JSON Schema 生成規則
（型別對應/預設值→選填）、回傳型別五階（string→ContentBlock→CallToolResult→結構化輸出）、
tool annotations（ReadOnly/Destructive/Idempotent/OpenWorld）、**工具錯誤 vs 協定錯誤**
（`McpException`/`McpProtocolException`/`McpErrorCode`）、動態工具清單通知。全書被引用最多的一章。

## 製作過程摘要（事後整理）

- 依 Pipeline D 草擬，經人工 review 移入。章內多處直接標注驗證出處
 （`AIFunctionMcpServerTool.cs` 的注入判定、`McpServerToolAttribute.cs` 的 annotation 預設值、
  `ContentBlock.cs` 的工廠方法）。
- 範例來源：`ProtectedMcpServer/Tools/WeatherTools.cs`（建構式注入）、
  `EverythingServer/Tools/LongRunningTool.cs`（McpServer+RequestContext 注入，原文）。
- **後續章節的實測回頭印證了本章多項核心宣稱**：
  - `McpException` → `IsError=true` 且 Message 傳到 client：ch13 dotnet test 實測 ✅
  - DI 服務（HttpClient）注入且不入 schema：ch11/ch13/ch16 實測 ✅
  - `McpServer` 參數注入：ch14/ch15/ch17 實測 ✅
  - 預設值參數為選填：ch17 的 `duration=10` 型範例間接支持
- **未被後續實測覆蓋的部分**：`McpProtocolException`/`McpErrorCode` 路徑、結構化輸出
 （UseStructuredContent/OutputSchemaType）、tool annotations 的 wire 呈現、多內容區塊回傳。

## 已知取捨與風險點（請多看一眼）

1. **「一般例外只回通用訊息 `An error occurred invoking '<tool>'.`」**：訊息字串引自
   官方 tools.md／原始碼，**未實測**（ch13 只測了 McpException 路徑）。訊息原文與格式值得核對。
2. **`McpProtocolException` 一律 re-throw 成 JSON-RPC error**：取自文件與原始碼分析，未實測。
3. **`OperationCanceledException` 的 re-throw 特例**：同上，未實測。
4. **annotation 預設值表**（Destructive=true、OpenWorld=true 等）：撰寫時對照 attribute 原始碼，
   注意這些是「未設定時的協定語意預設」，呈現方式（const）與 wire 行為的關係請覆核。
5. **`OutputSchemaType` 的版本標註（1.2.0，#1425）**：changelog 級宣稱，請對照 release notes。
6. **`ImageContentBlock.FromBytes` 工廠方法**：有原始碼出處標注，未編譯驗證。

## 審查 checklist

### A. 結構宣告

- [ ] `IServiceProviderIsService` 判定機制的描述與 `AIFunctionMcpServerTool.cs` 一致
- [ ] 「沒有 `IMcpServer` 介面，注入 `McpServer` 具體類別」正確（這與 PLAN 早期草稿用詞相反，是刻意修正）
- [ ] 三個例外型別的 namespace（根 `ModelContextProtocol`）與繼承鏈（`McpProtocolException : McpException`）
- [ ] annotation 四屬性與預設值（`McpServerToolAttribute.cs`）
- [ ] `CallToolResult.IsError` 為 `bool?`;`StructuredContent`/`OutputSchema` 為 `JsonElement?`
- [ ] `NotificationMethods.ToolListChangedNotification` 常數存在

### B. 程式碼

- [ ] 兩個上游範例與現行原始碼一致（ProtectedMcpServer/EverythingServer）
- [ ] 自撰範例（Search/Describe/GetReport/Divide/Process）可編譯——**本章自撰碼未經編譯驗證，優先抽查**
- [ ] `ImageContentBlock.FromBytes(bytes, "image/png")` 簽名正確

### C. 敘述

- [ ] 風險點 1–3 的錯誤處理三分法與 SDK 實際行為一致（本章最重要的知識，ch13/14/15 都依賴它）
- [ ] Schema 型別對應表無誤（複雜型別→object）
- [ ] 「stateless 無法主動送通知」與 ch08/ch12 一致

### D. 教學品質

- [ ] 「參數兩種身分」的心智模型是否清晰（它是後續所有章節的地基）
- [ ] 錯誤處理段的「對模型顯示 vs 不洩漏」的取捨是否講透
- [ ] 交叉引用（ch03/04/07/09/14/16）正確；繁中語感；骨架完整
