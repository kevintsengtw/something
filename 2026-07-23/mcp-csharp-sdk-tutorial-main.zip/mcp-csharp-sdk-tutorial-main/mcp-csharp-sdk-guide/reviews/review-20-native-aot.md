# 審查說明：第 20 章「Native AOT 相容」

> 對應檔案：[`../20-native-aot.md`](../20-native-aot.md)
> 製作日期：2026-07-16 ｜ 基準：ModelContextProtocol v1.4.0 ｜ dotnet SDK 10 → net9.0 osx-arm64
> 審查方法總則見 [README.md](./README.md)

## 章節概要

教 Native AOT 發佈：`PublishAot` 設定、SDK 的 AOT 安全區／危險區（泛型 `WithTools<T>` vs
`RequiresUnreferencedCode` 標記的反射掃描 API）、自訂型別的 source-generated
`JsonSerializerContext`（含 camelCase 命名策略陷阱）、上游 `AotCompatibility.TestApp` 的
CI 自測模式、依賴鏈相容性、容器瘦身銜接。全書最後一章。

## 製作過程摘要

**圖譜＋原始檔驗證**：`[RequiresUnreferencedCode]` 的分佈與訊息原文
（`McpServerBuilderExtensions.cs`——tools L19/L135/L188,prompts L204,resources L386;
訊息明示「Use the generic WithTools method instead」）；`McpJsonUtilities` 的 AOT 註記；
`McpServerToolCreateOptions.SerializerOptions`;上游 TestApp 的 csproj
（PublishAot + TrimmerRootAssembly ×3）與自測程式。

**真 AOT 實測**（章節引用的輸出即實測原文）：
- `dotnet publish -c Release -r osx-arm64`（PublishAot + InvariantGlobalization,
  ModelContextProtocol 1.4.0）成功，無 MCP 相關 trim 警告
- 產物 10MB Mach-O arm64 單一執行檔，`file` 確認
- 執行自測：tools 列表、`echo`（基本型別）、`order`（自訂 record + source-gen context）全過
- **實測抓到的陷阱**：context 未設 `PropertyNamingPolicy = CamelCase` 時，camelCase 引數
  對不上 PascalCase 屬性→**靜默 default 值**（`訂單： x0`）——已寫入進階用法與常見錯誤 3

**內容來源**：wiki `aot-compatibility`；上游 `tests/ModelContextProtocol.AotCompatibility.TestApp`、
`samples/ChatWithTools/ChatWithTools.csproj`（Anthropic SDK not AOT compatible 註解）。

## 已知取捨與風險點（請多看一眼）

1. **單平台實測**：osx-arm64。linux-x64/win-x64 的 AOT 工具鏈差異（如 linker 行為）未測；
   章節的 publish 指令列了三個 RID,隱含「都能跑」的暗示，請評估是否恰當。
2. **常見錯誤 1 的具體症狀**（IL2026 警告/工具缺漏/初始化失敗）：IL2026 是
   `RequiresUnreferencedCode` 的標準診斷，但本章**沒有實際發佈一個用 WithToolsFromAssembly
   的 AOT app** 來觀測真實症狀——「輕則…重則…」是推論。
3. **常見錯誤 2 的例外型別**（`NotSupportedException`）：反射式 STJ 在 AOT 禁用時的標準行為，
   未針對本 SDK 情境實測。
4. **「10MB」與「數十 MB 級映像」**：前者實測，後者（runtime-deps 容器）為推估，未 build 該映像。
5. **stdio server AOT 場景**（為什麼需要 1）：敘述性動機，本章實測的是 in-memory 自測程式，
   未實際發佈一個 stdio server 給 client spawn。
6. **HTTP（AspNetCore）伺服器的 AOT**：本章完全未涉及 `.AspNetCore` 套件在 AOT 下的狀態
  （上游 TestApp 有引用它，但本章實測只用 Core+hosting）。若讀者想 AOT 一個 ch12 型 server,
   本章沒有給答案——請評估是否需要補充或明示範圍。

## 審查 checklist

### A. 結構宣告

- [ ] `RequiresUnreferencedCode` 訊息引文與原始碼逐字一致
- [ ] 安全區／危險區表格的 API 歸類正確（含 Prompts/Resources 同型規則）
- [ ] `McpServerToolCreateOptions.SerializerOptions` 存在且用法正確
- [ ] TestApp 的 TrimmerRootAssembly 說明（套件作者手段 vs 一般應用不需要）正確

### B. 程式碼

- [ ] csproj 與程式全文可原樣建置（AOT publish）
- [ ] `JsonSourceGenerationOptions(PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase)` 語法正確
- [ ] `McpServerTool.Create` 兩種用法（帶/不帶 SerializerOptions）與 SDK 一致
- [ ] publish 指令與輸出路徑正確

### C. 敘述

- [ ] AOT 的能力/代價描述（無 JIT、反射受限）無過度簡化的誤導
- [ ] 命名策略陷阱的解釋（source-gen 嚴格 vs 反射寬容）技術上準確
- [ ] 風險點 2/3/4 的推論措辭是否需弱化
- [ ] 風險點 6：章節範圍（不含 AspNetCore AOT）是否需要明示

### D. 教學品質

- [ ] 作為全書收尾，與 ch04/ch13/ch19 的回扣是否自然
- [ ] 「訂單： x0」的實測故事是否有效傳達靜默失敗的危險
- [ ] CI 自測模式（照抄 TestApp）是否可操作
- [ ] 繁中語感與骨架完整性
