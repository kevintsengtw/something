# 審查說明：第 10 章「建立 MCP Client」

> 對應檔案：[`../10-mcp-client.md`](../10-mcp-client.md)
> 製作時期：2026-07-14 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建——製作過程摘要為事後整理）

## 章節概要

client 章：`McpClient.CreateAsync` 一個入口（含已移除的 `McpClientFactory` 防雷）、
三 primitive 的 client 端對照表（List/Call/Get/Read）、`CallToolResult` 解讀、
資源兩清單、prompt 取用、資源訂閱（`SubscribeToResourceAsync` 回傳 `IAsyncDisposable`）、
`RegisterNotificationHandler` 全域通知、`PingAsync`/`ClientTransportClosedException` 等雜項、
ch16 伏筆（`McpClientTool : AIFunction`）。

## 製作過程摘要（事後整理）

- 依 Pipeline D 由 wiki `mcp-client`+`mcp-client-tools`+`mcp-client-resources` 草擬，
  經人工 review 移入（草稿存檔 `outputs/draft-mcp-client.2026-07-14.bak.md`）。
- `CreateAsync` 簽名章內明標「驗證過」（kb 圖譜 in_degree=99）；
  `ListToolsAsync`/`CallToolAsync`/`ListResourcesAsync`/`ReadResourceAsync` 皆 kb 已驗
 （119/137/20/23）。程式碼來源：官方 docs（getting-started、resources.md,章內有標）。
- **本章是後續實測的最大受益者**：`CreateAsync`＋`ListToolsAsync`＋`CallToolAsync`＋
  `TextContentBlock` 解讀在 ch13–17 的 20 個測試中反覆執行；`ReadResourceAsync`＋
  兩清單區分在 ch11 煙霧測試執行過；`HttpClientTransport` 在 ch12/ch19 實測。
- **未實測部分**：`SubscribeToResourceAsync`/`RegisterNotificationHandler`/`PingAsync`/
  `GetPromptAsync`（prompts 全書無執行期驗證，見 review-06）。

## 已知取捨與風險點（請多看一眼）

1. **`SubscribeToResourceAsync` 帶 handler 的多載與 `IAsyncDisposable` 退訂**：
   取自官方 docs 原文，未實測；多載形態（有/無 handler）請對照原始碼。
2. **`ClientTransportClosedException`（v1.3.0，繼承 IOException）**：changelog 級宣稱，
   未觸發過該例外。
3. **常見錯誤 6**（先看 capabilities 再呼叫 `ListPromptsAsync`）：「會失敗」的具體形態
  （例外型別/錯誤碼）未寫明也未實測——審查者可要求補精確化。
4. **「不 dispose 會留下孤兒行程」**：與 `ShutdownTimeout` 的關係描述合理，未實測驗證
   孤兒行程的實際發生條件。
5. **`RegisterNotificationHandler`「定義在 `McpSession`」**：型別歸屬宣稱，請對照原始碼
  （client/server 共用基底的名稱是否確為 `McpSession`）。

## 審查 checklist

### A. 結構宣告

- [ ] `CreateAsync` 四參數簽名（已驗，對照即可）
- [ ] 對照表中六個 List/Get/Read 方法與回傳型別逐一存在
- [ ] `SubscribeToResourceAsync` 多載與回傳 `IAsyncDisposable`（風險點 1）
- [ ] `ClientTransportClosedException : IOException`、v1.3.0（風險點 2）
- [ ] `RegisterNotificationHandler` 的宣告位置（風險點 5）

### B. 程式碼

- [ ] 各段範例與官方 docs 一致
- [ ] `GetPromptAsync` 參數字典的值型別——**2026-07-16 補建本文件時已修正**：原範例傳
      `0.7`（浮點）但 ch06 的 `complex_prompt.temperature` 是 `int`,已改為 `1` 並加註解。
      請確認修正後與 int 綁定行為一致（浮點對 int 的實際失敗形態仍未實測）
- [ ] 資源讀取段與 ch07 的型別一致

### C. 敘述

- [ ] `McpClientFactory` 已移除的宣稱（附錄 B 伏筆）仍然正確
- [ ] 「連 HTTP 只是換傳輸」的等價性宣稱與 ch12 一致
- [ ] 常見錯誤六條準確度（尤其風險點 3）

### D. 教學品質

- [ ] 對照表是否有效建立 server 章節（04–07）與 client 端的映射
- [ ] 伏筆（ch16）與回顧（ch07/08/09）的節奏
- [ ] 繁中語感；骨架完整
