# 審查說明：第 03 章「第一個 MCP Server（Hosting / DI 架構）」

> 對應檔案：[`../03-mcp-server-builder.md`](../03-mcp-server-builder.md)
> 製作時期：2026-06-30 前後（教學初期）｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建——製作過程摘要為事後整理）

## 章節概要

server 建立章：高階（`AddMcpServer` + Generic Host/DI）與低階（`McpServer.Create`）兩條路徑、
鏈式設定流程、擴充方法的 namespace 慣例（`Microsoft.Extensions.DependencyInjection`）、
`McpServerOptions` 常用屬性表、stderr logging 紀律。

## 製作過程摘要（事後整理）

- 依 Pipeline D 由 wiki `mcp-server-builder` 草擬，經人工 review 移入。
- 章內明標「已用 codebase-memory-mcp 驗證」的宣告：`AddMcpServer`（kb 驗證 in_degree=153）、
  namespace 歸屬（kb 驗證探測 4 原則：DI 擴充刻意放 `Microsoft.Extensions.DependencyInjection`）；
  `McpServer.Create` 四參數簽名——此簽名後於 ch13 製作時再次經 get_code_snippet 驗證，兩處一致。
- 範例來源：`QuickstartWeatherServer`、`TestServerWithHosting`（上游原文節錄）。
- **本章程式碼未經獨立編譯驗證**;但高階路徑骨架與 ch11 實測程式一致、低階路徑與 ch13
  實測程式一致，間接背書強。

## 已知取捨與風險點（請多看一眼）

1. **`McpServerOptions` 屬性表**：五列屬性（ServerInfo/Capabilities/ProtocolVersion/
   ServerInstructions/*Collection）的型別與存在性來自撰寫當時的驗證，`ToolCollection` 後於
   ch13/ch20 實測用過；其餘（如 `ServerInstructions`）未在後續章節出現，值得抽查原始碼。
2. **低階用法骨架的註解**「自行驅動 server 的訊息迴圈」：ch13 實測顯示正確方式是
   `_ = server.RunAsync()`,本章沒有明說 `RunAsync`——表述偏含糊，審查者可評估是否該補
  （ch13 已補完整版，或許可接受）。
3. **「何時選低階」三點**：規範性建議，第三點（測試）已被 ch13 印證。
4. **`Implementation`/`ServerCapabilities` 的 namespace 宣告**：撰寫時驗證，未在本次會話重核。

## 審查 checklist

### A. 結構宣告

- [ ] `AddMcpServer`/`WithStdioServerTransport`/`WithTools<T>` 的 namespace＝`Microsoft.Extensions.DependencyInjection`、套件＝`ModelContextProtocol`
- [ ] `McpServer.Create` 四參數簽名（`McpServer.Methods.cs`）
- [ ] `McpServerOptions` 屬性表五列逐一對照原始碼（風險點 1）
- [ ] `Implementation`/`ServerCapabilities` 在 `ModelContextProtocol.Protocol`

### B. 程式碼

- [ ] 兩個上手範例與上游 sample 現行原始碼一致
- [ ] 低階骨架可編譯（含 using 兩行）
- [ ] `AddSingleton(httpClient)` 片段與 ch05/ch11 的 DI 注入敘述一致

### C. 敘述

- [ ] 「擴充方法放在被擴充型別 namespace 是 .NET 慣例」的說法準確
- [ ] 低階路徑「自行驅動訊息迴圈」是否需補 `RunAsync`（風險點 2）
- [ ] 常見錯誤五條症狀準確（尤其 ArgumentNullException 宣稱與 docstring 一致）

### D. 教學品質

- [ ] 「兩條路徑」的取捨是否讓初學者能果斷選高階
- [ ] 與 ch02/04/08/12 的路標正確
- [ ] 繁中語感；骨架完整
