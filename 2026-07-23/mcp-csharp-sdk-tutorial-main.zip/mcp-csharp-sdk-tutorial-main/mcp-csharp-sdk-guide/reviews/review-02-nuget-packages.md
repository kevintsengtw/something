# 審查說明：第 02 章「SDK 三套件選擇與安裝」

> 對應檔案：[`../02-nuget-packages.md`](../02-nuget-packages.md)
> 製作時期：2026-06-30 前後（教學初期）｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建——製作過程摘要為事後整理）

## 章節概要

套件導覽章：三套件分工表（.Core／ModelContextProtocol／.AspNetCore）＋ Analyzers、
依賴鏈（上層自動帶下層）、「沒有獨立 Authentication 套件」的澄清、安裝指令、選擇決策樹、
TFM 相容表、與 Microsoft.Extensions.AI 的關係。無對應 C# API（套件清單章）。

## 製作過程摘要（事後整理）

- 依 Pipeline D 由 wiki `nuget-packages` 草擬，經人工 review 移入。
- 依賴鏈與 TFM 表宣稱「取自上游各 .csproj」——事實層來源是 kb 的 raw/facts 與上游
  csproj 檔案。
- 「auth 型別分佈在 .Core 與 .AspNetCore」的宣稱，與 kb 驗證探測 4 的原則一致
 （套件歸屬以 file_path 第一段為準）；後續 ch18 的圖譜驗證再次印證此分佈。
- **本章的表格類事實未經本次會話重新核對**（如 TFM 清單、Analyzers 是否自動帶入）。

## 已知取捨與風險點（請多看一眼）

1. **TFM 表**：net10.0/net9.0/net8.0/netstandard2.0 的清單來自撰寫當時的上游 csproj;
   NuGet 1.4.0 正式包的實際 TFM 面請以 nuget.org 頁面對照（clone 的 csproj 與發佈包
   理論上一致，但值得抽查）。
2. **「Analyzers 通常隨上述套件自動帶入」**：此宣稱是否準確（哪個套件帶、以何種方式）
   未逐一驗證，審查者可查 nuspec 依賴。
3. **決策樹的「多數人選這個」**：規範性建議，合理但屬作者判斷。
4. **「.Core 依賴 Microsoft.Extensions.AI.Abstractions」**：與 ch16 實測（需另裝完整
   M.E.AI 套件才有 middleware）一致，無矛盾。
5. **版本語境**：「版本號以實際發佈為準」有寫，但若上游已出 1.5+/2.0,本章的表格
   時效性由 drift-check 管理——審查時確認目前基準仍是 v1.4.0。

## 審查 checklist

### A. 結構宣告

- [ ] 三套件的內容物歸屬（`AddMcpServer` 在 ModelContextProtocol、`MapMcp` 在 .AspNetCore 等）與上游一致
- [ ] 上游 src/ 確實只有四個專案（含 Analyzers）
- [ ] auth namespace 分佈（`ModelContextProtocol.Authentication` in .Core／`.AspNetCore.Authentication` in .AspNetCore）正確
- [ ] TFM 表與 NuGet 1.4.0 實包一致（風險點 1）

### B. 程式碼／指令

- [ ] `dotnet add package` 三行可執行
- [ ] csproj 片段語法正確
- [ ] 決策樹的邏輯無死路

### C. 敘述

- [ ] 依賴鏈方向正確（AspNetCore → ModelContextProtocol → Core）
- [ ] 「裝上層自動帶下層」與 NuGet 依賴行為一致
- [ ] 常見錯誤四條的症狀描述準確

### D. 教學品質

- [ ] 「沒有 Authentication 套件」的澄清是否醒目（這是本章最有價值的防雷點）
- [ ] 與 ch01/03/12/18 的路標正確
- [ ] 繁中語感；骨架完整
