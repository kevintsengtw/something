# 第二意見審查結果（2026-07-16）

審查範圍：`../01-what-is-mcp.md` 到 `../20-native-aot.md`，並抽查 `../README.md` 與上游 `../../csharp-sdk/` 原始碼。  
審查立場：以教學可照做性、API 敘述正確性、跨章一致性與繁中教材完成度為主；未重新執行每章範例的 build/test。

## 總結

主體內容已達可交付初稿水準：章節順序合理，API 版本意識清楚，後半部章節有大量實測紀錄，對初學 .NET 開發者的引導性足夠。第二意見發現的主要風險集中在少數局部錯誤與完稿清理，而不是整體架構問題。

建議第一方優先處理下列項目：

1. **P1 / 需修正：第 07 章二進位 resource 範例與 `BlobResourceContents.Blob` 語意矛盾。**
   `07-mcp-server-resources.md:93` 直接設定 `Blob = Encoding.UTF8.GetBytes(resource.Description!)`，但同章 `07-mcp-server-resources.md:121` 到 `07-mcp-server-resources.md:123` 已說明 `Blob` 期待的是 base64 編碼後 bytes。上游 `BlobResourceContents.FromBytes(...)` 的 XML doc 也明確表示 raw bytes 應走工廠方法。建議把範例改成 `BlobResourceContents.FromBytes(Encoding.UTF8.GetBytes(resource.Description!), resource.Uri, resource.MimeType)`，或改用 `DataContent` 讓 SDK 轉換。
2. **P1 / 需修正：第 04 章仍使用不存在的 `IMcpServer`。**
   `04-mcp-server-tools.md:36` 與 `04-mcp-server-tools.md:187` 說明可注入 `IMcpServer`，但第 05 章已正確指出 SDK 沒有 `IMcpServer`，應注入具體 `McpServer`。這會讓讀者在前一章先建立錯誤心智模型。
3. **P2 / 需清理：章節完成後仍殘留「規劃中」與不存在附錄引用。**
   `11-complete-weather-server.md:322`、`12-aspnetcore-hosting.md:206` 到 `12-aspnetcore-hosting.md:209`、`14-sampling.md:259` 仍標示後續章「規劃中」。`README.md:63` 到 `README.md:69` 列出附錄 A-E，但目前沒有對應檔案；同時 `01-what-is-mcp.md:146`、`02-nuget-packages.md:129`、`10-mcp-client.md:187` 都引用附錄。建議在主體完稿前補齊附錄，或把引用改成「預計附錄」並避免讀者以為連結缺漏。
4. **P2 / 需確認：協定版本範例不一致。**
   全書開頭 `01-what-is-mcp.md:22` 宣稱基準為 MCP 規格 `2025-11-25`，但 Docker 章 curl 初始化範例與回應使用 `2025-06-18`（`19-docker-deployment.md:103`、`19-docker-deployment.md:111`）。上游 SDK 同時支援 `2025-06-18` 與 `2025-11-25`，且 latest 是 `2025-11-25`；建議教學範例一律用 latest，或明確說明此處刻意示範舊版相容。
5. **P2 / 建議統一：primitive 控制權描述在跨章不一致。**
   第 01 章把 Resources 寫成「應用/使用者挑選」（`01-what-is-mcp.md:42`），第 06 章寫成「應用/模型 讀取」（`06-mcp-server-prompts.md:25`）。建議統一成規格語感：Tools model-controlled、Resources application-controlled、Prompts user-controlled；若要提模型可讀取 resource，另加一句「host 可把 resource 納入模型上下文」。
6. **P2 / 建議改善：安裝命令未釘版本，削弱可重現性。**
   第 02 章 CLI 範例 `02-nuget-packages.md:62` 到 `02-nuget-packages.md:70` 未加 `--version 1.4.0`，但全文以 v1.4.0 為基準。建議至少在教學主線命令釘版本，另註明可移除版本參數以取得最新版。

## 逐章審查結果

### 第 01 章：什麼是 MCP

結論：概念鋪陳清楚，M×N → M+N 的教學價值高。需調整處是「Resources 由誰主導」的措辭，以及延伸閱讀中的附錄 C 目前不存在。背景宣稱「官方 .NET 實作（與 Microsoft 合作維護）」可保留，但建議附上上游 repo 或 NuGet source 作為出處。

### 第 02 章：SDK 三套件選擇與安裝

結論：套件分層與 TFM 表經上游 `.csproj` 抽查可成立。建議把 CLI 安裝命令釘 `--version 1.4.0`，並補齊或移除附錄 A 引用。Authentication namespace 與 NuGet package 的區分寫得清楚，是本章強項。

### 第 03 章：第一個 MCP Server

結論：高階 builder 路徑與低階 `McpServer.Create` 的分工清楚，namespace 提醒有價值。未發現需立即修正的 API 問題。建議低階路徑段落補一句「此骨架尚需 transport 執行迴圈」以免初學者誤以為 `Create` 後已開始處理請求。

### 第 04 章：第一個工具

結論：工具 attribute、命名規則、stdio 紀律都寫得好。需修正 `IMcpServer` 為 `McpServer`，並同步更新「相關章節」描述。這是跨章一致性問題，也是可編譯性風險。

### 第 05 章：工具進階

結論：本章是全書品質較高章節之一，DI 判定、`McpServer` 注入、錯誤模型、structured content 與 annotations 都有實務價值。`IMcpServer` 風險已在本章正確修正。建議在第一方修第 04 章時，用本章的 wording 回填。

### 第 06 章：Prompts

結論：Prompts 與 Tools 的對稱性講得清楚，回傳型別表實用。需與第 01 章統一 Resources 控制權用語，避免「應用/使用者」與「應用/模型」兩種說法並存。其餘未發現阻斷問題。

### 第 07 章：Resources

結論：直接資源、範本資源、訂閱機制都涵蓋到位，但二進位 resource 範例是本次審查最明確的程式碼風險。請優先修正 `BlobResourceContents` 用法，並考慮在範例旁加一句「只有手上已是 base64 UTF-8 bytes 時才直接設定 `Blob`」。

### 第 08 章：傳輸層與 Sessions

結論：stdio、Streamable HTTP、stateful/stateless 的取捨表清楚，對部署決策有幫助。`StreamClientTransport` namespace 陷阱也提前提醒。未發現需立即修正問題。建議若第 19 章改用 `2025-11-25`，本章可補一句 latest protocol version 由 SDK 預設協商。

### 第 09 章：通知、進度、Logging 與 Completion

結論：進度 token、logging bridge、completion handler 的分層說明清楚，且有避免「stateless 下所有通知都不能用」的常見誤解。未發現阻斷問題。建議可補一個手動 logging 時檢查 `LoggingLevel` 的小片段，但不是必要。

### 第 10 章：建立 MCP Client

結論：client API 主線完整，tools/resources/prompts 都有涵蓋。需處理附錄 B 不存在的引用；若附錄暫不補，應把「見附錄 B」改成指向本章或 README 的版本記錄。`complex_prompt` 參數型別提醒是好的細節。

### 第 11 章：完整天氣 Server

結論：整合章節教學性佳，能把前面 primitives、DI、stdio 與 client 煙霧測試串起來。需清掉第 13 章「規劃中」殘留。另建議明確說明 `States` 字典「其餘州略」若照抄會查不到大多數州，避免讀者以為是完整資料。

### 第 12 章：ASP.NET Core 託管

結論：HTTP 託管、CORS、session production options 的密度高，部署導向明確。需清理第 13、14、18、19 章「規劃中」殘留。`PerSessionExecutionContext` 與 session migration 的描述可保留，但建議標註這些屬高階部署議題，初學者可先跳過。

### 第 13 章：測試策略

結論：測試分層、in-memory transport 接線與可重用 fixture 都很有價值，且能補足前面章節的驗證路徑。未發現需立即修正問題。建議 `server.RunAsync()` 的 fire-and-forget 可補上測試 fixture 會在 dispose 等待 `_serverTask`，避免讀者照抄最小版後吞掉背景例外。

### 第 14 章：Sampling

結論：server → client 反向請求與 capability 協商說明清楚，假 LLM 測試也有教學價值。需清理第 16 章「規劃中」殘留。繁中標點在本章開始明顯混用半形逗號，建議與前半章統一。

### 第 15 章：Elicitation

結論：與 Sampling 的差異講得好，`accept` / `decline` / `cancel` 分支有完整提醒。URL 模式只概述是合理取捨。未發現需立即修正問題；建議補一句「URL 模式完成狀態如何回 server」指向上游測試，讓讀者知道本章故意不展開。

### 第 16 章：LLM 整合

結論：`McpClientTool : AIFunction` 是全書主軸之一，本章說明到位；`UseFunctionInvocation()` 的錯誤提醒很實用。未發現阻斷問題。建議在 NuGet 清單中更明確拆出：MCP SDK、`Microsoft.Extensions.AI` middleware、供應商 client 三者各自來源。

### 第 17 章：Tasks

結論：實驗性功能有清楚標示，`MCPEXP001`、task store、async 工具自動 Optional 等重點明確。上游抽查顯示 `IMcpTaskStore` namespace 與 task client 方法描述可成立。未發現需立即修正問題。

### 第 18 章：Authorization 與傳輸安全

結論：Authorization 與 transport security 的分層正確，`RequireAuthorization()`、challenge scheme、audience 驗證的提醒有實務價值。建議把 `serverUrl = "http://localhost:7071/"` 明確標註為 local dev；production 應使用 HTTPS resource URL 與確切 `AllowedHosts`。README 已註明 OAuth flow 未端對端實測，建議本章也放一句同樣聲明。

### 第 19 章：Docker 部署

結論：Dockerfile、health check、非 root、curl 煙霧測試內容完整。需確認並統一 protocol version：若全書基準是 `2025-11-25`，curl initialize 與實測回應不宜停在 `2025-06-18`，除非明確說明這是舊版相容測試。其他部署建議合理。

### 第 20 章：Native AOT

結論：AOT 危險區、source-gen JSON context、命名策略陷阱都寫得很務實，是很好的收尾章。未發現需立即修正問題。建議把「10MB」標註為 `osx-arm64` 實測值，避免讀者在其他 RID 上得到不同大小時誤判失敗。

## 整體修訂建議

- 先修 P1：第 07 章 `BlobResourceContents` 範例、第 04 章 `IMcpServer`。
- 再做完稿清理：移除「規劃中」、處理附錄引用、統一 wiki-style `[[...]]` 是否要保留給最終讀者。
- 最後做一致性 pass：protocol version、primitive 控制權、繁中標點、安裝命令版本釘選。
