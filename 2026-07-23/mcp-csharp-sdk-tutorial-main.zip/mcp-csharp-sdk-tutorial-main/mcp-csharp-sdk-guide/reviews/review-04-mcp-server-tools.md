# 審查說明：第 04 章「第一個工具，用 stdio 跑起來」

> 對應檔案：[`../04-mcp-server-tools.md`](../04-mcp-server-tools.md)
> 製作時期：2026-07 上旬 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建——製作過程摘要為事後整理）

## 章節概要

第一個工具章：`[McpServerToolType]`/`[McpServerTool]` 兩 attribute、工具方法形狀
（static/實例、回傳型別、`[Description]`、schema 自動生成）、`WithTools<T>` vs
`WithToolsFromAssembly` 兩種註冊、stdio 執行與 client 驗證、**snake_case 命名規則**
（`GetAlerts` → `get_alerts`）、`McpException` 預告。

## 製作過程摘要（事後整理）

- 依 Pipeline D 由 wiki `mcp-server-tools` + `stdio-transport` 草擬，經人工 review 移入
 （對應草稿存檔 `outputs/draft-mcp-server-tools.2026-07-09.bak.md`）。
- 核心結構宣告的驗證脈絡：`McpServerToolAttribute`（kb 驗證探測 4：ns
  `ModelContextProtocol.Server`、套件 .Core）、`WithToolsFromAssembly`（kb 驗證 in_degree=4）、
  `WithTools`（in_degree=63）。
- **snake_case 命名規則**（本章最重要的防雷點）：撰寫時來自源碼分析，後於 ch13 以
  `dotnet test` 實測印證（`Echo`→`echo`、`Add`→`add`、`GetAlerts`→`get_alerts` 斷言通過）——
  此宣稱現在有執行期證據。
- 範例來源：`TestServerWithHosting/Tools/EchoTool.cs`、`QuickstartWeatherServer`（原文節錄）。
- **本章程式碼未經獨立編譯驗證**,但 EchoTool 同型程式碼在 ch13 測試專案完整編譯執行過。

## 已知取捨與風險點（請多看一眼）

1. **「去掉非同步方法的 Async 字尾」**：snake_case 說明中的附帶宣稱，ch13 實測未覆蓋
  （測試方法無 Async 字尾工具），請對照 SDK 命名程式碼確認。
2. **MCP Inspector 的提及**（上手範例）：一筆帶過「或 MCP Inspector」，該工具不在
   raw/ 素材內，教學未展開——確認提及方式不會誤導讀者以為後文會教。
3. **「特定型別參數被特別對待」**：DI 服務與框架型別排除於 schema 的規則，本章只給結論
  （細節指向 ch05），結論本身與 ch11/ch13 實測行為一致。
4. **EchoTool 範例回傳 `"hello " + message`**：上游 sample 原文如此；ch13 自撰的 EchoTools
   回傳 `"Echo: {message}"`——兩章的 echo 行為不同但各自一致，確認讀者不會混淆。
5. **`McpException` 的 namespace**（`ModelContextProtocol` 根）：與 ch11/ch13 實測 using 一致。

## 審查 checklist

### A. 結構宣告

- [ ] 兩 attribute 全名與 namespace/套件歸屬
- [ ] `WithToolsFromAssembly(Assembly?, JsonSerializerOptions?)` 簽名
- [ ] snake_case 規則（含 Async 字尾去除——風險點 1）與 SDK 實作一致
- [ ] `McpException : Exception`、ns `ModelContextProtocol`

### B. 程式碼

- [ ] EchoTool 與上游 `TestServerWithHosting` 原文一致
- [ ] client 驗證段可編譯（與 ch01 同源片段）
- [ ] `CallToolAsync("echo", ...)` 的名稱與命名規則自洽

### C. 敘述

- [ ] 「寫工具就像寫普通方法」的定位是否過度承諾（trimming/AOT 下有例外——ch20 已補，確認本章不與之矛盾）
- [ ] stdio 「不印 stdout」的行為描述準確
- [ ] 常見錯誤五條（特別是「只標方法不標類別掃不到」）與 SDK 行為一致

### D. 教學品質

- [ ] snake_case 防雷點的醒目程度（📌 區塊）是否足夠
- [ ] 與 ch03/05/08/10 的接力是否順暢
- [ ] 繁中語感；骨架完整
