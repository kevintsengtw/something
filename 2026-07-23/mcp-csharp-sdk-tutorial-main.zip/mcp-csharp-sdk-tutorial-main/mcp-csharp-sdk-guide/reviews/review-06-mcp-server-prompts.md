# 審查說明：第 06 章「Prompts（可重用提示範本）」

> 對應檔案：[`../06-mcp-server-prompts.md`](../06-mcp-server-prompts.md)
> 製作時期：2026-07-13 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建——製作過程摘要為事後整理）

## 章節概要

Prompts 章：三 primitive 控制權對比（模型/使用者/應用）、與 tools 完全對稱的定義方式、
回傳型別四階（string→ChatMessage→IEnumerable→GetPromptResult）、`AllowedValues` 參數補全、
四種註冊方式、參數注入對稱性、`Role` vs `ChatRole` 的防雷。

## 製作過程摘要（事後整理）

- 依 Pipeline D 由 wiki `mcp-server-prompts` 草擬，經人工 review 移入。
- 範例來源：`EverythingServer/Prompts/SimplePromptType.cs`、`ComplexPromptType.cs`（原文）；
  `GetPromptResult`/`Summarize` 範例為自撰。
- 結構宣告的驗證脈絡：`McpServerPrompt` 繼承鏈與 attribute namespace（kb 圖譜）；
  `WithPromptsFromAssembly`（wiki frontmatter 事實）；`GetPromptResult`/`PromptMessage` 的
  required 屬性（原始碼）。章內罕見地加了說明框註明「注入機制由原始碼驗證，官方 samples
  無示範」——這種透明度是好慣例。
- **本章程式碼未經編譯驗證**;後續章節亦未回頭覆蓋 prompts（ch13–20 的測試都以 tools 為主）——
  **prompts 是全書實測覆蓋最薄的 primitive**,審查時值得優先抽驗。

## 已知取捨與風險點（請多看一眼）

1. **實測薄弱**（見上）：`WithPrompts<T>` 註冊、`GetPromptAsync` 往返、`AllowedValues` 補全
   全都沒有執行期驗證。若第二意見要動手驗證，建議用 ch13 的測試基底加一個 prompts 測試
  （`builder.WithPrompts<T>()` + `client.ListPromptsAsync/GetPromptAsync`）。
2. **`AllowedValuesAttribute` 自動補全（1.1.0，#1380）**：版本與行為宣稱來自 release notes／
   wiki 事實層，未實測補全請求。
3. **prompt 名稱的命名規則**：上游範例都顯式給了 `Name`;未指定 `Name` 時是否同 tools 的
   snake_case 規則，**本章沒有宣告**（刻意迴避）——審查者可確認此留白不會造成誤導。
4. **「回傳 string 會包成一則 user 訊息」**：來自文件，未實測 wire 格式。
5. **`ComplexPromptType` 範例引用 `TinyImageTool.MCP_TINY_IMAGE`**：上游原文如此，
   但教學讀者拿不到該常數（沒展示其定義）——照抄會編譯失敗，確認上下文有無足夠提示。

## 審查 checklist

### A. 結構宣告

- [ ] `McpServerPrompt`（abstract class : IMcpServerPrimitive）與兩 attribute 的 ns/套件
- [ ] `GetPromptResult`/`PromptMessage` 結構（required Content/Role）與原始碼一致
- [ ] `WithPrompts` 四種多載存在
- [ ] `AllowedValuesAttribute` 屬 `System.ComponentModel.DataAnnotations`（BCL）且 SDK 確實讀它

### B. 程式碼

- [ ] 兩個上游範例與現行原始碼一致
- [ ] 自撰範例（Review/Summarize）可編譯（風險點 1——優先抽驗）
- [ ] 風險點 5：`MCP_TINY_IMAGE` 引用的呈現方式

### C. 敘述

- [ ] 三 primitive 控制權表與 ch01 一致
- [ ] 「與 tools 完全對稱」的宣稱邊界（注入、命名、探索）是否過度推廣
- [ ] `Role` vs `ChatRole` 防雷準確

### D. 教學品質

- [ ] 「prompt 是範本不是動作」的心智模型是否清楚
- [ ] 與 ch04/05/07/09/10 的路標正確
- [ ] 繁中語感；骨架完整
