# 審查說明：第 01 章「什麼是 MCP（Model Context Protocol）」

> 對應檔案：[`../01-what-is-mcp.md`](../01-what-is-mcp.md)
> 製作時期：2026-06-30 前後（教學初期）｜ 基準：ModelContextProtocol v1.4.0 / MCP 規格 2025-11-25
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建——ch01–12 落地當時尚無 reviews/ 慣例，製作過程摘要為事後整理）

## 章節概要

全書開篇概念章：M×N 整合問題與 MCP 的 M+N 解法、JSON-RPC 2.0 通訊模型、兩種主要傳輸
（stdio／Streamable HTTP）、三種 server primitive（Tools/Resources/Prompts）與進階互動的預告、
最小 server／工具／client 三段程式碼的「先看輪廓」展示、`McpClientTool : AIFunction` 的前瞻。
無對應 C# API（協定概念章）。

## 製作過程摘要（事後整理）

- 依 Pipeline D 由 wiki `what-is-mcp` 草擬，經人工 review 移入。
- 程式碼三段的來源：server 與工具取自上游 `samples/QuickstartWeatherServer`（原文節錄），
  client 段簡化自 `samples/QuickstartClient`。
- **本章程式碼未經獨立編譯驗證**（編譯驗證慣例自 ch11 起才建立）；但同型程式碼在後續章節
 （ch04/ch10/ch11）都有完整可編譯版本，間接背書。
- `McpClient.CreateAsync`／`ListToolsAsync` 等 API 經 codebase-memory-mcp 驗證
 （kb 建立時的七項探測含 `McpClient.CreateAsync`,in_degree=99）。

## 已知取捨與風險點（請多看一眼）

1. **歷史性宣稱**：「Anthropic 在 2024 年提出」「與 Microsoft 合作維護」——常識級背景，
   未附出處，請確認表述精確（例如 SDK 的維護方措辭）。
2. **「實作 MCP 規格 2025-11-25 版」**：v1.4.0 與規格版本的對應取自 kb 事實層，
   審查者可對照上游 release notes。
3. **三 primitive 的「由誰主導」欄**（模型/應用/使用者）：取自 MCP 規格的
   model-controlled/app-controlled/user-controlled 分類，翻譯後的語感是否精確值得看。
4. **client 段程式碼的註解**提到「v1.4.0 新增的子行程環境變數控制」——結構性宣稱
  （`InheritEnvironmentVariables` 等）僅在註解中出現，正文未驗證展開（ch10 有完整版）。
5. 開篇章的**簡化風險**：為了輪廓清晰，部分敘述刻意粗略（如「Tools 是會改變狀態的動作」）；
   與後續章節的精確定義是否矛盾，請通讀對照。

## 審查 checklist

### A. 結構宣告

- [ ] 三段程式碼與上游 QuickstartWeatherServer / QuickstartClient 現行原始碼一致
- [ ] `McpClientFactory` 已不存在、入口為 `McpClient.CreateAsync` 的宣稱（常見錯誤 4）正確
- [ ] `McpClientTool : AIFunction` 與外部套件歸屬（📌 註記）正確

### B. 程式碼

- [ ] server 骨架（AddMcpServer/WithStdioServerTransport/WithTools<T>/LogToStandardErrorThreshold）可編譯
- [ ] client 骨架（StdioClientTransport 選項）可編譯
- [ ] 「概念示意」的 ChatOptions 段與 ch16 的完整版一致

### C. 敘述

- [ ] M×N → M+N 的說法是否準確傳達協定價值
- [ ] 兩種傳輸的適用場景描述與 ch08 一致
- [ ] stdio「stdout 專供協定」警告與 ch04 一致
- [ ] 風險點 1–3 的背景宣稱查證

### D. 教學品質

- [ ] 「先不求看懂每一行」的期望管理是否有效
- [ ] 各段落指向後續章節的路標（03/04/10/16）是否正確且足夠
- [ ] 繁中語感；骨架完整
