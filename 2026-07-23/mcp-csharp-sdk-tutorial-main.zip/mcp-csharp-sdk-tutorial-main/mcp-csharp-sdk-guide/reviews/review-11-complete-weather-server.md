# 審查說明：第 11 章「實作範例——組裝一個完整的天氣 Server」

> 對應檔案：[`../11-complete-weather-server.md`](../11-complete-weather-server.md)
> 製作日期：2026-07-15 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建；製作過程有當日完整記錄，非事後回溯）

## 章節概要

整合實作章：以官方 `QuickstartWeatherServer` 為骨架（`WeatherTools.GetAlerts`/`GetForecast`
原文＋`HttpClientExt`），自撰 `WeatherResources`（直接資源 `weather://usage` ＋範本資源
`weather://states/{code}`），tools＋resources 同台組裝、DI 佈線（HttpClient 作工具參數注入，
與 ch05 的 IHttpClientFactory 建構式注入對照）、stderr logging、六步驟 walkthrough、
`McpClient` 煙霧測試收尾。含 tool vs resource 的選型決策表。

## 製作過程摘要（製作當日記錄）

- **本章建立了「移入前編譯驗證」慣例**：全章程式碼組成 scratchpad 專案
 （net9.0、ModelContextProtocol 1.4.0 + Microsoft.Extensions.Hosting 9.0.6）`dotnet build`,
  並以 client 煙霧測試實跑（列工具、呼叫 `get_alerts`、讀兩種資源）。
- **編譯驗證抓到 CS0718**：自撰 `WeatherResources` 原為 `public static class`,但
  `WithResources<T>()` 泛型參數不能是 static class——修正為非 static（方法保持 static），
  並把此陷阱寫入本章常見錯誤與 wiki 兩條目。這是「圖譜驗證抓不到 C# 語言層限制」的
  實證案例，也是編譯驗證慣例的起點。
- 圖譜驗證：`McpServerResource` attribute 屬性、`WithResources`（in_degree=8）等；
  `TextResourceContents` 用法沿 ch07 已驗事實。
- 後續 ch12 把本章 Tools/Resources **零修改**搬上 HTTP 再次全綠；ch13/ch16 的測試又
  拿 `WeatherTools` 當測試對象（假 HttpMessageHandler）——本章程式碼是全書被重複驗證最多的。

## 已知取捨與風險點（請多看一眼）

1. **NWS API 的行為描述**（alerts JSON 結構、`/points/{lat},{lon}` 兩段式查詢）：
   來自上游 sample 原文與其註解，教學未實際打過 api.weather.gov（煙霧測試時工具有真的出網路——
   當時網路可用且回應正常，但 JSON 結構的完整性宣稱仍以 sample 為據）。
2. **自撰 `WeatherResources` 的 URI scheme（`weather://`）**：自創示範，非上游 sample;
   scheme 命名慣例是否符合 MCP 生態習慣，審查者可評估。
3. **tool vs resource 決策表**：規範性內容（作者觀點），與 ch01/ch07 的原則一致但更細，
   請確認無過度簡化。
4. **`HttpClient` 參數注入 vs 建構式注入的對照**（與 ch05）：兩種寫法都經編譯/執行驗證，
   「何時選哪個」的建議是作者判斷。
5. **煙霧測試依賴真網路**：章節的驗證步驟需要能連 api.weather.gov;離線讀者照做會失敗，
   章節是否有足夠提示，請確認。

## 審查 checklist

### A. 結構宣告

- [ ] `WeatherTools` 兩方法與上游 QuickstartWeatherServer 現行原文一致
- [ ] `[McpServerResource]` 屬性用法（UriTemplate/Name/MimeType）與 ch07 一致
- [ ] CS0718 限制的表述精確（static class 不能當泛型引數是 C# 規則，非 SDK 規則）

### B. 程式碼

- [ ] 全章程式碼可依六步驟重建並編譯（scratchpad 專案結構在章內有呈現）
- [ ] `WeatherResources` 非 static 類別＋static 方法的形態正確
- [ ] 煙霧測試片段與 ch10 的 client 用法一致

### C. 敘述

- [ ] 風險點 1：NWS API 描述與 sample 原文一致
- [ ] 「工具參數注入」的機制描述與 ch05 的 `IServiceProviderIsService` 判定一致
- [ ] 決策表與前章原則無矛盾

### D. 教學品質

- [ ] 作為第一個「整合章」，從 ch04–07 積木到完整 server 的組裝敘事是否流暢
- [ ] 六步驟 walkthrough 可照做程度
- [ ] 交叉引用正確；繁中語感；骨架完整
