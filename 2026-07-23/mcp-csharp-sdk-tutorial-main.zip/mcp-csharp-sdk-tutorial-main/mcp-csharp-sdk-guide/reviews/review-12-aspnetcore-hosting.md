# 審查說明：第 12 章「ASP.NET Core 託管 MCP Server」

> 對應檔案：[`../12-aspnetcore-hosting.md`](../12-aspnetcore-hosting.md)
> 製作日期：2026-07-15 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)
> （本文件為 2026-07-16 補建；製作過程有當日完整記錄，非事後回溯）

## 章節概要

部署章（與 ch08 分工：概念在彼、實務在此）：三步佈線（`AddMcpServer` + `WithHttpTransport` +
`MapMcp`），實證 ch11 的 Tools/Resources **零修改**搬上 HTTP;CORS 整合（`Mcp-Session-Id`
標頭的允許與暴露）；`ConfigureSessionOptions` 做 per-session 客製（含
`AspNetCoreMcpPerSessionTools` 的 `app.MapMcp("/{toolCategory?}")` 路由技巧）；
**production 選項表**（直接從 `HttpServerTransportOptions.cs` 原始碼整理，含 wiki 未載的
`SessionMigrationHandler`、`PerSessionExecutionContext`、`ISseEventStreamStore` 實際型別名）；
v1.4.0 session 使用者綁定（GET/POST/DELETE 不同使用者 → 403）。

## 製作過程摘要（製作當日記錄）

- 圖譜驗證：`WithHttpTransport`（in_degree=92）、`MapMcp`（in_degree=78）等；
  `HttpServerTransportOptions` **全部屬性**以 `get_code_snippet` 讀原始碼逐項核實——
  發現多項 wiki 未記載的事實（`Stateless` 預設 false 與其犧牲清單、`ConfigureSessionOptions`
  在 stateful 為每 session 一次/stateless 為每請求、`RunSessionHandler` 為 MCPEXP002 且原文
  說「consider using ConfigureSessionOptions instead」而非「已取代」、`IdleTimeout` 2h/5s
  背景檢查/過期 resume 回 404、`MaxIdleSessionCount` 10,000 超限 critical log＋終止最舊）。
- **編譯驗證**：上手範例組成 scratchpad web 專案（Microsoft.NET.Sdk.Web、
  ModelContextProtocol.AspNetCore 1.4.0），ch11 的 Tools/Resources 原檔複製後 `dotnet build`
  0 警告 0 錯誤，client 驗證片段一併編譯。
- **後續再驗**：ch19 把本章成品容器化並實測 MCP 協定往返（initialize/tools-list 全通）——
  本章佈線的執行期正確性由 ch19 背書。
- wiki 措辭偏差處理：wiki `sessions` 條目稱 ConfigureSessionOptions「取代」RunSessionHandler,
  本章依原始碼採較弱措辭（未修 wiki——當時判斷屬語氣差異非事實錯誤）。

## 已知取捨與風險點（請多看一眼）

1. **production 選項表**：多數選項（EventStreamStore/SessionMigrationHandler/
   PerSessionExecutionContext/IdleTimeout/MaxIdleSessionCount）只驗證了「存在與文件語意」，
   **無執行期驗證**（過期 404、session 遷移等行為未實測）。
2. **per-session tools 段**：`AspNetCoreMcpPerSessionTools` sample 節錄，未編譯執行
  （route 參數 `{toolCategory?}` 的行為以 sample 原文為據）。
3. **CORS 段**：標頭清單（`MCP-Protocol-Version`、`Mcp-Session-Id`、
   `WithExposedHeaders("Mcp-Session-Id")` 對 stateful 必要）來自 sample 與文件，
   瀏覽器端未實測。
4. **session 使用者綁定（403）**：從 `StreamableHttpHandler.HandleDeleteRequestAsync` 等
   原始碼讀出，未實測多使用者情境（ch18 的 review 也標了同一點）。
5. **「零修改搬移」的宣稱**：編譯層面成立（原檔複製 build 過）；執行層面由 ch19 容器
   實測補足——宣稱可信，但「任何 ch11 型 server 都零修改」是單例推廣。

## 審查 checklist

### A. 結構宣告

- [ ] `HttpServerTransportOptions` 選項表逐列對照原始碼（含預設值與 Experimental 標記）
- [ ] `RunSessionHandler` 的措辭（consider using vs 已取代）與原始碼 XML docs 一致
- [ ] `MapMcp` 回傳型別支援 `.RequireAuthorization()` 鏈式（ch18 用到）
- [ ] `ISseEventStreamStore`（.Core）/`ISessionMigrationHandler`（.AspNetCore）型別名與套件歸屬

### B. 程式碼

- [ ] 上手範例（三步佈線）可編譯——已驗，對照即可
- [ ] CORS 範例與 `AspNetCoreMcpServer` sample 一致
- [ ] per-session 範例與 `AspNetCoreMcpPerSessionTools` sample 一致（風險點 2）

### C. 敘述

- [ ] stateless 犧牲清單（sampling/elicitation/roots/主動通知）與 ch08/ch14/ch15 一致
- [ ] `ConfigureSessionOptions` 的「stateful 每 session／stateless 每請求」時機描述正確
- [ ] 風險點 4 的 403 行為描述精確（「不再終止 session」的 v1.4.0 變更）

### D. 教學品質

- [ ] 與 ch08 的分工（概念 vs 實務）是否清楚，無大段重複
- [ ] production 選項表對初學者的可讀性（是否需要「先跳過」的指引）
- [ ] 交叉引用正確；繁中語感；骨架完整
