# 審查說明：第 14 章「Sampling——伺服器借用客戶端的 LLM」

> 對應檔案：[`../14-sampling.md`](../14-sampling.md)
> 製作日期：2026-07-16 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)

## 章節概要

教 sampling（server 反向請 client 的 LLM 生成內容）：訊息流與 capability 協商、server 端
`McpServer.SampleAsync`（協定原生與 M.E.AI 兩多載）與 `AsSamplingChatClient()`、client 端
`McpClientOptions.Handlers.SamplingHandler` 與 `CreateSamplingHandler(IChatClient)`、
以及用假 `SamplingHandler` 做 in-memory 測試（延續 ch13）。第六部分（伺服器↔客戶端進階）首章。

## 製作過程摘要

**圖譜＋原始檔驗證**：`McpServer.SampleAsync` 兩多載（in_degree=16）、`AsSamplingChatClient`
（in_degree=5，不支援時丟 `InvalidOperationException`——docstring 載明）、`CreateSamplingHandler`
（in_degree=7，**namespace 是根 `ModelContextProtocol`**）、`McpClientHandlers.SamplingHandler`
委派型別（原始檔 `Client/McpClientHandlers.cs` L88）、capability 自動宣告
（`McpClientImpl` `_options.Capabilities.Sampling ??= new()`）、`CreateMessageResult` 的
required 屬性（`Content`、`Model`）與 `StopReason` 常數為 internal。

**程式碼實測**：範例併入 ch13 的 xunit 專案，`dotnet test` 11/11 通過，其中 ch14 相關 3 個：
假 handler 摘要往返、`AsSamplingChatClient` 路徑、client 未掛 handler → 工具 `IsError`。
client 真實佈線片段（`CreateSamplingHandler`）以不執行的 snippet 編譯驗證。

**重要事實修正**：wiki `sampling` 條目原示意碼把 handler 掛在 `SamplingCapability.SamplingHandler`——
v1.4.0 原始碼證實**該屬性不存在**（`SamplingCapability` 只有 `Context`/`Tools`），正確位置是
`McpClientOptions.Handlers`。已同步修正 wiki 條目（2026-07-16）並寫入本章常見錯誤 3。

**內容來源**：wiki `sampling`；上游 `samples/ChatWithTools/Program.cs`（client 佈線）、
`samples/TestServerWithHosting/Tools/SampleLlmTool.cs`（server 工具與參數建構）。

## 已知取捨與風險點（請多看一眼）

1. **「stateless 不支援 sampling」**（核心概念＋常見錯誤 5）：依據是 ch12 引用過的
   `HttpServerTransportOptions.Stateless` 原始碼註解，本章**未實測** stateless 下 sampling 失敗的
   具體表現（error code / 例外型別）。
2. **「SystemPrompt／推論參數是建議不是命令」**：來自 MCP 規格語意（client 有最終決定權），
   屬敘述性宣告，SDK 端無強制，值得對照官方 sampling 文件確認措辭。
3. **`IncludeContext` 的說明**：「client 未宣告對應 capability 時應保守用 None」來自
   `SamplingCapability.Context` 的 XML docstring；教學把它壓縮成一格表格，可能過簡。
4. **訊息流 ASCII 圖**：自撰，方向與時序請對照實測（工具呼叫中發生 sampling 往返）驗證。
5. **常見錯誤 1 的建議**（先查 `server.ClientCapabilities?.Sampling` 再走 LLM 路徑）：
   `ClientCapabilities` 屬性名經圖譜見過（ch12 曾用），但**此屬性路徑本章未編譯驗證**。

## 審查 checklist

### A. 結構宣告（對照 `../../csharp-sdk/` v1.4.0）

- [ ] `SampleAsync` 兩多載簽名與回傳型別（`src/ModelContextProtocol.Core/Server/McpServer.Methods.cs`）
- [ ] `AsSamplingChatClient(JsonSerializerOptions?)` 存在且丟 `InvalidOperationException` 的條件正確
- [ ] `McpClientHandlers.SamplingHandler` 委派型別四個型別參數順序正確
- [ ] `CreateSamplingHandler` 的宣告位置（`AIContentExtensions`,根 namespace）
- [ ] `SamplingCapability` 在 v1.4.0 確實只有 `Context`/`Tools`（`Protocol/SamplingCapability.cs`）
- [ ] `CreateMessageResult.Content`/`Model` 為 `required`；`StopReason` 常數為 internal
- [ ] 風險點 5：`McpServer.ClientCapabilities` 屬性存在且可如建議使用

### B. 程式碼

- [ ] `SummarizeTools.Summarize` 可編譯，`CreateMessageRequestParams` 欄位名全部正確
- [ ] client 佈線片段（含三行 using）可編譯——特別是 `using ModelContextProtocol;`
- [ ] 測試範例與 ch13 `McpServerTestBase` 銜接正確（`CreateClientAsync(McpClientOptions?)` 簽名已在 ch13 出現或本章有說明）
- [ ] `"endTurn"` 等字串值與協定/SDK internal 常數一致

### C. 敘述

- [ ] 訊息流圖的方向（`sampling/createMessage` 為 server→client）正確
- [ ] 「掛 handler 即自動宣告 capability」與 SDK 行為一致
- [ ] M.E.AI 多載的翻譯規則（System→SystemPrompt、ModelId→hint、MaxOutputTokens→MaxTokens）與原始碼一致
- [ ] 風險點 1–3 的宣稱皆有據
- [ ] 「server 出 prompt,client 出模型」的比喻不造成誤導（如忽略 host 審核角色）

### D. 教學品質

- [ ] 「為什麼需要」的兩個動機（金鑰／模型選擇權）是否成立且足夠
- [ ] 與 ch05/ch09/ch10/ch12/ch13 的交叉引用正確，對 ch16 的前瞻不至於劇透過多
- [ ] 假 LLM 測試段是否自然銜接 ch13（讀者不需回頭重讀也能懂）
- [ ] 繁中語感、術語與前章一致；骨架八段落皆有實質內容
