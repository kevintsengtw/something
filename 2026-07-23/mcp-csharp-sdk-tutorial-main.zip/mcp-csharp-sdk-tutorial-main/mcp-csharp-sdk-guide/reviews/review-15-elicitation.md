# 審查說明：第 15 章「Elicitation——工具執行中向使用者徵詢輸入」

> 對應檔案：[`../15-elicitation.md`](../15-elicitation.md)
> 製作日期：2026-07-16 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)

## 章節概要

教 elicitation（server 經 client 向使用者徵詢輸入）：accept/decline/cancel 三種結局、
受限 JSON Schema 表單、型別化 `ElicitAsync<T>`（自動 schema＋自動反序列化）與協定原生
`ElicitAsync(ElicitRequestParams)`（手寫 schema）、client 端 `ElicitationHandler`、URL 模式簡介、
假 handler 測試。與 ch14 是對照組：sampling 問模型，elicitation 問人。

## 製作過程摘要

**圖譜＋原始檔驗證**：兩個 `ElicitAsync` 多載簽名（`McpServer.Methods.cs` L305/L673）、
型別化模式的 schema 生成規則（僅 string/number/boolean/string-enum,不支援成員被忽略——docstring 載明）、
`ElicitRequestParams`（Mode form/url、required Message、巢狀 schema 類別、url 模式需 ElicitationId）、
`ElicitResult`（Action 預設 "cancel"、IsAccepted、Content 為 JsonElement 字典）、
`McpClientHandlers.ElicitationHandler` 委派型別、capability 自動宣告（`McpClientImpl` L229,
未細指時預設 form）。

**程式碼實測**：dotnet test 15/15,ch15 相關 4 個——型別化 accept（含 camelCase 鍵名 name/seats
實測確認）、型別化 decline、手寫 `BooleanSchema` 確認流程（client 端還斷言了收到的 schema 型別）、
無 handler → `IsError`。

**修正**：wiki `elicitation` 條目 client 端示意碼原掛在 `ElicitationCapability`（與 sampling 條目
同型的過時寫法），已同步改為 `Handlers.ElicitationHandler` 並補上兩多載與 Action 語意（2026-07-16）。

**內容來源**：wiki `elicitation`；上游 `ElicitationTypedTests.cs`（型別化用法）、
`UrlElicitationTests.cs`（URL 模式，僅引述未展開）。

## 已知取捨與風險點（請多看一眼）

1. **「LLM 完全不在這條路徑上」**（為什麼需要）：指協定訊息流不經過模型。host 應用實作上
   仍可能把 elicitation 呈現在聊天介面裡，措辭是否過強請斟酌。
2. **camelCase 鍵名宣稱**：實測基於**預設序列化選項**。若使用者自帶 `JsonSerializerOptions`
  （`RequestOptions.JsonSerializerOptions`），命名規則隨之改變——章節在常見錯誤 2 有提「依序列化選項生成」，
   但主文範例只展示預設情況。
3. **「靜默失敗」宣稱**（常見錯誤 2）：鍵名不符時「拿到預設值而不是報錯」——這是依 System.Text.Json
   預設行為（大小寫敏感、缺鍵給預設值）推得，**未做專門實測**。
4. **URL 模式小節**：全部來自原始碼 docstring 與測試檔名，本章未實測 url 模式。
5. **常見錯誤 5** 是規範性建議（elicitation 不是參數設計的後門），屬作者觀點，非上游文件明文。

## 審查 checklist

### A. 結構宣告（對照 `../../csharp-sdk/` v1.4.0）

- [ ] `ElicitAsync` 兩多載簽名與回傳型別（`ValueTask<ElicitResult>` / `ValueTask<ElicitResult<T>>`）
- [ ] `ElicitResult.Action` 預設值確為 `"cancel"`;`IsAccepted` 為大小寫不敏感比對
- [ ] schema 類別的巢狀路徑（`ElicitRequestParams.RequestSchema`、`.BooleanSchema` 等）正確
- [ ] `ElicitationHandler` 委派型別（兩參數，無 IProgress——與 sampling 的三參數不同）
- [ ] capability 自動宣告與「未細指時預設 form」的描述正確（`McpClientImpl.cs` L229–234）
- [ ] 「url 模式必須設 ElicitationId」「URL 只能放 Url 欄位」與原始碼 docstring 一致

### B. 程式碼

- [ ] `ReservationForm`/`ReservationTools` 可編譯，`[Description]` 出現在型別與參數的位置正確
- [ ] `DangerousCleanup` 的 `Properties` 集合初始化語法（`RequestSchema.Properties` 是 get-only 屬性的集合初始化）合法
- [ ] client handler 骨架可編譯（`JsonSerializer.SerializeToElement` 用法）
- [ ] 測試範例與 ch13 基底銜接一致
- [ ] 工具名 snake_case（`reserve`、`dangerous_cleanup`）與第 4 章規則一致

### C. 敘述

- [ ] 三種 Action 的表格與 SDK/規格語意一致
- [ ] 「受限 schema 子集」的支援清單（含 enum 多選為唯一集合形態）正確
- [ ] 風險點 2/3：序列化命名與靜默失敗的描述是否需要加限定語
- [ ] sampling vs elicitation 的對照（問模型/問人）是否準確
- [ ] 「stateless 不支援」與 ch12/ch14 的說法一致

### D. 教學品質

- [ ] 三個使用情境（缺參數/確認/多步驟）是否貼切
- [ ] 型別化優先、手寫進階的順序是否合理
- [ ] 危險操作「預設不做」的安全語氣是否清楚
- [ ] 與 ch05/ch12/ch13/ch14 交叉引用正確；繁中語感與骨架完整性
