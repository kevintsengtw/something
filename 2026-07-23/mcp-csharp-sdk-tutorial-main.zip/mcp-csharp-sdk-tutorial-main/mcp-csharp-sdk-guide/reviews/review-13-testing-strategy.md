# 審查說明：第 13 章「測試策略」

> 對應檔案：[`../13-testing-strategy.md`](../13-testing-strategy.md)
> 製作日期：2026-07-16 ｜ 基準：ModelContextProtocol v1.4.0
> 審查方法總則見 [README.md](./README.md)

## 章節概要

教 MCP server 的測試分層：(1) 工具方法當普通 C# 方法做單元測試；(2) 用 in-memory transport
（`StreamServerTransport` ↔ `StreamClientTransport`，兩條 `Pipe` 對接）在同行程內走完整 MCP 協定做整合測試；
(3) 仿上游 `ClientServerTestBase` 抽出 DI 版測試基底；(4) 用假 `HttpMessageHandler` 替換外部相依，
把第 11 章的天氣 Server 放上測試檯。位置：第五部分（ASP.NET Core 與正式環境）收尾章，銜接 ch11/ch12 的實作劇情。

## 製作過程摘要

**圖譜驗證（codebase-memory-mcp @ v1.4.0，9 項全過）**：
`StreamServerTransport` 建構子 `(Stream inputStream, Stream outputStream, string? serverName = null, ILoggerFactory? loggerFactory = null)`、
`StreamClientTransport` 建構子 `(Stream serverInput, Stream serverOutput, ILoggerFactory? loggerFactory = null)`、
`McpServer.Create(ITransport, McpServerOptions, ILoggerFactory?, IServiceProvider?)`（callers=73）、
`McpServer.RunAsync`（in_degree=75）、`WithStreamServerTransport(this IMcpServerBuilder, Stream, Stream)`（in_degree=15）、
`McpServerTool.Create`（實作端 in_degree=172）、`McpClientTool.CallAsync`（in_degree=14）、
`McpClient.CreateAsync` / `CallToolAsync`（前章已驗，in_degree 99/137）。
namespace 陷阱（`StreamClientTransport` 在 `ModelContextProtocol.Protocol`）以上游原始檔 grep 確認。

**程式碼實測**：全章程式碼組成 xunit 專案（net9.0、ModelContextProtocol 1.4.0、
Microsoft.Extensions.DependencyInjection 9.0.6、xunit 2.9.2、Microsoft.NET.Test.Sdk 17.12.0），
`dotnet test` **8/8 通過**（EchoToolsUnitTests ×3、InMemoryEndToEndTests ×1、HostedEchoServerTests ×3、
WeatherServerIntegrationTests ×1）。這章特殊之處：範例本身就是測試，所以驗證強度是「執行通過」而非僅編譯。

**內容來源**：wiki `testing-strategy` + `in-memory-transport`；上游 `samples/InMemoryTransport/Program.cs`
（低階組裝範例的直接出處）、`tests/ModelContextProtocol.Tests/ClientServerTestBase.cs`
（DI 版基底的改寫來源）、`samples/TestServerWithHosting`（僅引述）。

## 已知取捨與風險點（請多看一眼）

1. **`McpException` → `IsError` 的行為描述**（「進階用法」DI 版小節末段）：宣稱「`McpException` 訊息原文
   送到 client；一般例外只得到通用錯誤訊息」。前半句經測試實證；**後半句（一般例外的遮蔽行為）沿用
   第 5 章的說法，本章沒有對應測試**。若要嚴格，可加一個丟 `InvalidOperationException` 的工具驗證。
2. **`ClientServerTestBase` 的簡化改寫**：本章的 `McpServerTestBase` 去掉了 xunit v3 專屬 API 與 C# `field`
   關鍵字，並把 logging 相關註冊拿掉。`DisposeAsync` 的清理順序照抄上游，但簡化後是否在所有失敗情境下
   都不掛住，只在 8 個測試的範圍內驗證過。
3. **中文測試方法名**（如 `工具名稱依預設轉為snake_case`）：刻意示範、實測合法。若讀者環境或團隊慣例
   不容，是教學呈現的取捨問題，非正確性問題。
4. **管線方向的文字說明**（「核心概念」接線圖與「常見錯誤 1」）：方向口訣是自撰敘述，雖與實測程式碼
   一致，文字本身值得用接線圖再對一次。
5. **「上游測試專案幾乎全部建立在這個模式上」**（為什麼需要／進階用法）：定性宣稱，依據是
   `ClientServerTestBase` 的繼承使用廣度，未逐一清點。

## 審查 checklist

### A. 結構宣告（對照 `../../csharp-sdk/` v1.4.0 原始碼）

- [ ] `StreamServerTransport` 建構子參數順序與預設值（`src/ModelContextProtocol.Core/Server/StreamServerTransport.cs`）
- [ ] `StreamClientTransport` 建構子與 **namespace = `ModelContextProtocol.Protocol`**（`src/ModelContextProtocol.Core/Client/StreamClientTransport.cs`）
- [ ] `McpServer.Create` 四參數簽名（`src/ModelContextProtocol.Core/Server/McpServer.Methods.cs`）
- [ ] `WithStreamServerTransport` 是 `ModelContextProtocol` 套件（非 .Core）的 builder 擴充
- [ ] 「兩個類別都在 `ModelContextProtocol.Core` 套件」的說法與 csproj/檔案位置一致

### B. 程式碼（可重建驗證：xunit 專案 + 上列五個 NuGet 套件版本）

- [ ] 上手範例三段（EchoTools／單元測試／低階端對端）可直接複製編譯
- [ ] `McpServerTestBase` 可編譯，且 `DisposeAsync` 順序（cancel → Complete ×2 → await task）與敘述一致
- [ ] `WeatherServerIntegrationTests` 引用的 `WeatherTools` 與第 11 章一致（HttpClient 參數注入）
- [ ] `StubHttpMessageHandler` primary constructor 寫法在 net9.0 下合法
- [ ] 步驟 1 的 `dotnet add` 指令逐條可執行（含 `Microsoft.Extensions.DependencyInjection` 的必要性）

### C. 敘述

- [ ] 「為什麼需要」的三傳輸對比表與第 8 章的傳輸層描述不矛盾
- [ ] 接線圖（`clientToServerPipe`/`serverToClientPipe` 方向）與程式碼中 Reader/Writer 的取用完全對應
- [ ] 風險點 1：一般例外遮蔽訊息的說法，與第 5 章及上游行為一致
- [ ] 「常見錯誤」五項的症狀描述（卡住／CS0246 等）是否準確
- [ ] 測試分層表格（單元／整合／端對端）的定位與速度宣稱合理

### D. 教學品質

- [ ] 從「工具就是普通方法」到「DI fixture」的難度梯度是否平滑
- [ ] 與 ch11（待測物）、ch12（對照的真實部署）、ch5/ch8/ch10 的交叉引用是否都成立
- [ ] snake_case 命名斷言與第 4 章的命名規則描述一致
- [ ] 繁中語感與術語一致性（transport／工具／資源譯法同前章）
- [ ] 骨架八段落皆有實質內容
