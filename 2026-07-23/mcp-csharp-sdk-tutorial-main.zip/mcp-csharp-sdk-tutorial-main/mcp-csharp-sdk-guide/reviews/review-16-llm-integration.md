# 審查說明：第 16 章「與 LLM 整合——把 MCP 工具餵給 IChatClient」

> 對應檔案：[`../16-llm-integration.md`](../16-llm-integration.md)
> 製作日期：2026-07-16 ｜ 基準：ModelContextProtocol v1.4.0 + Microsoft.Extensions.AI 10.8.0
> 審查方法總則見 [README.md](./README.md)

## 章節概要

教 MCP × LLM 的整合：M.E.AI 抽象速覽、`McpClientTool : AIFunction` 橋接、
`UseFunctionInvocation()` 自動工具迴圈、對話迴圈（含串流）、`WithName`/`WithDescription`/
`WithProgress` 裝飾、以及「有劇本的假 LLM」測試法。呼應 ch01 的 M×N 命題與 ch14 的反向整合。

## 製作過程摘要

**驗證**：`McpClientTool` 的四個裝飾方法逐一在原始檔定位（`Client/McpClientTool.cs`
L250/L274/L295/L328）；`McpClientTool : AIFunction` 繼承關係沿 kb 既有驗證（基底為外部型別）。
`IChatClient`/`ChatOptions`/`FunctionCallContent` 等外部 M.E.AI 型別**不做簽名宣告**,
全部以「編譯＋執行通過的程式碼」呈現。

**程式碼實測**：dotnet test 17/17,ch16 相關 2 個——(1) `ListToolsAsync` 的每個工具可指派為
`AIFunction`；(2) 核心測試：自製 `ScriptedChatClient`（兩輪劇本）經 `AsBuilder().UseFunctionInvocation().Build()`
包裝後，對 in-memory 天氣 server 的問題自動觸發 `get_alerts` 呼叫，第二輪收到的
`FunctionResultContent` 內含 stub NWS 資料——證明 middleware→AIFunction→CallToolAsync 全鏈路。
**相容性實證**：ModelContextProtocol 1.4.0 + Microsoft.Extensions.AI 10.8.0（net9.0）還原、編譯、執行無警告。

**內容來源**：wiki `mef-ai-integration` + `mcp-client-tools`；上游 `samples/ChatWithTools/Program.cs`
（上手範例的骨架來源；原 sample 的 OpenTelemetry 與 everything server 改為連 ch11 天氣 server）。

## 已知取捨與風險點（請多看一眼）

1. **上手範例未整體編譯**：OpenAI 供應商部分（`OpenAIClient`、`AsIChatClient()`）來自上游 sample
   原文改寫，本章測試專案**沒有**引用 `Microsoft.Extensions.AI.OpenAI`,該段程式碼未經編譯驗證
  （MCP 端與迴圈邏輯則有假 LLM 測試背書）。OpenAI SDK 的 API 若有變動，此段會過時。
2. **M.E.AI 表格的角色描述**（三分鐘認識小節）：對外部套件的概括性敘述，基於 M.E.AI 公開文件常識，
   未逐項對照官方文件。
3. **「`InvokeAsync` 在底層就是 `CallToolAsync`」**：行為上由測試證實（透過 AIFunction 路徑呼叫
   確實執行了工具），但「底層實作」的說法未貼原始碼佐證。
4. **`AddMessages(response)` 與 `AddMessages(updates)`**：兩個多載的存在依上游 sample 與實測
   （非串流版在測試中未直接用到 `AddMessages`）。串流段落整段取自上游 sample,未在測試中執行。
5. **版本宣稱**：「實測 10.8.0 相容」是單點驗證，不构成範圍保證；讀者用其他版本組合可能遇到
   abstractions 版本衝突——常見錯誤 4 已提示「以還原成功為準」。

## 審查 checklist

### A. 結構宣告

- [ ] `McpClientTool` 四個 With* 方法存在且為不可變裝飾（回傳新實例）（`Client/McpClientTool.cs`）
- [ ] `McpClientTool : AIFunction` 繼承鏈正確（`AIFunction` 屬 M.E.AI.Abstractions）
- [ ] `ChatOptions.Tools` 型別為 `IList<AITool>`（常見錯誤 2 的前提）
- [ ] `StdioClientTransport` 的選項欄位（`Command`/`Arguments`/`Name`）與 ch10 用法一致

### B. 程式碼

- [ ] 上手範例：MCP 端＋迴圈部分可編譯（OpenAI 三行除外——見風險點 1,可對照上游 sample 原文）
- [ ] `ScriptedChatClient` 實作了 `IChatClient` 全部成員，且在最新 M.E.AI 下仍編譯
- [ ] `[.. tools]` collection expression 語法正確
- [ ] `WithProgress(new Progress<ProgressNotificationValue>(...))` 型別對得上（ch09 的型別）
- [ ] 測試碼兩個斷言的邏輯（回答文字＋工具真的執行過）站得住

### C. 敘述

- [ ] UseFunctionInvocation 迴圈圖的時序正確（模型宣告→執行→回填→再問）
- [ ] 「一次 GetResponseAsync 可能多輪工具往返」正確
- [ ] 雙向整合表（本章 vs ch14）方向沒有寫反
- [ ] 常見錯誤 1 的症狀描述（拿到未執行的工具呼叫描述）是否準確
- [ ] M.E.AI 表格（風險點 2）無誤導

### D. 教學品質

- [ ] 與 ch01 M×N 的首尾呼應是否自然
- [ ] 「你的程式碼沒有一行提到工具名稱」的對比是否有力且準確
- [ ] 假 LLM 測試段的難度是否過高（它是全書最複雜的測試碼之一）——若嫌深，是否至少可安全跳過
- [ ] 交叉引用（ch01/ch10/ch11/ch13/ch14）正確；繁中語感與骨架完整性
