# 審查說明：第 19 章「Docker 部署」

> 對應檔案：[`../19-docker-deployment.md`](../19-docker-deployment.md)
> 製作日期：2026-07-16 ｜ 基準：ModelContextProtocol v1.4.0 ｜ Docker 29.6.1（macOS/Apple Silicon）
> 審查方法總則見 [README.md](./README.md)

## 章節概要

DevOps 章：把 ch12 的 HTTP MCP server（加 health endpoint）容器化——多階段 Dockerfile、
stateless 水平擴展、非 root、port 佈局、curl 煙霧測試（含真實 MCP 協定往返輸出）、
環境變數組態、stdio server 容器化（`docker run -i` 作為 `StdioClientTransport` 的 Command）。
無新 C# API。

## 製作過程摘要

**全流程實測**（本書驗證強度最高的章節之一）：
- `docker build`（sdk:9.0 → aspnet:9.0 多階段）成功
- `docker run -p 18080:8080` 後：`GET /health` → `Healthy`
- **真實 MCP 協定**：`POST` initialize（protocolVersion 2025-06-18）→ SSE 格式回應，
  serverInfo=WeatherServerHttp、capabilities 含 logging/resources/tools（章節引用的回應即實測原文）
- `tools/list` → `get_alerts`/`get_forecast`
- `docker exec whoami` → `app`（`USER $APP_UID` 非 root 生效）

**C# 部分**：只在 ch12 已驗證的 Program.cs 上加 `AddHealthChecks`/`MapHealthChecks`
（ASP.NET Core 標準 API），容器內編譯（publish）即驗證。

**內容來源**：wiki `docker-deployment`（Dockerfile 骨架，本章改為 9.0 tag 並實測）、
raw/docs-conceptual/transports.md（Accept 標頭、安全）、.NET 官方容器慣例。

## 已知取捨與風險點（請多看一眼）

1. **單平台實測**：macOS/Apple Silicon（linux/arm64 映像）。x64 環境與雲端 K8s 未測，
   但 Dockerfile 無平台特定內容。
2. **「.NET 8+ 預設聽 8080」**（常見錯誤 1）：官方容器映像行為，本章仍顯式設了
   `ASPNETCORE_URLS`,該宣稱本身未單獨驗證（沒測「拿掉 ENV 後聽哪」）。
3. **「缺 Accept 標頭會被拒絕」**（常見錯誤 2）：來自 Streamable HTTP 規格與官方文件，
   **未實測**具體回應碼（措辭刻意用「會被拒絕」而非具體 4xx）。
4. **stdio 容器化段落**：`docker run -i` 模式的 client 程式碼**可編譯等級**的正確性沿
   `StdioClientTransport` 已驗選項，但未實際打包一個 stdio 映像跑通。
5. **映像大小宣稱**（「aspnet:9.0 約略百餘 MB」「sdk 多數百 MB」）：概略值，未給實測數字——
   審查者可 `docker images` 對照。
6. **health checks 是 liveness 級**：`AddHealthChecks()` 無自訂檢查，只證明行程活著；
   章節未展開 readiness 與依賴檢查，是否足夠請評估。

## 審查 checklist

### A. 結構宣告

- [ ] Dockerfile 指令與 .NET 官方多階段慣例一致（restore 分層、--no-restore）
- [ ] `USER $APP_UID` 在 .NET 9 aspnet 映像有效（實測過，但值得確認文件出處）
- [ ] `StdioClientTransport` 選項（Command/Arguments/Name）與 ch10/ch16 一致
- [ ] initialize 請求 JSON 的欄位（protocolVersion/capabilities/clientInfo）符合規格

### B. 程式碼／指令

- [ ] Program.cs 增量（AddHealthChecks/MapHealthChecks）正確且位置合理（MapHealthChecks 在 MapMcp 前後皆可，確認無誤導）
- [ ] curl 指令可原樣複製執行（引號、跳脫）
- [ ] 引用的 SSE 回應與 stateless 模式行為一致
- [ ] `docker run -e AllowedHosts=...` 的環境變數→組態對映正確（ASP.NET Core 組態鍵規則）

### C. 敘述

- [ ] 「stdio 通常不需容器化」的理由是否成立
- [ ] 水平擴展檢查清單四項與 ch12/ch17/ch18 的說法一致
- [ ] 風險點 2/3/5 的未實測宣稱措辭是否恰當
- [ ] 「TLS 終結在邊界」的建議與 ch18 不矛盾

### D. 教學品質

- [ ] 步驟 1–3 可讓讀者零 Docker 經驗照做成功
- [ ] 實測輸出的呈現（SSE 區塊）是否幫助理解
- [ ] 與 ch12/17/18/20 的交叉引用正確（ch20 尚為「規劃中」，ch20 落地後應回改連結）
- [ ] 繁中語感與骨架完整性
