# 第 04 章：第一個工具，用 stdio 跑起來

> 對應 wiki 概念：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md)、[stdio-transport](../mcp-csharp-sdk-kb/wiki/concepts/stdio-transport.md)
> 上游 API：`McpServerTool` / `[McpServerTool]` / `[McpServerToolType]`（`ModelContextProtocol.Core`）、`WithToolsFromAssembly` / `WithTools<T>`（`ModelContextProtocol`）
> 基準版本：v1.4.0

## 本章目標

讀完本章，你可以：

- 用 `[McpServerToolType]` + `[McpServerTool]` 把一個普通 C# 方法變成 MCP 工具
- 用 `WithTools<T>()` 或 `WithToolsFromAssembly()` 註冊工具
- 用 `[Description]` 讓工具與參數對模型可讀，理解 JSON Schema 自動產生
- 把 server 用 stdio 跑起來，並用 client 驗證工具有被列出與呼叫

## 為什麼需要這個

Tools 是 MCP 三 primitive 中最常用的——它是「讓模型能做事」的入口。MCP C# SDK 的設計目標是：**寫工具就像寫一個普通方法**，attribute 負責把它暴露給協定，參數的 JSON Schema 由 SDK 從方法簽名與 `[Description]` 自動產生，你不必手寫 schema。

## 核心概念

### 兩個 attribute

| Attribute | 標在哪 | 全名（驗證）| 作用 |
|-----------|--------|------|------|
| `[McpServerToolType]` | 類別 | `McpServerToolTypeAttribute` | 標記「這個類別含工具」，供探索 |
| `[McpServerTool]` | 方法 | `McpServerToolAttribute` | 標記「這個方法是一個工具」|

兩者都在 namespace **`ModelContextProtocol.Server`**，屬 **`ModelContextProtocol.Core`** 套件（`using ModelContextProtocol.Server;`）。`[McpServerTool]` 是 `McpServerToolAttribute` 的簡寫。

### 工具方法的形狀

- 可以是 `static` 或實例方法
- 回傳型別彈性大：`string`、物件（會序列化）、`Task<T>`（非同步）皆可
- 參數會自動產生 JSON Schema；用 `[Description]`（來自 .NET BCL `System.ComponentModel`）描述用途
- 特定型別的參數會被「特別對待」而非當成 schema 輸入——例如 DI 服務、`McpServer`（第 05 章詳談）

## 上手範例

### 最小工具：Echo（取自 TestServerWithHosting）

```csharp
// Tools/EchoTool.cs
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerToolType]
public sealed class EchoTool
{
    [McpServerTool, Description("Echoes the input back to the client.")]
    public static string Echo(string message)
    {
        return "hello " + message;
    }
}
```

### 註冊並用 stdio 跑（接續第 03 章）

```csharp
// Program.cs
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithTools<EchoTool>();          // 註冊單一工具類別

builder.Logging.AddConsole(o => o.LogToStandardErrorThreshold = LogLevel.Trace);

await builder.Build().RunAsync();
```

跑起來：

```bash
dotnet run --project ./MyMcpServer
```

stdio server 不會印「Server started」之類的東西到 stdout（那會污染協定）——它就靜靜等 client 透過 stdin 連進來。要驗證它能動，用一個 client（見下）或 MCP Inspector。

### 用 client 驗證（接續第 01 章的片段）

```csharp
using ModelContextProtocol.Client;

var clientTransport = new StdioClientTransport(new()
{
    Name = "Demo Server",
    Command = "dotnet",
    Arguments = ["run", "--project", "./MyMcpServer"],
    // 真實的 QuickstartClient 還設了 InheritEnvironmentVariables = false 與 EnvironmentVariables
    // （v1.4.0 新增的子行程環境變數控制 + 安全強化）——完整版見第 10 章、安全細節見第 18 章。
});

await using var mcpClient = await McpClient.CreateAsync(clientTransport);

foreach (var tool in await mcpClient.ListToolsAsync())
    Console.WriteLine($"工具：{tool.Name} — {tool.Description}");

var result = await mcpClient.CallToolAsync(
    "echo",
    new Dictionary<string, object?> { ["message"] = "MCP" });
```

> 📌 **工具名稱：未指定 `Name` 時，工具名＝方法名的 snake_case 小寫形式**，不是方法名原樣。SDK 預設用 `JsonNamingPolicy.SnakeCaseLower` 正規化方法名（並去掉非同步方法的 `Async` 字尾），所以方法 `Echo` 對外的工具名是 `"echo"`、`GetAlerts` 是 `"get_alerts"`、`EchoComplex` 是 `"echo_complex"`。呼叫端要用正規化後的名字（`CallToolAsync("echo", ...)`）。要固定名稱就用 `[McpServerTool(Name = "...")]` 明確指定。

（完整 client 在第 10 章；這裡只為了「看到工具真的被列出與呼叫」。）

## 進階用法

### 兩種註冊方式

```csharp
// (1) 指定類別（可鏈多次）
builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithTools<EchoTool>()
    .WithTools<WeatherTools>();

// (2) 掃描整個組件，自動找所有 [McpServerToolType]
builder.Services.AddMcpServer()
    .WithStdioServerTransport()
    .WithToolsFromAssembly();        // 無參數＝掃描呼叫端組件
```

- `WithTools<T>()`：精準、明確，適合工具不多或想控制註冊範圍時
- `WithToolsFromAssembly()`：方便，工具一多就不用逐一列；簽名為 `WithToolsFromAssembly(Assembly? toolAssembly = null, JsonSerializerOptions? serializerOptions = null)`，預設掃描呼叫端組件

### 參數描述與自訂工具名稱

`[Description]` 會進到工具/參數的 metadata，讓模型知道何時、如何呼叫（取自 WeatherTools 與 AddTool）：

```csharp
using ModelContextProtocol.Server;
using System.ComponentModel;

[McpServerToolType]
public class AddTool
{
    // 可用 Name 覆寫工具名稱（未指定時取方法名的 snake_case 小寫形式，見下方說明）
    [McpServerTool(Name = "add"), Description("Adds two numbers.")]
    public static string Add(int a, int b) => $"The sum of {a} and {b} is {a + b}";
}
```

```csharp
[McpServerTool, Description("Get weather alerts for a US state.")]
public static async Task<string> GetAlerts(
    HttpClient client,                                          // DI 注入（第 05 章）
    [Description("The US state to get alerts for. Use the 2 letter abbreviation for the state (e.g. NY).")] string state)
{
    // ...
}
```

> 上例的 `HttpClient client` 參數不會變成工具的 input schema——它是被 DI 注入的服務。SDK 對「服務型別」與「`McpServer` 等框架型別」會自動排除於 schema 之外，只把真正的輸入（如 `state`）暴露給模型。細節在第 05 章。

### 錯誤處理：`McpException`

工具內要回報協定層級的錯誤時，丟 `McpException`（`class McpException : Exception`，ns `ModelContextProtocol`，套件 `.Core`）：

```csharp
using ModelContextProtocol;   // McpException

// 節錄自 QuickstartWeatherServer/Tools/WeatherTools.cs 的 GetForecast
var forecastUrl = locationDocument.RootElement.GetProperty("properties").GetProperty("forecast").GetString()
    ?? throw new McpException($"No forecast URL provided by {client.BaseAddress}points/{latitude},{longitude}");
```

（錯誤處理的完整模式——何時用 `McpException`、何時讓例外自然冒泡、如何回傳 `isError` 結果——在第 05 章。）

## 常見錯誤

- **忘了類別上的 `[McpServerToolType]`**：只標方法的 `[McpServerTool]` 不夠，`WithToolsFromAssembly()` 會掃不到該類別。
- **`using` 少了 `System.ComponentModel`**：`[Description]` 編不過（它是 .NET BCL，不是 SDK 型別）。
- **stdio server 印東西到 stdout**：例如 `Console.WriteLine("started")`，會破壞協定。除錯訊息一律走 log（stderr）。
- **以為要手寫 JSON Schema**：不用——schema 由方法簽名 + `[Description]` 自動產生。
- **工具名稱衝突**：兩個工具同名（含 `Name=` 覆寫後相同）會衝突；用 `[McpServerTool(Name = "...")]` 確保唯一。

## 相關章節

- 第 03 章：[mcp-server-builder](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-builder.md) — server 骨架與 `AddMcpServer`
- 第 05 章：[mcp-server-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-server-tools.md)（進階）— DI 注入、`McpServer` 注入、參數 Schema 細節、`McpException` 與錯誤回傳
- 第 08 章：[stdio-transport](../mcp-csharp-sdk-kb/wiki/concepts/stdio-transport.md) — stdio 傳輸與其他傳輸層比較
- 第 10 章：[mcp-client](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client.md)、[mcp-client-tools](../mcp-csharp-sdk-kb/wiki/concepts/mcp-client-tools.md) — 從 client 端列出與呼叫工具

## 延伸閱讀

- 上游 sample：`samples/QuickstartWeatherServer`、`samples/EverythingServer`、`samples/TestServerWithHosting`
- 官方概念文件：Tools（`raw/docs-conceptual/tools.md`）
