using System.Net.Http.Json;
using AutoFixture;
using AwesomeAssertions;
using Dapper;
using Sample.WebApi.IntegrationTests.Fixtures;
using Sample.WebApi.Models;

namespace Sample.WebApi.IntegrationTests.Tests;

/// <summary>
/// 場景二：大量 seed data（數千筆小 INSERT）—— 這正是最容易觸發
/// WRITELOG 等待與間歇性逾時的工作負載，也是 tmpfs 設定要保護的對象。
/// </summary>
public class OrdersBulkSeedTests : IntegrationTestBase
{
    private readonly IFixture _autoFixture = new Fixture();

    public OrdersBulkSeedTests(SqlServerContainerFixture fixture)
        : base(fixture)
    {
    }

    [Fact]
    public async Task GetByShipper_塞入2000筆訂單_分頁查詢應正確()
    {
        // arrange
        var shipperId = await SeedDataHelper.InsertShipperAsync(
            this.ConnectionString, "量販物流");

        var orders = this._autoFixture.Build<Order>()
                         .Without(x => x.OrderId)
                         .With(x => x.ShipperId, shipperId)
                         .With(x => x.OrderDate, DateTime.UtcNow)
                         .With(x => x.Freight, 99.5m)
                         .CreateMany(2000);

        await SeedDataHelper.InsertOrdersAsync(this.ConnectionString, orders);

        // act
        var page3 = await this.Client.GetFromJsonAsync<List<Order>>(
            $"/api/orders/by-shipper/{shipperId}?page=3&pageSize=50");

        // assert
        page3.Should().NotBeNull();
        page3.Should().HaveCount(50);
        page3.Should().OnlyContain(x => x.ShipperId == shipperId);

        await using var connection = this.CreateConnection();
        var total = await connection.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM dbo.Orders WHERE ShipperID = @ShipperId",
            new { ShipperId = shipperId });
        total.Should().Be(2000);
    }

    [Fact]
    public async Task ResetDatabase_前一個測試的資料_不應殘留()
    {
        // 這個測試驗證 Respawn 的隔離效果：
        // 不管前面的測試塞了幾千筆，這裡看到的一定是乾淨的資料庫
        await using var connection = this.CreateConnection();
        var orderCount = await connection.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM dbo.Orders");
        var shipperCount = await connection.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM dbo.Shippers");

        orderCount.Should().Be(0);
        shipperCount.Should().Be(0);
    }
}
