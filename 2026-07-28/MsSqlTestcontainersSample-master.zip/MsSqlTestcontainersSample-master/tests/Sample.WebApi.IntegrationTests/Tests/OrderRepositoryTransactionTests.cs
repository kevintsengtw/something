using AwesomeAssertions;
using Dapper;
using Microsoft.Data.SqlClient;
using Sample.WebApi.IntegrationTests.Fixtures;
using Sample.WebApi.Models;
using Sample.WebApi.Repositories;

namespace Sample.WebApi.IntegrationTests.Tests;

/// <summary>
/// 場景三：交易的 commit 與 rollback —— 這類行為用 mock 驗證不了，
/// 只有真實資料庫能給出可信的答案，是整合測試相對於單元測試的核心價值。
/// 同時示範正確的交易寫法（using + 明確 Commit/Rollback），
/// 對照文章中「洩漏的未提交交易持鎖」的反面教材。
/// </summary>
public class OrderRepositoryTransactionTests : IntegrationTestBase
{
    public OrderRepositoryTransactionTests(SqlServerContainerFixture fixture)
        : base(fixture)
    {
    }

    [Fact]
    public async Task CreateBatchAsync_全部合法_應全數寫入()
    {
        // arrange
        var shipperId = await SeedDataHelper.InsertShipperAsync(
            this.ConnectionString, "交易測試物流");
        var repository = this.CreateRepository();

        var orders = Enumerable.Range(1, 10)
                               .Select(i => new Order
                               {
                                   ShipperId = shipperId,
                                   CustomerName = $"客戶 {i}",
                                   Freight = i * 10m,
                                   OrderDate = DateTime.UtcNow
                               });

        // act
        var affected = await repository.CreateBatchAsync(orders);

        // assert
        affected.Should().Be(10);
    }

    [Fact]
    public async Task CreateBatchAsync_其中一筆違反FK_應全數回復()
    {
        // arrange
        var shipperId = await SeedDataHelper.InsertShipperAsync(
            this.ConnectionString, "回復測試物流");
        var repository = this.CreateRepository();

        var orders = new List<Order>
        {
            new() { ShipperId = shipperId, CustomerName = "合法客戶", Freight = 10m, OrderDate = DateTime.UtcNow },
            new() { ShipperId = 9999, CustomerName = "FK 違規客戶", Freight = 20m, OrderDate = DateTime.UtcNow }
        };

        // act
        var act = async () => await repository.CreateBatchAsync(orders);

        // assert：例外要拋出，且「合法的那一筆」也必須不存在（交易原子性）
        await act.Should().ThrowAsync<SqlException>();

        await using var connection = this.CreateConnection();
        var count = await connection.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM dbo.Orders");
        count.Should().Be(0);
    }

    private OrderRepository CreateRepository()
    {
        return new OrderRepository(
            new TestDbConnectionFactory(this.ConnectionString));
    }

    private sealed class TestDbConnectionFactory : Sample.WebApi.Infrastructure.IDbConnectionFactory
    {
        private readonly string _connectionString;

        public TestDbConnectionFactory(string connectionString)
        {
            this._connectionString = connectionString;
        }

        public System.Data.IDbConnection CreateConnection()
        {
            return new SqlConnection(this._connectionString);
        }
    }
}
