using System.Net;
using System.Net.Http.Json;
using AwesomeAssertions;
using Sample.WebApi.IntegrationTests.Fixtures;
using Sample.WebApi.Models;

namespace Sample.WebApi.IntegrationTests.Tests;

/// <summary>
/// 場景一：透過 WebApplicationFactory 從 HTTP 層驗證 API 完整行為，
/// 資料真實落在 Testcontainers 的 SQL Server。
/// </summary>
public class ShippersApiTests : IntegrationTestBase
{
    public ShippersApiTests(SqlServerContainerFixture fixture)
        : base(fixture)
    {
    }

    [Fact]
    public async Task GetAll_資料庫沒有資料_應回傳空集合()
    {
        // act
        var actual = await this.Client.GetFromJsonAsync<List<Shipper>>("/api/shippers");

        // assert
        actual.Should().NotBeNull();
        actual.Should().BeEmpty();
    }

    [Fact]
    public async Task Create_輸入合法資料_應回傳201並可由GetById取回()
    {
        // arrange
        var shipper = new Shipper { CompanyName = "貓頭鷹物流", Phone = "(02) 1234-5678" };

        // act
        var response = await this.Client.PostAsJsonAsync("/api/shippers", shipper);

        // assert
        response.StatusCode.Should().Be(HttpStatusCode.Created);

        var created = await response.Content.ReadFromJsonAsync<Shipper>();
        created.Should().NotBeNull();
        created.ShipperId.Should().BeGreaterThan(0);

        var fetched = await this.Client.GetFromJsonAsync<Shipper>(
            $"/api/shippers/{created.ShipperId}");
        fetched.Should().NotBeNull();
        fetched.CompanyName.Should().Be("貓頭鷹物流");
    }

    [Fact]
    public async Task Create_CompanyName重複_應回傳409()
    {
        // arrange：直接 seed 一筆既有資料
        await SeedDataHelper.InsertShipperAsync(this.ConnectionString, "重複物流");

        var duplicated = new Shipper { CompanyName = "重複物流" };

        // act
        var response = await this.Client.PostAsJsonAsync("/api/shippers", duplicated);

        // assert
        response.StatusCode.Should().Be(HttpStatusCode.Conflict);
    }

    [Fact]
    public async Task Update_指定的資料不存在_應回傳404()
    {
        // arrange
        var shipper = new Shipper { CompanyName = "不存在物流" };

        // act
        var response = await this.Client.PutAsJsonAsync("/api/shippers/9999", shipper);

        // assert
        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task Delete_指定的資料存在_應回傳204且資料被刪除()
    {
        // arrange
        var shipperId = await SeedDataHelper.InsertShipperAsync(
            this.ConnectionString, "待刪除物流");

        // act
        var deleteResponse = await this.Client.DeleteAsync($"/api/shippers/{shipperId}");
        var getResponse = await this.Client.GetAsync($"/api/shippers/{shipperId}");

        // assert
        deleteResponse.StatusCode.Should().Be(HttpStatusCode.NoContent);
        getResponse.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }
}
