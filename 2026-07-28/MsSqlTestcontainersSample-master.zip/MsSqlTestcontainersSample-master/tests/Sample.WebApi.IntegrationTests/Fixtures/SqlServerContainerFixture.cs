using System.Diagnostics;
using Dapper;
using DotNet.Testcontainers.Builders;
using Microsoft.Data.SqlClient;
using Respawn;
using Sample.WebApi.IntegrationTests.Diagnostics;
using Testcontainers.MsSql;

namespace Sample.WebApi.IntegrationTests.Fixtures;

/// <summary>
/// Collection Fixture：整個測試 collection 共用同一個 SQL Server 容器。
/// 重點設定：
/// 1. data 與 log 目錄掛載 tmpfs（RAM 檔案系統），消滅 WRITELOG 等待與宿主機 I/O 變異，
///    解決 Docker Desktop / WSL2 環境下間歇性的指令逾時（command timeout）問題。
/// 2. 測試資料庫設定 RECOVERY SIMPLE + DELAYED_DURABILITY，測試資料不需要耐久性保證。
/// 3. 透過 Respawn 在測試之間重設資料，而非重建容器。
/// 4. 三層等待策略處理 readiness gap，見 <see cref="BuildContainer"/> 與 <see cref="WarmUpAsync"/>。
/// </summary>
public class SqlServerContainerFixture : IAsyncLifetime
{
    private const string DatabaseName = "SampleDb";

    private const string ImageName = "mcr.microsoft.com/mssql/server:2022-latest";

    /// <summary>
    /// SQL Server 完成復原（recovery）後寫進<b>標準輸出</b>的訊息，實測原文為
    /// <c>Recovery is complete. This is an informational message only. No user action is required.</c>
    /// （UntilMessageIsLogged 會同時比對 stdout 與 stderr，所以走哪一條都能命中，
    ///   但為求精確：這則訊息在 stdout。）
    /// </summary>
    private const string RecoveryCompletePattern = @"Recovery is complete\.";

    private readonly MsSqlContainer _container = BuildContainer();

    private Respawner _respawner = null!;

    /// <summary>
    /// 最近一次暖身探測的結果，供測試與診斷判讀。
    /// </summary>
    public WarmupResult? WarmupResult { get; private set; }

    /// <summary>
    /// 建立容器，並套用「三層等待策略」的第二層（自訂 wait strategy）。
    /// 第一層是 Testcontainers.MsSql 內建的預設策略，第三層見 <see cref="WarmUpAsync"/>。
    /// </summary>
    private static MsSqlContainer BuildContainer()
    {
        // 第一層背景（這裡沒有動它，純粹是換掉它之前要知道的事）：
        // 以 Testcontainers.MsSql 4.13.0 原始碼為準（MsSqlBuilder.Init()）：
        //   .WithWaitStrategy(Wait.ForUnixContainer().AddCustomWaitStrategy(new WaitUntil()))
        // 實際檢查兩件事，全部通過才算就緒：
        //   (a) Wait.ForUnixContainer() 的建構式已經內建 UntilContainerIsRunning，
        //       模式是 WaitStrategyMode.OneShot，只確認容器處於 running 狀態。
        //   (b) MsSqlBuilder 私有巢狀類別 WaitUntil：先用
        //       find /opt/mssql-tools*/bin/sqlcmd -type f -print -quit 找出 sqlcmd 路徑
        //       （結果以 Lazy 快取），再執行 sqlcmd -C -Q "SELECT 1;"，取 ExitCode == 0。
        //       帳密與資料庫不走參數，而是靠 builder 設好的 SQLCMDUSER / SQLCMDPASSWORD /
        //       SQLCMDDBNAME 環境變數；-C 是 trust server certificate。
        // 輪詢參數來自 WaitStrategy 的預設值（可由 TestcontainersSettings 覆寫）：
        //   Interval = 1 秒、Retries = 0（不限次數）、Timeout = 1 小時。
        //
        // 關鍵結論：它只證明「SQL Server 收得到並回得了一個最廉價的查詢」。
        // SELECT 1 不碰 DDL、不寫 log、不需要 buffer pool 就緒。
        // 這正是 readiness gap 的來源，也是第一個測試就逾時的原因，所以下面要換掉它。

        // Testcontainers 4.13.0 起，無參數的 MsSqlBuilder() 已標記為過時（CS0618），
        // 映像檔名稱必須由建構式傳入。
        return new MsSqlBuilder(ImageName)
            .WithTmpfsMount("/var/opt/mssql/data")
            .WithTmpfsMount("/var/opt/mssql/log")
            // 記憶體預算：容器總量與 SQL Server 本體上限是兩層不同的東西，
            // 兩層都要設，理由見 ContainerMemoryBudget。必須排在 WithTmpfsMount 之後。
            .WithMemoryBudget()
            // 陷阱：ContainerConfiguration 對 WaitStrategies 呼叫的是
            // BuildConfiguration.Combine<IEnumerable<WaitStrategy>>(old, new)，
            // 明確指定泛型參數會挑到「純量」多載（新值非 null 就整個取代），
            // 而不是會串接兩個集合的 IEnumerable 多載。
            // 也就是說，WithWaitStrategy 是整組取代，不是追加。
            // 一旦自訂，上面第一層那段內建的 sqlcmd 檢查就消失了，必須自己加回來，
            // 也就是下面的 (2)。此行為由 WaitStrategyReplacementExperimentTests 驗證。
            .WithWaitStrategy(
                Wait.ForUnixContainer()
                    // (1) 等 recovery 真的跑完，而不只是「連得上」。
                    //     加上 timeout 上限：萬一映像檔換版、訊息措辭改變導致永遠比對不到，
                    //     這裡會在 3 分鐘後失敗收場，而不是卡在預設的 1 小時。
                    .UntilMessageIsLogged(
                        RecoveryCompletePattern,
                        strategy => strategy.WithTimeout(TimeSpan.FromMinutes(3)))
                    // (2) 把被取代掉的內建 sqlcmd 檢查加回來。
                    //     sqlcmd 路徑在不同映像檔版本會變（mssql-tools / mssql-tools18），
                    //     所以照抄官方的 find 寫法，不寫死版本號。
                    .UntilCommandIsCompleted(
                        """
                        "$(find /opt/mssql-tools*/bin/sqlcmd -type f -print -quit)" -C -Q "SELECT 1;"
                        """,
                        strategy => strategy.WithTimeout(TimeSpan.FromMinutes(3))))
            .Build();
    }

    /// <summary>
    /// 指向 SampleDb 的連線字串，供 WebApplicationFactory 與測試程式使用。
    /// </summary>
    public string ConnectionString { get; private set; } = string.Empty;

    /// <summary>
    /// 容器啟動（含等待策略）所花的時間。
    /// </summary>
    public TimeSpan ContainerStartDuration { get; private set; }

    /// <summary>
    /// 從呼叫 StartAsync 到資料庫可用（含建庫、建表、Respawn 初始化）的總時間。
    /// </summary>
    public TimeSpan TotalReadyDuration { get; private set; }

    public async Task InitializeAsync()
    {
        var stopwatch = Stopwatch.StartNew();

        await this._container.StartAsync();
        this.ContainerStartDuration = stopwatch.Elapsed;

        // 模組預設連到 master，改指向我們自己的測試資料庫
        var builder = new SqlConnectionStringBuilder(this._container.GetConnectionString())
        {
            InitialCatalog = DatabaseName,
            ConnectTimeout = 30
        };
        this.ConnectionString = builder.ConnectionString;

        // 第三層：best-effort 暖身探測。
        // 位置就是這裡：容器啟動之後、建庫之前。
        await this.WarmUpAsync();

        await this.CreateDatabaseAsync();
        await this.CreateSchemaAsync();

        // Respawn 7.0.0 移除了吃連線字串的多載，一律改吃已開啟的 DbConnection
        await using var respawnConnection = new SqlConnection(this.ConnectionString);
        await respawnConnection.OpenAsync();

        this._respawner = await Respawner.CreateAsync(
            respawnConnection,
            new RespawnerOptions
            {
                DbAdapter = DbAdapter.SqlServer,
                WithReseed = true
            });

        this.TotalReadyDuration = stopwatch.Elapsed;
    }

    public async Task DisposeAsync()
    {
        // 關閉容器前的「終場快照」：若有洩漏的未提交交易，
        // 這裡是抓到它的最後機會（sleeping session 不會自行消失）。
        // 只有真的抓到東西才會寫檔，回傳的路徑在這裡用不上，忽略即可。
        await SqlDiagnosticsDumper.DumpFinalSnapshotAsync(this._container.GetConnectionString());

        await this._container.DisposeAsync();
    }

    /// <summary>
    /// 於每個測試開始前呼叫，將資料庫重設為乾淨狀態（保留結構、清空資料、重設 IDENTITY）。
    /// </summary>
    public async Task ResetDatabaseAsync()
    {
        await using var connection = new SqlConnection(this.ConnectionString);
        await connection.OpenAsync();
        await this._respawner.ResetAsync(connection);
    }

    /// <summary>
    /// 第三層：<see cref="DatabaseWarmupProbe"/>。前兩層都只回答「SQL Server 有沒有在動」，
    /// 這一層回答「它現在扛不扛得住寫入」，不論結果如何都會往下走。
    /// </summary>
    private async Task WarmUpAsync()
    {
        this.WarmupResult = await DatabaseWarmupProbe.RunAsync(
            this._container.GetConnectionString());
    }

    private async Task CreateDatabaseAsync()
    {
        await using var connection = new SqlConnection(this._container.GetConnectionString());
        await connection.OpenAsync();

        // 測試資料庫不需要耐久性：SIMPLE 讓 log 自動回收、
        // DELAYED_DURABILITY 讓 commit 不等待 log 寫入完成
        await connection.ExecuteAsync(
            $"""
             CREATE DATABASE [{DatabaseName}];
             ALTER DATABASE [{DatabaseName}] SET RECOVERY SIMPLE;
             ALTER DATABASE [{DatabaseName}] SET DELAYED_DURABILITY = FORCED;
             """,
            commandTimeout: 120);
    }

    private async Task CreateSchemaAsync()
    {
        var scriptDirectory = Path.Combine(AppContext.BaseDirectory, "database");
        var scripts = Directory.GetFiles(scriptDirectory, "*.sql").OrderBy(x => x);

        await using var connection = new SqlConnection(this.ConnectionString);
        await connection.OpenAsync();

        foreach (var script in scripts)
        {
            var sql = await File.ReadAllTextAsync(script);
            await connection.ExecuteAsync(sql, commandTimeout: 120);
        }
    }
}
