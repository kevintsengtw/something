using Dapper;
using Microsoft.Data.SqlClient;
using Sample.WebApi.IntegrationTests.Diagnostics;
using Sample.WebApi.Models;

namespace Sample.WebApi.IntegrationTests.Fixtures;

/// <summary>
/// 測試資料建立 helper。
/// 所有 seed 操作統一經過這裡，好處：
/// 1. commandTimeout 預設拉高到 120 秒（容器啟動初期本來就是最慢的時刻）；
///    呼叫端可用 commandTimeout 參數覆寫——實驗性測試需要「幾秒內就逾時」才跑得動
/// 2. 逾時發生時自動觸發診斷快照，把案發現場留在 %TEMP%，
///    並把 log 路徑掛在例外的 Data 上（見 <see cref="DiagnosticsLogPathKey"/>）
/// </summary>
public static class SeedDataHelper
{
    private const int SeedCommandTimeout = 120;

    /// <summary>
    /// 逾時例外的 <see cref="Exception.Data"/> 中，存放診斷 log 路徑所用的 key。
    /// </summary>
    public const string DiagnosticsLogPathKey = "DiagnosticsLogPath";

    public static async Task<int> InsertShipperAsync(
        string connectionString, string companyName, string? phone = null, int? commandTimeout = null)
    {
        const string sql =
            """
            INSERT INTO dbo.Shippers (CompanyName, Phone)
            VALUES (@CompanyName, @Phone);
            SELECT CAST(SCOPE_IDENTITY() AS int);
            """;

        return await ExecuteWithDiagnosticsAsync(
            connectionString,
            async connection => await connection.ExecuteScalarAsync<int>(
                sql, new { CompanyName = companyName, Phone = phone },
                commandTimeout: commandTimeout ?? SeedCommandTimeout));
    }

    public static async Task InsertOrdersAsync(
        string connectionString, IEnumerable<Order> orders, int? commandTimeout = null)
    {
        const string sql =
            """
            INSERT INTO dbo.Orders (ShipperID, CustomerName, Freight, OrderDate)
            VALUES (@ShipperId, @CustomerName, @Freight, @OrderDate);
            """;

        await ExecuteWithDiagnosticsAsync(
            connectionString,
            async connection => await connection.ExecuteAsync(
                sql, orders, commandTimeout: commandTimeout ?? SeedCommandTimeout));
    }

    private static async Task<T> ExecuteWithDiagnosticsAsync<T>(
        string connectionString, Func<SqlConnection, Task<T>> action)
    {
        await using var connection = new SqlConnection(connectionString);
        try
        {
            return await action(connection);
        }
        catch (SqlException ex) when (ex.Number == SqlDiagnosticsDumper.TimeoutErrorNumber)
        {
            // 逾時的瞬間容器一定還活著（容器要等 Fixture Dispose 才會關），
            // 此刻採證、log 寫到宿主機，之後容器關掉也無所謂
            var logPath = await SqlDiagnosticsDumper.DumpOnTimeoutAsync(connectionString);

            // 把 log 路徑掛在例外上：測試失敗訊息裡就會有「去哪看現場」的線索，
            // 不必靠掃 %TEMP% 的時間戳去猜是哪一個檔
            ex.Data[DiagnosticsLogPathKey] = logPath;
            throw;
        }
    }
}
