using System.Diagnostics;
using AwesomeAssertions;
using Sample.WebApi.IntegrationTests.Fixtures;

namespace Sample.WebApi.IntegrationTests.InfrastructureTests;

/// <summary>
/// 暖身探測的控制流程測試。
/// 這裡不需要資料庫——探測動作以委派注入，測的是「迴圈會不會停」這件事。
/// 初版暖身的死循環缺陷（只有「成功且夠快」和「失敗超時」兩個出口，
/// 漏掉「一直成功但一直不夠快」）就是被這組測試釘住的。
/// </summary>
[Trait("Category", "Unit")]
public class DatabaseWarmupProbeTests
{
    [Fact]
    public async Task RunAsync_探測成功且夠快_應回報就緒且只跑一次()
    {
        // arrange
        var options = new WarmupOptions
        {
            Deadline = TimeSpan.FromSeconds(5),
            FastEnough = TimeSpan.FromSeconds(1),
            RetryDelay = TimeSpan.FromMilliseconds(10)
        };

        // act
        var actual = await DatabaseWarmupProbe.RunAsync(
            _ => Task.CompletedTask, options);

        // assert
        actual.Outcome.Should().Be(WarmupOutcome.Ready);
        actual.Attempts.Should().Be(1);
    }

    [Fact]
    public async Task RunAsync_探測一直成功但一直不夠快_應在deadline到期後放行()
    {
        // arrange：這正是初版死循環的路徑——永遠成功，但永遠慢於門檻
        var options = new WarmupOptions
        {
            Deadline = TimeSpan.FromMilliseconds(600),
            FastEnough = TimeSpan.FromMilliseconds(10),
            RetryDelay = TimeSpan.FromMilliseconds(10)
        };

        var stopwatch = Stopwatch.StartNew();

        // act
        var actual = await DatabaseWarmupProbe.RunAsync(
            async ct => await Task.Delay(TimeSpan.FromMilliseconds(80), ct), options);

        stopwatch.Stop();

        // assert：放行而不是拋例外，而且真的在 deadline 附近就結束
        actual.Outcome.Should().Be(WarmupOutcome.DeadlineReached);
        actual.Attempts.Should().BeGreaterThan(1);
        stopwatch.Elapsed.Should().BeLessThan(TimeSpan.FromSeconds(5));
    }

    [Fact]
    public async Task RunAsync_探測每次都失敗_應在deadline到期後放行而不拋出()
    {
        // arrange
        var options = new WarmupOptions
        {
            Deadline = TimeSpan.FromMilliseconds(400),
            FastEnough = TimeSpan.FromSeconds(1),
            RetryDelay = TimeSpan.FromMilliseconds(20)
        };

        var attempts = 0;

        // act
        var act = async () => await DatabaseWarmupProbe.RunAsync(
            _ =>
            {
                attempts++;
                throw new InvalidOperationException("模擬資料庫還沒準備好");
            },
            options);

        // assert：最差結局是「退回無暖身行為」，不是讓測試套件掛掉
        var actual = await act.Should().NotThrowAsync();
        actual.Which.Outcome.Should().Be(WarmupOutcome.DeadlineReached);
        attempts.Should().BeGreaterThan(1);
    }

    [Fact]
    public async Task RunAsync_探測本身卡住不返回_不應超過deadline太久()
    {
        // arrange：單次探測的 CancellationToken 是從剩餘時間切出來的，
        // 所以即使探測寫得再爛，整體也不會無限等待
        var options = new WarmupOptions
        {
            Deadline = TimeSpan.FromMilliseconds(500),
            FastEnough = TimeSpan.FromMilliseconds(50),
            RetryDelay = TimeSpan.FromMilliseconds(10)
        };

        var stopwatch = Stopwatch.StartNew();

        // act
        var actual = await DatabaseWarmupProbe.RunAsync(
            async ct => await Task.Delay(Timeout.InfiniteTimeSpan, ct), options);

        stopwatch.Stop();

        // assert
        actual.Outcome.Should().Be(WarmupOutcome.DeadlineReached, actual.Trace);
        stopwatch.Elapsed.Should().BeLessThan(TimeSpan.FromSeconds(3), actual.Trace);
        // 這條斷言是防「deadline 邊界忙碌輪詢」的哨兵，不是可有可無的細節。
        // 曾經跑出 attempts=38（其中 37 次耗時 0.0ms）——因為 CancelAfter 與 Task.Delay
        // 都把 TimeSpan 截斷成整數毫秒，剩不到 1 毫秒時兩者都變成 no-op。
        // 修法是 MinimumUsefulBudget：剩餘時間小到做不了事就直接放行。
        actual.Attempts.Should().BeLessThanOrEqualTo(2, actual.Trace);
    }

    [Fact]
    public async Task RunAsync_探測先慢後快_應在轉快的那次回報就緒()
    {
        // arrange
        var options = new WarmupOptions
        {
            Deadline = TimeSpan.FromSeconds(10),
            FastEnough = TimeSpan.FromMilliseconds(50),
            RetryDelay = TimeSpan.FromMilliseconds(10)
        };

        var attempts = 0;

        // act
        var actual = await DatabaseWarmupProbe.RunAsync(
            async ct =>
            {
                attempts++;
                if (attempts < 3)
                {
                    await Task.Delay(TimeSpan.FromMilliseconds(150), ct);
                }
            },
            options);

        // assert
        // 刻意不寫 Attempts == 3：探測耗時是牆上時鐘量出來的，
        // 機器一忙第 3 次也可能被判定為「還不夠快」而多跑幾輪。
        // 這個測試要釘的是「轉快之後會就緒」，不是「剛好第幾次」。
        actual.Outcome.Should().Be(WarmupOutcome.Ready);
        actual.Attempts.Should().BeGreaterThanOrEqualTo(3);
    }

    [Fact]
    public async Task RunAsync_外部要求取消_應往外拋出而非默默放行()
    {
        // arrange：deadline 到期要放行，但呼叫端主動取消是另一回事，不可以吞掉
        var options = new WarmupOptions
        {
            Deadline = TimeSpan.FromSeconds(30),
            FastEnough = TimeSpan.FromMilliseconds(10),
            RetryDelay = TimeSpan.FromMilliseconds(10)
        };

        using var cts = new CancellationTokenSource(TimeSpan.FromMilliseconds(150));

        // act
        var act = async () => await DatabaseWarmupProbe.RunAsync(
            async ct => await Task.Delay(TimeSpan.FromMilliseconds(50), ct),
            options,
            cts.Token);

        // assert
        await act.Should().ThrowAsync<OperationCanceledException>();
    }
}
