using AwesomeAssertions;
using Dapper;
using Microsoft.Data.SqlClient;
using Sample.WebApi.IntegrationTests.Diagnostics;
using Sample.WebApi.IntegrationTests.Fixtures;
using Sample.WebApi.IntegrationTests.Testing;

namespace Sample.WebApi.IntegrationTests.Experiments;

/// <summary>
/// 診斷工具的實證：刻意製造鎖等待與洩漏交易，驗證 SqlDiagnosticsDumper 真的採得到證。
///
/// 這組測試的斷言全部是<b>先跑過、看過原始輸出之後才寫的</b>。
/// 最初的規劃是斷言「Requests 有 blocking_session_id != 0 且 LCK_M_* 等待」，
/// 實測發現那條斷言永遠不會成立——原因見
/// <see cref="CaptureAsync_逾時當下採證_受害者的請求已被取消而不在結果中"/>。
///
/// 預設不執行：測試以 <see cref="ExperimentFactAttribute"/> 標記，
/// 未設定 SAMPLE_TESTS_RUN_EXPERIMENTS 時一律 skip（命令列與 IDE 兩個入口都適用）。
/// </summary>
[Trait("Category", "Experiment")]
public class SqlDiagnosticsDumperExperimentTests : IClassFixture<DiagnosticsExperimentFixture>
{
    /// <summary>
    /// 設成一個目錄路徑，實驗跑完就把當次的快照寫進去，作為文章素材。
    /// 沒設定就不寫——一般執行不該產生 repo 內的檔案。
    /// </summary>
    private const string SampleOutputEnvironmentVariable = "SAMPLE_TESTS_DIAGNOSTICS_OUTPUT";

    private readonly DiagnosticsExperimentFixture _fixture;

    public SqlDiagnosticsDumperExperimentTests(DiagnosticsExperimentFixture fixture)
    {
        this._fixture = fixture;
    }

    /// <summary>
    /// 把快照另存一份到素材目錄（若有設定環境變數）。
    /// 內容與 %TEMP% 落下的 log 完全一致，不做任何改寫。
    /// </summary>
    private static async Task SaveSampleAsync(string name, string content)
    {
        var directory = Environment.GetEnvironmentVariable(SampleOutputEnvironmentVariable);

        if (string.IsNullOrWhiteSpace(directory))
        {
            return;
        }

        Directory.CreateDirectory(directory);
        await File.WriteAllTextAsync(Path.Combine(directory, $"{name}.log"), content);
    }

    /// <summary>
    /// 逾時當下的即時快照：受害者不在，但兇手在。
    ///
    /// command timeout 的機制是用戶端主動取消查詢，在伺服器端觸發 Attention event（error 3617）。
    /// 等 catch 區塊跑起來、採證連線接上去查 DMV 時，受害者的請求已經從
    /// sys.dm_exec_requests 消失了——該檢視只列出「當下正在執行」的請求。
    /// 這是工具的盲點，不是 bug，寫進文章時要誠實揭露。
    /// </summary>
    [ExperimentFact]
    public async Task CaptureAsync_逾時當下採證_受害者的請求已被取消而不在結果中()
    {
        // arrange：兇手持 TABLOCKX 不提交
        await using var blocker = new SqlConnection(this._fixture.ConnectionString);
        await blocker.OpenAsync();
        var transaction = (SqlTransaction)await blocker.BeginTransactionAsync();

        try
        {
            // 先取 SPID 再持鎖 —— dm_exec_input_buffer 給的是最後一個輸入批次，
            // 順序反了證據就會變成 SELECT @@SPID
            var blockerSessionId = await blocker.ExecuteScalarAsync<int>(
                "SELECT @@SPID;", transaction: transaction);

            await blocker.ExecuteAsync(
                "SELECT * FROM dbo.Shippers WITH (TABLOCKX);", transaction: transaction);

            // act：受害者走 SeedDataHelper 的正式路徑寫入，直到 command timeout
            var act = async () => await SeedDataHelper.InsertShipperAsync(
                this._fixture.ConnectionString, "受害者物流", commandTimeout: 5);

            var thrown = await act.Should().ThrowAsync<SqlException>();

            // 明確斷言 -2（command timeout），而不是只收 SqlException。
            // LOCK_TIMEOUT 預設 -1（無限等待），所以會走到 command timeout 而非 error 1222；
            // 哪天環境改了 LOCK_TIMEOUT，這裡要直接紅給我們看。
            thrown.Which.Number.Should().Be(SqlDiagnosticsDumper.TimeoutErrorNumber);

            // 正式路徑有把採證 log 的位置掛回例外上
            var logPath = thrown.Which.Data[SeedDataHelper.DiagnosticsLogPathKey].Should().BeOfType<string>().Subject;
            File.Exists(logPath).Should().BeTrue();
            (await File.ReadAllTextAsync(logPath)).Should().Contain("reason     : timeout");

            // assert：此刻兇手還握著鎖，再採一次證來做結構化斷言
            var snapshot = await SqlDiagnosticsDumper.CaptureAsync(
                this._fixture.ConnectionString, "timeout");

            snapshot.Error.Should().BeNull();

            // (1) 受害者不見了 —— 沒有任何使用者請求在等鎖
            snapshot.Requests.Should().NotContain(
                x => x.BlockingSessionId != 0,
                "受害者的請求已被 attention 取消，dm_exec_requests 留不住它");
            snapshot.Requests.Should().NotContain(
                x => x.WaitType != null && x.WaitType.StartsWith("LCK_M_"),
                "同上：等鎖的那條請求已經不存在");

            // (2) 兇手還在 —— 鎖還握著
            snapshot.Locks.Should().Contain(
                x => x.SessionId == blockerSessionId
                     && x.Resource == "dbo.Shippers"
                     && x.RequestMode == "X"
                     && x.RequestStatus == "GRANT",
                "兇手持有的排他鎖在受害者被取消之後依然留得住");

            // (3) 兇手的未提交交易也還在
            snapshot.OpenTransactions.Should().Contain(
                x => x.SessionId == blockerSessionId
                     && x.OpenTransactionCount > 0
                     && x.Status == "sleeping");

            await SaveSampleAsync("timeout-blocking", SqlDiagnosticsDumper.Format(snapshot));
        }
        finally
        {
            await transaction.RollbackAsync();
            await transaction.DisposeAsync();
        }
    }

    /// <summary>
    /// Requests 段的<b>正向對照</b>，同時回答「判讀表第一列什麼時候才看得到」。
    ///
    /// 前一個測試證明的是「從 catch 路徑採證，受害者已經不在了」。
    /// 但那些斷言全是否定式——如果 Requests 查詢寫壞、永遠回空集合，它們一樣會通過。
    /// 這個測試補上正向證據：受害者<b>還在等的時候</b>採證，就抓得到
    /// blocking_session_id != 0 與 LCK_M_* 等待。
    ///
    /// 差別只在採證時機：不是在 catch 裡（那時已被 attention 取消），
    /// 而是由旁觀者趁受害者仍在等待時採。
    /// </summary>
    [ExperimentFact]
    public async Task CaptureAsync_受害者仍在等待時採證_應抓到blocking關係與LCK_M等待()
    {
        // arrange：兇手持 TABLOCKX 不提交
        await using var blocker = new SqlConnection(this._fixture.ConnectionString);
        await blocker.OpenAsync();
        var transaction = (SqlTransaction)await blocker.BeginTransactionAsync();

        var blockerSessionId = await blocker.ExecuteScalarAsync<int>(
            "SELECT @@SPID;", transaction: transaction);

        await blocker.ExecuteAsync(
            "SELECT * FROM dbo.Shippers WITH (TABLOCKX);", transaction: transaction);

        // 受害者的 command timeout 拉長，讓它在採證期間仍在等待（不 await）
        var victim = SeedDataHelper.InsertShipperAsync(
            this._fixture.ConnectionString, "仍在等待的受害者", commandTimeout: 60);

        try
        {
            // 等它真的進入鎖等待
            await Task.Delay(TimeSpan.FromSeconds(2));

            // act：旁觀者採證
            var snapshot = await SqlDiagnosticsDumper.CaptureAsync(
                this._fixture.ConnectionString, "blocked");

            // assert
            snapshot.Error.Should().BeNull();

            var blocked = snapshot.Requests
                                  .Should().ContainSingle(x => x.BlockingSessionId == blockerSessionId)
                                  .Subject;

            blocked.WaitType.Should().StartWith("LCK_M_");
            blocked.Command.Should().NotBeNullOrWhiteSpace();
            blocked.SqlText.Should().Contain("INSERT INTO dbo.Shippers");
            blocked.WaitTime.Should().BeGreaterThan(0);

            // 兇手這一側也看得到：等待中的鎖會排在最前面
            snapshot.Locks.Should().Contain(x => x.RequestStatus == "WAIT");

            await SaveSampleAsync("blocked-victim-still-waiting", SqlDiagnosticsDumper.Format(snapshot));
        }
        finally
        {
            // 放掉鎖，讓受害者跑完，不留背景工作
            await transaction.RollbackAsync();
            await transaction.DisposeAsync();

            await victim;
        }
    }

    /// <summary>
    /// 終場快照：抓到 sleeping + 未提交交易的 session，且 event_info 看得到那句 SQL。
    /// </summary>
    [ExperimentFact]
    public async Task CaptureAsync_終場快照有洩漏的未提交交易_應抓到並附上該session最後的SQL()
    {
        // arrange
        await using var leaker = new SqlConnection(this._fixture.ConnectionString);
        await leaker.OpenAsync();
        var transaction = (SqlTransaction)await leaker.BeginTransactionAsync();

        try
        {
            var leakerSessionId = await leaker.ExecuteScalarAsync<int>(
                "SELECT @@SPID;", transaction: transaction);

            await leaker.ExecuteAsync(
                "INSERT INTO dbo.Shippers (CompanyName, Phone) VALUES (N'洩漏物流', N'02-0000-0000');",
                transaction: transaction);

            // 讓連線真的進入 sleeping（沒有正在執行的請求，但交易還開著）
            await Task.Delay(TimeSpan.FromSeconds(1));

            // act
            var snapshot = await SqlDiagnosticsDumper.CaptureAsync(
                this._fixture.MasterConnectionString, "final");

            // assert
            snapshot.Error.Should().BeNull();

            var leaked = snapshot.OpenTransactions
                                 .Should().ContainSingle(x => x.SessionId == leakerSessionId)
                                 .Subject;

            leaked.Status.Should().Be("sleeping");
            leaked.OpenTransactionCount.Should().BeGreaterThan(0);
            leaked.EventInfo.Should().Contain("INSERT INTO dbo.Shippers");

            // 未提交的寫入會握著 KEY 或 PAGE 的排他／意圖排他鎖
            snapshot.Locks.Should().Contain(x => x.SessionId == leakerSessionId);

            await SaveSampleAsync("final-open-transaction", SqlDiagnosticsDumper.Format(snapshot));
        }
        finally
        {
            await transaction.RollbackAsync();
            await transaction.DisposeAsync();
        }
    }

    /// <summary>
    /// 採證連線本身失敗時，必須留下失敗原因——「連 dumper 都連不上」這件事本身就是證據。
    /// 順便確認失敗訊息不會把連線資訊（尤其是密碼）寫進 log。
    /// </summary>
    [ExperimentFact]
    public async Task DumpAsync_採證連線失敗_應留下失敗原因且不外洩連線資訊()
    {
        // arrange：指向一個不會有人聽的埠
        var builder = new SqlConnectionStringBuilder(this._fixture.MasterConnectionString)
        {
            DataSource = "127.0.0.1,1"
        };

        var password = builder.Password;
        password.Should().NotBeNullOrEmpty("這個測試的前提是連線字串裡真的有密碼");

        // act
        // 用專屬的 reason，log 表頭與檔名才對得起來（原本借用 final 會讓人比對時困惑）
        var logPath = await SqlDiagnosticsDumper.DumpAsync(builder.ConnectionString, "unreachable");
        var content = await File.ReadAllTextAsync(logPath);

        // assert
        content.Should().Contain("reason     : unreachable");
        content.Should().Contain("DUMPER 採證失敗");
        content.Should().Contain(nameof(SqlException), "例外型別本身就是判讀的依據");
        content.Should().NotContain(password, "採證 log 可能被貼到 issue 或文章，不可以帶出密碼");
        content.Should().NotContain(builder.UserID);

        await SaveSampleAsync("dumper-unreachable", content);
    }
}
