using Dapper;
using Microsoft.Data.SqlClient;
using Sample.WebApi.IntegrationTests.Fixtures;
using Testcontainers.MsSql;

namespace Sample.WebApi.IntegrationTests.Experiments;

/// <summary>
/// 診斷實驗專用的容器。
/// 刻意不共用 <see cref="Fixtures.SqlServerContainerFixture"/>：實驗會製造 TABLOCKX 與未提交交易，
/// 丟進共享容器會讓 Respawn 重設卡住，一般測試就跟著不可信了。
/// </summary>
public class DiagnosticsExperimentFixture : IAsyncLifetime
{
    private const string ImageName = "mcr.microsoft.com/mssql/server:2022-latest";

    private const string DatabaseName = "DiagDb";

    private readonly MsSqlContainer _container = new MsSqlBuilder(ImageName)
        .WithTmpfsMount("/var/opt/mssql/data")
        .WithTmpfsMount("/var/opt/mssql/log")
        .WithMemoryBudget()
        .Build();

    /// <summary>指向 DiagDb 的連線字串。</summary>
    public string ConnectionString { get; private set; } = string.Empty;

    /// <summary>指向 master 的連線字串（採證用）。</summary>
    public string MasterConnectionString => this._container.GetConnectionString();

    public async Task InitializeAsync()
    {
        await this._container.StartAsync();

        this.ConnectionString = new SqlConnectionStringBuilder(this.MasterConnectionString)
        {
            InitialCatalog = DatabaseName,
            ConnectTimeout = 30
        }.ConnectionString;

        await using (var master = new SqlConnection(this.MasterConnectionString))
        {
            await master.OpenAsync();
            await master.ExecuteAsync(
                $"""
                 CREATE DATABASE [{DatabaseName}];
                 ALTER DATABASE [{DatabaseName}] SET RECOVERY SIMPLE;
                 """,
                commandTimeout: 120);
        }

        await using var connection = new SqlConnection(this.ConnectionString);
        await connection.OpenAsync();

        var scriptDirectory = Path.Combine(AppContext.BaseDirectory, "database");

        foreach (var script in Directory.GetFiles(scriptDirectory, "*.sql").OrderBy(x => x))
        {
            await connection.ExecuteAsync(await File.ReadAllTextAsync(script), commandTimeout: 120);
        }
    }

    public async Task DisposeAsync()
    {
        await this._container.DisposeAsync();
    }
}
