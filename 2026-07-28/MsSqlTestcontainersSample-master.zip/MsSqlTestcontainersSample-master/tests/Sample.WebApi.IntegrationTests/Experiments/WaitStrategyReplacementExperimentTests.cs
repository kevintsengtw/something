using System.Diagnostics;
using AwesomeAssertions;
using DotNet.Testcontainers.Builders;
using Microsoft.Data.SqlClient;
using Sample.WebApi.IntegrationTests.Testing;
using Testcontainers.MsSql;
using Xunit.Abstractions;

namespace Sample.WebApi.IntegrationTests.Experiments;

// 為什麼要實測：Testcontainers 4.13.0 的 ContainerConfiguration 對 WaitStrategies 呼叫的是
// BuildConfiguration.Combine<IEnumerable<WaitStrategy>>(old, new)——明確指定泛型參數會選到
// 「純量」多載（新值非 null 就取代舊值），而不是那個會把兩個集合串接起來的 IEnumerable 多載。
// 讀原始碼推得出這個結論，但這種等級的宣稱不能只靠讀，要跑過。
/// <summary>
/// 實驗性測試：驗證 <c>WithWaitStrategy</c> 究竟是「追加」還是「整組取代」內建的等待策略。
/// 換上一個「立刻就會通過」的等待策略，用啟動耗時與事後能不能連線來判斷（見兩個測試的 assert）。
/// 預設不執行，見 <see cref="ExperimentFactAttribute"/>。
/// </summary>
[Trait("Category", "Experiment")]
public class WaitStrategyReplacementExperimentTests
{
    private const string ImageName = "mcr.microsoft.com/mssql/server:2022-latest";

    private readonly ITestOutputHelper _output;

    public WaitStrategyReplacementExperimentTests(ITestOutputHelper output)
    {
        this._output = output;
    }

    [ExperimentFact]
    public async Task WithWaitStrategy_換上立即通過的策略_內建sqlcmd檢查應已被取代()
    {
        // arrange
        var container = new MsSqlBuilder(ImageName)
            .WithTmpfsMount("/var/opt/mssql/data")
            .WithWaitStrategy(Wait.ForUnixContainer().UntilCommandIsCompleted("true"))
            .Build();

        await using var _ = container;

        // act
        var stopwatch = Stopwatch.StartNew();
        await container.StartAsync();
        stopwatch.Stop();

        var connectResult = await TryConnectAsync(container.GetConnectionString());

        this._output.WriteLine(
            $"[experiment/custom] StartAsync={stopwatch.Elapsed.TotalSeconds:F1}s " +
            $"connect={connectResult ?? "OK"}");

        // assert：StartAsync 幾乎沒等，且此刻 SQL Server 還連不上
        //         → 內建的 sqlcmd SELECT 1 檢查確實被整組取代掉了
        stopwatch.Elapsed.Should().BeLessThan(
            TimeSpan.FromSeconds(10),
            "自訂策略若只是追加在內建策略之後，StartAsync 會被 sqlcmd 檢查擋住而等更久");

        connectResult.Should().NotBeNull(
            "SQL Server 尚未就緒，連線應該失敗——這證明就緒檢查沒有被執行");
    }

    [ExperimentFact]
    public async Task WithWaitStrategy_使用內建預設策略_啟動後應可立即連線()
    {
        // arrange：對照組，不動 wait strategy
        var container = new MsSqlBuilder(ImageName)
            .WithTmpfsMount("/var/opt/mssql/data")
            .Build();

        await using var _ = container;

        // act
        var stopwatch = Stopwatch.StartNew();
        await container.StartAsync();
        stopwatch.Stop();

        var connectResult = await TryConnectAsync(container.GetConnectionString());

        this._output.WriteLine(
            $"[experiment/default] StartAsync={stopwatch.Elapsed.TotalSeconds:F1}s " +
            $"connect={connectResult ?? "OK"}");

        // assert
        connectResult.Should().BeNull(
            "內建策略會等到 sqlcmd 能執行 SELECT 1，因此啟動後應該立刻連得上");
    }

    /// <summary>
    /// 嘗試連線並跑一個最廉價的查詢。成功回傳 null，失敗回傳例外訊息。
    /// </summary>
    private static async Task<string?> TryConnectAsync(string connectionString)
    {
        var builder = new SqlConnectionStringBuilder(connectionString)
        {
            ConnectTimeout = 3
        };

        try
        {
            await using var connection = new SqlConnection(builder.ConnectionString);
            await connection.OpenAsync();

            await using var command = connection.CreateCommand();
            command.CommandText = "SELECT 1;";
            command.CommandTimeout = 3;
            await command.ExecuteScalarAsync();

            return null;
        }
        catch (Exception ex)
        {
            return $"{ex.GetType().Name}: {ex.Message}";
        }
    }
}
