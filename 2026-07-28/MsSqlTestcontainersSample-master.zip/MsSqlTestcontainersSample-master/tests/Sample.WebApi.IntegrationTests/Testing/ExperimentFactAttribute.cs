using Xunit.Sdk;

namespace Sample.WebApi.IntegrationTests.Testing;

/// <summary>
/// 實驗性測試專用的 <see cref="FactAttribute"/>：未設定開關時自動 skip。
///
/// 為什麼不能只靠 csproj 的 VSTestTestCaseFilter：
/// 那是 MSBuild 屬性，只有走 dotnet test（經過 MSBuild）才會傳給 VSTest。
/// Visual Studio 與 Rider 的 Test Explorer 直接驅動 VSTest、不經過 MSBuild，
/// 在 IDE 裡按「執行全部」時實驗測試照跑，還會多啟動一顆容器。
///
/// 改用 .runsettings 的 TestCaseFilter 可以涵蓋 IDE，但它會與命令列 filter 以 AND 結合，
/// 導致 filter "Category=Experiment" 變成互斥條件而一個測試都選不到（已實測）。
/// 所以改由測試自己把關：不論從哪個入口進來，沒開開關就不執行。
/// </summary>
[AttributeUsage(AttributeTargets.Method)]
public sealed class ExperimentFactAttribute : FactAttribute
{
    /// <summary>
    /// 啟用實驗性測試的環境變數。設為 true / 1 才會執行。
    /// </summary>
    public const string EnabledEnvironmentVariable = "SAMPLE_TESTS_RUN_EXPERIMENTS";

    public ExperimentFactAttribute()
    {
        if (!IsEnabled())
        {
            this.Skip =
                $"實驗性測試預設不執行（會另外啟動容器、刻意製造逾時與鎖等待）。" +
                $"設定環境變數 {EnabledEnvironmentVariable}=true 後再執行。";
        }
    }

    private static bool IsEnabled()
    {
        var value = Environment.GetEnvironmentVariable(EnabledEnvironmentVariable);

        if (string.IsNullOrWhiteSpace(value))
        {
            return false;
        }

        return value.Trim() is "1"
               || value.Trim().Equals("true", StringComparison.OrdinalIgnoreCase);
    }
}
