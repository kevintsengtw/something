# 診斷快照範例輸出

`SqlDiagnosticsDumper` 在四種情境下的**實際輸出**，未經任何改寫。
由 `SqlDiagnosticsDumperExperimentTests` 產生。

## 重現方式

需要**兩個**環境變數：一個放行實驗測試，一個指定素材輸出目錄。

```powershell
$env:SAMPLE_TESTS_RUN_EXPERIMENTS = 'true'
$env:SAMPLE_TESTS_DIAGNOSTICS_OUTPUT = "$PWD\docs\diagnostics-sample-output"
dotnet test --filter "Category=Experiment"
```

- 沒設 `SAMPLE_TESTS_RUN_EXPERIMENTS`，實驗測試會全部 skip（跑出來是 0 通過 / 6 略過）
- 沒設 `SAMPLE_TESTS_DIAGNOSTICS_OUTPUT` 就不寫檔——一般執行不該在 repo 裡留下產物

## 採證當下的環境

文章的所有宣稱都靠這幾份 log 背書。你在別的環境跑出不同結果時，靠這張表判斷差異來自哪裡。

| 項目 | 版本 |
| --- | --- |
| 作業系統 | Windows 11 專業版 10.0.26200（16 核 / 63.4 GB RAM） |
| Docker Desktop | 4.83.0.234302（WSL2 後端，Linux 容器） |
| Docker Engine / CLI | 29.6.2 |
| SQL Server 映像檔 | `mcr.microsoft.com/mssql/server:2022-latest` |
| 映像檔 digest | `sha256:db9a8fe3098b7e8bbde41106bdc7caee942e97124e5fdb71b872ca208de3092d` |
| SQL Server 版本 | Microsoft SQL Server 2022 (RTM-CU22) (KB5068450) - 16.0.4225.2 (X64)<br>Developer Edition on Linux (Ubuntu 22.04.5 LTS) |
| .NET SDK | 10.0.302 |
| Testcontainers.MsSql | 4.13.0 |
| Microsoft.Data.SqlClient | 7.0.2 |
| 容器儲存 | `/var/opt/mssql/data` 與 `/var/opt/mssql/log` 掛 tmpfs |
| 採證日期 | 2026-07-26 |

## 四份範例

### `timeout-blocking.log` —— 逾時當下的即時快照

情境：連線 A 以 `SELECT * FROM dbo.Shippers WITH (TABLOCKX)` 持鎖不提交，
連線 B 透過 `SeedDataHelper` 寫入，5 秒後 command timeout（`SqlException.Number == -2`），
在 `catch` 內觸發採證。

**這份 log 最重要的一行是「使用者請求 sys.dm_exec_requests（0 筆）」。**

受害者不見了。原因不是 dumper 壞掉，是結構性的：

- `sys.dm_exec_requests` 只列出**當下正在執行**的請求
  （[官方說明](https://learn.microsoft.com/troubleshoot/sql/database-engine/performance/understand-resolve-blocking#gather-information-from-dmvs)）
- command timeout 的機制是**用戶端主動取消查詢**，在伺服器端觸發 Attention event（error 3617）
  （[官方說明](https://learn.microsoft.com/troubleshoot/sql/database-engine/performance/troubleshoot-query-timeouts#symptoms)）

等 `catch` 區塊跑起來、採證連線接上去查 DMV 時，受害者的請求早就不在了。

**行車紀錄器錄得到肇事者，錄不到受害者的最後一刻。** 證據在擋人的那一側：

- `sys.dm_tran_locks`：session 57 對 `dbo.Shippers` 握著 `X` 鎖，`GRANT`（`LockCount: 16` 是同一個 `TABLOCKX` 展開的重複列，已聚合）
- `sys.dm_exec_sessions`：session 57 `sleeping`、`open_transaction_count: 1`、`EventInfo` 就是那句 `TABLOCKX`

### `blocked-victim-still-waiting.log` —— 受害者還在等的時候採證

情境與上一份**完全相同**，只差採證時機：不是在 `catch` 裡採，
而是由旁觀者趁受害者仍在等待（command timeout 拉長到 60 秒）時採。

這一份是上一份的對照組，證明 dumper 的 Requests 段確實會動，
也證明判讀表第一列不是空談——只是**要在對的時機才看得到**：

```json
{
  "SessionId": 89,
  "BlockingSessionId": 57,
  "WaitType": "LCK_M_IX",
  "WaitTime": 2016,
  "WaitResource": "OBJECT: 5:901578250:12 ",
  "Command": "INSERT",
  "SqlText": "...INSERT INTO dbo.Shippers (CompanyName, Phone)..."
}
```

`Locks` 段也同時看得到兩側：session 89 的 `IX` 是 `WAIT`（排在最前面），
session 57 的 `X` 是 `GRANT`。這才是「抓到現行犯」的完整長相。

### `final-open-transaction.log` —— 終場快照

情境：連線開了交易、寫入一筆、然後閒置。這是「洩漏的未提交交易」的標準長相。

`sleeping` + `open_transaction_count: 1` 是鐵證。搭配 `Locks` 段可以看到未提交的寫入
握著 `KEY` 的 `X` 鎖與 `OBJECT` / `PAGE` 的 `IX` 鎖。

### `dumper-unreachable.log` —— 連採證都失敗

情境：採證連線指向沒人聽的埠。log 表頭的 `reason` 是 `unreachable`（與檔名一致）。

**採證失敗本身就是證據**——在真實案例裡，這代表 server 已經全面癱瘓到連一條新連線都給不出來。
所以 dumper 絕不能靜默失敗，一定要留下例外型別與訊息。

已確認這份 log **不會帶出連線字串裡的密碼與帳號**（由 `採證連線失敗_應留下失敗原因且不外洩連線資訊` 測試釘住）。

## 判讀對照表

| 看到什麼 | 結論 | 什麼時候看得到 |
| --- | --- | --- |
| Requests 有 `blocking_session_id != 0` 且 `LCK_M_*` 等待 | 鎖的問題，抓到現行犯 | **不會**出現在 `DumpOnTimeoutAsync` 的 catch 路徑。要在受害者仍在等待時採證：終場快照剛好撞上、獨立觀察者定時採證、或受害者的 command timeout 遠長於採證所需時間（見 `blocked-victim-still-waiting.log`） |
| Requests 空的，但 OpenTransactions 有 sleeping + 未提交交易、Locks 有 `X` 鎖 | 結論一樣是鎖，只是受害者已被 attention 取消 | **command timeout 的典型長相**，也就是 catch 路徑採到的樣子（見 `timeout-blocking.log`） |
| Requests 有 `WRITELOG` / `PAGEIOLATCH_*` 等待 | 宿主機 I/O 壓力（tmpfs 可解） | 同第一列，需要在請求仍在執行時採證 |
| 只有 Error 欄位，其餘皆空 | server 整體資源耗盡，或 dumper 自己出錯——看例外型別分辨 | 任何時候（見 `dumper-unreachable.log`） |

**這張表最容易誤用的地方是第一列。** Phase 3 的實測結論是：
從 `catch (SqlException ex) when (ex.Number == -2)` 進來的採證，第一列的組合**永遠不會出現**，
因為受害者在 attention 取消的那一刻就從 `dm_exec_requests` 消失了。
拿著第一列去等一個不會來的訊號，是這套工具最可能被誤用的方式。

## 兩個使用上的注意事項

1. **`EventInfo` 是那條 session 的「最後一個輸入批次」**，來自 `sys.dm_exec_input_buffer`，
   不保證就是持鎖的那一句。實驗腳本刻意先取 `@@SPID` 再持鎖，否則樣本裡會看到 `SELECT @@SPID;`。
2. **不要用 `session_id > 50` 當作「只取使用者連線」的判斷**。
   實測 SQL Server 2022 on Linux 的內部背景工作（`BRKR TASK`、`TASK MANAGER`、`XE TIMER` 等）
   session_id 落在 51～92，用 50 當門檻會撈進四十幾筆雜訊把證據淹掉。
   正確作法是 join `sys.dm_exec_sessions` 並過濾 `is_user_process = 1`。
