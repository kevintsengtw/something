# 為什麼會這樣：WRITELOG、WSL2 的寫入鏈，與「就緒」的假象

上一篇給了藥方：把 SQL Server 容器的資料與交易記錄目錄掛成 tmpfs，再讓測試資料庫走 `RECOVERY SIMPLE` 加 `DELAYED_DURABILITY = FORCED`。這一篇講為什麼。

不過在講原理之前，先給一個你今天就用得上的東西：怎麼從錯誤訊息本身判斷你遇到的是哪一種逾時。

## 一、兩種 timeout，措辭不一樣

`SqlException` 的逾時有兩種常見來源，英文訊息開頭都是「Timeout expired」，但後半句完全不同。以下原文取自 `Microsoft.Data.SqlClient` 7.0.2 的資源字串，原本各是一行，這裡為版面折行；句號後面是兩個空白，這是原文就有的。

一種是**指令逾時**：

```text
Timeout expired.  The timeout period elapsed prior to completion of the operation
or the server is not responding.
```

關鍵字是 `prior to completion of the operation`。意思是連線已經建立、指令已經送出去了，只是伺服器在你設定的時間內沒有把它跑完。`SqlException.Number` 是 `-2`。

另一種是**連線集區逾時**：

```text
Timeout expired.  The timeout period elapsed prior to obtaining a connection from
the pool.  This may have occurred because all pooled connections were in use and
max pool size was reached.
```

關鍵字是 `prior to obtaining a connection from the pool`。這是連線都還沒拿到，通常代表你有連線沒關、或是同時開太多。

這個差別很實用，因為兩者的排查方向完全相反。前者要往「伺服器為什麼慢」查，後者要往「我的連線是不是漏了」查。我們遇到的是前者，這一句話就先砍掉了一整個方向。

### 中文訊息的分辨點在另一半

如果你的環境是繁體中文，同樣兩句長這樣：

```text
執行逾時到期。在作業完成之前超過逾時等待的時間，或是伺服器未回應。

已超過連接逾時的設定。在取得集區連接之前超過逾時等待的時間，可能的原因為所有的
共用連接已在使用中，並已達共用集區大小的最大值。
```

這裡有個很容易踩的地方：中文版還有第三句，長得跟第一句幾乎一樣。

```text
已超過連接 Timeout 的設定。在作業完成之前超過逾時等待的時間，或者是伺服器未回應。
```

後半句跟指令逾時只差「或是」與「或者是」兩個字，但它是**連線**層級的逾時。

所以規則要反過來記：**英文看後半句，中文看前半句。**「執行逾時到期」才是指令逾時，開頭是「已超過連接…」的都不是。最保險的做法還是看 `SqlException.Number` 是不是 `-2`。

## 二、四個假設，三個被推翻

排查的價值不只在找到答案，也在於怎麼把錯的選項一個一個拿掉。當時桌上有四個假設。

**連線集區耗盡。** 排除，理由就是上一節那句話：措辭對不上。這是最便宜的一次排除，看訊息就夠。

**xUnit 平行測試互相競爭。** 這個要實際確認，而且這裡有個很多人會踩的誤解：xUnit v2 從 2.0 開始，**不同 collection 之間預設是平行執行的**。更麻煩的是，沒有掛 `[Collection]` 屬性的測試類別，每一個都會自成一個「隱含 collection」。也就是說，你以為它們排隊跑，其實它們在搶同一顆資料庫。

三十秒的驗證法：去看測試專案裡的 `xunit.runner.json`。

```json
{
  "$schema": "https://xunit.net/schema/current/xunit.runner.json",
  "parallelizeTestCollections": false,
  "diagnosticMessages": true
}
```

`parallelizeTestCollections` 設成 `false`，才是真的循序。確認過之後，這個假設也排除了。

**洩漏的未提交交易在持鎖。** 這個假設最合理，也最難排除，直到我注意到症狀的第三個特徵：**有時候第一個測試都還沒跑就中了**。錯在初始化那批資料的時候。既然前面一個測試都沒有，就不可能有誰洩漏了交易。這條路自己斷了。

**I/O 與資源壓力。** 剩下這個。它是唯一能同時解釋三個特徵的假設：發生在大量小寫入的時候、隨機出現、而且可以在最一開始就發生。

## 三、寫入鏈與 durability

在 Windows 加 Docker Desktop（WSL2）上，容器裡的一次寫入實際上要穿過這些層：

```text
容器 overlayfs → WSL2 的 ext4 → VHDX 虛擬磁碟檔 → 宿主機 NTFS →（防毒即時掃描）
```

每一層都會加一點延遲。真正麻煩的是最後那一段：它的耗時取決於宿主機當下在忙什麼。你開了 IDE、瀏覽器在背景更新、防毒剛好掃到那個 VHDX——延遲就跳一下。這就是「間歇性」的物理來源，它不是隨機，是跟著別的東西起伏。

SQL Server 這邊則有它非做不可的事。交易 commit 之前，交易記錄必須確實寫到儲存裝置上，這是耐久性（durability）保證的一部分，沒辦法靠作業系統的頁面快取蒙混過去。這個等待在 SQL Server 裡有個名字，叫 `WRITELOG`。

把兩件事疊起來就清楚了：一筆一筆的小 INSERT，是這個組合下最糟的工作負載。每一筆都要老老實實走完那條長鏈一次，而 seed data 往往就是幾百幾千筆小 INSERT。

`DELAYED_DURABILITY = FORCED` 是在 SQL Server 這一側鬆綁：commit 不再等記錄寫完。tmpfs 是在儲存這一側鬆綁：那條鏈只剩一層，而且是 RAM。測試資料本來就不需要耐久性，容器關掉，全部都要丟。

## 四、「就緒」是個假象

還有一個更隱蔽的問題，它解釋了「第一發就中」。

Testcontainers 說容器就緒了，到底檢查了什麼？我去讀了 `Testcontainers.MsSql` 4.13.0 的原始碼。`MsSqlBuilder.Init()` 掛上的等待策略，實際上做兩件事：確認容器處於 running 狀態，然後在容器裡執行

```bash
sqlcmd -C -Q "SELECT 1;"
```

取它的 exit code，是 0 就算就緒。

`SELECT 1` 不碰 DDL、不寫任何記錄、不需要 buffer pool 準備好。它只證明「SQL Server 收得到、也回得了一句最廉價的查詢」。但這時候系統資料庫可能還在展開、buffer pool 還在初始化，你緊接著塞兩千筆資料進去，它扛不住。

這中間的落差，就是第一個測試還沒跑就逾時的原因。

要補強，可以自己指定等待策略。但這裡有個陷阱，我實際踩過也寫了測試釘住它：**`WithWaitStrategy` 是整組取代，不是追加。** 一旦你自訂，模組內建的那個 sqlcmd 檢查就消失了，得自己加回來。

```csharp
.WithWaitStrategy(
    Wait.ForUnixContainer()
        .UntilMessageIsLogged(
            RecoveryCompletePattern,
            strategy => strategy.WithTimeout(TimeSpan.FromMinutes(3)))
        .UntilCommandIsCompleted(
            """
            "$(find /opt/mssql-tools*/bin/sqlcmd -type f -print -quit)" -C -Q "SELECT 1;"
            """,
            strategy => strategy.WithTimeout(TimeSpan.FromMinutes(3))))
```

第一個條件等 SQL Server 印出 recovery 完成的訊息，那是內建策略完全不看的東西。第二個條件把被取代掉的 sqlcmd 檢查加回來。sqlcmd 的路徑在不同映像檔版本會變（`mssql-tools` 或 `mssql-tools18`），所以照抄官方的 `find` 寫法，不要寫死。兩個都加了三分鐘的上限，萬一哪天映像檔換版、訊息措辭改了，它會在三分鐘後失敗收場，而不是卡在預設的一小時。

還可以再往前一步：容器起來之後、建資料庫之前，先做一次「建暫存表、塞五十筆、再刪掉」的暖身。這個工作負載是刻意挑的：它同時踩到 DDL 與交易記錄寫入，也就是 `SELECT 1` 完全沒碰、卻是 seed data 真正會走的那條路。探測成功而且夠快，就當作真的就緒了。

但它是盡力而為，不是通過條件。設定的時限到了就直接放行，不拋例外、不擋人，最差的結局等於沒做暖身。這是最佳化，不該變成測試跑不跑得起來的前提。範例專案裡有這個探測，不過老實說掛了 tmpfs 之後它的必要性已經低很多，留著主要是給不能用 tmpfs 的人當退階方案。

順便講一個寫它時踩到的坑，因為那個教訓比工具本身有用。這種「盡力而為」的迴圈一定要有整體 deadline，到期就放行，這是基本盤。但光有 deadline 不夠：我的版本在 deadline 邊界上會空轉，一次量測跑出三十八次探測，其中三十七次的耗時是 0.0 毫秒。原因是 `CancellationTokenSource.CancelAfter` 和 `Task.Delay` 都會把時間截成整數毫秒，剩下 0.4 毫秒的時候，兩者都變成「立刻返回」。它會結束，不是無窮迴圈，但那三十七次是不折不扣的空轉，而這段程式碼的賣點正是它不空轉。**有出口不等於不會空轉：剩餘時間小到做不了事的時候，就該直接放行。**

## 五、關鍵不是變快，是變穩

tmpfs 當然比較快，但那不是它救了測試的原因。真正的差別在於：原本每次寫入的耗時是一個會隨宿主機負載起伏的函數，換成 RAM 之後，它變成一個接近常數的東西。

這件事為什麼重要？因為逾時是一個門檻判斷。如果每次寫入都穩定花 X 毫秒，只要 X 沒有超過門檻，它永遠不會逾時。但如果平均是 X、偶爾跳到 5X，那你就會得到一個「大部分時候好好的、偶爾紅一次」的測試，也就是最難查、最消耗信任的那一種。

flaky 的根源不是慢，是有時候慢。

下一篇談的是：如果照著做了問題還在，你要怎麼採證？間歇性問題有個特別討厭的地方：它發生的時候你不在場，等你看到錯誤，容器早就被回收了。所以採證得先寫進程式碼裡。
