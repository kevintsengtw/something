# 讓 Testcontainers 的 SQL Server 不再偶爾卡住

如果你用 `Testcontainers.MsSql` 跑整合測試，而且遇過那種「這次紅、重跑就過」的逾時，這篇是給你的。解法在第二節，前面一小段先確認我們講的是同一件事。

## 一、症狀長這樣

錯誤訊息是這一句：

```text
執行逾時到期。在作業完成之前超過逾時等待的時間，或是伺服器未回應。
```

英文環境會看到（原文是一行，這裡為版面折行；句號後面確實是兩個空白）：

```text
Timeout expired.  The timeout period elapsed prior to completion of the operation
or the server is not responding.
```

抓到的是 `SqlException`，`Number` 為 `-2`。

中文訊息這裡有個陷阱要先講。SqlClient 還有另一句長得幾乎一樣的：

```text
已超過連接 Timeout 的設定。在作業完成之前超過逾時等待的時間，或者是伺服器未回應。
```

後半句只差「或是」跟「或者是」兩個字，但它講的是完全不同的事：那是**連線**層級的逾時，代表連都還沒連上。**分辨點在前半句**，「執行逾時到期」是指令逾時，「已超過連接 Timeout 的設定」是連線逾時。如果不確定，就看 `Number` 是不是 `-2`。

光有這句話還不夠，因為逾時的成因很多。真正對得上的是這三個特徵：

第一，錯誤發生在 Arrange 階段塞 seed data 的時候，而且是那種一筆一筆的小 INSERT。第二，它是間歇性的——同一份程式碼，這次失敗、下次全過，失敗的位置還不固定。第三，也是最關鍵的一點：**有時候第一個測試都還沒開始跑就中了**，錯在初始化那批資料。

第三點很重要，因為它直接排除掉一整類猜測。沒有前面的測試，就不會有洩漏的交易在持鎖，也不會有累積的連線把 pool 吃光。問題出在資料庫本身當下寫不動。

如果你的症狀只符合前兩點，這篇的解法可能沒用，你要找的大概是別的東西。

## 二、藥方

兩個地方要改。

第一個地方是建立容器的時候，把 SQL Server 的資料與交易記錄目錄掛成 tmpfs：

```csharp
return new MsSqlBuilder(ImageName)
    .WithTmpfsMount("/var/opt/mssql/data")
    .WithTmpfsMount("/var/opt/mssql/log")
    // 範例專案在這裡還接了記憶體上限與自訂等待策略，見第五節與下一篇
    .Build();
```

tmpfs 是記憶體檔案系統。掛上之後，容器對這兩個目錄的寫入不會落到宿主機的磁碟，只會寫進 RAM。

第二個地方是建立測試資料庫之後，補兩道設定：

```csharp
await connection.ExecuteAsync(
    $"""
     CREATE DATABASE [{DatabaseName}];
     ALTER DATABASE [{DatabaseName}] SET RECOVERY SIMPLE;
     ALTER DATABASE [{DatabaseName}] SET DELAYED_DURABILITY = FORCED;
     """,
    commandTimeout: 120);
```

`RECOVERY SIMPLE` 讓交易記錄檔用完就回收，不會一路長大。`DELAYED_DURABILITY = FORCED` 讓交易 commit 的時候不等記錄檔寫完才回應。

這四行請當成一整帖，不要只抄一半。它們處理的是同一條路徑上不同的環節，我沒有做過拆開來的對照實驗，所以也不會告訴你哪一行貢獻比較多——就整組拿去用。

我把它們放進一個 Collection Fixture，讓整個測試 collection 共用一顆容器。完整的檔案在範例專案的 `tests/Sample.WebApi.IntegrationTests/Fixtures/SqlServerContainerFixture.cs`，裡面還有等待策略跟診斷工具的部分，那些留到後面兩篇再談。上面這幾行是決定性的部分，你的 Fixture 長得跟我不一樣也沒關係，照樣貼得進去。

至於它有沒有效，這套設定在實際使用中已經穩定運作，原本那種隔幾次就紅一回的狀況沒有再出現過。我沒有另外做一組前後對照的量測，理由很簡單：那種數字換一台機器就不一樣，而「裝上去之後就不再發生了」是更接近你真正想知道的答案。

## 三、確認你真的掛對了

這一步不要跳過。tmpfs 掛在錯誤的路徑上不會有任何錯誤訊息，測試照跑、容器照起，只是設定完全沒有生效。你會以為問題還在，然後去找別的原因。

容器跑起來之後，執行：

```bash
docker exec <container> df -h /var/opt/mssql/data /var/opt/mssql/log
```

掛對的話會看到這樣。這是跑完一輪測試（包含兩千筆 seed）之後的實際輸出：

```text
Filesystem      Size  Used Avail Use% Mounted on
tmpfs           512M  150M  363M  30% /var/opt/mssql/data
tmpfs           512M  236K  512M   1% /var/opt/mssql/log
```

**看第一欄就好。** 是 `tmpfs` 就對了；如果顯示 `overlay`，代表沒掛上，你的寫入還是走容器的一般檔案系統。

`Used` 那欄剛啟動時可能還是 0，那只是取樣的時機比 SQL Server 展開系統資料庫還早，不用在意。

`Size` 那個 512M 是我設的，下一節會講為什麼。如果你沒設，這裡會是一個大得嚇人的數字：tmpfs 沒有指定大小時，預設是可用記憶體的一半，我的 WSL2 VM 有 31 GB，所以原本顯示的是 16G。

## 四、要付多少記憶體

以下是我在自己機器上量的數字。這不是統計，只是給你一個量級的參考，你的機器會不一樣。

剛就緒、還沒開始大量寫入的時候，`docker stats` 顯示 297.8 MiB。跑完整套測試（含兩千筆 seed）之後，我連跑三次拿到 0.94、0.94、1.35 GiB——同一份程式碼、同一台機器，尾端就是會晃。順帶一提，設了容器上限之後 `docker stats` 的分母會直接顯示 `/ 4GiB`，這也是確認上限有沒有套上的最快方法。

這一整包裡面，tmpfs 佔的是前面看到的 150 MB 左右。tmpfs 的頁面會算進容器的 memory cgroup，所以它跟 SQL Server 自己的 buffer pool 是共用同一個數字的。換句話說，把資料庫搬進記憶體的額外代價大概是百 MB 量級，剩下的九百多 MB 本來就是 SQL Server 要吃的。

那 150 MB 幾乎全在 data 這一側，log 只用了 236K。`RECOVERY SIMPLE` 讓交易記錄持續回收，所以它根本長不大。

如果你的機器記憶體很緊，最簡單的退路是只掛 log 不掛 data。寫入鏈上最要命的是交易記錄的同步落盤，先處理那一段通常就有感，而且從前面的數字看得出來，log 那一側幾乎不佔空間。

不過在那之前，先把上限設好，這比退路重要。

## 五、兩個記憶體上限，很多人只設一個

「SQL Server 容器要給 4GB」這個說法很常見。但 4GB 講的是哪一層？這裡有兩個旋鈕，管的是不同的東西，混在一起就會踩到雷。

**第一層是容器總量**，也就是 `docker run --memory` 那個 cgroup 上限。它要裝的不只是 SQL Server 的 buffer pool，還有執行緒堆疊、query workspace，**以及 tmpfs 的檔案內容**。最後這項是這篇的重點：tmpfs 的頁面算在容器的 memory cgroup 額度裡，你把資料庫搬進記憶體，那些資料就是從容器的額度扣的。4GB 這個慣例講的是這一層。

**第二層是 SQL Server 行程自己**，環境變數 `MSSQL_MEMORY_LIMIT_MB`。注意是**三個底線**，`MEMORY_LIMIT_MB`；`mssql.conf` 裡的同名設定才是無底線的 `memorylimitmb`，兩者很容易混。不設的話，SQL Server 會吃掉它「看得到」的實體記憶體的八成，而它看到的往往是整個 WSL2 VM，不是容器額度。

為什麼兩層都要設？只設第二層，容器沒有上限，4GB 是被動滿足的，SQL Server 仍可能排擠同一台機器上的其他容器。只設第一層，SQL Server 照著「看到的」記憶體去擴張，撞到 cgroup 上限就被 OOM kill，而那又是一次沒有錯誤訊息的間歇性死亡。官方的建議也是這樣：memorylimitmb 要低於主機記憶體與 cgroup 上限。

範例專案兩層都設了：

```csharp
.WithEnvironment(
    "MSSQL_MEMORY_LIMIT_MB",
    SqlServerLimitMb.ToString(CultureInfo.InvariantCulture))   // 2560
.WithCreateParameterModifier(parameters =>
{
    var hostConfig = parameters.HostConfig ??= new HostConfig();
    hostConfig.Memory = ContainerLimitBytes;                   // 4 GB
})
```

預算是這樣分的：容器 4 GB ＝ SQL Server 本體 2.5 GB ＋ tmpfs 上限兩個各 512 MB ＋ 剩下給作業系統和緩衝。兩個數字之間刻意留了缺口，tmpfs 漲起來或 SQL Server 短暫超用都不會撞牆。

### 不要把 SQL Server 那個上限壓到 2048

我原本設 2048，想說整合測試的資料量才幾百 MB，2 GB 的 buffer pool 綽綽有餘。結果連 `CREATE DATABASE` 都跑不完：

```text
There is insufficient system memory in resource pool 'default' to run this query.
```

2 GB 是 SQL Server on Linux 對**整台機器**的最低需求，不是這個設定的安全值。`MSSQL_MEMORY_LIMIT_MB` 涵蓋的是 buffer pool、SQLPAL、query workspace 這些全部加起來的額度，壓到 2048 之後 default resource pool 分不到足夠的量，連建一個空資料庫都做不到。2560 可以，我沒有再往下試更精確的邊界。

### tmpfs 的大小上限得從別的地方設

`WithTmpfsMount` 只吃掛載路徑跟 access mode，沒有指定大小的多載，所以 size 要從 `WithCreateParameterModifier` 補。這裡有個會讓人白做工的地方：Testcontainers 把 tmpfs 放進 `HostConfig.Mounts`（`Type` 是 `tmpfs`），不是旁邊那個 `HostConfig.Tmpfs` 字典。後者從頭到尾都是 `null`。

我第一次就是寫去改 `HostConfig.Tmpfs`，沒有任何錯誤，`docker inspect` 出來 `Tmpfs` 也還是 `null`，看起來就像「設了但 Docker 不理我」。實際上是我對著一個空欄位做事。正確的做法是走 `Mounts`：

```csharp
foreach (var mount in hostConfig.Mounts)
{
    if ("tmpfs".Equals(mount.Type, StringComparison.OrdinalIgnoreCase))
    {
        mount.TmpfsOptions = new TmpfsOptions { SizeBytes = TmpfsSizeLimitBytes };
    }
}
```

上面兩段的 `SqlServerLimitMb`、`ContainerLimitBytes`、`TmpfsSizeLimitBytes` 是常數，值分別是 2560、4 GB、512 MB，完整檔案在範例專案的 `tests/Sample.WebApi.IntegrationTests/Fixtures/ContainerMemoryBudget.cs`。

設對了之後，容器裡 `df -h` 的 `Size` 就會從預設的 16G 變成 512M，也就是第三節看到的那個輸出。

## 六、為什麼這樣有效

三句話講完，細節留給下一篇。

在 Windows 加 Docker Desktop（WSL2）的環境下，容器裡的一次寫入要穿過好幾層才會真的落地：容器的 overlayfs、WSL2 的 ext4、VHDX 虛擬磁碟、最後才是宿主機的 NTFS，而且路上可能還有防毒軟體的即時掃描。這條鏈的末端延遲會隨著宿主機當下在忙什麼而浮動。這就是「間歇性」的物理來源。

SQL Server 這一側則有它的堅持：交易 commit 之前，記錄檔必須確實寫到儲存裝置上，這是耐久性保證，沒辦法靠作業系統的快取蒙混過去。所以大量的小 INSERT 是最糟糕的組合，每一筆都要等那條長鏈走完一次。

把目錄換成 tmpfs 之後，那條鏈只剩一層，而且是記憶體。真正關鍵的不是「變快了」，而是**延遲的變異消失了**。它從一個會隨宿主機負載起伏的函數，變成一個接近常數的東西。測試會 flaky，根源往往不是慢，是有時候慢。

下一篇會拆開這件事：兩種 timeout 錯誤訊息怎麼分辨、寫入鏈的完整樣貌，以及一個更隱蔽的問題——Testcontainers 說容器「就緒」了，其實只證明了它能回答一句 `SELECT 1`。
