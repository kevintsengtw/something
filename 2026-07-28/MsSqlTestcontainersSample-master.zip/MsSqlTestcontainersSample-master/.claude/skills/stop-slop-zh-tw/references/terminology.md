# 台灣用語校正（taiwan-md 層）

把中國用語換成台灣慣用語。這是詞彙層級的對應，正簡轉換做不到——「視頻」轉成正體仍是「視頻」。

完整詞庫在 [data/terms.json](../data/terms.json)（上百條，**不進 context**），由掃描器讀取。本檔只留三樣東西：怎麼跑掃描、同形詞判斷、無法執行時的最高頻保底表。

## 自動掃描（環境可執行 shell 時優先用）

詞庫不必整包進 context。對檔案或草稿跑掃描器，它只回報**實際命中**的詞：

```bash
node scripts/zh-tw-terms.mjs <檔案>         # 報告命中
node scripts/zh-tw-terms.mjs --json <檔案>  # 機器可讀，給 Agent 解析
node scripts/zh-tw-terms.mjs --dry-run <檔案> # 預覽 auto 校正，不寫入
node scripts/zh-tw-terms.mjs --fix <檔案>   # 自動套用 auto，flag 留待判斷
echo "一段文字" | node scripts/zh-tw-terms.mjs -   # 從 stdin 讀
```

- **auto**：安全直換（視頻→影片），`--fix` 會自動套用。
- **flag**：同形詞或台灣也通用的詞，只標記、不自動換，由你依語境判斷。

掃描器會保護 Markdown 程式碼、行內程式碼、URL、連結目標、HTML 標籤、Email 與常見路徑。`--json` 另提供每次命中的規則 ID、行號、欄位和原文片段；`--fix` 使用安全寫回，執行前先用 `--dry-run` 檢查差異。

詞條可用 `match` 控制比對方式：

| match | 用途 |
| ---- | ---- |
| substring | 預設；一般兩字以上中文詞 |
| phrase | 明確列入詞庫的完整技術詞組 |
| word | 英數詞；前後不能連著英數字或底線 |
| regex | 少數需要上下文的規則，必須提供 `pattern` |

不要收錄「庫、類、宏、棧、堆」這類單一中文字做全域掃描。改收「第三方庫、類方法、宏定義、調用棧」等能判斷語境的完整詞組。修改詞庫後執行：

```bash
node scripts/validate-terms.mjs data/terms.json
node --test tests/zh-tw-terms.test.mjs
```

無法執行 shell（Claude Projects／API）時，改用下方「最高頻保底表」＋你的既有知識。

## 同形詞與判斷題（換之前先看語境）

這些詞兩岸同形或台灣也通用，掃描器一律標 `flag`、不自動換：

| 詞 | 怎麼判斷 |
| ---- | -------- |
| 文件 | file→檔案；document 才是（台灣的）「文件」。別把 file 誤校成「文件」 |
| 文檔 | document→文件、說明文件 |
| 程序 | program→程式；procedure／法律「程序」（程序正義）勿改 |
| 對象 | object→物件；target／「測試對象」看語境 |
| 質量 | quality→品質；物理「質量」(mass) 勿改 |
| 支持 | support→支援；情感「支持」勿改 |
| 比特 | bit→位元；「比特幣」(Bitcoin) 勿改 |
| 宏 | macro→巨集；「宏觀／宏大」勿改 |
| 事務 | transaction→交易；「事務所」等勿改 |
| 鏡像 | image→映像檔；一般「鏡像」勿改 |
| 刷新 | refresh→重新整理；「刷新紀錄」勿改 |
| 推理 | inference→推論；reasoning「推理」勿改 |
| 框架 / 部署 / 分支 / 序列化 | 兩岸相同，不要改 |

## 最高頻保底表（無法執行掃描器時用）

技術寫作最常見、最該優先校正的子集：

| 中國用語 | 台灣用語 |
|----------|----------|
| 代碼 | 程式碼 |
| 軟件 | 軟體 |
| 硬件 | 硬體 |
| 數據 | 資料 |
| 數據庫 | 資料庫 |
| 信息 | 資訊 |
| 內存 | 記憶體 |
| 緩存 | 快取 |
| 默認 | 預設 |
| 性能 | 效能 |
| 兼容 | 相容 |
| 接口 | 介面 |
| 函數 | 函式 |
| 變量 | 變數 |
| 對象 | 物件 |
| 服務器 | 伺服器 |
| 視頻 | 影片 |
| 屏幕 | 螢幕 |
| 鼠標 | 滑鼠 |
| 網絡 | 網路 |
| 智能 | 智慧 |
| 算法 | 演算法 |
| 調試 | 偵錯 |
| 注釋 | 註解 |
| 設置 | 設定 |
| 在線 | 線上 |
| 編程 | 寫程式、程式設計 |
| 程序員 | 程式設計師 |
| 計算機 | 電腦 |
| 芯片 | 晶片 |

完整版（含 AI、CS 概念、日常操作、網路流行語等上百條）見 [data/terms.json](../data/terms.json)。

## 使用原則

- **技術名詞優先保留英文。** Agent、MCP、Extension、Hook、Skill、Endpoint、Token、Commit、PR、Repo、Deploy 等不必硬翻。
- **同形詞不要過度校正。** 見上方判斷題表；掃描器已用 `flag` 標出，別把台灣本就通用的詞當支語。
- **語感層面也要看。** 用語對了，但句法是大陸書面腔（「對…進行賦能」），仍需依 phrases.md／structures.md 處理。
- **詞庫擴充。** terms.json 可從授權相容的來源（CC0／Apache／CC BY-SA）擴充，見 README「用語對照的範圍與延伸資源」。只併授權相容者。
- **保留來源。** 正式詞條必須有 `source`，其定義見 `data/term-sources.json`；容易誤判的詞另以 `note` 記錄適用邊界。早期組合詞庫使用 `legacy-curated-composite`，不要假裝能回推更精確的逐筆上游。
