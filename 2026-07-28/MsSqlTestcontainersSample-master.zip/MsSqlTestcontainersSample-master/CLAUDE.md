# CLAUDE.md

.NET 10 + Testcontainers.MsSql 整合測試範例專案。設計說明與背景見 [README.md](README.md)，
這份檔案只寫「動手前必須知道」的規則。

## 常用指令

```powershell
dotnet build
dotnet test                                    # 實驗性測試不會跑

# 實驗性測試（刻意製造逾時／鎖等待，會另外啟動容器）
$env:SAMPLE_TESTS_RUN_EXPERIMENTS = 'true'
dotnet test --filter "Category=Experiment"

# 重新產生 docs/diagnostics-sample-output/ 的採證範例
$env:SAMPLE_TESTS_DIAGNOSTICS_OUTPUT = "$PWD\docs\diagnostics-sample-output"
dotnet test --filter "Category=Experiment"

# 連續 N 輪執行，收集 TRX 與失敗明細（間歇性問題的驗收方式）
./scripts/run-test-rounds.ps1 -Rounds 10
```

需要 Docker Desktop（WSL2 後端）。首次執行會拉 `mcr.microsoft.com/mssql/server:2022-latest`。

## 測試專案的規則

- **測試依「測什麼」分三個資料夾放**，不要混在一起：
  `Tests/` 測目標專案 `Sample.WebApi`、`InfrastructureTests/` 測測試基礎設施自己（不碰資料庫）、
  `Experiments/` 測第三方行為（Testcontainers、SQL Server）且預設 skip。namespace 跟著資料夾走。
- **新增測試類別一律繼承 `IntegrationTestBase`**。它已經掛好 `[Collection]`；沒掛的類別會各自
  成為隱含 collection 而平行執行，搶同一顆資料庫。（`InfrastructureTests/` 與 `Experiments/`
  不共用那顆容器，所以不繼承，改用自己的 fixture 或完全不用。）
- **所有 seed 走 `SeedDataHelper`**，不要自己開連線寫 INSERT。逾時自動採證與
  `ex.Data["DiagnosticsLogPath"]` 都在那裡。
- **實驗性測試用 `[ExperimentFact]`**，不要用 `[Fact]` 加 Trait 了事。csproj 的
  `VSTestTestCaseFilter` 擋不住 IDE 的 Test Explorer，`[ExperimentFact]` 才是不論入口都有效的閘門。
- **不要改用 `.runsettings` 的 `TestCaseFilter`**。它與命令列 filter 以 AND 結合，會讓
  `--filter "Category=Experiment"` 一個測試都選不到（已實測）。
- 套件版本集中在 `Directory.Packages.props`（CPM），`PackageReference` 不寫版本號。

## 動 Fixture 之前

`SqlServerContainerFixture` 有幾處是踩過坑才長成現在這樣的，改之前先讀該檔案的 XML 註解：

- tmpfs 兩行掛載 + `RECOVERY SIMPLE` + `DELAYED_DURABILITY = FORCED` 是一整帖，不要只留一半。
- `MSSQL_MEMORY_LIMIT_MB` **不要調到 2048**，實測會讓 `CREATE DATABASE` 失敗
  （`insufficient system memory in resource pool 'default'`）。現值 2560，見 `ContainerMemoryBudget`。
- tmpfs 的大小上限要設在 `HostConfig.Mounts` 的 `TmpfsOptions`，**不是** `HostConfig.Tmpfs`
  （後者恆為 null，寫了不會出現錯誤也不會生效）。
- `WithWaitStrategy` 是**整組取代**不是追加，自訂就必須把內建的 sqlcmd 檢查加回來。
- `DatabaseWarmupProbe` 是 best-effort：deadline 到期一律放行、不拋例外。不要把它改成通過條件。

## 文件與文章

### 用語

- **正體中文（台灣）**，不寫「繁體中文」。
- 一律台灣用語：程式碼、物件、資料、介面、最佳化、字串、函式、預設值。
  完整對照見 [.claude/skills/stop-slop-zh-tw/references/terminology.md](.claude/skills/stop-slop-zh-tw/references/terminology.md)。
- 技術名詞保留英文原文（tmpfs、buffer pool、command timeout、DMV），不要硬翻。

掃描中國用語與排版：

```bash
node .claude/skills/stop-slop-zh-tw/scripts/zh-tw-terms.mjs --json <file>
node .claude/skills/stop-slop-zh-tw/scripts/zh-tw-terms.mjs --fix  <file>
node .claude/skills/stop-slop-zh-tw/scripts/zh-tw-typography.mjs --json <file>
```

`--fix` 只處理 `auto` 類的安全替換；`flag` 類要依語境自己判斷（例如「文件」可能是 file 也可能是
document）。**不要無條件跑 `--fix`**，先看 `--json` 再逐項決定。這兩個掃描器做的是字串比對而非斷詞，
在本專案有已知誤判：

- **「寫進程式碼」會被改成「寫行程式碼」。** 詞庫有一條 `進程 → 行程`（process），而「寫進 /
  程式碼」的交界剛好湊出「進程」兩個字。這類誤判最危險，因為它產出的是不存在的字串，不是用錯的
  術語。`docs/articles/` 有兩處命中。
- 「組件」被歸為 `auto` 類、會被改成「元件」。中國用語的「组件」確實是 component，但 .NET 的
  **assembly 在台灣正體中文就是「組件」**（Microsoft 官方術語），這裡不能替換。
- 「函數」被歸為 `auto` 類、會被改成「函式」。程式的 function 確實是函式，但數學意義的函數
  （例如「隨負載起伏的函數」）在台灣就是函數，不要一律替換。
- 排版掃描器把沒包在反引號裡的產品名句點當成半形標點（`Testcontainers.MsSql`），
  也會誤判 Markdown 連結路徑（`[.claude/...]`）與連結結尾後的全形句號。
  把技術名詞包進 `` ` `` 可以避開前者，後兩者直接忽略。

### 潤稿流程（stop-slop + humanizer 四步）

整段改寫或潤飾既有草稿時依序跑這四步，每步只動上一步的輸出，並標出做了什麼：

1. **清理 + 在地化**（`stop-slop-zh-tw`）：先砍結構性贅詞與公式化句式，再修歐化句法與翻譯腔，
   最後把中國用語校正成台灣慣用語。技術名詞保留英文。這步只清理，不加內容。
2. **補掃**（`humanizer-zh-tw`）：補抓 stop-slop 沒處理到的模式——諂媚語氣、知識截止免責聲明、
   過度限定、通用積極結論、填充詞、粗體與表情符號濫用。跳過英文專屬項目（彎引號、首字母大寫、
   繫詞迴避）。這步只指出並修掉，不加人味。
3. **注入人味**（`humanizer-zh-tw`）：加入明確觀點、適當用第一人稱、長短句交錯、保留一點不完美、
   把抽象說法換成具體細節。原意與台灣用語不變。
4. **回掃 + 評分**（`stop-slop-zh-tw`）：用語回掃，確認第 3 步沒有又帶進中國用語或翻譯腔；
   再用 6 維評分（直接／節奏／信任／真實／密度／台灣味）給分。低於 42/60 就指出哪幾維不足、
   要改哪裡，退回重改後重新評分。

短文可把四步併成一輪；正式文章走分段四步，每步可檢視、可回退。
`stop-slop-zh-tw` 是台灣用語與評分的把關者，`humanizer-zh-tw` 是補洞與加人味的工具。
**`humanizer-zh-tw` 的範例多為中國寫法，第 4 步的 stop-slop 收尾不能省**，否則會把中國用語帶回稿子。

### `docs/articles/` 的查核標準

三篇文章的所有技術宣稱都必須對得上實作或留存的證據：

- 程式碼片段要與 `tests/` 下的實際檔案逐字相符，不要憑印象改寫。
- 引用採證輸出時以 `docs/diagnostics-sample-output/` 的 `.log` 檔為準，不要引用該目錄
  `README.md` 裡的 JSON（曾經發生 README 引的是上一輪跑的數字而與 log 對不上）。
- 引用套件的錯誤訊息原文要對組件資源字串驗證，不要憑記憶寫。
  `Microsoft.Data.SqlClient` 的訊息句號後面是**兩個空白**。
- log 片段為版面省略欄位時要註明，因為文章宣稱這些輸出「未經改寫」。
