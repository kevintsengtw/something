<#
.SYNOPSIS
    連續執行測試套件 N 輪，收集每輪耗時與失敗明細。

.DESCRIPTION
    間歇性問題的驗收沒辦法靠「跑一次綠燈」交差，必須看連續多輪的結果。
    每輪都輸出 TRX，失敗當下的測試名稱與訊息會留在檔案裡——
    這和 SqlDiagnosticsDumper 是同一個思路：採證要自動化，
    因為你不會剛好在失敗的那一刻盯著螢幕。

.PARAMETER Rounds
    要跑幾輪，預設 10。

.PARAMETER ResultsDirectory
    TRX 與摘要的輸出目錄，預設 ./TestResults/rounds。

.PARAMETER Tmpfs
    是否啟用 tmpfs（設定 SAMPLE_TESTS_TMPFS 環境變數）。預設不覆寫，沿用程式預設值。

.EXAMPLE
    ./scripts/run-test-rounds.ps1 -Rounds 10
#>
[CmdletBinding()]
param(
    [int]$Rounds = 10,
    [string]$ResultsDirectory = 'TestResults/rounds',
    [ValidateSet('true', 'false')][string]$Tmpfs
)

$ErrorActionPreference = 'Stop'
$repositoryRoot = Split-Path -Parent $PSScriptRoot
Set-Location $repositoryRoot

if ($PSBoundParameters.ContainsKey('Tmpfs')) { $env:SAMPLE_TESTS_TMPFS = $Tmpfs }

$resultsPath = Join-Path $repositoryRoot $ResultsDirectory
New-Item -ItemType Directory -Force -Path $resultsPath | Out-Null

Write-Host "建置中..." -ForegroundColor Cyan
dotnet build MsSqlTestcontainersSample.slnx -v quiet | Out-Null
if ($LASTEXITCODE -ne 0) { throw '建置失敗' }

$summary = [System.Collections.Generic.List[object]]::new()

for ($round = 1; $round -le $Rounds; $round++) {
    $trxName = "round-$('{0:D2}' -f $round).trx"
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

    dotnet test MsSqlTestcontainersSample.slnx --no-build `
        --logger "trx;LogFileName=$trxName" `
        --results-directory $resultsPath | Out-Null

    $stopwatch.Stop()

    $trxPath = Join-Path $resultsPath $trxName
    $passed = 0
    $failed = 0
    $failureDetails = @()

    if (Test-Path $trxPath) {
        $trx = [xml](Get-Content $trxPath)
        $results = @($trx.TestRun.Results.UnitTestResult)
        $passed = @($results | Where-Object { $_.outcome -eq 'Passed' }).Count
        $failedResults = @($results | Where-Object { $_.outcome -ne 'Passed' })
        $failed = $failedResults.Count
        $failureDetails = $failedResults | ForEach-Object {
            [PSCustomObject]@{
                TestName = $_.testName
                Message  = $_.Output.ErrorInfo.Message
                Stack    = $_.Output.ErrorInfo.StackTrace
            }
        }
    }

    $summary.Add([PSCustomObject]@{
        Round    = $round
        Seconds  = [math]::Round($stopwatch.Elapsed.TotalSeconds, 1)
        Passed   = $passed
        Failed   = $failed
        Failures = $failureDetails
    })

    $colour = if ($failed -eq 0) { 'Green' } else { 'Red' }
    Write-Host ("Round {0,2}: {1,3} passed / {2,3} failed  ({3}s)" -f $round, $passed, $failed, [math]::Round($stopwatch.Elapsed.TotalSeconds, 1)) -ForegroundColor $colour

    foreach ($failure in $failureDetails) {
        Write-Host "    ✗ $($failure.TestName)" -ForegroundColor Red
        Write-Host "      $($failure.Message)" -ForegroundColor DarkYellow
    }
}

$totalFailed = ($summary | Measure-Object -Property Failed -Sum).Sum
$durations = $summary | Select-Object -ExpandProperty Seconds

Write-Host ''
Write-Host '=== 摘要 ===' -ForegroundColor Cyan
Write-Host ("輪數        : {0}" -f $Rounds)
Write-Host ("失敗總數    : {0}" -f $totalFailed)
Write-Host ("耗時 最短/中位/最長 : {0}s / {1}s / {2}s" -f `
    ($durations | Measure-Object -Minimum).Minimum,
    ($durations | Sort-Object)[[int]($durations.Count / 2)],
    ($durations | Measure-Object -Maximum).Maximum)
Write-Host ("TRX 輸出    : {0}" -f $resultsPath)

$summaryPath = Join-Path $resultsPath 'summary.json'
$summary | ConvertTo-Json -Depth 5 | Set-Content -Path $summaryPath -Encoding utf8
Write-Host ("摘要 JSON   : {0}" -f $summaryPath)

exit ($totalFailed -eq 0 ? 0 : 1)
