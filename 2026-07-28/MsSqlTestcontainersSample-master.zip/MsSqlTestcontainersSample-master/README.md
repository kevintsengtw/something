# MsSqlTestcontainersSample

.NET 10 + Testcontainers.MsSql 整合測試範例專案。

示範以 **WebApplicationFactory + Testcontainers + Collection Fixture** 建立
可共享容器、彼此隔離、且對「間歇性逾時」具備診斷能力的整合測試架構。

## 環境需求

- .NET 10 SDK
- Docker Desktop（或任何 Docker 環境）
- 首次執行會拉取 `mcr.microsoft.com/mssql/server:2022-latest` 映像檔

## 快速開始

```bash
dotnet test
```

## 專案結構

```text
├── src/Sample.WebApi                          ASP.NET Core WebAPI（Dapper + Microsoft.Data.SqlClient）
│   ├── Controllers                            Shippers CRUD、Orders 分頁查詢
│   ├── Models                                 Shipper / Order
│   ├── Repositories                           Dapper Repository（含交易批次寫入）
│   └── Infrastructure                         IDbConnectionFactory
├── tests/Sample.WebApi.IntegrationTests
│   ├── Fixtures
│   │   ├── SqlServerContainerFixture.cs       ★ 核心：容器生命週期 + tmpfs + 三層等待 + Respawn
│   │   ├── ContainerMemoryBudget.cs           ★ 兩層記憶體上限（容器 cgroup + SQL Server 行程）
│   │   ├── DatabaseWarmupProbe.cs             ★ best-effort 暖身探測（readiness gap 的第三層）
│   │   ├── SeedDataHelper.cs                  ★ 帶診斷能力的 seed（逾時自動採證）
│   │   ├── DiagnosticsExperimentFixture.cs    診斷實驗專用容器（不與一般測試共用）
│   │   ├── IntegrationTestBase.cs             每個測試前 Respawn 重設資料庫
│   │   ├── IntegrationTestCollection.cs       Collection 定義（共享容器、循序執行）
│   │   └── SampleWebApplicationFactory.cs     連線字串替換
│   ├── Diagnostics
│   │   ├── SqlDiagnosticsDumper.cs            ★ 行車紀錄器：DMV 快照工具
│   │   └── SqlDiagnosticsSnapshot.cs          快照的 record 定義
│   ├── Testing
│   │   └── ExperimentFactAttribute.cs         實驗性測試的開關（未設環境變數即 skip）
│   ├── Tests                                  ← 目標專案 Sample.WebApi 的整合測試
│   │   ├── ShippersApiTests.cs                HTTP 層 CRUD
│   │   ├── OrdersBulkSeedTests.cs             2000 筆大量 seed + 分頁
│   │   └── OrderRepositoryTransactionTests.cs 交易 commit / rollback
│   ├── InfrastructureTests                    ← 測試基礎設施自身的測試（不碰資料庫）
│   │   └── DatabaseWarmupProbeTests.cs        暖身控制流程
│   └── Experiments                            ← 第三方行為的實測（預設 skip）
│       ├── SqlDiagnosticsDumperExperimentTests.cs   診斷工具實證，並產出 docs 的採證範例
│       └── WaitStrategyReplacementExperimentTests.cs 等待策略取代行為
├── docs/diagnostics-sample-output              四份實際採證輸出 + 判讀對照表
├── scripts/run-test-rounds.ps1                 連續 N 輪執行並收集失敗明細
└── database/001_CreateTables.sql               資料庫結構（Shippers / Orders）
```

## 三個核心設計（★）

### 1. SqlServerContainerFixture —— 穩定性的關鍵設定

```csharp
new MsSqlBuilder("mcr.microsoft.com/mssql/server:2022-latest")
    .WithTmpfsMount("/var/opt/mssql/data")
    .WithTmpfsMount("/var/opt/mssql/log")
    .WithMemoryBudget()   // 見 ContainerMemoryBudget：容器 4 GB + SQL Server 2560 MB
    .Build();
```

data 與 log 掛載 tmpfs（RAM 檔案系統），消滅 `WRITELOG` 等待與
Docker Desktop / WSL2 的多層 I/O 變異——這是解決「間歇性指令逾時」的治本手段。
建庫後再加上 `RECOVERY SIMPLE` 與 `DELAYED_DURABILITY = FORCED`，
測試資料庫不需要為用不到的耐久性付出 I/O 成本。

驗證 tmpfs 是否生效：

```bash
docker exec <container> df -h /var/opt/mssql/data
# Filesystem 顯示 tmpfs 即生效；Size 顯示 512M 代表 tmpfs 的大小上限也套上了
```

記憶體要設**兩層**，很多人只設一層：容器總量（cgroup，`HostConfig.Memory` = 4 GB）
與 SQL Server 行程本身（`MSSQL_MEMORY_LIMIT_MB` = 2560，注意是三個底線）。
tmpfs 的頁面算進容器的 cgroup 額度，所以兩者要一起編預算。
細節與兩個實測踩到的坑（2048 太低會讓 `CREATE DATABASE` 失敗、
tmpfs 的 size 要設在 `HostConfig.Mounts` 而非 `HostConfig.Tmpfs`）見
[`ContainerMemoryBudget.cs`](tests/Sample.WebApi.IntegrationTests/Fixtures/ContainerMemoryBudget.cs)。

### 2. Respawn 重設而非重建

測試之間以 Respawn 清空資料並重設 IDENTITY（`IntegrationTestBase.InitializeAsync`），
容器與資料庫結構全程共用——隔離性與速度兼得。

### 3. SqlDiagnosticsDumper —— 間歇性問題的行車紀錄器

間歇性逾時的困境：無法隨叫隨到重現、看到錯誤時容器已被回收。
對策是把採證寫進程式碼自動執行：

- **即時快照**：`SeedDataHelper` 攔截 `SqlException.Number == -2`（逾時）當下採證，
  並把 log 路徑掛回 `ex.Data["DiagnosticsLogPath"]`
- **終場快照**：`Fixture.DisposeAsync` 關容器前無條件採一次
- 每次採證分三段：`sys.dm_exec_requests`（誰在等）、`sys.dm_tran_locks`（誰握著鎖）、
  `sys.dm_exec_sessions`（誰帶著未提交交易在睡覺）
- log 落在宿主機 `%TEMP%\sql-diagnostics-*.log`，容器關閉不影響
- 採證連線使用獨立 `Application Name`（獨立 connection pool），
  主測試的 pool 出任何狀況都不影響採證

**這個工具的盲點（實測確認，不要對它有錯誤期待）**：
command timeout 是**用戶端主動取消查詢**，在伺服器端觸發 Attention event（error 3617）。
等 `catch` 跑起來、採證連線接上去查 DMV 時，受害者的請求已經從
`sys.dm_exec_requests` 消失了——該檢視只列出「當下正在執行」的請求。
實測逾時當下的 Requests 是 **0 筆**。

行車紀錄器錄得到肇事者，錄不到受害者的最後一刻。
可用的證據在擋人那一側：`dm_tran_locks` 的 `X` / `IX` 鎖，
與 `dm_exec_sessions` 的 `sleeping` + `open_transaction_count > 0`。
實際 log 範例與判讀對照表見 [docs/diagnostics-sample-output/](docs/diagnostics-sample-output/)。

## 測試場景

| 測試類別 | 場景 | 驗證重點 |
| --- | --- | --- |
| `ShippersApiTests` | HTTP 層 CRUD | WebApplicationFactory 完整管線、404/409 等狀態碼 |
| `OrdersBulkSeedTests` | 2000 筆大量 seed + 分頁 | tmpfs 保護的典型工作負載、Respawn 隔離效果 |
| `OrderRepositoryTransactionTests` | 交易 commit / rollback | FK 違規時的原子性——mock 給不了的真實答案 |

## 等待策略：三層處理 readiness gap

Testcontainers 的 wait strategy 通過 ≠ 資料庫扛得住 DDL 與大量寫入。
`SqlServerContainerFixture` 分三層處理這段落差。

| 層 | 實作 | 回答的問題 |
| --- | --- | --- |
| 1 | Testcontainers.MsSql 內建預設策略 | SQL Server 有沒有在動？ |
| 2 | 自訂 wait strategy（recovery 訊息 + sqlcmd） | 復原跑完了沒？ |
| 3 | `DatabaseWarmupProbe` best-effort 暖身 | 它現在扛不扛得住寫入？ |

**第一層（以 Testcontainers.MsSql 4.13.0 原始碼為準）**：`MsSqlBuilder.Init()` 設定
`Wait.ForUnixContainer().AddCustomWaitStrategy(new WaitUntil())`，實際只檢查兩件事——
容器處於 running（`UntilContainerIsRunning`，OneShot 模式），
以及 `sqlcmd -C -Q "SELECT 1;"` 的 ExitCode 為 0。
輪詢預設 1 秒一次、不限次數、總 timeout 一小時。
`SELECT 1` 不碰 DDL、不寫 log，這就是「第一個測試都還沒跑就逾時」的來源。

**第二層有個陷阱**：`WithWaitStrategy` 是**整組取代**，不是追加——
`ContainerConfiguration` 對 `WaitStrategies` 呼叫的是
`BuildConfiguration.Combine<IEnumerable<WaitStrategy>>(old, new)`，
明確指定泛型參數會選到「純量」多載（新值非 null 就取代舊值）。
一旦自訂，內建的 sqlcmd 檢查就沒了，必須自己加回來。
此行為由 `WaitStrategyReplacementExperimentTests` 實測驗證。

**第三層的鐵則**（記取初版死循環的教訓）：整體只有一個 deadline，
迴圈只有「成功且夠快 → 就緒」與「deadline 到期 → 放行」兩個出口，
到期一律放行、不拋例外，最差結局等於沒做暖身。
以 `new WarmupOptions { Enabled = false }` 關閉，不透過環境變數。

還有第二個教訓，是被測試抓出來的：**「有出口」不等於「不會空轉」**。
`CancellationTokenSource.CancelAfter(TimeSpan)` 與 `Task.Delay(TimeSpan)` 都會把時間
截斷成整數毫秒，所以剩餘預算不到 1 毫秒時，兩者都退化成 no-op，
迴圈就在 deadline 邊界上忙碌輪詢——實測在 thread pool 被佔滿時跑出 38 次探測，
其中 37 次耗時 0.0 毫秒。修法是 `MinimumUsefulBudget`：
剩餘時間小到做不了事，就直接當作 deadline 到期。

## 測試分類與執行

```powershell
# 一般執行（實驗性測試不會跑）
dotnet test

# 跑實驗性測試（刻意製造逾時／鎖等待，會另外啟動容器）
$env:SAMPLE_TESTS_RUN_EXPERIMENTS = 'true'
dotnet test --filter "Category=Experiment"

# 連續 10 輪，收集 TRX 與失敗明細（間歇性問題的驗收方式）
./scripts/run-test-rounds.ps1 -Rounds 10
```

`docs/diagnostics-sample-output/` 的四份採證 log 就是 `Experiments/` 那組測試產出的，
要重新產生就多設一個環境變數指向輸出目錄：

```powershell
$env:SAMPLE_TESTS_RUN_EXPERIMENTS = 'true'
$env:SAMPLE_TESTS_DIAGNOSTICS_OUTPUT = "$PWD\docs\diagnostics-sample-output"
dotnet test --filter "Category=Experiment"
```

實驗性測試有**兩道**閘門，因為單靠任何一道都有破口：

| 機制 | 作用 | 破口 |
| --- | --- | --- |
| csproj 的 `VSTestTestCaseFilter` | `dotnet test` 預設帶上 `Category!=Experiment` | 它是 MSBuild 屬性，IDE 的 Test Explorer 直接驅動 VSTest、不經過 MSBuild，因此擋不住 |
| `[ExperimentFact]` 檢查 `SAMPLE_TESTS_RUN_EXPERIMENTS` | 沒設開關就 skip | 無——不論從哪個入口進來都適用 |

不用 `.runsettings` 的 `TestCaseFilter`（它可以涵蓋 IDE）的原因：
它會與命令列 filter 以 **AND** 結合，導致 `--filter "Category=Experiment"`
變成 `(Category!=Experiment)&(Category=Experiment)`，一個測試都選不到。

## xUnit 執行模型

`xunit.runner.json` 明確設定 `parallelizeTestCollections: false`。
注意 xUnit v2 從 2.0 起 **collection 之間預設平行執行**，
沒掛 `[Collection]` 的測試類別各自是隱含 collection——
新增測試類別時務必繼承 `IntegrationTestBase`（已內建 Collection 屬性）。

## 套件版本

版本集中管理於 `Directory.Packages.props`（CPM）。
發佈或引用前建議以 `dotnet outdated` 或 NuGet 確認最新版本。
