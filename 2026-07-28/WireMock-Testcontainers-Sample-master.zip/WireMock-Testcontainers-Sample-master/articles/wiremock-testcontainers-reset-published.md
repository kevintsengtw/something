---
title: "WireMock.Net.Testcontainers 多服務整合測試：正確重置共用 Container"
date: 2026-07-28
tags:
  - dotnet
  - csharp
  - testing
  - xunit
  - wiremock
  - testcontainers
  - integration-test
categories:
  - 測試
description: 使用多個 WireMock.Net Testcontainers 共用測試環境時，如何正確清除 mappings 與 request log，避免錯用 Java WireMock 的 /__admin/reset。
---

# WireMock.Net.Testcontainers 多服務整合測試：正確重置共用 Container

## 問題情境

假設一個開戶 API 會依序呼叫三個外部服務：

- 開戶主檔服務
- 身分驗證服務
- 金流服務

正式環境裡，這三個服務各有不同的 base URL。整合測試也採用相同拓撲：一個外部服務對應一個 WireMock container，避免不同服務的路徑與狀態混在一起。

Container 的啟動成本比一般測試物件高，因此整組測試會透過 xUnit Collection Fixture 共用三個 container。每個測試只需要重新設定該情境使用的 stub，不必重新啟動 Docker。

共用資源帶來的問題是狀態隔離。前一個測試留下的 mapping 或 request log，可能影響下一個測試，所以每個測試開始前都必須重置全部 WireMock 服務。

## 最容易踩到的錯誤：`/__admin/reset`

下面這段看起來像是在加強清理，實際上混用了兩套不同的 API：

```csharp
using var httpClient = container.CreateClient();
using var response = await httpClient.PostAsync(
    "/__admin/reset",
    null,
    cancellationToken);

response.EnsureSuccessStatusCode();

await admin.ResetMappingsAsync(cancellationToken: cancellationToken);
await admin.ResetRequestsAsync(cancellationToken);
```

問題在於 `POST /__admin/reset` 是 Java WireMock 的管理端點，不是 WireMock.Net 的端點。WireMock.Net 收到這個請求時找不到相符的管理路由或 stub，會回傳 `404 Not Found`。

接著 `EnsureSuccessStatusCode()` 會拋出 `HttpRequestException`，所以下方真正負責清理的 `ResetMappingsAsync()` 與 `ResetRequestsAsync()` 根本沒有執行。

如果例外沒有被捕捉，測試初始化會直接失敗；如果外層只記錄或忽略了例外，表面上就可能看起來像是 reset 執行過卻沒有作用。兩種情況的根因都一樣：不是 `ResetMappingsAsync()` 失效，而是程式流程沒有走到它。

WireMock.Net 對應的管理操作是：

- `POST /__admin/mappings/reset`：刪除 mappings
- `POST /__admin/requests/reset`：刪除 request log

使用 `WireMock.Net.RestClient` 提供的 `IWireMockAdminApi` 時，不需要自己組合這些 URL，直接呼叫：

```csharp
await admin.ResetMappingsAsync(cancellationToken: cancellationToken);
await admin.ResetRequestsAsync(cancellationToken);
```

同一件事固定使用官方 admin client，能避免混入其他語言版本的端點與語意。

## 完整解法

範例使用：

- .NET 10
- xUnit v3
- `WireMock.Net.Testcontainers` 2.13.0
- `Microsoft.AspNetCore.Mvc.Testing`

完整可執行專案放在 repository 的 `samples/` 目錄。

### 集中管理服務名稱

```csharp
/// <summary>
/// 集中定義整合測試使用的外部服務名稱。
/// </summary>
public static class WireMockServices
{
    /// <summary>
    /// 開戶主檔服務的名稱。
    /// </summary>
    public const string OpenAccountApi = "OpenAccountApi";

    /// <summary>
    /// 身分驗證服務的名稱。
    /// </summary>
    public const string IdentityApi = "IdentityApi";

    /// <summary>
    /// 金流服務的名稱。
    /// </summary>
    public const string PaymentApi = "PaymentApi";
}
```

服務名稱同時用於 container registry、admin client 查找與 ASP.NET Core named `HttpClient`，集中成常數可以避免拼字不一致。

### Collection Fixture

Fixture 負責四件事：

1. 啟動所有 WireMock containers。
2. 保存各服務的 admin client 與公開 URL。
3. 建立 `WebApplicationFactory<Program>`，注入動態 URL。
4. 在整組測試結束後釋放資源。

```csharp
using System.Collections.Concurrent;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using WireMock.Client;
using WireMock.Net.Testcontainers;
using Xunit;

/// <summary>
/// 管理整組整合測試共用的 WireMock containers 與 ASP.NET Core 測試主機。
/// </summary>
/// <remarks>
/// 每個外部服務各使用一個 container，並透過 xUnit Collection Fixture
/// 在多個測試類別之間共用。每個測試開始前應呼叫 <see cref="ResetAllAsync"/>。
/// </remarks>
public sealed class WireMockFixture : IAsyncLifetime
{
    private static readonly string[] Services =
    {
        WireMockServices.OpenAccountApi,
        WireMockServices.IdentityApi,
        WireMockServices.PaymentApi,
    };

    private readonly ConcurrentDictionary<string, WireMockContainer> _containers = new();
    private readonly ConcurrentDictionary<string, IWireMockAdminApi> _admins = new();
    private readonly ConcurrentDictionary<string, string> _baseUrls = new();

    private bool _disposed;

    /// <summary>
    /// 取得已注入動態 WireMock 位址的 ASP.NET Core 測試應用程式工廠。
    /// </summary>
    public WebApplicationFactory<Program> Factory { get; private set; } = null!;

    /// <summary>
    /// 平行啟動所有 WireMock containers，並建立測試應用程式工廠。
    /// </summary>
    /// <returns>代表非同步初始化作業的工作。</returns>
    public async ValueTask InitializeAsync()
    {
        try
        {
            await Task.WhenAll(Services.Select(StartAsync));
        }
        catch
        {
            // InitializeAsync 失敗時，不能依賴 xUnit 之後呼叫 DisposeAsync。
            await DisposeAsync();
            throw;
        }

        Factory = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
        {
            builder.ConfigureAppConfiguration((_, configurationBuilder) =>
            {
                configurationBuilder.AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["ExternalServices:OpenAccountApi:BaseUrl"] =
                        BaseUrl(WireMockServices.OpenAccountApi),
                    ["ExternalServices:IdentityApi:BaseUrl"] =
                        BaseUrl(WireMockServices.IdentityApi),
                    ["ExternalServices:PaymentApi:BaseUrl"] =
                        BaseUrl(WireMockServices.PaymentApi),
                });
            });
        });
    }

    /// <summary>
    /// 啟動指定服務的 WireMock container，並註冊其 admin client 與公開位址。
    /// </summary>
    /// <param name="serviceName">要啟動的服務名稱。</param>
    private async Task StartAsync(string serviceName)
    {
        var container = new WireMockContainerBuilder().Build();

        try
        {
            await container.StartAsync();
        }
        catch
        {
            // 尚未加入 _containers 的失敗實例，要在這裡直接釋放。
            await container.DisposeAsync();
            throw;
        }

        _containers[serviceName] = container;
        _admins[serviceName] = container.CreateWireMockAdminClient();
        _baseUrls[serviceName] = container.GetPublicUrl();
    }

    /// <summary>
    /// 取得指定 WireMock 服務可由測試主機存取的公開位址。
    /// </summary>
    /// <param name="serviceName">服務名稱。</param>
    /// <returns>WireMock 服務的 base URL。</returns>
    public string BaseUrl(string serviceName) => _baseUrls[serviceName];

    /// <summary>
    /// 取得指定 WireMock 服務的管理 API client。
    /// </summary>
    /// <param name="serviceName">服務名稱。</param>
    /// <returns>可設定與重置該服務的管理 API client。</returns>
    public IWireMockAdminApi Admin(string serviceName) => _admins[serviceName];

    /// <summary>
    /// 清除所有 WireMock 服務的動態 mappings 與 request logs。
    /// </summary>
    /// <param name="cancellationToken">取消非同步重置作業的權杖。</param>
    /// <returns>代表非同步重置作業的工作。</returns>
    /// <exception cref="InvalidOperationException">任一服務在重置後仍殘留 mapping。</exception>
    public async Task ResetAllAsync(CancellationToken cancellationToken = default)
    {
        foreach (var (name, admin) in _admins)
        {
            await admin.ResetMappingsAsync(cancellationToken: cancellationToken);
            await admin.ResetRequestsAsync(cancellationToken);

            var remaining = await admin.GetMappingsAsync(cancellationToken);
            if (remaining.Count != 0)
            {
                throw new InvalidOperationException(
                    $"[{name}] reset 後仍殘留 {remaining.Count} 筆 mapping：" +
                    string.Join(
                        ", ",
                        remaining.Select(mapping =>
                            $"{mapping.Guid}:{mapping.Request?.Path}")));
            }
        }
    }

    /// <summary>
    /// 釋放測試應用程式工廠與所有已啟動的 WireMock containers。
    /// </summary>
    /// <returns>代表非同步清理作業的工作。</returns>
    public async ValueTask DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;

        if (Factory is not null)
        {
            await Factory.DisposeAsync();
        }

        await Task.WhenAll(
            _containers.Values.Select(container =>
                container.DisposeAsync().AsTask()));
    }
}
```

這裡有三個重要細節。

第一，containers 使用 `Task.WhenAll` 平行啟動，因此多個 `StartAsync` 會同時寫入 registry，欄位使用 `ConcurrentDictionary`。

第二，外層 `catch` 會清理已成功啟動並加入 registry 的 containers；內層 `catch` 則清理「啟動失敗、尚未加入 registry」的那一個。兩層負責的資源不同。

第三，`ResetAllAsync` 在清理後重新查詢 mappings。若某個服務仍有殘留，測試會在初始化階段直接失敗，而不是讓髒狀態流入後續斷言。

如果測試使用 WireMock scenario，還要依需求重置 scenario state；本文範例沒有使用 scenario。

### 測試開始前重置

Collection Fixture 讓多個測試類別共用同一份 `WireMockFixture`：

```csharp
/// <summary>
/// 定義共用 <see cref="WireMockFixture"/> 的 xUnit test collection。
/// </summary>
[CollectionDefinition(Name)]
public sealed class WireMockCollection : ICollectionFixture<WireMockFixture>
{
    /// <summary>
    /// WireMock 整合測試 collection 的唯一名稱。
    /// </summary>
    public const string Name = "wiremock";
}
```

測試基底類別統一套用 collection，並在每個測試的 `InitializeAsync()` 清除狀態：

```csharp
/// <summary>
/// 提供共用 WireMock fixture 與每個測試執行前的狀態重置。
/// </summary>
[Collection(WireMockCollection.Name)]
public abstract class WireMockTestBase : IAsyncLifetime
{
    /// <summary>
    /// 取得目前 test collection 共用的 WireMock fixture。
    /// </summary>
    protected readonly WireMockFixture Fixture;

    /// <summary>
    /// 初始化測試基底類別。
    /// </summary>
    /// <param name="fixture">目前 collection 共用的 WireMock fixture。</param>
    protected WireMockTestBase(WireMockFixture fixture)
    {
        Fixture = fixture;
    }

    /// <summary>
    /// 在每個測試方法執行前清除所有 WireMock 狀態。
    /// </summary>
    /// <returns>代表非同步初始化作業的工作。</returns>
    public async ValueTask InitializeAsync() =>
        await Fixture.ResetAllAsync(
            TestContext.Current.CancellationToken);

    /// <summary>
    /// 完成單一測試的清理；共用 fixture 由 xUnit 在 collection 結束時釋放。
    /// </summary>
    /// <returns>已完成的非同步清理作業。</returns>
    public ValueTask DisposeAsync() => default;
}
```

把 reset 放在測試之前，代表每個測試自己保證起點乾淨，不依賴上一個測試是否正確收尾。

同一個 xUnit test collection 內的測試不會彼此平行，這對共用 WireMock 狀態很重要。所有會操作這份 fixture 的測試類別，都必須加入相同 collection。把 `[Collection]` 放在共同基底類別，可以降低漏標的風險。

### 動態設定 Stub

測試內的 stub 可以包成擴充方法：

```csharp
using WireMock.Admin.Mappings;
using WireMock.Client;

/// <summary>
/// 提供整合測試建立 WireMock JSON stub 的便利方法。
/// </summary>
public static class WireMockStubExtensions
{
    /// <summary>
    /// 建立一筆依 HTTP method 與 path 比對並回傳 JSON 的動態 mapping。
    /// </summary>
    /// <param name="admin">目標 WireMock 服務的管理 API client。</param>
    /// <param name="method">要比對的 HTTP method。</param>
    /// <param name="path">要比對的請求 path。</param>
    /// <param name="statusCode">stub 回傳的 HTTP 狀態碼。</param>
    /// <param name="body">要序列化成 JSON 的回應內容。</param>
    /// <param name="cancellationToken">取消建立 mapping 作業的權杖。</param>
    /// <returns>代表非同步建立 mapping 作業的工作。</returns>
    public static Task StubJsonAsync(
        this IWireMockAdminApi admin,
        string method,
        string path,
        int statusCode,
        object body,
        CancellationToken cancellationToken = default)
    {
        return admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel
            {
                Path = path,
                Methods = new[] { method },
            },
            Response = new ResponseModel
            {
                StatusCode = statusCode,
                Headers = new Dictionary<string, object>
                {
                    ["Content-Type"] = "application/json",
                },
                BodyAsJson = body,
            },
        }, cancellationToken);
    }
}
```

這個 helper 不指定固定 `Guid`，每次呼叫都建立該測試需要的 mapping。本文情境也不需要將動態 mapping 寫入磁碟。

### 實際測試

每個測試只設定自己需要的三個外部服務：

```csharp
/// <summary>
/// 驗證開戶 API 與三個外部服務之間的整合流程。
/// </summary>
public sealed class OpenAccountTests : WireMockTestBase
{
    /// <summary>
    /// 初始化開戶流程整合測試。
    /// </summary>
    /// <param name="fixture">目前 collection 共用的 WireMock fixture。</param>
    public OpenAccountTests(WireMockFixture fixture)
        : base(fixture)
    {
    }

    /// <summary>
    /// 驗證三個外部服務皆成功時，API 會回傳新帳號與交易狀態。
    /// </summary>
    [Fact]
    public async Task 開戶成功_應回傳帳號()
    {
        var cancellationToken = TestContext.Current.CancellationToken;

        await Fixture.Admin(WireMockServices.OpenAccountApi)
            .StubJsonAsync(
                "POST",
                "/api/accounts",
                200,
                new { accountNo = "0012345678" },
                cancellationToken);

        await Fixture.Admin(WireMockServices.IdentityApi)
            .StubJsonAsync(
                "POST",
                "/api/verify",
                200,
                new { verified = true },
                cancellationToken);

        await Fixture.Admin(WireMockServices.PaymentApi)
            .StubJsonAsync(
                "POST",
                "/api/deposits",
                200,
                new { transactionId = "TX-001", status = "Completed" },
                cancellationToken);

        using var client = Fixture.Factory.CreateClient();
        using var response = await client.PostAsJsonAsync(
            "/api/open-account",
            new OpenAccountRequest(
                "Kevin",
                "A123456789",
                1000m),
            cancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var result =
            await response.Content.ReadFromJsonAsync<OpenAccountResponse>(
                cancellationToken);

        result!.AccountNo.Should().Be("0012345678");
        result.Status.Should().Be("Completed");
    }
}
```

另一個值得保留的測試是身分驗證失敗時，不得呼叫金流服務。這同時驗證業務短路邏輯，也驗證 request log 在測試開始前確實是乾淨的：

```csharp
var paymentRequests =
    await Fixture.Admin(WireMockServices.PaymentApi)
        .GetRequestsAsync(cancellationToken);

paymentRequests.Should().BeEmpty();
```

不要用兩個測試的執行先後來證明 reset 有效。若要直接測試 reset，應在同一個測試方法內完成「建立舊狀態、reset、建立新狀態、驗證新結果」，避免依賴測試順序。

## 靜態 Mapping

若 container 使用 `.WithMappings(...)` 從檔案載入靜態 mappings，需要先決定 reset 後是否要重新載入它們。

```csharp
await admin.ResetMappingsAsync(
    reloadStaticMappings: true,
    cancellationToken: cancellationToken);
```

本文範例的 mappings 全部由測試動態建立，因此使用預設行為，reset 後保持空白。

## xUnit v2 與 v3

本文使用 xUnit v3，`IAsyncLifetime.InitializeAsync()` 與非同步清理使用 `ValueTask`。

xUnit v2 的 `IAsyncLifetime` 則是：

```csharp
public interface IAsyncLifetime
{
    Task InitializeAsync();
    Task DisposeAsync();
}
```

如果專案仍使用 xUnit v2，保留相同生命週期邏輯，將方法簽章換成 v2 對應的 `Task` 即可。

## 排查清單

遇到 WireMock 測試互相污染時，可以依序確認：

1. 所有共用 fixture 的測試類別是否位於相同 xUnit collection。
2. 是否同時清除了 mappings 與 request log。
3. 多 container 架構是否遍歷了全部 admin clients。
4. reset 是否放在每個測試開始前。
5. reset 後是否立即查詢並拒絕殘留 mappings。
6. 是否混用了手刻 admin URL 與官方 admin client。
7. 是否誤用 Java WireMock 的 `POST /__admin/reset`。
8. 是否使用靜態 mappings，且需要 `reloadStaticMappings: true`。
9. 若 WireMock 已乾淨，待測系統本身是否仍有快取或靜態狀態。

## 結語

這個問題的修正很直接：

```csharp
await admin.ResetMappingsAsync(cancellationToken: cancellationToken);
await admin.ResetRequestsAsync(cancellationToken);
```

真正重要的是讓測試基礎設施只有一套明確的重置機制，並在 reset 後立即驗證結果。這樣一旦隔離失效，錯誤會出現在 fixture，而不是在下一個看似無關的測試裡。

開發過程中的行為驗證、效能實驗與 xUnit 生命週期探測保留在 repository 的 `docs/` 與 `WireMockDemo.Experiments`，不影響本文的解決方案主線。

## 參考資料

- [WireMock.Net GitHub](https://github.com/wiremock/WireMock.Net)
- [Using WireMock.Net.Testcontainers](https://wiremock.org/dotnet/using-wiremock-net-testcontainers/)
- [WireMock.Net Admin API Reference](https://wiremock.org/dotnet/admin-api-reference/)
- [xUnit：Sharing Context between Tests](https://xunit.net/docs/shared-context)
- [xUnit：Running Tests in Parallel](https://xunit.net/docs/running-tests-in-parallel)
- 完整範例：`samples/`
- 驗證紀錄：`docs/verification-results.md`
