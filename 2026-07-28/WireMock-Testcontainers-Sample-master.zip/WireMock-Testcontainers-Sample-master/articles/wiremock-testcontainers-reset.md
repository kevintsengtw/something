---
title: "WireMock.Net.Testcontainers 多服務整合測試：一個 reset 失效的除錯歷程"
date: 2026-07-27
tags:
  - dotnet
  - csharp
  - testing
  - xunit
  - wiremock
  - testcontainers
  - integration-test
categories:
  - 測試
description: 用 WireMock.Net.Testcontainers 模擬多組外部 API 服務時，遇到「測試情境一污染測試情境二」的問題。這篇記錄完整的排查過程，從懷疑平行執行、檢查 IsPersistent，一路到找出真正的兇手：一段多餘的 /__admin/reset 呼叫。
draft: true
---

# WireMock.Net.Testcontainers 多服務整合測試：一個 reset 失效的除錯歷程

> **草稿，尚未發表。** 文章內的程式碼與行為描述尚未經過實際專案編譯與執行驗證，發表前務必先完成文末〈發表前待驗證清單〉的每一項。

## 前言

寫整合測試時，只要系統會呼叫外部 API，遲早會需要一個 mock server。[WireMock.Net](https://github.com/wiremock/WireMock.Net) 是 .NET 生態裡最成熟的選擇，而 `WireMock.Net.Testcontainers` 讓你可以把它跑在 Docker container 裡，用完即棄。

我最近在一個專案裡遇到的情境比較複雜：待測系統會呼叫**多組不同的外部 API 服務**，所以我需要同時啟動多個 WireMock container，各自模擬一個服務。架構搭起來之後，測試開始出現一個惱人的症狀 —— **測試情境一的 stub 設定，會影響到測試情境二的執行結果**。

明明每個測試前都有呼叫 `ResetMappingsAsync()`，為什麼還是會互相污染？

這篇文章記錄整個排查過程。結論其實只有一行程式碼的差別，但中間繞的路、以及過程中釐清的觀念，我認為比答案本身更有價值。如果你正在用 WireMock 寫整合測試，這些坑你大概率也會踩到。

## 背景：為什麼需要多個 Container

先說明一下架構。假設待測系統是一個開戶流程的 API，它在處理請求時會依序呼叫三個外部服務：開戶主檔服務、身分驗證服務、以及金流服務。

一個很自然的想法是：反正 WireMock 可以設定多組 path，用**一個** container 模擬全部三個服務不就好了嗎？

技術上可行，但實務上不建議。因為這三個服務在正式環境是三個不同的 base URL，如果你用一個 mock 打發全部，就必須讓待測系統的三組設定都指向同一個位址 —— 這跟正式環境的拓撲不一致，而且一旦不同服務的 path 撞名（例如都有 `/health` 或 `/api/status`），你就得靠 header 或 query 去繞，很快就會失控。

所以我的做法是：**一個外部服務對應一個 WireMock container**，各自有獨立的 base URL，跟正式環境的結構一致。

## 第一版架構

先看單一 container 怎麼設定多組 path，這是基本功。container 啟動後，透過 admin client 灌入 mapping：

```csharp
using WireMock.Net.Testcontainers;
using WireMock.Admin.Mappings;
using WireMock.Client;

var container = new WireMockContainerBuilder().Build();
await container.StartAsync();

var adminApi = container.CreateWireMockAdminClient();

await adminApi.PostMappingsAsync(new[]
{
    new MappingModel
    {
        Request  = new RequestModel { Path = "/api/users", Methods = new[] { "GET" } },
        Response = new ResponseModel
        {
            StatusCode = 200,
            Headers    = new Dictionary<string, object> { ["Content-Type"] = "application/json" },
            BodyAsJson = new { id = 1, name = "Kevin" }
        }
    },
    new MappingModel
    {
        Request  = new RequestModel { Path = "/api/orders", Methods = new[] { "GET" } },
        Response = new ResponseModel { StatusCode = 200, BodyAsJson = new[] { new { orderId = "A001" } } }
    }
});

var baseUrl = container.GetPublicUrl();
```

`PostMappingsAsync` 接受一個 `MappingModel` 陣列，每個元素就是一組「path 對應 response」。想多幾個 path 就往陣列裡塞。

接著是多 container 的版本。因為 container 啟動很貴（每個大約一到數秒），不可能每個測試方法都重啟一輪，所以自然的做法是用 xUnit 的 Collection Fixture 讓整組測試共用，並在每個測試方法執行前把狀態清乾淨：

```csharp
public class WireMockFixture : IAsyncLifetime
{
    private readonly Dictionary<string, WireMockContainer> _containers = new();
    private readonly Dictionary<string, IWireMockAdminApi> _admins = new();

    public async Task InitializeAsync() { /* 啟動各個 container */ }

    public async Task ResetAllAsync()
    {
        foreach (var admin in _admins.Values)
        {
            await admin.ResetMappingsAsync();
            await admin.ResetRequestsAsync();
        }
    }

    public async Task DisposeAsync()
    {
        foreach (var c in _containers.Values)
        {
            await c.DisposeAsync();
        }
    }
}

[CollectionDefinition("wiremock")]
public class WireMockCollection : ICollectionFixture<WireMockFixture> { }
```

測試基底類別在每個測試前呼叫 `ResetAllAsync()`：

```csharp
public abstract class WireMockTestBase : IAsyncLifetime
{
    protected readonly WireMockFixture Fixture;
    protected WireMockTestBase(WireMockFixture fixture) => Fixture = fixture;

    public Task InitializeAsync() => Fixture.ResetAllAsync();
    public Task DisposeAsync() => Task.CompletedTask;
}
```

理論上這樣就乾淨了。實際上，測試還是會互相污染。

## 排查第一站：是不是平行執行？

共用 mock server 出現污染，第一個要懷疑的永遠是**平行執行**。如果兩個測試同時對同一個 container 操作，A 的 `ResetMappingsAsync` 會把 B 剛灌進去的 mapping 洗掉，或者 B 讀到 A 殘留的設定 —— 症狀跟我遇到的一模一樣。

這裡有個 xUnit 的機制要先講清楚，因為很多人（包括當時的我）搞混過。xUnit 的平行規則是：**同一個 test collection 內的測試類別會依序執行、彼此絕不平行；不同 collection 之間才會平行**。

這代表什麼？如果你有五個測試類別都會用到這個共用的 fixture，但其中一個忘了標 `[Collection("wiremock")]`，那個類別就會自成一個獨立的 collection，跟其他四個平行執行 —— 然後一起打同一個 container，互相踩踏。

而且這個坑很隱蔽：collection 名稱是字串比對，`"wiremock"` 和 `"WireMock"` 是兩個不同的 collection。只要有任何一個類別脫隊，整套隔離就破功。

所以第一步是確認序列化。有三種做法，任選其一：

最直接的是確保**所有**會碰到這個 container 的測試類別，都標上完全相同的 collection 名稱：

```csharp
[Collection("wiremock")]
public class OpenAccountTests : WireMockTestBase { /* ... */ }

[Collection("wiremock")]   // 必須同名，不能省略、不能拼錯
public class PaymentTests : WireMockTestBase { /* ... */ }
```

或者直接關掉整個測試組件的平行執行，放在任一個 `.cs` 檔：

```csharp
[assembly: CollectionBehavior(DisableTestParallelization = true)]
```

也可以用 `xunit.runner.json` 設定：

```json
{ "parallelizeTestCollections": false }
```

我把整個組件的平行執行關掉之後 —— **污染依舊存在**。

這其實是個好消息，因為它一口氣排除了最大的嫌疑犯。問題不在平行，而在 reset 邏輯本身。

## 排查第二站：reset 有清到全部嗎？

多 container 架構最常見的疏漏，是 reset 只清了其中一部分。

想像你的字典裡有 `openAccount`、`identity`、`payment` 三個 container，但 `ResetAllAsync` 因為某次重構只清了前兩個，或是新增服務時忘了加進清單 —— 那個漏掉的 container 就會忠實地把上一個測試的 stub 帶到下一個測試。

這種 bug 特別討厭，因為它是「部分失效」：大部分測試看起來正常，只有牽涉到那個服務的測試會偶爾出錯，很容易被誤判成 flaky test。

我檢查了 `ResetAllAsync`，確認它是用 `foreach` 遍歷字典裡**每一個** admin client，沒有遺漏。這條也排除了。

順帶一提，這裡有個容易寫錯的細節：`ResetMappingsAsync()` 和 `ResetRequestsAsync()` 是兩件不同的事。前者清掉 mapping（也就是 stub 設定），後者只清「收到的請求紀錄」（給事後驗證用的 request journal）。造成 stub 污染的是前者，但如果你的測試會驗證「某個 API 被呼叫了幾次」，那後者沒清也會造成假陽性。兩個都要清。

## 排查第三站：靜態 mapping 與持久化

第三個嫌疑犯是 mapping 本身的屬性。

WireMock 的 mapping 有幾種來源。除了測試中動態 POST 進去的之外，還有透過 `.WithMappings("./mappings")` 從 JSON 檔載入的**靜態 mapping**。這兩者在 reset 時的行為，跟直覺不太一樣。

這裡值得展開講，因為它牽涉到 WireMock.Net 的一段歷史。專案的 [issue #372](https://github.com/wiremock/WireMock.Net/issues/372) 就是在討論 reset 的語意問題：當時的 reset 會把**所有** stub mapping 刪掉，包括從磁碟載入的靜態 mapping，導致使用者原本預期「重置回初始狀態」，結果拿到一個完全空的 server。

修正的方式是給 reset 加上一個參數：

```csharp
ResetMappingsAsync(bool? reloadStaticMappings = false)
```

注意預設值是 `false`。也就是說，**你呼叫 `ResetMappingsAsync()` 之後，靜態 mapping 不會自動回來**，除非你明確傳 `true`。

這個設計對「每個測試都完全動態設定」的用法來說是對的（我們就是要一個乾淨的空 server），但如果你的架構是「靜態 mapping 當共用基底 + 動態 mapping 做個案覆寫」，那每次 reset 之後你的基底就消失了，行為當然會亂掉。

我的專案沒有用靜態 mapping，全部都是測試內動態設定的，所以這條也不是。

## 讓程式自己說話：加上診斷

排查到這裡，三個主要嫌疑犯都排除了，但污染還在。與其繼續用猜的，不如讓程式自己告訴我哪裡出問題。

我在 `ResetAllAsync` 裡加了一段驗證：reset 完之後立刻回頭查詢，如果還有殘留就當場拋例外，並把殘留的 mapping 印出來。

```csharp
public async Task ResetAllAsync()
{
    foreach (var (name, admin) in _admins)
    {
        await admin.ResetMappingsAsync();
        await admin.ResetRequestsAsync();

        var remaining = await admin.GetMappingsAsync();
        if (remaining.Count != 0)
        {
            throw new InvalidOperationException(
                $"[{name}] reset 後仍殘留 {remaining.Count} 筆 mapping：" +
                string.Join(", ", remaining.Select(m => $"{m.Guid}:{m.Request?.Path}")));
        }
    }
}
```

這段程式碼的價值不只在於找出當下的問題，更在於它把「隱性的污染」變成「顯性的失敗」。原本髒狀態會悄悄流到下一個測試，讓你在錯誤的地方 debug；現在它會在污染發生的當下、在正確的位置炸開，還告訴你是哪個服務、殘留了什麼 path。

**我強烈建議把這種自我驗證留在 fixture 裡**，不要只當成臨時的除錯手段。它的成本是每個測試多幾個 HTTP 往返，換來的是整套測試的可信度。

跑下去之後，例外訊息立刻指出：reset 呼叫完之後，mapping 數量根本沒有歸零。

## 真兇：一段多餘的 `/__admin/reset`

有了明確的線索，回頭翻 `ResetAsync` 的實作，問題就浮出來了。

原本的程式碼在呼叫 `ResetMappingsAsync()` 之前，還多做了一件事：先從 container 取得一個 `HttpClient`，然後直接對 `/__admin/reset` 這個路徑打一發 HTTP 請求。

```csharp
// 問題所在：多此一舉的手動呼叫
var httpClient = container.CreateClient();
await httpClient.PostAsync("/__admin/reset", null);

// 然後才是正規的 admin client
await admin.ResetMappingsAsync();
```

把上面那兩行手動呼叫拿掉之後，reset 立刻正常，測試污染完全消失。

## 為什麼會這樣？

這裡值得停下來想一下，因為「拿掉就好了」不算真的理解。而這一節也是我寫這篇文章時，唯一去翻了原始碼才敢下筆的部分 —— 因為我原本的直覺解釋是錯的。

### 第一個事實：WireMock.Net 根本沒有 `/__admin/reset` 這個端點

查閱 [WireMock.Net 的 Admin API Reference](https://wiremock.org/dotnet/admin-api-reference/)，跟重置有關的端點是這幾個：

`DELETE /__admin/mappings` 或 `POST /__admin/mappings/reset` 用來刪除所有 stub mapping；`POST /__admin/mappings/reloadStaticMappings` 用來從磁碟重新載入靜態 mapping；`POST /__admin/requests/reset` 用來清除請求紀錄。

翻 WireMock.Net 的原始碼（`WireMockServer.Admin.cs` 的路由註冊區塊）可以確認，跟 reset 相關的註冊路由只有四條：`POST __admin/mappings/reset`、`POST __admin/mappings/reloadStaticMappings`、`POST __admin/requests/reset`，以及 scenario 相關的 reset。**清單裡沒有 `/__admin/reset`。**

這代表：對 `/__admin/reset` 發出的請求，並不會被 admin 路由攔截，而是**掉進一般的 stub 比對流程**，因為沒有任何 mapping 符合，最後回傳 404。它對 mapping 完全沒有副作用。

### 第二個事實：這是從 Java 版帶過來的習慣

`/__admin/reset` 是 WireMock **Java 版**的端點，語意是「移除所有 stub mapping 並清空 request log」。很多教學文章與 Stack Overflow 答案是以 Java 版為基礎寫的，路徑就這樣被複製到 .NET 專案裡。

更容易混淆的是：`/__admin/mappings/reset` 在**兩邊都存在，語意卻不同**。Java 版的意思是「還原成檔案定義的預設 mappings」，.NET 版則是「刪除全部，且預設不重載靜態 mapping」。所以這不是單純的「Java 有、.NET 沒有」，而是同名端點在兩個實作裡代表不同的事 —— 這種陷阱比純粹的路徑不存在更難察覺。

### 那為什麼拿掉它就好了？

既然那個呼叫只會拿到 404、對 mapping 沒有副作用，理論上它應該是無害的死程式碼才對。這裡我必須誠實：**我沒有百分之百確定的因果鏈。**

最合理的解釋是：那個失敗的呼叫讓 `ResetAsync` 這個方法**根本沒有執行到後面真正的 reset**。無論是因為呼叫端有做狀態碼檢查（例如 `EnsureSuccessStatusCode()`）而拋出例外，或是外層有 try/catch 把例外吞掉、導致後續程式碼被跳過 —— 結果都一樣：`ResetMappingsAsync()` 那一行從來沒有被執行。這完全符合我觀察到的症狀，也解釋了為什麼「多做一步」會讓 reset「失效」—— 它其實不是失效，是壓根沒跑到。

這個推論帶出的教訓，比端點路徑本身更普遍：**一段看起來無害的多餘呼叫，可能讓後面真正該執行的程式碼不會被執行到。** 尤其在 setup / teardown 這種「沒人在看」的基礎設施程式碼裡，一個被吞掉的例外可以安靜地癱瘓整套清理邏輯。這也再次說明了前一節那段驗證程式碼的價值 —— 有它在，這種靜默失敗會立刻現形。

至於直接可行動的結論，則是：

> **同一件事只用一種方式做。** 既然已經有官方的 admin client，就固定用 `ResetMappingsAsync()` / `ResetRequestsAsync()`，不要自己去拼 admin URL 疊加呼叫。手刻的 HTTP 呼叫繞過了 client 的型別檢查與版本適配，路徑打錯不會有編譯錯誤，只會在執行期安靜地回一個 404。

## 重寫後的完整架構

問題解決後，我順手把整個 fixture 重構了一輪。以下是最終版本，我會分段說明每個設計決策。

### 服務名稱常數

先把服務名稱集中管理，避免字串打錯：

```csharp
public static class WireMockServices
{
    public const string OpenAccountApi = "OpenAccountApi";
    public const string IdentityApi    = "IdentityApi";
    public const string PaymentApi     = "PaymentApi";
}
```

重點是用 `const`（或至少 `static`）而不是 instance 欄位 —— 讓 `Type.Member` 這種形式能直接取用的是 **static**，不是 const。選 `const` 的額外好處在於它是編譯期常數，可以用在 attribute 引數、`switch` 的 `case` 標籤這些只吃常數的位置；例如你想寫 `[Collection(WireMockServices.OpenAccountApi)]` 時，`static readonly` 是不行的，`const` 才可以。

### 資料驅動的 Fixture

這是重構的重點。第一版的寫法是每個服務手寫一行啟動、一個屬性、一次指派，服務一多就是滿滿的重複程式碼。改成資料驅動之後，**新增一個服務只需要在陣列裡加一個常數**：

```csharp
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using WireMock.Client;
using WireMock.Net.Testcontainers;

public class WireMockFixture : IAsyncLifetime
{
    private static readonly string[] Services =
    {
        WireMockServices.OpenAccountApi,
        WireMockServices.IdentityApi,
        WireMockServices.PaymentApi,
    };

    private readonly ConcurrentDictionary<string, WireMockContainer> _containers = new();
    private readonly ConcurrentDictionary<string, IWireMockAdminApi> _admins = new();
    private readonly ConcurrentDictionary<string, string> _baseUrls = new();

    private bool _disposed;

    // 全部平行啟動
    public async Task InitializeAsync()
    {
        try
        {
            await Task.WhenAll(Services.Select(StartAsync));
        }
        catch
        {
            // Task.WhenAll 只會拋出第一個例外，
            // 此時可能已經有部分 container 成功啟動。
            // InitializeAsync 拋例外時 xUnit 不會呼叫 DisposeAsync，
            // 所以要自己把它們釋放掉，避免留下孤兒 container。
            await DisposeAsync();
            throw;
        }
    }

    private async Task StartAsync(string serviceName)
    {
        var container = new WireMockContainerBuilder().Build();
        await container.StartAsync();

        _containers[serviceName] = container;
        _admins[serviceName]     = container.CreateWireMockAdminClient();
        _baseUrls[serviceName]   = container.GetPublicUrl();
    }

    public string BaseUrl(string serviceName) => _baseUrls[serviceName];

    public IWireMockAdminApi Admin(string serviceName) => _admins[serviceName];

    // 具名屬性：純粹讀字典，沒有額外的指派邏輯
    public string OpenAccountApiBaseUrl => _baseUrls[WireMockServices.OpenAccountApi];
    public string IdentityApiBaseUrl    => _baseUrls[WireMockServices.IdentityApi];
    public string PaymentApiBaseUrl     => _baseUrls[WireMockServices.PaymentApi];

    public async Task ResetAllAsync()
    {
        foreach (var (name, admin) in _admins)
        {
            await admin.ResetMappingsAsync();
            await admin.ResetRequestsAsync();

            var remaining = await admin.GetMappingsAsync();
            if (remaining.Count != 0)
            {
                throw new InvalidOperationException(
                    $"[{name}] reset 後仍殘留 {remaining.Count} 筆 mapping");
            }
        }
    }

    public async Task DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;

        // 三個字典裡只有 _containers 持有需要釋放的資源，
        // _admins 是 RestEase 產生的 client、_baseUrls 是字串，都不需要處理。
        await Task.WhenAll(_containers.Values.Select(c => c.DisposeAsync().AsTask()));
    }
}
```

`InitializeAsync` 裡那段 try/catch 值得說明一下，它跟字典型別無關，是**平行啟動**本身帶來的問題。`Task.WhenAll` 只會拋出第一個例外，但此時其他 container 可能已經成功啟動了；而 `InitializeAsync` 拋例外時 xUnit **不會**呼叫對應的 `DisposeAsync`，那些 container 就變成沒人回收的孤兒。本機開發時偶爾會發現 `docker ps` 裡有殘留，就是這個原因。這裡直接複用 `DisposeAsync`（因為失敗時 `_containers` 裡已經有成功啟動的那些），`_disposed` 旗標則順便讓重複呼叫變安全。

有三個設計決策值得說明。

**為什麼 `StartAsync` 回傳 `Task` 而不是 `Task<string>`？** 因為它在內部就把 container、admin client、base URL 三樣東西都存進字典了，呼叫端不需要接回傳值。如果讓它回傳 URL，`InitializeAsync` 就得寫成一堆 `xxxUrl = await StartAsync(...)` 的指派，或是用 `Task.WhenAll` 之後再讀 `.Result` —— 兩種都比現在的一行 `Task.WhenAll(Services.Select(StartAsync))` 醜。

**為什麼用 `ConcurrentDictionary`？** 因為 `Task.WhenAll` 會讓多個 `StartAsync` 同時執行，而它們都會寫入字典。`Dictionary<TKey, TValue>` 不是執行緒安全的，多執行緒同時寫入可能造成內部結構損壞或遺漏 key —— 而且這種 bug 是機率性的，在 CI 上偶爾炸一次，超難查。換成 `ConcurrentDictionary` 就從根本上避免。

不過這個選擇值得再往下挖一層，因為它不是「有多執行緒就一定要用 `ConcurrentDictionary`」那麼單純。下一節專門談這件事。

**平行啟動的效益有多大？** 假設三個 container 各需要 1.5 秒，循序啟動總共約 4.5 秒，平行啟動則約等於最慢的那一個，大約 1.5 秒。服務數量越多，差距越明顯。要注意這個 `Task.WhenAll` 只在 fixture 初始化時跑一次，**跟測試之間會不會互相污染完全無關** —— 這是兩個不同層次的「平行」，別搞混了。

另外，`foreach (var (name, admin) in _admins)` 這種對 `KeyValuePair` 直接解構的寫法需要 .NET Core 2.0 / .NET Standard 2.1 以上；如果你的目標框架比較舊，改寫成 `foreach (var kvp in _admins)` 再取 `kvp.Key` / `kvp.Value` 即可。

### 補充：`Dictionary` 還是 `ConcurrentDictionary`？

這是我在重構時想最久的一個決定，也是很容易被「反射性地換成 `ConcurrentDictionary` 就對了」帶過去的地方。

判斷的關鍵不是「有沒有多執行緒讀取」，而是「**寫入發生在什麼時候**」。

先把危險的情況講清楚。如果你用 `Task.WhenAll` 平行啟動，而每個 `StartAsync` 都直接往 `_containers[name] = container` 寫，那就是多個執行緒同時寫同一個 `Dictionary`。`Dictionary` 在擴容（resize / rehash）的瞬間內部結構是不一致的，同時寫入可能造成 key 遺失、無限迴圈，甚至 `IndexOutOfRangeException`。而且它是機率性的：本機三個服務可能永遠不會炸，CI 上跑一百次壞一次。

但反過來也要講清楚：**啟動完成之後的階段完全不用擔心**。`Dictionary` 的文件明確保證「只要沒有任何寫入，並行讀取是安全的」。所以測試期間各個測試方法同時去讀 base URL、讀 admin client，即使是一般的 `Dictionary` 也不會有事。也就是說，執行緒安全的需求只存在於 `InitializeAsync` 那短短一段，不是整個 fixture 的生命週期。

想通這件事之後，就會發現有兩種都成立的做法。

**方案一：循序啟動 + `Dictionary`。** 從頭到尾只有一個執行緒在寫，完全沒問題，程式碼也最單純。代價是啟動時間是各 container 相加。服務只有兩三個、每個一秒多的話，其實可以接受。

**方案二：平行啟動 + `ConcurrentDictionary`。** 也就是前面那份程式碼，也是我最後採用的版本。從 `Dictionary` 換過去的成本幾乎是零 —— 索引子寫入、索引子讀取、`foreach` 遍歷 `.Values` 這些簽章完全一樣，連 `new()` 都照舊，改一個型別名稱就結束了。

### 我考慮過但放棄的第三種寫法

原本我還設計了第三種：讓 `StartAsync` 回傳結果而不是自己碰共用狀態，等 `Task.WhenAll` 收齊、回到單一執行緒之後才一次建好字典，欄位型別用 `IReadOnlyDictionary`，讓「建好之後不會再改」直接寫在型別上。

出發點是這樣的：`ConcurrentDictionary` 這個型別在對讀者說「這個字典隨時可能被並行修改」，但實際上你只在初始化時寫入，之後全是唯讀 —— 型別傳達的語意和真實的生命週期並不完全吻合。用 `IReadOnlyDictionary` 就精確多了。

概念上很漂亮，但把整個類別完整寫出來之後，我改變了主意。實際的成本是：

三個欄位**不能再宣告成 `readonly`**（因為要在 `InitializeAsync` 裡指派），所以還得給一個空字典當初始值，免得到處都要處理 null。`StartAsync` 的回傳型別變成 `Task<(string Name, WireMockContainer Container, IWireMockAdminApi Admin, string BaseUrl)>` 這種長到必須換行的四元組；想讓它好看就得再定義一個 record，那是**多一個型別**的代價。而且你失去了 `_containers[name] = container` 這種一行搞定的直覺寫法，換成「先收集、再投影三次」，初始化邏輯從三行變成十行左右。

那換到了什麼？**沒有防止任何 bug。** 兩種寫法在正確使用下的行為完全一樣，換到的只是「型別更精確地表達意圖」這個純粹的表達力收益。

這筆帳不划算。`ConcurrentDictionary` 的代價不過是幾個用不到的鎖物件和一點語意上的失真；而唯讀版要付出的是實打實的樣板程式碼，還會讓後續維護的人多花力氣理解「為什麼要繞這一圈」。**在測試基礎設施這種本來就該讓人一眼看懂的地方，多餘的精巧是負債。**

如果你確實想要 `readonly` 欄位加上唯讀的對外介面，有個幾乎免費的折衷：欄位維持 `readonly ConcurrentDictionary`，需要對外暴露時再用 `IReadOnlyDictionary` 當屬性型別就好 —— `ConcurrentDictionary` 本來就實作了這個介面：

```csharp
private readonly ConcurrentDictionary<string, string> _baseUrls = new();

// 對外只看得到唯讀介面，內部照樣享有執行緒安全的寫入
public IReadOnlyDictionary<string, string> BaseUrls => _baseUrls;
```

這樣同時拿到 `readonly` 欄位、零改寫成本、以及對呼叫端的唯讀保證。美中不足的是類別內部仍然「有能力」在初始化之後亂寫 —— 但那條線靠的本來就是約定與 code review，不是型別系統。

### 順帶澄清：清除 WireMock 狀態跟字典無關

討論字典型別時很容易冒出一個疑問：唯讀字典沒有 `Remove`、沒有 `Clear`，那 teardown 怎麼辦？共用容器資源的 fixture 不是很需要清乾淨嗎？

這個疑問其實混淆了兩件事，值得單獨講清楚，因為就算你用 `ConcurrentDictionary` 也一樣適用。

**清除 WireMock 狀態，從頭到尾不會去動字典。** 你在每個測試前做的 reset，清的是 **WireMock server 內部的 mapping 與 request log**，是透過 admin client 發 HTTP 請求達成的。`ResetMappingsAsync()` 不需要、也不應該把 `_admins` 裡的任何一筆刪掉 —— 那個 admin client 還要繼續用，被清掉的是 server 那邊的狀態。

**釋放資源也不需要移除項目。** teardown 時你是遍歷 `.Values` 逐一 `DisposeAsync()`，這跟能不能從字典移除完全無關 —— 唯讀的是「集合」，不是「元素」。釋放完也不必 `Clear()`：fixture 物件本身馬上就會被丟棄，清空字典沒有實質效果，反而給人「已經清乾淨所以安全」的錯覺。如果你擔心有人在 dispose 之後還誤用 fixture，加一個 `_disposed` 旗標讓誤用直接拋 `ObjectDisposedException`，比一個空字典丟出 `KeyNotFoundException` 好懂太多。

把這兩點合起來就會發現：這個字典的角色只是一張**註冊表**（服務名稱 → container / admin client / base URL），對應關係在啟動的那一刻就固定，直到 fixture 銷毀都不會變。

那什麼情況才真的需要在初始化之後修改字典？主要是這幾種：**延遲啟動**（某個服務只有部分測試會用到，第一次被要求時才啟動）、測試過程中**動態增減** mock 服務、或 container 掛掉後**重啟並替換**。這些都是合理需求，而且都發生在多執行緒環境下，這時候 `ConcurrentDictionary` 搭配 `GetOrAdd` 才真正發揮作用 —— 但要注意 `GetOrAdd` 的 factory 可能被重複執行，用在「啟動 container」這種昂貴又有副作用的操作上還得自己額外處理，那又是另一個題目了。

### 換成 `ConcurrentDictionary` 的成本與代價

實務上很多人會說：反正從 `Dictionary` 換成 `ConcurrentDictionary` 的改動成本很低，換了就換了。這句話是對的 —— 以 fixture 這種用法來說（索引子寫入、索引子讀取、`foreach` 遍歷 `.Values`），兩個型別的簽章完全一樣，連 `new()` 都照舊，真的是零改動。

但正因為換起來太便宜，值得知道自己買到的是什麼。有兩類差異：

**會在編譯期擋下來的，所以無害。** `ConcurrentDictionary` 沒有公開的 `Add(key, value)`，對應的是 `TryAdd`；`Remove(key)` 對應的是 `TryRemove(key, out var value)`。編不過你就會發現，改掉即可。

**編得過、跑得動，但語意悄悄變了的，這才要小心。** 最重要的是：**換型別只讓「單一操作」變成原子的，不會讓「一連串操作」變成原子的。** 下面這段在兩個型別上都是錯的：

```csharp
// 換成 ConcurrentDictionary 之後依然是 race condition
if (!_containers.ContainsKey(name))
{
    _containers[name] = await StartContainerAsync(name);   // 兩條執行緒可能同時進來
}
```

`ContainsKey` 和索引子指派各自都是執行緒安全的，但兩者之間有空隙。要正確就得用 `GetOrAdd` / `AddOrUpdate` / `TryAdd` 這類**把檢查與寫入合併成一次操作**的 API。

其次是列舉行為。`Dictionary` 在列舉過程中被修改會拋 `InvalidOperationException`，這其實是個有用的護欄，會把邏輯錯誤當場暴露；`ConcurrentDictionary` 允許邊列舉邊修改，你拿到的是一份不保證一致的快照。**原本會炸給你看的 bug，換型別之後變成安靜地讀到半新半舊的資料。**

還有兩個小的：`ConcurrentDictionary` 的 `Count` 需要取得所有內部鎖，不像 `Dictionary` 那樣是 O(1) 的欄位讀取；`.Values` 也不是即時檢視，而是每次複製出一份快照集合。在 fixture 裡這兩點都無關痛癢，但如果哪天在高頻程式碼裡做同樣的替換就有差了。

（這一段關於兩個型別行為差異的描述，來源是 .NET 官方文件與 API 簽章，我沒有為了寫這篇文章另外做基準測試或壓力測試驗證。並行寫入 `Dictionary` 造成的損壞是機率性的，本來就不容易用少量次數的實驗穩定重現 —— 如果你要在自己的專案裡驗證，記得跑夠多輪次並提高執行緒數。）

所以結論不是「別用 `ConcurrentDictionary`」，而是：**替換成本低容易讓人把它當成執行緒安全問題的通用解。** 它解決單一操作的原子性，解決不了複合操作的競爭，也解決不了「共用狀態被四散在各處修改」這種設計層面的問題。fixture 的情況剛好落在它最擅長的那一格 —— 只有索引子寫入、沒有 check-then-act、寫入只發生在初始化 —— 所以換過去確實是免費的。真正該守住的那條線是「**共用狀態的寫入只集中在初始化**」，字典型別只是這個決定的外顯而已。

### 注意：xUnit v2 與 v3 的 `IAsyncLifetime` 不一樣

上面所有程式碼是以 **xUnit v2** 為準，`IAsyncLifetime` 的簽章是 `Task InitializeAsync()` 加 `Task DisposeAsync()`。

xUnit v3 改了這個介面：初始化變成 `ValueTask InitializeAsync()`，而清理則改由 `IAsyncDisposable` 提供的 `ValueTask DisposeAsync()` 負責。同一份程式碼直接搬到 v3 是編不過的，要調整成：

```csharp
// xUnit v3：方法主體不變，只有簽章要改
public async ValueTask InitializeAsync()
{
    try
    {
        await Task.WhenAll(Services.Select(StartAsync));
    }
    catch
    {
        await DisposeAsync();
        throw;
    }
}

public async ValueTask DisposeAsync()
{
    if (_disposed)
    {
        return;
    }

    _disposed = true;

    await Task.WhenAll(_containers.Values.Select(c => c.DisposeAsync().AsTask()));
}
```

測試基底類別同理：

```csharp
// xUnit v3
public ValueTask InitializeAsync() => new(Fixture.ResetAllAsync());
public ValueTask DisposeAsync() => default;
```

升級 v3 時這是最容易踩到的第一個編譯錯誤，先知道就不會慌。

### Stub 設定的輔助方法

為了讓測試裡的設定簡潔，包一個擴充方法：

```csharp
using System.Collections.Generic;
using System.Threading.Tasks;
using WireMock.Admin.Mappings;
using WireMock.Client;

public static class WireMockStubExtensions
{
    public static Task StubJsonAsync(
        this IWireMockAdminApi admin,
        string method,
        string path,
        int statusCode,
        object body)
    {
        return admin.PostMappingAsync(new MappingModel
        {
            // 不指定 Guid：讓每次都是全新的 mapping
            // 不設 IsPersistent：確保 reset 清得掉
            Request = new RequestModel
            {
                Path    = path,
                Methods = new[] { method }
            },
            Response = new ResponseModel
            {
                StatusCode = statusCode,
                Headers    = new Dictionary<string, object> { ["Content-Type"] = "application/json" },
                BodyAsJson = body
            }
        });
    }
}
```

兩個註解值得注意。**不要寫死 `Guid`** —— 如果每次 stub 都帶同一個固定 Guid，重複設定時的覆蓋行為會變得難以預測。**不要在動態 stub 上設持久化旗標** —— 動態設定的 stub 本來就該隨測試結束而消失，任何讓它「活得比測試久」的設定都是在製造污染。

另外注意 `admin` 是透過參數傳進來的，而不是在方法內部固定抓某一個服務。多 container 架構下，這個設計讓呼叫端明確指定要對哪個服務下 stub。

### 測試基底類別與實際使用

```csharp
public abstract class WireMockTestBase : IAsyncLifetime
{
    protected readonly WireMockFixture Fixture;

    protected WireMockTestBase(WireMockFixture fixture) => Fixture = fixture;

    // 注意：放在 InitializeAsync（測試前），不是 DisposeAsync（測試後）
    public Task InitializeAsync() => Fixture.ResetAllAsync();

    public Task DisposeAsync() => Task.CompletedTask;
}
```

```csharp
[Collection("wiremock")]
public class OpenAccountTests : WireMockTestBase
{
    public OpenAccountTests(WireMockFixture fixture) : base(fixture) { }

    [Fact]
    public async Task 開戶成功_應回傳帳號()
    {
        await Fixture.Admin(WireMockServices.OpenAccountApi)
            .StubJsonAsync("POST", "/api/accounts", 200, new { accountNo = "0012345678" });

        await Fixture.Admin(WireMockServices.IdentityApi)
            .StubJsonAsync("POST", "/api/verify", 200, new { verified = true });

        // 讓待測系統的各個 client 指向對應的 base url
        // Fixture.OpenAccountApiBaseUrl、Fixture.IdentityApiBaseUrl ...
    }

    [Fact]
    public async Task 身分驗證失敗_應回傳400()
    {
        // 這個測試的 stub 完全獨立，前一個測試的設定已在 InitializeAsync 清除
        await Fixture.Admin(WireMockServices.IdentityApi)
            .StubJsonAsync("POST", "/api/verify", 200, new { verified = false });
    }
}
```

### 為什麼 reset 要放在測試「之前」

這是個小細節，但影響不小。

把清理放在 `DisposeAsync`（測試之後）看起來很符合直覺 —— 誰弄髒誰負責清。

這裡要先澄清一個常見的誤解：**測試方法拋出例外時，xUnit 仍然會執行 `DisposeAsync`**，所以「測試失敗就不會清理」並不成立。後置清理真正會被跳過的情況比較窄：`InitializeAsync` 自己失敗（此時 xUnit 不會呼叫對應的 dispose）、或整個測試程序被強制中止（逾時被砍、CI runner 掛掉、`Environment.FailFast`）。

即便如此，我還是建議把 reset 放在 `InitializeAsync`，理由是**責任歸屬**而不是例外處理：每個測試自己保證起點乾淨，不需要依賴「上一個測試有沒有正確收尾」這件事。這個差異在 debug 時很有感 —— 如果依賴後置清理，一旦有任何一個測試沒清乾淨，你 debug 的會是「第二個測試莫名其妙失敗」，真正的兇手卻是第一個測試。

**防禦性的清理應該由「受害者」而非「加害者」執行。** 兩邊都做也不是壞事，但如果只能選一邊，選前置。

## 隔離策略的取捨

回頭看，「共用 container + reset」並不是唯一解。這裡整理三種策略的取捨，供你依專案情況選擇。

**共用 container + 每測試 reset**，也就是本文的做法。速度最快，因為 container 只啟動一次。代價是你必須自己維護隔離：確保序列化執行、確保 reset 涵蓋所有 container、確保沒有持久化的殘留。適合測試數量多、CI 時間敏感的專案。

**每個測試類別一個 container**，把 `ICollectionFixture` 換成 `IClassFixture`。跨類別天生隔離，類別內仍需 reset。速度與隔離度的折衷。

**改用 in-process 的 `WireMockServer`**，完全不走 Docker。啟動一台 in-process server 是**數十毫秒**等級（相對於 container 的數秒），所以可以奢侈地「每個測試方法一個全新 server」，用完就 `Stop()`，沒有任何共享狀態，也就不需要 reset。這是隔離度最高的做法，而且反而最快。

一個實務細節：`WireMockServer.Start()` 起來的 server **不會**啟用 admin 介面，要用 `WireMockServer.StartWithAdminInterface(...)` 才有。不過在「每個測試一台全新 server」的模式下，你通常會直接用 `server.Given(...).RespondWith(...)` 這組 fluent API 設定 stub，根本不需要 admin API。

那什麼時候非用 container 不可？當你的**待測系統本身也跑在 container 裡**、必須透過 Docker network 用 service name 互連時。如果待測系統是在測試行程內用 `WebApplicationFactory` 跑起來、可以自由設定 `HttpClient` 的 base address，那 in-process 的 `WireMockServer` 通常是更好的選擇。

我的專案因為有 container 間網路的需求，所以留在方案一。但如果你只是單純要 mock 幾個 HTTP 呼叫，不妨先評估 in-process 方案，能省掉本文一大半的麻煩。

## 排查檢查清單

如果你也遇到 WireMock 測試互相污染，照這個順序查：

先確認是不是平行執行。所有相關測試類別是否都標上**完全相同**的 `[Collection]` 名稱？可以先用 `DisableTestParallelization = true` 強制序列化來驗證假設 —— 如果污染消失，方向就對了。

接著確認 reset 有沒有涵蓋全部。多 container 架構下，是否 `foreach` 遍歷了字典裡每一個 admin？新增服務時有沒有漏掉？`ResetMappingsAsync` 和 `ResetRequestsAsync` 是否都呼叫了？

再來確認 reset 的位置。是放在 `InitializeAsync`（測試前）還是 `DisposeAsync`（測試後）？前者才能抵禦「上一個測試爆炸」的情況。

然後確認 mapping 的來源與屬性。有沒有用 `.WithMappings()` 載入靜態 mapping？記得 `ResetMappingsAsync()` 預設**不會**重新載入它們。動態 stub 有沒有被設成持久化？

再檢查有沒有混用多套重置機制。這是我這次踩到的坑：除了 admin client 之外，有沒有另外用 `HttpClient` 手動打 admin 端點？如果有，先拿掉再說。順帶一提，`/__admin/reset` 是 WireMock **Java 版**才有的路徑，WireMock.Net 沒有註冊這條路由，打過去只會得到 404；.NET 這邊要清乾淨需要 `POST /__admin/mappings/reset` 加上 `POST /__admin/requests/reset` 兩支。更麻煩的是 `/__admin/mappings/reset` 兩邊都存在但語意不同（Java 是「還原成檔案定義的預設 mappings」，.NET 是「刪除全部，預設不重載靜態 mapping」），所以照抄 Java 版的範例特別容易出事。

最後，如果以上都確認無誤、reset 後查詢 mapping 數量確實是 0，但污染還在 —— 那問題可能不在 WireMock，而在**待測系統自己**。檢查是否有單例的 `HttpClient`、被快取的設定值、或跨測試存活的靜態狀態。Mock 清乾淨了不代表 SUT 也乾淨。

## 結語

這次除錯花的時間，遠多於最終修改的程式碼量 —— 拿掉兩行而已。但過程中釐清的幾件事，我認為值得記下來。

**症狀相似不代表成因相同。** 「測試互相污染」最典型的成因是平行執行，我一開始也往那邊查。但先用最低成本的方式（強制序列化）驗證假設、快速排除，比一頭鑽進去調整 collection 設定有效率得多。

**讓失敗顯性化。** 那段「reset 後驗證殘留」的程式碼是整個排查的轉捩點。在此之前我都在猜；加上之後，程式直接告訴我答案。**測試基礎設施本身也應該有斷言** —— 它保護的是整套測試的可信度。

**不要混用兩套機制做同一件事。** 有官方 client 就用官方 client。手刻的 HTTP 呼叫繞過了型別檢查與版本適配，出錯時不會有編譯錯誤，只有詭異的執行期行為。

**跨語言移植要小心慣用法。** WireMock 的 Java 版與 .NET 版同名同源，但 admin API 的端點路徑並不完全一致。搜尋到的解法要先確認是哪個版本的文件。

希望這篇能幫你少繞一點路。

## 發表前待驗證清單

> 這一節是給我自己的，發表前刪除。

文章裡的程式碼與行為描述目前都還沒有經過實際專案的編譯與執行驗證。建議建立一個範例方案（一個 WebApi 專案 + 一個 xUnit 測試專案），逐項確認之後再改寫對應段落。

**先確認 API 簽章與可編譯性。** 所有程式碼片段是否能在實際的 `WireMock.Net.Testcontainers` 版本下編譯通過？特別注意 `CreateWireMockAdminClient()` 與 `GetPublicUrl()` 的方法名稱、`MappingModel` / `RequestModel` / `ResponseModel` 的屬性名稱、以及 `ResetMappingsAsync` 的多載與參數。順便把驗證時使用的套件版本號寫進文章，讓讀者知道適用範圍。

**確認 reset 的實際行為。** `ResetMappingsAsync()` 之後 `GetMappingsAsync()` 是否確實回傳空集合？`ResetMappingsAsync(reloadStaticMappings: true)` 與預設值的差異是否如文中所述？搭配 `.WithMappings()` 載入靜態 mapping 時，reset 後靜態 mapping 是否真的不會自動回來？

**確認 `/__admin/reset` 的實際回應。** 直接對容器打這個路徑，實際拿到的狀態碼是什麼（文中主張是 404）？打完之後 mapping 數量是否真的沒有變化？這一點是全文的核心論證，最需要實測佐證。

**驗證真正的因果鏈。** 文中對「為什麼多做一步就讓 reset 失效」的解釋是推論而非定論。建議把當時的 `ResetAsync` 原始碼找回來，確認究竟是 `EnsureSuccessStatusCode()` 拋出例外，還是外層 try/catch 吞掉例外導致後續程式碼被跳過。確認之後就可以把那段「我沒有百分之百確定的因果鏈」改寫成明確的結論。

**確認 xUnit 的生命週期行為。** 測試方法拋出例外時，`DisposeAsync` 是否確實仍會被呼叫？`InitializeAsync` 拋出例外時，對應的 `DisposeAsync` 是否確實不會被呼叫（這是孤兒 container 那段的前提）？順便確認你使用的是 xUnit v2 還是 v3，並據此保留對應的程式碼版本。

**確認集合型別的行為差異。** 文中關於 `Dictionary` 並行寫入會損壞、`ConcurrentDictionary` 允許邊列舉邊修改、`Count` 取鎖、`.Values` 回傳快照這幾點，來源是官方文件與 API 簽章，沒有實測。若要保留這些論述，建議寫一組小程式實際跑出來（並行寫入要跑夠多輪次、開夠多執行緒才容易重現）；若不想花這個成本，就把敘述改成明確引用官方文件並附上連結。

**確認計時類的數字。** 文中提到 container 啟動約一到數秒、in-process `WireMockServer` 啟動約數十毫秒、平行啟動可省下多少時間 —— 這些都應該用你自己環境的實測數字取代，並註明測試環境。

**確認 in-process 方案的細節。** `WireMockServer.Start()` 是否確實不啟用 admin 介面、必須改用 `StartWithAdminInterface(...)`？若文中要推薦這個方案，最好附上一個實際可跑的最小範例。

## 參考資料

- [WireMock.Net GitHub](https://github.com/wiremock/WireMock.Net)
- [Using WireMock.Net.Testcontainers（官方 Wiki）](https://github.com/wiremock/WireMock.Net/wiki/Using-WireMock.Net.Testcontainers)
- [WireMock.Net Admin API Reference](https://wiremock.org/dotnet/admin-api-reference/)
- [Issue #372：Reset in WireMock admin API not working fine](https://github.com/wiremock/WireMock.Net/issues/372)
- [Sharing WireMock.NET in sequential and parallel tests — Cezary Piątek](https://cezarypiatek.github.io/post/wiremock-in-parallel-tests/)
- [NuGet：WireMock.Net.Testcontainers](https://www.nuget.org/packages/WireMock.Net.Testcontainers)