using System.Net;
using AwesomeAssertions;
using WireMock.RequestBuilders;
using WireMock.ResponseBuilders;
using WireMock.Server;
using Xunit;

namespace WireMockDemo.Experiments;

/// <summary>
/// 驗證 in-process <see cref="WireMockServer"/> 的管理介面與 fluent stub API。
/// </summary>
public sealed class V8_InProcessWireMockServerTests
{
    /// <summary>
    /// 驗證一般啟動方式不會開啟管理介面。
    /// </summary>
    [Fact]
    public async Task StartWithoutAdminInterface_AdminEndpoint應回傳404()
    {
        using var server = WireMockServer.Start();

        using var httpClient = new HttpClient { BaseAddress = new Uri(server.Url!) };
        var response = await httpClient.GetAsync("/__admin/mappings", TestContext.Current.CancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    /// <summary>
    /// 驗證明確啟用管理介面後可存取 mappings 端點。
    /// </summary>
    [Fact]
    public async Task StartWithAdminInterface_AdminEndpoint應可正常存取()
    {
        using var server = WireMockServer.StartWithAdminInterface();

        using var httpClient = new HttpClient { BaseAddress = new Uri(server.Url!) };
        var response = await httpClient.GetAsync("/__admin/mappings", TestContext.Current.CancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    /// <summary>
    /// 驗證每個測試建立全新 server 時，可直接使用 fluent API 設定 stub。
    /// </summary>
    [Fact]
    public async Task 每個測試一個全新Server_使用GivenRespondWith設定Stub()
    {
        using var server = WireMockServer.Start();

        server
            .Given(Request.Create().WithPath("/api/ping").UsingGet())
            .RespondWith(Response.Create().WithStatusCode(200).WithBody("pong"));

        using var httpClient = new HttpClient { BaseAddress = new Uri(server.Url!) };
        var response = await httpClient.GetAsync("/api/ping", TestContext.Current.CancellationToken);
        var body = await response.Content.ReadAsStringAsync(TestContext.Current.CancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.OK);
        body.Should().Be("pong");
    }
}
