using System.Net;
using AwesomeAssertions;
using WireMock.Admin.Mappings;
using WireMock.Client;
using WireMock.Net.Testcontainers;
using Xunit;

namespace WireMockDemo.Experiments;

/// <summary>
/// 重現錯用 <c>/__admin/reset</c> 後，真正 mapping reset 未被執行的因果鏈。
/// </summary>
public sealed class V3_BugReproductionTests : IAsyncLifetime
{
    private WireMockContainer _container = null!;

    /// <summary>
    /// 為每個 bug 重現測試啟動一個全新的 WireMock container。
    /// </summary>
    /// <returns>代表非同步初始化作業的工作。</returns>
    public async ValueTask InitializeAsync()
    {
        _container = new WireMockContainerBuilder().Build();
        await _container.StartAsync();
    }

    /// <summary>
    /// 釋放此測試使用的 WireMock container。
    /// </summary>
    /// <returns>代表非同步清理作業的工作。</returns>
    public async ValueTask DisposeAsync() => await _container.DisposeAsync();

    /// <summary>
    /// 驗證錯誤 reset 流程在吞掉 404 例外後會留下原 mapping。
    /// </summary>
    [Fact]
    public async Task 有問題的Reset_多打一次AdminReset_Mapping會殘留()
    {
        var admin = _container.CreateWireMockAdminClient();
        await StubProbeMappingAsync(admin, TestContext.Current.CancellationToken);

        await BuggyResetAsync(_container, TestContext.Current.CancellationToken);

        var mappings = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        mappings.Should().ContainSingle();
    }

    /// <summary>
    /// 驗證只使用官方 admin client 時 mapping 會被正確清除。
    /// </summary>
    [Fact]
    public async Task 正確的Reset_只呼叫ResetMappingsAsync_Mapping會清空()
    {
        var admin = _container.CreateWireMockAdminClient();
        await StubProbeMappingAsync(admin, TestContext.Current.CancellationToken);

        await admin.ResetMappingsAsync(cancellationToken: TestContext.Current.CancellationToken);

        var mappings = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        mappings.Should().BeEmpty();
    }

    /// <summary>
    /// 驗證對 404 回應呼叫 <c>EnsureSuccessStatusCode</c> 會拋出包含狀態碼的例外。
    /// </summary>
    [Fact]
    public async Task 有問題的Reset_因果鏈_EnsureSuccessStatusCode應拋出HttpRequestException()
    {
        using var httpClient = _container.CreateClient();

        var act = async () =>
        {
            using var response = await httpClient.PostAsync("/__admin/reset", null, TestContext.Current.CancellationToken);
            response.EnsureSuccessStatusCode();
        };

        var assertion = await act.Should().ThrowAsync<HttpRequestException>();
        assertion.Which.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    /// <summary>
    /// 建立供 reset 行為檢查使用的最小 mapping。
    /// </summary>
    /// <param name="admin">WireMock 管理 API client。</param>
    /// <param name="cancellationToken">取消建立 mapping 作業的權杖。</param>
    /// <returns>代表非同步建立 mapping 作業的工作。</returns>
    private static Task StubProbeMappingAsync(IWireMockAdminApi admin, CancellationToken cancellationToken) =>
        admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel { Path = "/api/probe", Methods = new[] { "GET" } },
            Response = new ResponseModel { StatusCode = 200 },
        }, cancellationToken);

    /// <summary>
    /// 模擬先呼叫不存在的 reset 路徑，再嘗試呼叫正式 reset 的錯誤流程。
    /// </summary>
    /// <param name="container">要操作的 WireMock container。</param>
    /// <param name="cancellationToken">取消非同步作業的權杖。</param>
    /// <returns>代表非同步錯誤 reset 流程的工作。</returns>
    private static async Task BuggyResetAsync(WireMockContainer container, CancellationToken cancellationToken)
    {
        try
        {
            using var httpClient = container.CreateClient();
            var response = await httpClient.PostAsync("/__admin/reset", null, cancellationToken);
            response.EnsureSuccessStatusCode();

            // 如果上面這行拋出例外，下面這行就永遠不會執行——
            // 這正是原始 bug 的因果鏈：不是 reset 失效，而是根本沒跑到。
            var admin = container.CreateWireMockAdminClient();
            await admin.ResetMappingsAsync(cancellationToken: cancellationToken);
        }
        catch (HttpRequestException)
        {
            // 這裡吞掉例外只是為了讓測試能繼續往下檢查 mapping 的殘留狀態；
            // 不代表原始程式碼真的有這個 catch。例外本身的型別與內容
            // 由另一個測試（因果鏈）獨立驗證。
        }
    }
}
