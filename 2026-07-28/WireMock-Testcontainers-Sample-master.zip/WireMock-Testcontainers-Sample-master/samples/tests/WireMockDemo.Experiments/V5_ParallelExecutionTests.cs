using Xunit;

namespace WireMockDemo.Experiments;

/// <summary>
/// 將測試類別的執行區間寫入 CSV，供平行執行行為分析。
/// </summary>
internal static class V5_TimestampLog
{
    private static readonly object FileLock = new();

    /// <summary>
    /// 取得時間戳記 CSV 的輸出路徑。
    /// </summary>
    public static readonly string LogFilePath =
        Path.Combine(AppContext.BaseDirectory, "V5Log", "timestamps.csv");

    /// <summary>
    /// 以 thread-safe 方式附加一筆測試執行區間。
    /// </summary>
    /// <param name="className">測試類別名稱。</param>
    /// <param name="startUnixMs">開始時間的 Unix 毫秒值。</param>
    /// <param name="endUnixMs">結束時間的 Unix 毫秒值。</param>
    public static void Append(string className, long startUnixMs, long endUnixMs)
    {
        lock (FileLock)
        {
            var directory = Path.GetDirectoryName(LogFilePath)!;
            Directory.CreateDirectory(directory);
            File.AppendAllText(LogFilePath, $"{className},{startUnixMs},{endUnixMs}{Environment.NewLine}");
        }
    }
}

/// <summary>
/// 定義用來驗證同 collection 序列執行的 xUnit test collection。
/// </summary>
[CollectionDefinition(Name)]
public sealed class V5SameCollection
{
    /// <summary>
    /// 平行執行實驗使用的 collection 名稱。
    /// </summary>
    public const string Name = "V5Same";
}

/// <summary>
/// 同 collection 序列執行實驗的第一個測試類別。
/// </summary>
[Collection(V5SameCollection.Name)]
public sealed class V5_SameCollection_ClassA
{
    /// <summary>
    /// 等待固定時間並記錄執行區間。
    /// </summary>
    [Fact]
    public async Task 執行並記錄時間戳記()
    {
        var start = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        await Task.Delay(300, TestContext.Current.CancellationToken);
        var end = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        V5_TimestampLog.Append(nameof(V5_SameCollection_ClassA), start, end);
    }
}

/// <summary>
/// 同 collection 序列執行實驗的第二個測試類別。
/// </summary>
[Collection(V5SameCollection.Name)]
public sealed class V5_SameCollection_ClassB
{
    /// <summary>
    /// 等待固定時間並記錄執行區間。
    /// </summary>
    [Fact]
    public async Task 執行並記錄時間戳記()
    {
        var start = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        await Task.Delay(300, TestContext.Current.CancellationToken);
        var end = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        V5_TimestampLog.Append(nameof(V5_SameCollection_ClassB), start, end);
    }
}

/// <summary>
/// 未指定 collection 的第一個平行執行對照類別。
/// </summary>
public sealed class V5_NoCollection_ClassC
{
    /// <summary>
    /// 等待固定時間並記錄執行區間。
    /// </summary>
    [Fact]
    public async Task 執行並記錄時間戳記()
    {
        var start = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        await Task.Delay(300, TestContext.Current.CancellationToken);
        var end = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        V5_TimestampLog.Append(nameof(V5_NoCollection_ClassC), start, end);
    }
}

/// <summary>
/// 未指定 collection 的第二個平行執行對照類別。
/// </summary>
public sealed class V5_NoCollection_ClassD
{
    /// <summary>
    /// 等待固定時間並記錄執行區間。
    /// </summary>
    [Fact]
    public async Task 執行並記錄時間戳記()
    {
        var start = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        await Task.Delay(300, TestContext.Current.CancellationToken);
        var end = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        V5_TimestampLog.Append(nameof(V5_NoCollection_ClassD), start, end);
    }
}
