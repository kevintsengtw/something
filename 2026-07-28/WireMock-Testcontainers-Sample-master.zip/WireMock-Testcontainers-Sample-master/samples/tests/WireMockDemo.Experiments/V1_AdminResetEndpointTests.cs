using System.Net;
using AwesomeAssertions;
using WireMock.Admin.Mappings;
using WireMock.Net.Testcontainers;
using Xunit;

namespace WireMockDemo.Experiments;

/// <summary>
/// 驗證 WireMock.Net 對 Java WireMock 的 <c>/__admin/reset</c> 路徑如何回應。
/// </summary>
public sealed class V1_AdminResetEndpointTests : IAsyncLifetime
{
    private WireMockContainer _container = null!;

    /// <summary>
    /// 為每個實驗測試啟動一個全新的 WireMock container。
    /// </summary>
    /// <returns>代表非同步初始化作業的工作。</returns>
    public async ValueTask InitializeAsync()
    {
        _container = new WireMockContainerBuilder().Build();
        await _container.StartAsync();
    }

    /// <summary>
    /// 釋放此測試使用的 WireMock container。
    /// </summary>
    /// <returns>代表非同步清理作業的工作。</returns>
    public async ValueTask DisposeAsync() => await _container.DisposeAsync();

    /// <summary>
    /// 驗證不存在的 reset 路徑回傳 404，且不會修改既有 mapping。
    /// </summary>
    [Fact]
    public async Task PostAdminReset_應回傳404且對Mapping數量無副作用()
    {
        var admin = _container.CreateWireMockAdminClient();
        await admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel { Path = "/api/probe", Methods = new[] { "GET" } },
            Response = new ResponseModel { StatusCode = 200 },
        }, TestContext.Current.CancellationToken);

        var beforeCount = (await admin.GetMappingsAsync(TestContext.Current.CancellationToken)).Count;

        using var httpClient = _container.CreateClient();
        var response = await httpClient.PostAsync("/__admin/reset", null, TestContext.Current.CancellationToken);

        var afterCount = (await admin.GetMappingsAsync(TestContext.Current.CancellationToken)).Count;

        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
        afterCount.Should().Be(beforeCount);
    }
}
