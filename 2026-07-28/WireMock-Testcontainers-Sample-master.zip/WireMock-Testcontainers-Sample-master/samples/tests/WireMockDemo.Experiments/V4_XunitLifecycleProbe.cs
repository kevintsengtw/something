using Xunit;

namespace WireMockDemo.Experiments;

/// <summary>
/// 管理 xUnit 非同步生命週期探測所使用的 marker 檔案。
/// </summary>
internal static class V4_MarkerFiles
{
    private static readonly string OutputDirectory =
        Path.Combine(AppContext.BaseDirectory, "LifecycleProbeOutput");

    /// <summary>
    /// 測試方法拋出例外情境所使用的 marker 路徑。
    /// </summary>
    public static readonly string TestMethodThrowsMarker =
        Path.Combine(OutputDirectory, "test-method-throws.marker");

    /// <summary>
    /// 初始化拋出例外情境所使用的 marker 路徑。
    /// </summary>
    public static readonly string InitializeThrowsMarker =
        Path.Combine(OutputDirectory, "initialize-throws.marker");

    /// <summary>
    /// 寫入代表 <c>DisposeAsync</c> 已執行的 marker。
    /// </summary>
    /// <param name="path">marker 檔案路徑。</param>
    public static void WriteMarker(string path)
    {
        Directory.CreateDirectory(OutputDirectory);
        File.WriteAllText(path, "disposed");
    }

    /// <summary>
    /// 刪除前一次探測可能留下的 marker。
    /// </summary>
    /// <param name="path">marker 檔案路徑。</param>
    public static void DeleteMarker(string path)
    {
        if (File.Exists(path))
        {
            File.Delete(path);
        }
    }
}

/// <summary>
/// 探測測試方法失敗後，xUnit 是否仍會呼叫 <c>DisposeAsync</c>。
/// </summary>
[Trait("Category", "LifecycleProbe")]
public sealed class V4_TestMethodThrows_DisposeAsyncStillRunsProbe : IAsyncLifetime
{
    /// <summary>
    /// 清除舊 marker，確保本次探測結果不受前次執行影響。
    /// </summary>
    /// <returns>已完成的非同步初始化作業。</returns>
    public ValueTask InitializeAsync()
    {
        V4_MarkerFiles.DeleteMarker(V4_MarkerFiles.TestMethodThrowsMarker);
        return ValueTask.CompletedTask;
    }

    /// <summary>
    /// 寫入 marker，表示測試失敗後仍進入清理階段。
    /// </summary>
    /// <returns>已完成的非同步清理作業。</returns>
    public ValueTask DisposeAsync()
    {
        V4_MarkerFiles.WriteMarker(V4_MarkerFiles.TestMethodThrowsMarker);
        return ValueTask.CompletedTask;
    }

    /// <summary>
    /// 刻意拋出例外，以觀察 xUnit 是否仍執行清理。
    /// </summary>
    [Fact(Explicit = true)]
    public Task 測試方法拋出例外_探測DisposeAsync是否仍會被呼叫()
    {
        throw new InvalidOperationException("刻意拋出的例外，用來驗證 DisposeAsync 是否仍會被呼叫。");
    }
}

/// <summary>
/// 探測 <c>InitializeAsync</c> 失敗時，xUnit 是否略過對應的 <c>DisposeAsync</c>。
/// </summary>
[Trait("Category", "LifecycleProbe")]
public sealed class V4_InitializeAsyncThrows_DisposeAsyncDoesNotRunProbe : IAsyncLifetime
{
    /// <summary>
    /// 清除舊 marker 後刻意拋出例外，中止測試初始化。
    /// </summary>
    /// <returns>此方法不會正常完成。</returns>
    public ValueTask InitializeAsync()
    {
        V4_MarkerFiles.DeleteMarker(V4_MarkerFiles.InitializeThrowsMarker);
        throw new InvalidOperationException("刻意拋出的例外，用來驗證 InitializeAsync 失敗時 DisposeAsync 是否不會被呼叫。");
    }

    /// <summary>
    /// 若被呼叫則寫入 marker，用來偵測與預期不符的生命週期行為。
    /// </summary>
    /// <returns>已完成的非同步清理作業。</returns>
    public ValueTask DisposeAsync()
    {
        V4_MarkerFiles.WriteMarker(V4_MarkerFiles.InitializeThrowsMarker);
        return ValueTask.CompletedTask;
    }

    /// <summary>
    /// 提供 xUnit 可發現的測試方法；正常情況下不會執行到方法主體。
    /// </summary>
    [Fact(Explicit = true)]
    public Task 這個測試方法理論上不會被執行到()
    {
        // InitializeAsync 已經拋例外，xUnit 不會走到這裡；
        // 留著只是滿足類別需要至少一個 [Fact] 才會被 xUnit 發現並嘗試建立實例。
        return Task.CompletedTask;
    }
}
