using AwesomeAssertions;
using WireMock.Admin.Mappings;
using WireMock.Net.Testcontainers;
using Xunit;

namespace WireMockDemo.Experiments;

/// <summary>
/// 驗證 mappings 與 request log 各自對應的 WireMock reset 行為。
/// </summary>
public sealed class V2_ResetBehaviorTests : IAsyncLifetime
{
    private WireMockContainer _container = null!;

    /// <summary>
    /// 為每個 reset 行為測試啟動一個全新的 WireMock container。
    /// </summary>
    /// <returns>代表非同步初始化作業的工作。</returns>
    public async ValueTask InitializeAsync()
    {
        _container = new WireMockContainerBuilder().Build();
        await _container.StartAsync();
    }

    /// <summary>
    /// 釋放此測試使用的 WireMock container。
    /// </summary>
    /// <returns>代表非同步清理作業的工作。</returns>
    public async ValueTask DisposeAsync() => await _container.DisposeAsync();

    /// <summary>
    /// 驗證 <c>ResetMappingsAsync</c> 會移除動態建立的 mapping。
    /// </summary>
    [Fact]
    public async Task ResetMappingsAsync_應清空所有動態Mapping()
    {
        var admin = _container.CreateWireMockAdminClient();
        await admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel { Path = "/api/probe", Methods = new[] { "GET" } },
            Response = new ResponseModel { StatusCode = 200 },
        }, TestContext.Current.CancellationToken);

        await admin.ResetMappingsAsync(cancellationToken: TestContext.Current.CancellationToken);

        var mappings = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        mappings.Should().BeEmpty();
    }

    /// <summary>
    /// 驗證 <c>ResetRequestsAsync</c> 只清除 request log，不會移除 mapping。
    /// </summary>
    [Fact]
    public async Task ResetRequestsAsync_只清RequestLog_不影響Mapping()
    {
        var admin = _container.CreateWireMockAdminClient();
        await admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel { Path = "/api/probe", Methods = new[] { "GET" } },
            Response = new ResponseModel { StatusCode = 200 },
        }, TestContext.Current.CancellationToken);

        using var httpClient = _container.CreateClient();
        await httpClient.GetAsync("/api/probe", TestContext.Current.CancellationToken);

        await admin.ResetRequestsAsync(TestContext.Current.CancellationToken);

        var mappings = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        var requests = await admin.GetRequestsAsync(TestContext.Current.CancellationToken);

        mappings.Should().ContainSingle();
        requests.Should().BeEmpty();
    }
}

/// <summary>
/// 驗證重置後是否重新載入由檔案提供的靜態 mappings。
/// </summary>
public sealed class V2_StaticMappingReloadTests : IAsyncLifetime
{
    private static readonly string StaticMappingsPath =
        Path.Combine(AppContext.BaseDirectory, "TestData", "StaticMappings");

    private WireMockContainer _container = null!;

    /// <summary>
    /// 啟動一個已掛載靜態 mapping 目錄的 WireMock container。
    /// </summary>
    /// <returns>代表非同步初始化作業的工作。</returns>
    public async ValueTask InitializeAsync()
    {
        _container = new WireMockContainerBuilder()
            .WithMappings(StaticMappingsPath)
            .Build();
        await _container.StartAsync();
    }

    /// <summary>
    /// 釋放此測試使用的 WireMock container。
    /// </summary>
    /// <returns>代表非同步清理作業的工作。</returns>
    public async ValueTask DisposeAsync() => await _container.DisposeAsync();

    /// <summary>
    /// 驗證預設 reset 會移除靜態 mapping，且不會自動重新載入。
    /// </summary>
    [Fact]
    public async Task ResetMappingsAsync預設_靜態Mapping不會自動回來()
    {
        var admin = _container.CreateWireMockAdminClient();

        var beforeReset = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        beforeReset.Should().ContainSingle();

        await admin.ResetMappingsAsync(cancellationToken: TestContext.Current.CancellationToken);

        var afterReset = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        afterReset.Should().BeEmpty();
    }

    /// <summary>
    /// 驗證指定重新載入時，靜態 mapping 會在 reset 後恢復。
    /// </summary>
    [Fact]
    public async Task ResetMappingsAsyncReloadStaticMappingsTrue_靜態Mapping會重新載入()
    {
        var admin = _container.CreateWireMockAdminClient();

        await admin.ResetMappingsAsync(reloadStaticMappings: true, cancellationToken: TestContext.Current.CancellationToken);

        var mappings = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        mappings.Should().ContainSingle();
    }
}
