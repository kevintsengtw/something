using System.Diagnostics;
using System.Runtime.InteropServices;
using WireMock.Net.Testcontainers;
using WireMock.Server;
using Xunit;

namespace WireMockDemo.Experiments;

/// <summary>
/// 量測 WireMock container 與 in-process server 的啟動時間。
/// </summary>
/// <remarks>
/// 這些數字只用於記錄特定測試環境，不應視為通用效能保證。
/// </remarks>
[Trait("Category", "TimingBenchmark")]
public sealed class V7_TimingBenchmarkTests
{
    private const int Repetitions = 5;

    /// <summary>
    /// 重複啟動單一 container 並輸出排序後的時間與中位數。
    /// </summary>
    [Fact]
    public async Task 單一Container啟動耗時_5次取中位數()
    {
        var durations = new List<double>();

        for (var i = 0; i < Repetitions; i++)
        {
            var stopwatch = Stopwatch.StartNew();
            await using var container = new WireMockContainerBuilder().Build();
            await container.StartAsync(TestContext.Current.CancellationToken);
            stopwatch.Stop();
            durations.Add(stopwatch.Elapsed.TotalMilliseconds);
        }

        LogDurations("單一 container 啟動耗時", durations);
    }

    /// <summary>
    /// 比較三個 containers 循序啟動與平行啟動的時間。
    /// </summary>
    [Fact]
    public async Task 三個Container循序vs平行啟動耗時比較_5次取中位數()
    {
        var sequentialDurations = new List<double>();
        for (var i = 0; i < Repetitions; i++)
        {
            var stopwatch = Stopwatch.StartNew();
            await using var c1 = new WireMockContainerBuilder().Build();
            await using var c2 = new WireMockContainerBuilder().Build();
            await using var c3 = new WireMockContainerBuilder().Build();
            await c1.StartAsync(TestContext.Current.CancellationToken);
            await c2.StartAsync(TestContext.Current.CancellationToken);
            await c3.StartAsync(TestContext.Current.CancellationToken);
            stopwatch.Stop();
            sequentialDurations.Add(stopwatch.Elapsed.TotalMilliseconds);
        }

        var parallelDurations = new List<double>();
        for (var i = 0; i < Repetitions; i++)
        {
            var stopwatch = Stopwatch.StartNew();
            await using var c1 = new WireMockContainerBuilder().Build();
            await using var c2 = new WireMockContainerBuilder().Build();
            await using var c3 = new WireMockContainerBuilder().Build();
            await Task.WhenAll(
                c1.StartAsync(TestContext.Current.CancellationToken),
                c2.StartAsync(TestContext.Current.CancellationToken),
                c3.StartAsync(TestContext.Current.CancellationToken));
            stopwatch.Stop();
            parallelDurations.Add(stopwatch.Elapsed.TotalMilliseconds);
        }

        LogDurations("三個 container 循序啟動", sequentialDurations);
        LogDurations("三個 container 平行啟動", parallelDurations);
    }

    /// <summary>
    /// 重複啟動 in-process WireMock server 並輸出中位數。
    /// </summary>
    [Fact]
    public void InProcessWireMockServer啟動耗時_5次取中位數()
    {
        var durations = new List<double>();

        for (var i = 0; i < Repetitions; i++)
        {
            var stopwatch = Stopwatch.StartNew();
            using var server = WireMockServer.Start();
            stopwatch.Stop();
            durations.Add(stopwatch.Elapsed.TotalMilliseconds);
            server.Stop();
        }

        LogDurations("in-process WireMockServer 啟動耗時", durations);
    }

    /// <summary>
    /// 記錄作業系統、CPU、.NET runtime 與 Docker 版本。
    /// </summary>
    [Fact]
    public void 記錄測試環境資訊()
    {
        var dockerVersion = GetDockerVersion();

        TestContext.Current.TestOutputHelper?.WriteLine($"OS：{RuntimeInformation.OSDescription}");
        TestContext.Current.TestOutputHelper?.WriteLine($"CPU 核心數：{Environment.ProcessorCount}");
        TestContext.Current.TestOutputHelper?.WriteLine($".NET Runtime：{RuntimeInformation.FrameworkDescription}");
        TestContext.Current.TestOutputHelper?.WriteLine($"Docker：{dockerVersion}");
    }

    /// <summary>
    /// 將量測結果排序並輸出中位數。
    /// </summary>
    /// <param name="label">量測項目的顯示名稱。</param>
    /// <param name="durations">以毫秒表示的量測結果。</param>
    private static void LogDurations(string label, List<double> durations)
    {
        var sorted = durations.OrderBy(d => d).ToList();
        var median = sorted[sorted.Count / 2];
        TestContext.Current.TestOutputHelper?.WriteLine(
            $"{label}（{sorted.Count} 次）：{string.Join(", ", sorted.Select(d => $"{d:F0}ms"))}，中位數：{median:F0}ms");
    }

    /// <summary>
    /// 取得目前環境的 Docker CLI 版本文字。
    /// </summary>
    /// <returns>Docker 版本；無法執行 CLI 時回傳錯誤說明。</returns>
    private static string GetDockerVersion()
    {
        try
        {
            var startInfo = new ProcessStartInfo("docker", "--version")
            {
                RedirectStandardOutput = true,
                UseShellExecute = false,
            };
            using var process = Process.Start(startInfo);
            var output = process!.StandardOutput.ReadToEnd().Trim();
            process.WaitForExit();
            return output;
        }
        catch (Exception exception)
        {
            return $"無法取得（{exception.Message}）";
        }
    }
}
