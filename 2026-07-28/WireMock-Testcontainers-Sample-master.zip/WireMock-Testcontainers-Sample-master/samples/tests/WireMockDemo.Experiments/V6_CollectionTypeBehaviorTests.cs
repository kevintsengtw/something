using System.Collections.Concurrent;
using AwesomeAssertions;
using Xunit;

namespace WireMockDemo.Experiments;

/// <summary>
/// 比較 <see cref="Dictionary{TKey,TValue}"/> 與
/// <see cref="ConcurrentDictionary{TKey,TValue}"/> 的並行與列舉行為。
/// </summary>
public sealed class V6_CollectionTypeBehaviorTests
{
    /// <summary>
    /// 重複執行多執行緒寫入，記錄例外、逾時與資料數量異常。
    /// </summary>
    [Fact]
    public void 並行寫入Dictionary_1000輪x16執行緒_統計失敗率與逾時次數()
    {
        const int rounds = 1000;
        const int threadCount = 16;
        var failureCount = 0;
        var timeoutCount = 0;
        var silentCorruptionCount = 0;
        var exceptionTypeCounts = new ConcurrentDictionary<string, int>();

        for (var round = 0; round < rounds; round++)
        {
            var dictionary = new Dictionary<int, int>();
            var threads = new Thread[threadCount];

            for (var t = 0; t < threadCount; t++)
            {
                var key = t;
                threads[t] = new Thread(() =>
                {
                    try
                    {
                        dictionary[key] = key;
                    }
                    catch (Exception exception)
                    {
                        Interlocked.Increment(ref failureCount);
                        exceptionTypeCounts.AddOrUpdate(exception.GetType().Name, 1, (_, count) => count + 1);
                    }
                })
                {
                    IsBackground = true,
                };
                threads[t].Start();
            }

            var allJoined = true;
            foreach (var thread in threads)
            {
                if (!thread.Join(TimeSpan.FromMilliseconds(500)))
                {
                    allJoined = false;
                }
            }

            if (!allJoined)
            {
                timeoutCount++;
                continue;
            }

            if (dictionary.Count != threadCount)
            {
                silentCorruptionCount++;
            }
        }

        TestContext.Current.TestOutputHelper?.WriteLine($"並行寫入 Dictionary：{rounds} 輪 x {threadCount} 執行緒");
        TestContext.Current.TestOutputHelper?.WriteLine($"  例外失敗次數：{failureCount}");
        TestContext.Current.TestOutputHelper?.WriteLine($"  疑似逾時（執行緒卡住超過 500ms）輪數：{timeoutCount}");
        TestContext.Current.TestOutputHelper?.WriteLine($"  無例外但 key 數量不對（靜默損壞）輪數：{silentCorruptionCount}");
        foreach (var (type, count) in exceptionTypeCounts)
        {
            TestContext.Current.TestOutputHelper?.WriteLine($"  例外型別 {type}：{count} 次");
        }
    }

    /// <summary>
    /// 驗證一般 Dictionary 在列舉期間被修改時會拋出例外。
    /// </summary>
    [Fact]
    public void Dictionary列舉中被修改_應拋出InvalidOperationException()
    {
        var dictionary = new Dictionary<int, int> { [1] = 1, [2] = 2 };

        var act = () =>
        {
            foreach (var _ in dictionary)
            {
                dictionary[3] = 3;
            }
        };

        act.Should().Throw<InvalidOperationException>();
    }

    /// <summary>
    /// 驗證 ConcurrentDictionary 允許在列舉期間進行修改。
    /// </summary>
    [Fact]
    public void ConcurrentDictionary列舉中被修改_不會拋出例外()
    {
        var dictionary = new ConcurrentDictionary<int, int>(new Dictionary<int, int> { [1] = 1, [2] = 2 });

        var act = () =>
        {
            foreach (var _ in dictionary)
            {
                dictionary[3] = 3;
            }
        };

        act.Should().NotThrow();
    }

    /// <summary>
    /// 驗證已具體化的 values 清單不會隨原字典後續修改而改變。
    /// </summary>
    [Fact]
    public void ConcurrentDictionaryValues_具體化後修改字典_具體化的List不受影響()
    {
        var dictionary = new ConcurrentDictionary<int, int> { [1] = 1, [2] = 2 };

        var materializedValues = dictionary.Values.ToList();
        dictionary[3] = 3;

        materializedValues.Should().HaveCount(2);
        materializedValues.Should().BeEquivalentTo(new[] { 1, 2 });
    }

    /// <summary>
    /// 驗證每次存取 ConcurrentDictionary.Values 都會取得新的內容快照。
    /// </summary>
    [Fact]
    public void ConcurrentDictionaryValues_每次呼叫都是新的快照()
    {
        var dictionary = new ConcurrentDictionary<int, int> { [1] = 1 };

        var firstSnapshot = dictionary.Values;
        dictionary[2] = 2;
        var secondSnapshot = dictionary.Values;

        firstSnapshot.Should().HaveCount(1);
        secondSnapshot.Should().HaveCount(2);
    }
}
