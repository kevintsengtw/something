using Xunit;

namespace WireMockDemo.IntegrationTests.Infrastructure;

/// <summary>
/// 提供共用 WireMock fixture 與每個測試執行前的狀態重置。
/// </summary>
[Collection(WireMockCollection.Name)]
public abstract class WireMockTestBase : IAsyncLifetime
{
    /// <summary>
    /// 取得目前 test collection 共用的 WireMock fixture。
    /// </summary>
    protected readonly WireMockFixture Fixture;

    /// <summary>
    /// 初始化測試基底類別。
    /// </summary>
    /// <param name="fixture">目前 collection 共用的 WireMock fixture。</param>
    protected WireMockTestBase(WireMockFixture fixture)
    {
        Fixture = fixture;
    }

    // 注意：放在 InitializeAsync（測試前），不是 DisposeAsync（測試後）——
    // 每個測試自己保證起點乾淨，不依賴「上一個測試有沒有正確收尾」。
    /// <summary>
    /// 在每個測試方法執行前清除所有 WireMock 狀態。
    /// </summary>
    /// <returns>代表非同步初始化作業的工作。</returns>
    public async ValueTask InitializeAsync() =>
        await Fixture.ResetAllAsync(TestContext.Current.CancellationToken);

    /// <summary>
    /// 完成單一測試的清理；共用 fixture 由 xUnit 在 collection 結束時釋放。
    /// </summary>
    /// <returns>已完成的非同步清理作業。</returns>
    public ValueTask DisposeAsync() => default;
}
