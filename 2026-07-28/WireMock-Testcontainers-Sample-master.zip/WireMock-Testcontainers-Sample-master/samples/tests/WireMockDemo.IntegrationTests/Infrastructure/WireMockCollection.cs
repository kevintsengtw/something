using Xunit;

namespace WireMockDemo.IntegrationTests.Infrastructure;

/// <summary>
/// 定義共用 <see cref="WireMockFixture"/> 的 xUnit test collection。
/// </summary>
[CollectionDefinition(Name)]
public sealed class WireMockCollection : ICollectionFixture<WireMockFixture>
{
    /// <summary>
    /// WireMock 整合測試 collection 的唯一名稱。
    /// </summary>
    public const string Name = "wiremock";
}
