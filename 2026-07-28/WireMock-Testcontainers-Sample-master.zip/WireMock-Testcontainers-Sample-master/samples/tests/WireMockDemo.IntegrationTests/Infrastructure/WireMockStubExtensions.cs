using WireMock.Admin.Mappings;
using WireMock.Client;

namespace WireMockDemo.IntegrationTests.Infrastructure;

/// <summary>
/// 提供整合測試建立 WireMock JSON stub 的便利方法。
/// </summary>
public static class WireMockStubExtensions
{
    /// <summary>
    /// 建立一筆依 HTTP method 與 path 比對並回傳 JSON 的動態 mapping。
    /// </summary>
    /// <param name="admin">目標 WireMock 服務的管理 API client。</param>
    /// <param name="method">要比對的 HTTP method。</param>
    /// <param name="path">要比對的請求 path。</param>
    /// <param name="statusCode">stub 回傳的 HTTP 狀態碼。</param>
    /// <param name="body">要序列化成 JSON 的回應內容。</param>
    /// <param name="cancellationToken">取消建立 mapping 作業的權杖。</param>
    /// <returns>代表非同步建立 mapping 作業的工作。</returns>
    public static Task StubJsonAsync(
        this IWireMockAdminApi admin,
        string method,
        string path,
        int statusCode,
        object body,
        CancellationToken cancellationToken = default)
    {
        // 不指定 Guid：讓每次都是全新的 mapping。
        // 測試中的動態 mapping 不需要寫入磁碟。
        return admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel
            {
                Path = path,
                Methods = new[] { method },
            },
            Response = new ResponseModel
            {
                StatusCode = statusCode,
                Headers = new Dictionary<string, object> { ["Content-Type"] = "application/json" },
                BodyAsJson = body,
            },
        }, cancellationToken);
    }
}
