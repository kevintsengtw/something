using System.Collections.Concurrent;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using WireMock.Client;
using WireMock.Net.Testcontainers;
using Xunit;

namespace WireMockDemo.IntegrationTests.Infrastructure;

/// <summary>
/// 管理整組整合測試共用的 WireMock containers 與 ASP.NET Core 測試主機。
/// </summary>
/// <remarks>
/// 每個外部服務各使用一個 container，並透過 xUnit Collection Fixture
/// 在多個測試類別之間共用。每個測試開始前應呼叫 <see cref="ResetAllAsync"/>。
/// </remarks>
public sealed class WireMockFixture : IAsyncLifetime
{
    private static readonly string[] Services =
    {
        WireMockServices.OpenAccountApi,
        WireMockServices.IdentityApi,
        WireMockServices.PaymentApi,
    };

    private readonly ConcurrentDictionary<string, WireMockContainer> _containers = new();
    private readonly ConcurrentDictionary<string, IWireMockAdminApi> _admins = new();
    private readonly ConcurrentDictionary<string, string> _baseUrls = new();

    private bool _disposed;

    /// <summary>
    /// 取得已注入動態 WireMock 位址的 ASP.NET Core 測試應用程式工廠。
    /// </summary>
    public WebApplicationFactory<Program> Factory { get; private set; } = null!;

    /// <summary>
    /// 平行啟動所有 WireMock containers，並建立測試應用程式工廠。
    /// </summary>
    /// <returns>代表非同步初始化作業的工作。</returns>
    public async ValueTask InitializeAsync()
    {
        try
        {
            await Task.WhenAll(Services.Select(StartAsync));
        }
        catch
        {
            // Task.WhenAll 只會拋出第一個例外，此時可能已經有部分 container 成功啟動。
            // InitializeAsync 拋例外時 xUnit 不會呼叫 DisposeAsync，所以要自己釋放，避免孤兒 container。
            await DisposeAsync();
            throw;
        }

        Factory = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
        {
            builder.ConfigureAppConfiguration((_, configurationBuilder) =>
            {
                configurationBuilder.AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["ExternalServices:OpenAccountApi:BaseUrl"] = BaseUrl(WireMockServices.OpenAccountApi),
                    ["ExternalServices:IdentityApi:BaseUrl"] = BaseUrl(WireMockServices.IdentityApi),
                    ["ExternalServices:PaymentApi:BaseUrl"] = BaseUrl(WireMockServices.PaymentApi),
                });
            });
        });
    }

    /// <summary>
    /// 啟動指定服務的 WireMock container，並註冊其 admin client 與公開位址。
    /// </summary>
    /// <param name="serviceName">要啟動的服務名稱。</param>
    private async Task StartAsync(string serviceName)
    {
        var container = new WireMockContainerBuilder().Build();
        try
        {
            await container.StartAsync();
        }
        catch
        {
            // 啟動失敗的 container 尚未加入 _containers，外層 DisposeAsync 清不到它。
            await container.DisposeAsync();
            throw;
        }

        _containers[serviceName] = container;
        _admins[serviceName] = container.CreateWireMockAdminClient();
        _baseUrls[serviceName] = container.GetPublicUrl();
    }

    /// <summary>
    /// 取得指定 WireMock 服務可由測試主機存取的公開位址。
    /// </summary>
    /// <param name="serviceName">服務名稱。</param>
    /// <returns>WireMock 服務的 base URL。</returns>
    public string BaseUrl(string serviceName) => _baseUrls[serviceName];

    /// <summary>
    /// 取得指定 WireMock 服務的管理 API client。
    /// </summary>
    /// <param name="serviceName">服務名稱。</param>
    /// <returns>可設定與重置該服務的管理 API client。</returns>
    public IWireMockAdminApi Admin(string serviceName) => _admins[serviceName];

    /// <summary>
    /// 清除所有 WireMock 服務的動態 mappings 與 request logs。
    /// </summary>
    /// <param name="cancellationToken">取消非同步重置作業的權杖。</param>
    /// <returns>代表非同步重置作業的工作。</returns>
    /// <exception cref="InvalidOperationException">任一服務在重置後仍殘留 mapping。</exception>
    public async Task ResetAllAsync(CancellationToken cancellationToken = default)
    {
        foreach (var (name, admin) in _admins)
        {
            await admin.ResetMappingsAsync(cancellationToken: cancellationToken);
            await admin.ResetRequestsAsync(cancellationToken);

            var remaining = await admin.GetMappingsAsync(cancellationToken);
            if (remaining.Count != 0)
            {
                throw new InvalidOperationException(
                    $"[{name}] reset 後仍殘留 {remaining.Count} 筆 mapping：" +
                    string.Join(", ", remaining.Select(m => $"{m.Guid}:{m.Request?.Path}")));
            }
        }
    }

    /// <summary>
    /// 釋放測試應用程式工廠與所有已啟動的 WireMock containers。
    /// </summary>
    /// <returns>代表非同步清理作業的工作。</returns>
    public async ValueTask DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;

        if (Factory is not null)
        {
            await Factory.DisposeAsync();
        }

        await Task.WhenAll(_containers.Values.Select(c => c.DisposeAsync().AsTask()));
    }
}
