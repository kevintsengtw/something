using System.Linq;
using System.Net;
using System.Net.Http.Json;
using AwesomeAssertions;
using Xunit;

namespace WireMockDemo.IntegrationTests.Infrastructure;

/// <summary>
/// 驗證 <see cref="WireMockFixture"/> 本身的啟動、連線與重置能力。
/// </summary>
public sealed class WireMockFixtureTests : IClassFixture<WireMockFixture>
{
    private readonly WireMockFixture _fixture;

    /// <summary>
    /// 初始化 fixture 基礎設施測試。
    /// </summary>
    /// <param name="fixture">此測試類別共用的 WireMock fixture。</param>
    public WireMockFixtureTests(WireMockFixture fixture)
    {
        _fixture = fixture;
    }

    /// <summary>
    /// 驗證三個 WireMock containers 具有不同位址，且管理端點皆可連線。
    /// </summary>
    [Fact]
    public async Task 三個容器啟動後_應提供互不相同且可連線的端點()
    {
        var serviceNames = new[] { WireMockServices.OpenAccountApi, WireMockServices.IdentityApi, WireMockServices.PaymentApi };
        var urls = serviceNames.Select(_fixture.BaseUrl).ToArray();

        urls.Should().OnlyHaveUniqueItems();

        foreach (var serviceName in serviceNames)
        {
            var health = await _fixture.Admin(serviceName).GetHealthAsync(TestContext.Current.CancellationToken);
            health.Should().Be("Healthy");
        }
    }

    /// <summary>
    /// 驗證透過 helper 建立的 mapping 可由對應服務實際回傳。
    /// </summary>
    [Fact]
    public async Task StubJsonAsync下的Mapping_應能透過該服務的HttpClient實際取得回應()
    {
        var cancellationToken = TestContext.Current.CancellationToken;

        await _fixture.Admin(WireMockServices.OpenAccountApi)
            .StubJsonAsync("GET", "/api/ping", 200, new { message = "pong" }, cancellationToken);

        using var client = new HttpClient { BaseAddress = new Uri(_fixture.BaseUrl(WireMockServices.OpenAccountApi)) };
        using var response = await client.GetAsync("/api/ping", cancellationToken);
        var body = await response.Content.ReadFromJsonAsync<PingResponse>(cancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.OK);
        body!.Message.Should().Be("pong");
    }

    /// <summary>
    /// 驗證重置會清除所有服務的 mappings 與 request logs。
    /// </summary>
    [Fact]
    public async Task ResetAllAsync_三個服務皆有殘留Mapping_應清空全部服務的Mapping與RequestLog()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        var probes = new[]
        {
            (WireMockServices.OpenAccountApi, "/api/leftover-open-account"),
            (WireMockServices.IdentityApi, "/api/leftover-identity"),
            (WireMockServices.PaymentApi, "/api/leftover-payment"),
        };

        foreach (var (serviceName, path) in probes)
        {
            await _fixture.Admin(serviceName)
                .StubJsonAsync("GET", path, 200, new { }, cancellationToken);

            using var client = new HttpClient { BaseAddress = new Uri(_fixture.BaseUrl(serviceName)) };
            using var response = await client.GetAsync(path, cancellationToken);
            response.StatusCode.Should().Be(HttpStatusCode.OK);
        }

        await _fixture.ResetAllAsync(cancellationToken);

        foreach (var (serviceName, _) in probes)
        {
            var mappings = await _fixture.Admin(serviceName).GetMappingsAsync(cancellationToken);
            var requests = await _fixture.Admin(serviceName).GetRequestsAsync(cancellationToken);

            mappings.Should().BeEmpty();
            requests.Should().BeEmpty();
        }
    }

    /// <summary>
    /// 表示 fixture 連線測試使用的最小 JSON 回應。
    /// </summary>
    /// <param name="Message">WireMock stub 回傳的訊息。</param>
    private sealed record PingResponse(string Message);
}
