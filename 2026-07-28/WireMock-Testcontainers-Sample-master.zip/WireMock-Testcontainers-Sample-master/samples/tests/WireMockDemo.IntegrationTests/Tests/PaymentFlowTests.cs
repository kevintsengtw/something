using System.Net;
using System.Net.Http.Json;
using AwesomeAssertions;
using WireMockDemo.IntegrationTests.Infrastructure;
using Xunit;

namespace WireMockDemo.IntegrationTests.Tests;

/// <summary>
/// 驗證金流服務 request log 在測試之間維持隔離。
/// </summary>
public sealed class PaymentFlowTests : WireMockTestBase
{
    /// <summary>
    /// 初始化金流流程整合測試。
    /// </summary>
    /// <param name="fixture">目前 collection 共用的 WireMock fixture。</param>
    public PaymentFlowTests(WireMockFixture fixture) : base(fixture)
    {
    }

    /// <summary>
    /// 驗證測試開始時沒有前次請求殘留，且本次流程只留下單一金流請求。
    /// </summary>
    [Fact]
    public async Task 金流服務RequestLog_不應包含其他測試類別殘留的請求()
    {
        var cancellationToken = TestContext.Current.CancellationToken;
        var existingRequests = await Fixture.Admin(WireMockServices.PaymentApi).GetRequestsAsync(cancellationToken);
        existingRequests.Should().BeEmpty();

        await Fixture.Admin(WireMockServices.OpenAccountApi)
            .StubJsonAsync("POST", "/api/accounts", 200, new { accountNo = "0077777777" }, cancellationToken);
        await Fixture.Admin(WireMockServices.IdentityApi)
            .StubJsonAsync("POST", "/api/verify", 200, new { verified = true }, cancellationToken);
        await Fixture.Admin(WireMockServices.PaymentApi)
            .StubJsonAsync("POST", "/api/deposits", 200, new { transactionId = "TX-003", status = "Completed" }, cancellationToken);

        using var client = Fixture.Factory.CreateClient();
        using var response = await client.PostAsJsonAsync(
            "/api/open-account",
            new OpenAccountRequest("Alice", "B123456789", 500m),
            cancellationToken);
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var requestsAfterCall = await Fixture.Admin(WireMockServices.PaymentApi).GetRequestsAsync(cancellationToken);
        requestsAfterCall.Should().ContainSingle();
    }
}
