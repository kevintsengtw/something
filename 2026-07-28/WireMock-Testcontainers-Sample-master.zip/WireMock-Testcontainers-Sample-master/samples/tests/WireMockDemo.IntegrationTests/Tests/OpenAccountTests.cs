using System.Net;
using System.Net.Http.Json;
using AwesomeAssertions;
using WireMockDemo.IntegrationTests.Infrastructure;
using Xunit;

namespace WireMockDemo.IntegrationTests.Tests;

/// <summary>
/// 驗證開戶 API 與三個外部服務之間的整合流程。
/// </summary>
public sealed class OpenAccountTests : WireMockTestBase
{
    /// <summary>
    /// 初始化開戶流程整合測試。
    /// </summary>
    /// <param name="fixture">目前 collection 共用的 WireMock fixture。</param>
    public OpenAccountTests(WireMockFixture fixture) : base(fixture)
    {
    }

    /// <summary>
    /// 驗證三個外部服務皆成功時，API 會回傳新帳號與交易狀態。
    /// </summary>
    [Fact]
    public async Task 開戶成功_應回傳帳號()
    {
        var cancellationToken = TestContext.Current.CancellationToken;

        await Fixture.Admin(WireMockServices.OpenAccountApi)
            .StubJsonAsync("POST", "/api/accounts", 200, new { accountNo = "0012345678" }, cancellationToken);
        await Fixture.Admin(WireMockServices.IdentityApi)
            .StubJsonAsync("POST", "/api/verify", 200, new { verified = true }, cancellationToken);
        await Fixture.Admin(WireMockServices.PaymentApi)
            .StubJsonAsync("POST", "/api/deposits", 200, new { transactionId = "TX-001", status = "Completed" }, cancellationToken);

        using var client = Fixture.Factory.CreateClient();
        using var response = await client.PostAsJsonAsync(
            "/api/open-account",
            new OpenAccountRequest("Kevin", "A123456789", 1000m),
            cancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var result = await response.Content.ReadFromJsonAsync<OpenAccountResponse>(cancellationToken);
        result!.AccountNo.Should().Be("0012345678");
        result.Status.Should().Be("Completed");
    }

    /// <summary>
    /// 驗證身分驗證失敗時回傳 400，且流程不會呼叫金流服務。
    /// </summary>
    [Fact]
    public async Task 身分驗證失敗_應回傳400且不呼叫金流服務()
    {
        var cancellationToken = TestContext.Current.CancellationToken;

        await Fixture.Admin(WireMockServices.OpenAccountApi)
            .StubJsonAsync("POST", "/api/accounts", 200, new { accountNo = "0099999999" }, cancellationToken);
        await Fixture.Admin(WireMockServices.IdentityApi)
            .StubJsonAsync("POST", "/api/verify", 200, new { verified = false }, cancellationToken);

        using var client = Fixture.Factory.CreateClient();
        using var response = await client.PostAsJsonAsync(
            "/api/open-account",
            new OpenAccountRequest("Kevin", "A000000000", 1000m),
            cancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);

        var paymentRequests = await Fixture.Admin(WireMockServices.PaymentApi).GetRequestsAsync(cancellationToken);
        paymentRequests.Should().BeEmpty();
    }

    /// <summary>
    /// 驗證 reset 後重新設定相同路徑時，只會取得新的 stub 回應。
    /// </summary>
    [Fact]
    public async Task Reset後重新設定開戶情境_應回傳新帳號而非Reset前的值()
    {
        var cancellationToken = TestContext.Current.CancellationToken;

        await Fixture.Admin(WireMockServices.OpenAccountApi)
            .StubJsonAsync("POST", "/api/accounts", 200, new { accountNo = "0012345678" }, cancellationToken);
        await Fixture.Admin(WireMockServices.IdentityApi)
            .StubJsonAsync("POST", "/api/verify", 200, new { verified = true }, cancellationToken);
        await Fixture.Admin(WireMockServices.PaymentApi)
            .StubJsonAsync("POST", "/api/deposits", 200, new { transactionId = "TX-OLD", status = "Completed" }, cancellationToken);

        using var client = Fixture.Factory.CreateClient();
        using var firstResponse = await client.PostAsJsonAsync(
            "/api/open-account",
            new OpenAccountRequest("Kevin", "A123456789", 1000m),
            cancellationToken);
        var firstResult = await firstResponse.Content.ReadFromJsonAsync<OpenAccountResponse>(cancellationToken);
        firstResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        firstResult!.AccountNo.Should().Be("0012345678");

        await Fixture.ResetAllAsync(cancellationToken);

        await Fixture.Admin(WireMockServices.OpenAccountApi)
            .StubJsonAsync("POST", "/api/accounts", 200, new { accountNo = "0088888888" }, cancellationToken);
        await Fixture.Admin(WireMockServices.IdentityApi)
            .StubJsonAsync("POST", "/api/verify", 200, new { verified = true }, cancellationToken);
        await Fixture.Admin(WireMockServices.PaymentApi)
            .StubJsonAsync("POST", "/api/deposits", 200, new { transactionId = "TX-002", status = "Completed" }, cancellationToken);

        using var response = await client.PostAsJsonAsync(
            "/api/open-account",
            new OpenAccountRequest("Kevin", "A123456789", 1000m),
            cancellationToken);

        var result = await response.Content.ReadFromJsonAsync<OpenAccountResponse>(cancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.OK);
        result!.AccountNo.Should().Be("0088888888");
        result.AccountNo.Should().NotBe("0012345678");
    }
}
