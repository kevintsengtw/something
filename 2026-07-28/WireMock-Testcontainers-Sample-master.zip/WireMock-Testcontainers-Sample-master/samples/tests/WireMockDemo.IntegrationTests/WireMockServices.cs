namespace WireMockDemo.IntegrationTests;

/// <summary>
/// 集中定義整合測試使用的外部服務名稱。
/// </summary>
public static class WireMockServices
{
    /// <summary>
    /// 開戶主檔服務的名稱。
    /// </summary>
    public const string OpenAccountApi = "OpenAccountApi";

    /// <summary>
    /// 身分驗證服務的名稱。
    /// </summary>
    public const string IdentityApi = "IdentityApi";

    /// <summary>
    /// 金流服務的名稱。
    /// </summary>
    public const string PaymentApi = "PaymentApi";
}
