var builder = WebApplication.CreateBuilder(args);

// 使用 named HttpClient 將三個外部服務的位址分開管理；
// 測試環境會透過 WebApplicationFactory 覆寫這些設定值。
builder.Services.AddHttpClient("OpenAccountApi", (serviceProvider, client) =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    client.BaseAddress = new Uri(configuration["ExternalServices:OpenAccountApi:BaseUrl"]!);
});

builder.Services.AddHttpClient("IdentityApi", (serviceProvider, client) =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    client.BaseAddress = new Uri(configuration["ExternalServices:IdentityApi:BaseUrl"]!);
});

builder.Services.AddHttpClient("PaymentApi", (serviceProvider, client) =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    client.BaseAddress = new Uri(configuration["ExternalServices:PaymentApi:BaseUrl"]!);
});

var app = builder.Build();

// 開戶流程依序建立主檔、驗證身分，最後才執行初始存款。
// CancellationToken 會沿著所有外部 HTTP 呼叫傳遞，讓用戶端中止請求時能及時取消工作。
app.MapPost("/api/open-account", async (
    OpenAccountRequest request,
    IHttpClientFactory httpClientFactory,
    CancellationToken cancellationToken) =>
{
    var openAccountClient = httpClientFactory.CreateClient("OpenAccountApi");
    using var openAccountResponse = await openAccountClient.PostAsJsonAsync(
        "/api/accounts",
        new OpenAccountApiRequest(request.ApplicantName),
        cancellationToken);
    openAccountResponse.EnsureSuccessStatusCode();
    var account = await openAccountResponse.Content.ReadFromJsonAsync<OpenAccountApiResponse>(cancellationToken)
        ?? throw new InvalidOperationException("OpenAccountApi returned an empty response.");

    var identityClient = httpClientFactory.CreateClient("IdentityApi");
    using var identityResponse = await identityClient.PostAsJsonAsync(
        "/api/verify",
        new IdentityVerifyRequest(request.IdentityNo),
        cancellationToken);
    identityResponse.EnsureSuccessStatusCode();
    var identity = await identityResponse.Content.ReadFromJsonAsync<IdentityVerifyResponse>(cancellationToken)
        ?? throw new InvalidOperationException("IdentityApi returned an empty response.");

    if (!identity.Verified)
    {
        return Results.BadRequest(new { message = "Identity verification failed." });
    }

    var paymentClient = httpClientFactory.CreateClient("PaymentApi");
    using var paymentResponse = await paymentClient.PostAsJsonAsync(
        "/api/deposits",
        new PaymentDepositRequest(account.AccountNo, request.InitialDeposit),
        cancellationToken);
    paymentResponse.EnsureSuccessStatusCode();
    var payment = await paymentResponse.Content.ReadFromJsonAsync<PaymentDepositResponse>(cancellationToken)
        ?? throw new InvalidOperationException("PaymentApi returned an empty response.");

    return Results.Ok(new OpenAccountResponse(account.AccountNo, payment.Status));
});

app.Run();

/// <summary>
/// 提供 <c>WebApplicationFactory&lt;Program&gt;</c> 可識別的應用程式進入點。
/// </summary>
public partial class Program;
