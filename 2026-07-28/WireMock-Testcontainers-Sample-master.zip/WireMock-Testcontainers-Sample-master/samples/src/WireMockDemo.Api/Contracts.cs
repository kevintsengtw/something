/// <summary>
/// 表示開戶 API 接收的申請資料。
/// </summary>
/// <param name="ApplicantName">申請人姓名。</param>
/// <param name="IdentityNo">申請人的身分識別號碼。</param>
/// <param name="InitialDeposit">開戶時的初始存款金額。</param>
public sealed record OpenAccountRequest(string ApplicantName, string IdentityNo, decimal InitialDeposit);

/// <summary>
/// 表示開戶 API 成功完成後回傳的結果。
/// </summary>
/// <param name="AccountNo">新建立的帳號。</param>
/// <param name="Status">初始存款交易狀態。</param>
public sealed record OpenAccountResponse(string AccountNo, string Status);

/// <summary>
/// 表示傳送給開戶主檔服務的請求。
/// </summary>
/// <param name="ApplicantName">申請人姓名。</param>
internal sealed record OpenAccountApiRequest(string ApplicantName);

/// <summary>
/// 表示開戶主檔服務建立帳號後的回應。
/// </summary>
/// <param name="AccountNo">新建立的帳號。</param>
internal sealed record OpenAccountApiResponse(string AccountNo);

/// <summary>
/// 表示傳送給身分驗證服務的請求。
/// </summary>
/// <param name="IdentityNo">要驗證的身分識別號碼。</param>
internal sealed record IdentityVerifyRequest(string IdentityNo);

/// <summary>
/// 表示身分驗證服務的判定結果。
/// </summary>
/// <param name="Verified">身分是否通過驗證。</param>
internal sealed record IdentityVerifyResponse(bool Verified);

/// <summary>
/// 表示傳送給金流服務的初始存款請求。
/// </summary>
/// <param name="AccountNo">存入款項的帳號。</param>
/// <param name="Amount">存款金額。</param>
internal sealed record PaymentDepositRequest(string AccountNo, decimal Amount);

/// <summary>
/// 表示金流服務處理初始存款後的回應。
/// </summary>
/// <param name="TransactionId">金流交易識別碼。</param>
/// <param name="Status">交易狀態。</param>
internal sealed record PaymentDepositResponse(string TransactionId, string Status);
