# CLAUDE.md

這份文件說明在此 repository 工作時的共同規範與目前狀態。

## 最高優先規則：一律使用正體中文回覆

所有回覆一律使用正體中文。程式碼識別字、套件名稱與 API 名稱維持英文。

## 專案目的

這個 repository 驗證並整理一篇 WireMock.Net.Testcontainers 技術文章，主題是多服務整合測試共用 container 時的狀態重置。

公開文章只保留讀者可直接採用的解決方案。開發規劃、行為驗證、效能量測與破壞性實驗保留在 `docs/` 與 `WireMockDemo.Experiments`，不加入公開文章主線。

## 目前產出

- `articles/wiremock-testcontainers-reset.md`：原始草稿，保留 `draft: true`，不對外發表。
- `articles/wiremock-testcontainers-reset-published.md`：精簡後的公開版本。
- `samples/src/WireMockDemo.Api`：會呼叫三個外部服務的最小開戶 API。
- `samples/tests/WireMockDemo.IntegrationTests`：正式整合測試與共用 WireMock fixture。
- `samples/tests/WireMockDemo.Experiments`：技術主張、生命週期與效能驗證。
- `docs/verification-results.md`：實驗輸出與技術主張的驗證紀錄。
- `docs/changes-from-draft.md`：公開文章相對原始草稿的修改摘要。
- `docs/superpowers/`：歷史設計與實作計畫，不是目前操作指南。

## 範例架構

```text
samples/
  WireMockDemo.slnx
  src/WireMockDemo.Api/
  tests/WireMockDemo.IntegrationTests/
    Infrastructure/WireMockFixture.cs
    Infrastructure/WireMockTestBase.cs
    Infrastructure/WireMockCollection.cs
  tests/WireMockDemo.Experiments/
```

正式整合測試採用：

- 一個外部服務對應一個 WireMock container。
- xUnit Collection Fixture 共用 containers。
- 每個測試開始前清除 mappings 與 request log。
- reset 後立即確認沒有殘留 mappings。
- container 平行啟動，啟動失敗時主動清理部分成功或尚未註冊的實例。
- `WebApplicationFactory<Program>` 注入三個動態 base URL。

## 開發與驗證指令

```bash
dotnet build samples/WireMockDemo.slnx
dotnet test samples/WireMockDemo.slnx

dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj
dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj --filter "FullyQualifiedName~OpenAccountTests"
```

`WireMockDemo.Experiments` 內刻意拋例外的生命週期探測標成 xUnit explicit tests，預設不執行，因此日常 solution 測試不會被這些探測刻意弄成失敗。

測試會啟動 Docker containers。執行後可確認沒有殘留：

```bash
docker ps -a --filter "ancestor=sheyenrath/wiremock.net-alpine"
```

## 技術棧

- Target framework：`net10.0`
- xUnit v3 3.2.2
- VSTest：`xunit.runner.visualstudio` 3.1.5
- `WireMock.Net.Testcontainers` 2.13.0
- `AwesomeAssertions` 9.5.0
- `Microsoft.AspNetCore.Mvc.Testing` 10.0.10

xUnit v3 的 `IAsyncLifetime.InitializeAsync()` 與非同步清理使用 `ValueTask`。遇到不確定的 WireMock API 時，重新查官方文件或原始碼，不憑印象假設簽章。

## 文件角色

`docs/superpowers/specs/` 與 `docs/superpowers/plans/` 記錄各階段的設計與執行計畫，內容可能反映當時尚未完成的狀態。它們應作為歷史紀錄閱讀，不應覆蓋目前程式碼、驗證結果與公開文章。

公開文章的技術主張必須符合以下至少一項：

1. 由目前範例直接驗證。
2. 引用官方文件。
3. 無法可靠驗證時移除。
