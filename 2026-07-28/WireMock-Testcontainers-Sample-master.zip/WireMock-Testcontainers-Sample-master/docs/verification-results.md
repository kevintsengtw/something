# 驗證結果紀錄

這份文件記錄 `articles/wiremock-testcontainers-reset.md` 草稿裡各項技術主張的**實際**驗證結果，對應 `samples/tests/WireMockDemo.Experiments` 專案裡的測試。每一項都附上實際執行的指令與實際輸出，不寫「預期會是」這種未執行的描述。

## 測試環境

- OS：Windows 11 Pro 10.0.26200
- .NET SDK：10.0.302（測試執行期為 .NET 10.0.10 runtime）
- Docker：29.6.2
- `WireMock.Net.Testcontainers`：2.13.0（container image 未手動指定版本，交給套件自行決定）
- xUnit：v3 3.2.2（`xunit.runner.visualstudio` 3.1.5，VSTest）
- 斷言函式庫：`AwesomeAssertions` 9.5.0

驗證日期：2026-07-27。

---

## 驗證 1：`/__admin/reset` 端點是否存在

**草稿主張：** .NET 版沒有這個端點、打下去會回 404、對 mapping 完全沒有副作用。

**執行指令：**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V1_AdminResetEndpointTests"
```

**實際輸出：**

```text
已通過 WireMockDemo.Experiments.V1_AdminResetEndpointTests.PostAdminReset_應回傳404且對Mapping數量無副作用 [4 s]
測試回合成功。
測試數總計: 1
     通過: 1
```

`POST /__admin/reset` 的實際回應狀態碼為 `404 NotFound`；灌入一筆 mapping 後，呼叫前後 `GetMappingsAsync()` 的數量都是 1，沒有變化。

**結論：confirmed。** 草稿的三個主張（不存在、404、無副作用）全數成立。此外，規劃階段已直接查過 `wiremock/WireMock.Net` 原始碼的 `WireMockServer.Admin.cs`，確認註冊的 reset 相關路由只有 `mappings/reset`、`requests/reset`、`scenarios/reset`、`scenarios/{name}/reset`，沒有裸的 `reset`——這與實測結果一致：打這個路徑會落入一般 stub 比對流程，因為沒有匹配的 mapping 而回 404。

---

## 驗證 2：reset 的實際行為

**草稿主張：** `ResetMappingsAsync()` 會清空所有動態 mapping；預設（`reloadStaticMappings: false`）不會重新載入靜態 mapping，需要明確傳 `true` 才會；`ResetRequestsAsync()` 清的是 request log，不影響 mapping。

**執行指令：**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V2_"
```

**實際輸出：**

```text
已通過 WireMockDemo.Experiments.V2_StaticMappingReloadTests.ResetMappingsAsyncReloadStaticMappingsTrue_靜態Mapping會重新載入 [3 s]
已通過 WireMockDemo.Experiments.V2_ResetBehaviorTests.ResetMappingsAsync_應清空所有動態Mapping [4 s]
已通過 WireMockDemo.Experiments.V2_StaticMappingReloadTests.ResetMappingsAsync預設_靜態Mapping不會自動回來 [2 s]
已通過 WireMockDemo.Experiments.V2_ResetBehaviorTests.ResetRequestsAsync_只清RequestLog_不影響Mapping [2 s]
測試回合成功。
測試數總計: 4
     通過: 4
```

具體數字：

- 灌入 1 筆動態 mapping 後呼叫 `ResetMappingsAsync()`，`GetMappingsAsync()` 回傳 0 筆。
- 用 `.WithMappings(...)` 載入 1 筆靜態 mapping，呼叫預設的 `ResetMappingsAsync()`（`reloadStaticMappings: false`）後，`GetMappingsAsync()` 從 1 筆變成 0 筆——靜態 mapping 沒有自動回來。
- 呼叫 `ResetMappingsAsync(reloadStaticMappings: true)` 後，`GetMappingsAsync()` 回傳 1 筆——靜態 mapping 重新載入。
- 灌入 1 筆 mapping 並打一次該路徑後，呼叫 `ResetRequestsAsync()`：`GetMappingsAsync()` 仍是 1 筆，`GetRequestsAsync()` 變成 0 筆。

**結論：confirmed。** 草稿的三個子主張全數成立。額外發現：`.WithMappings(...)` 的 bind mount 在 Windows + Docker Desktop 的本機環境下運作正常，沒有遇到檔案共享權限問題。

---

## 驗證 3：重現原始 bug 與因果鏈（最有價值的一項）

**草稿主張：** 在 `ResetMappingsAsync()` 之前多打一發手動的 `/__admin/reset`，會讓 reset 實質失效、mapping 殘留；草稿原文對因果鏈只有推論（「我沒有百分之百確定的因果鏈」），懷疑是 `EnsureSuccessStatusCode()` 拋出例外導致後續程式碼被跳過。

**執行指令：**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V3_"
```

**實際輸出：**

```text
已通過 WireMockDemo.Experiments.V3_BugReproductionTests.有問題的Reset_多打一次AdminReset_Mapping會殘留 [4 s]
已通過 WireMockDemo.Experiments.V3_BugReproductionTests.有問題的Reset_因果鏈_EnsureSuccessStatusCode應拋出HttpRequestException [2 s]
已通過 WireMockDemo.Experiments.V3_BugReproductionTests.正確的Reset_只呼叫ResetMappingsAsync_Mapping會清空 [1 s]
測試回合成功。
測試數總計: 3
     通過: 3
```

具體結果：

- 「有問題的 reset」（手動 POST `/__admin/reset` 後接 `ResetMappingsAsync()`，中間沒有 try/catch）：`GetMappingsAsync()` 執行後仍是 1 筆——**bug 完整重現**，mapping 確實殘留。
- 「正確的 reset」（只呼叫 `ResetMappingsAsync()`）：`GetMappingsAsync()` 變成 0 筆，如預期清空。
- 因果鏈：對 `/__admin/reset` 的回應呼叫 `EnsureSuccessStatusCode()`，實際拋出 `HttpRequestException`，且例外的 `StatusCode` 屬性確實是 `HttpStatusCode.NotFound`。

**結論：confirmed，且因果鏈從推論變成確定結論。** `EnsureSuccessStatusCode()` 對 404 回應會拋出 `HttpRequestException`；如果呼叫端沒有用 try/catch 包住這段手動呼叫，這個例外會直接往外拋，導致後面那行 `ResetMappingsAsync()` **從未被執行**——不是 reset 失效，而是根本沒跑到。草稿裡「我沒有百分之百確定的因果鏈」這句話，改寫文章時應該替換成明確的結論。

---

## 驗證 4：xUnit 生命週期

> 後續整理公開範例時，這兩個刻意拋出例外的探測已標記為 xUnit explicit tests，避免日常 `dotnet test` 必然失敗。探測執行前也會先刪除對應 marker，確保結果不受前次執行殘留影響。以下保留最初驗證時的實際輸出。

**草稿主張：** 測試方法拋出例外時，`DisposeAsync` 仍然會被呼叫；`InitializeAsync` 拋出例外時，對應的 `DisposeAsync` 不會被呼叫（這是草稿「孤兒 container」論述的前提）。

**執行指令：**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category=LifecycleProbe"
```

**實際輸出：**

```text
V4_TestMethodThrows_DisposeAsyncStillRunsProbe.測試方法拋出例外_探測DisposeAsync是否仍會被呼叫 [FAIL]
  System.InvalidOperationException : 刻意拋出的例外，用來驗證 DisposeAsync 是否仍會被呼叫。

V4_InitializeAsyncThrows_DisposeAsyncDoesNotRunProbe.這個測試方法理論上不會被執行到 [FAIL]
  System.InvalidOperationException : 刻意拋出的例外，用來驗證 InitializeAsync 失敗時 DisposeAsync 是否不會被呼叫。

測試回合失敗。
測試數總計: 2
     失敗: 2
```

這兩個測試「失敗」是設計上的行為（兩者都刻意拋例外），真正的證據來自執行後檢查 `LifecycleProbeOutput/` 目錄：只有 `test-method-throws.marker` 存在，`initialize-throws.marker` 不存在。

**結論：confirmed。** 測試方法拋例外時，`DisposeAsync` 確實仍會被呼叫；`InitializeAsync` 拋例外時，對應的 `DisposeAsync` 確實不會被呼叫。草稿「孤兒 container」那段論述的前提成立。

---

## 驗證 5：xUnit 平行執行行為

**草稿主張：** 同一個 test collection 內的測試類別會依序執行、彼此絕不平行；不同 collection 之間才會平行；沒標 `[Collection]` 的類別會自成一個獨立 collection，跟其他類別平行執行。額外交叉確認：參考專案 `securities-trading-integration-testing` 明確設定 `[CollectionDefinition(DisableParallelization = true)]`，這個設定對「同 collection 內序列執行」是否真的必要。

**執行指令：**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V5_"
python3 -c "讀取 V5Log/timestamps.csv，計算起訖時間區間是否重疊"
```

**實際輸出（時間戳記，Unix epoch 毫秒）：**

```text
V5_NoCollection_ClassC,   1785140931079, 1785140931382
V5_NoCollection_ClassD,   1785140931080, 1785140931382
V5_SameCollection_ClassA, 1785140931080, 1785140931382
V5_SameCollection_ClassB, 1785140931401, 1785140931710

SameCollection overlap: False
NoCollection overlap: True
```

**結論：confirmed。** 同一個 `V5Same` collection 的 `ClassA`／`ClassB` 沒有時間重疊（`ClassA` 在 931382 結束，`ClassB` 到 931401 才開始）——依序執行成立，而且**沒有**設定 `DisableParallelization`。沒標 `[Collection]` 的 `ClassC`／`ClassD` 幾乎完全重疊（931079-931382 對 931080-931382）——平行執行成立。額外發現：標了 `V5Same` 的 `ClassA` 執行區間跟 `ClassC`／`ClassD`（各自獨立的預設 collection）幾乎重疊，直接證明不同 collection 之間確實會平行。

對照參考專案的疑點：`DisableParallelization = true` 對「同 collection 內序列執行」這件事**不是必要的**——這個保證是 xUnit 的預設行為，跟有沒有設這個旗標無關。這個設定比較可能是防禦性寫法（例如避免未來新增的測試類別意外沒有加入該 collection），而不是讓序列執行「生效」的必要條件。

---

## 驗證 6：集合型別行為差異

**草稿主張：** 並行寫入 `Dictionary` 可能造成 key 遺失或例外；`Dictionary` 在列舉過程中被修改會拋 `InvalidOperationException` 而 `ConcurrentDictionary` 不會；`ConcurrentDictionary.Count` 需要取得所有內部鎖；`ConcurrentDictionary.Values` 回傳的是快照而非即時檢視。

**執行指令：**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V6_"
```

**實際輸出：**

```text
已通過 V6_CollectionTypeBehaviorTests.並行寫入Dictionary_1000輪x16執行緒_統計失敗率與逾時次數 [1 s]
  並行寫入 Dictionary：1000 輪 x 16 執行緒
    例外失敗次數：0
    疑似逾時（執行緒卡住超過 500ms）輪數：0
    無例外但 key 數量不對（靜默損壞）輪數：0
已通過 V6_CollectionTypeBehaviorTests.Dictionary列舉中被修改_應拋出InvalidOperationException [16 ms]
已通過 V6_CollectionTypeBehaviorTests.ConcurrentDictionary列舉中被修改_不會拋出例外 [2 ms]
已通過 V6_CollectionTypeBehaviorTests.ConcurrentDictionaryValues_具體化後修改字典_具體化的List不受影響 [17 ms]
已通過 V6_CollectionTypeBehaviorTests.ConcurrentDictionaryValues_每次呼叫都是新的快照 [< 1 ms]
測試回合成功。
測試數總計: 5
     通過: 5
```

**結論：部分 confirmed、部分 refuted、一項改引用文件語氣。**

- 列舉中修改的行為：**confirmed。** `Dictionary` 列舉中被修改確實拋出 `InvalidOperationException`；`ConcurrentDictionary` 確實不會。
- `.Values` 快照行為：**confirmed。** 具體化後的 `List` 不受後續修改影響；每次呼叫 `.Values` 都是新的快照（第一次快照的數量在字典新增元素後仍維持不變）。
- 並行寫入損壞：**本次執行未能重現，如實記錄，不代表風險不存在。** 1000 輪 × 16 執行緒、每個執行緒各自寫入一個獨立的 key，全數 0 失敗、0 逾時、0 靜默損壞。這件事本身有一個合理解釋值得記錄：16 個執行緒各自只新增一個獨一無二的 key、總數量不大，很可能從未觸發 `Dictionary` 內部的 resize／rehash（這正是並行寫入最危險的時間點）；沒有觸發 resize，就沒有觀察到損壞。改寫文章時，這一段的語氣要從「會造成 key 遺失或例外」降級為「官方文件與 API 設計都明確不保證執行緒安全，但實際觸發損壞需要特定條件（例如寫入量足以觸發 resize），本次在 16 個執行緒、不重疊 key 的情境下未能重現」。
- `ConcurrentDictionary.Count` 是否取所有內部鎖：**改為引用官方文件語氣，不寫測試。** 沒有可靠的公開 API 能直接觀察「有沒有取鎖」這種內部實作細節，勉強寫一個計時比較測試也無法排除雜訊干擾，不值得為了硬湊一個「測過」的假象而做出不可靠的結論。

---

## 驗證 7：計時數字

**草稿主張：** 單一 WireMock container 啟動耗時約一到數秒；三個 container 平行啟動大約等於最慢的那一個，比循序啟動快很多；in-process `WireMockServer` 啟動耗時是數十毫秒等級。

**測試環境：**

```text
OS：Microsoft Windows 10.0.26200
CPU 核心數：16
.NET Runtime：.NET 10.0.10
Docker：Docker version 29.6.2, build dfc4efb
```

**執行指令：**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category=TimingBenchmark"
```

**實際輸出（5 次取中位數）：**

```text
in-process WireMockServer 啟動耗時：1ms, 2ms, 2ms, 10ms, 532ms，中位數：2ms
單一 container 啟動耗時：       1466ms, 1473ms, 1474ms, 1486ms, 1501ms，中位數：1474ms
三個 container 循序啟動：       4464ms, 4482ms, 4503ms, 4529ms, 6314ms，中位數：4503ms
三個 container 平行啟動：       1576ms, 1577ms, 1579ms, 1589ms, 1594ms，中位數：1579ms
```

**結論：confirmed，數字全部替換成本機實測值。**

- 單一 container 啟動：中位數 1474ms，落在草稿說的「一到數秒」範圍內。
- 三個 container 平行啟動（中位數 1579ms）幾乎等於單一 container 的啟動時間（1474ms），確認「平行啟動約等於最慢的那一個」成立；循序啟動（中位數 4503ms）則接近三個單一啟動時間相加，兩者差距約 2.85 倍。
- in-process `WireMockServer` 中位數 2ms，是「數十毫秒等級」的說法應該修正為「個位數毫秒等級，比草稿原本估計的還要快」——第一次呼叫出現 532ms 的離群值，合理解釋是 JIT 預熱／組件載入的一次性成本，不代表穩定狀態下的啟動時間，這點會在文章裡說明。

---

## 驗證 8：in-process `WireMockServer`

**草稿主張：** `WireMockServer.Start()` 起來的 server 不會啟用 admin 介面，必須改用 `WireMockServer.StartWithAdminInterface(...)` 才有；`server.Given(...).RespondWith(...)` 這組 fluent API 可以正常運作。

**執行指令：**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V8_"
```

**實際輸出：**

```text
已通過 V8_InProcessWireMockServerTests.StartWithAdminInterface_AdminEndpoint應可正常存取 [3 s]
已通過 V8_InProcessWireMockServerTests.每個測試一個全新Server_使用GivenRespondWith設定Stub [23 ms]
已通過 V8_InProcessWireMockServerTests.StartWithoutAdminInterface_AdminEndpoint應回傳404 [6 ms]
測試回合成功。
測試數總計: 3
     通過: 3
```

**結論：confirmed。** `WireMockServer.Start()` 起來的 server 打 `/__admin/mappings` 回 404（admin 介面確實沒有啟用，請求落入一般 stub 比對流程，跟驗證 1 的 `/__admin/reset` 是同一種機制）；`StartWithAdminInterface()` 起來的 server 打同一個路徑回 200。`server.Given(Request.Create()...).RespondWith(Response.Create()...)` 這組 fluent API 的命名空間（`WireMock.RequestBuilders`、`WireMock.ResponseBuilders`、`WireMock.Server`）與簽章跟草稿設想的一致，第一次寫就編譯通過、行為也符合預期。

---

## 小結

草稿〈發表前待驗證清單〉的 8 項技術主張全部完成實測，改寫文章時的處理方式：

- **驗證 1、2、3、4、5、8：全數 confirmed**，可以用肯定語氣改寫，並附上本次驗證的套件版本與測試環境。驗證 3 的因果鏈從推論變成了確定結論，是全文最有價值的一次修正。
- **驗證 6**：列舉行為與 `.Values` 快照 confirmed；並行寫入損壞本次未能重現，語氣要降級為「理論風險存在但本次條件下未觀察到」；`ConcurrentDictionary.Count` 取鎖行為改成引用官方文件、不聲稱有實測。
- **驗證 7**：計時數字全部替換成本機實測值，in-process `WireMockServer` 的啟動耗時比草稿原本估計的快一個數量級，需要在改寫時特別修正。

草稿裡不再有任何一個技術主張停留在「應該」「可能」「理論上」這種未經驗證的推論語氣。
