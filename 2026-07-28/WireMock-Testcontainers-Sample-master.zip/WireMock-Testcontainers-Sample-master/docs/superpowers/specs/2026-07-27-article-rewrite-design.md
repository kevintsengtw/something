---
title: 文章改寫 —— 從草稿到可發表版本
date: 2026-07-27
status: 待實作
---

# 背景與目標

`WireMockDemo.Experiments` 的 8 項驗證已全數完成，實際輸出都記錄在 `docs/verification-results.md`。這份文件規劃任務的最後一個階段：依照實測結果把 `articles/wiremock-testcontainers-reset.md`（草稿）改寫成 `articles/wiremock-testcontainers-reset-published.md`（發表版），並產出 `docs/changes-from-draft.md`（給作者 review 用、逐條記錄改了什麼與為什麼改，不對外發表）。

改寫時的最高原則不變：文章裡每一個技術主張都要落在「已實測」「引用官方文件」「刪除」三態之一，不保留「應該」「可能」「理論上」這種未經驗證的推論語氣。

# 兩項內容決定（已與作者確認）

1. **驗證6「並行寫入 Dictionary 損壞未重現」**：只寫「1000 輪都沒重現」這個事實，**刪掉**「可能是因為 16 個執行緒各自寫入不重疊的 key、從未觸發 resize」這個推測——這個解釋本身沒有另外實測過。
2. **`DisableParallelization = true` 的新發現**（規劃範例專案時查參考專案 `securities-trading-integration-testing` 發現，不在草稿原本 8 項驗證清單內）：收錄進「排查第一站：平行執行」那一節，因為它直接補強了草稿原本「同 collection 內序列執行」那段論述，且是在驗證5的過程中一併確認的。

# 結構性決定

## xUnit v2/v3 的 framing 對調

草稿目前主線程式碼是 v2 寫法（`Task InitializeAsync`），v3 只在「注意：xUnit v2 與 v3 的 IAsyncLifetime 不一樣」這個小節帶過。範例專案的**所有**實際程式碼都是 v3（`ValueTask`）。依照「程式碼片段全部換成範例專案裡實際編譯過的版本」的原則，發表版的主線程式碼必須全部改成 v3；原本那個小節的 framing 要反過來，變成「本文與範例都以 v3 為準，這裡是跟 v2 的差異」，而不是「主線是 v2，附帶提一下 v3」。

## 「第一版架構」的 naive 示範程式碼

草稿這一節示範了一個刻意寫得不夠好的早期版本（`Dictionary`、逐一手刻的服務屬性），用來鋪陳後面重構的敘事。範例專案沒有實作這個「錯誤示範」版本——我們直接做對的版本，所以這段沒有對應到真實檔案的程式碼。處理方式：這段的程式碼區塊改成**純文字描述**，敘事節奏保留（讀者仍然知道「一開始是怎麼寫的、後來為什麼要改」），但不會出現任何沒有真實檔案支撐的程式碼。

# 逐節對照表

| 草稿章節 | 處理方式 | 依據 |
|---|---|---|
| Front matter | 移除 `draft: true` | — |
| 草稿警語（開頭 blockquote） | 整段移除 | — |
| 前言 | 語氣微調，補一句已完成實測 | — |
| 背景：為什麼需要多個 Container | 架構理由，非行為主張，維持原文 | — |
| 第一版架構：single container 範例 | 換成範例專案裡真正用過的 `PostMappingAsync`（單筆）用法，不用草稿原本的 `PostMappingsAsync`（複數批次，我們沒有實際測過這個用法） | `V1_AdminResetEndpointTests.cs` 等實際程式碼 |
| 第一版架構：naive `WireMockFixture` | 程式碼區塊 → 改純文字描述 | 見上方結構性決定 |
| 排查第一站：平行執行 | 換成驗證5實測數據（時間戳記、重疊/不重疊），新增 `DisableParallelization` 發現 | 驗證5 |
| 排查第二站：reset 有清到全部嗎 | 語氣確認即可，`ResetMappingsAsync` vs `ResetRequestsAsync` 的區分換成驗證2的實測描述 | 驗證2 |
| 排查第三站：靜態 mapping 與持久化 | 換成驗證2實測結果與實際數字 | 驗證2 |
| 讓程式自己說話：加上診斷 | 程式碼換成真實 `WireMockFixture.ResetAllAsync()` | `WireMockFixture.cs` |
| 真兇：一段多餘的 `/__admin/reset` | 換成驗證1、3的實測狀態碼 | 驗證1、3 |
| 為什麼會這樣？第一個事實 | 換成驗證1的實測結果 + 原始碼查證 | 驗證1 |
| 為什麼會這樣？第二個事實（Java 習慣） | 維持原文語氣（歷史脈絡說明，非可實測的行為主張），措辭微調避免過度肯定 | — |
| 那為什麼拿掉它就好了？ | **整段改寫**：「我沒有百分之百確定的因果鏈」→ 驗證3確認的 `HttpRequestException` 因果鏈 | 驗證3 |
| 重寫後的完整架構（全部子節） | 程式碼全部換成真實 `WireMockFixture`／`WireMockTestBase`／`WireMockStubExtensions`／`WireMockCollection`／`WireMockServices` | 對應實際檔案 |
| 補充：Dictionary 還是 ConcurrentDictionary？ | 損壞風險的敘述換成驗證6實測（0/1000 輪失敗），不寫推測原因（見上方決定） | 驗證6 |
| 我考慮過但放棄的第三種寫法 | 設計取捨討論，非行為主張，維持原文 | — |
| 注意：xUnit v2 與 v3 不一樣 | **Framing 對調**，v3 為主、v2 為輔，行為描述換成驗證4的實測結果 | 驗證4 |
| Stub 設定的輔助方法 | 換成真實 `WireMockStubExtensions.StubJsonAsync` | `WireMockStubExtensions.cs` |
| 測試基底類別與實際使用 | 換成真實 `WireMockTestBase`／`OpenAccountTests` | 對應實際檔案 |
| 為什麼 reset 要放在測試之前 | 「測試方法拋例外時 DisposeAsync 仍會執行」換成驗證4的實測結果 | 驗證4 |
| 隔離策略的取捨 | in-process server 耗時換成驗證7實測數字（中位數 2ms，比原本估計快一個數量級） | 驗證7、8 |
| 排查檢查清單 | 內容跟前面章節同步更新，語氣從「應該」改成確定語氣 | 全部 |
| 結語 | 補一句連結到範例專案 | — |
| 發表前待驗證清單 | 整節移除 | — |
| 參考資料 | 新增範例專案路徑、`verification-results.md` 連結 | — |

# 新增內容：驗證環境段落

在文章開頭（front matter 之後、前言之前）或結尾（參考資料之前）加入一段，內容取自 `docs/verification-results.md` 的「測試環境」章節：OS、.NET SDK/Runtime、xUnit 版本、`WireMock.Net`／`WireMock.Net.Testcontainers` 版本、Docker 版本、驗證日期。放在**開頭**，讓讀者一開始就知道文章的適用範圍，比放在結尾更符合「先講清楚前提」的閱讀順序。

# `docs/changes-from-draft.md` 的格式

逐條列出，每條包含：對應草稿的章節／段落、改了什麼、為什麼改（哪一項驗證推翻或補強了草稿的哪個說法）。這份文件不對外發表，純粹給作者 review。

# 驗收標準

- `articles/wiremock-testcontainers-reset-published.md` 裡的每一段程式碼都能在 `samples/` 目錄裡找到對應檔案（「第一版架構」的 naive 示範例外，那段已改為純文字）
- 沒有任何「應該」「可能」「理論上」這種語氣用來描述本可實測的行為
- `docs/changes-from-draft.md` 完整記錄所有跟草稿不同之處
- 移除 `draft: true`、草稿警語、〈發表前待驗證清單〉整節
