---
title: WireMock.Net.Testcontainers reset 除錯文章 —— 範例專案設計
date: 2026-07-27
status: 待實作
---

# 背景與目標

`articles/wiremock-testcontainers-reset.md` 是一篇尚未發表的草稿，主題是「用 WireMock.Net.Testcontainers 做多服務整合測試時，reset 失效導致測試互相污染」的除錯歷程。草稿裡所有程式碼與行為描述都只是根據記憶、官方文件與原始碼閱讀寫成，**尚未經過實際編譯與執行驗證**。

本次任務要做三件事：

1. 建立一個可實際編譯執行的範例方案，把草稿裡的架構落地成真正的程式碼。
2. 在範例方案裡逐項驗證草稿的每一個技術主張，把實際輸出記錄下來。
3. 依照驗證結果改寫文章 —— 已實測的用肯定語氣、只有文件依據的引用官方文件、兩者皆無的刪除，絕不保留未經驗證的推論語氣。

這份文件只涵蓋**範例專案與測試專案的結構規劃**（對應任務的第一階段）。逐項驗證的執行與文章改寫是後續階段，由 writing-plans 產出的實作計畫驅動。

# 技術棧決策

| 項目 | 決定 | 理由 |
|---|---|---|
| Target framework | `net10.0` | 使用者指定，對齊本機安裝的 SDK（10.0.302） |
| 測試框架 | xUnit v3（3.2.2） | 版本最新、與 net10.0 搭配自然，也讓文章裡「v2 與 v3 的 `IAsyncLifetime` 差異」那一段能從真實的 v3 程式碼出發（`ValueTask InitializeAsync()`、`IAsyncDisposable`） |
| 測試執行器 | 標準 VSTest（`xunit.runner.visualstudio`） | 使用者選擇：避免 Microsoft Testing Platform 的 CLI 差異分散文章焦點 |
| WireMock 套件 | `WireMock.Net` / `WireMock.Net.Testcontainers`，以 NuGet 目前最新穩定版為準（查詢當下為 2.13.0） | 若實作中發現與已驗證過的 2.12.0（見下方參考專案）行為不同，於 `verification-results.md` 註明並視情況調整 |
| Container image | 明確釘住版本標籤，不用 `latest` | 避免遠端 image 漂移，比照參考專案的作法 |

# 參考專案：`kevintsengtw/securities-trading-integration-testing`

使用者提供的同作者正式專案，架構比本次的教學範例複雜得多（多資料庫、Kafka、Redis、診斷報告），但直接證實了幾件事，作為我們實作時的依據：

- `IWireMockAdminApi` 確實有 `ResetMappingsAsync`／`ResetRequestsAsync`／`GetMappingsAsync`／`GetRequestsAsync`／`PostMappingsAsync`／`GetHealthAsync`，`WireMockContainer` 確實有 `CreateWireMockAdminClient()`。
- xUnit v3 用 `ValueTask InitializeAsync()` / `ValueTask DisposeAsync()`，reset 放在 `InitializeAsync`（測試前）—— 與草稿的設計決策一致。
- Container image 明確釘版本（例如 `sheyenrath/wiremock.net-alpine:2.12.0`）。
- `IntegrationTestCollection` 明確加了 `[CollectionDefinition(Name, DisableParallelization = true)]`，並註明「這是必要的，不是效能取捨」——這跟草稿驗證項目 5 的假設（同一 collection 內本來就會依序執行、不需要額外設定）有潛在出入，**驗證 5 執行時要特別交叉確認這一點**，如果發現草稿假設不完整，要在文章裡誠實修正。

參考專案採用 Microsoft Testing Platform（`xunit.v3.mtp-v2`）作為測試執行器；本次範例**不**跟隨，改用標準 VSTest（使用者已確認）。

參考專案用具名屬性（`KycAdmin`／`MarketDataAdmin`／`BrokerAdmin`）管理三個固定服務；本次範例**不**跟隨，維持草稿原本的 `ConcurrentDictionary` 資料驅動設計 —— 因為草稿裡「`Dictionary` vs `ConcurrentDictionary`」整節討論正是以這個設計為載體，換成具名屬性會讓那節文字失去對應的程式碼。

# 方案結構

```
samples/
  WireMockDemo.sln
  src/
    WireMockDemo.Api/                      # 產品專案：最小化開戶 API
  tests/
    WireMockDemo.IntegrationTests/         # 完整實作草稿架構的整合測試
    WireMockDemo.Experiments/              # 逐項驗證草稿技術主張的實驗測試
```

一共 3 個 `.csproj`：1 個產品專案 + 2 個測試專案。「開戶主檔」「身分驗證」「金流」三個外部服務**不是**額外的專案，完全由 WireMock container 模擬 —— 這正是 WireMock 的用途，`WireMockDemo.Api` 裡有真正呼叫這三個外部服務的 client 程式碼，服務本身在測試時被 WireMock 取代。

## `src/WireMockDemo.Api`

```
src/WireMockDemo.Api/
  WireMockDemo.Api.csproj          # net10.0, Microsoft.NET.Sdk.Web
  Program.cs                       # minimal API + 3 個具名 HttpClient 註冊
  appsettings.json                 # 三個外部服務 BaseUrl 的預留位置（測試時由 WebApplicationFactory 覆寫）
  Models/
    OpenAccountRequest.cs          # ApplicantName, IdentityNo, InitialDeposit
    OpenAccountResponse.cs         # AccountNo, Status
  ExternalServices/
    OpenAccountApiClient.cs        # 呼叫 POST /api/accounts -> { AccountNo }
    IdentityApiClient.cs           # 呼叫 POST /api/verify -> { Verified }
    PaymentApiClient.cs            # 呼叫 POST /api/deposits -> { TransactionId, Status }
```

**唯一 endpoint：`POST /api/open-account`**。流程依序呼叫開戶主檔 → 身分驗證 → 金流；身分驗證失敗就短路回 400、不呼叫金流。這個短路設計是刻意的：讓「PaymentApi 有沒有被呼叫」成為一個可觀察的隔離檢查點（借用參考專案的 short-circuit assertion 手法），比單純比對 status code 更能抓到測試污染。

三個具名 `HttpClient`（`"OpenAccountApi"` / `"IdentityApi"` / `"PaymentApi"`）的 BaseAddress 從設定讀取，不寫死；沒有任何持久化或商業邏輯。

## `tests/WireMockDemo.IntegrationTests`

```
tests/WireMockDemo.IntegrationTests/
  WireMockDemo.IntegrationTests.csproj
  WireMockServices.cs               # 服務名稱常數類別（草稿原樣）
  Infrastructure/
    WireMockFixture.cs              # ConcurrentDictionary 資料驅動、平行啟動、ResetAllAsync 含殘留驗證、DisposeAsync 含孤兒回收
    WireMockStubExtensions.cs       # StubJsonAsync 擴充方法
    WireMockTestBase.cs             # InitializeAsync 呼叫 Fixture.ResetAllAsync()
    WireMockCollection.cs           # [CollectionDefinition("wiremock")]
  Tests/
    OpenAccountTests.cs
    PaymentFlowTests.cs
```

**草稿沒有明講、但範例要能實際跑起來就必須補上的部分：** 待測系統怎麼被啟動、HttpClient 怎麼指到三個動態 port。比照參考專案的做法，用 `WebApplicationFactory<Program>` 在測試行程內跑 `WireMockDemo.Api`；容器啟動完成、拿到三個實際 base URL 之後，透過 `ConfigureAppConfiguration` 注入。這部分會加進 `WireMockFixture`（或緊鄰它的一個小類別），**是範例專案需要、但非草稿原有內容**，實作時會明確標註。

**測試案例設計（刻意做成「污染敏感」）：**

- `OpenAccountTests`
  - `開戶成功_應回傳帳號`：三個服務都 stub 成功，驗證 200 與 `AccountNo`
  - `身分驗證失敗_應回傳400`：IdentityApi stub 為 `Verified:false`，驗證 400，並且斷言 PaymentApi 的 request count 是 0
  - `重複呼叫_應回傳目前stub的帳號而非前次殘留值`：用跟第一個測試不同的 `AccountNo` 值下 stub，斷言回傳的是新值而不是前一個測試留下的舊值 —— 專門設計來抓污染
- `PaymentFlowTests`：另一個測試類別，同樣標 `[Collection("wiremock")]`，驗證跨類別共用 fixture 時 request journal 不會互相污染計數

`WireMockFixture` 本身的基礎設施測試（三個 container 端點互不相同、reset 後 mapping 數量歸零等）放在 `Experiments` 專案的驗證 1／2，不在這裡重複，避免兩處測同一件事、之後改一邊忘了改另一邊。

## `tests/WireMockDemo.Experiments`

```
tests/WireMockDemo.Experiments/
  WireMockDemo.Experiments.csproj
  V1_AdminResetEndpointTests.cs        # 驗證1：/__admin/reset 狀態碼與副作用
  V2_ResetBehaviorTests.cs             # 驗證2：ResetMappingsAsync / reloadStaticMappings / ResetRequestsAsync
  V3_BugReproductionTests.cs           # 驗證3：重現原始 bug + 因果鏈
  V4_XunitLifecycleProbe.cs            # 驗證4：InitializeAsync/DisposeAsync 生命週期
  V5_ParallelExecutionTests.cs         # 驗證5：collection 內序列、跨 collection 平行
  V6_CollectionTypeBehaviorTests.cs    # 驗證6：Dictionary vs ConcurrentDictionary
  V7_TimingBenchmarkTests.cs           # 驗證7：啟動耗時
  V8_InProcessWireMockServerTests.cs   # 驗證8：in-process WireMockServer
```

### 兩項需要特殊處理才能維持「`dotnet test` 全部綠燈」的驗證

**驗證 4（生命週期）：** 要證明「`InitializeAsync` 拋例外時 `DisposeAsync` 不會被呼叫」，需要一個 fixture 故意在 `InitializeAsync` 拋例外，這在 `dotnet test` 底下會顯示成錯誤，破壞全綠的驗收標準。處理方式：把這類探測測試標上 xUnit Trait（例如 `Category=LifecycleProbe`），預設 `dotnet test` 不會執行它；驗證時另外用 `dotnet test --filter Category=LifecycleProbe` 單獨執行、記錄實際輸出（測試失敗/錯誤本身就是證據），並在 `verification-results.md` 裡說明這項的驗證方式與其他項不同。

**驗證 6（並行寫入 `Dictionary` 損壞）：** 本質上是在製造未定義行為，實際執行時可能拋出例外、造成死迴圈或安靜遺漏 key。每一輪寫入包在 `try/catch` 裡計數失敗次數與類型，而不是任由測試崩潰 —— 這樣不管失敗率多少，實驗本身仍是綠燈測試，回報的「失敗率」數字才是真正要的實測結果。若某次執行觸發了會讓整個 process 掛掉的損壞（機率低但存在），如實記錄，不為了綠燈弱化實驗的破壞力。

# 尚未在此規劃階段決定、留給實作計畫處理的事項

- Phase 1：實際查閱 `WireMock.Net.Testcontainers` / `WireMock.Net` 公開 API，確認草稿裡的方法名稱、型別是否正確可編譯
- Phase 2：逐項驗證的具體測試程式與 `verification-results.md` 的產出
- Phase 3：文章改寫（`wiremock-testcontainers-reset-published.md`）與 `changes-from-draft.md`
- 是否 `git init` 讓範例與文章的變更有版本紀錄（目前工作目錄尚未是 git repo）
