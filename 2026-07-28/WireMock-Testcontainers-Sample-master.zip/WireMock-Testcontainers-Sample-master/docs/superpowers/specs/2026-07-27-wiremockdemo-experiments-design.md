---
title: WireMockDemo.Experiments —— 逐項驗證草稿技術主張
date: 2026-07-27
status: 待實作
---

# 背景與目標

`articles/wiremock-testcontainers-reset.md` 這篇草稿的每一個技術主張，目前都只是根據記憶、官方文件與原始碼閱讀寫成，**尚未實際編譯執行驗證**。`WireMockDemo.Api` 與 `WireMockDemo.IntegrationTests`（已完成）只證明了草稿裡「最終修正版架構」本身可以編譯、可以通過測試，但草稿真正的論證核心——`/__admin/reset` 是否存在、原始 bug 能不能重現、xUnit 生命週期與平行執行規則、`Dictionary` 與 `ConcurrentDictionary` 的行為差異、實際計時數字、in-process `WireMockServer` 的行為——一項都還沒有實測過。

`WireMockDemo.Experiments` 這個子專案的目的，就是把原始任務說明〈階段二：逐項驗證〉列出的 8 項技術主張逐一寫成會實際執行的測試，把**實際輸出**（狀態碼、數量、耗時、例外訊息）記錄進 `docs/verification-results.md`，讓後續改寫文章時，每個主張都能落在「已實測」「引用官方文件」「刪除」三態之一。

過程中如果發現原始 8 項清單之外、但草稿裡同樣需要查證的主張，會一併處理並在 `verification-results.md` 註明；目前規劃階段沒有找到清單外的新項目（除了 V5 部分——先前查參考專案 `securities-trading-integration-testing` 時發現它明確設定 `DisableParallelization = true`，這點會在 V5 一併交叉確認）。

# 專案結構

```
samples/tests/WireMockDemo.Experiments/
  WireMockDemo.Experiments.csproj
  V1_AdminResetEndpointTests.cs
  V2_ResetBehaviorTests.cs
  V3_BugReproductionTests.cs
  V4_XunitLifecycleProbe.cs
  V5_ParallelExecutionTests.cs
  V6_CollectionTypeBehaviorTests.cs
  V7_TimingBenchmarkTests.cs
  V8_InProcessWireMockServerTests.cs
  TestData/StaticMappings/static-mapping.json
```

**不依賴 `WireMockDemo.Api`**，沒有 project reference——這 8 項驗證測的是 `WireMock.Net`、.NET 執行環境與 xUnit 本身的行為，不是我們寫的範例 API。

**套件**：`Microsoft.NET.Test.Sdk` 18.8.1、`xunit.v3` 3.2.2、`xunit.runner.visualstudio` 3.1.5、`AwesomeAssertions` 9.5.0（與 `IntegrationTests` 一致）、`WireMock.Net.Testcontainers` 2.13.0、另外加 `WireMock.Net`（驗證8的 in-process `WireMockServer` 需要，`WireMock.Net.Testcontainers` 套件本身不含這個型別）。

# 每項驗證的設計

每個驗證測試類別各自管理自己專屬的 container（`IAsyncLifetime` 直接寫在類別上），不透過共用 fixture——這批實驗彼此獨立，各自獨立閱讀、獨立執行最清楚，不需要像 `IntegrationTests` 那樣共用一份 `WireMockFixture`。

## V1：`/__admin/reset` 端點是否存在

全文最核心的論證。直接對啟動好的 container 送 `POST /__admin/reset`，記錄實際狀態碼；呼叫前後各查一次 `GetMappingsAsync()` 的數量，確認這個呼叫對 mapping 是否真的沒有副作用。草稿主張三點：.NET 版沒有這個端點、會回 404、無副作用——規劃階段已經直接查過 `wiremock/WireMock.Net` 原始碼的 `WireMockServer.Admin.cs` 路由註冊區塊，確認只有 `mappings/reset`、`requests/reset`、`scenarios/reset`、`scenarios/{name}/reset` 四條路由，沒有裸的 `reset`，這代表打 `/__admin/reset` 會落入一般的 stub 比對流程；但這只是原始碼層級的證據，仍然要跑出實際的狀態碼與副作用結果才算數。

## V2：reset 的實際行為

三個子項：
1. 灌入數筆 mapping 後呼叫 `ResetMappingsAsync()`，確認 `GetMappingsAsync()` 回傳空集合。
2. 用 `.WithMappings(path)` 從 `TestData/StaticMappings/static-mapping.json` 載入靜態 mapping，比較 `ResetMappingsAsync()`（預設 `reloadStaticMappings: false`）與 `ResetMappingsAsync(reloadStaticMappings: true)` 之後靜態 mapping 是否還在。
3. 確認 `ResetRequestsAsync()` 清的是 request log（`GetRequestsAsync()`）而不是 mapping：先下一個 mapping、打一次讓它產生 request log，呼叫 `ResetRequestsAsync()` 後，確認 mapping 還在但 request log 空了。

## V3：重現原始 bug（最有價值的一項）

不模擬「兩個 xUnit 測試互相污染」，改成直接驗證核心事實：
- 「有問題的 reset」（先用 `container.CreateClient()` 拿到的 `HttpClient` 手動 POST `/__admin/reset`，再呼叫 `ResetMappingsAsync()`）之後，mapping 是否依然殘留。
- 「正確的 reset」（只呼叫 `ResetMappingsAsync()`）之後，mapping 是否確實清空。

如果能重現，因果鏈直接用 `try/catch` 包住那段手動呼叫（`httpClient.PostAsync("/__admin/reset", null)` 後接 `EnsureSuccessStatusCode()`），捕捉實際拋出的例外型別與訊息，確認這個例外是否真的讓後面的 `ResetMappingsAsync()` 那行從未被執行——這是可以直接觀察的事實，不需要再用推論語氣。如果無法重現，如實記錄「無法重現」並說明嘗試過的排除方式。

## V4：xUnit 生命週期

兩個探測測試：
1. 測試方法拋例外時，`DisposeAsync` 是否仍會被呼叫。
2. `InitializeAsync` 拋例外時，對應的 `DisposeAsync` 是否不會被呼叫（草稿「孤兒 container」論述的前提）。

用檔案旗標記錄實際呼叫順序（`DisposeAsync` 寫入一個暫存檔，測試結束後讀取確認）。這兩個測試設計上就是要讓自己「失敗／出錯」才能證明生命週期規則，所以標 `[Trait("Category", "LifecycleProbe")]`，**不進預設 `dotnet test` 範圍**，用 `dotnet test --filter "Category=LifecycleProbe"` 單獨執行，把實際輸出記錄進 `verification-results.md`。

## V5：xUnit 平行執行行為

兩組情境：
- 同一個 `[Collection]` 的兩個測試類別，各自記錄起訖時間戳，斷言時間區間**不重疊**——這是 xUnit 的明文契約，可以放心 hard-assert。
- 沒有標 `[Collection]` 的兩個測試類別，同樣記錄起訖時間戳，但**只記錄觀察結果、不斷言一定重疊**（平不平行仍取決於排程，斷言死板反而製造假性 flaky）。

順帶交叉確認先前在參考專案發現的疑點：`[CollectionDefinition(Name, DisableParallelization = true)]` 是否真的有必要，還是同一 collection 內本來就會依序執行、這個設定只是防禦性寫法。

## V6：集合型別行為差異

- 並行寫入 `Dictionary`：1000 輪 × 16 執行緒，全程包 `try/catch` 計數失敗次數與例外型別，不會讓測試本身崩潰。
- `Dictionary` 在列舉過程中被修改是否拋 `InvalidOperationException`，`ConcurrentDictionary` 是否不會。
- `ConcurrentDictionary.Count` 是否需要取得所有內部鎖（用簡單的計時比較沒有直接的 API 可測「有沒有取鎖」，這項會改成引用官方文件語氣，不強行寫一個不可靠的效能測試去證明內部實作細節）。
- `ConcurrentDictionary.Values` 是否為快照：取得 `.Values` 並具體化成 `List` 之後，修改字典，確認具體化後的 `List` 不受影響；另外呼叫兩次 `.Values` 確認每次都是新的快照。

這項不需要 Trait 排除——`try/catch` 已經確保測試本身不會崩潰，1000×16 的迴圈跑起來是幾秒等級，不到需要另外排除的程度。

## V7：計時數字

- 單一 container 啟動耗時，重複 5 次取中位數。
- 三個 container 循序啟動 vs 平行啟動（`Task.WhenAll`）的總耗時比較，重複 5 次取中位數。
- in-process `WireMockServer.Start()` 啟動耗時，重複 5 次取中位數。
- 記錄測試環境：`RuntimeInformation.OSDescription`、`Environment.ProcessorCount`、`RuntimeInformation.FrameworkDescription`、`docker --version`（透過 `Process.Start` 取得）。

跟驗證4一樣標 `[Trait("Category", "TimingBenchmark")]`，不進預設 `dotnet test` 範圍，用 `dotnet test --filter "Category=TimingBenchmark"` 單獨執行。

## V8：in-process `WireMockServer`

- 確認 `WireMockServer.Start()` 起來的 server 沒有啟用 admin 介面（打 `/__admin/mappings` 應該連不上或回錯誤），`StartWithAdminInterface(...)` 才有。
- 寫一個「每個測試方法一個全新 server」的最小範例，用 `server.Given(Request.Create()...).RespondWith(Response.Create()...)` 這組 fluent API 設定 stub 並實際打一次確認回應正確。

不需要 Docker，跑起來快，留在預設 `dotnet test` 範圍內。

# 驗收範圍與 Trait 慣例

預設「全綠」的 `dotnet test` 指令是：

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category!=LifecycleProbe&Category!=TimingBenchmark"
```

被排除的兩類（V4、V7）各自有獨立指令：

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category=LifecycleProbe"
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category=TimingBenchmark"
```

三個指令的實際輸出都要記錄進 `docs/verification-results.md`。

# `docs/verification-results.md` 的格式

每個驗證項目一個章節，包含：實際執行的指令、實際輸出（狀態碼、數量、耗時數字、例外訊息等，直接貼實際文字或整理成表格）、以及一句話結論（confirmed / refuted / undetermined，對照草稿原本的主張）。不寫「預期會是」這種未執行的描述。

# 實作拆成 3 份計畫

一次寫完全部 8 項驗證的實作計畫過大，拆成 3 份，每份都能獨立實作、驗收：

1. **Reset 行為**（驗證1-3）——含 `WireMockDemo.Experiments` 專案骨架，這組是全文最核心的論證。
2. **xUnit 執行行為**（驗證4-5）。
3. **集合型別／計時／in-process server**（驗證6-8）。

三份計畫共用同一份本設計文件與同一份 `verification-results.md`，只是分批實作。

# 尚未在此規劃階段決定、留給各份實作計畫處理的事項

- V2 靜態 mapping 測試用的 `static-mapping.json` 實際內容
- V3 因果鏈驗證的確切例外型別斷言（要等實際跑過才知道 `EnsureSuccessStatusCode()` 拋出的確切訊息）
- V5 記錄時間戳與交叉檢查的具體實作方式（靜態集合、檔案，或其他）
- V6 `ConcurrentDictionary.Count` 取鎖行為若無法用可靠的方式測出，改寫成引用官方文件語氣的具體措辭
- V7 計時數字的實際基準環境紀錄（本機 CPU、Docker 版本等要等實際執行時查）
