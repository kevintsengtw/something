# WireMockDemo.Experiments — 集合型別／計時／in-process Server 驗證（驗證6-8）Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在 `WireMockDemo.Experiments` 專案裡實作草稿〈發表前待驗證清單〉的驗證 6（`Dictionary` 與 `ConcurrentDictionary` 行為差異）、驗證 7（計時數字）、驗證 8（in-process `WireMockServer`），完成後這 8 項驗證全數有實測依據。

**Architecture:** 驗證6是純 .NET 記憶體內實驗，不碰 Docker；驗證7、8 需要額外的 `WireMock.Net` 套件（`WireMockServer` 這個 in-process server 型別不在 `WireMock.Net.Testcontainers` 套件裡）。驗證6的並行寫入壓力測試用獨立 `Thread`（不是 `Task.Run`）搭配逾時偵測，避免 `Dictionary` 損壞造成的潛在無限迴圈耗盡共用執行緒池、拖垮整個測試行程。

**Tech Stack:** net10.0、xUnit v3（3.2.2）+ `xunit.runner.visualstudio`（VSTest）、`AwesomeAssertions`（9.5.0）、`WireMock.Net.Testcontainers`（2.13.0）、新增 `WireMock.Net`（2.13.0）。

## Global Constraints

- Target framework：`net10.0`
- 所有非同步呼叫傳遞 `TestContext.Current.CancellationToken`
- 驗證7的所有測試標 `[Trait("Category", "TimingBenchmark")]`，**不進預設 `dotnet test` 範圍**——會實際啟動多輪 container，跑起來比其他驗證慢很多
- 驗證6、8不需要 Trait 排除，留在預設範圍
- 本計畫接手後，`WireMockDemo.Experiments` 的「預設全綠」指令變成：
  ```bash
  dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category!=LifecycleProbe&Category!=TimingBenchmark"
  ```
  這是原本規劃就設計好的最終形態，本計畫完成後不會再變動
- 驗證7、8需要在 `WireMockDemo.Experiments.csproj` 新增 `WireMock.Net` 2.13.0 套件參照（`WireMockServer`、`StartWithAdminInterface`、`Request.Create()`／`Response.Create()` fluent API 都在這個套件，`WireMock.Net.Testcontainers` 本身不含這些型別）
- 工作目錄已是 git repository，每個任務結尾都要 `git add` + `git commit`
- 本計畫完成後，8 項驗證（草稿〈發表前待驗證清單〉全部項目）都有實測依據，這是 `WireMockDemo.Experiments` 整個子專案的最後一份實作計畫
- 承接 `docs/superpowers/specs/2026-07-27-wiremockdemo-experiments-design.md`，`WireMockDemo.Experiments.csproj` 專案骨架、`docs/verification-results.md` 前五項驗證的紀錄格式已存在

---

## File Structure

```
samples/tests/WireMockDemo.Experiments/
  V6_CollectionTypeBehaviorTests.cs   # 驗證6：Dictionary vs ConcurrentDictionary
  V7_TimingBenchmarkTests.cs          # 驗證7：計時數字
  V8_InProcessWireMockServerTests.cs  # 驗證8：in-process WireMockServer
```

---

## Task 1: 驗證6 —— 集合型別行為差異

**Files:**
- Create: `samples/tests/WireMockDemo.Experiments/V6_CollectionTypeBehaviorTests.cs`

**Interfaces:**
- Produces: 無（獨立驗證，後續任務不依賴）

- [ ] **Step 1: 寫入 `V6_CollectionTypeBehaviorTests.cs`**

```csharp
using System.Collections.Concurrent;
using AwesomeAssertions;
using Xunit;

namespace WireMockDemo.Experiments;

public sealed class V6_CollectionTypeBehaviorTests
{
    [Fact]
    public void 並行寫入Dictionary_1000輪x16執行緒_統計失敗率與逾時次數()
    {
        const int rounds = 1000;
        const int threadCount = 16;
        var failureCount = 0;
        var timeoutCount = 0;
        var silentCorruptionCount = 0;
        var exceptionTypeCounts = new ConcurrentDictionary<string, int>();

        for (var round = 0; round < rounds; round++)
        {
            var dictionary = new Dictionary<int, int>();
            var threads = new Thread[threadCount];

            for (var t = 0; t < threadCount; t++)
            {
                var key = t;
                threads[t] = new Thread(() =>
                {
                    try
                    {
                        dictionary[key] = key;
                    }
                    catch (Exception exception)
                    {
                        Interlocked.Increment(ref failureCount);
                        exceptionTypeCounts.AddOrUpdate(exception.GetType().Name, 1, (_, count) => count + 1);
                    }
                })
                {
                    IsBackground = true,
                };
                threads[t].Start();
            }

            var allJoined = true;
            foreach (var thread in threads)
            {
                if (!thread.Join(TimeSpan.FromMilliseconds(500)))
                {
                    allJoined = false;
                }
            }

            if (!allJoined)
            {
                timeoutCount++;
                continue;
            }

            if (dictionary.Count != threadCount)
            {
                silentCorruptionCount++;
            }
        }

        TestContext.Current.TestOutputHelper?.WriteLine($"並行寫入 Dictionary：{rounds} 輪 x {threadCount} 執行緒");
        TestContext.Current.TestOutputHelper?.WriteLine($"  例外失敗次數：{failureCount}");
        TestContext.Current.TestOutputHelper?.WriteLine($"  疑似逾時（執行緒卡住超過 500ms）輪數：{timeoutCount}");
        TestContext.Current.TestOutputHelper?.WriteLine($"  無例外但 key 數量不對（靜默損壞）輪數：{silentCorruptionCount}");
        foreach (var (type, count) in exceptionTypeCounts)
        {
            TestContext.Current.TestOutputHelper?.WriteLine($"  例外型別 {type}：{count} 次");
        }
    }

    [Fact]
    public void Dictionary列舉中被修改_應拋出InvalidOperationException()
    {
        var dictionary = new Dictionary<int, int> { [1] = 1, [2] = 2 };

        var act = () =>
        {
            foreach (var _ in dictionary)
            {
                dictionary[3] = 3;
            }
        };

        act.Should().Throw<InvalidOperationException>();
    }

    [Fact]
    public void ConcurrentDictionary列舉中被修改_不會拋出例外()
    {
        var dictionary = new ConcurrentDictionary<int, int>(new Dictionary<int, int> { [1] = 1, [2] = 2 });

        var act = () =>
        {
            foreach (var _ in dictionary)
            {
                dictionary[3] = 3;
            }
        };

        act.Should().NotThrow();
    }

    [Fact]
    public void ConcurrentDictionaryValues_具體化後修改字典_具體化的List不受影響()
    {
        var dictionary = new ConcurrentDictionary<int, int> { [1] = 1, [2] = 2 };

        var materializedValues = dictionary.Values.ToList();
        dictionary[3] = 3;

        materializedValues.Should().HaveCount(2);
        materializedValues.Should().BeEquivalentTo(new[] { 1, 2 });
    }

    [Fact]
    public void ConcurrentDictionaryValues_每次呼叫都是新的快照()
    {
        var dictionary = new ConcurrentDictionary<int, int> { [1] = 1 };

        var firstSnapshot = dictionary.Values;
        dictionary[2] = 2;
        var secondSnapshot = dictionary.Values;

        firstSnapshot.Should().HaveCount(1);
        secondSnapshot.Should().HaveCount(2);
    }
}
```

第一個測試刻意用獨立 `Thread`（不是 `Task.Run`）——如果 `Dictionary` 損壞真的造成無限迴圈，卡住的會是專屬的背景執行緒，不會佔用 xUnit 與其他非同步機制共用的執行緒池，才不會拖垮整個測試行程。`ConcurrentDictionary.Count` 是否需要取得所有內部鎖沒有寫測試——沒有可靠的公開 API 能直接觀察「有沒有取鎖」，改寫文章時這一點會用引用官方文件的語氣處理，不強行寫一個不可靠的效能測試去證明內部實作細節。

- [ ] **Step 2: 執行測試，記錄實際結果**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V6_" --logger "console;verbosity=detailed"
```

Expected: 5 個測試通過（並行寫入的壓力測試本身不會因為偵測到損壞而判定失敗，它只是記錄統計數字）。把並行寫入測試印出的失敗次數／逾時輪數／靜默損壞輪數／例外型別統計實際數字記下來——不管數字是 0 還是有非 0 的損壞紀錄，這都是有效的實測結果。如果這個測試本身逾時掛住（例如太多輪同時卡住導致整個測試行程沒有在合理時間內結束），先降低 `rounds` 到一個能跑完的數字（例如先試 100 輪），並在 `verification-results.md` 裡記錄下調過的實際輪數與原因。

- [ ] **Step 3: Commit**

```bash
git add samples/tests/WireMockDemo.Experiments
git commit -m "test: add V6 collection type behavior verification"
```

---

## Task 2: 驗證7 —— 計時數字

**Files:**
- Create: `samples/tests/WireMockDemo.Experiments/V7_TimingBenchmarkTests.cs`
- Modify: `samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj`

**Interfaces:**
- Consumes: `WireMockContainerBuilder`（已在專案內）
- Produces: 無（獨立驗證，後續任務不依賴）

- [ ] **Step 1: 修改 csproj，新增 `WireMock.Net` 套件參照**

在 `WireMockDemo.Experiments.csproj` 的套件 `<ItemGroup>` 裡，`WireMock.Net.Testcontainers` 那一行之後加入：

```xml
    <PackageReference Include="WireMock.Net" Version="2.13.0" />
```

- [ ] **Step 2: 寫入 `V7_TimingBenchmarkTests.cs`**

```csharp
using System.Diagnostics;
using System.Runtime.InteropServices;
using WireMock.Net.Testcontainers;
using WireMock.Server;
using Xunit;

namespace WireMockDemo.Experiments;

[Trait("Category", "TimingBenchmark")]
public sealed class V7_TimingBenchmarkTests
{
    private const int Repetitions = 5;

    [Fact]
    public async Task 單一Container啟動耗時_5次取中位數()
    {
        var durations = new List<double>();

        for (var i = 0; i < Repetitions; i++)
        {
            var stopwatch = Stopwatch.StartNew();
            await using var container = new WireMockContainerBuilder().Build();
            await container.StartAsync();
            stopwatch.Stop();
            durations.Add(stopwatch.Elapsed.TotalMilliseconds);
        }

        LogDurations("單一 container 啟動耗時", durations);
    }

    [Fact]
    public async Task 三個Container循序vs平行啟動耗時比較_5次取中位數()
    {
        var sequentialDurations = new List<double>();
        for (var i = 0; i < Repetitions; i++)
        {
            var stopwatch = Stopwatch.StartNew();
            await using var c1 = new WireMockContainerBuilder().Build();
            await using var c2 = new WireMockContainerBuilder().Build();
            await using var c3 = new WireMockContainerBuilder().Build();
            await c1.StartAsync();
            await c2.StartAsync();
            await c3.StartAsync();
            stopwatch.Stop();
            sequentialDurations.Add(stopwatch.Elapsed.TotalMilliseconds);
        }

        var parallelDurations = new List<double>();
        for (var i = 0; i < Repetitions; i++)
        {
            var stopwatch = Stopwatch.StartNew();
            await using var c1 = new WireMockContainerBuilder().Build();
            await using var c2 = new WireMockContainerBuilder().Build();
            await using var c3 = new WireMockContainerBuilder().Build();
            await Task.WhenAll(c1.StartAsync(), c2.StartAsync(), c3.StartAsync());
            stopwatch.Stop();
            parallelDurations.Add(stopwatch.Elapsed.TotalMilliseconds);
        }

        LogDurations("三個 container 循序啟動", sequentialDurations);
        LogDurations("三個 container 平行啟動", parallelDurations);
    }

    [Fact]
    public void InProcessWireMockServer啟動耗時_5次取中位數()
    {
        var durations = new List<double>();

        for (var i = 0; i < Repetitions; i++)
        {
            var stopwatch = Stopwatch.StartNew();
            using var server = WireMockServer.Start();
            stopwatch.Stop();
            durations.Add(stopwatch.Elapsed.TotalMilliseconds);
            server.Stop();
        }

        LogDurations("in-process WireMockServer 啟動耗時", durations);
    }

    [Fact]
    public void 記錄測試環境資訊()
    {
        var dockerVersion = GetDockerVersion();

        TestContext.Current.TestOutputHelper?.WriteLine($"OS：{RuntimeInformation.OSDescription}");
        TestContext.Current.TestOutputHelper?.WriteLine($"CPU 核心數：{Environment.ProcessorCount}");
        TestContext.Current.TestOutputHelper?.WriteLine($".NET Runtime：{RuntimeInformation.FrameworkDescription}");
        TestContext.Current.TestOutputHelper?.WriteLine($"Docker：{dockerVersion}");
    }

    private static void LogDurations(string label, List<double> durations)
    {
        var sorted = durations.OrderBy(d => d).ToList();
        var median = sorted[sorted.Count / 2];
        TestContext.Current.TestOutputHelper?.WriteLine(
            $"{label}（{sorted.Count} 次）：{string.Join(", ", sorted.Select(d => $"{d:F0}ms"))}，中位數：{median:F0}ms");
    }

    private static string GetDockerVersion()
    {
        try
        {
            var startInfo = new ProcessStartInfo("docker", "--version")
            {
                RedirectStandardOutput = true,
                UseShellExecute = false,
            };
            using var process = Process.Start(startInfo);
            var output = process!.StandardOutput.ReadToEnd().Trim();
            process.WaitForExit();
            return output;
        }
        catch (Exception exception)
        {
            return $"無法取得（{exception.Message}）";
        }
    }
}
```

- [ ] **Step 3: 執行測試，記錄實際結果**

```bash
dotnet build samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category=TimingBenchmark" --logger "console;verbosity=detailed"
```

Expected: 4 個測試通過（這個檔案的測試會實跑很多輪 container，耗時明顯比其他驗證久，屬正常）。把每個測試印出的實際毫秒數（單一 container、三個循序、三個平行、in-process server）與環境資訊（OS、CPU 核心數、.NET Runtime、Docker 版本）記下來，準備寫進 `verification-results.md`。如果 `WireMock.Server` 或 `WireMockServer.Start()` 的命名空間、簽章跟程式碼裡寫的不一致導致編譯失敗，先用 `dotnet build` 的錯誤訊息確認實際的型別/命名空間，修正後再繼續。

- [ ] **Step 4: Commit**

```bash
git add samples/tests/WireMockDemo.Experiments
git commit -m "test: add V7 timing benchmark verification"
```

---

## Task 3: 驗證8 —— in-process `WireMockServer`

**Files:**
- Create: `samples/tests/WireMockDemo.Experiments/V8_InProcessWireMockServerTests.cs`

**Interfaces:**
- Consumes: `WireMockServer`（`WireMock.Net` 套件，Task 2 已加入參照）
- Produces: 無

- [ ] **Step 1: 寫入 `V8_InProcessWireMockServerTests.cs`**

```csharp
using System.Net;
using AwesomeAssertions;
using WireMock.RequestBuilders;
using WireMock.ResponseBuilders;
using WireMock.Server;
using Xunit;

namespace WireMockDemo.Experiments;

public sealed class V8_InProcessWireMockServerTests
{
    [Fact]
    public async Task StartWithoutAdminInterface_AdminEndpoint應回傳404()
    {
        using var server = WireMockServer.Start();

        using var httpClient = new HttpClient { BaseAddress = new Uri(server.Url!) };
        var response = await httpClient.GetAsync("/__admin/mappings", TestContext.Current.CancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task StartWithAdminInterface_AdminEndpoint應可正常存取()
    {
        using var server = WireMockServer.StartWithAdminInterface();

        using var httpClient = new HttpClient { BaseAddress = new Uri(server.Url!) };
        var response = await httpClient.GetAsync("/__admin/mappings", TestContext.Current.CancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }

    [Fact]
    public async Task 每個測試一個全新Server_使用GivenRespondWith設定Stub()
    {
        using var server = WireMockServer.Start();

        server
            .Given(Request.Create().WithPath("/api/ping").UsingGet())
            .RespondWith(Response.Create().WithStatusCode(200).WithBody("pong"));

        using var httpClient = new HttpClient { BaseAddress = new Uri(server.Url!) };
        var response = await httpClient.GetAsync("/api/ping", TestContext.Current.CancellationToken);
        var body = await response.Content.ReadAsStringAsync(TestContext.Current.CancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.OK);
        body.Should().Be("pong");
    }
}
```

- [ ] **Step 2: 執行測試，記錄實際結果**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V8_" --logger "console;verbosity=detailed"
```

Expected: 3 個測試通過。如果 `WireMockServer.Start()` 起來的 server 其實**不是**回 404（例如直接拒絕連線、或回其他狀態碼），如實記錄實際的狀態碼或例外，不要調整斷言硬湊出 404。

- [ ] **Step 3: Commit**

```bash
git add samples/tests/WireMockDemo.Experiments
git commit -m "test: add V8 in-process WireMockServer verification"
```

---

## Task 4: 最終驗證 + 完成 `docs/verification-results.md`

**Files:**
- 無新檔案，純驗證與文件更新

**Interfaces:**
- 無

- [ ] **Step 1: 全專案建置**

```bash
dotnet build samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj
```

Expected: `Build succeeded. 0 Warning(s) 0 Error(s)`

- [ ] **Step 2: 執行「預設全綠」範圍的測試（最終形態，同時排除 LifecycleProbe 與 TimingBenchmark）**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category!=LifecycleProbe&Category!=TimingBenchmark"
```

Expected: 驗證1-3（8個）+ 驗證5（4個）+ 驗證6（5個）+ 驗證8（3個）= 20 個測試全數通過，0 個失敗。

- [ ] **Step 3: 確認沒有殘留的 wiremock container**

```bash
docker ps -a --filter "ancestor=sheyenrath/wiremock.net-alpine"
```

Expected: 空清單（驗證7單獨執行時啟動的 container 也應該都已經被 `await using` 正確釋放）。

- [ ] **Step 4: 把 Task 1-3 的實際輸出整理進 `docs/verification-results.md`**

在既有的 `docs/verification-results.md` 檔案裡，於「## 驗證 5」章節之後、「## 小結」章節之前，插入「## 驗證 6」「## 驗證 7」「## 驗證 8」三個新章節，格式比照既有章節（草稿主張、執行指令、實際輸出、結論）。驗證7的章節需要包含完整的測試環境紀錄（OS、CPU 核心數、.NET Runtime、Docker 版本、實測的中位數毫秒數）。同時把文件最後的「小結」段落改成：8 項驗證全數完成，草稿裡不再有未經驗證的技術主張。

- [ ] **Step 5: Commit**

```bash
git add docs/verification-results.md
git commit -m "docs: record V6-V8 verification results, complete all 8 verifications"
```

---

## Self-Review 記錄

- **Spec coverage：** 對照 `docs/superpowers/specs/2026-07-27-wiremockdemo-experiments-design.md` 的驗證 6、7、8 段落——並行寫入損壞統計、列舉中修改的例外行為、`.Values` 快照行為（Task 1）；三種計時數字與環境紀錄（Task 2）；admin 介面開關與 fluent API 最小範例（Task 3）均有對應任務。`docs/verification-results.md` 的最終更新在 Task 4。
- **Placeholder scan：** 全文檢查過，沒有「TBD」字樣；「如實記錄、不調整斷言硬湊結果」是刻意的方法論指引，跟前兩份計畫一致，不是未完成的佔位內容。
- **Type consistency：** `V7_TimingBenchmarkTests` 與 `V8_InProcessWireMockServerTests` 都依賴 Task 2 Step 1 新增的 `WireMock.Net` 套件參照；`LogDurations` 輔助方法只在 `V7_TimingBenchmarkTests` 內部使用，沒有跨檔案依賴。

---

**Plan complete and saved to `docs/superpowers/plans/2026-07-27-wiremockdemo-experiments-collections-timing-inprocess.md`. Two execution options:**

**1. Subagent-Driven (recommended)** - 每個任務派一個新的 subagent 執行，任務之間我會 review，適合快速迭代
**2. Inline Execution** - 在目前這個對話裡直接照 executing-plans 逐批執行，設檢查點讓你 review

**你要選哪一種？**
