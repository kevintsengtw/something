# 文章改寫 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 把 `articles/wiremock-testcontainers-reset.md`（草稿）依照 `docs/verification-results.md` 的實測結果改寫成 `articles/wiremock-testcontainers-reset-published.md`（發表版），並產出 `docs/changes-from-draft.md`。

**Architecture:** 逐節改寫，每個任務對應草稿的一組相鄰章節，改寫時同步寫入 `docs/changes-from-draft.md` 的對應條目，最後做一次全文自我審閱與驗收確認。

**Tech Stack:** 純 Markdown 文件撰寫，不涉及程式碼建置。

## Global Constraints

- 保留草稿的敘事結構（除錯歷程 + 解法的順序）、正體中文、既有 front matter 欄位
- 移除 `draft: true`、開頭的草稿警語、文末〈發表前待驗證清單〉整節
- 每一段程式碼都要能在 `samples/` 目錄找到對應檔案，唯一例外是「第一版架構」的 naive 示範（改成純文字描述，不放程式碼）
- xUnit 主線程式碼一律用 v3（`ValueTask`），v2 只在專門的差異小節提及
- 沒有任何「應該」「可能」「理論上」這種語氣用來描述本可實測的行為——已實測的用肯定語氣，只有文件依據的引用來源，兩者皆無的刪除
- 驗證6「並行寫入 Dictionary 損壞未重現」只寫事實（0/1000 輪失敗），不寫「為什麼沒重現」的推測
- `DisableParallelization = true` 的新發現收錄進「排查第一站：平行執行」章節
- 驗證環境段落放在文章**開頭**（front matter 之後、前言之前）
- 本計畫是寫作任務，不是程式碼任務：每個任務的 Step 直接是「改寫 `articles/wiremock-testcontainers-reset-published.md` 的哪個章節、必須包含哪些具體內容點」，不在計畫文件裡預先寫好整段最終文字（草稿本身已經 710 行，若在計畫裡再完整複寫一次發表版全文，等於重複兩倍的內容，且執行者與撰寫計畫者是同一個 agent、同一個 session，沒有交接的必要）。每個 Step 列出的「必須包含的內容點」都是具體、可核對的，不是空泛的「補充適當內容」。

---

## File Structure

```
articles/
  wiremock-testcontainers-reset.md            # 草稿，不修改
  wiremock-testcontainers-reset-published.md  # 新建，發表版
docs/
  changes-from-draft.md                       # 新建，給作者 review 用
```

---

## Task 1: 建立發表版檔案骨架 + 驗證環境段落 + 前言 + 背景

**Files:**
- Create: `articles/wiremock-testcontainers-reset-published.md`
- Create: `docs/changes-from-draft.md`（先建立骨架，後續任務逐條補充）

**Interfaces:**
- Consumes: `articles/wiremock-testcontainers-reset.md` 第 1-40 行（front matter 到「背景：為什麼需要多個 Container」結尾）、`docs/verification-results.md` 的「測試環境」章節
- Produces: 無

- [ ] **Step 1: 複製草稿 front matter，移除 `draft: true`**

保留 `title`／`date`／`tags`／`categories`／`description` 欄位，`date` 改成今天的改寫日期。

- [ ] **Step 2: 移除開頭的草稿警語 blockquote**

草稿第 20 行的「> **草稿，尚未發表。**...」整段不保留。

- [ ] **Step 3: 標題之後、前言之前，加入「驗證環境」段落**

必須包含的內容點（取自 `docs/verification-results.md` 的「測試環境」章節）：
- OS：Windows 11 Pro 10.0.26200
- .NET SDK 10.0.302（測試執行期 .NET 10.0.10 runtime）
- Docker 29.6.2
- `WireMock.Net` / `WireMock.Net.Testcontainers` 2.13.0
- xUnit v3 3.2.2（`xunit.runner.visualstudio` 3.1.5）
- `AwesomeAssertions` 9.5.0
- 一句話說明：本文所有程式碼與數字都來自 `samples/` 目錄下的範例專案實際執行結果，附上目錄路徑

- [ ] **Step 4: 前言段落**

沿用草稿前言（第 22-30 行）的內容與語氣，只需微調一句話，說明這篇文章的程式碼與數字都已實際驗證過。

- [ ] **Step 5: 背景：為什麼需要多個 Container**

沿用草稿第 32-40 行，這段是架構理由（非可實測的行為主張），文字不需要大改。

- [ ] **Step 6: 在 `docs/changes-from-draft.md` 建立骨架**

```markdown
# 改寫紀錄

給作者 review 用，不對外發表。逐條記錄跟草稿不同之處與原因，對照 `docs/verification-results.md` 的驗證項目編號。

## Front matter 與開頭

- 移除 `draft: true`。
- 移除草稿警語 blockquote。
- 新增「驗證環境」段落，放在標題之後、前言之前，內容取自 verification-results.md 的測試環境章節。
```

- [ ] **Step 7: Commit**

```bash
git add articles/wiremock-testcontainers-reset-published.md docs/changes-from-draft.md
git commit -m "docs: start published article rewrite - intro and environment section"
```

---

## Task 2: 第一版架構

**Files:**
- Modify: `articles/wiremock-testcontainers-reset-published.md`
- Modify: `docs/changes-from-draft.md`

**Interfaces:**
- Consumes: 草稿第 42-125 行；`samples/tests/WireMockDemo.Experiments/V1_AdminResetEndpointTests.cs`、`V2_ResetBehaviorTests.cs` 裡實際用過的 `PostMappingAsync` 單筆寫法
- Produces: 無

- [ ] **Step 1: single container 多路徑範例，換成真實用過的單筆 `PostMappingAsync` 寫法**

草稿原本示範 `PostMappingsAsync`（複數、批次陣列）——範例專案裡從未實際測過這個批次寫法，一律用 `admin.PostMappingAsync(new MappingModel { ... })` 逐筆呼叫（對照 `WireMockStubExtensions.StubJsonAsync` 的實際實作）。程式碼範例直接引用 `V1_AdminResetEndpointTests.cs` 裡建立 mapping 那幾行的寫法（`Request = new RequestModel { Path = ..., Methods = ... }`、`Response = new ResponseModel { StatusCode = ... }`）。

- [ ] **Step 2: naive 版 `WireMockFixture`（`Dictionary`、逐一手刻屬性）——程式碼區塊改成純文字描述**

不放程式碼。用文字說明「最初的寫法是每個服務各自宣告一個欄位、手動指派，服務一多就是重複的樣板；容器啟動用循序 `await`，沒有平行化」，保留敘事節奏（後面章節會講為什麼要改成資料驅動）。明確加一句：這個早期版本沒有實際寫成範例專案的一部分，下文看到的程式碼都是最終版本。

- [ ] **Step 3: 在 `docs/changes-from-draft.md` 補上這段的條目**

```markdown
## 第一版架構

- single container 範例改用單筆 `PostMappingAsync`，不用草稿原本的批次 `PostMappingsAsync`——後者沒有在範例專案裡實際測過。
- naive 版 `WireMockFixture` 的程式碼區塊改成純文字描述——範例專案沒有實作這個「錯誤示範」版本，沒有對應的真實檔案可以引用。
```

- [ ] **Step 4: Commit**

```bash
git add articles/wiremock-testcontainers-reset-published.md docs/changes-from-draft.md
git commit -m "docs: rewrite article section - first architecture version"
```

---

## Task 3: 排查第一站（平行執行）、第二站（reset 涵蓋範圍）、第三站（靜態 mapping）

**Files:**
- Modify: `articles/wiremock-testcontainers-reset-published.md`
- Modify: `docs/changes-from-draft.md`

**Interfaces:**
- Consumes: 草稿第 127-196 行；`docs/verification-results.md` 驗證2、驗證5章節
- Produces: 無

- [ ] **Step 1: 排查第一站：平行執行——換成驗證5實測數據**

必須包含的內容點：
- 同一個 `V5Same` collection 的兩個測試類別實測結果：`ClassA` 931080-931382、`ClassB` 931401-931710（Unix 毫秒），沒有重疊——確認序列執行，且**沒有設定** `DisableParallelization`
- 沒標 `[Collection]` 的兩個類別：`ClassC` 931079-931382、`ClassD` 931080-931382，幾乎完全重疊——確認會平行
- 新增段落：交叉確認 `securities-trading-integration-testing` 參考專案的 `DisableParallelization = true` 設定，實測證明這個設定**不是**「同 collection 內序列執行」的必要條件（那是 xUnit 的預設保證），比較可能是防禦性寫法

- [ ] **Step 2: 排查第二站：reset 有清到全部嗎——維持原有敘事，`ResetMappingsAsync` / `ResetRequestsAsync` 的區分換成驗證2的實測描述**

必須包含的內容點：`ResetRequestsAsync()` 清的是 request log、不影響 mapping，這點已用 `GetMappingsAsync()` 仍是 1 筆、`GetRequestsAsync()` 變成 0 筆的實測結果確認（驗證2）。

- [ ] **Step 3: 排查第三站：靜態 mapping 與持久化——換成驗證2實測結果**

必須包含的內容點：
- 用 `.WithMappings(...)` 載入靜態 mapping 後，預設的 `ResetMappingsAsync()`（`reloadStaticMappings: false`）會讓它從 1 筆變 0 筆——不會自動回來
- `ResetMappingsAsync(reloadStaticMappings: true)` 之後變回 1 筆——確認會重新載入
- `.WithMappings(...)` 的 bind mount 在 Windows + Docker Desktop 環境下實測正常，沒有檔案共享問題（可以當一句補充註記）

- [ ] **Step 4: 在 `docs/changes-from-draft.md` 補上這段的條目**

```markdown
## 排查第一站～第三站

- 平行執行章節換成驗證5實測時間戳記，新增 `DisableParallelization` 交叉確認（原本8項清單外的發現）。
- reset 涵蓋範圍、靜態 mapping 兩段換成驗證2的實測數字，語氣從推論改成確定。
```

- [ ] **Step 5: Commit**

```bash
git add articles/wiremock-testcontainers-reset-published.md docs/changes-from-draft.md
git commit -m "docs: rewrite article sections - parallel execution and reset coverage"
```

---

## Task 4: 讓程式自己說話（診斷）、真兇、為什麼會這樣（含因果鏈改寫）

**Files:**
- Modify: `articles/wiremock-testcontainers-reset-published.md`
- Modify: `docs/changes-from-draft.md`

**Interfaces:**
- Consumes: 草稿第 197-276 行；`samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockFixture.cs` 的 `ResetAllAsync`；`docs/verification-results.md` 驗證1、驗證3章節
- Produces: 無

這是全文改動幅度最大的一個任務——因果鏈那段是整個驗證計畫最有價值的成果。

- [ ] **Step 1: 讓程式自己說話：加上診斷——程式碼換成真實 `WireMockFixture.ResetAllAsync()`**

直接引用 `samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockFixture.cs` 裡 `ResetAllAsync` 方法的實際程式碼（`foreach (var (name, admin) in _admins)`、`ResetMappingsAsync()`、`ResetRequestsAsync()`、殘留檢查拋 `InvalidOperationException` 那段）。

- [ ] **Step 2: 真兇：一段多餘的 `/__admin/reset`——換成驗證1、3的實測狀態碼**

必須包含的內容點：`POST /__admin/reset` 實測回傳 `404 NotFound`，前後 mapping 數量不變（驗證1）；「有問題的 reset」（手動打 `/__admin/reset` 後接 `ResetMappingsAsync()`）實測後 mapping 確實殘留 1 筆，「正確的 reset」實測後確實清空（驗證3）。

- [ ] **Step 3: 為什麼會這樣？第一個事實——換成驗證1的實測結果 + 原始碼查證**

必須包含的內容點：查過 `wiremock/WireMock.Net` 原始碼的 `WireMockServer.Admin.cs`，確認註冊的 reset 相關路由只有 `mappings/reset`、`requests/reset`、`scenarios/reset`、`scenarios/{name}/reset`，沒有裸的 `reset`；實測也確認打這個路徑回 404。

- [ ] **Step 4: 為什麼會這樣？第二個事實（Java 習慣）——維持原文語氣，措辭微調**

這段是歷史脈絡說明，不是可實測的行為主張，草稿原文可以維持，但把「這是從 Java 版帶過來的習慣」這種肯定語氣微調成「常見的解釋是」，避免對無法查證的歷史脈絡下過度肯定的斷言。

- [ ] **Step 5: 那為什麼拿掉它就好了？——整段改寫成驗證3確認的因果鏈**

必須包含的內容點（取代原本「我沒有百分之百確定的因果鏈」那段推論）：
- 對 `/__admin/reset` 的回應呼叫 `EnsureSuccessStatusCode()`，實測會拋出 `HttpRequestException`
- 這個例外的 `StatusCode` 屬性實測確實是 `HttpStatusCode.NotFound`
- 如果呼叫端沒有用 try/catch 包住這段手動呼叫，例外會直接往外拋，導致後面的 `ResetMappingsAsync()` 那行**從未被執行**——不是 reset 失效，而是根本沒跑到
- 這是實測結果，不再是推論；原本的「我沒有百分之百確定的因果鏈」這句話整句刪除

- [ ] **Step 6: 在 `docs/changes-from-draft.md` 補上這段的條目**

```markdown
## 讓程式自己說話／真兇／為什麼會這樣

- 診斷程式碼換成真實 `WireMockFixture.ResetAllAsync()`。
- `/__admin/reset` 的狀態碼與副作用換成驗證1實測結果（404，無副作用）。
- 原始 bug 重現換成驗證3實測結果（mapping 確實殘留 vs 確實清空）。
- **因果鏈整段改寫**：原本「我沒有百分之百確定的因果鏈」的推論，換成驗證3實測確認的結論——`EnsureSuccessStatusCode()` 對 404 回應拋出 `HttpRequestException`，導致後續 `ResetMappingsAsync()` 從未執行。這是全篇改動幅度最大、也最有價值的一處。
- 「Java 習慣」那段歷史脈絡說明語氣從肯定調整為「常見的解釋是」，因為這點無法直接實測查證。
```

- [ ] **Step 7: Commit**

```bash
git add articles/wiremock-testcontainers-reset-published.md docs/changes-from-draft.md
git commit -m "docs: rewrite article sections - diagnostics, root cause, and confirmed causal chain"
```

---

## Task 5: 重寫後的完整架構（一）—— 服務名稱常數、資料驅動 Fixture、Dictionary 補充

**Files:**
- Modify: `articles/wiremock-testcontainers-reset-published.md`
- Modify: `docs/changes-from-draft.md`

**Interfaces:**
- Consumes: 草稿第 277-489 行；`samples/tests/WireMockDemo.IntegrationTests/WireMockServices.cs`、`Infrastructure/WireMockFixture.cs`；`docs/verification-results.md` 驗證6章節
- Produces: 無

- [ ] **Step 1: 服務名稱常數——換成真實 `WireMockServices.cs`**

直接引用實際檔案內容（`OpenAccountApi`／`IdentityApi`／`PaymentApi` 三個 `const string`）。草稿原本解釋 `const` vs `static readonly` 差異的段落可以維持，這是語言特性說明，不是需要驗證的行為主張。

- [ ] **Step 2: 資料驅動的 Fixture——換成真實 `WireMockFixture.cs`**

直接引用實際檔案的 `InitializeAsync`（含孤兒 container 回收的 try/catch）、`StartAsync`、`BaseUrl`／`Admin` 方法。範例專案的版本比草稿多了 `WebApplicationFactory<Program>` 相關程式碼（因為範例需要真的把 `WireMockDemo.Api` 跑起來），這部分視覺上會讓程式碼變長；改寫時可以只引用跟草稿討論主題（資料驅動、平行啟動、孤兒回收）直接相關的部分，`WebApplicationFactory` 那段可以用一句話帶過（「範例專案另外還需要把待測 API 跑起來，這部分程式碼在此省略，完整版見 `samples/`」）。

- [ ] **Step 3: 補充：Dictionary 還是 ConcurrentDictionary？——損壞風險換成驗證6實測**

必須包含的內容點：
- 草稿原本「並行寫入 Dictionary 可能造成 key 遺失、無限迴圈」這段描述維持（這是 .NET 官方文件與 API 設計保證範圍內的敘述，可以用引用文件的語氣）
- 新增實測結果：1000 輪 × 16 執行緒的並行寫入測試，**0 次失敗、0 次逾時、0 次靜默損壞**
- 明確寫「本次在 16 個執行緒、各自寫入不重疊 key 的情境下未能重現這個風險，這不代表風險不存在（官方文件仍明確不保證執行緒安全），但也不該把『一定會壞』寫成確定的事」——**不寫任何關於「為什麼沒重現」的推測**
- 列舉中被修改的行為（`Dictionary` 拋 `InvalidOperationException`、`ConcurrentDictionary` 不會）、`.Values` 快照行為，都換成驗證6的實測確認語氣
- `ConcurrentDictionary.Count` 取鎖的說法，改成明確引用官方文件語氣（沒有實測，因為沒有可靠的公開 API 能觀察這個內部實作細節）

- [ ] **Step 4: 在 `docs/changes-from-draft.md` 補上這段的條目**

```markdown
## 重寫後的完整架構（服務常數、Fixture、Dictionary 補充）

- 服務名稱常數、Fixture 主體換成真實檔案內容；`WebApplicationFactory` 相關的部分因為是範例專案額外需要、草稿沒有討論，改寫時用一句話帶過並附連結。
- Dictionary/ConcurrentDictionary 損壞風險：新增驗證6實測（0/1000 輪失敗），明確不寫「為什麼沒重現」的推測（作者已確認這個處理方式）。
- `ConcurrentDictionary.Count` 取鎖的說法改成引用官方文件語氣，沒有實測依據。
```

- [ ] **Step 5: Commit**

```bash
git add articles/wiremock-testcontainers-reset-published.md docs/changes-from-draft.md
git commit -m "docs: rewrite article sections - services constants, fixture, and dictionary comparison"
```

---

## Task 6: 重寫後的完整架構（二）—— xUnit v2/v3、Stub 輔助方法、測試基底類別、reset 放置時機

**Files:**
- Modify: `articles/wiremock-testcontainers-reset-published.md`
- Modify: `docs/changes-from-draft.md`

**Interfaces:**
- Consumes: 草稿第 424-634 行；`samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockStubExtensions.cs`、`WireMockTestBase.cs`、`Tests/OpenAccountTests.cs`；`docs/verification-results.md` 驗證4章節
- Produces: 無

- [ ] **Step 1: 「我考慮過但放棄的第三種寫法」——維持原文**

這是設計取捨討論，不是可實測的行為主張，草稿原文可以維持。

- [ ] **Step 2: 「注意：xUnit v2 與 v3 不一樣」—— framing 對調**

原本草稿是「主線 v2、附帶提 v3」，改寫版本要反過來：本文與範例都以 xUnit v3 為準（`ValueTask InitializeAsync()`、`IAsyncDisposable.DisposeAsync()`），如果你還在用 v2，這裡是主要差異（`Task` 簽章、`IAsyncLifetime` 單一介面涵蓋兩個方法）。前面所有章節出現的程式碼片段，改寫時都要確認是 v3 語法（`ValueTask`，不是 `Task`）。

- [ ] **Step 3: Stub 設定的輔助方法——換成真實 `WireMockStubExtensions.StubJsonAsync`**

直接引用實際檔案內容，草稿原本「不要寫死 Guid」「不要設持久化旗標」這兩點說明可以維持（這是設計決策說明，程式碼本身已經是這樣寫的，不需要另外驗證）。

- [ ] **Step 4: 測試基底類別與實際使用——換成真實 `WireMockTestBase`／`OpenAccountTests`**

直接引用實際檔案內容。草稿原本的範例測試方法名稱（開戶成功、身分驗證失敗）跟範例專案實際寫的高度一致，改寫時可以直接對齊實際測試方法。

- [ ] **Step 5: 為什麼 reset 要放在測試之前——換成驗證4的實測結果**

必須包含的內容點：
- 「測試方法拋出例外時，`DisposeAsync` 仍然會被呼叫」這句話從草稿原本已經是肯定語氣（可以保留），但要加註：這點已用驗證4的探測測試實際確認（`DisposeAsync` 寫入的標記檔案確實存在）
- 「`InitializeAsync` 拋出例外時，對應的 `DisposeAsync` 不會被呼叫」——同樣加註已用驗證4實測確認（標記檔案確實不存在）
- 「防禦性的清理應該由受害者而非加害者執行」這句結論可以維持，這是設計原則陳述

- [ ] **Step 6: 在 `docs/changes-from-draft.md` 補上這段的條目**

```markdown
## 重寫後的完整架構（xUnit v2/v3、Stub 輔助方法、測試基底類別）

- xUnit v2/v3 段落 framing 對調：主線改成 v3，v2 變成差異說明（因為範例專案全部用 v3 寫成）。
- Stub 輔助方法、測試基底類別換成真實檔案內容。
- 「reset 放測試之前」那段的兩個生命週期主張都加註已用驗證4實測確認。
```

- [ ] **Step 7: Commit**

```bash
git add articles/wiremock-testcontainers-reset-published.md docs/changes-from-draft.md
git commit -m "docs: rewrite article sections - xUnit v3 framing, stub helper, and test base class"
```

---

## Task 7: 隔離策略的取捨、排查檢查清單、結語、參考資料，移除發表前待驗證清單

**Files:**
- Modify: `articles/wiremock-testcontainers-reset-published.md`
- Modify: `docs/changes-from-draft.md`

**Interfaces:**
- Consumes: 草稿第 635-710 行；`docs/verification-results.md` 驗證7、8章節
- Produces: 無

- [ ] **Step 1: 隔離策略的取捨——in-process server 耗時換成驗證7實測數字**

必須包含的內容點：in-process `WireMockServer` 啟動耗時實測中位數 **2ms**（5 次量測：1ms, 2ms, 2ms, 10ms, 532ms），比草稿原本估計的「數十毫秒等級」還要快一個數量級，改寫時要明確指出這個修正；`WireMockServer.Start()` 沒有 admin 介面、`StartWithAdminInterface()` 才有，這點已用驗證8實測確認。三個 container 平行啟動（中位數 1579ms）約等於單一 container 啟動時間（1474ms），循序啟動（中位數 4503ms）明顯更久，這兩個數字也要放進來取代草稿原本的估計句「大約 1.5 秒」等假設性文字。

- [ ] **Step 2: 排查檢查清單——語氣同步更新**

跟前面各章節保持一致，把「應該」改成確定語氣，並確保跟前面章節的結論不矛盾。

- [ ] **Step 3: 結語——補一句連結到範例專案**

在結語段落最後加一句，說明完整範例與驗證過程可見 `samples/` 目錄與 `docs/verification-results.md`。

- [ ] **Step 4: 移除「發表前待驗證清單」整節**

草稿最後這一節（含子項目）整節刪除，不出現在發表版。

- [ ] **Step 5: 參考資料——新增範例專案與驗證結果連結**

在草稿原本的參考資料清單最後，新增兩條：範例專案（`samples/` 目錄）、`docs/verification-results.md`。

- [ ] **Step 6: 在 `docs/changes-from-draft.md` 補上這段的條目**

```markdown
## 隔離策略／檢查清單／結語／參考資料

- in-process WireMockServer 啟動耗時換成驗證7實測中位數（2ms），比草稿原本估計快一個數量級，特別註明這項修正。
- 三個 container 循序/平行啟動時間換成驗證7實測數字。
- 移除〈發表前待驗證清單〉整節。
- 參考資料新增範例專案與 verification-results.md 連結。
```

- [ ] **Step 7: Commit**

```bash
git add articles/wiremock-testcontainers-reset-published.md docs/changes-from-draft.md
git commit -m "docs: rewrite article sections - isolation tradeoffs, checklist, closing, references"
```

---

## Task 8: 全文自我審閱

**Files:**
- Modify: `articles/wiremock-testcontainers-reset-published.md`（如有發現問題才修改）

**Interfaces:**
- Consumes: `articles/wiremock-testcontainers-reset-published.md`（Task 1-7 產出的完整發表版）、`docs/verification-results.md`
- Produces: 無

- [ ] **Step 1: 掃描殘留的模糊語氣**

通篇搜尋「應該」「可能」「理論上」「大概」「我猜」這類字樣，逐一確認：是不是本可實測但還沒換成確定語氣的殘留？如果是，回頭修正；如果是設計取捨/個人偏好類的陳述（例如「我考慮過但放棄的第三種寫法」那種主觀評估），保留無妨。

- [ ] **Step 2: 確認每段程式碼都有對應的真實檔案**

逐一核對文章裡的程式碼區塊，跟 `samples/` 目錄下的實際檔案內容比對，確認沒有走樣。唯一的例外（「第一版架構」的 naive 示範）應該已經在 Task 2 改成純文字，這裡再次確認沒有遺漏的程式碼區塊。

- [ ] **Step 3: 確認 front matter 與草稿警語都已正確移除**

檢查發表版檔案開頭沒有 `draft: true`、沒有草稿警語 blockquote。

- [ ] **Step 4: Commit（如果 Step 1-3 有修改）**

```bash
git add articles/wiremock-testcontainers-reset-published.md
git commit -m "docs: self-review pass on published article"
```

如果 Step 1-3 沒有發現需要修改的地方，這個任務不需要 commit，直接進入 Task 9。

---

## Task 9: 完成 `docs/changes-from-draft.md`

**Files:**
- Modify: `docs/changes-from-draft.md`

**Interfaces:**
- Consumes: Task 1-7 累積寫入的條目
- Produces: 無

- [ ] **Step 1: 檢查骨架完整性**

確認 Task 1-7 每個任務的條目都已經寫入，章節標題跟文章實際章節對應。

- [ ] **Step 2: 加一個文件開頭的總覽段落**

在檔案最前面（逐條清單之前）加幾句總覽：這次改寫依據 8 項驗證的實測結果，最大幅度的改動是驗證3的因果鏈（從推論變成確定結論）與驗證6的 Dictionary 損壞風險（從「會壞」降級為「本次未重現」）；xUnit v2/v3 的 framing 也整個對調成 v3 為主。

- [ ] **Step 3: Commit**

```bash
git add docs/changes-from-draft.md
git commit -m "docs: finalize changes-from-draft summary"
```

---

## Task 10: 最終驗收確認

**Files:**
- 無新檔案，純確認

**Interfaces:**
- 無

- [ ] **Step 1: 逐項對照驗收標準**

對照 spec 文件（`docs/superpowers/specs/2026-07-27-article-rewrite-design.md`）的「驗收標準」段落，逐項確認：

- [ ] `articles/wiremock-testcontainers-reset-published.md` 裡的每一段程式碼都能在 `samples/` 找到對應檔案（naive 示範例外）
- [ ] 沒有任何「應該」「可能」「理論上」語氣描述本可實測的行為
- [ ] `docs/changes-from-draft.md` 完整記錄所有跟草稿不同之處
- [ ] 已移除 `draft: true`、草稿警語、〈發表前待驗證清單〉整節

- [ ] **Step 2: 向使用者報告完成狀態**

如果 Step 1 全部打勾，回報改寫完成；如果有任何一項沒過，回到對應的任務修正。

---

## Self-Review 記錄

- **Spec coverage：** 對照 `docs/superpowers/specs/2026-07-27-article-rewrite-design.md` 的逐節對照表——表格裡列出的每一個章節都能在 Task 1-7 裡找到對應的處理任務。兩項作者確認過的內容決定（驗證6不寫推測、`DisableParallelization` 收錄進平行執行章節）分別寫進 Task 5 Step 3、Task 3 Step 1。
- **Placeholder scan：** 全文檢查過，沒有「TBD」字樣；「必須包含的內容點」是刻意的具體要求清單，不是空泛指示——每一條都指明了確切的數字、來源檔案或結論文字。
- **Type consistency：** 各任務引用的實際檔案路徑（`WireMockFixture.cs`、`WireMockStubExtensions.cs`、`WireMockTestBase.cs`、`OpenAccountTests.cs`、`WireMockServices.cs`）跟 samples 目錄裡實際存在的檔案一致；`docs/changes-from-draft.md` 的章節標題跟 Task 1-7 处理的文章章節一一對應。

---

**Plan complete and saved to `docs/superpowers/plans/2026-07-27-article-rewrite.md`. Two execution options:**

**1. Subagent-Driven (recommended)** - 每個任務派一個新的 subagent 執行，任務之間我會 review，適合快速迭代
**2. Inline Execution** - 在目前這個對話裡直接照 executing-plans 逐批執行，設檢查點讓你 review

**你要選哪一種？**
