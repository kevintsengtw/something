# WireMockDemo.Experiments — xUnit 執行行為驗證（驗證4-5）Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在 `WireMockDemo.Experiments` 專案裡實作草稿〈發表前待驗證清單〉的驗證 4（xUnit 生命週期）與驗證 5（xUnit 平行執行行為），把草稿的推論語氣換成實測結果。

**Architecture:** 驗證4用兩個刻意會失敗的探測測試類別，靠 `DisposeAsync` 寫入標記檔的方式，觀察 xUnit 在測試方法拋例外／`InitializeAsync` 拋例外這兩種情境下實際的生命週期呼叫順序；驗證5用四個測試類別（兩個共用 collection、兩個不標 collection）各自把起訖時間戳記寫進共用的 log 檔，執行完後用外部腳本讀檔判斷是否重疊。兩者都不在 xUnit 測試內部做斷言，而是靠測試執行完之後的外部檢查——這樣可以避免「探測本身刻意失敗」與「跨測試類別協調時序」這兩件事污染 `dotnet test` 的通過/失敗判定。

**Tech Stack:** net10.0、xUnit v3（3.2.2）+ `xunit.runner.visualstudio`（VSTest）、`AwesomeAssertions`（9.5.0，本計畫實際上用不到，因為兩項驗證都不在測試內部斷言）。

## Global Constraints

- Target framework：`net10.0`
- 測試框架：xUnit v3 3.2.2，`IAsyncLifetime` 用 `ValueTask InitializeAsync()` / `ValueTask DisposeAsync()`
- 所有非同步呼叫傳遞 `TestContext.Current.CancellationToken`
- 驗證4的兩個探測測試標 `[Trait("Category", "LifecycleProbe")]`，**不進預設 `dotnet test` 範圍**——這兩個測試設計上就是要讓自己失敗/出錯才能證明生命週期規則
- 驗證5的四個測試類別**不需要** Trait 排除——它們本身不會失敗，只是記錄時間戳記，可以留在預設 `dotnet test` 範圍
- 本計畫接手後，`WireMockDemo.Experiments` 的「預設全綠」指令變成：
  ```bash
  dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category!=LifecycleProbe"
  ```
  等驗證 7（計時數字，屬於下一份計畫）加入 `TimingBenchmark` Trait 之後，這個指令才會再加上 `&Category!=TimingBenchmark`
- 工作目錄已是 git repository，每個任務結尾都要 `git add` + `git commit`
- 本計畫範圍**只涵蓋**驗證 4～5。驗證 6～8（集合型別／計時／in-process server）是後續獨立計畫
- 承接 `docs/superpowers/specs/2026-07-27-wiremockdemo-experiments-design.md` 與已完成的 `docs/superpowers/plans/2026-07-27-wiremockdemo-experiments-reset-behavior.md`（驗證1-3），`WireMockDemo.Experiments.csproj` 與相關套件已存在，本計畫不需要再建立專案骨架

---

## File Structure

```
samples/tests/WireMockDemo.Experiments/
  V4_XunitLifecycleProbe.cs      # 驗證4：InitializeAsync/DisposeAsync 生命週期
  V5_ParallelExecutionTests.cs   # 驗證5：同 collection 循序、不同 collection 平行
```

---

## Task 1: 驗證4 —— xUnit 生命週期

**Files:**
- Create: `samples/tests/WireMockDemo.Experiments/V4_XunitLifecycleProbe.cs`

**Interfaces:**
- Produces: 無（獨立驗證，後續任務不依賴）

- [ ] **Step 1: 寫入 `V4_XunitLifecycleProbe.cs`**

```csharp
using Xunit;

namespace WireMockDemo.Experiments;

internal static class V4_MarkerFiles
{
    private static readonly string OutputDirectory =
        Path.Combine(AppContext.BaseDirectory, "LifecycleProbeOutput");

    public static readonly string TestMethodThrowsMarker =
        Path.Combine(OutputDirectory, "test-method-throws.marker");

    public static readonly string InitializeThrowsMarker =
        Path.Combine(OutputDirectory, "initialize-throws.marker");

    public static void WriteMarker(string path)
    {
        Directory.CreateDirectory(OutputDirectory);
        File.WriteAllText(path, "disposed");
    }
}

[Trait("Category", "LifecycleProbe")]
public sealed class V4_TestMethodThrows_DisposeAsyncStillRunsProbe : IAsyncLifetime
{
    public ValueTask InitializeAsync() => ValueTask.CompletedTask;

    public ValueTask DisposeAsync()
    {
        V4_MarkerFiles.WriteMarker(V4_MarkerFiles.TestMethodThrowsMarker);
        return ValueTask.CompletedTask;
    }

    [Fact]
    public Task 測試方法拋出例外_探測DisposeAsync是否仍會被呼叫()
    {
        throw new InvalidOperationException("刻意拋出的例外，用來驗證 DisposeAsync 是否仍會被呼叫。");
    }
}

[Trait("Category", "LifecycleProbe")]
public sealed class V4_InitializeAsyncThrows_DisposeAsyncDoesNotRunProbe : IAsyncLifetime
{
    public ValueTask InitializeAsync() =>
        throw new InvalidOperationException("刻意拋出的例外，用來驗證 InitializeAsync 失敗時 DisposeAsync 是否不會被呼叫。");

    public ValueTask DisposeAsync()
    {
        V4_MarkerFiles.WriteMarker(V4_MarkerFiles.InitializeThrowsMarker);
        return ValueTask.CompletedTask;
    }

    [Fact]
    public Task 這個測試方法理論上不會被執行到()
    {
        // InitializeAsync 已經拋例外，xUnit 不會走到這裡；
        // 留著只是滿足類別需要至少一個 [Fact] 才會被 xUnit 發現並嘗試建立實例。
        return Task.CompletedTask;
    }
}
```

- [ ] **Step 2: 清掉舊的標記檔，執行探測測試（預期會顯示失敗/錯誤，這是設計上的行為，不是 bug）**

```bash
rm -f samples/tests/WireMockDemo.Experiments/bin/Debug/net10.0/LifecycleProbeOutput/*.marker
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category=LifecycleProbe"
```

Expected: 測試回合顯示 2 個測試、都不是「通過」（`V4_TestMethodThrows_...` 應該顯示失敗，因為 `[Fact]` 本身拋了例外；`V4_InitializeAsyncThrows_...` 應該顯示錯誤，因為 `InitializeAsync` 拋例外導致無法建立測試類別實例）。這兩個結果本身就是證據的一部分，記下實際的失敗/錯誤訊息文字。

- [ ] **Step 3: 檢查標記檔，確認 `DisposeAsync` 實際的呼叫情形**

```bash
ls samples/tests/WireMockDemo.Experiments/bin/Debug/net10.0/LifecycleProbeOutput/
```

Expected: 只看到 `test-method-throws.marker`（證明測試方法拋例外時，`DisposeAsync` 仍然被呼叫），**沒有** `initialize-throws.marker`（證明 `InitializeAsync` 拋例外時，對應的 `DisposeAsync` 不會被呼叫）。如果實際結果不同——例如兩個標記檔都出現、或都沒出現——如實記錄，這代表草稿「孤兒 container」那段論述的前提需要重新檢視，不要調整程式碼硬湊出預期結果。

- [ ] **Step 4: Commit**

```bash
git add samples/tests/WireMockDemo.Experiments
git commit -m "test: add V4 xUnit lifecycle probes"
```

---

## Task 2: 驗證5 —— xUnit 平行執行行為

**Files:**
- Create: `samples/tests/WireMockDemo.Experiments/V5_ParallelExecutionTests.cs`

**Interfaces:**
- Produces: 無（獨立驗證，後續任務不依賴）

- [ ] **Step 1: 寫入 `V5_ParallelExecutionTests.cs`**

```csharp
using Xunit;

namespace WireMockDemo.Experiments;

internal static class V5_TimestampLog
{
    private static readonly object FileLock = new();

    public static readonly string LogFilePath =
        Path.Combine(AppContext.BaseDirectory, "V5Log", "timestamps.csv");

    public static void Append(string className, long startUnixMs, long endUnixMs)
    {
        lock (FileLock)
        {
            var directory = Path.GetDirectoryName(LogFilePath)!;
            Directory.CreateDirectory(directory);
            File.AppendAllText(LogFilePath, $"{className},{startUnixMs},{endUnixMs}{Environment.NewLine}");
        }
    }
}

[CollectionDefinition(Name)]
public sealed class V5SameCollection
{
    public const string Name = "V5Same";
}

[Collection(V5SameCollection.Name)]
public sealed class V5_SameCollection_ClassA
{
    [Fact]
    public async Task 執行並記錄時間戳記()
    {
        var start = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        await Task.Delay(300, TestContext.Current.CancellationToken);
        var end = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        V5_TimestampLog.Append(nameof(V5_SameCollection_ClassA), start, end);
    }
}

[Collection(V5SameCollection.Name)]
public sealed class V5_SameCollection_ClassB
{
    [Fact]
    public async Task 執行並記錄時間戳記()
    {
        var start = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        await Task.Delay(300, TestContext.Current.CancellationToken);
        var end = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        V5_TimestampLog.Append(nameof(V5_SameCollection_ClassB), start, end);
    }
}

public sealed class V5_NoCollection_ClassC
{
    [Fact]
    public async Task 執行並記錄時間戳記()
    {
        var start = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        await Task.Delay(300, TestContext.Current.CancellationToken);
        var end = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        V5_TimestampLog.Append(nameof(V5_NoCollection_ClassC), start, end);
    }
}

public sealed class V5_NoCollection_ClassD
{
    [Fact]
    public async Task 執行並記錄時間戳記()
    {
        var start = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        await Task.Delay(300, TestContext.Current.CancellationToken);
        var end = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        V5_TimestampLog.Append(nameof(V5_NoCollection_ClassD), start, end);
    }
}
```

`V5_SameCollection_ClassA`／`ClassB` 標同一個 `[Collection(V5SameCollection.Name)]`，沒有另外設定 `DisableParallelization`——這正是要交叉確認先前在參考專案發現的疑點：`DisableParallelization = true` 是否真的必要，還是同一 collection 內本來就會依序執行。

- [ ] **Step 2: 清掉舊的 log 檔，執行測試**

```bash
rm -f samples/tests/WireMockDemo.Experiments/bin/Debug/net10.0/V5Log/timestamps.csv
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V5_"
```

Expected: 4 個測試全數通過（這四個測試本身不會失敗，只是記錄時間戳記）。

- [ ] **Step 3: 讀取 log 檔，計算是否重疊**

```bash
python3 -c "
import csv

entries = {}
with open('samples/tests/WireMockDemo.Experiments/bin/Debug/net10.0/V5Log/timestamps.csv') as f:
    for row in csv.reader(f):
        name, start, end = row
        entries[name] = (int(start), int(end))

def overlaps(a, b):
    return a[0] < b[1] and b[0] < a[1]

same = overlaps(entries['V5_SameCollection_ClassA'], entries['V5_SameCollection_ClassB'])
no_collection = overlaps(entries['V5_NoCollection_ClassC'], entries['V5_NoCollection_ClassD'])

print('SameCollection overlap:', same)
print('NoCollection overlap:', no_collection)
"
```

Expected: `SameCollection overlap: False`（草稿「同一個 collection 內的測試類別會依序執行」成立，且沒有標 `DisableParallelization` 也一樣成立，代表這個設定對「同 collection 內序列執行」這件事不是必要的）；`NoCollection overlap:` 的結果**如實記錄**（`True` 或 `False` 都是合法結果，因為平不平行還取決於當下的排程與可用執行緒數，不強求特定結果）。

- [ ] **Step 4: Commit**

```bash
git add samples/tests/WireMockDemo.Experiments
git commit -m "test: add V5 parallel execution verification"
```

---

## Task 3: Plan B 最終驗證

**Files:**
- 無新檔案，純驗證

**Interfaces:**
- 無

- [ ] **Step 1: 全專案建置**

```bash
dotnet build samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj
```

Expected: `Build succeeded. 0 Warning(s) 0 Error(s)`

- [ ] **Step 2: 執行「預設全綠」範圍的測試**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "Category!=LifecycleProbe"
```

Expected: 驗證1-3的 8 個測試 + 驗證5的 4 個測試 = 12 個測試全數通過，0 個失敗（驗證4的兩個探測測試因為 Trait 排除，不在這個範圍內）。

- [ ] **Step 3: 把 Task 1、2 的實際輸出整理進 `docs/verification-results.md`**

在既有的 `docs/verification-results.md` 檔案裡，於「## 驗證 3」章節之後、「## 小結」章節之前，插入「## 驗證 4」與「## 驗證 5」兩個新章節，內容比照既有章節的格式（草稿主張、執行指令、實際輸出、結論），用 Task 1 Step 2-3 與 Task 2 Step 2-3 實際觀察到的結果填寫。同時更新文件最後的「小結」段落，把驗證 4-5 從「尚未執行」改成已完成，並簡述結論。

- [ ] **Step 4: Commit**

```bash
git add docs/verification-results.md
git commit -m "docs: record V4-V5 verification results"
```

---

## Self-Review 記錄

- **Spec coverage：** 對照 `docs/superpowers/specs/2026-07-27-wiremockdemo-experiments-design.md` 的驗證 4、5 段落——生命週期的兩個探測（Task 1）、平行執行的兩組情境含 `DisableParallelization` 交叉確認（Task 2）均有對應任務，`verification-results.md` 更新在 Task 3。
- **Placeholder scan：** 全文檢查過，沒有「TBD」字樣；「如實記錄，不強求特定結果」是刻意的方法論指引，不是未完成的佔位內容。
- **Type consistency：** `V4_MarkerFiles`／`V5_TimestampLog` 只在各自檔案內使用，沒有跨任務依賴；`V5SameCollection.Name` 在 Task 2 定義後，`ClassA`／`ClassB` 的 `[Collection(...)]` 用法一致。

---

**Plan complete and saved to `docs/superpowers/plans/2026-07-27-wiremockdemo-experiments-xunit-execution.md`. Two execution options:**

**1. Subagent-Driven (recommended)** - 每個任務派一個新的 subagent 執行，任務之間我會 review，適合快速迭代
**2. Inline Execution** - 在目前這個對話裡直接照 executing-plans 逐批執行，設檢查點讓你 review

**你要選哪一種？**
