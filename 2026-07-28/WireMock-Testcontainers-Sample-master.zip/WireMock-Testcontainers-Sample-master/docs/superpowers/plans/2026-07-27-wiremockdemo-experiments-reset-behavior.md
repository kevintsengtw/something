# WireMockDemo.Experiments — Reset 行為驗證（驗證1-3）Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 建立 `WireMockDemo.Experiments` 專案骨架，並實作草稿〈發表前待驗證清單〉的驗證 1～3（`/__admin/reset` 端點是否存在、reset 的實際行為、重現原始 bug 與因果鏈），全部用實際跑得動的測試取代推論語氣。

**Architecture:** 每個驗證測試類別各自用 `IAsyncLifetime` 管理自己專屬的 WireMock container（不透過共用 fixture，也不依賴 `WireMockDemo.Api`），直接呼叫 `IWireMockAdminApi` 與手動 `HttpClient` 驗證 WireMock.Net 本身的行為。

**Tech Stack:** net10.0、xUnit v3（3.2.2）+ `xunit.runner.visualstudio`（VSTest）、`AwesomeAssertions`（9.5.0）、`WireMock.Net.Testcontainers`（2.13.0）。

## Global Constraints

- Target framework：`net10.0`
- 測試框架：xUnit v3 3.2.2，`IAsyncLifetime` 用 `ValueTask InitializeAsync()` / `ValueTask DisposeAsync()`
- 測試執行器：標準 VSTest（`xunit.runner.visualstudio` 3.1.5）
- `Microsoft.NET.Test.Sdk` 版本 18.8.1
- `AwesomeAssertions` 版本 9.5.0，測試斷言一律用 `.Should()` 語法，不用 xUnit 內建的 `Assert.*`
- `WireMock.Net.Testcontainers` 版本 2.13.0，container image 不手動指定版本（`new WireMockContainerBuilder().Build()`）
- 所有非同步呼叫傳遞 `TestContext.Current.CancellationToken`，避免 xUnit1051 分析器警告
- `WireMockDemo.Experiments` **不**參照 `WireMockDemo.Api`，沒有 project reference——這些驗證測的是 `WireMock.Net` 與 .NET 執行環境本身的行為
- 工作目錄已是 git repository，每個任務結尾都要 `git add` + `git commit`
- 本計畫範圍**只涵蓋**驗證 1～3（含專案骨架）。驗證 4～5（xUnit 執行行為）與驗證 6～8（集合型別／計時／in-process server）是後續獨立計畫，不在此計畫的任務範圍內
- `IWireMockAdminApi`／`MappingModel`／`RequestModel`／`ResponseModel`／`WireMockContainer`／`WireMockContainerBuilder` 的方法簽章已於規劃階段直接查閱 `wiremock/WireMock.Net` GitHub 原始碼核對，本計畫程式碼均以該次核對結果為準
- 目前這個計畫階段沒有任何測試需要 Trait 排除；`dotnet test` 對 `WireMockDemo.Experiments.csproj` 直接執行即可全綠（Trait 排除機制留給驗證 4、7 所在的後續計畫引入）

---

## File Structure

```
samples/tests/WireMockDemo.Experiments/
  WireMockDemo.Experiments.csproj
  V1_AdminResetEndpointTests.cs        # 驗證1：/__admin/reset 狀態碼與副作用
  V2_ResetBehaviorTests.cs             # 驗證2：ResetMappingsAsync／ResetRequestsAsync／靜態 mapping
  V3_BugReproductionTests.cs           # 驗證3：重現原始 bug + 因果鏈
  TestData/StaticMappings/static-mapping.json   # 驗證2靜態 mapping 測試用的檔案
```

`V2_ResetBehaviorTests.cs` 裡會有兩個測試類別：一個用不含靜態 mapping 的 container（測 `ResetMappingsAsync`／`ResetRequestsAsync` 的動態行為），另一個用 `.WithMappings(...)` 載入靜態 mapping 的 container（測 `reloadStaticMappings` 差異）——兩者需要不同的 container 設定，分成兩個類別比硬塞進同一個類別更清楚。

---

## Task 1: 建立 `WireMockDemo.Experiments` 專案骨架

**Files:**
- Create: `samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj`

**Interfaces:**
- Produces: 空的 xUnit v3 測試專案，已加入 `samples/WireMockDemo.slnx`

- [ ] **Step 1: 建立目錄與 csproj**

```bash
mkdir -p samples/tests/WireMockDemo.Experiments
```

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <IsPackable>false</IsPackable>
    <OutputType>Exe</OutputType>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.NET.Test.Sdk" Version="18.8.1" />
    <PackageReference Include="xunit.v3" Version="3.2.2" />
    <PackageReference Include="xunit.runner.visualstudio" Version="3.1.5">
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
      <PrivateAssets>all</PrivateAssets>
    </PackageReference>
    <PackageReference Include="AwesomeAssertions" Version="9.5.0" />
    <PackageReference Include="WireMock.Net.Testcontainers" Version="2.13.0" />
  </ItemGroup>

</Project>
```

- [ ] **Step 2: 加入 solution 並建置驗證**

```bash
dotnet sln samples/WireMockDemo.slnx add samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj
dotnet build samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj
```

Expected: `Build succeeded. 0 Warning(s) 0 Error(s)`

- [ ] **Step 3: Commit**

```bash
git add samples/WireMockDemo.slnx samples/tests/WireMockDemo.Experiments
git commit -m "feat: scaffold WireMockDemo.Experiments project"
```

---

## Task 2: 驗證1 —— `/__admin/reset` 端點是否存在

**Files:**
- Create: `samples/tests/WireMockDemo.Experiments/V1_AdminResetEndpointTests.cs`

**Interfaces:**
- Consumes: `WireMockContainerBuilder`、`WireMockContainer.CreateClient()`、`WireMockContainer.CreateWireMockAdminClient()`
- Produces: 無（獨立驗證，後續任務不依賴）

- [ ] **Step 1: 寫入 `V1_AdminResetEndpointTests.cs`**

```csharp
using System.Net;
using AwesomeAssertions;
using WireMock.Admin.Mappings;
using WireMock.Net.Testcontainers;
using Xunit;

namespace WireMockDemo.Experiments;

public sealed class V1_AdminResetEndpointTests : IAsyncLifetime
{
    private WireMockContainer _container = null!;

    public async ValueTask InitializeAsync()
    {
        _container = new WireMockContainerBuilder().Build();
        await _container.StartAsync();
    }

    public async ValueTask DisposeAsync() => await _container.DisposeAsync();

    [Fact]
    public async Task PostAdminReset_應回傳404且對Mapping數量無副作用()
    {
        var admin = _container.CreateWireMockAdminClient();
        await admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel { Path = "/api/probe", Methods = new[] { "GET" } },
            Response = new ResponseModel { StatusCode = 200 },
        }, TestContext.Current.CancellationToken);

        var beforeCount = (await admin.GetMappingsAsync(TestContext.Current.CancellationToken)).Count;

        using var httpClient = _container.CreateClient();
        var response = await httpClient.PostAsync("/__admin/reset", null, TestContext.Current.CancellationToken);

        var afterCount = (await admin.GetMappingsAsync(TestContext.Current.CancellationToken)).Count;

        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
        afterCount.Should().Be(beforeCount);
    }
}
```

- [ ] **Step 2: 執行測試，記錄實際結果**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V1_AdminResetEndpointTests"
```

Expected: 1 個測試通過，`response.StatusCode` 為 `404 NotFound`（依規劃階段查過的 `WireMockServer.Admin.cs` 路由註冊——只有 `mappings/reset`、`requests/reset`、`scenarios/reset` 幾條路由，沒有裸的 `reset`，所以打這個路徑會落入一般 stub 比對、無匹配則回 404）。如果實際狀態碼不是 404，**不要回頭改斷言讓它變綠**——這代表發現了跟原始碼分析不同的真實行為，先記下實際狀態碼，這本身就是驗證的價值所在，等 Task 4（最終驗證）時一併整理進 `docs/verification-results.md`。

- [ ] **Step 3: Commit**

```bash
git add samples/tests/WireMockDemo.Experiments
git commit -m "test: add V1 admin reset endpoint verification"
```

---

## Task 3: 驗證2 —— reset 的實際行為

**Files:**
- Create: `samples/tests/WireMockDemo.Experiments/V2_ResetBehaviorTests.cs`
- Create: `samples/tests/WireMockDemo.Experiments/TestData/StaticMappings/static-mapping.json`
- Modify: `samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj`

**Interfaces:**
- Consumes: 同 Task 2
- Produces: 無

- [ ] **Step 1: 寫入靜態 mapping 測試檔 `TestData/StaticMappings/static-mapping.json`**

```json
{
  "Guid": "b1e6a4f0-6b0a-4c1a-9b0a-000000000001",
  "Request": {
    "Path": "/api/static-probe",
    "Methods": [ "GET" ]
  },
  "Response": {
    "StatusCode": 200,
    "Body": "static-mapping-ok"
  }
}
```

- [ ] **Step 2: 修改 `WireMockDemo.Experiments.csproj`，讓靜態 mapping 檔複製到輸出目錄**

在 `</Project>` 之前加入：

```xml
  <ItemGroup>
    <None Include="TestData/StaticMappings/static-mapping.json">
      <CopyToOutputDirectory>PreserveNewest</CopyToOutputDirectory>
    </None>
  </ItemGroup>
```

- [ ] **Step 3: 寫入 `V2_ResetBehaviorTests.cs`**

```csharp
using AwesomeAssertions;
using WireMock.Admin.Mappings;
using WireMock.Net.Testcontainers;
using Xunit;

namespace WireMockDemo.Experiments;

public sealed class V2_ResetBehaviorTests : IAsyncLifetime
{
    private WireMockContainer _container = null!;

    public async ValueTask InitializeAsync()
    {
        _container = new WireMockContainerBuilder().Build();
        await _container.StartAsync();
    }

    public async ValueTask DisposeAsync() => await _container.DisposeAsync();

    [Fact]
    public async Task ResetMappingsAsync_應清空所有動態Mapping()
    {
        var admin = _container.CreateWireMockAdminClient();
        await admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel { Path = "/api/probe", Methods = new[] { "GET" } },
            Response = new ResponseModel { StatusCode = 200 },
        }, TestContext.Current.CancellationToken);

        await admin.ResetMappingsAsync(cancellationToken: TestContext.Current.CancellationToken);

        var mappings = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        mappings.Should().BeEmpty();
    }

    [Fact]
    public async Task ResetRequestsAsync_只清RequestLog_不影響Mapping()
    {
        var admin = _container.CreateWireMockAdminClient();
        await admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel { Path = "/api/probe", Methods = new[] { "GET" } },
            Response = new ResponseModel { StatusCode = 200 },
        }, TestContext.Current.CancellationToken);

        using var httpClient = _container.CreateClient();
        await httpClient.GetAsync("/api/probe", TestContext.Current.CancellationToken);

        await admin.ResetRequestsAsync(TestContext.Current.CancellationToken);

        var mappings = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        var requests = await admin.GetRequestsAsync(TestContext.Current.CancellationToken);

        mappings.Should().ContainSingle();
        requests.Should().BeEmpty();
    }
}

public sealed class V2_StaticMappingReloadTests : IAsyncLifetime
{
    private static readonly string StaticMappingsPath =
        Path.Combine(AppContext.BaseDirectory, "TestData", "StaticMappings");

    private WireMockContainer _container = null!;

    public async ValueTask InitializeAsync()
    {
        _container = new WireMockContainerBuilder()
            .WithMappings(StaticMappingsPath)
            .Build();
        await _container.StartAsync();
    }

    public async ValueTask DisposeAsync() => await _container.DisposeAsync();

    [Fact]
    public async Task ResetMappingsAsync預設_靜態Mapping不會自動回來()
    {
        var admin = _container.CreateWireMockAdminClient();

        var beforeReset = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        beforeReset.Should().ContainSingle();

        await admin.ResetMappingsAsync(cancellationToken: TestContext.Current.CancellationToken);

        var afterReset = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        afterReset.Should().BeEmpty();
    }

    [Fact]
    public async Task ResetMappingsAsyncReloadStaticMappingsTrue_靜態Mapping會重新載入()
    {
        var admin = _container.CreateWireMockAdminClient();

        await admin.ResetMappingsAsync(reloadStaticMappings: true, cancellationToken: TestContext.Current.CancellationToken);

        var mappings = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        mappings.Should().ContainSingle();
    }
}
```

- [ ] **Step 4: 執行測試，記錄實際結果**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V2_"
```

Expected: 4 個測試通過。如果 `V2_StaticMappingReloadTests` 的兩個測試因為 bind mount 找不到檔案而失敗（例如 Docker Desktop 的檔案共享設定沒有涵蓋這個路徑），先確認 `docker info` 裡的檔案共享範圍是否包含這個 repo 所在的磁碟機，這是 Windows + Docker Desktop 常見的環境限制，不是程式碼問題。

- [ ] **Step 5: Commit**

```bash
git add samples/tests/WireMockDemo.Experiments
git commit -m "test: add V2 reset behavior verification"
```

---

## Task 4: 驗證3 —— 重現原始 bug 與因果鏈

**Files:**
- Create: `samples/tests/WireMockDemo.Experiments/V3_BugReproductionTests.cs`

**Interfaces:**
- Consumes: 同 Task 2
- Produces: 無

- [ ] **Step 1: 寫入 `V3_BugReproductionTests.cs`**

```csharp
using System.Net;
using AwesomeAssertions;
using WireMock.Admin.Mappings;
using WireMock.Client;
using WireMock.Net.Testcontainers;
using Xunit;

namespace WireMockDemo.Experiments;

public sealed class V3_BugReproductionTests : IAsyncLifetime
{
    private WireMockContainer _container = null!;

    public async ValueTask InitializeAsync()
    {
        _container = new WireMockContainerBuilder().Build();
        await _container.StartAsync();
    }

    public async ValueTask DisposeAsync() => await _container.DisposeAsync();

    [Fact]
    public async Task 有問題的Reset_多打一次AdminReset_Mapping會殘留()
    {
        var admin = _container.CreateWireMockAdminClient();
        await StubProbeMappingAsync(admin, TestContext.Current.CancellationToken);

        await BuggyResetAsync(_container, TestContext.Current.CancellationToken);

        var mappings = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        mappings.Should().ContainSingle();
    }

    [Fact]
    public async Task 正確的Reset_只呼叫ResetMappingsAsync_Mapping會清空()
    {
        var admin = _container.CreateWireMockAdminClient();
        await StubProbeMappingAsync(admin, TestContext.Current.CancellationToken);

        await admin.ResetMappingsAsync(cancellationToken: TestContext.Current.CancellationToken);

        var mappings = await admin.GetMappingsAsync(TestContext.Current.CancellationToken);
        mappings.Should().BeEmpty();
    }

    [Fact]
    public async Task 有問題的Reset_因果鏈_EnsureSuccessStatusCode應拋出HttpRequestException()
    {
        using var httpClient = _container.CreateClient();

        var act = async () =>
        {
            using var response = await httpClient.PostAsync("/__admin/reset", null, TestContext.Current.CancellationToken);
            response.EnsureSuccessStatusCode();
        };

        var assertion = await act.Should().ThrowAsync<HttpRequestException>();
        assertion.Which.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    private static Task StubProbeMappingAsync(IWireMockAdminApi admin, CancellationToken cancellationToken) =>
        admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel { Path = "/api/probe", Methods = new[] { "GET" } },
            Response = new ResponseModel { StatusCode = 200 },
        }, cancellationToken);

    private static async Task BuggyResetAsync(WireMockContainer container, CancellationToken cancellationToken)
    {
        try
        {
            using var httpClient = container.CreateClient();
            var response = await httpClient.PostAsync("/__admin/reset", null, cancellationToken);
            response.EnsureSuccessStatusCode();

            // 如果上面這行拋出例外，下面這行就永遠不會執行——
            // 這正是原始 bug 的因果鏈：不是 reset 失效，而是根本沒跑到。
            var admin = container.CreateWireMockAdminClient();
            await admin.ResetMappingsAsync(cancellationToken: cancellationToken);
        }
        catch (HttpRequestException)
        {
            // 這裡吞掉例外只是為了讓測試能繼續往下檢查 mapping 的殘留狀態；
            // 不代表原始程式碼真的有這個 catch。例外本身的型別與內容
            // 由另一個測試（因果鏈）獨立驗證。
        }
    }
}
```

- [ ] **Step 2: 執行測試，記錄實際結果**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj --filter "FullyQualifiedName~V3_"
```

Expected: 3 個測試通過。第一個測試證明「多打一次 `/__admin/reset` 會讓 mapping 殘留」，第二個測試證明「正確呼叫會清空」，第三個測試證明因果鏈——`EnsureSuccessStatusCode()` 對 404 回應會拋出 `HttpRequestException`，且 `StatusCode` 屬性確實是 `NotFound`。如果第一個測試失敗（mapping 沒有殘留，代表原始 bug 無法用這個方式重現），如實記錄「無法重現」，不要調整測試邏輯硬湊出殘留的結果。

- [ ] **Step 3: Commit**

```bash
git add samples/tests/WireMockDemo.Experiments
git commit -m "test: add V3 bug reproduction and causal chain verification"
```

---

## Task 5: Plan A 最終驗證

**Files:**
- 無新檔案，純驗證

**Interfaces:**
- 無

- [ ] **Step 1: 全專案建置**

```bash
dotnet build samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj
```

Expected: `Build succeeded. 0 Warning(s) 0 Error(s)`

- [ ] **Step 2: 全部測試**

```bash
dotnet test samples/tests/WireMockDemo.Experiments/WireMockDemo.Experiments.csproj
```

Expected: 8 個測試（V1：1、V2：4、V3：3）全數通過或至少全數執行完畢——如果有測試因為「發現跟預期不同的真實行為」而失敗（例如 V1 的狀態碼不是 404、V3 的 bug 無法重現），這是合法結果，不是要修掉的錯誤；把失敗訊息完整記下來即可，不要為了讓這一步顯示全綠而回頭修改斷言。

- [ ] **Step 3: 確認沒有殘留的 wiremock container**

```bash
docker ps -a --filter "ancestor=sheyenrath/wiremock.net-alpine"
```

Expected: 空清單

- [ ] **Step 4: 把本次執行的實際輸出整理進 `docs/verification-results.md`**

建立（或如果已存在則附加）`docs/verification-results.md`，至少包含驗證 1～3 三個章節，每個章節記錄：實際執行的 `dotnet test --filter` 指令、實際輸出（狀態碼、mapping/request 數量、例外訊息等）、對照草稿原本主張的結論（confirmed／refuted／undetermined）。內容以 Task 2～4 的 Step 2 實際觀察到的結果為準，不要重寫成「預期會是」的語氣。

- [ ] **Step 5: Commit**

```bash
git add docs/verification-results.md
git commit -m "docs: record V1-V3 verification results"
```

---

## Self-Review 記錄

- **Spec coverage：** 對照 `docs/superpowers/specs/2026-07-27-wiremockdemo-experiments-design.md` 的驗證 1～3 段落——V1 的狀態碼與副作用（Task 2）、V2 的三個子項（Task 3，動態 mapping reset、request log reset、靜態 mapping reload 差異）、V3 的重現與因果鏈（Task 4）均有對應任務。`docs/verification-results.md` 的產出在 Task 5 涵蓋。
- **Placeholder scan：** 全文檢查過，沒有「TBD」「依此類推」這類字樣；Task 5 的「不要為了全綠回頭改斷言」是刻意的方法論指引，不是未完成的佔位內容。
- **Type consistency：** `StubProbeMappingAsync`／`BuggyResetAsync` 只在 Task 4 內部使用，沒有跨任務依賴；`IWireMockAdminApi`／`WireMockContainer`／`MappingModel` 等型別在 Task 2、3、4 的用法一致（都是 Task 1 建立的專案直接參照 `WireMock.Net.Testcontainers` 套件取得，不是本計畫自己定義的型別）。

---

**Plan complete and saved to `docs/superpowers/plans/2026-07-27-wiremockdemo-experiments-reset-behavior.md`. Two execution options:**

**1. Subagent-Driven (recommended)** - 每個任務派一個新的 subagent 執行，任務之間我會 review，適合快速迭代
**2. Inline Execution** - 在目前這個對話裡直接照 executing-plans 逐批執行，設檢查點讓你 review

**你要選哪一種？**
