# WireMockDemo 範例方案（Api + IntegrationTests）Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 建立 `samples/WireMockDemo.slnx`，包含最小化的 `WireMockDemo.Api`（開戶流程 Web API，依序呼叫三個外部服務）與 `WireMockDemo.IntegrationTests`（完整實作草稿裡的 WireMock 多 container 隔離架構），讓整個方案可以 `dotnet build` / `dotnet test` 全綠通過。

**Architecture:** `WireMockDemo.Api` 用三個具名 `HttpClient` 呼叫開戶主檔／身分驗證／金流三個外部服務；`WireMockDemo.IntegrationTests` 用 `WireMockFixture` 啟動三個 `WireMock.Net.Testcontainers` container（一服務一 container），每個測試前呼叫 `ResetAllAsync()` 清空狀態，並透過 `WebApplicationFactory<Program>` 在測試行程內跑 `WireMockDemo.Api`、把三個動態 base URL 注入設定。

**Tech Stack:** net10.0、xUnit v3（3.2.2）+ `xunit.runner.visualstudio`（VSTest）、`WireMock.Net.Testcontainers` 2.13.0、`Microsoft.AspNetCore.Mvc.Testing` 10.0.10。

## Global Constraints

- Target framework：`net10.0`（所有專案）
- 測試框架：xUnit v3 3.2.2，`IAsyncLifetime` 用 `ValueTask InitializeAsync()` / `ValueTask DisposeAsync()`（v3 簽章，非 v2 的 `Task`）
- 測試執行器：標準 VSTest（`xunit.runner.visualstudio` 3.1.5），**不**使用 Microsoft Testing Platform
- `Microsoft.NET.Test.Sdk` 版本 18.8.1
- `WireMock.Net.Testcontainers` 版本 **2.13.0**（比照使用者實際工作專案目前採用的版本）
- Container image **不手動指定版本**：直接用 `new WireMockContainerBuilder().Build()`，由 `WireMock.Net.Testcontainers` 2.13.0 自行決定要拉的映像（依作業系統自動選 Linux／Windows 映像），不在範例程式碼裡另外呼叫 `.WithImage(...)` 釘版本
- `Microsoft.AspNetCore.Mvc.Testing` 版本 10.0.10
- 測試斷言一律用 `AwesomeAssertions`（9.5.0）的 `.Should()` 語法，不用 xUnit 內建的 `Assert.*`（比照使用者實際工作專案的慣例）
- 工作目錄 `c:\github\WireMock-Testcontainers-Sample` 已於 2026-07-27 以 `git init` 建立為 git repository（第一個 commit 只含既有規劃文件）：本計畫的每個任務在建置／測試通過後都要 `git add` + `git commit`，維持一個任務一個 commit
- 本計畫範圍**只涵蓋** `WireMockDemo.Api` 與 `WireMockDemo.IntegrationTests` 兩個專案（對應 `docs/superpowers/specs/2026-07-27-wiremock-testcontainers-reset-sample-design.md` 的規劃）。`WireMockDemo.Experiments`（逐項技術驗證）與文章改寫是後續獨立的計畫，不在此計畫的任務範圍內
- 所有 WireMock admin API 方法名稱、`MappingModel`/`RequestModel`/`ResponseModel` 屬性、`WireMockContainer`/`WireMockContainerBuilder` 方法簽章，已於規劃階段直接查閱 `wiremock/WireMock.Net` GitHub 原始碼（`IWireMockAdminApi.cs`、`WireMockContainer.cs`、`WireMockContainerBuilder.cs`、`MappingModel.cs`、`RequestModel.cs`、`ResponseModel.cs`）核對，本計畫程式碼均以該次核對結果為準

---

## File Structure

```
samples/
  WireMockDemo.slnx
  src/
    WireMockDemo.Api/
      WireMockDemo.Api.csproj
      Program.cs                          # DI 註冊 + /api/open-account endpoint
      Contracts.cs                        # 對外/對外部服務的 DTO（全域命名空間）
      appsettings.json
  tests/
    WireMockDemo.IntegrationTests/
      WireMockDemo.IntegrationTests.csproj
      WireMockServices.cs                 # 服務名稱常數
      Infrastructure/
        WireMockFixture.cs                # container 啟動、reset、dispose、WebApplicationFactory
        WireMockCollection.cs             # [CollectionDefinition("wiremock")]
        WireMockStubExtensions.cs         # StubJsonAsync 擴充方法
        WireMockTestBase.cs               # 測試前呼叫 ResetAllAsync()
        WireMockFixtureTests.cs           # Fixture 自身的基礎連線／reset 驗證（最小必要，非逐項技術驗證）
      Tests/
        OpenAccountTests.cs
        PaymentFlowTests.cs
```

每個檔案職責單一：`WireMockFixture` 只管 container 生命週期與狀態重設，`WireMockStubExtensions` 只管 stub 設定的語法糖，`WireMockTestBase` 只管「測試前重設」這一件事，`Tests/` 底下的類別只放實際的業務情境測試。

---

## Task 1: 建立 Solution 與 `WireMockDemo.Api` 專案骨架

**Files:**

- Create: `samples/WireMockDemo.slnx`
- Create: `samples/src/WireMockDemo.Api/WireMockDemo.Api.csproj`
- Create: `samples/src/WireMockDemo.Api/Program.cs`
- Create: `samples/src/WireMockDemo.Api/appsettings.json`

**Interfaces:**

- Produces: `public partial class Program;`（供之後 `WebApplicationFactory<Program>` 使用）；三個具名 `HttpClient`："OpenAccountApi"、"IdentityApi"、"PaymentApi"，BaseAddress 讀自設定鍵 `ExternalServices:{Name}:BaseUrl`

- [ ] **Step 1: 建立目錄與 solution 檔**

```bash
mkdir -p samples/src/WireMockDemo.Api
dotnet new sln -n WireMockDemo -o samples -f slnx
```

- [ ] **Step 2: 寫入 `WireMockDemo.Api.csproj`**

```xml
<Project Sdk="Microsoft.NET.Sdk.Web">

  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <InvariantGlobalization>true</InvariantGlobalization>
  </PropertyGroup>

</Project>
```

- [ ] **Step 3: 寫入 `Program.cs`（先只做 DI 註冊，endpoint 留給 Task 2）**

```csharp
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient("OpenAccountApi", (serviceProvider, client) =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    client.BaseAddress = new Uri(configuration["ExternalServices:OpenAccountApi:BaseUrl"]!);
});

builder.Services.AddHttpClient("IdentityApi", (serviceProvider, client) =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    client.BaseAddress = new Uri(configuration["ExternalServices:IdentityApi:BaseUrl"]!);
});

builder.Services.AddHttpClient("PaymentApi", (serviceProvider, client) =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    client.BaseAddress = new Uri(configuration["ExternalServices:PaymentApi:BaseUrl"]!);
});

var app = builder.Build();

app.Run();

public partial class Program;
```

- [ ] **Step 4: 寫入 `appsettings.json`**

```json
{
  "ExternalServices": {
    "OpenAccountApi": {
      "BaseUrl": "http://localhost:9001"
    },
    "IdentityApi": {
      "BaseUrl": "http://localhost:9002"
    },
    "PaymentApi": {
      "BaseUrl": "http://localhost:9003"
    }
  }
}
```

- [ ] **Step 5: 加入 solution 並建置驗證**

```bash
dotnet sln samples/WireMockDemo.slnx add samples/src/WireMockDemo.Api/WireMockDemo.Api.csproj
dotnet build samples/src/WireMockDemo.Api/WireMockDemo.Api.csproj
```

Expected: `Build succeeded. 0 Warning(s) 0 Error(s)`

- [ ] **Step 6: Commit**

```bash
git add samples/WireMockDemo.slnx samples/src/WireMockDemo.Api
git commit -m "feat: scaffold WireMockDemo.Api project"
```

---

## Task 2: 實作 `/api/open-account` 端點邏輯

**Files:**

- Create: `samples/src/WireMockDemo.Api/Contracts.cs`
- Modify: `samples/src/WireMockDemo.Api/Program.cs`

**Interfaces:**

- Consumes: Task 1 的三個具名 `HttpClient`
- Produces: `public sealed record OpenAccountRequest(string ApplicantName, string IdentityNo, decimal InitialDeposit)`；`public sealed record OpenAccountResponse(string AccountNo, string Status)`；endpoint `POST /api/open-account`

這段邏輯本身沒有分支以外的商業規則（依序呼叫三個服務、身分驗證失敗就短路回 400），刻意不另外寫單元測試 —— 它真正的測試覆蓋來自 Task 7～9 用 WireMock 驅動的整合測試，那正是這個範例專案存在的目的，重複寫一層 mock-based 單元測試只是重工。

- [ ] **Step 1: 寫入 `Contracts.cs`（全域命名空間，不加 `namespace`，讓 `Program.cs` 的頂層陳述式可以直接引用）**

```csharp
public sealed record OpenAccountRequest(string ApplicantName, string IdentityNo, decimal InitialDeposit);

public sealed record OpenAccountResponse(string AccountNo, string Status);

internal sealed record OpenAccountApiRequest(string ApplicantName);

internal sealed record OpenAccountApiResponse(string AccountNo);

internal sealed record IdentityVerifyRequest(string IdentityNo);

internal sealed record IdentityVerifyResponse(bool Verified);

internal sealed record PaymentDepositRequest(string AccountNo, decimal Amount);

internal sealed record PaymentDepositResponse(string TransactionId, string Status);
```

- [ ] **Step 2: 修改 `Program.cs`，在 `var app = builder.Build();` 之後、`app.Run();` 之前加入 endpoint**

```csharp
app.MapPost("/api/open-account", async (OpenAccountRequest request, IHttpClientFactory httpClientFactory) =>
{
    var openAccountClient = httpClientFactory.CreateClient("OpenAccountApi");
    var openAccountResponse = await openAccountClient.PostAsJsonAsync(
        "/api/accounts",
        new OpenAccountApiRequest(request.ApplicantName));
    openAccountResponse.EnsureSuccessStatusCode();
    var account = await openAccountResponse.Content.ReadFromJsonAsync<OpenAccountApiResponse>()
        ?? throw new InvalidOperationException("OpenAccountApi returned an empty response.");

    var identityClient = httpClientFactory.CreateClient("IdentityApi");
    var identityResponse = await identityClient.PostAsJsonAsync(
        "/api/verify",
        new IdentityVerifyRequest(request.IdentityNo));
    identityResponse.EnsureSuccessStatusCode();
    var identity = await identityResponse.Content.ReadFromJsonAsync<IdentityVerifyResponse>()
        ?? throw new InvalidOperationException("IdentityApi returned an empty response.");

    if (!identity.Verified)
    {
        return Results.BadRequest(new { message = "Identity verification failed." });
    }

    var paymentClient = httpClientFactory.CreateClient("PaymentApi");
    var paymentResponse = await paymentClient.PostAsJsonAsync(
        "/api/deposits",
        new PaymentDepositRequest(account.AccountNo, request.InitialDeposit));
    paymentResponse.EnsureSuccessStatusCode();
    var payment = await paymentResponse.Content.ReadFromJsonAsync<PaymentDepositResponse>()
        ?? throw new InvalidOperationException("PaymentApi returned an empty response.");

    return Results.Ok(new OpenAccountResponse(account.AccountNo, payment.Status));
});
```

- [ ] **Step 3: 建置驗證**

```bash
dotnet build samples/src/WireMockDemo.Api/WireMockDemo.Api.csproj
```

Expected: `Build succeeded. 0 Warning(s) 0 Error(s)`

- [ ] **Step 4: Commit**

```bash
git add samples/src/WireMockDemo.Api
git commit -m "feat: implement /api/open-account endpoint logic"
```

---

## Task 3: 建立 `WireMockDemo.IntegrationTests` 專案骨架

**Files:**

- Create: `samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj`
- Create: `samples/tests/WireMockDemo.IntegrationTests/WireMockServices.cs`

**Interfaces:**

- Consumes: `WireMockDemo.Api` 專案（project reference）
- Produces: `public static class WireMockServices` 含 `OpenAccountApi`、`IdentityApi`、`PaymentApi` 三個 `const string`

- [ ] **Step 1: 建立目錄**

```bash
mkdir -p samples/tests/WireMockDemo.IntegrationTests/Infrastructure
mkdir -p samples/tests/WireMockDemo.IntegrationTests/Tests
```

- [ ] **Step 2: 寫入 `WireMockDemo.IntegrationTests.csproj`**

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <IsPackable>false</IsPackable>
    <OutputType>Exe</OutputType>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.NET.Test.Sdk" Version="18.8.1" />
    <PackageReference Include="xunit.v3" Version="3.2.2" />
    <PackageReference Include="xunit.runner.visualstudio" Version="3.1.5">
      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
      <PrivateAssets>all</PrivateAssets>
    </PackageReference>
    <PackageReference Include="Microsoft.AspNetCore.Mvc.Testing" Version="10.0.10" />
    <PackageReference Include="WireMock.Net.Testcontainers" Version="2.13.0" />
    <PackageReference Include="AwesomeAssertions" Version="9.5.0" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="..\..\src\WireMockDemo.Api\WireMockDemo.Api.csproj" />
  </ItemGroup>

</Project>
```

- [ ] **Step 3: 寫入 `WireMockServices.cs`**

```csharp
namespace WireMockDemo.IntegrationTests;

public static class WireMockServices
{
    public const string OpenAccountApi = "OpenAccountApi";
    public const string IdentityApi = "IdentityApi";
    public const string PaymentApi = "PaymentApi";
}
```

- [ ] **Step 4: 加入 solution 並建置驗證**

```bash
dotnet sln samples/WireMockDemo.slnx add samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj
dotnet build samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj
```

Expected: `Build succeeded. 0 Warning(s) 0 Error(s)`（此時專案內還沒有任何測試，屬正常）

- [ ] **Step 5: Commit**

```bash
git add samples/WireMockDemo.slnx samples/tests/WireMockDemo.IntegrationTests
git commit -m "feat: scaffold WireMockDemo.IntegrationTests project"
```

---

## Task 4: `WireMockFixture` 核心（container 啟動、`WebApplicationFactory`、dispose）+ `WireMockCollection`

**Files:**

- Create: `samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockCollection.cs`
- Create: `samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockFixture.cs`
- Test: `samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockFixtureTests.cs`

**Interfaces:**

- Consumes: `WireMockServices`（Task 3）、`Program`（Task 1，`WireMockDemo.Api` 的全域命名空間類別）
- Produces: `WireMockFixture.BaseUrl(string serviceName)`、`WireMockFixture.Admin(string serviceName)`、`WireMockFixture.Factory`（`WebApplicationFactory<Program>`）、`WireMockCollection.Name = "wiremock"`

- [ ] **Step 1: 寫入 `WireMockCollection.cs`**

```csharp
using Xunit;

namespace WireMockDemo.IntegrationTests.Infrastructure;

[CollectionDefinition(Name)]
public sealed class WireMockCollection : ICollectionFixture<WireMockFixture>
{
    public const string Name = "wiremock";
}
```

- [ ] **Step 2: 寫入 `WireMockFixture.cs`（core：啟動、baseurl/admin、factory、dispose；`ResetAllAsync` 留給 Task 6）**

```csharp
using System.Collections.Concurrent;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using WireMock.Client;
using WireMock.Net.Testcontainers;
using Xunit;

namespace WireMockDemo.IntegrationTests.Infrastructure;

public sealed class WireMockFixture : IAsyncLifetime
{
    private static readonly string[] Services =
    {
        WireMockServices.OpenAccountApi,
        WireMockServices.IdentityApi,
        WireMockServices.PaymentApi,
    };

    private readonly ConcurrentDictionary<string, WireMockContainer> _containers = new();
    private readonly ConcurrentDictionary<string, IWireMockAdminApi> _admins = new();
    private readonly ConcurrentDictionary<string, string> _baseUrls = new();

    private bool _disposed;

    public WebApplicationFactory<Program> Factory { get; private set; } = null!;

    public async ValueTask InitializeAsync()
    {
        try
        {
            await Task.WhenAll(Services.Select(StartAsync));
        }
        catch
        {
            // Task.WhenAll 只會拋出第一個例外，此時可能已經有部分 container 成功啟動。
            // InitializeAsync 拋例外時 xUnit 不會呼叫 DisposeAsync，所以要自己釋放，避免孤兒 container。
            await DisposeAsync();
            throw;
        }

        Factory = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
        {
            builder.ConfigureAppConfiguration((_, configurationBuilder) =>
            {
                configurationBuilder.AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["ExternalServices:OpenAccountApi:BaseUrl"] = BaseUrl(WireMockServices.OpenAccountApi),
                    ["ExternalServices:IdentityApi:BaseUrl"] = BaseUrl(WireMockServices.IdentityApi),
                    ["ExternalServices:PaymentApi:BaseUrl"] = BaseUrl(WireMockServices.PaymentApi),
                });
            });
        });
    }

    private async Task StartAsync(string serviceName)
    {
        var container = new WireMockContainerBuilder().Build();
        await container.StartAsync();

        _containers[serviceName] = container;
        _admins[serviceName] = container.CreateWireMockAdminClient();
        _baseUrls[serviceName] = container.GetPublicUrl();
    }

    public string BaseUrl(string serviceName) => _baseUrls[serviceName];

    public IWireMockAdminApi Admin(string serviceName) => _admins[serviceName];

    public async ValueTask DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;

        if (Factory is not null)
        {
            await Factory.DisposeAsync();
        }

        await Task.WhenAll(_containers.Values.Select(c => c.DisposeAsync().AsTask()));
    }
}
```

- [ ] **Step 3: 寫入測試 `WireMockFixtureTests.cs`**

```csharp
using System.Linq;
using AwesomeAssertions;
using Xunit;

namespace WireMockDemo.IntegrationTests.Infrastructure;

public sealed class WireMockFixtureTests : IClassFixture<WireMockFixture>
{
    private readonly WireMockFixture _fixture;

    public WireMockFixtureTests(WireMockFixture fixture)
    {
        _fixture = fixture;
    }

    [Fact]
    public async Task 三個容器啟動後_應提供互不相同且可連線的端點()
    {
        var serviceNames = new[] { WireMockServices.OpenAccountApi, WireMockServices.IdentityApi, WireMockServices.PaymentApi };
        var urls = serviceNames.Select(_fixture.BaseUrl).ToArray();

        urls.Should().OnlyHaveUniqueItems();

        foreach (var serviceName in serviceNames)
        {
            var health = await _fixture.Admin(serviceName).GetHealthAsync(TestContext.Current.CancellationToken);
            health.Should().Be("Healthy");
        }
    }
}
```

這個測試用 `IClassFixture<WireMockFixture>` 而不是 `[Collection(WireMockCollection.Name)]`，是刻意的：它只是驗證 fixture 本身能不能正確啟動，不需要跟其他測試共用同一份 container，用 class-level fixture 讓它獨立、不受其他測試類別影響。從 Task 7 開始的業務情境測試才會改用 `WireMockCollection` 共用同一份。

- [ ] **Step 4: 執行測試確認通過**

```bash
dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj --filter "FullyQualifiedName~WireMockFixtureTests"
```

Expected: 1 個測試通過（`docker ps` 應會短暫看到 3 個 wiremock container 啟動又消失）

- [ ] **Step 5: Commit**

```bash
git add samples/tests/WireMockDemo.IntegrationTests
git commit -m "feat: add WireMockFixture core with container startup and WebApplicationFactory wiring"
```

---

## Task 5: `WireMockStubExtensions.StubJsonAsync`

**Files:**

- Create: `samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockStubExtensions.cs`
- Modify: `samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockFixtureTests.cs`

**Interfaces:**

- Consumes: `IWireMockAdminApi`（`WireMock.Client`）
- Produces: `Task StubJsonAsync(this IWireMockAdminApi admin, string method, string path, int statusCode, object body)`

- [ ] **Step 1: 寫入 `WireMockStubExtensions.cs`**

```csharp
using WireMock.Admin.Mappings;
using WireMock.Client;

namespace WireMockDemo.IntegrationTests.Infrastructure;

public static class WireMockStubExtensions
{
    public static Task StubJsonAsync(
        this IWireMockAdminApi admin,
        string method,
        string path,
        int statusCode,
        object body)
    {
        // 不指定 Guid：讓每次都是全新的 mapping。
        // 不設 IsPersistent：確保 ResetMappingsAsync 清得掉。
        return admin.PostMappingAsync(new MappingModel
        {
            Request = new RequestModel
            {
                Path = path,
                Methods = new[] { method },
            },
            Response = new ResponseModel
            {
                StatusCode = statusCode,
                Headers = new Dictionary<string, object> { ["Content-Type"] = "application/json" },
                BodyAsJson = body,
            },
        });
    }
}
```

- [ ] **Step 2: 在 `WireMockFixtureTests.cs` 加入驗證這個擴充方法的測試**

在既有的 `WireMockFixtureTests` 類別內加入（記得在檔案頂端補上 `using System.Net;` 與 `using System.Net.Http.Json;`）：

```csharp
[Fact]
public async Task StubJsonAsync下的Mapping_應能透過該服務的HttpClient實際取得回應()
{
    await _fixture.Admin(WireMockServices.OpenAccountApi)
        .StubJsonAsync("GET", "/api/ping", 200, new { message = "pong" });

    using var client = new HttpClient { BaseAddress = new Uri(_fixture.BaseUrl(WireMockServices.OpenAccountApi)) };
    var response = await client.GetAsync("/api/ping", TestContext.Current.CancellationToken);
    var body = await response.Content.ReadFromJsonAsync<PingResponse>(TestContext.Current.CancellationToken);

    response.StatusCode.Should().Be(HttpStatusCode.OK);
    body!.Message.Should().Be("pong");
}

private sealed record PingResponse(string Message);
```

- [ ] **Step 3: 執行測試確認通過**

```bash
dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj --filter "FullyQualifiedName~WireMockFixtureTests"
```

Expected: 2 個測試通過

- [ ] **Step 4: Commit**

```bash
git add samples/tests/WireMockDemo.IntegrationTests
git commit -m "feat: add WireMockStubExtensions.StubJsonAsync"
```

---

## Task 6: `WireMockFixture.ResetAllAsync` + `WireMockTestBase`

**Files:**

- Modify: `samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockFixture.cs`
- Create: `samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockTestBase.cs`
- Modify: `samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockFixtureTests.cs`

**Interfaces:**

- Consumes: `WireMockStubExtensions.StubJsonAsync`（Task 5）
- Produces: `WireMockFixture.ResetAllAsync()`；`abstract class WireMockTestBase(WireMockFixture fixture) : IAsyncLifetime`，標有 `[Collection(WireMockCollection.Name)]`

- [ ] **Step 1: 在 `WireMockFixture.cs` 的 `DisposeAsync` 之前加入 `ResetAllAsync`**

```csharp
public async Task ResetAllAsync()
{
    foreach (var (name, admin) in _admins)
    {
        await admin.ResetMappingsAsync();
        await admin.ResetRequestsAsync();

        var remaining = await admin.GetMappingsAsync();
        if (remaining.Count != 0)
        {
            throw new InvalidOperationException(
                $"[{name}] reset 後仍殘留 {remaining.Count} 筆 mapping：" +
                string.Join(", ", remaining.Select(m => $"{m.Guid}:{m.Request?.Path}")));
        }
    }
}
```

- [ ] **Step 2: 寫入 `WireMockTestBase.cs`**

```csharp
using Xunit;

namespace WireMockDemo.IntegrationTests.Infrastructure;

[Collection(WireMockCollection.Name)]
public abstract class WireMockTestBase : IAsyncLifetime
{
    protected readonly WireMockFixture Fixture;

    protected WireMockTestBase(WireMockFixture fixture)
    {
        Fixture = fixture;
    }

    // 注意：放在 InitializeAsync（測試前），不是 DisposeAsync（測試後）——
    // 每個測試自己保證起點乾淨，不依賴「上一個測試有沒有正確收尾」。
    public async ValueTask InitializeAsync() => await Fixture.ResetAllAsync();

    public ValueTask DisposeAsync() => default;
}
```

- [ ] **Step 3: 在 `WireMockFixtureTests.cs` 加入驗證 `ResetAllAsync` 的測試**

```csharp
[Fact]
public async Task ResetAllAsync_三個服務皆有殘留Mapping_應清空全部服務的Mapping與RequestLog()
{
    await _fixture.Admin(WireMockServices.OpenAccountApi)
        .StubJsonAsync("GET", "/api/leftover-open-account", 200, new { });
    await _fixture.Admin(WireMockServices.IdentityApi)
        .StubJsonAsync("GET", "/api/leftover-identity", 200, new { });
    await _fixture.Admin(WireMockServices.PaymentApi)
        .StubJsonAsync("GET", "/api/leftover-payment", 200, new { });

    await _fixture.ResetAllAsync();

    var serviceNames = new[] { WireMockServices.OpenAccountApi, WireMockServices.IdentityApi, WireMockServices.PaymentApi };
    foreach (var serviceName in serviceNames)
    {
        var mappings = await _fixture.Admin(serviceName).GetMappingsAsync(TestContext.Current.CancellationToken);
        mappings.Should().BeEmpty();
    }
}
```

- [ ] **Step 4: 執行測試確認通過**

```bash
dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj --filter "FullyQualifiedName~WireMockFixtureTests"
```

Expected: 3 個測試通過

- [ ] **Step 5: Commit**

```bash
git add samples/tests/WireMockDemo.IntegrationTests
git commit -m "feat: add WireMockFixture.ResetAllAsync and WireMockTestBase"
```

---

## Task 7: `OpenAccountTests` —— 開戶成功

**Files:**

- Create: `samples/tests/WireMockDemo.IntegrationTests/Tests/OpenAccountTests.cs`

**Interfaces:**

- Consumes: `WireMockTestBase`（Task 6）、`WireMockStubExtensions.StubJsonAsync`（Task 5）、`Fixture.Factory`（Task 4）、`OpenAccountRequest`/`OpenAccountResponse`（Task 2，全域命名空間）

- [ ] **Step 1: 寫入 `OpenAccountTests.cs`**

```csharp
using System.Net;
using System.Net.Http.Json;
using AwesomeAssertions;
using WireMockDemo.IntegrationTests.Infrastructure;
using Xunit;

namespace WireMockDemo.IntegrationTests.Tests;

public sealed class OpenAccountTests : WireMockTestBase
{
    public OpenAccountTests(WireMockFixture fixture) : base(fixture)
    {
    }

    [Fact]
    public async Task 開戶成功_應回傳帳號()
    {
        await Fixture.Admin(WireMockServices.OpenAccountApi)
            .StubJsonAsync("POST", "/api/accounts", 200, new { accountNo = "0012345678" });
        await Fixture.Admin(WireMockServices.IdentityApi)
            .StubJsonAsync("POST", "/api/verify", 200, new { verified = true });
        await Fixture.Admin(WireMockServices.PaymentApi)
            .StubJsonAsync("POST", "/api/deposits", 200, new { transactionId = "TX-001", status = "Completed" });

        using var client = Fixture.Factory.CreateClient();
        var response = await client.PostAsJsonAsync(
            "/api/open-account",
            new OpenAccountRequest("Kevin", "A123456789", 1000m),
            TestContext.Current.CancellationToken);

        response.StatusCode.Should().Be(HttpStatusCode.OK);
        var result = await response.Content.ReadFromJsonAsync<OpenAccountResponse>(TestContext.Current.CancellationToken);
        result!.AccountNo.Should().Be("0012345678");
        result.Status.Should().Be("Completed");
    }
}
```

- [ ] **Step 2: 執行測試確認通過**

```bash
dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj --filter "FullyQualifiedName~OpenAccountTests"
```

Expected: 1 個測試通過。這是整條鏈路（3 個 container + fixture + `WebApplicationFactory` + 真實 `WireMockDemo.Api` 端點邏輯）第一次被完整跑過，如果失敗，優先檢查 `WireMockFixture.InitializeAsync` 注入的設定鍵名稱是否與 `Program.cs` 讀取的鍵名稱一致。

- [ ] **Step 3: Commit**

```bash
git add samples/tests/WireMockDemo.IntegrationTests
git commit -m "test: add OpenAccountTests success scenario"
```

---

## Task 8: `OpenAccountTests` —— 身分驗證失敗

**Files:**

- Modify: `samples/tests/WireMockDemo.IntegrationTests/Tests/OpenAccountTests.cs`

**Interfaces:**

- Consumes: 同 Task 7；額外使用 `Fixture.Admin(...).GetRequestsAsync()`

- [ ] **Step 1: 在 `OpenAccountTests` 類別內加入第二個 `[Fact]`**

```csharp
[Fact]
public async Task 身分驗證失敗_應回傳400且不呼叫金流服務()
{
    await Fixture.Admin(WireMockServices.OpenAccountApi)
        .StubJsonAsync("POST", "/api/accounts", 200, new { accountNo = "0099999999" });
    await Fixture.Admin(WireMockServices.IdentityApi)
        .StubJsonAsync("POST", "/api/verify", 200, new { verified = false });

    using var client = Fixture.Factory.CreateClient();
    var response = await client.PostAsJsonAsync(
        "/api/open-account",
        new OpenAccountRequest("Kevin", "A000000000", 1000m),
        TestContext.Current.CancellationToken);

    response.StatusCode.Should().Be(HttpStatusCode.BadRequest);

    var paymentRequests = await Fixture.Admin(WireMockServices.PaymentApi).GetRequestsAsync(TestContext.Current.CancellationToken);
    paymentRequests.Should().BeEmpty();
}
```

注意這個測試**沒有**替 PaymentApi 下任何 stub —— 如果 `Program.cs` 的短路邏輯寫錯、不小心呼叫了金流服務，WireMock 會因為找不到對應 mapping 回 404，`EnsureSuccessStatusCode()` 會拋例外，最終回應會是 500 而不是 400，這個測試會直接失敗並指出問題所在。

- [ ] **Step 2: 執行測試確認通過**

```bash
dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj --filter "FullyQualifiedName~OpenAccountTests"
```

Expected: 2 個測試通過

- [ ] **Step 3: Commit**

```bash
git add samples/tests/WireMockDemo.IntegrationTests
git commit -m "test: add OpenAccountTests identity-verification-failed scenario"
```

---

## Task 9: `OpenAccountTests` —— 污染敏感的重複呼叫測試

**Files:**

- Modify: `samples/tests/WireMockDemo.IntegrationTests/Tests/OpenAccountTests.cs`

**Interfaces:**

- Consumes: 同 Task 7

- [ ] **Step 1: 在 `OpenAccountTests` 類別內加入第三個 `[Fact]`**

```csharp
[Fact]
public async Task 重複呼叫開戶成功情境_應回傳目前stub的帳號而非前次殘留值()
{
    await Fixture.Admin(WireMockServices.OpenAccountApi)
        .StubJsonAsync("POST", "/api/accounts", 200, new { accountNo = "0088888888" });
    await Fixture.Admin(WireMockServices.IdentityApi)
        .StubJsonAsync("POST", "/api/verify", 200, new { verified = true });
    await Fixture.Admin(WireMockServices.PaymentApi)
        .StubJsonAsync("POST", "/api/deposits", 200, new { transactionId = "TX-002", status = "Completed" });

    using var client = Fixture.Factory.CreateClient();
    var response = await client.PostAsJsonAsync(
        "/api/open-account",
        new OpenAccountRequest("Kevin", "A123456789", 1000m),
        TestContext.Current.CancellationToken);

    var result = await response.Content.ReadFromJsonAsync<OpenAccountResponse>(TestContext.Current.CancellationToken);

    response.StatusCode.Should().Be(HttpStatusCode.OK);
    result!.AccountNo.Should().Be("0088888888");
    result.AccountNo.Should().NotBe("0012345678");
}
```

`"0012345678"` 是 Task 7 測試用的帳號值；這裡刻意用不同值下 stub，並明確斷言**不是**前一個測試的殘留值。如果 `WireMockTestBase.InitializeAsync` 沒有正確呼叫 `ResetAllAsync()`，這個測試最可能的失敗方式是 WireMock 用第一個符合的 mapping 回應（先前殘留的那筆），導致斷言失敗。

- [ ] **Step 2: 執行測試確認通過**

```bash
dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj --filter "FullyQualifiedName~OpenAccountTests"
```

Expected: 3 個測試通過

- [ ] **Step 3: Commit**

```bash
git add samples/tests/WireMockDemo.IntegrationTests
git commit -m "test: add pollution-sensitive repeat-call scenario to OpenAccountTests"
```

---

## Task 10: `PaymentFlowTests` —— 跨測試類別的 request journal 隔離

**Files:**

- Create: `samples/tests/WireMockDemo.IntegrationTests/Tests/PaymentFlowTests.cs`

**Interfaces:**

- Consumes: 同 Task 7（`WireMockTestBase`、`WireMockStubExtensions`、`Fixture.Factory`）

- [ ] **Step 1: 寫入 `PaymentFlowTests.cs`**

```csharp
using System.Net.Http.Json;
using AwesomeAssertions;
using WireMockDemo.IntegrationTests.Infrastructure;
using Xunit;

namespace WireMockDemo.IntegrationTests.Tests;

public sealed class PaymentFlowTests : WireMockTestBase
{
    public PaymentFlowTests(WireMockFixture fixture) : base(fixture)
    {
    }

    [Fact]
    public async Task 金流服務RequestLog_不應包含其他測試類別殘留的請求()
    {
        var existingRequests = await Fixture.Admin(WireMockServices.PaymentApi).GetRequestsAsync(TestContext.Current.CancellationToken);
        existingRequests.Should().BeEmpty();

        await Fixture.Admin(WireMockServices.OpenAccountApi)
            .StubJsonAsync("POST", "/api/accounts", 200, new { accountNo = "0077777777" });
        await Fixture.Admin(WireMockServices.IdentityApi)
            .StubJsonAsync("POST", "/api/verify", 200, new { verified = true });
        await Fixture.Admin(WireMockServices.PaymentApi)
            .StubJsonAsync("POST", "/api/deposits", 200, new { transactionId = "TX-003", status = "Completed" });

        using var client = Fixture.Factory.CreateClient();
        await client.PostAsJsonAsync(
            "/api/open-account",
            new OpenAccountRequest("Alice", "B123456789", 500m),
            TestContext.Current.CancellationToken);

        var requestsAfterCall = await Fixture.Admin(WireMockServices.PaymentApi).GetRequestsAsync(TestContext.Current.CancellationToken);
        requestsAfterCall.Should().ContainSingle();
    }
}
```

第一個斷言（`existingRequests` 應為空）直接證明：`OpenAccountTests`（Task 7、9）雖然也呼叫過金流服務，但它的 request journal 沒有殘留到這個完全不同的測試類別 —— 這是跨類別共用同一份 `WireMockFixture` 時最容易翻車的地方。

- [ ] **Step 2: 執行測試確認通過**

```bash
dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj --filter "FullyQualifiedName~PaymentFlowTests"
```

Expected: 1 個測試通過

- [ ] **Step 3: Commit**

```bash
git add samples/tests/WireMockDemo.IntegrationTests
git commit -m "test: add PaymentFlowTests cross-class request journal isolation"
```

---

## Task 11: 全方案最終驗證

**Files:**

- 無新檔案，純驗證

**Interfaces:**

- 無

- [ ] **Step 1: 全方案建置**

```bash
dotnet build samples/WireMockDemo.slnx
```

Expected: `Build succeeded. 0 Warning(s) 0 Error(s)`

- [ ] **Step 2: 全方案測試**

```bash
dotnet test samples/WireMockDemo.slnx
```

Expected: 全部測試通過（`WireMockFixtureTests` 3 個 + `OpenAccountTests` 3 個 + `PaymentFlowTests` 1 個 = 7 個），0 個失敗

- [ ] **Step 3: 確認沒有殘留的 wiremock container**

```bash
docker ps -a --filter "ancestor=sheyenrath/wiremock.net-alpine"
```

Expected: 空清單（測試結束後所有 container 都應被 `WireMockFixture.DisposeAsync` 清乾淨）。如果有殘留，記下 container ID 與狀態，這本身就是後續 Experiments 專案驗證 4（xUnit 生命週期）要交叉確認的線索之一，先不要手動刪除，向使用者回報。

---

## Self-Review 記錄

- **Spec coverage：** 對照 `docs/superpowers/specs/2026-07-27-wiremock-testcontainers-reset-sample-design.md` 的「範例結構」段落 —— `WireMockDemo.Api`（Task 1-2）、`WireMockServices`/`WireMockFixture`/`WireMockStubExtensions`/`WireMockTestBase`/`WireMockCollection`（Task 3-6）、`OpenAccountTests` 三個案例（Task 7-9）、`PaymentFlowTests`（Task 10）均有對應任務。`WireMockDemo.Experiments` 依規劃刻意排除於本計畫之外，已在 Global Constraints 說明。
- **Placeholder scan：** 全文檢查過，沒有 "TBD"／"待補"／"依上述類推" 這類字樣，每個 Step 都是完整可執行的程式碼或指令。
- **Type consistency：** `WireMockFixture.BaseUrl`/`Admin`/`ResetAllAsync`/`Factory` 在 Task 4/6 定義後，Task 7-10 的用法（`Fixture.Admin(...)`、`Fixture.Factory.CreateClient()`）一致；`OpenAccountRequest`/`OpenAccountResponse` 的建構參數順序（`ApplicantName, IdentityNo, InitialDeposit`／`AccountNo, Status`）在 Task 2 定義後，Task 7/9/10 呼叫端與之一致。

---

**Plan complete and saved to `docs/superpowers/plans/2026-07-27-wiremockdemo-sample-solution.md`. Two execution options:**

**1. Subagent-Driven (recommended)** - 每個任務派一個新的 subagent 執行，任務之間我會 review，適合快速迭代
**2. Inline Execution** - 在目前這個對話裡直接照 executing-plans 逐批執行，設檢查點讓你review

**你要選哪一種？**
