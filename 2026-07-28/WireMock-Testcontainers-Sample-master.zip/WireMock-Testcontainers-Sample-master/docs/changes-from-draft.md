# 改寫紀錄

這份文件供作者 review，不對外發表。

## 改寫方向

原始草稿與早期發表版混合了問題排查、架構規劃、行為實驗、效能量測與設計取捨。最終公開版改為只保留讀者解決問題所需的內容：

1. 多服務各使用一個 WireMock container。
2. 共用 container 時，每個測試開始前清除 mappings 與 request log。
3. WireMock.Net 不支援 Java WireMock 的 `POST /__admin/reset`。
4. 404 經過 `EnsureSuccessStatusCode()` 會中斷流程，使後續 reset 沒有執行。
5. 使用 `IWireMockAdminApi.ResetMappingsAsync()` 與 `ResetRequestsAsync()`。
6. reset 後立即驗證 mappings 為空。
7. 用 xUnit Collection Fixture 與測試基底類別集中管理隔離。

## 從公開文章移除的內容

- V1～V8 的逐項實驗過程與完整輸出。
- xUnit 平行執行時間戳記。
- `Dictionary` 並行寫入實驗。
- `ConcurrentDictionary` 的長篇設計取捨。
- container 與 in-process server 的效能 benchmark。
- xUnit 生命週期 marker 探測。
- 被考慮但未採用的替代實作。
- 規劃階段與開發階段的敘事。

這些內容仍保留在 `docs/verification-results.md`、`docs/superpowers/` 與 `samples/tests/WireMockDemo.Experiments`，作為可追溯的驗證證據。

## 技術修正

### 精確描述例外因果

舊版文章把 mapping 殘留直接描述成跨測試污染。新版改為：

- `POST /__admin/reset` 在 WireMock.Net 回傳 404。
- `EnsureSuccessStatusCode()` 拋出 `HttpRequestException`。
- 後續 `ResetMappingsAsync()` 與 `ResetRequestsAsync()` 沒有執行。
- 未捕捉例外時，測試初始化直接失敗。
- 若外層記錄或忽略例外，才可能表現成狀態沒有清除。

這避免把實驗中刻意吞掉例外的做法誤寫成正式程式的行為。

### 補齊 container 啟動失敗清理

成功啟動並加入 registry 的 containers 由 fixture 外層清理；啟動失敗且尚未加入 registry 的 container，改由 `StartAsync()` 內層 `catch` 直接釋放。

### 補齊測試隔離驗證

- `ResetAllAsync` 接受並傳遞 cancellation token。
- fixture 測試會真的建立 request log，再驗證 mappings 與 requests 都被清空。
- reset 行為在單一測試內建立舊狀態與新狀態，不依賴 xUnit 測試順序。
- API 對外 HTTP 呼叫傳遞 cancellation token 並釋放 `HttpResponseMessage`。

### 分離破壞性實驗

xUnit 生命週期探測會刻意拋例外，現在標記為 explicit tests，預設 solution 測試不執行。Marker 在探測開始前也會先刪除，避免舊檔影響判讀。

### 補齊程式碼文件

`samples/` 下的 API contracts、正式整合測試基礎設施、測試案例與 V1～V8 experiments，均補上 XML `<summary>`、參數與回傳值說明。公開文章內引用的程式碼片段同步保留相同文件註解，避免文章範例與 repository 實作不一致。

## 保留的原始資料

- `articles/wiremock-testcontainers-reset.md`：原始草稿。
- `docs/verification-results.md`：逐項驗證結果。
- `docs/superpowers/`：各階段設計與實作計畫。
- `WireMockDemo.Experiments`：可重現的實驗程式。

公開文章不再承擔保存開發歷程的角色。
