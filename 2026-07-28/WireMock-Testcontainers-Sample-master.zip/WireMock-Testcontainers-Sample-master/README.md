# WireMock.Net Testcontainers 多服務整合測試範例

這個 repository 示範如何在 ASP.NET Core 整合測試中，使用
`WireMock.Net.Testcontainers` 模擬多個外部 HTTP 服務，並在共用 containers
的前提下維持每個測試的狀態隔離。

範例情境是一個開戶 API，流程會依序呼叫：

1. 開戶主檔服務
2. 身分驗證服務
3. 金流服務

測試環境讓每個外部服務各自使用一個 WireMock container，再透過 xUnit
Collection Fixture 讓不同測試類別共用這三個 containers，避免為每個測試
重複支付容器啟動成本。

## 核心問題

共用 WireMock container 時，前一個測試留下的 mappings 或 request log
可能影響後續測試，因此每個測試都必須從乾淨狀態開始。

本範例採用 WireMock.Net admin client 提供的 API：

```csharp
await admin.ResetMappingsAsync(cancellationToken: cancellationToken);
await admin.ResetRequestsAsync(cancellationToken);
```

不要額外呼叫 Java WireMock 的 `POST /__admin/reset`。WireMock.Net
沒有這個管理端點，請求會收到 `404 Not Found`；如果接著呼叫
`EnsureSuccessStatusCode()`，例外會使真正的 reset 程式碼根本沒有機會執行。

## 解決方案設計

正式整合測試採用以下策略：

- 一個外部服務對應一個 WireMock container，避免服務狀態混在一起。
- 使用 xUnit Collection Fixture，在多個測試類別間共用 containers。
- 透過 `WebApplicationFactory<Program>` 將動態 container URL 注入 API。
- 在每個測試的 `InitializeAsync()` 清除全部 mappings 與 request logs。
- reset 後再次查詢 mappings；若仍有殘留，立即讓測試失敗。
- 平行啟動三個 containers，縮短整體初始化時間。
- 初始化失敗時主動釋放已建立的 containers，避免留下孤兒資源。

```text
測試
  │
  ├─ WebApplicationFactory<Program> ── 開戶 API
  │                                      │
  │                                      ├─ OpenAccountApi container
  │                                      ├─ IdentityApi container
  │                                      └─ PaymentApi container
  │
  └─ IWireMockAdminApi ── 設定 stub、清除 mapping、清除 request log
```

共用 fixture 的主要實作位於
[`WireMockFixture.cs`](samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockFixture.cs)，
每個測試開始前的隔離機制位於
[`WireMockTestBase.cs`](samples/tests/WireMockDemo.IntegrationTests/Infrastructure/WireMockTestBase.cs)。

## 專案結構

```text
.
├─ samples/
│  ├─ WireMockDemo.slnx
│  ├─ src/
│  │  └─ WireMockDemo.Api/                 # 最小開戶 API
│  └─ tests/
│     ├─ WireMockDemo.IntegrationTests/     # 正式解決方案與整合測試
│     └─ WireMockDemo.Experiments/          # 行為、生命週期與效能實驗
├─ articles/
│  ├─ wiremock-testcontainers-reset.md      # 原始文章草稿
│  └─ wiremock-testcontainers-reset-published.md
│                                           # 解決方案導向的公開版本
└─ docs/
   ├─ verification-results.md               # 技術主張與實測結果
   ├─ changes-from-draft.md                  # 公開文章修改摘要
   └─ superpowers/                           # 歷史設計與實作計畫
```

`docs/superpowers/` 記錄各階段的規劃與實驗脈絡，內容可能反映當時尚未完成的
狀態。若內容不一致，應以目前程式碼、[`verification-results.md`](docs/verification-results.md)
和公開文章為準。

## 環境需求

- .NET 10 SDK
- 可正常執行 Linux containers 的 Docker 環境，例如 Docker Desktop
- 可連線至 container registry，以便第一次執行時下載 WireMock image

目前使用的主要套件版本：

| 套件 | 版本 |
| --- | --- |
| `xunit.v3` | 3.2.2 |
| `WireMock.Net.Testcontainers` | 2.13.0 |
| `Microsoft.AspNetCore.Mvc.Testing` | 10.0.10 |
| `AwesomeAssertions` | 9.5.0 |

## 快速開始

以下指令都從 repository 根目錄執行。

還原與建置：

```bash
dotnet restore samples/WireMockDemo.slnx
dotnet build samples/WireMockDemo.slnx --no-restore
```

只執行正式整合測試：

```bash
dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj
```

執行完整 solution，包括實驗與效能驗證：

```bash
dotnet test samples/WireMockDemo.slnx
```

完整 solution 的執行時間會比正式整合測試長，因為 experiments 包含多次
container 啟動的計時測試。兩個刻意拋出例外的 xUnit 生命週期探針已標記為
explicit tests，日常執行時不會執行。

若只想執行開戶流程測試：

```bash
dotnet test samples/tests/WireMockDemo.IntegrationTests/WireMockDemo.IntegrationTests.csproj \
  --filter "FullyQualifiedName~OpenAccountTests"
```

測試結束後可以確認沒有殘留 WireMock containers：

```bash
docker ps -a --filter "ancestor=sheyenrath/wiremock.net-alpine"
```

## 測試內容

### 正式整合測試

[`WireMockDemo.IntegrationTests`](samples/tests/WireMockDemo.IntegrationTests)
涵蓋：

- 三個 WireMock containers 的啟動、連線與獨立 URL。
- 開戶成功時的完整三服務流程。
- 身分驗證失敗時回傳 `400 Bad Request`，且不呼叫金流服務。
- reset 後重新設定相同路徑，只會取得新的 stub 回應。
- 不同測試類別之間不會殘留 request log。
- mappings 與 request logs 能從全部服務完整清除。

### 實驗專案

[`WireMockDemo.Experiments`](samples/tests/WireMockDemo.Experiments)
保留文章改寫前用來驗證技術主張的實驗：

| 組別 | 驗證內容 |
| --- | --- |
| V1 | WireMock.Net 是否提供 `POST /__admin/reset` |
| V2 | mappings、request logs 與 static mappings 的 reset 行為 |
| V3 | 錯誤 reset 流程的 bug 與例外因果鏈 |
| V4 | xUnit `IAsyncLifetime` 發生例外時的清理行為 |
| V5 | 相同與不同 test collection 的平行執行行為 |
| V6 | `Dictionary` 與 `ConcurrentDictionary` 的行為差異 |
| V7 | in-process server 與 containers 的啟動時間 |
| V8 | in-process `WireMockServer` 的 admin interface 行為 |

實驗的實際輸出、成立條件與未能重現的項目，都記錄在
[`docs/verification-results.md`](docs/verification-results.md)，不會混入公開文章的
解決方案主線。

## 延伸閱讀

- [公開文章：WireMock.Net.Testcontainers 多服務整合測試：正確重置共用 Container](articles/wiremock-testcontainers-reset-published.md)
- [完整驗證結果](docs/verification-results.md)
- [原始草稿與公開版本的差異](docs/changes-from-draft.md)
