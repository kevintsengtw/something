# CLAUDE.md — dotnet-testing-codex-agent-extension

## 專案概述

這是一個 **Codex 模式專用** 的 VS Code Extension，讓公司內部 .NET 開發人員一鍵完成 Codex CLI 輔助測試開發環境設定。
本專案由多模式版本 `dotnet-testing-vscode-extensions` 抽離而來，**只保留 Codex 模式**，並將 skills / orchestration-codex 的來源改為**可設定**（預設 GitHub，可指向公司內部 Gitea）。

發佈方式為內部 Gitea Release（.vsix），不走 VS Code Marketplace。

## 與原始多模式版本的關係

- 原始碼完全獨立，與 `dotnet-testing-vscode-extensions` 切開、各自演進。
- 移除了所有 Copilot / Claude 模式與 RAG / MCP 相關程式碼。
- 保留共用底層：`release-downloader`、`version-checker`、`shell`、`logger`、`file-deploy`、`toml-merge`、`path-resolver`（精簡為只留 `getWorkspacePath()`）。

## 核心設計決策

### 定義檔部署策略：Bundle 初始化 + Online 背景更新

init 時**直接部署 Extension 內建的 bundled 版本**，不在初始化路徑上進行網路下載，確保初始化快速且離線可用：

- 初始化（`dta.codex.init`）：由 `CodexInstaller.deploySkills()` / `deployAgents()` 從 `bundled/` 複製 Skills 與 Orchestration，不觸發任何 Release 下載。
- 背景更新：初始化完成後於背景檢查來源 repo（`dta.codex.skillsRepo` / `dta.codex.orchRepo`）的最新 tag（`dta.codex.skillsVersion`，預設 `"latest"`）；有新版時提示使用者，經確認後由 `deploySkillsFromRelease()` 從 Release 下載並覆蓋 `.codex/`。

`bundled/` 目錄隨 Extension 一起分發，作為初始化來源與離線基準。開發者執行 `npm run sync-bundled` / `npm run sync-bundled-codex` 更新 bundled 版本，打包時一併包入 `.vsix`。

> 注意：online 路徑（`deploySkillsFromRelease` / `deployOrchFromRelease`）只用於「初始化後的背景更新 / 立即更新」，不是 init 的主路徑，也不是 online-first。

### 來源可設定（GitHub / 內部 Gitea 雙相容）

skills 與 orchestration-codex 的來源 repo URL 可由設定覆寫，以指向公司內部 Gitea：

- `dta.codex.skillsRepo`、`dta.codex.orchRepo`：留空則使用 `constants.ts` 的 `DEFAULT_*` 預設值（GitHub）。
- 下載機制為 `git clone`（對 Gitea URL 通用）＋「解析 latest tag 的 Releases API」。後者由 `src/utils/release-api.ts` 的 `buildReleaseApiUrl()` 依 host 自動選用：
  - GitHub → `https://api.github.com/repos/{owner}/{repo}/releases/latest`
  - Gitea → `{scheme}://{host}/api/v1/repos/{owner}/{repo}/releases/latest`
- Gitea 與 GitHub 的 Releases API JSON 結構相容（`tag_name` / `html_url` / `body` / `published_at`），parsing 共用。
- 假設內部 Gitea repo **匿名可讀**，因此不帶認證 header。若日後需私有存取，於 `release-downloader` 的 clone URL 與 API header 注入 token。

> `buildReleaseApiUrl` / `extractOwnerRepo` 為 `ReleaseDownloader` 與 `CodexWebviewProvider` **共用**，避免只改一半。

### UI 元件策略

Sidebar 使用兩個 WebviewView：`dta.about`（版本資訊）與 `dta.codex.webview`（Codex 面板：總覽 / Skills / Orchestration 三分頁）。無 TreeView、無 MCP、無 RAG。

### 無 MCP / 無 RAG

Codex 模式不使用 `vscode.lm.registerMcpServerDefinitionProvider()`，也不建立 LanceDB 索引。init 僅部署檔案到 `.codex/`。

### Windows 優先

- `child_process` 執行時 shell 使用 `cmd.exe`，不用 PowerShell。
- 使用 Node.js `path` module 處理路徑，不手動拼接。

## 技術棧

- **語言**：TypeScript 5.x（strict: true）
- **打包**：esbuild（輸出 `dist/extension.js`，格式 cjs，external: vscode）
- **最低 VS Code**：1.85.0
- **Node.js**：>= 18.0.0
- **測試**：Mocha（純 Node 單元測試，不需 VS Code 實例）+ @vscode/test-electron（E2E）

> 單元測試設計原則：test 只 import **純函式** 或不在載入時 require('vscode') 的模組。`CodexInstaller` 對 `vscode` 使用 `import type` + getter 內 lazy `require('vscode')`，以維持純 Node 可測。

## 開發指令

```bash
npm run compile              # 型別檢查 + esbuild 打包
npm run check-types          # 只跑 tsc --noEmit
npm run watch                # 同時監聽 esbuild + tsc
npm run lint                 # ESLint 檢查
npm run test                 # 單元測試（mocha，不需要 VS Code 實例）
npm run test:vscode          # E2E 測試（需要 VS Code 實例）
npm run package              # vsce package
npm run sync-bundled         # 同步 bundled/shared/skills/ + bundled/shared/version.json
npm run sync-bundled-codex   # 同步 bundled/codex/（agents/skills/scripts/config.toml）
```

同步時可用 `--skills-repo` / `--orch-repo` 指向內部 Gitea，或 `--skills-path` / `--orch-path` 走本地路徑。

## 目錄結構

```
dotnet-testing-codex-extension/
├── package.json
├── esbuild.mjs
├── scripts/
│   ├── sync-bundled.mjs         # 同步 shared skills → bundled/shared/
│   └── sync-bundled-codex.mjs   # 同步 Codex orchestration → bundled/codex/
├── resources/
│   ├── icon.png
│   ├── beaker.svg               # Activity Bar 圖示
│   └── walkthrough-*.svg
├── src/
│   ├── extension.ts             # 進入點（只註冊 Codex + 版本資訊）
│   ├── constants.ts
│   ├── types.ts
│   ├── commands/
│   │   ├── codex-init.ts        # dta.codex.init
│   │   └── codex-doctor.ts      # dta.codex.doctor
│   ├── services/
│   │   ├── codex-installer.ts
│   │   ├── release-downloader.ts
│   │   ├── version-checker.ts
│   │   └── version-check-url.ts
│   ├── views/
│   │   ├── codex-webview-provider.ts / codex-webview-html.ts
│   │   └── about-webview-provider.ts / about-webview-html.ts
│   └── utils/
│       ├── release-api.ts       # buildReleaseApiUrl / extractOwnerRepo（GitHub/Gitea）
│       ├── path-resolver.ts     # 只留 getWorkspacePath()
│       ├── shell.ts / logger.ts / file-deploy.ts / toml-merge.ts / semver.ts
├── bundled/
│   ├── shared/
│   │   ├── skills/              # 共用 Skills（sync-bundled 管理）
│   │   └── version.json         # shared skills 版本資訊
│   └── codex/
│       ├── skills/ agents/ scripts/ config.toml
│       └── version.json
└── test/suite/
```

## 指令規格

| Command ID | 顯示名稱 |
| --- | --- |
| `dta.codex.init` | 初始化 Codex Agent 環境 |
| `dta.codex.doctor` | Codex 環境診斷 |
| `dta.openExternalUrl` | 在瀏覽器開啟 |

## Context Keys

| Key | 型別 | 說明 |
| --- | --- | --- |
| `dta.codex.initialized` | boolean | workspace Codex 模式是否已初始化 |
| `dta.codex.isRunning` | boolean | 是否正在執行 codex.init/codex.doctor |
| `dta.hasUpdate` | boolean | Extension 是否有新版本 |

## 檔案部署路徑

```
<workspace>/
├── .codex/
│   ├── skills/          ← 共用 skills + Codex orchestrator skills（兩段疊加）
│   ├── agents/          ← 16 個 subagent 定義（.toml）
│   ├── scripts/         ← run-state.mjs + estimate-token-usage.mjs
│   └── config.toml      ← 平台設定（補差異合併，不覆寫使用者既有值）
└── .dotnet-testing-agent/
    └── manifest-codex.json
```

> skills 為兩段疊加：先鋪 `bundled/shared/skills/`，再疊 `bundled/codex/skills/`（orchestrator skills）。

## Codex init / doctor

- **init（4 步驟）**：前置檢查 → 部署 Skills（`.codex/skills/`）→ 部署 Agents（`.codex/agents/`）+ Config（`.codex/config.toml`，補差異合併）+ Scripts（`.codex/scripts/`）→ 寫 `manifest-codex.json`。完成後自動 silent doctor + 背景檢查新版。
- **doctor（6 項）**：Node.js、`.codex/skills`、`.codex/agents`（`.toml`）、`.codex/config.toml`（含 `[features]`/`[agents]`）、`.codex/scripts`（`run-state.mjs` + `estimate-token-usage.mjs`）、`codex --version`。前 5 項（除 Node）已初始化時可一鍵自動修復。

## Extension Settings

| Key | 類型 | 預設值 | 說明 |
| --- | --- | --- | --- |
| `dta.giteaUrl` | string | `""` | Gitea URL（Extension 版本檢查用） |
| `dta.giteaRepo` | string | `""` | repo 路徑 owner/repo（Extension 版本檢查用） |
| `dta.checkUpdatesOnStartup` | boolean | `true` | 啟動檢查更新 |
| `dta.codex.skillsRepo` | string | GitHub 預設 | Skills 來源 repo URL（可指向內部 Gitea） |
| `dta.codex.orchRepo` | string | GitHub 預設 | Codex Orchestration 來源 repo URL（可指向內部 Gitea） |
| `dta.codex.skillsVersion` | string | `"latest"` | Skills 部署版本 tag |

## 編碼規範

- 使用 `async/await`；公開函式加 JSDoc；錯誤訊息用繁體中文、日誌用英文。
- 型別集中在 `types.ts`；Service 使用 constructor injection。
- 檔名 kebab-case、類別 PascalCase、常數 UPPER_SNAKE_CASE。
- Command / Context / Setting Key 一律 `dta.` 前綴。
- Commit 使用 Conventional Commits；`bundled/` commit 進 repo。

## 注意事項

### 必須遵守

- `child_process` 在 Windows 上使用 `cmd.exe`。
- 錯誤處理不可吞掉 error，必須 log + 通知使用者。
- `bundled/` 視為 read-only，透過 sync 腳本更新。
- 改動下載來源時，`release-downloader` 與 `codex-webview-provider` 兩處務必共用 `release-api.ts`。

### 不要做

- 不要重新引入 Copilot / Claude / MCP / RAG 相關程式碼。
- 不要在 activate 時執行耗時操作（版本檢查已延遲）。
- 不要硬編碼來源 repo URL，改用設定 + `DEFAULT_*` fallback。
- 不要在 .vsix 中包含 src/、test/、node_modules/。

## 相關專案

| Repo | 說明 |
|---|---|
| dotnet-testing-agent-skills | 共用 .NET 測試 Agent Skill 定義檔 |
| dotnet-testing-agent-orchestration-codex | Codex：agents（.toml）/skills/scripts/config.toml（`.codex/`） |

## 套件約束

- 測試框架使用 **AwesomeAssertions**（不是 FluentAssertions）。
- Mock 框架使用 **NSubstitute**（不是 Moq）。
- 這兩個約束存在於 Skills 定義檔中，Extension 本身不直接使用。
