import * as vscode from 'vscode';
import { Logger } from './utils/logger';
import { ShellExecutor } from './utils/shell';
import { PathResolver } from './utils/path-resolver';
import { VersionChecker } from './services/version-checker';
import { ReleaseDownloader } from './services/release-downloader';
import { CodexWebviewProvider } from './views/codex-webview-provider';
import { AboutWebviewProvider } from './views/about-webview-provider';
import { CodexInstaller } from './services/codex-installer';
import { executeCodexInit } from './commands/codex-init';
import { executeCodexDoctor } from './commands/codex-doctor';
import {
  CTX_HAS_UPDATE,
  VERSION_CHECK_DELAY_MS,
  CMD_CODEX_INIT,
  CMD_CODEX_DOCTOR,
  CTX_CODEX_INITIALIZED,
  CTX_CODEX_IS_RUNNING,
  STATE_LAST_SEEN_VERSION,
} from './constants';

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  // Initialize core utilities
  const logger = new Logger();
  const shell = new ShellExecutor(logger);
  const pathResolver = new PathResolver();

  // Initialize services
  const releaseDownloader = new ReleaseDownloader(shell, logger);
  const versionChecker = new VersionChecker(context, logger);
  const codexInstaller = new CodexInstaller(context, logger, releaseDownloader);

  // Initialize Status Bar Item
  const statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
  context.subscriptions.push(statusBarItem);

  // Register sidebar Webview providers
  const codexWebviewProvider = new CodexWebviewProvider(codexInstaller, pathResolver);
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(CodexWebviewProvider.viewType, codexWebviewProvider)
  );

  // 偵測「剛更新」：比對 globalState 存的上次版本 vs 目前版本。
  // 新增 Sidebar 面板的版本在 VSIX 就地覆蓋後，只 Reload Window 面板不會出現，
  // 需完整重啟 VS Code；有落差時在版本資訊面板顯示提示橫幅。
  const currentExtVersion = context.extension.packageJSON.version as string;
  const lastSeenVersion = context.globalState.get<string>(STATE_LAST_SEEN_VERSION);
  const justUpdated = !!lastSeenVersion && lastSeenVersion !== currentExtVersion;
  void context.globalState.update(STATE_LAST_SEEN_VERSION, currentExtVersion);

  const aboutProvider = new AboutWebviewProvider(
    context, versionChecker, codexInstaller, pathResolver,
    justUpdated, lastSeenVersion
  );
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(AboutWebviewProvider.viewType, aboutProvider)
  );

  // Set initial context keys and status bar state
  await vscode.commands.executeCommand('setContext', CTX_HAS_UPDATE, false);
  await vscode.commands.executeCommand('setContext', CTX_CODEX_IS_RUNNING, false);

  let workspacePath: string | undefined;
  try {
    workspacePath = pathResolver.getWorkspacePath();
    const codexInitialized = codexInstaller.isInitialized(workspacePath);
    await vscode.commands.executeCommand('setContext', CTX_CODEX_INITIALIZED, codexInitialized);
    updateStatusBar(statusBarItem, codexInitialized);
  } catch {
    await vscode.commands.executeCommand('setContext', CTX_CODEX_INITIALIZED, false);
    updateStatusBar(statusBarItem, false);
  }

  statusBarItem.show();

  // Register commands
  context.subscriptions.push(
    vscode.commands.registerCommand('dta.openExternalUrl', (url: string) => {
      vscode.env.openExternal(vscode.Uri.parse(url));
    }),

    vscode.commands.registerCommand(CMD_CODEX_INIT, async () => {
      await executeCodexInit(context, codexInstaller, pathResolver, logger, codexWebviewProvider);
      aboutProvider.refresh();
    }),

    vscode.commands.registerCommand(CMD_CODEX_DOCTOR, (silent?: boolean) =>
      executeCodexDoctor(shell, pathResolver, codexInstaller, logger, codexWebviewProvider, silent)
    )
  );

  // Delayed version check
  const config = vscode.workspace.getConfiguration();
  if (config.get<boolean>('dta.checkUpdatesOnStartup')) {
    setTimeout(async () => {
      try {
        const updateInfo = await versionChecker.check();
        if (updateInfo) {
          await versionChecker.notifyIfNeeded(updateInfo);
        }
      } catch (err) {
        logger.debug(`Version check error: ${err}`);
      }
    }, VERSION_CHECK_DELAY_MS);
  }

  logger.info(`Extension activated (workspace: ${workspacePath ?? 'none'})`);
}

export function deactivate(): void {
  // intentionally empty — VS Code disposes subscriptions automatically
}

function updateStatusBar(item: vscode.StatusBarItem, initialized: boolean): void {
  if (initialized) {
    item.text = '$(beaker) Codex Agent ✓';
    item.tooltip = 'Codex Agent 環境已初始化，點擊執行環境診斷';
    item.backgroundColor = undefined;
    item.command = CMD_CODEX_DOCTOR;
  } else {
    item.text = '$(beaker) Codex Agent ⚠';
    item.tooltip = 'Codex Agent 環境尚未初始化，點擊執行初始化';
    item.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
    item.command = CMD_CODEX_INIT;
  }
}
