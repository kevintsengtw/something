export interface DiagnosticResult {
  passed: boolean;
  detail: string;
  suggestion?: string;
}

export interface DiagnosticCheck {
  name: string;
  check: () => Promise<DiagnosticResult>;
  autoFix?: () => Promise<void>;
}

export interface UpdateInfo {
  currentVersion: string;
  latestVersion: string;
  releaseUrl: string;
  downloadUrl: string;
}

export interface ShellResult {
  stdout: string;
  stderr: string;
  exitCode: number;
}

export interface InitStepResult {
  name: string;
  status: 'success' | 'failed' | 'skipped';
  error?: string;
}

export interface CodexManifest {
  extensionVersion: string;
  installedAt: string;
  updatedAt: string;
  skills: {
    version: string;       // dotnet-testing-agent-skills version (shared skills)
    orchVersion?: string;  // dotnet-testing-agent-orchestration-codex version (Codex-specific skills)
    count: number;
    path: string;
  };
  agents: {
    version: string;       // dotnet-testing-agent-orchestration-codex version
    count: number;
    path: string;
  };
  config: {
    installed: boolean;    // .codex/config.toml 是否部署成功
    path: string;          // '.codex/config.toml'
  };
  scripts: {
    installed: boolean;    // token 估算引擎（.codex/scripts/）是否部署成功
    path: string;          // '.codex/scripts'
  };
}

/** 由 VersionChecker.fetchLatestRelease() 回傳的最新 release 資訊（不論是否較新）。 */
export interface LatestRelease {
  version: string;     // tag_name 去掉前綴 v
  notes: string;       // release body（可能為空字串）
  publishedAt: string; // ISO 字串，可能為空
  url: string;         // release 的 html_url
}

/** Codex 模式已初始化但部署版本與目前安裝版本不一致時的落差資訊。 */
export interface VersionDrift {
  mode: 'codex';
  deployedVersion: string; // manifest.extensionVersion
}
