/**
 * Release API 位址解析工具 —— 同時支援 GitHub 與 Gitea（或任意自架 Git host）。
 *
 * Gitea 與 GitHub 的 Releases API 回傳 JSON 結構相容（tag_name / html_url / body /
 * published_at / assets），差別只在 host 與路徑（Gitea 多了 /api/v1）。這裡集中處理
 * 這個差異，讓 ReleaseDownloader 與 Webview 共用同一份邏輯，避免只改一半。
 */

/**
 * 從 repo URL 解析 "owner/repo"，支援 GitHub 與 Gitea 等任意 host。
 * - "https://github.com/owner/repo"      → "owner/repo"
 * - "https://github.com/owner/repo.git"  → "owner/repo"
 * - "https://gitea.company.com/owner/repo" → "owner/repo"
 */
export function extractOwnerRepo(repoUrl: string): string {
  const m = repoUrl.match(/^https?:\/\/[^/]+\/([^/]+\/[^/.]+)/);
  if (!m) throw new Error(`無法從 URL 解析 owner/repo：${repoUrl}`);
  return m[1];
}

/**
 * 依 repo host 組出 Releases API 的 "latest" endpoint。
 * - GitHub → https://api.github.com/repos/{owner}/{repo}/releases/latest
 * - 其他（Gitea）→ {scheme}://{host}/api/v1/repos/{owner}/{repo}/releases/latest
 */
export function buildReleaseApiUrl(repoUrl: string): string {
  const ownerRepo = extractOwnerRepo(repoUrl);
  const hostMatch = repoUrl.match(/^(https?):\/\/([^/]+)\//);
  if (!hostMatch) throw new Error(`無法從 URL 解析 host：${repoUrl}`);
  const [, scheme, host] = hostMatch;
  if (host === 'github.com' || host === 'www.github.com') {
    return `https://api.github.com/repos/${ownerRepo}/releases/latest`;
  }
  return `${scheme}://${host}/api/v1/repos/${ownerRepo}/releases/latest`;
}
