import * as vscode from 'vscode';
import { OUTPUT_CHANNEL_NAME } from '../constants';

export class Logger {
  private readonly channel: vscode.OutputChannel;

  constructor(channelName: string = OUTPUT_CHANNEL_NAME) {
    this.channel = vscode.window.createOutputChannel(channelName);
  }

  info(message: string): void {
    this.log('INFO', message);
  }

  warn(message: string): void {
    this.log('WARN', message);
  }

  error(message: string, error?: Error): void {
    this.log('ERROR', message);
    if (error) {
      this.channel.appendLine(`  ${error.stack ?? error.message}`);
    }
  }

  debug(message: string): void {
    this.log('DEBUG', message);
  }

  show(): void {
    this.channel.show(true);
  }

  appendLine(text: string): void {
    this.channel.appendLine(text);
  }

  dispose(): void {
    this.channel.dispose();
  }

  private log(level: string, message: string): void {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
    this.channel.appendLine(`[${timestamp}] [${level}] ${message}`);
  }
}
