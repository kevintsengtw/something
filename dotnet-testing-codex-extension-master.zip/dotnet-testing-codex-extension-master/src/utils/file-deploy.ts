import * as fs from 'fs';
import * as path from 'path';

export function copyDirRecursive(src: string, dest: string, exclude?: Set<string>): void {
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    if (entry.name === '.gitkeep') continue;
    if (exclude?.has(entry.name)) continue;
    const srcPath  = path.join(src,  entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      fs.mkdirSync(destPath, { recursive: true });
      copyDirRecursive(srcPath, destPath, exclude);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

/** Counts immediate subdirectories only (each = one skill). */
export function countDirs(dirPath: string): number {
  if (!fs.existsSync(dirPath)) return 0;
  return fs.readdirSync(dirPath, { withFileTypes: true })
    .filter(e => e.isDirectory())
    .length;
}

export function countFiles(dirPath: string, exclude?: Set<string>): number {
  if (!fs.existsSync(dirPath)) return 0;
  let count = 0;
  for (const entry of fs.readdirSync(dirPath, { withFileTypes: true })) {
    if (entry.name === '.gitkeep') continue;
    if (exclude?.has(entry.name)) continue;
    if (entry.isDirectory()) {
      count += countFiles(path.join(dirPath, entry.name), exclude);
    } else {
      count++;
    }
  }
  return count;
}
