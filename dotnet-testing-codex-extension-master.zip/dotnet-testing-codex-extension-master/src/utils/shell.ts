import * as cp from 'child_process';
import * as os from 'os';
import * as vscode from 'vscode';
import { Logger } from './logger';
import { ShellResult } from '../types';

export class ShellExecutor {
  constructor(private readonly logger: Logger) {}

  async exec(
    command: string,
    options: { cwd?: string; timeout?: number; env?: Record<string, string> } = {}
  ): Promise<ShellResult> {
    const shell = this.getShell();
    const timeout = options.timeout ?? 60_000;

    this.logger.debug(`exec: ${command} (shell: ${shell})`);

    return new Promise((resolve) => {
      const proc = cp.exec(command, {
        shell,
        cwd: options.cwd,
        timeout,
        env: this.buildEnv(options.env),
      }, (error, stdout, stderr) => {
        const exitCode = error?.code ?? 0;
        resolve({
          stdout: stdout.trim(),
          stderr: stderr.trim(),
          exitCode: typeof exitCode === 'number' ? exitCode : 1,
        });
      });

      proc.on('error', (err) => {
        resolve({ stdout: '', stderr: err.message, exitCode: 1 });
      });
    });
  }

  getShell(): string {
    const config = vscode.workspace.getConfiguration();
    const custom = config.get<string>('dta.shellExecutable');
    if (custom) {
      return custom;
    }
    return os.platform() === 'win32' ? 'cmd.exe' : '/bin/sh';
  }

  private buildEnv(extra?: Record<string, string>): NodeJS.ProcessEnv {
    const env = { ...process.env };
    const config = vscode.workspace.getConfiguration();
    const npmRegistry = config.get<string>('dta.npmRegistry');
    if (npmRegistry) {
      env['npm_config_registry'] = npmRegistry;
    }
    if (extra) {
      Object.assign(env, extra);
    }
    return env;
  }
}
