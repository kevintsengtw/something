/**
 * 輕量、零相依的 TOML「補差異」合併工具，專供 Codex 模式的 `.codex/config.toml` 使用。
 *
 * Codex 的 config.toml 結構單純：只有 top-level scalar key 與單層 `[table]` 區段
 * （目前為 `[features]`、`[agents]`）。本工具刻意只支援這種形狀，不引入完整的
 * TOML 解析套件，以符合專案 zero-dep / esbuild 打包原則。
 *
 * 合併語意（「看差異、補差異」）：
 *   - 完全保留使用者既有檔案的內容（含註解與既有值）。
 *   - 只把 bundled 版本「有、而使用者缺少」的 key 補進去：
 *       · 缺少的 top-level key → 插入在第一個 table 標頭之前（或檔尾）。
 *       · 既有 table 缺少的 key → 插入在該 table 標頭之後。
 *       · 整個 table 缺少 → 於檔尾附加新的 table 區塊。
 *   - 永不覆寫使用者既有的值。
 *
 * 若日後 config 出現巢狀 table（如 `[a.b]`）或陣列表，需擴充本解析邏輯。
 */

const HEADER_RE = /^\s*\[([^\]]+)\]\s*(?:#.*)?$/;
const KEYVAL_RE = /^\s*([A-Za-z0-9_.-]+)\s*=/;

const TOP = ''; // top-level（無 table）區段以空字串表示

interface KeyLine {
  key: string;
  raw: string;
}

interface ParsedToml {
  /** 出現過的 `${section}\n${key}`（以換行為分隔，不會出現在單行 TOML 內），用於判斷某 key 是否已存在 */
  presentKeys: Set<string>;
  /** 各 section 的標頭所在行索引（top-level 不在此 map 內） */
  tableHeaderIndex: Map<string, number>;
  /** 第一個 table 標頭的行索引；無 table 時為 null */
  firstHeaderIndex: number | null;
  lines: string[];
}

function presenceKey(section: string, key: string): string {
  return `${section}\n${key}`;
}

/** 解析既有檔案，建立補差異所需的索引資訊。 */
function parseExisting(text: string): ParsedToml {
  const lines = text.split('\n');
  const presentKeys = new Set<string>();
  const tableHeaderIndex = new Map<string, number>();
  let firstHeaderIndex: number | null = null;
  let current = TOP;

  lines.forEach((line, idx) => {
    const header = HEADER_RE.exec(line);
    if (header) {
      current = header[1].trim();
      if (firstHeaderIndex === null) firstHeaderIndex = idx;
      if (!tableHeaderIndex.has(current)) tableHeaderIndex.set(current, idx);
      return;
    }
    const kv = KEYVAL_RE.exec(line);
    if (kv) {
      presentKeys.add(presenceKey(current, kv[1]));
    }
  });

  return { presentKeys, tableHeaderIndex, firstHeaderIndex, lines };
}

/** 解析 bundled 檔案，取出每個 key 的原始行文字，保留 section 順序。 */
function parseBundled(text: string): { top: KeyLine[]; tableOrder: string[]; tables: Map<string, KeyLine[]> } {
  const top: KeyLine[] = [];
  const tableOrder: string[] = [];
  const tables = new Map<string, KeyLine[]>();
  let current = TOP;

  for (const rawLine of text.split('\n')) {
    const line = rawLine.replace(/\s+$/, '');
    const header = HEADER_RE.exec(line);
    if (header) {
      current = header[1].trim();
      if (!tables.has(current)) {
        tables.set(current, []);
        tableOrder.push(current);
      }
      continue;
    }
    const kv = KEYVAL_RE.exec(line);
    if (!kv) continue;
    const entry: KeyLine = { key: kv[1], raw: line };
    if (current === TOP) top.push(entry);
    else tables.get(current)!.push(entry);
  }

  return { top, tableOrder, tables };
}

/**
 * 將 bundled 版本中使用者缺少的 key 補進 existing 文字後回傳。
 * @param bundledText bundled 內附的官方 config.toml 內容
 * @param existingText workspace 既有的 config.toml 內容；null 代表尚未存在
 * @returns 合併後的 config.toml 文字
 */
export function mergeCodexConfigToml(bundledText: string, existingText: string | null): string {
  // 不存在 → 整檔複製（保留官方註解）
  if (existingText === null || existingText.trim() === '') return bundledText;

  const existing = parseExisting(existingText);
  const bundled = parseBundled(bundledText);

  // 收集插入指令：{ atIndex, lines }，最後由下往上套用避免索引位移
  const inserts: Array<{ at: number; lines: string[] }> = [];

  // 1) 缺少的 top-level key
  const missingTop = bundled.top.filter((e) => !existing.presentKeys.has(presenceKey(TOP, e.key)));
  if (missingTop.length > 0) {
    const at = existing.firstHeaderIndex ?? existing.lines.length;
    inserts.push({ at, lines: missingTop.map((e) => e.raw) });
  }

  // 2) 既有 table 補缺 key / 整個 table 缺少則附加
  const appendBlocks: string[] = [];
  for (const section of bundled.tableOrder) {
    const bundledKeys = bundled.tables.get(section)!;
    const headerIdx = existing.tableHeaderIndex.get(section);
    if (headerIdx === undefined) {
      // 整個 table 缺少 → 檔尾附加
      appendBlocks.push('', `[${section}]`, ...bundledKeys.map((e) => e.raw));
      continue;
    }
    const missingKeys = bundledKeys.filter((e) => !existing.presentKeys.has(presenceKey(section, e.key)));
    if (missingKeys.length > 0) {
      inserts.push({ at: headerIdx + 1, lines: missingKeys.map((e) => e.raw) });
    }
  }

  const out = [...existing.lines];
  inserts
    .sort((a, b) => b.at - a.at)
    .forEach(({ at, lines }) => out.splice(at, 0, ...lines));

  let result = out.join('\n');
  if (appendBlocks.length > 0) {
    if (!result.endsWith('\n')) result += '\n';
    result += appendBlocks.join('\n') + '\n';
  }
  return result;
}

/** 回傳檔案中出現的 table section 名稱集合（供 doctor 驗證必要區段）。 */
export function parseTomlSections(text: string): Set<string> {
  const sections = new Set<string>();
  for (const line of text.split('\n')) {
    const header = HEADER_RE.exec(line);
    if (header) sections.add(header[1].trim());
  }
  return sections;
}
