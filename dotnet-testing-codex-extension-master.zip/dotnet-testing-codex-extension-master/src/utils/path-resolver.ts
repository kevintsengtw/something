import * as vscode from 'vscode';

export class PathResolver {
  /** Returns the absolute workspace root, or throws if no workspace is open. */
  getWorkspacePath(): string {
    const folders = vscode.workspace.workspaceFolders;
    if (!folders || folders.length === 0) {
      throw new Error('未開啟工作區資料夾，請先開啟一個專案資料夾再執行此指令。');
    }
    return folders[0].uri.fsPath;
  }
}
