/**
 * 純 semver 比較工具（無 vscode 相依，可在單元測試直接 import）。
 */

/** latest 是否比 current 新（只比 major.minor.patch）。 */
export function isNewerVersion(latest: string, current: string): boolean {
  const parse = (v: string) => v.split('.').map(Number);
  const [lMaj, lMin, lPatch] = parse(latest);
  const [cMaj, cMin, cPatch] = parse(current);
  if (lMaj !== cMaj) { return lMaj > cMaj; }
  if (lMin !== cMin) { return lMin > cMin; }
  return lPatch > cPatch;
}
