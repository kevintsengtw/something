import * as path from 'path';

export const EXTENSION_ID = 'kevintsengtw.dotnet-testing-codex-agent';
export const EXTENSION_NAME = 'dotnet-testing Codex Agent 工具包';
export const OUTPUT_CHANNEL_NAME = 'dotnet-testing Codex Agent 工具包';

// ── 共用（shared）───────────────────────────────────────────────────────────

// Workspace 層級共用路徑
export const WS_MANIFEST_DIR = '.dotnet-testing-agent';

// Node.js 最低版本
export const MIN_NODE_VERSION = '18.0.0';

// bundled 路徑（runtime 相對於 extension 解析）
// shared skills：所有模式共用，由 sync-bundled.mjs 產生
export const BUNDLED_SHARED_SKILLS_DIR  = path.join('shared', 'skills');
// shared skills 版本資訊（由 sync-bundled.mjs 產生）
export const BUNDLED_SHARED_VERSION_FILE = path.join('shared', 'version.json');

// ── 線上部署來源（預設值）────────────────────────────────────────────────────
// 這些是 fallback 預設值；實際來源可由 dta.codex.skillsRepo / dta.codex.orchRepo 設定覆寫，
// 以便指向公司內部 Gitea repo。
export const DEFAULT_SKILLS_REPO     = 'https://github.com/kevintsengtw/dotnet-testing-agent-skills';
export const DEFAULT_CODEX_ORCH_REPO = 'https://github.com/kevintsengtw/dotnet-testing-agent-orchestration-codex';

// 本 Extension 自身的發佈 repo（owner/repo 形式），供版本更新檢查在未設定 Gitea 時預設使用
export const EXTENSION_GITHUB_REPO = 'kevintsengtw/dotnet-testing-codex-extension';

// ── 版本檢查 ─────────────────────────────────────────────────────────────────
export const VERSION_CHECK_DELAY_MS   = 10_000;
export const VERSION_CHECK_TIMEOUT_MS = 5_000;

// Context keys（版本更新）
export const CTX_HAS_UPDATE = 'dta.hasUpdate';

// Global state keys
export const STATE_IGNORED_VERSION = 'dta.ignoredVersion';
// 記錄上次啟動時的 extension 版本，用於偵測「剛更新」以在版本資訊面板提示完整重啟
export const STATE_LAST_SEEN_VERSION = 'dta.lastSeenVersion';

// ── Codex mode ──────────────────────────────────────────────────────────────

// Context keys
export const CTX_CODEX_INITIALIZED = 'dta.codex.initialized';
export const CTX_CODEX_IS_RUNNING  = 'dta.codex.isRunning';

// Command IDs
export const CMD_CODEX_INIT   = 'dta.codex.init';
export const CMD_CODEX_DOCTOR = 'dta.codex.doctor';

// View ID
export const VIEW_CODEX_STATUS = 'dta.codex.webview';

// Workspace paths (relative)
export const WS_CODEX_SKILLS_PATH  = path.join('.codex', 'skills');
export const WS_CODEX_AGENTS_PATH  = path.join('.codex', 'agents');
export const WS_CODEX_SCRIPTS_PATH = path.join('.codex', 'scripts');
export const WS_CODEX_CONFIG_PATH  = path.join('.codex', 'config.toml');
export const CODEX_MANIFEST_PATH   = path.join('.dotnet-testing-agent', 'manifest-codex.json');

// bundled subdirectory name under bundled/
export const BUNDLED_CODEX_DIR = 'codex';

// Codex scripts (relative to .codex/scripts/)
export const CODEX_TOKEN_SCRIPT     = 'estimate-token-usage.mjs';
// run-state.mjs：確定性 run-state.json 寫入器（orchestration-codex >= v1.0.2；
// 修正 Codex VS Code 擴充 runtime 無法寫出 run-state 導致 timing/token 全空的問題）
export const CODEX_RUN_STATE_SCRIPT = 'run-state.mjs';
