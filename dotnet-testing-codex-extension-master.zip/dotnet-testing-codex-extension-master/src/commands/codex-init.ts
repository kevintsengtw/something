import * as vscode from 'vscode';
import { CodexInstaller } from '../services/codex-installer';
import { PathResolver } from '../utils/path-resolver';
import { Logger } from '../utils/logger';
import { CodexWebviewProvider } from '../views/codex-webview-provider';
import { CodexManifest, InitStepResult } from '../types';
import {
  CTX_CODEX_INITIALIZED,
  CTX_CODEX_IS_RUNNING,
  CMD_CODEX_INIT,
  WS_CODEX_SKILLS_PATH,
  WS_CODEX_AGENTS_PATH,
  WS_CODEX_CONFIG_PATH,
  WS_CODEX_SCRIPTS_PATH,
} from '../constants';

let isRunning = false;

export async function executeCodexInit(
  context: vscode.ExtensionContext,
  installer: CodexInstaller,
  pathResolver: PathResolver,
  logger: Logger,
  webviewProvider?: CodexWebviewProvider
): Promise<void> {
  if (isRunning) {
    vscode.window.showWarningMessage('操作進行中，請稍候再試。');
    return;
  }

  let workspacePath: string;
  try {
    workspacePath = pathResolver.getWorkspacePath();
  } catch (err) {
    vscode.window.showErrorMessage(err instanceof Error ? err.message : String(err));
    return;
  }

  isRunning = true;
  await vscode.commands.executeCommand('setContext', CTX_CODEX_IS_RUNNING, true);

  const steps: InitStepResult[] = [];

  await vscode.window.withProgress(
    {
      location: vscode.ProgressLocation.Notification,
      title: '初始化 .NET Testing Agent (Codex)',
      cancellable: false,
    },
    async (progress) => {
      // Step 1: Pre-check
      progress.report({ message: '[1/4] 前置環境檢查...' });
      try {
        const nodeVer = process.version.replace(/^v/, '').split('.').map(Number);
        if (nodeVer[0] < 18) {
          throw new Error(`Node.js 版本過舊（${process.version}），需要 >= 18.0.0`);
        }
        if (!vscode.workspace.workspaceFolders?.length) {
          throw new Error('請先開啟一個 Workspace 資料夾再執行初始化。');
        }
        steps.push({ name: '前置環境檢查', status: 'success' });
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        steps.push({ name: '前置環境檢查', status: 'failed', error: message });
        vscode.window.showErrorMessage(`初始化失敗：${message}`);
        return;
      }

      // Step 2: Deploy Skills
      progress.report({ message: '[2/4] 部署 Skills → .codex/skills/...' });
      let skillsCount = 0;
      let skillsVersion = '0.0.0';
      let skillsOrchVersion = '0.0.0';
      try {
        const result = await installer.deploySkills(workspacePath);
        skillsCount       = result.count;
        skillsVersion     = result.version;
        skillsOrchVersion = result.orchVersion;
        steps.push({ name: 'Skills 部署', status: 'success' });
        logger.info(`Codex skills deployed: ${skillsCount} dirs`);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        steps.push({ name: 'Skills 部署', status: 'failed', error: message });
        logger.error(`Codex skills deploy failed: ${message}`);
      }

      // Step 3: Deploy Agents + Config + Scripts
      progress.report({ message: '[3/4] 部署 Agents + Config → .codex/...' });
      let agentsCount = 0;
      let agentsVersion = '0.0.0';
      try {
        const result = await installer.deployAgents(workspacePath);
        agentsCount   = result.count;
        agentsVersion = result.version;
        steps.push({ name: 'Agents 部署', status: 'success' });
        logger.info(`Codex agents deployed: ${agentsCount} files`);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        steps.push({ name: 'Agents 部署', status: 'failed', error: message });
        logger.error(`Codex agents deploy failed: ${message}`);
      }

      let configInstalled = false;
      try {
        const result = await installer.deployConfig(workspacePath);
        configInstalled = result.installed;
        steps.push({ name: 'Config 部署', status: result.installed ? 'success' : 'failed' });
        logger.info(`Codex config deployed: installed=${result.installed}`);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        steps.push({ name: 'Config 部署', status: 'failed', error: message });
        logger.error(`Codex config deploy failed: ${message}`);
      }

      let scriptsInstalled = false;
      try {
        const result = await installer.deployScripts(workspacePath);
        scriptsInstalled = result.installed;
        steps.push({ name: 'Scripts 部署', status: result.installed ? 'success' : 'failed' });
        logger.info(`Codex scripts deployed: installed=${result.installed}`);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        steps.push({ name: 'Scripts 部署', status: 'failed', error: message });
        logger.error(`Codex scripts deploy failed: ${message}`);
      }

      // Step 4: Write manifest + notify
      progress.report({ message: '[4/4] 完成初始化...' });
      const now = new Date().toISOString();
      const manifest: CodexManifest = {
        extensionVersion: context.extension.packageJSON.version as string,
        installedAt: installer.readManifest(workspacePath)?.installedAt ?? now,
        updatedAt: now,
        skills: {
          version: skillsVersion,
          orchVersion: skillsOrchVersion,
          count: skillsCount,
          path: WS_CODEX_SKILLS_PATH.replace(/\\/g, '/'),
        },
        agents: {
          version: agentsVersion,
          count: agentsCount,
          path: WS_CODEX_AGENTS_PATH.replace(/\\/g, '/'),
        },
        config: {
          installed: configInstalled,
          path: WS_CODEX_CONFIG_PATH.replace(/\\/g, '/'),
        },
        scripts: {
          installed: scriptsInstalled,
          path: WS_CODEX_SCRIPTS_PATH.replace(/\\/g, '/'),
        },
      };

      try {
        installer.writeManifest(workspacePath, manifest);
        steps.push({ name: '寫入 Manifest', status: 'success' });
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        steps.push({ name: '寫入 Manifest', status: 'failed', error: message });
        logger.error(`Codex manifest write failed: ${message}`);
      }
    }
  );

  isRunning = false;
  await vscode.commands.executeCommand('setContext', CTX_CODEX_IS_RUNNING, false);

  const initialized = installer.isInitialized(workspacePath);
  await vscode.commands.executeCommand('setContext', CTX_CODEX_INITIALIZED, initialized);
  webviewProvider?.refresh();

  // Run doctor automatically after init to reflect latest deployment state in the webview
  void vscode.commands.executeCommand('dta.codex.doctor', true);

  // Background online update check — mirrors Claude mode's checkAndNotifyClaudeUpdates()
  void checkAndNotifyCodexUpdates(workspacePath, installer, logger, webviewProvider);

  const failedSteps = steps.filter((s) => s.status === 'failed');
  if (failedSteps.length === 0) {
    const successCount = steps.filter((s) => s.status === 'success').length;
    vscode.window.showInformationMessage(
      `✅ Codex 模式初始化完成（${successCount}/${steps.length} 步驟通過）`
    );
  } else {
    const failedNames = failedSteps.map((s) => s.name).join(', ');
    vscode.window.showWarningMessage(
      `⚠ Codex 初始化部分步驟失敗：${failedNames}`,
      '重新初始化'
    ).then((action) => {
      if (action === '重新初始化') {
        void vscode.commands.executeCommand(CMD_CODEX_INIT);
      }
    });
  }
}

function isNewerVersion(online: string, installed: string): boolean {
  const normalize = (v: string) => v.replace(/^v/, '').split('.').map(Number);
  const a = normalize(online);
  const b = normalize(installed);
  for (let i = 0; i < 3; i++) {
    if ((a[i] ?? 0) > (b[i] ?? 0)) return true;
    if ((a[i] ?? 0) < (b[i] ?? 0)) return false;
  }
  return false;
}

async function checkAndNotifyCodexUpdates(
  workspacePath: string,
  installer: CodexInstaller,
  logger: Logger,
  webviewProvider?: CodexWebviewProvider
): Promise<void> {
  try {
    const manifest = installer.readManifest(workspacePath);
    if (!manifest) return;

    const [latestSkills, latestOrch] = await Promise.all([
      installer.getLatestOnlineSkillsVersion(),
      installer.getLatestOnlineOrchVersion(),
    ]);

    const skillsNewer = latestSkills !== null && isNewerVersion(latestSkills, manifest.skills.version);
    const orchNewer   = latestOrch   !== null && isNewerVersion(latestOrch,   manifest.agents.version);

    if (!skillsNewer && !orchNewer) {
      logger.debug('Codex background update check: already up to date');
      return;
    }

    const parts: string[] = [];
    if (skillsNewer) parts.push(`Skills ${manifest.skills.version} → ${latestSkills!}`);
    if (orchNewer)   parts.push(`Orchestration ${manifest.agents.version} → ${latestOrch!}`);
    logger.info(`Codex update available: ${parts.join(', ')}`);

    const action = await vscode.window.showInformationMessage(
      `Codex 模式發現新版本：${parts.join('、')}`,
      '立即更新',
      '略過'
    );
    if (action !== '立即更新') return;

    await vscode.window.withProgress(
      { location: vscode.ProgressLocation.Notification, title: '更新 Codex 模式定義檔...' },
      async (progress) => {
        let newSkillsVersion  = manifest.skills.version;
        let newOrchVersion    = manifest.skills.orchVersion ?? manifest.agents.version;
        let newAgentsVersion  = manifest.agents.version;
        let newSkillsCount    = manifest.skills.count;
        let newAgentsCount    = manifest.agents.count;

        if (skillsNewer) {
          progress.report({ message: '更新 Skills...' });
          const result = await installer.deploySkillsFromRelease(workspacePath);
          newSkillsVersion = result.version;
          newOrchVersion   = result.orchVersion;
          newSkillsCount   = result.count;
          logger.info(`Codex skills updated to ${result.version}`);
        }

        if (orchNewer) {
          progress.report({ message: '更新 Agents + Config...' });
          const result = await installer.deployOrchFromRelease(workspacePath);
          newAgentsVersion = result.version;
          newAgentsCount   = result.agentsCount;
          if (!skillsNewer) newOrchVersion = result.version;
          logger.info(`Codex orch updated to ${result.version}`);
        }

        installer.writeManifest(workspacePath, {
          ...manifest,
          updatedAt: new Date().toISOString(),
          skills: {
            ...manifest.skills,
            version:     newSkillsVersion,
            orchVersion: newOrchVersion,
            count:       newSkillsCount,
          },
          agents: {
            ...manifest.agents,
            version: newAgentsVersion,
            count:   newAgentsCount,
          },
        });
      }
    );

    webviewProvider?.refresh();
    vscode.window.showInformationMessage('Codex 模式更新完成 ✅');
  } catch (err) {
    logger.debug(`Codex background update check error: ${err}`);
  }
}
