import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import { ShellExecutor } from '../utils/shell';
import { PathResolver } from '../utils/path-resolver';
import { CodexInstaller } from '../services/codex-installer';
import { Logger } from '../utils/logger';
import { CodexWebviewProvider, CodexDoctorResultItem } from '../views/codex-webview-provider';
import { DiagnosticCheck, DiagnosticResult } from '../types';
import {
  MIN_NODE_VERSION,
  WS_CODEX_SKILLS_PATH,
  WS_CODEX_AGENTS_PATH,
  WS_CODEX_SCRIPTS_PATH,
  WS_CODEX_CONFIG_PATH,
  CODEX_TOKEN_SCRIPT,
  CODEX_RUN_STATE_SCRIPT,
} from '../constants';
import { countDirs } from '../utils/file-deploy';
import { parseTomlSections } from '../utils/toml-merge';

function compareVersions(a: string, b: string): number {
  const pa = a.split('.').map(Number);
  const pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if ((pa[i] ?? 0) !== (pb[i] ?? 0)) {
      return (pa[i] ?? 0) > (pb[i] ?? 0) ? 1 : -1;
    }
  }
  return 0;
}

const REQUIRED_CONFIG_SECTIONS = ['features', 'agents'];

export async function executeCodexDoctor(
  shell: ShellExecutor,
  pathResolver: PathResolver,
  installer: CodexInstaller,
  logger: Logger,
  webviewProvider: CodexWebviewProvider,
  silent = false
): Promise<void> {
  let workspacePath: string;
  try {
    workspacePath = pathResolver.getWorkspacePath();
  } catch (err) {
    vscode.window.showErrorMessage(err instanceof Error ? err.message : String(err));
    return;
  }

  const skillsPath  = path.join(workspacePath, WS_CODEX_SKILLS_PATH);
  const agentsPath  = path.join(workspacePath, WS_CODEX_AGENTS_PATH);
  const configPath  = path.join(workspacePath, WS_CODEX_CONFIG_PATH);
  const scriptsPath = path.join(workspacePath, WS_CODEX_SCRIPTS_PATH);
  const runStatePath   = path.join(scriptsPath, CODEX_RUN_STATE_SCRIPT);
  const tokenEnginePath = path.join(scriptsPath, CODEX_TOKEN_SCRIPT);
  const isInitialized = installer.isInitialized(workspacePath);

  const checks: DiagnosticCheck[] = [
    {
      name: 'Node.js',
      check: async () => {
        const r = await shell.exec('node --version');
        if (r.exitCode !== 0) {
          return { passed: false, detail: '未安裝', suggestion: '請安裝 Node.js >= 18：https://nodejs.org/' };
        }
        const ver = r.stdout.replace(/^v/, '');
        const ok = compareVersions(ver, MIN_NODE_VERSION) >= 0;
        return {
          passed: ok,
          detail: `v${ver} (>= ${MIN_NODE_VERSION})`,
          suggestion: ok ? undefined : `Node.js 版本過舊，請升級至 >= ${MIN_NODE_VERSION}`,
        };
      },
    },
    {
      name: '.codex/skills 目錄',
      check: async () => {
        if (!fs.existsSync(skillsPath)) {
          return {
            passed: false,
            detail: '目錄不存在',
            suggestion: isInitialized ? '自動修復可還原 Skills' : '請先執行「初始化（Codex 模式）」',
          };
        }
        const dirCount = countDirs(skillsPath);
        if (dirCount === 0) {
          return { passed: false, detail: '目錄為空', suggestion: '請重新執行初始化' };
        }
        return { passed: true, detail: `${dirCount} 個 skill 目錄` };
      },
      autoFix: isInitialized ? async () => {
        await installer.deploySkills(workspacePath);
      } : undefined,
    },
    {
      name: '.codex/agents 目錄',
      check: async () => {
        if (!fs.existsSync(agentsPath)) {
          return {
            passed: false,
            detail: '目錄不存在',
            suggestion: isInitialized ? '自動修復可還原 Agents' : '請先執行「初始化（Codex 模式）」',
          };
        }
        const files = fs.readdirSync(agentsPath).filter((f) => f.endsWith('.toml'));
        if (files.length === 0) {
          return { passed: false, detail: '目錄為空（無 .toml）', suggestion: '請重新執行初始化' };
        }
        return { passed: true, detail: `${files.length} 個 agent 定義 (.toml)` };
      },
      autoFix: isInitialized ? async () => {
        await installer.deployAgents(workspacePath);
      } : undefined,
    },
    {
      name: '.codex/config.toml',
      check: async () => {
        if (!fs.existsSync(configPath)) {
          return {
            passed: false,
            detail: '檔案不存在',
            suggestion: isInitialized ? '自動修復可還原 config.toml' : '請先執行「初始化（Codex 模式）」',
          };
        }
        let sections: Set<string>;
        try {
          sections = parseTomlSections(fs.readFileSync(configPath, 'utf-8'));
        } catch {
          return { passed: false, detail: '無法解析 config.toml', suggestion: '請重新執行初始化' };
        }
        const missing = REQUIRED_CONFIG_SECTIONS.filter((s) => !sections.has(s));
        if (missing.length > 0) {
          return {
            passed: false,
            detail: `缺少必要區段：${missing.map((s) => `[${s}]`).join(', ')}`,
            suggestion: '自動修復可補上缺少的設定區段',
          };
        }
        return { passed: true, detail: '已部署（含 [features]/[agents]）' };
      },
      autoFix: isInitialized ? async () => {
        await installer.deployConfig(workspacePath);
      } : undefined,
    },
    {
      name: '.codex/scripts 目錄 (run-state + token 引擎)',
      check: async () => {
        const missing: string[] = [];
        // run-state.mjs 是關鍵：缺它會導致 timing / token telemetry 全空（orchestration-codex >= v1.0.2）
        if (!fs.existsSync(runStatePath))   missing.push(CODEX_RUN_STATE_SCRIPT);
        if (!fs.existsSync(tokenEnginePath)) missing.push(CODEX_TOKEN_SCRIPT);
        if (missing.length > 0) {
          return {
            passed: false,
            detail: `缺少：${missing.join(', ')}`,
            suggestion: isInitialized
              ? '自動修復可還原 run-state / token 引擎'
              : '請先執行「初始化（Codex 模式）」',
          };
        }
        return { passed: true, detail: `${CODEX_RUN_STATE_SCRIPT}、${CODEX_TOKEN_SCRIPT} 已部署` };
      },
      autoFix: isInitialized ? async () => {
        await installer.deployScripts(workspacePath);
      } : undefined,
    },
    {
      name: 'Codex CLI',
      check: async () => {
        const r = await shell.exec('codex --version');
        if (r.exitCode !== 0) {
          return {
            passed: false,
            detail: '未安裝或不在 PATH 中',
            suggestion: '請安裝 Codex CLI：https://github.com/openai/codex',
          };
        }
        return { passed: true, detail: r.stdout.trim() || '已安裝' };
      },
    },
  ];

  const results: Array<{ check: DiagnosticCheck; result: DiagnosticResult }> = [];

  for (const check of checks) {
    try {
      const result = await check.check();
      results.push({ check, result });
    } catch (err) {
      results.push({
        check,
        result: {
          passed: false,
          detail: '檢查時發生錯誤',
          suggestion: err instanceof Error ? err.message : String(err),
        },
      });
    }
  }

  const doctorItems: CodexDoctorResultItem[] = results.map((r) => ({
    name: r.check.name,
    passed: r.result.passed,
    detail: r.result.detail,
    suggestion: r.result.suggestion,
  }));

  webviewProvider.showDoctorResults(doctorItems);

  const passedCount  = results.filter((r) => r.result.passed).length;
  const failedChecks = results.filter((r) => !r.result.passed);
  const fixableChecks = failedChecks.filter((r) => !!r.check.autoFix);

  if (failedChecks.length === 0) {
    if (!silent) {
      vscode.window.showInformationMessage(
        `環境診斷完成：${passedCount}/${results.length} 項目全部通過 ✅`
      );
    }
  } else {
    const msg = `環境診斷完成：${passedCount}/${results.length} 項目通過，${failedChecks.length} 項需要修復`;
    const buttons: string[] = [];
    if (fixableChecks.length > 0) buttons.push('一鍵修復');

    const action = await vscode.window.showWarningMessage(msg, ...buttons);
    if (action === '一鍵修復') {
      await vscode.window.withProgress(
        { location: vscode.ProgressLocation.Notification, title: '自動修復 Codex 環境問題' },
        async (progress) => {
          for (const { check } of fixableChecks) {
            progress.report({ message: `修復：${check.name}...` });
            try {
              await check.autoFix!();
              logger.info(`Codex auto-fix succeeded: ${check.name}`);
            } catch (err) {
              logger.error(`Codex auto-fix failed: ${check.name}`, err instanceof Error ? err : undefined);
            }
          }
        }
      );
      webviewProvider.refresh();
      vscode.window.showInformationMessage('自動修復完成，建議重新執行環境診斷確認結果。');
    }
  }
}
