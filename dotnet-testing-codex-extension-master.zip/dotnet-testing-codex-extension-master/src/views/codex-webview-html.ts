function getNonce(): string {
  let text = '';
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < 32; i++) {
    text += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return text;
}

/**
 * Builds the Codex Webview HTML string. No vscode dependency — safe to import in unit tests.
 * @param nonce Optional nonce override for deterministic testing.
 */
export function buildCodexWebviewHtml(nonce?: string): string {
  const _nonce = nonce ?? getNonce();
  return `<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${_nonce}';">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>${CSS}</style>
</head>
<body>
<nav class="tab-bar">
  <button class="tab active" data-tab="overview">總覽</button>
  <button class="tab" data-tab="skills">Skills</button>
  <button class="tab" data-tab="agents">Agents</button>
</nav>
<div class="panels">

  <div id="panel-overview" class="panel active">
    <div id="status-badge" class="status-badge">
      <span id="status-icon">⚠️</span>
      <span id="status-text">尚未初始化</span>
    </div>
    <div id="overview-installed" class="info-grid hidden">
      <div class="info-row"><span class="info-label">安裝時間</span><span id="installed-at">—</span></div>
      <div class="info-row"><span class="info-label">更新時間</span><span id="updated-at">—</span></div>
      <div class="info-row"><span class="info-label">Extension</span><span id="ext-version">—</span></div>
    </div>
    <div class="actions">
      <button id="btn-init">初始化 Codex</button>
      <button class="secondary" id="btn-doctor">環境診斷</button>
    </div>
    <div id="doctor-results" class="hidden">
      <div class="section-title">診斷結果</div>
      <div id="doctor-list"></div>
    </div>
  </div>

  <div id="panel-skills" class="panel">
    <p id="skills-not-init" class="hint">尚未初始化，請先執行初始化。</p>
    <div id="skills-info" class="hidden">
      <div class="info-grid">
        <div class="info-row"><span class="info-label">共用版本</span><span id="skills-version" style="flex:1">—</span><button id="skills-version-link" class="link-btn hidden" data-url=""></button></div>
        <div class="info-row"><span class="info-label">Codex 版本</span><span id="skills-orch-version">—</span></div>
        <div class="info-row"><span class="info-label">數量</span><span id="skills-count">—</span></div>
        <div class="info-row"><span class="info-label">路徑</span><span id="skills-path" class="path-val">—</span></div>
      </div>
      <div class="section-title">GitHub Release Notes <span class="source-tag">dotnet-testing-agent-skills</span></div>
      <div id="skills-release-content" class="hint">切換至此 Tab 後自動載入…</div>
      <div class="section-title" style="margin-top:10px">Codex 專屬 Skills <span class="source-tag">orchestration-codex</span></div>
      <div id="skills-highlight"></div>
    </div>
  </div>

  <div id="panel-agents" class="panel">
    <p id="agents-not-init" class="hint">尚未初始化，請先執行初始化。</p>
    <div id="agents-info" class="hidden">
      <div class="info-grid">
        <div class="info-row"><span class="info-label">版本</span><span id="agents-version">—</span></div>
        <div class="info-row"><span class="info-label">GitHub</span><button class="link-btn" data-url="https://github.com/kevintsengtw/dotnet-testing-agent-orchestration-codex">orchestration-codex ↗</button></div>
        <div class="info-row"><span class="info-label">數量</span><span id="agents-count">—</span></div>
        <div class="info-row"><span class="info-label">路徑</span><span id="agents-path" class="path-val">—</span></div>
        <div class="info-row"><span class="info-label">Config</span><span id="config-status">—</span></div>
      </div>
      <div class="section-title">GitHub Release Notes <span class="source-tag">orchestration-codex</span></div>
      <div id="orch-release-content" class="hint">切換至此 Tab 後自動載入…</div>
      <div class="section-title" style="margin-top:10px">Config <span class="source-tag">.codex/config.toml</span></div>
      <div id="config-list"></div>
      <div class="section-title" style="margin-top:10px">Agent 定義 <span class="source-tag">orchestration-codex</span></div>
      <div id="agents-list"></div>
      <div class="section-title" style="margin-top:10px">Token 估算引擎 <span class="source-tag">.codex/scripts</span></div>
      <div id="scripts-list"></div>
    </div>
  </div>

</div>
<script nonce="${_nonce}">${JS}</script>
</body>
</html>`;
}

// ─── CSS ────────────────────────────────────────────────────────────────────
const CSS = `
*{box-sizing:border-box;margin:0;padding:0}
body{
  font-family:var(--vscode-font-family);
  font-size:var(--vscode-font-size);
  color:var(--vscode-editor-foreground);
  background:var(--vscode-sideBar-background);
  display:flex;flex-direction:column;height:100vh;overflow:hidden
}
.tab-bar{
  display:flex;flex-shrink:0;
  background:var(--vscode-tab-inactiveBackground);
  border-bottom:1px solid var(--vscode-panel-border);
  overflow-x:auto;scrollbar-width:none
}
.tab-bar::-webkit-scrollbar{display:none}
.tab{
  flex:1;min-width:max-content;padding:6px 8px;border:none;
  background:transparent;color:var(--vscode-tab-inactiveForeground);
  cursor:pointer;font-size:11px;border-bottom:2px solid transparent;
  white-space:nowrap
}
.tab:hover{background:var(--vscode-tab-hoverBackground)}
.tab.active{
  color:var(--vscode-tab-activeForeground);
  border-bottom-color:var(--vscode-focusBorder);
  background:var(--vscode-tab-activeBackground)
}
.panels{flex:1;overflow-y:auto}
.panel{display:none;padding:12px}
.panel.active{display:block}
.status-badge{
  display:flex;align-items:center;gap:6px;
  padding:8px 10px;border-radius:4px;margin-bottom:8px;
  background:var(--vscode-badge-background);
  font-weight:600;font-size:13px
}
.info-grid{
  border:1px solid var(--vscode-panel-border);
  border-radius:4px;margin-bottom:12px
}
.info-row{
  display:flex;gap:8px;padding:5px 10px;font-size:12px;
  border-bottom:1px solid var(--vscode-panel-border)
}
.info-row:last-child{border-bottom:none}
.info-label{color:var(--vscode-descriptionForeground);min-width:52px;flex-shrink:0}
.path-val{word-break:break-all;font-size:11px}
.actions{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px}
button{
  padding:5px 12px;border:none;border-radius:2px;
  background:var(--vscode-button-background);
  color:var(--vscode-button-foreground);
  cursor:pointer;font-size:12px
}
button:hover{background:var(--vscode-button-hoverBackground)}
button.secondary{
  background:var(--vscode-button-secondaryBackground);
  color:var(--vscode-button-secondaryForeground)
}
button.secondary:hover{background:var(--vscode-button-secondaryHoverBackground)}
button.link-btn{
  background:transparent;color:var(--vscode-textLink-foreground);
  padding:0 2px;border:none;cursor:pointer;font-size:11px;text-decoration:underline;border-radius:0
}
button.link-btn:hover{background:transparent;color:var(--vscode-textLink-activeForeground)}
.section-title{
  font-size:11px;font-weight:600;text-transform:uppercase;
  letter-spacing:.5px;color:var(--vscode-descriptionForeground);margin-bottom:6px;
  display:flex;align-items:center;gap:6px
}
.source-tag{
  background:var(--vscode-badge-background);color:var(--vscode-badge-foreground);
  padding:1px 5px;border-radius:8px;font-size:10px;font-weight:400;
  text-transform:none;letter-spacing:0
}
.hint{font-size:12px;color:var(--vscode-descriptionForeground);margin-bottom:8px}
.release-header{display:flex;gap:8px;align-items:center;margin-bottom:6px}
.release-tag{
  background:var(--vscode-badge-background);color:var(--vscode-badge-foreground);
  padding:2px 6px;border-radius:10px;font-size:11px
}
.release-date{font-size:11px;color:var(--vscode-descriptionForeground)}
.release-body{
  font-size:11px;line-height:1.5;white-space:pre-wrap;word-break:break-word;
  background:var(--vscode-input-background);padding:8px;border-radius:4px;
  max-height:260px;overflow-y:auto
}
.result-table{width:100%;border-collapse:collapse;font-size:12px;margin-bottom:8px}
.result-table th{
  text-align:left;padding:5px 8px;
  background:var(--vscode-sideBarSectionHeader-background);
  border-bottom:1px solid var(--vscode-panel-border);font-weight:600
}
.result-table td{
  padding:5px 8px;border-bottom:1px solid var(--vscode-panel-border);vertical-align:top
}
.result-table tr:last-child td{border-bottom:none}
.sug-row td{
  padding-top:2px;padding-bottom:6px;
  font-size:11px;color:var(--vscode-descriptionForeground)
}
.result-summary{
  padding:6px 10px;border-radius:4px;font-size:12px;font-weight:600;
  background:var(--vscode-badge-background)
}
.hidden{display:none}
`;

// ─── JavaScript ──────────────────────────────────────────────────────────────
const JS = `
const vscode = acquireVsCodeApi();
let orchReleaseLoaded = false;
let skillsReleaseLoaded = false;

function sendCmd(c){ vscode.postMessage({command:c}); }
function openUrl(url){ vscode.postMessage({command:'openUrl',url}); }
document.body.addEventListener('click', e => {
  const btn = e.target && e.target.closest && e.target.closest('.link-btn');
  if(btn && btn.dataset.url) openUrl(btn.dataset.url);
});

document.getElementById('btn-init').addEventListener('click', () => sendCmd('init'));
document.getElementById('btn-doctor').addEventListener('click', () => sendCmd('runDoctor'));

document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => activateTab(btn.dataset.tab, true));
});

function activateTab(name, fromUser){
  document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  const t = document.querySelector('[data-tab="'+name+'"]');
  const p = document.getElementById('panel-'+name);
  if(t) t.classList.add('active');
  if(p) p.classList.add('active');
  if(fromUser && name === 'agents' && !orchReleaseLoaded){
    orchReleaseLoaded = true;
    sendCmd('fetchOrchRelease');
  }
  if(fromUser && name === 'skills' && !skillsReleaseLoaded){
    skillsReleaseLoaded = true;
    sendCmd('fetchSkillsRelease');
  }
}

window.addEventListener('message', e => {
  const msg = e.data;
  if(msg.type === 'state')              onState(msg);
  else if(msg.type === 'orchRelease')   onRelease(msg);
  else if(msg.type === 'skillsRelease') onSkillsRelease(msg);
  else if(msg.type === 'doctorResults') onDoctorResults(msg.results);
  else if(msg.type === 'switchTab')     activateTab(msg.tab, false);
});

function renderList(id, items){
  const el = document.getElementById(id);
  if(!el || !Array.isArray(items)) return;
  el.innerHTML = items.map(it =>
    '<div class="info-row">' +
    '<span class="info-label" style="min-width:0;flex:1;word-break:break-all">' + esc(it.name) + '</span>' +
    '<span style="flex-shrink:0">' + (it.exists ? '✅' : '❌') + '</span>' +
    '</div>'
  ).join('');
}

function onState(msg){
  const m = msg.manifest;
  const ok = msg.initialized && !!m;
  document.getElementById('status-icon').textContent = ok ? '✅' : '⚠️';
  document.getElementById('status-text').textContent = ok ? '已初始化' : '尚未初始化';
  if(ok && m){
    show('overview-installed');
    setText('installed-at', fmt(m.installedAt));
    setText('updated-at',   fmt(m.updatedAt));
    setText('ext-version',  'v' + m.extensionVersion);
    show('skills-info'); hide('skills-not-init');
    setText('skills-version',      m.skills.version);
    setText('skills-orch-version', m.skills.orchVersion ?? '—');
    setText('skills-count',        (msg.skillsDirCount ?? m.skills.count) + ' 個 Skills');
    setText('skills-path',         m.skills.path);
    renderList('skills-highlight', msg.highlightSkills);
    show('agents-info'); hide('agents-not-init');
    setText('agents-version', m.agents.version);
    setText('agents-count',   m.agents.count + ' 個');
    setText('agents-path',    m.agents.path);
    setText('config-status',  m.config && m.config.installed ? '已部署' : '未部署');
    renderList('config-list',  msg.configList);
    renderList('agents-list',  msg.agentsList);
    renderList('scripts-list', msg.scriptsList);
  } else {
    hide('overview-installed');
    hide('skills-info'); show('skills-not-init');
    hide('agents-info'); show('agents-not-init');
  }
}

function onRelease(msg){
  const el = document.getElementById('orch-release-content');
  if(!el) return;
  if(msg.error || !msg.release){
    el.innerHTML = '<span style="color:var(--vscode-errorForeground)">無法取得 Release 資訊：'+esc(msg.error||'unknown')+'</span>';
    return;
  }
  const r = msg.release;
  el.innerHTML =
    '<div class="release-header">'+
    '<span class="release-tag">'+esc(r.tag)+'</span>'+
    (r.url?'<button class="link-btn release-link" data-url="'+esc(r.url)+'">在 GitHub 查看 ↗</button>':'')+
    '<span class="release-date">'+fmt(r.publishedAt)+'</span>'+
    '</div>'+
    '<pre class="release-body">'+esc(r.body)+'</pre>';
}

function onSkillsRelease(msg){
  const el = document.getElementById('skills-release-content');
  if(!el) return;
  if(msg.error || !msg.release){
    el.innerHTML = '<span style="color:var(--vscode-errorForeground)">無法取得 Release 資訊：'+esc(msg.error||'unknown')+'</span>';
    return;
  }
  const r = msg.release;
  if(r.url){
    const lnk = document.getElementById('skills-version-link');
    if(lnk){ lnk.dataset.url = r.url; lnk.classList.remove('hidden'); lnk.textContent = r.tag+' ↗'; }
  }
  el.innerHTML =
    '<div class="release-header">'+
    '<span class="release-tag">'+esc(r.tag)+'</span>'+
    (r.url?'<button class="link-btn release-link" data-url="'+esc(r.url)+'">在 GitHub 查看 ↗</button>':'')+
    '<span class="release-date">'+fmt(r.publishedAt)+'</span>'+
    '</div>'+
    '<pre class="release-body">'+esc(r.body)+'</pre>';
}

function onDoctorResults(results){
  const list = document.getElementById('doctor-list');
  let rows = '';
  results.forEach(r => {
    rows += '<tr><td>'+esc(r.name)+'</td><td>'+(r.passed?'✅':'❌')+'</td><td>'+esc(r.detail)+'</td></tr>';
    if(!r.passed && r.suggestion)
      rows += '<tr class="sug-row"><td colspan="3">💡 '+esc(r.suggestion)+'</td></tr>';
  });
  const passed = results.filter(r => r.passed).length;
  list.innerHTML =
    '<table class="result-table">'+
    '<thead><tr><th>項目</th><th>狀態</th><th>詳細</th></tr></thead>'+
    '<tbody>'+rows+'</tbody></table>'+
    '<div class="result-summary">結果：'+passed+'/'+results.length+' 項目'+
    (passed===results.length ? '全部通過 ✅' : '通過 ⚠️')+'</div>';
  show('doctor-results');
}

function setText(id,v){ const e=document.getElementById(id); if(e) e.textContent=v; }
function show(id){ document.getElementById(id).classList.remove('hidden'); }
function hide(id){ document.getElementById(id).classList.add('hidden'); }
function fmt(s){ try{ return new Date(s).toLocaleString('zh-TW'); }catch{ return s||'—'; } }
function esc(s){
  return String(s||'')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

sendCmd('requestState');
`;
