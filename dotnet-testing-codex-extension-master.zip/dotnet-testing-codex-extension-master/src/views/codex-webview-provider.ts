import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import { CodexInstaller } from '../services/codex-installer';
import { PathResolver } from '../utils/path-resolver';
import { CodexManifest } from '../types';
import { countDirs } from '../utils/file-deploy';
import { parseTomlSections } from '../utils/toml-merge';
import { buildCodexWebviewHtml } from './codex-webview-html';
import { buildReleaseApiUrl } from '../utils/release-api';
import {
  DEFAULT_CODEX_ORCH_REPO,
  DEFAULT_SKILLS_REPO,
  WS_CODEX_CONFIG_PATH,
  WS_CODEX_SCRIPTS_PATH,
  CODEX_TOKEN_SCRIPT,
  CODEX_RUN_STATE_SCRIPT,
} from '../constants';

const CODEX_HIGHLIGHT_SKILLS = [
  'dotnet-test',
  'dotnet-testing-orchestrator-unit',
  'dotnet-testing-orchestrator-aspire',
  'dotnet-testing-orchestrator-integration',
  'dotnet-testing-orchestrator-tunit',
];

// .codex/scripts/ 下的引擎檔案：run-state 寫入器 + token 估算引擎
const CODEX_SCRIPT_FILES = [CODEX_RUN_STATE_SCRIPT, CODEX_TOKEN_SCRIPT];

const CODEX_AGENTS = [
  'dotnet-testing-analyzer',
  'dotnet-testing-writer',
  'dotnet-testing-executor',
  'dotnet-testing-reviewer',
  'dotnet-testing-advanced-integration-analyzer',
  'dotnet-testing-advanced-integration-writer',
  'dotnet-testing-advanced-integration-executor',
  'dotnet-testing-advanced-integration-reviewer',
  'dotnet-testing-advanced-aspire-analyzer',
  'dotnet-testing-advanced-aspire-writer',
  'dotnet-testing-advanced-aspire-executor',
  'dotnet-testing-advanced-aspire-reviewer',
  'dotnet-testing-advanced-tunit-analyzer',
  'dotnet-testing-advanced-tunit-writer',
  'dotnet-testing-advanced-tunit-executor',
  'dotnet-testing-advanced-tunit-reviewer',
];

const REQUIRED_CONFIG_SECTIONS = ['features', 'agents'];

export { buildCodexWebviewHtml } from './codex-webview-html';

export interface CodexDoctorResultItem {
  name: string;
  passed: boolean;
  detail: string;
  suggestion?: string;
}

export class CodexWebviewProvider implements vscode.WebviewViewProvider {
  public static readonly viewType = 'dta.codex.webview';

  private _view?: vscode.WebviewView;

  constructor(
    private readonly installer: CodexInstaller,
    private readonly pathResolver: PathResolver
  ) {}

  resolveWebviewView(
    webviewView: vscode.WebviewView,
    _context: vscode.WebviewViewResolveContext,
    _token: vscode.CancellationToken
  ): void {
    this._view = webviewView;
    webviewView.webview.options = { enableScripts: true };
    webviewView.webview.html = buildCodexWebviewHtml();

    webviewView.webview.onDidReceiveMessage(async (msg: { command: string; url?: string }) => {
      switch (msg.command) {
        case 'requestState':       this.sendState(); break;
        case 'init':               await vscode.commands.executeCommand('dta.codex.init'); break;
        case 'runDoctor':          await vscode.commands.executeCommand('dta.codex.doctor'); break;
        case 'fetchOrchRelease':   void this.fetchRelease(); break;
        case 'fetchSkillsRelease': void this.fetchSkillsRelease(); break;
        case 'openUrl':
          if (msg.url) { void vscode.env.openExternal(vscode.Uri.parse(msg.url)); }
          break;
      }
    });
  }

  refresh(): void {
    this.sendState();
  }

  /** 來源 repo URL 可由設定覆寫（改指向內部 Gitea）；留空則使用內建預設值。 */
  private resolveRepo(settingKey: string, fallback: string): string {
    return vscode.workspace.getConfiguration().get<string>(settingKey)?.trim() || fallback;
  }

  /** 從指定 repo（GitHub / Gitea）查最新 release，並回傳到 webview。 */
  private async fetchLatestRelease(repoUrl: string, messageType: 'orchRelease' | 'skillsRelease'): Promise<void> {
    try {
      const apiUrl = buildReleaseApiUrl(repoUrl);
      const resp = await fetch(apiUrl);
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json() as { tag_name: string; body: string; published_at: string; html_url: string };
      this._view?.webview.postMessage({
        type: messageType,
        release: { tag: data.tag_name, body: data.body, publishedAt: data.published_at, url: data.html_url },
      });
    } catch (err) {
      this._view?.webview.postMessage({ type: messageType, error: String(err) });
    }
  }

  private async fetchRelease(): Promise<void> {
    await this.fetchLatestRelease(this.resolveRepo('dta.codex.orchRepo', DEFAULT_CODEX_ORCH_REPO), 'orchRelease');
  }

  private async fetchSkillsRelease(): Promise<void> {
    await this.fetchLatestRelease(this.resolveRepo('dta.codex.skillsRepo', DEFAULT_SKILLS_REPO), 'skillsRelease');
  }

  showDoctorResults(results: CodexDoctorResultItem[]): void {
    this._view?.webview.postMessage({ type: 'doctorResults', results });
    this._view?.webview.postMessage({ type: 'switchTab', tab: 'overview' });
  }

  private sendState(): void {
    let manifest: CodexManifest | null = null;
    let wsPath = '';
    let skillsAbsPath = '';
    try {
      wsPath = this.pathResolver.getWorkspacePath();
      manifest = this.installer.readManifest(wsPath);
      if (manifest) {
        skillsAbsPath = path.join(wsPath, manifest.skills.path);
      }
    } catch { /* no workspace */ }

    const skillsDirCount = skillsAbsPath ? countDirs(skillsAbsPath) : 0;
    const highlightSkills = CODEX_HIGHLIGHT_SKILLS.map(name => ({
      name,
      exists: skillsAbsPath ? fs.existsSync(path.join(skillsAbsPath, name)) : false,
    }));

    let agentsAbsPath = '';
    let scriptsAbsPath = '';
    if (manifest && wsPath) {
      agentsAbsPath  = path.join(wsPath, manifest.agents.path);
      scriptsAbsPath = path.join(wsPath, manifest.scripts?.path ?? WS_CODEX_SCRIPTS_PATH);
    }
    const agentsList = CODEX_AGENTS.map(name => ({
      name,
      exists: agentsAbsPath ? fs.existsSync(path.join(agentsAbsPath, name + '.toml')) : false,
    }));

    const scriptsList = CODEX_SCRIPT_FILES.map(name => ({
      name,
      exists: scriptsAbsPath ? fs.existsSync(path.join(scriptsAbsPath, name)) : false,
    }));

    // Config 狀態：config.toml 存在 + 必要區段
    const configAbsPath = wsPath ? path.join(wsPath, WS_CODEX_CONFIG_PATH) : '';
    let configSections = new Set<string>();
    const configExists = configAbsPath ? fs.existsSync(configAbsPath) : false;
    if (configExists) {
      try {
        configSections = parseTomlSections(fs.readFileSync(configAbsPath, 'utf-8'));
      } catch { /* ignore parse error */ }
    }
    const configList = [
      { name: 'config.toml', exists: configExists },
      ...REQUIRED_CONFIG_SECTIONS.map(s => ({ name: `[${s}]`, exists: configSections.has(s) })),
    ];

    this._view?.webview.postMessage({
      type: 'state',
      manifest,
      initialized: !!manifest,
      skillsDirCount,
      highlightSkills,
      agentsList,
      configList,
      scriptsList,
    });
  }
}
