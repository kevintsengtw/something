import * as vscode from 'vscode';
import { CodexInstaller } from '../services/codex-installer';
import { PathResolver } from '../utils/path-resolver';
import { VersionChecker } from '../services/version-checker';
import { isNewerVersion } from '../utils/semver';
import { VersionDrift } from '../types';
import { CMD_CODEX_INIT } from '../constants';
import { buildAboutWebviewHtml } from './about-webview-html';

/** Sidebar 置頂的「版本資訊」WebviewView：目前版本 / 最新 release / release note / 部署落差。 */
export class AboutWebviewProvider implements vscode.WebviewViewProvider {
  public static readonly viewType = 'dta.about';

  private _view?: vscode.WebviewView;

  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly versionChecker: VersionChecker,
    private readonly codexInstaller: CodexInstaller,
    private readonly pathResolver: PathResolver,
    /** 本次啟動是否偵測到 extension 剛更新（版本與上次啟動不同）。 */
    private readonly justUpdated: boolean = false,
    /** 更新前的版本（首次安裝為 undefined）。 */
    private readonly updatedFrom?: string
  ) {}

  resolveWebviewView(webviewView: vscode.WebviewView): void {
    this._view = webviewView;
    webviewView.webview.options = { enableScripts: true };
    webviewView.webview.html = buildAboutWebviewHtml();

    webviewView.webview.onDidReceiveMessage(async (msg: { command: string; url?: string; mode?: string }) => {
      switch (msg.command) {
        case 'requestState':
        case 'refresh':
          await this.sendState();
          break;
        case 'openUrl':
          if (msg.url) { void vscode.env.openExternal(vscode.Uri.parse(msg.url)); }
          break;
        case 'reinit':
          if (msg.mode === 'codex') { void vscode.commands.executeCommand(CMD_CODEX_INIT); }
          break;
      }
    });
  }

  /** 重新蒐集並推送狀態（供 init 完成後或外部刷新呼叫）。 */
  refresh(): void {
    void this.sendState();
  }

  private async sendState(): Promise<void> {
    const currentVersion = this.context.extension.packageJSON.version as string;
    const latest = await this.versionChecker.fetchLatestRelease();
    const hasUpdate = latest ? isNewerVersion(latest.version, currentVersion) : false;
    const drifts = this.collectDrifts(currentVersion);
    this._view?.webview.postMessage({
      type: 'state', currentVersion, latest, hasUpdate, drifts,
      justUpdated: this.justUpdated, updatedFrom: this.updatedFrom,
    });
  }

  /** 比對 Codex manifest 的部署版本與目前安裝版本，回傳不一致者。 */
  private collectDrifts(currentVersion: string): VersionDrift[] {
    let wsPath: string;
    try {
      wsPath = this.pathResolver.getWorkspacePath();
    } catch {
      return [];
    }
    const drifts: VersionDrift[] = [];
    const codex = this.codexInstaller.readManifest(wsPath);
    if (codex?.extensionVersion && codex.extensionVersion !== currentVersion) {
      drifts.push({ mode: 'codex', deployedVersion: codex.extensionVersion });
    }
    return drifts;
  }
}
