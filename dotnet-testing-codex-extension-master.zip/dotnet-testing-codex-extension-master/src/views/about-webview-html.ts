function getNonce(): string {
  let text = '';
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < 32; i++) {
    text += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return text;
}

/**
 * 建立「版本資訊」Webview 的 HTML 字串。純函式、無 vscode 相依，可在單元測試直接呼叫。
 * @param nonce 測試可傳入固定 nonce；正式執行時自動生成。
 */
export function buildAboutWebviewHtml(nonce?: string): string {
  const _nonce = nonce ?? getNonce();
  return `<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${_nonce}';">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>${CSS}</style>
</head>
<body>
<div id="update-banner" class="update-banner hidden">
  <div class="ub-text">🔄 <b>已更新至 v<span id="ub-version">—</span></b><span id="ub-from"></span>。若側邊欄未看到新面板（例如「Codex 模式」），請<b>完整結束 VS Code 再重新開啟</b>（Windows：<code>File → Exit</code>；macOS：<code>Cmd+Q</code>），<b>不能只用 Reload Window</b>。</div>
  <button id="ub-dismiss" class="ub-dismiss" title="關閉">✕</button>
</div>
<div class="info-grid">
  <div class="info-row"><span class="info-label">目前安裝版本</span><span id="current-version" class="val">—</span></div>
  <div class="info-row"><span class="info-label">最新版本</span><span id="latest-version" class="val">—</span><span id="latest-status" class="badge"></span></div>
  <div class="info-row"><span class="info-label">發佈日期</span><span id="latest-date" class="val">—</span></div>
</div>
<div class="actions">
  <button class="link-btn" id="link-release" data-url="">在 GitHub 查看 ↗</button>
  <button class="link-btn hidden" id="link-download" data-url="">前往下載 ↗</button>
  <button class="secondary" id="btn-refresh">🔄 重新整理</button>
</div>
<div class="section-title">最新版本說明</div>
<pre id="release-notes" class="notes">載入中…</pre>
<div id="drift-wrap" class="hidden">
  <div class="section-title">部署落差</div>
  <div id="drift-list"></div>
</div>
<script nonce="${_nonce}">${JS}</script>
</body>
</html>`;
}

const CSS = `
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:var(--vscode-font-family);font-size:var(--vscode-font-size);color:var(--vscode-editor-foreground);background:var(--vscode-sideBar-background);padding:12px}
.info-grid{border:1px solid var(--vscode-panel-border);border-radius:4px;margin-bottom:10px}
.info-row{display:flex;gap:8px;align-items:center;padding:5px 10px;font-size:12px;border-bottom:1px solid var(--vscode-panel-border)}
.info-row:last-child{border-bottom:none}
.info-label{color:var(--vscode-descriptionForeground);min-width:84px;flex-shrink:0}
.val{font-weight:600}
.badge{font-size:10px;padding:1px 6px;border-radius:8px;background:var(--vscode-badge-background);color:var(--vscode-badge-foreground)}
.badge.update{background:var(--vscode-statusBarItem-warningBackground)}
.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
button{padding:4px 10px;border:none;border-radius:2px;background:var(--vscode-button-background);color:var(--vscode-button-foreground);cursor:pointer;font-size:12px}
button:hover{background:var(--vscode-button-hoverBackground)}
button.secondary{background:var(--vscode-button-secondaryBackground);color:var(--vscode-button-secondaryForeground)}
button.link-btn{background:transparent;color:var(--vscode-textLink-foreground);padding:0 2px;text-decoration:underline}
button.link-btn:hover{background:transparent;color:var(--vscode-textLink-activeForeground)}
.section-title{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--vscode-descriptionForeground);margin:6px 0}
.notes{font-size:11px;line-height:1.5;white-space:pre-wrap;word-break:break-word;background:var(--vscode-input-background);padding:8px;border-radius:4px;max-height:300px;overflow-y:auto}
.drift-row{display:flex;flex-direction:column;gap:4px;padding:8px;border:1px solid var(--vscode-statusBarItem-warningBackground);border-radius:4px;margin-bottom:6px;font-size:12px}
.update-banner{display:flex;gap:8px;align-items:flex-start;padding:8px 10px;margin-bottom:10px;border-radius:4px;background:var(--vscode-statusBarItem-warningBackground);color:var(--vscode-statusBarItem-warningForeground);border:1px solid var(--vscode-statusBarItem-warningBackground);font-size:12px;line-height:1.55}
.update-banner code{background:var(--vscode-textCodeBlock-background);padding:0 3px;border-radius:3px}
.ub-text{flex:1}
.ub-dismiss{background:transparent;color:inherit;border:none;cursor:pointer;padding:0 2px;font-size:12px;flex-shrink:0}
.ub-dismiss:hover{background:transparent;opacity:.75}
.hidden{display:none}
`;

const JS = `
const vscode = acquireVsCodeApi();
function sendCmd(c){ vscode.postMessage({command:c}); }
function openUrl(url){ vscode.postMessage({command:'openUrl',url}); }

document.getElementById('btn-refresh').addEventListener('click', () => { setText('release-notes','載入中…'); sendCmd('refresh'); });
document.getElementById('ub-dismiss').addEventListener('click', () => { document.getElementById('update-banner').classList.add('hidden'); });

document.body.addEventListener('click', e => {
  const link = e.target && e.target.closest && e.target.closest('.link-btn');
  if(link && link.dataset.url){ openUrl(link.dataset.url); return; }
  const re = e.target && e.target.closest && e.target.closest('.reinit-btn');
  if(re && re.dataset.mode){ vscode.postMessage({command:'reinit', mode:re.dataset.mode}); }
});

window.addEventListener('message', e => {
  const msg = e.data;
  if(msg.type === 'state') onState(msg);
});

function onState(msg){
  setText('current-version', 'v' + msg.currentVersion);
  const banner = document.getElementById('update-banner');
  if(msg.justUpdated){
    setText('ub-version', msg.currentVersion);
    setText('ub-from', msg.updatedFrom ? '（前版 v'+msg.updatedFrom+'）' : '');
    banner.classList.remove('hidden');
  } else {
    banner.classList.add('hidden');
  }
  const statusEl = document.getElementById('latest-status');
  const dl = document.getElementById('link-download');
  if(msg.latest){
    setText('latest-version', 'v' + msg.latest.version);
    setText('latest-date', fmt(msg.latest.publishedAt));
    document.getElementById('link-release').dataset.url = msg.latest.url || '';
    if(msg.hasUpdate){
      statusEl.textContent = '⬆ 有新版'; statusEl.classList.add('update');
      dl.dataset.url = msg.latest.url || ''; dl.classList.remove('hidden');
    } else {
      statusEl.textContent = '✅ 已是最新'; statusEl.classList.remove('update');
      dl.classList.add('hidden');
    }
    setText('release-notes', msg.latest.notes || '（無 release note）');
  } else {
    setText('latest-version', '—'); setText('latest-date', '—');
    statusEl.textContent = ''; dl.classList.add('hidden');
    setText('release-notes', '無法取得最新版本資訊，請按重新整理重試。');
  }
  const wrap = document.getElementById('drift-wrap');
  const list = document.getElementById('drift-list');
  const drifts = Array.isArray(msg.drifts) ? msg.drifts : [];
  if(drifts.length){
    wrap.classList.remove('hidden');
    const label = () => 'Codex';
    list.innerHTML = drifts.map(d =>
      '<div class="drift-row">' +
      '<span>⚠ ' + label(d.mode) + ' 模式部署於 v' + esc(d.deployedVersion) +
      '（目前 extension v' + esc(msg.currentVersion) + '）</span>' +
      '<span><button class="reinit-btn" data-mode="' + esc(d.mode) + '">重新初始化 ' + label(d.mode) + '</button></span>' +
      '</div>'
    ).join('');
  } else {
    wrap.classList.add('hidden'); list.innerHTML = '';
  }
}

function setText(id,v){ const e=document.getElementById(id); if(e) e.textContent=v; }
function fmt(s){ try{ return s ? new Date(s).toLocaleDateString('zh-TW') : '—'; }catch{ return s||'—'; } }
function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

sendCmd('requestState');
`;
