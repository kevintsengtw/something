import { EXTENSION_GITHUB_REPO } from '../constants';

/**
 * 決定版本檢查要打的 Releases API URL。
 *
 * 設定了 Gitea（`dta.giteaUrl` + `dta.giteaRepo` 皆有值）時走 Gitea API（企業/自架）；
 * 否則預設改打 GitHub 公開 repo 的 Releases API，讓使用者免設定即可收到 Extension 更新通知。
 *
 * 此函式刻意不依賴 `vscode`，以便在純 Node 單元測試中直接驗證真正執行的邏輯。
 *
 * @param giteaUrl `dta.giteaUrl` 設定值（可能為空字串或 undefined）
 * @param giteaRepo `dta.giteaRepo` 設定值（可能為空字串或 undefined）
 * @returns 要查詢 latest release 的 API URL
 */
export function resolveReleaseApiUrl(
  giteaUrl: string | undefined,
  giteaRepo: string | undefined
): string {
  return giteaUrl && giteaRepo
    ? `${giteaUrl}/api/v1/repos/${giteaRepo}/releases/latest`
    : `https://api.github.com/repos/${EXTENSION_GITHUB_REPO}/releases/latest`;
}
