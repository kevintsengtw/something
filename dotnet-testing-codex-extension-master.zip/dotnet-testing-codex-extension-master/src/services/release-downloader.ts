import * as fs   from 'fs';
import * as path from 'path';
import * as os   from 'os';
import { ShellExecutor } from '../utils/shell';
import { Logger }        from '../utils/logger';
import { extractOwnerRepo, buildReleaseApiUrl } from '../utils/release-api';

export interface SubDirMapping {
  /** Relative path inside the cloned repo, e.g. "skills" or ".github/agents" */
  subDir: string;
  targetDir: string;
  overwrite: boolean;
  /** Entry names (file or directory) to skip during copy */
  exclude?: Set<string>;
}

export class ReleaseDownloader {
  constructor(
    private readonly shell: ShellExecutor,
    private readonly logger: Logger
  ) {}

  /**
   * Extracts "owner/repo" from a repo URL（GitHub 或 Gitea）。
   * "https://github.com/owner/repo" → "owner/repo"
   * "https://gitea.company.com/owner/repo" → "owner/repo"
   */
  extractOwnerRepo(repoUrl: string): string {
    return extractOwnerRepo(repoUrl);
  }

  /** Returns the actual tag, resolving "latest" via the repo host's Releases API（GitHub / Gitea）。 */
  async resolveTag(repoUrl: string, version: string): Promise<string> {
    if (version !== 'latest') return version;
    const apiUrl = buildReleaseApiUrl(repoUrl);
    this.logger.info(`Resolving latest release tag from ${apiUrl}`);
    const res = await fetch(apiUrl, {
      headers: { 'User-Agent': 'dotnet-testing-codex-agent' },
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) throw new Error(`Release API 回應錯誤 ${res.status}：${apiUrl}`);
    const data = await res.json() as { tag_name?: string };
    if (!data.tag_name) throw new Error('Release API 回應缺少 tag_name');
    this.logger.info(`Resolved latest release tag: ${data.tag_name}`);
    return data.tag_name;
  }

  /**
   * Clones the repo at the given tag once, then copies one or more subdirectories
   * to their respective target directories. Temp clone is cleaned up after.
   */
  async downloadAndDeploy(options: {
    repoUrl: string;
    tag: string;
    mappings: SubDirMapping[];
  }): Promise<{ filesDeployed: number }> {
    const { repoUrl, tag, mappings } = options;
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dta-release-'));

    try {
      this.logger.info(`Cloning ${repoUrl} @ ${tag}`);
      const result = await this.shell.exec(
        `git clone --branch "${tag}" --depth 1 "${repoUrl}" "${tmpDir}"`,
        { timeout: 300_000 }
      );
      if (result.exitCode !== 0) {
        throw new Error(`git clone 失敗：${result.stderr || result.stdout}`);
      }

      let total = 0;
      for (const { subDir, targetDir, overwrite, exclude } of mappings) {
        const srcDir = path.join(tmpDir, ...subDir.split('/'));
        if (!fs.existsSync(srcDir)) {
          this.logger.warn(`子目錄不存在，略過：${subDir}`);
          continue;
        }
        if (overwrite && fs.existsSync(targetDir)) {
          fs.rmSync(targetDir, { recursive: true, force: true });
        }
        fs.mkdirSync(targetDir, { recursive: true });
        this.copyDirRecursive(srcDir, targetDir, exclude);
        const count = this.countFiles(targetDir, exclude);
        this.logger.info(`Deployed ${count} files to ${targetDir}`);
        total += count;
      }

      return { filesDeployed: total };
    } finally {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  }

  private copyDirRecursive(src: string, dest: string, exclude?: Set<string>): void {
    for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
      if (entry.name === '.gitkeep' || exclude?.has(entry.name)) continue;
      const srcPath  = path.join(src,  entry.name);
      const destPath = path.join(dest, entry.name);
      if (entry.isDirectory()) {
        fs.mkdirSync(destPath, { recursive: true });
        this.copyDirRecursive(srcPath, destPath, exclude);
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    }
  }

  countFiles(dirPath: string, exclude?: Set<string>): number {
    if (!fs.existsSync(dirPath)) return 0;
    let count = 0;
    for (const entry of fs.readdirSync(dirPath, { withFileTypes: true })) {
      if (exclude?.has(entry.name)) continue;
      if (entry.isDirectory()) count += this.countFiles(path.join(dirPath, entry.name), exclude);
      else if (entry.name !== '.gitkeep') count++;
    }
    return count;
  }
}
