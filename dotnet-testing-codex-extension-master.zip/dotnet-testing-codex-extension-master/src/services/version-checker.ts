import * as vscode from 'vscode';
import * as https from 'https';
import * as http from 'http';
import { Logger } from '../utils/logger';
import { UpdateInfo, LatestRelease } from '../types';
import {
  STATE_IGNORED_VERSION,
  VERSION_CHECK_TIMEOUT_MS,
  CTX_HAS_UPDATE,
} from '../constants';
import { resolveReleaseApiUrl } from './version-check-url';
import { isNewerVersion } from '../utils/semver';

interface GiteaRelease {
  tag_name: string;
  name: string;
  html_url: string;
  body?: string;
  published_at?: string;
  assets: Array<{
    name: string;
    browser_download_url: string;
  }>;
}

export class VersionChecker {
  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly logger: Logger
  ) {}

  async check(): Promise<UpdateInfo | null> {
    const config = vscode.workspace.getConfiguration();
    const giteaUrl = config.get<string>('dta.giteaUrl');
    const giteaRepo = config.get<string>('dta.giteaRepo');

    // 設定了 Gitea（企業/自架）時走 Gitea API；否則預設改打 GitHub 公開 repo Releases，
    // 讓使用者免設定即可收到 Extension 更新通知。
    const apiUrl = resolveReleaseApiUrl(giteaUrl, giteaRepo);

    try {
      const release = await this.fetchJson<GiteaRelease>(apiUrl);
      const latestVersion = release.tag_name.replace(/^v/, '');
      const currentVersion = this.context.extension.packageJSON.version as string;

      if (!this.isNewer(latestVersion, currentVersion)) {
        this.logger.debug(`Version up-to-date: ${currentVersion}`);
        return null;
      }

      const vsixAsset = release.assets.find((a) => a.name.endsWith('.vsix'));
      return {
        currentVersion,
        latestVersion,
        releaseUrl: release.html_url,
        downloadUrl: vsixAsset?.browser_download_url ?? release.html_url,
      };
    } catch (err) {
      this.logger.debug(`Version check failed (silent): ${err}`);
      return null;
    }
  }

  /**
   * 取得最新 release 資訊（不論是否較新都回傳），供「版本資訊」面板顯示。
   * 與 check() 不同：check() 只在有新版時回 UpdateInfo。失敗回 null（靜默）。
   */
  async fetchLatestRelease(): Promise<LatestRelease | null> {
    const config = vscode.workspace.getConfiguration();
    const giteaUrl = config.get<string>('dta.giteaUrl');
    const giteaRepo = config.get<string>('dta.giteaRepo');
    const apiUrl = resolveReleaseApiUrl(giteaUrl, giteaRepo);

    try {
      const release = await this.fetchJson<GiteaRelease>(apiUrl);
      return {
        version: release.tag_name.replace(/^v/, ''),
        notes: release.body ?? '',
        publishedAt: release.published_at ?? '',
        url: release.html_url,
      };
    } catch (err) {
      this.logger.debug(`fetchLatestRelease failed (silent): ${err}`);
      return null;
    }
  }

  async notifyIfNeeded(updateInfo: UpdateInfo): Promise<void> {
    const ignoredVersion = this.context.globalState.get<string>(STATE_IGNORED_VERSION);
    if (ignoredVersion === updateInfo.latestVersion) {
      return;
    }

    await vscode.commands.executeCommand('setContext', CTX_HAS_UPDATE, true);

    const action = await vscode.window.showInformationMessage(
      `.NET Testing Agent 有新版本可用！v${updateInfo.currentVersion} → v${updateInfo.latestVersion}`,
      '前往下載',
      '本次略過',
      '不再提醒此版本'
    );

    if (action === '前往下載') {
      await vscode.env.openExternal(vscode.Uri.parse(updateInfo.releaseUrl));
    } else if (action === '不再提醒此版本') {
      await this.setIgnoredVersion(updateInfo.latestVersion);
    }
  }

  async setIgnoredVersion(version: string): Promise<void> {
    await this.context.globalState.update(STATE_IGNORED_VERSION, version);
  }

  private isNewer(latest: string, current: string): boolean {
    return isNewerVersion(latest, current);
  }

  private fetchJson<T>(url: string): Promise<T> {
    return new Promise((resolve, reject) => {
      const lib = url.startsWith('https') ? https : http;
      const req = lib.get(url, { headers: { 'User-Agent': 'dotnet-testing-agent-vscode' } }, (res) => {
        let body = '';
        res.on('data', (chunk) => (body += chunk));
        res.on('end', () => {
          try {
            resolve(JSON.parse(body) as T);
          } catch (e) {
            reject(new Error(`Invalid JSON response: ${body.substring(0, 100)}`));
          }
        });
      });
      req.setTimeout(VERSION_CHECK_TIMEOUT_MS, () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });
      req.on('error', reject);
    });
  }
}
