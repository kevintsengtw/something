import * as fs   from 'fs';
import * as path from 'path';
// 只作型別使用（不在模組載入時 require('vscode')），讓單元測試可在純 Node 執行。
import type * as vscode from 'vscode';
import { Logger } from '../utils/logger';
import { CodexManifest } from '../types';
import {
  WS_CODEX_SKILLS_PATH,
  WS_CODEX_AGENTS_PATH,
  WS_CODEX_SCRIPTS_PATH,
  WS_CODEX_CONFIG_PATH,
  CODEX_MANIFEST_PATH,
  BUNDLED_CODEX_DIR,
  BUNDLED_SHARED_SKILLS_DIR,
  BUNDLED_SHARED_VERSION_FILE,
  WS_MANIFEST_DIR,
  DEFAULT_SKILLS_REPO,
  DEFAULT_CODEX_ORCH_REPO,
} from '../constants';
import { copyDirRecursive, countDirs } from '../utils/file-deploy';
import { mergeCodexConfigToml } from '../utils/toml-merge';
import { ReleaseDownloader } from './release-downloader';

const SKILLS_EXCLUDE = new Set(['skill-creator-advanced', 'README.md']);

/**
 * 讀取 VS Code 設定值（trim 後非空才回傳）。
 * 使用 lazy require('vscode') 而非 top-level import，讓本模組在純 Node 單元測試中
 * 載入時不強制依賴 vscode；測試環境取不到設定時回傳 undefined，由呼叫端 fallback 預設值。
 */
function readSetting(key: string): string | undefined {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const vscode = require('vscode') as typeof import('vscode');
    return vscode.workspace.getConfiguration().get<string>(key)?.trim() || undefined;
  } catch {
    return undefined;
  }
}

/** Counts `.toml` files (Codex agent definitions) directly under a directory. */
function countTomlFiles(dirPath: string): number {
  if (!fs.existsSync(dirPath)) return 0;
  return fs.readdirSync(dirPath).filter((f) => f.endsWith('.toml')).length;
}

export class CodexInstaller {
  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly logger: Logger,
    private readonly downloader: ReleaseDownloader
  ) {}

  getBundledPath(): string {
    return this.context.asAbsolutePath(path.join('bundled', BUNDLED_CODEX_DIR));
  }

  // ── Configurable sources ──────────────────────────────────────────────────
  // 來源 repo 可透過設定覆寫（改指向公司內部 Gitea repo）；留空則使用內建預設值。

  /** Skills 來源 repo URL（dta.codex.skillsRepo，預設 DEFAULT_SKILLS_REPO）。 */
  private get skillsRepo(): string {
    return readSetting('dta.codex.skillsRepo') || DEFAULT_SKILLS_REPO;
  }

  /** Codex orchestration 來源 repo URL（dta.codex.orchRepo，預設 DEFAULT_CODEX_ORCH_REPO）。 */
  private get orchRepo(): string {
    return readSetting('dta.codex.orchRepo') || DEFAULT_CODEX_ORCH_REPO;
  }

  /** 部署時使用的版本 tag（dta.codex.skillsVersion，預設 'latest'）。 */
  private get skillsVersion(): string {
    return readSetting('dta.codex.skillsVersion') || 'latest';
  }

  /** Shared skills version（來自 bundled/shared/version.json）。 */
  getBundledVersion(): string {
    try {
      const versionFile = this.context.asAbsolutePath(
        path.join('bundled', BUNDLED_SHARED_VERSION_FILE)
      );
      const data = JSON.parse(fs.readFileSync(versionFile, 'utf-8')) as { skills?: { version?: string } };
      return data.skills?.version ?? '0.0.0';
    } catch {
      return '0.0.0';
    }
  }

  getCodexOrchVersion(): string {
    try {
      const versionFile = this.context.asAbsolutePath(
        path.join('bundled', BUNDLED_CODEX_DIR, 'version.json')
      );
      const data = JSON.parse(fs.readFileSync(versionFile, 'utf-8')) as {
        orchestration?: { version?: string; commit?: string };
      };
      if (data.orchestration?.version) return data.orchestration.version;
      if (data.orchestration?.commit)  return data.orchestration.commit.substring(0, 7);
      return '0.0.0';
    } catch {
      return '0.0.0';
    }
  }

  // ── Online version queries ────────────────────────────────────────────────

  async getLatestOnlineSkillsVersion(): Promise<string | null> {
    try {
      // 更新檢查一律查詢遠端最新 tag（不受 skillsVersion 釘選影響）。
      return await this.downloader.resolveTag(this.skillsRepo, 'latest');
    } catch {
      return null;
    }
  }

  async getLatestOnlineOrchVersion(): Promise<string | null> {
    try {
      return await this.downloader.resolveTag(this.orchRepo, 'latest');
    } catch {
      return null;
    }
  }

  // ── Bundled deploy ────────────────────────────────────────────────────────

  async deploySkills(workspacePath: string): Promise<{ count: number; version: string; orchVersion: string }> {
    const sharedSkills = this.context.asAbsolutePath(path.join('bundled', BUNDLED_SHARED_SKILLS_DIR));
    const targetPath   = path.join(workspacePath, WS_CODEX_SKILLS_PATH);

    if (!fs.existsSync(sharedSkills)) {
      throw new Error('Bundled shared skills 目錄不存在，請先執行 npm run sync-bundled。');
    }

    if (fs.existsSync(targetPath)) {
      fs.rmSync(targetPath, { recursive: true, force: true });
    }
    fs.mkdirSync(targetPath, { recursive: true });

    copyDirRecursive(sharedSkills, targetPath);

    const codexSpecificSkills = path.join(this.getBundledPath(), 'skills');
    if (fs.existsSync(codexSpecificSkills)) {
      copyDirRecursive(codexSpecificSkills, targetPath);
    }

    const count       = countDirs(targetPath);
    const version     = this.getBundledVersion();
    const orchVersion = this.getCodexOrchVersion();
    this.logger.info(`Codex skills deployed from bundled ${version}: ${count} skill dirs`);
    return { count, version, orchVersion };
  }

  async deployAgents(workspacePath: string): Promise<{ count: number; version: string }> {
    const bundledAgents = path.join(this.getBundledPath(), 'agents');
    const targetPath    = path.join(workspacePath, WS_CODEX_AGENTS_PATH);

    if (!fs.existsSync(bundledAgents)) {
      throw new Error('Bundled Codex agents 目錄不存在，請先執行 npm run sync-bundled-codex。');
    }

    if (fs.existsSync(targetPath)) {
      fs.rmSync(targetPath, { recursive: true, force: true });
    }
    fs.mkdirSync(targetPath, { recursive: true });
    copyDirRecursive(bundledAgents, targetPath);

    const count   = countTomlFiles(targetPath);
    const version = this.getCodexOrchVersion();
    this.logger.info(`Codex agents deployed from bundled (orch) ${version}: ${count} toml files`);
    return { count, version };
  }

  /**
   * Deploy `.codex/config.toml` by gap-filling from the bundled copy.
   *
   * Unlike Claude's hooks (which inject into settings.json), Codex ships a
   * single platform config file. We never clobber a user's existing config:
   * missing keys are filled in, existing values are preserved.
   */
  async deployConfig(workspacePath: string): Promise<{ installed: boolean }> {
    const bundledConfig = path.join(this.getBundledPath(), 'config.toml');
    const targetPath    = path.join(workspacePath, WS_CODEX_CONFIG_PATH);

    if (!fs.existsSync(bundledConfig)) {
      this.logger.warn(
        'Bundled Codex config.toml 不存在，略過 config 部署，請執行 npm run sync-bundled-codex。'
      );
      return { installed: false };
    }

    const bundledText  = fs.readFileSync(bundledConfig, 'utf-8');
    const existingText = fs.existsSync(targetPath) ? fs.readFileSync(targetPath, 'utf-8') : null;
    const merged       = mergeCodexConfigToml(bundledText, existingText);

    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
    fs.writeFileSync(targetPath, merged, 'utf-8');
    this.logger.info(`Codex config.toml deployed to ${targetPath} (${existingText ? 'merged' : 'fresh'})`);
    return { installed: true };
  }

  /**
   * Deploy the token-usage estimation script (`.codex/scripts/`) from bundled.
   * Tolerant of a missing bundled source (mirrors Claude's deployScripts).
   */
  async deployScripts(workspacePath: string): Promise<{ installed: boolean }> {
    const bundledScripts = path.join(this.getBundledPath(), 'scripts');
    const targetPath     = path.join(workspacePath, WS_CODEX_SCRIPTS_PATH);

    if (!fs.existsSync(bundledScripts)) {
      this.logger.warn(
        'Bundled Codex scripts 目錄不存在，略過 scripts 部署（token 估算功能將無法使用，請執行 npm run sync-bundled-codex）。'
      );
      return { installed: false };
    }

    if (fs.existsSync(targetPath)) {
      fs.rmSync(targetPath, { recursive: true, force: true });
    }
    fs.mkdirSync(targetPath, { recursive: true });
    copyDirRecursive(bundledScripts, targetPath);

    this.logger.info(`Codex scripts deployed to ${targetPath}`);
    return { installed: true };
  }

  // ── Online deploy ─────────────────────────────────────────────────────────

  /** Deploy shared skills from release + merge codex-specific skills on top. */
  async deploySkillsFromRelease(workspacePath: string): Promise<{ count: number; version: string; orchVersion: string }> {
    const targetPath = path.join(workspacePath, WS_CODEX_SKILLS_PATH);

    const skillsTag = await this.downloader.resolveTag(this.skillsRepo, this.skillsVersion);
    await this.downloader.downloadAndDeploy({
      repoUrl: this.skillsRepo,
      tag: skillsTag,
      mappings: [{ subDir: 'skills', targetDir: targetPath, overwrite: true, exclude: SKILLS_EXCLUDE }],
    });

    const orchTag = await this.downloader.resolveTag(this.orchRepo, 'latest');
    await this.downloader.downloadAndDeploy({
      repoUrl: this.orchRepo,
      tag: orchTag,
      mappings: [{ subDir: '.codex/skills', targetDir: targetPath, overwrite: false }],
    });

    const count = countDirs(targetPath);
    this.logger.info(`Codex skills deployed from release ${skillsTag} (orch ${orchTag}): ${count} dirs`);
    return { count, version: skillsTag, orchVersion: orchTag };
  }

  /**
   * Deploy agents + scripts from CODEX_ORCH_GITHUB_REPO release.
   *
   * config.toml is NOT fetched online — ReleaseDownloader only copies whole
   * subdirectories, and the config is small/stable. After the release deploy we
   * re-run deployConfig() to gap-fill from the bundled config.
   */
  async deployOrchFromRelease(workspacePath: string): Promise<{ version: string; agentsCount: number }> {
    const agentsPath  = path.join(workspacePath, WS_CODEX_AGENTS_PATH);
    const skillsPath  = path.join(workspacePath, WS_CODEX_SKILLS_PATH);
    const scriptsPath = path.join(workspacePath, WS_CODEX_SCRIPTS_PATH);

    const tag = await this.downloader.resolveTag(this.orchRepo, 'latest');
    await this.downloader.downloadAndDeploy({
      repoUrl: this.orchRepo,
      tag,
      mappings: [
        { subDir: '.codex/agents',  targetDir: agentsPath,  overwrite: true },
        { subDir: '.codex/scripts', targetDir: scriptsPath, overwrite: true },
        { subDir: '.codex/skills',  targetDir: skillsPath,  overwrite: false },
      ],
    });
    await this.deployConfig(workspacePath);

    const agentsCount = countTomlFiles(agentsPath);
    this.logger.info(`Codex orch deployed from release ${tag}: ${agentsCount} agents`);
    return { version: tag, agentsCount };
  }

  // ── Manifest ──────────────────────────────────────────────────────────────

  writeManifest(workspacePath: string, manifest: CodexManifest): void {
    const dirPath  = path.join(workspacePath, WS_MANIFEST_DIR);
    const filePath = path.join(workspacePath, CODEX_MANIFEST_PATH);
    fs.mkdirSync(dirPath, { recursive: true });
    fs.writeFileSync(filePath, JSON.stringify(manifest, null, 2), 'utf-8');
    this.logger.info(`Codex manifest written to ${filePath}`);
  }

  readManifest(workspacePath: string): CodexManifest | null {
    const filePath = path.join(workspacePath, CODEX_MANIFEST_PATH);
    try {
      const raw = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(raw) as CodexManifest;
    } catch {
      return null;
    }
  }

  isInitialized(workspacePath: string): boolean {
    const manifest = this.readManifest(workspacePath);
    return manifest !== null && !!manifest.extensionVersion;
  }
}
