# Changelog

本專案（Codex 模式獨立版）遵循 [Keep a Changelog](https://keepachangelog.com/) 與 [Semantic Versioning](https://semver.org/)。

## [0.1.0] - 初始版本

### 新增

- 由多模式版本 `dotnet-testing-vscode-extensions` 抽離出 **Codex 模式獨立版**（原始碼完全獨立）。
- Codex 初始化與診斷：`dta.codex.init`、`dta.codex.doctor`。
- 側邊欄面板：版本資訊（`dta.about`）+ Codex 模式面板（`dta.codex.webview`）。
- **來源可設定**：新增 `dta.codex.skillsRepo` / `dta.codex.orchRepo`，可將 skills / orchestration-codex 來源指向公司內部 Gitea。
- **GitHub / Gitea 雙相容**的 Release API 解析（`src/utils/release-api.ts` 的 `buildReleaseApiUrl` / `extractOwnerRepo`），由 `ReleaseDownloader` 與 `CodexWebviewProvider` 共用。
- `sync-bundled.mjs` / `sync-bundled-codex.mjs` 支援 `--skills-repo` / `--orch-repo` 指向 Gitea。

### 移除

- 移除 Copilot 與 Claude 模式、RAG 索引、MCP server provider 等所有非 Codex 功能與程式碼。

### 修正

- `dta.codex.skillsVersion` 設定現在會實際套用於 skills 部署（先前宣告但未被讀取）。
- `getBundledVersion()` 改讀 `bundled/shared/version.json`（先前借用 Copilot 的 `bundled/copilot/version.json`）。
