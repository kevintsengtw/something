import * as assert from 'assert';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { CodexInstaller } from '../../src/services/codex-installer';
import { CodexManifest } from '../../src/types';

const stubLogger = {
  info: () => {},
  warn: () => {},
  error: () => {},
  debug: () => {},
} as any;

const BUNDLED_CONFIG = `# Codex workspace configuration.
personality = "friendly"

[features]
multi_agent = true
hooks = true

[agents]
max_depth = 1
max_threads = 6
job_max_runtime_seconds = 1800
`;

/**
 * Stub ReleaseDownloader — simulates online deploys by creating dirs/files
 * in the target directory (no network access).
 */
function makeStubDownloader(opts: {
  resolvedTag?: string;
  createEntries?: { name: string; isDir: boolean }[];
} = {}) {
  const tag = opts.resolvedTag ?? 'v1.2.3';
  const entries = opts.createEntries ?? [];
  return {
    resolveTag: async (_repoUrl: string, _version: string) => tag,
    downloadAndDeploy: async (options: {
      repoUrl: string;
      tag: string;
      mappings: Array<{ targetDir: string; overwrite: boolean }>;
    }) => {
      let total = 0;
      for (const { targetDir, overwrite } of options.mappings) {
        if (overwrite && fs.existsSync(targetDir)) {
          fs.rmSync(targetDir, { recursive: true, force: true });
        }
        fs.mkdirSync(targetDir, { recursive: true });
        for (const entry of entries) {
          if (entry.isDir) {
            fs.mkdirSync(path.join(targetDir, entry.name), { recursive: true });
            fs.writeFileSync(path.join(targetDir, entry.name, 'SKILL.md'), `# ${entry.name}`);
          } else {
            fs.writeFileSync(path.join(targetDir, entry.name), `# ${entry.name}`);
          }
          total++;
        }
      }
      return { filesDeployed: total };
    },
  } as any;
}

const stubDownloader = makeStubDownloader();

function makeManifest(overrides: Partial<CodexManifest> = {}): CodexManifest {
  return {
    extensionVersion: '0.1.2',
    installedAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z',
    skills: { version: '2.4.1', orchVersion: 'v1.0.1', count: 34, path: '.codex/skills' },
    agents: { version: 'v1.0.1', count: 16, path: '.codex/agents' },
    config: { installed: true, path: '.codex/config.toml' },
    scripts: { installed: true, path: '.codex/scripts' },
    ...overrides,
  };
}

/**
 * Build a fake extension root with the bundled structure expected by CodexInstaller.
 * Shared skills live under bundled/shared/skills/. Codex content lives under
 * bundled/codex/ (agents .toml, scripts, config.toml, optional skills).
 */
function makeFakeBundled(
  root: string,
  opts: {
    skills?: string[];
    agents?: string[];
    codexSkills?: string[];
    scripts?: string[];
    config?: string | null;
  } = {}
): void {
  // shared skills — each skill is a directory containing SKILL.md
  const sharedSkillsDir = path.join(root, 'bundled', 'shared', 'skills');
  fs.mkdirSync(sharedSkillsDir, { recursive: true });
  for (const name of opts.skills ?? ['skill-a', 'skill-b']) {
    const skillDir = path.join(sharedSkillsDir, name);
    fs.mkdirSync(skillDir, { recursive: true });
    fs.writeFileSync(path.join(skillDir, 'SKILL.md'), `# ${name}`);
  }

  // shared version.json (getBundledVersion reads from here)
  const sharedDir = path.join(root, 'bundled', 'shared');
  fs.mkdirSync(sharedDir, { recursive: true });
  fs.writeFileSync(
    path.join(sharedDir, 'version.json'),
    JSON.stringify({ syncedAt: '2026-01-01T00:00:00Z', skills: { version: '2.4.1' } }),
    'utf-8'
  );

  // codex-specific content
  const codexBase = path.join(root, 'bundled', 'codex');
  const agentsDir = path.join(codexBase, 'agents');
  fs.mkdirSync(agentsDir, { recursive: true });

  // codex version.json (getCodexOrchVersion reads from here)
  fs.writeFileSync(
    path.join(codexBase, 'version.json'),
    JSON.stringify({ syncedAt: '2026-01-01T00:00:00Z', orchestration: { version: 'v1.0.1', commit: 'abc1234def5678', branch: 'main', variant: 'codex' } }),
    'utf-8'
  );

  for (const name of opts.agents ?? ['dotnet-testing-analyzer.toml', 'dotnet-testing-writer.toml']) {
    fs.writeFileSync(path.join(agentsDir, name), `# ${name}`);
  }

  // config.toml (single file). pass null to omit.
  if (opts.config !== null) {
    fs.writeFileSync(path.join(codexBase, 'config.toml'), opts.config ?? BUNDLED_CONFIG, 'utf-8');
  }

  // optional codex-specific orchestrator skills — directories
  if (opts.codexSkills && opts.codexSkills.length > 0) {
    const codexSkillsDir = path.join(codexBase, 'skills');
    fs.mkdirSync(codexSkillsDir, { recursive: true });
    for (const name of opts.codexSkills) {
      const skillDir = path.join(codexSkillsDir, name);
      fs.mkdirSync(skillDir, { recursive: true });
      fs.writeFileSync(path.join(skillDir, 'SKILL.md'), `# ${name}`);
    }
  }

  // optional token estimation scripts — flat under scripts/
  if (opts.scripts && opts.scripts.length > 0) {
    const scriptsDir = path.join(codexBase, 'scripts');
    fs.mkdirSync(scriptsDir, { recursive: true });
    for (const name of opts.scripts) {
      fs.writeFileSync(path.join(scriptsDir, name), `// ${name}`);
    }
  }
}

suite('CodexInstaller', () => {
  let tmpDir: string;
  let workspaceDir: string;
  let extensionRoot: string;
  let installer: CodexInstaller;

  setup(() => {
    tmpDir       = fs.mkdtempSync(path.join(os.tmpdir(), 'dta-codex-installer-test-'));
    workspaceDir = path.join(tmpDir, 'workspace');
    extensionRoot = path.join(tmpDir, 'extension');
    fs.mkdirSync(workspaceDir, { recursive: true });
    fs.mkdirSync(extensionRoot, { recursive: true });

    const stubContext = {
      asAbsolutePath: (relativePath: string) => path.join(extensionRoot, relativePath),
      extension: { packageJSON: { version: '0.1.2' } },
    } as any;

    installer = new CodexInstaller(stubContext, stubLogger, stubDownloader);
  });

  teardown(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // ── readManifest ─────────────────────────────────────────────────────────

  suite('readManifest', () => {
    test('returns null when manifest file does not exist', () => {
      assert.strictEqual(installer.readManifest(workspaceDir), null);
    });

    test('returns parsed CodexManifest when file exists', () => {
      installer.writeManifest(workspaceDir, makeManifest());
      const result = installer.readManifest(workspaceDir);
      assert.ok(result !== null);
      assert.strictEqual(result.extensionVersion, '0.1.2');
      assert.strictEqual(result.agents.count, 16);
      assert.strictEqual(result.config.installed, true);
      assert.strictEqual(result.config.path, '.codex/config.toml');
      assert.strictEqual(result.scripts.installed, true);
    });

    test('returns null when manifest contains invalid JSON', () => {
      const manifestDir = path.join(workspaceDir, '.dotnet-testing-agent');
      fs.mkdirSync(manifestDir, { recursive: true });
      fs.writeFileSync(path.join(manifestDir, 'manifest-codex.json'), 'not valid json', 'utf-8');
      assert.strictEqual(installer.readManifest(workspaceDir), null);
    });
  });

  // ── writeManifest ────────────────────────────────────────────────────────

  suite('writeManifest', () => {
    test('creates .dotnet-testing-agent directory and manifest-codex.json', () => {
      installer.writeManifest(workspaceDir, makeManifest());
      const filePath = path.join(workspaceDir, '.dotnet-testing-agent', 'manifest-codex.json');
      assert.ok(fs.existsSync(filePath));
    });

    test('overwrites existing manifest', () => {
      installer.writeManifest(workspaceDir, makeManifest({ extensionVersion: '0.1.0' }));
      installer.writeManifest(workspaceDir, makeManifest({ extensionVersion: '0.2.0' }));
      assert.strictEqual(installer.readManifest(workspaceDir)?.extensionVersion, '0.2.0');
    });
  });

  // ── isInitialized ────────────────────────────────────────────────────────

  suite('isInitialized', () => {
    test('returns false when manifest does not exist', () => {
      assert.strictEqual(installer.isInitialized(workspaceDir), false);
    });

    test('returns true when valid manifest exists', () => {
      installer.writeManifest(workspaceDir, makeManifest());
      assert.strictEqual(installer.isInitialized(workspaceDir), true);
    });

    test('returns false when manifest has empty extensionVersion', () => {
      installer.writeManifest(workspaceDir, makeManifest({ extensionVersion: '' }));
      assert.strictEqual(installer.isInitialized(workspaceDir), false);
    });
  });

  // ── getBundledVersion / getCodexOrchVersion ───────────────────────────────

  suite('getBundledVersion', () => {
    test('returns shared skills version from shared version.json', () => {
      makeFakeBundled(extensionRoot);
      assert.strictEqual(installer.getBundledVersion(), '2.4.1');
    });

    test('returns 0.0.0 when version.json does not exist', () => {
      assert.strictEqual(installer.getBundledVersion(), '0.0.0');
    });
  });

  suite('getCodexOrchVersion', () => {
    test('returns version field from codex version.json', () => {
      makeFakeBundled(extensionRoot);
      assert.strictEqual(installer.getCodexOrchVersion(), 'v1.0.1');
    });

    test('falls back to short commit when version field absent', () => {
      const codexDir = path.join(extensionRoot, 'bundled', 'codex');
      fs.mkdirSync(codexDir, { recursive: true });
      fs.writeFileSync(
        path.join(codexDir, 'version.json'),
        JSON.stringify({ orchestration: { commit: 'deadbeef12345678' } }),
        'utf-8'
      );
      assert.strictEqual(installer.getCodexOrchVersion(), 'deadbee');
    });

    test('returns 0.0.0 when codex version.json does not exist', () => {
      assert.strictEqual(installer.getCodexOrchVersion(), '0.0.0');
    });
  });

  // ── deploySkills ───────────────────────────────────────────────────────────

  suite('deploySkills', () => {
    test('copies skill dirs to .codex/skills/', async () => {
      makeFakeBundled(extensionRoot, { skills: ['skill-a', 'skill-b', 'skill-c'] });
      const result = await installer.deploySkills(workspaceDir);
      assert.strictEqual(result.count, 3);
      assert.strictEqual(result.orchVersion, 'v1.0.1');
      assert.ok(fs.existsSync(path.join(workspaceDir, '.codex', 'skills', 'skill-a')));
    });

    test('overwrites existing .codex/skills/ directory', async () => {
      const skillsDir = path.join(workspaceDir, '.codex', 'skills');
      fs.mkdirSync(path.join(skillsDir, 'old-skill'), { recursive: true });
      makeFakeBundled(extensionRoot, { skills: ['new-skill'] });
      await installer.deploySkills(workspaceDir);
      assert.ok(!fs.existsSync(path.join(skillsDir, 'old-skill')));
      assert.ok(fs.existsSync(path.join(skillsDir, 'new-skill')));
    });

    test('throws when bundled shared skills directory does not exist', async () => {
      await assert.rejects(
        () => installer.deploySkills(workspaceDir),
        /Bundled shared skills 目錄不存在/
      );
    });

    test('merges codex-specific skills when bundled/codex/skills/ exists', async () => {
      makeFakeBundled(extensionRoot, { skills: ['shared-a', 'shared-b'], codexSkills: ['orchestrator-unit'] });
      const result = await installer.deploySkills(workspaceDir);
      assert.strictEqual(result.count, 3);
      assert.ok(fs.existsSync(path.join(workspaceDir, '.codex', 'skills', 'orchestrator-unit')));
    });
  });

  // ── deployAgents ────────────────────────────────────────────────────────────

  suite('deployAgents', () => {
    test('copies .toml agents to .codex/agents/ and counts only .toml', async () => {
      makeFakeBundled(extensionRoot, { agents: ['a.toml', 'b.toml', 'README.md'] });
      const result = await installer.deployAgents(workspaceDir);
      assert.strictEqual(result.count, 2, 'only .toml files counted');
      assert.ok(fs.existsSync(path.join(workspaceDir, '.codex', 'agents', 'a.toml')));
      assert.ok(fs.existsSync(path.join(workspaceDir, '.codex', 'agents', 'README.md')), 'non-toml still copied');
    });

    test('throws when bundled agents directory does not exist', async () => {
      await assert.rejects(
        () => installer.deployAgents(workspaceDir),
        /Bundled Codex agents 目錄不存在/
      );
    });
  });

  // ── deployConfig（補差異合併）────────────────────────────────────────────────

  suite('deployConfig', () => {
    test('writes config.toml verbatim when workspace has none', async () => {
      makeFakeBundled(extensionRoot);
      const result = await installer.deployConfig(workspaceDir);
      assert.strictEqual(result.installed, true);
      const written = fs.readFileSync(path.join(workspaceDir, '.codex', 'config.toml'), 'utf-8');
      assert.strictEqual(written, BUNDLED_CONFIG, 'fresh deploy is verbatim copy');
    });

    test('gap-fills existing config without overwriting user values', async () => {
      makeFakeBundled(extensionRoot);
      const configPath = path.join(workspaceDir, '.codex', 'config.toml');
      fs.mkdirSync(path.dirname(configPath), { recursive: true });
      fs.writeFileSync(configPath, `personality = "blunt"\n\n[agents]\nmax_threads = 12\n`, 'utf-8');

      const result = await installer.deployConfig(workspaceDir);

      assert.strictEqual(result.installed, true);
      const merged = fs.readFileSync(configPath, 'utf-8');
      assert.ok(merged.includes('personality = "blunt"'), 'user value preserved');
      assert.ok(merged.includes('max_threads = 12'), 'user value preserved');
      assert.ok(merged.includes('max_depth = 1'), 'missing key filled');
      assert.ok(merged.includes('multi_agent = true'), 'missing [features] table appended');
      assert.ok(!merged.includes('personality = "friendly"'), 'bundled value not forced');
    });

    test('returns installed:false when bundled config.toml missing', async () => {
      makeFakeBundled(extensionRoot, { config: null });
      const result = await installer.deployConfig(workspaceDir);
      assert.strictEqual(result.installed, false);
      assert.ok(!fs.existsSync(path.join(workspaceDir, '.codex', 'config.toml')));
    });
  });

  // ── deployScripts ────────────────────────────────────────────────────────────

  suite('deployScripts', () => {
    test('copies estimate-token-usage.mjs to .codex/scripts/ and returns installed:true', async () => {
      makeFakeBundled(extensionRoot, { scripts: ['estimate-token-usage.mjs'] });
      const result = await installer.deployScripts(workspaceDir);
      assert.strictEqual(result.installed, true);
      assert.ok(fs.existsSync(path.join(workspaceDir, '.codex', 'scripts', 'estimate-token-usage.mjs')));
    });

    test('returns installed:false and does not create dir when bundled scripts missing', async () => {
      makeFakeBundled(extensionRoot); // no scripts
      const result = await installer.deployScripts(workspaceDir);
      assert.strictEqual(result.installed, false);
      assert.ok(!fs.existsSync(path.join(workspaceDir, '.codex', 'scripts')));
    });

    test('replaces stale scripts content on redeploy', async () => {
      const scriptsDir = path.join(workspaceDir, '.codex', 'scripts');
      fs.mkdirSync(scriptsDir, { recursive: true });
      fs.writeFileSync(path.join(scriptsDir, 'stale.mjs'), '// old');
      makeFakeBundled(extensionRoot, { scripts: ['estimate-token-usage.mjs'] });
      await installer.deployScripts(workspaceDir);
      assert.ok(!fs.existsSync(path.join(scriptsDir, 'stale.mjs')), 'stale file removed');
      assert.ok(fs.existsSync(path.join(scriptsDir, 'estimate-token-usage.mjs')));
    });
  });

  // ── online version queries ────────────────────────────────────────────────

  suite('getLatestOnlineSkillsVersion / getLatestOnlineOrchVersion', () => {
    test('returns tag from downloader when online', async () => {
      const local = new CodexInstaller(
        { asAbsolutePath: (p: string) => path.join(extensionRoot, p), extension: { packageJSON: { version: '0.1.2' } } } as any,
        stubLogger,
        makeStubDownloader({ resolvedTag: 'v3.0.0' })
      );
      assert.strictEqual(await local.getLatestOnlineSkillsVersion(), 'v3.0.0');
      assert.strictEqual(await local.getLatestOnlineOrchVersion(), 'v3.0.0');
    });

    test('returns null when downloader throws', async () => {
      const failDownloader = {
        resolveTag: async () => { throw new Error('network error'); },
        downloadAndDeploy: async () => ({ filesDeployed: 0 }),
      } as any;
      const local = new CodexInstaller(
        { asAbsolutePath: (p: string) => path.join(extensionRoot, p), extension: { packageJSON: { version: '0.1.2' } } } as any,
        stubLogger,
        failDownloader
      );
      assert.strictEqual(await local.getLatestOnlineSkillsVersion(), null);
      assert.strictEqual(await local.getLatestOnlineOrchVersion(), null);
    });
  });

  // ── deploySkillsFromRelease ─────────────────────────────────────────────────

  suite('deploySkillsFromRelease', () => {
    test('deploys skill dirs to .codex/skills/ and returns version info', async () => {
      const dl = makeStubDownloader({
        resolvedTag: 'v2.5.0',
        createEntries: [{ name: 'skill-a', isDir: true }, { name: 'skill-b', isDir: true }],
      });
      const local = new CodexInstaller(
        { asAbsolutePath: (p: string) => path.join(extensionRoot, p), extension: { packageJSON: { version: '0.1.2' } } } as any,
        stubLogger,
        dl
      );
      const result = await local.deploySkillsFromRelease(workspaceDir);
      assert.ok(fs.existsSync(path.join(workspaceDir, '.codex', 'skills')));
      assert.strictEqual(result.version, 'v2.5.0');
      assert.strictEqual(result.orchVersion, 'v2.5.0');
    });
  });

  // ── deployOrchFromRelease ────────────────────────────────────────────────────

  suite('deployOrchFromRelease', () => {
    test('deploys agents from release and merges config from bundled', async () => {
      makeFakeBundled(extensionRoot); // bundled config available for the post-merge step
      const dl = makeStubDownloader({
        resolvedTag: 'v1.5.0',
        createEntries: [{ name: 'a.toml', isDir: false }, { name: 'b.toml', isDir: false }],
      });
      const local = new CodexInstaller(
        { asAbsolutePath: (p: string) => path.join(extensionRoot, p), extension: { packageJSON: { version: '0.1.2' } } } as any,
        stubLogger,
        dl
      );

      const result = await local.deployOrchFromRelease(workspaceDir);

      assert.strictEqual(result.version, 'v1.5.0');
      assert.strictEqual(result.agentsCount, 2, 'counts .toml agents');
      assert.ok(
        fs.existsSync(path.join(workspaceDir, '.codex', 'config.toml')),
        'config.toml gap-filled from bundled after online deploy'
      );
    });
  });
});
