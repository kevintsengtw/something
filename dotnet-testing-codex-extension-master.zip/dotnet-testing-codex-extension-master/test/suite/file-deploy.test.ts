import * as assert from 'assert';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { copyDirRecursive, countFiles, countDirs } from '../../src/utils/file-deploy';

suite('file-deploy', () => {
  let tmpDir: string;

  setup(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dta-file-deploy-test-'));
  });

  teardown(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  // ── copyDirRecursive ─────────────────────────────────────────────────────

  suite('copyDirRecursive', () => {
    test('copies flat files', () => {
      const src  = path.join(tmpDir, 'src');
      const dest = path.join(tmpDir, 'dest');
      fs.mkdirSync(src);
      fs.writeFileSync(path.join(src, 'a.md'), 'content a');
      fs.writeFileSync(path.join(src, 'b.md'), 'content b');

      fs.mkdirSync(dest);
      copyDirRecursive(src, dest);

      assert.ok(fs.existsSync(path.join(dest, 'a.md')));
      assert.ok(fs.existsSync(path.join(dest, 'b.md')));
      assert.strictEqual(fs.readFileSync(path.join(dest, 'a.md'), 'utf-8'), 'content a');
    });

    test('copies nested directories', () => {
      const src  = path.join(tmpDir, 'src');
      const dest = path.join(tmpDir, 'dest');
      fs.mkdirSync(path.join(src, 'sub'), { recursive: true });
      fs.writeFileSync(path.join(src, 'sub', 'nested.md'), 'nested');

      fs.mkdirSync(dest);
      copyDirRecursive(src, dest);

      assert.ok(fs.existsSync(path.join(dest, 'sub', 'nested.md')));
      assert.strictEqual(fs.readFileSync(path.join(dest, 'sub', 'nested.md'), 'utf-8'), 'nested');
    });

    test('skips .gitkeep files', () => {
      const src  = path.join(tmpDir, 'src');
      const dest = path.join(tmpDir, 'dest');
      fs.mkdirSync(src);
      fs.writeFileSync(path.join(src, '.gitkeep'), '');
      fs.writeFileSync(path.join(src, 'real.md'), 'real');

      fs.mkdirSync(dest);
      copyDirRecursive(src, dest);

      assert.ok(!fs.existsSync(path.join(dest, '.gitkeep')));
      assert.ok(fs.existsSync(path.join(dest, 'real.md')));
    });

    test('skips entries in exclude set', () => {
      const src     = path.join(tmpDir, 'src');
      const dest    = path.join(tmpDir, 'dest');
      const exclude = new Set(['excluded.md']);
      fs.mkdirSync(src);
      fs.writeFileSync(path.join(src, 'excluded.md'), 'skip me');
      fs.writeFileSync(path.join(src, 'included.md'), 'keep me');

      fs.mkdirSync(dest);
      copyDirRecursive(src, dest, exclude);

      assert.ok(!fs.existsSync(path.join(dest, 'excluded.md')));
      assert.ok(fs.existsSync(path.join(dest, 'included.md')));
    });

    test('copies without exclude set when not provided', () => {
      const src  = path.join(tmpDir, 'src');
      const dest = path.join(tmpDir, 'dest');
      fs.mkdirSync(src);
      fs.writeFileSync(path.join(src, 'file.md'), 'data');

      fs.mkdirSync(dest);
      copyDirRecursive(src, dest);

      assert.ok(fs.existsSync(path.join(dest, 'file.md')));
    });
  });

  // ── countFiles ───────────────────────────────────────────────────────────

  suite('countFiles', () => {
    test('returns 0 for non-existent directory', () => {
      const result = countFiles(path.join(tmpDir, 'does-not-exist'));
      assert.strictEqual(result, 0);
    });

    test('returns 0 for empty directory', () => {
      const dir = path.join(tmpDir, 'empty');
      fs.mkdirSync(dir);
      assert.strictEqual(countFiles(dir), 0);
    });

    test('counts flat files correctly', () => {
      const dir = path.join(tmpDir, 'flat');
      fs.mkdirSync(dir);
      fs.writeFileSync(path.join(dir, 'a.md'), '');
      fs.writeFileSync(path.join(dir, 'b.md'), '');
      fs.writeFileSync(path.join(dir, 'c.md'), '');
      assert.strictEqual(countFiles(dir), 3);
    });

    test('counts files in nested directories', () => {
      const dir = path.join(tmpDir, 'nested');
      fs.mkdirSync(path.join(dir, 'sub'), { recursive: true });
      fs.writeFileSync(path.join(dir, 'root.md'), '');
      fs.writeFileSync(path.join(dir, 'sub', 'child.md'), '');
      assert.strictEqual(countFiles(dir), 2);
    });

    test('does not count .gitkeep', () => {
      const dir = path.join(tmpDir, 'withkeep');
      fs.mkdirSync(dir);
      fs.writeFileSync(path.join(dir, '.gitkeep'), '');
      fs.writeFileSync(path.join(dir, 'real.md'), '');
      assert.strictEqual(countFiles(dir), 1);
    });

    test('does not count excluded entries', () => {
      const dir     = path.join(tmpDir, 'withexclude');
      const exclude = new Set(['skip.md']);
      fs.mkdirSync(dir);
      fs.writeFileSync(path.join(dir, 'skip.md'), '');
      fs.writeFileSync(path.join(dir, 'keep.md'), '');
      assert.strictEqual(countFiles(dir, exclude), 1);
    });
  });

  // ── countDirs ────────────────────────────────────────────────────────────

  suite('countDirs', () => {
    test('returns 0 for non-existent directory', () => {
      assert.strictEqual(countDirs(path.join(tmpDir, 'does-not-exist')), 0);
    });

    test('returns 0 for empty directory', () => {
      const dir = path.join(tmpDir, 'empty-for-dirs');
      fs.mkdirSync(dir);
      assert.strictEqual(countDirs(dir), 0);
    });

    test('returns 0 when directory contains only files', () => {
      const dir = path.join(tmpDir, 'files-only');
      fs.mkdirSync(dir);
      fs.writeFileSync(path.join(dir, 'a.md'), '');
      fs.writeFileSync(path.join(dir, 'b.md'), '');
      assert.strictEqual(countDirs(dir), 0);
    });

    test('counts immediate subdirectories', () => {
      const dir = path.join(tmpDir, 'with-subdirs');
      fs.mkdirSync(path.join(dir, 'skill-a'), { recursive: true });
      fs.mkdirSync(path.join(dir, 'skill-b'), { recursive: true });
      fs.mkdirSync(path.join(dir, 'skill-c'), { recursive: true });
      assert.strictEqual(countDirs(dir), 3);
    });

    test('does not count nested subdirectories (only immediate children)', () => {
      const dir = path.join(tmpDir, 'nested-dirs');
      fs.mkdirSync(path.join(dir, 'skill-a', 'nested'), { recursive: true });
      fs.mkdirSync(path.join(dir, 'skill-b'), { recursive: true });
      // skill-a and skill-b are 2 immediate dirs; nested inside skill-a is NOT counted
      assert.strictEqual(countDirs(dir), 2);
    });

    test('counts directories even when they also contain files', () => {
      const dir = path.join(tmpDir, 'mixed');
      const sub = path.join(dir, 'skill-a');
      fs.mkdirSync(sub, { recursive: true });
      fs.writeFileSync(path.join(sub, 'SKILL.md'), '# skill-a');
      fs.writeFileSync(path.join(dir, 'README.md'), '');
      // 1 subdirectory + 1 file at top level → countDirs returns 1
      assert.strictEqual(countDirs(dir), 1);
    });
  });
});
