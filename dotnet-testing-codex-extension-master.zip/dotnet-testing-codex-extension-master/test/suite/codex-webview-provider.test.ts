import * as assert from 'assert';
import { buildCodexWebviewHtml } from '../../src/views/codex-webview-html';

/**
 * 驗證 Codex Webview HTML 的結構與安全性。
 *
 * 測試對象：buildCodexWebviewHtml()（exported pure function）
 * 測試環境：純 Mocha，無 VS Code 實例
 */

const TEST_NONCE = 'TestNonce1234567890ABCDEF123456';

suite('CodexWebviewProvider / buildCodexWebviewHtml', () => {
  let html: string;

  suiteSetup(() => {
    html = buildCodexWebviewHtml(TEST_NONCE);
  });

  // ── CSP ──────────────────────────────────────────────────────────────────

  suite('Content Security Policy', () => {
    test('CSP default-src none', () => {
      assert.ok(html.includes("default-src 'none'"));
    });
    test('style-src unsafe-inline', () => {
      assert.ok(html.includes("style-src 'unsafe-inline'"));
    });
    test('script-src 使用傳入的 nonce', () => {
      assert.ok(html.includes(`script-src 'nonce-${TEST_NONCE}'`));
    });
    test('<script> nonce 與 CSP nonce 一致', () => {
      const cspMatch = html.match(/script-src 'nonce-([^']+)'/);
      const scriptMatch = html.match(/<script nonce="([^"]+)">/);
      assert.ok(cspMatch && scriptMatch);
      assert.strictEqual(cspMatch![1], scriptMatch![1]);
    });
  });

  // ── 禁止 inline event handlers ──────────────────────────────────────────

  suite('禁止 inline event handlers', () => {
    test('無 onclick=', () => assert.ok(!html.includes('onclick=')));
    test('無 onchange=', () => assert.ok(!html.includes('onchange=')));
    test('無 onload=', () => assert.ok(!html.includes('onload=')));
  });

  // ── 事件綁定 ────────────────────────────────────────────────────────────

  suite('事件綁定使用 addEventListener', () => {
    test('包含 addEventListener', () => assert.ok(html.includes('addEventListener')));
    test('btn-init 綁定 click', () => {
      assert.ok(html.includes("getElementById('btn-init')") && html.includes("addEventListener('click'"));
    });
    test('btn-doctor 綁定 click', () => {
      assert.ok(html.includes("getElementById('btn-doctor')") && html.includes("addEventListener('click'"));
    });
    test('分頁切換使用 data-tab + querySelectorAll', () => {
      assert.ok(html.includes('data-tab') && html.includes('querySelectorAll'));
    });
  });

  // ── HTML 結構 ────────────────────────────────────────────────────────────

  suite('HTML 結構完整性', () => {
    test('三個分頁按鈕（總覽 / Skills / Agents）', () => {
      assert.ok(html.includes('data-tab="overview"'));
      assert.ok(html.includes('data-tab="skills"'));
      assert.ok(html.includes('data-tab="agents"'));
    });
    test('三個 panel div', () => {
      assert.ok(html.includes('id="panel-overview"'));
      assert.ok(html.includes('id="panel-skills"'));
      assert.ok(html.includes('id="panel-agents"'));
    });
    test('總覽分頁預設 active', () => {
      assert.ok(html.includes('id="panel-overview" class="panel active"'));
    });
    test('btn-init / btn-doctor / status-badge / doctor-results / overview-installed 存在', () => {
      assert.ok(html.includes('id="btn-init"'));
      assert.ok(html.includes('id="btn-doctor"'));
      assert.ok(html.includes('id="status-badge"'));
      assert.ok(html.includes('id="doctor-results"'));
      assert.ok(html.includes('id="overview-installed"'));
    });
  });

  // ── VS Code Webview API ─────────────────────────────────────────────────

  suite('VS Code Webview API', () => {
    test('acquireVsCodeApi()', () => assert.ok(html.includes('acquireVsCodeApi()')));
    test('載入後送出 requestState', () => assert.ok(html.includes("sendCmd('requestState')")));
    test('init / runDoctor 指令', () => {
      assert.ok(html.includes("sendCmd('init')"));
      assert.ok(html.includes("sendCmd('runDoctor')"));
    });
    test('處理 state / doctorResults / switchTab 訊息', () => {
      assert.ok(html.includes("msg.type === 'state'"));
      assert.ok(html.includes("msg.type === 'doctorResults'"));
      assert.ok(html.includes("msg.type === 'switchTab'"));
    });
  });

  // ── Agents tab（Codex 特有：config 取代 hooks）──────────────────────────

  suite('Agents tab 元素（Codex 特有）', () => {
    test('agents-list 容器存在', () => assert.ok(html.includes('id="agents-list"')));
    test('config-list 容器存在（取代 Claude 的 hooks-list）', () => {
      assert.ok(html.includes('id="config-list"'));
      assert.ok(!html.includes('id="hooks-list"'), '不應殘留 hooks-list');
    });
    test('config-status 容器存在', () => assert.ok(html.includes('id="config-status"')));
    test('scripts-list 容器存在（token 估算引擎）', () => assert.ok(html.includes('id="scripts-list"')));
    test('orch-release-content 容器存在', () => assert.ok(html.includes('id="orch-release-content"')));
    test('Agents GitHub 連結指向 orchestration-codex', () => {
      assert.ok(html.includes('data-url="https://github.com/kevintsengtw/dotnet-testing-agent-orchestration-codex"'));
    });
  });

  // ── Release 訊息處理 ─────────────────────────────────────────────────────

  suite('Release 訊息處理', () => {
    test('orchRelease 型別 + fetchOrchRelease + orchReleaseLoaded 旗標', () => {
      assert.ok(html.includes("msg.type === 'orchRelease'"));
      assert.ok(html.includes("'fetchOrchRelease'"));
      assert.ok(html.includes('orchReleaseLoaded'));
    });
    test('skillsRelease 型別 + fetchSkillsRelease + skillsReleaseLoaded 旗標', () => {
      assert.ok(html.includes("msg.type === 'skillsRelease'"));
      assert.ok(html.includes("'fetchSkillsRelease'"));
      assert.ok(html.includes('skillsReleaseLoaded'));
    });
    test('skills-release-content / skills-version-link 存在', () => {
      assert.ok(html.includes('id="skills-release-content"'));
      assert.ok(html.includes('id="skills-version-link"'));
    });
  });

  // ── openUrl 連結機制 ─────────────────────────────────────────────────────

  suite('openUrl 連結機制', () => {
    test('openUrl command', () => assert.ok(html.includes("command:'openUrl'")));
    test('link-btn 事件委派', () => {
      assert.ok(html.includes("closest('.link-btn')") || html.includes('closest(".link-btn")'));
    });
  });

  // ── 隨機 nonce 生成 ─────────────────────────────────────────────────────

  suite('隨機 nonce 生成', () => {
    test('不傳 nonce 時自動生成', () => {
      assert.ok(buildCodexWebviewHtml().includes("script-src 'nonce-"));
    });
    test('兩次呼叫 nonce 不同', () => {
      const n1 = buildCodexWebviewHtml().match(/script-src 'nonce-([^']+)'/)?.[1];
      const n2 = buildCodexWebviewHtml().match(/script-src 'nonce-([^']+)'/)?.[1];
      assert.notStrictEqual(n1, n2);
    });
  });
});
