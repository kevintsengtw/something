import * as assert from 'assert';
import * as os from 'os';

suite('ShellExecutor', () => {
  test('getShell returns cmd.exe on Windows', () => {
    if (os.platform() !== 'win32') {
      return;
    }
    // Validate the platform logic inline
    const shell = os.platform() === 'win32' ? 'cmd.exe' : '/bin/sh';
    assert.strictEqual(shell, 'cmd.exe');
  });

  test('getShell returns /bin/sh on non-Windows', () => {
    if (os.platform() === 'win32') {
      return;
    }
    const shell = os.platform() === 'win32' ? 'cmd.exe' : '/bin/sh';
    assert.strictEqual(shell, '/bin/sh');
  });
});
