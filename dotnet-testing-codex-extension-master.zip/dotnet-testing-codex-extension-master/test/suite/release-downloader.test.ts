import * as assert from 'assert';
import { ReleaseDownloader } from '../../src/services/release-downloader';

const stubShell  = { exec: async () => ({ stdout: '', stderr: '', exitCode: 0 }) } as any;
const stubLogger = { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} } as any;

suite('ReleaseDownloader', () => {
  let downloader: ReleaseDownloader;

  setup(() => {
    downloader = new ReleaseDownloader(stubShell, stubLogger);
  });

  test('extractOwnerRepo: valid GitHub URL', () => {
    const result = downloader.extractOwnerRepo(
      'https://github.com/kevintsengtw/dotnet-testing-agent-skills'
    );
    assert.strictEqual(result, 'kevintsengtw/dotnet-testing-agent-skills');
  });

  test('extractOwnerRepo: URL with .git suffix is trimmed', () => {
    const result = downloader.extractOwnerRepo(
      'https://github.com/kevintsengtw/dotnet-testing-agent-skills.git'
    );
    assert.strictEqual(result, 'kevintsengtw/dotnet-testing-agent-skills');
  });

  test('extractOwnerRepo: Gitea URL is parsed (host-agnostic)', () => {
    const result = downloader.extractOwnerRepo(
      'https://gitea.company.com/dotnet-testing/dotnet-testing-agent-skills'
    );
    assert.strictEqual(result, 'dotnet-testing/dotnet-testing-agent-skills');
  });

  test('extractOwnerRepo: invalid URL throws', () => {
    assert.throws(
      () => downloader.extractOwnerRepo('not-a-valid-url'),
      /無法從 URL 解析 owner\/repo/
    );
  });

  test('resolveTag: returns version as-is when not "latest"', async () => {
    const tag = await downloader.resolveTag('https://github.com/owner/repo', 'v1.2.3');
    assert.strictEqual(tag, 'v1.2.3');
  });

  test('resolveTag: returns empty string input unchanged', async () => {
    const tag = await downloader.resolveTag('https://github.com/owner/repo', 'v0.0.1-beta');
    assert.strictEqual(tag, 'v0.0.1-beta');
  });
});
