import * as assert from 'assert';
import { buildAboutWebviewHtml } from '../../src/views/about-webview-html';

const TEST_NONCE = 'TestNonce1234567890ABCDEF123456';

suite('AboutWebview / buildAboutWebviewHtml', () => {
  let html: string;
  suiteSetup(() => { html = buildAboutWebviewHtml(TEST_NONCE); });

  test('CSP default-src none + script nonce 一致', () => {
    assert.ok(html.includes("default-src 'none'"));
    assert.ok(html.includes(`script-src 'nonce-${TEST_NONCE}'`));
    assert.ok(html.includes(`<script nonce="${TEST_NONCE}">`));
  });

  test('無 inline event handlers', () => {
    assert.ok(!html.includes('onclick='));
    assert.ok(!html.includes('onchange='));
    assert.ok(!html.includes('onload='));
  });

  test('事件以 addEventListener 綁定、載入送出 requestState', () => {
    assert.ok(html.includes('addEventListener'));
    assert.ok(html.includes("sendCmd('requestState')"));
  });

  test('容器：目前版本 / 最新版本 / 狀態 / release note / 落差 / refresh', () => {
    assert.ok(html.includes('id="current-version"'), 'current-version');
    assert.ok(html.includes('id="latest-version"'), 'latest-version');
    assert.ok(html.includes('id="latest-status"'), 'latest-status');
    assert.ok(html.includes('id="release-notes"'), 'release-notes');
    assert.ok(html.includes('id="drift-list"'), 'drift-list');
    assert.ok(html.includes('id="btn-refresh"'), 'btn-refresh');
  });

  test('處理 state 訊息、openUrl 與 reinit 指令', () => {
    assert.ok(html.includes("msg.type === 'state'"));
    assert.ok(html.includes("command:'openUrl'"));
    assert.ok(html.includes("'reinit'"));
  });

  test('剛更新提示橫幅：元素存在且由 justUpdated 控制顯示、可關閉', () => {
    assert.ok(html.includes('id="update-banner"'), '缺少 update-banner 橫幅容器');
    assert.ok(html.includes('id="ub-version"'), '缺少版本佔位');
    assert.ok(html.includes('id="ub-dismiss"'), '缺少關閉按鈕');
    assert.ok(html.includes('msg.justUpdated'), 'onState 應依 justUpdated 顯示橫幅');
    assert.ok(html.includes('完整結束 VS Code'), '橫幅應提示完整重啟');
    assert.ok(html.includes('不能只用 Reload Window') || html.includes('Reload Window'), '橫幅應點出不能只 Reload Window');
  });

  test('未傳 nonce 時自動生成且每次不同', () => {
    const a = buildAboutWebviewHtml();
    const b = buildAboutWebviewHtml();
    const na = a.match(/script-src 'nonce-([^']+)'/)?.[1];
    const nb = b.match(/script-src 'nonce-([^']+)'/)?.[1];
    assert.ok(na && nb);
    assert.notStrictEqual(na, nb);
  });
});
