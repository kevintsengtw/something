import * as assert from 'assert';
import { mergeCodexConfigToml, parseTomlSections } from '../../src/utils/toml-merge';

const BUNDLED = `# Codex workspace configuration for the unit testing orchestration workflow.
personality = "friendly"

[features]
multi_agent = true
hooks = true

[agents]
max_depth = 1
max_threads = 6
job_max_runtime_seconds = 1800
`;

suite('toml-merge', () => {
  suite('mergeCodexConfigToml', () => {
    test('returns bundled verbatim when existing is null', () => {
      assert.strictEqual(mergeCodexConfigToml(BUNDLED, null), BUNDLED);
    });

    test('returns bundled verbatim when existing is empty/whitespace', () => {
      assert.strictEqual(mergeCodexConfigToml(BUNDLED, '   \n  '), BUNDLED);
    });

    test('preserves user values, never overwrites', () => {
      const existing = `personality = "blunt"

[agents]
max_threads = 12
`;
      const merged = mergeCodexConfigToml(BUNDLED, existing);
      // 使用者既有值保留
      assert.ok(merged.includes('personality = "blunt"'), 'user personality kept');
      assert.ok(merged.includes('max_threads = 12'), 'user max_threads kept');
      // 不應引入 bundled 的 personality / max_threads 值
      assert.ok(!merged.includes('personality = "friendly"'), 'bundled personality not added');
      assert.ok(!merged.includes('max_threads = 6'), 'bundled max_threads not added');
    });

    test('fills missing keys within an existing table', () => {
      const existing = `[agents]
max_threads = 12
`;
      const merged = mergeCodexConfigToml(BUNDLED, existing);
      const sections = parseTomlSections(merged);
      assert.ok(merged.includes('max_threads = 12'), 'user value kept');
      assert.ok(merged.includes('max_depth = 1'), 'missing max_depth filled');
      assert.ok(merged.includes('job_max_runtime_seconds = 1800'), 'missing runtime filled');
      assert.ok(sections.has('agents'));
    });

    test('appends an entire missing table', () => {
      const existing = `[agents]
max_depth = 1
max_threads = 6
job_max_runtime_seconds = 1800
`;
      const merged = mergeCodexConfigToml(BUNDLED, existing);
      const sections = parseTomlSections(merged);
      assert.ok(sections.has('features'), '[features] table appended');
      assert.ok(merged.includes('multi_agent = true'), 'features keys present');
    });

    test('inserts missing top-level key before first table header', () => {
      const existing = `[features]
multi_agent = true
hooks = true

[agents]
max_depth = 1
max_threads = 6
job_max_runtime_seconds = 1800
`;
      const merged = mergeCodexConfigToml(BUNDLED, existing);
      assert.ok(merged.includes('personality = "friendly"'), 'top-level key filled');
      // personality 應出現在第一個 [ 之前
      const personalityIdx = merged.indexOf('personality');
      const firstTableIdx = merged.indexOf('[');
      assert.ok(personalityIdx < firstTableIdx, 'top-level key placed before first table');
    });

    test('no-op when existing already has everything', () => {
      const merged = mergeCodexConfigToml(BUNDLED, BUNDLED);
      // 不應重複任何 key
      assert.strictEqual((merged.match(/max_depth/g) ?? []).length, 1);
      assert.strictEqual((merged.match(/personality/g) ?? []).length, 1);
    });
  });

  suite('parseTomlSections', () => {
    test('extracts table section names', () => {
      const sections = parseTomlSections(BUNDLED);
      assert.ok(sections.has('features'));
      assert.ok(sections.has('agents'));
      assert.strictEqual(sections.size, 2);
    });
  });
});
