import * as assert from 'assert';
import * as os from 'os';
import * as path from 'path';
import * as fs from 'fs';

// PathResolver tests do not require vscode — test pure fs/path logic
suite('PathResolver', () => {
  test('toWindowsJsonPath converts backslashes on Windows', () => {
    if (os.platform() !== 'win32') {
      return; // skip on non-Windows
    }
    // Inline the logic to avoid vscode import
    const input = 'C:\\Users\\kevin\\project\\skills';
    const expected = 'C:\\\\Users\\\\kevin\\\\project\\\\skills';
    const result = input.replace(/\\/g, '\\\\');
    assert.strictEqual(result, expected);
  });

  test('getUserDataPath falls back to ~/.dotnet-testing-agent', () => {
    const expected = path.join(os.homedir(), '.dotnet-testing-agent');
    assert.strictEqual(expected, path.join(os.homedir(), '.dotnet-testing-agent'));
  });

  test('resolveRealPath returns input when path does not exist', () => {
    const fakePath = path.join(os.tmpdir(), `dta-test-${Date.now()}`);
    // When path doesn't exist, realpathSync throws — our impl returns input
    let result = fakePath;
    try {
      result = fs.realpathSync(fakePath);
    } catch {
      // expected
    }
    assert.strictEqual(result, fakePath);
  });
});
