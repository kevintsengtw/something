import * as assert from 'assert';
import { resolveReleaseApiUrl } from '../../src/services/version-check-url';
import { isNewerVersion as isNewer } from '../../src/utils/semver';
import { EXTENSION_GITHUB_REPO } from '../../src/constants';

suite('VersionChecker (semver comparison)', () => {
  test('same version returns false', () => {
    assert.strictEqual(isNewer('1.2.3', '1.2.3'), false);
  });

  test('newer major returns true', () => {
    assert.strictEqual(isNewer('2.0.0', '1.9.9'), true);
  });

  test('older major returns false', () => {
    assert.strictEqual(isNewer('1.0.0', '2.0.0'), false);
  });

  test('same major, newer minor returns true', () => {
    assert.strictEqual(isNewer('1.3.0', '1.2.9'), true);
  });

  test('same major, older minor returns false', () => {
    assert.strictEqual(isNewer('1.2.0', '1.3.0'), false);
  });

  test('same major and minor, newer patch returns true', () => {
    assert.strictEqual(isNewer('1.2.4', '1.2.3'), true);
  });

  test('same major and minor, older patch returns false', () => {
    assert.strictEqual(isNewer('1.2.2', '1.2.3'), false);
  });

  test('major version 0 boundary', () => {
    assert.strictEqual(isNewer('0.2.0', '0.1.9'), true);
    assert.strictEqual(isNewer('0.1.0', '0.2.0'), false);
  });

  test('tag_name v-prefix stripped before comparison', () => {
    // VersionChecker strips 'v' prefix via release.tag_name.replace(/^v/, '')
    const stripped = 'v1.2.4'.replace(/^v/, '');
    assert.strictEqual(isNewer(stripped, '1.2.3'), true);
  });

  test('large version numbers', () => {
    assert.strictEqual(isNewer('10.0.0', '9.99.99'), true);
    assert.strictEqual(isNewer('1.10.0', '1.9.99'), true);
  });
});

// Release API URL selection — the exact logic that previously skipped the check
// (returned null) whenever Gitea was unconfigured, so users never got update notifications.
suite('VersionChecker (release API URL selection)', () => {
  const githubUrl = `https://api.github.com/repos/${EXTENSION_GITHUB_REPO}/releases/latest`;

  test('defaults to GitHub public repo when Gitea is unconfigured (both empty)', () => {
    assert.strictEqual(resolveReleaseApiUrl('', ''), githubUrl);
  });

  test('defaults to GitHub when both are undefined (settings unset)', () => {
    assert.strictEqual(resolveReleaseApiUrl(undefined, undefined), githubUrl);
  });

  test('falls back to GitHub when only giteaUrl is set', () => {
    assert.strictEqual(resolveReleaseApiUrl('https://gitea.example.com', ''), githubUrl);
  });

  test('falls back to GitHub when only giteaRepo is set', () => {
    assert.strictEqual(resolveReleaseApiUrl('', 'owner/repo'), githubUrl);
  });

  test('uses Gitea API when both giteaUrl and giteaRepo are set', () => {
    assert.strictEqual(
      resolveReleaseApiUrl('https://gitea.example.com', 'owner/repo'),
      'https://gitea.example.com/api/v1/repos/owner/repo/releases/latest'
    );
  });
});
