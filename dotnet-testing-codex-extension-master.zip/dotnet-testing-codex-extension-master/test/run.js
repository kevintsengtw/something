const Mocha = require('mocha');
const fs = require('fs');
const path = require('path');

const m = new Mocha({ ui: 'tdd', timeout: 10000, color: true });
const dir = path.join(__dirname, '..', 'out', 'test', 'suite');

fs.readdirSync(dir)
  .filter((f) => f.endsWith('.test.js'))
  .forEach((f) => m.addFile(path.join(dir, f)));

m.run((failures) => {
  process.exitCode = failures > 0 ? 1 : 0;
});
