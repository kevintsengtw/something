import * as esbuild from 'esbuild';

const watch = process.argv.includes('--watch');
const production = process.argv.includes('--production');

const ctx = await esbuild.context({
  entryPoints: ['src/extension.ts'],
  bundle: true,
  outfile: 'dist/extension.js',
  external: ['vscode'],
  format: 'cjs',
  platform: 'node',
  target: 'node18',
  sourcemap: !production,
  sourcesContent: false,
  minify: production,
});

if (watch) {
  await ctx.watch();
  console.log('[watch] build started — watching for changes...');
} else {
  await ctx.rebuild();
  await ctx.dispose();
  console.log(production ? 'Production build complete.' : 'Build complete.');
}
