#!/usr/bin/env node
/**
 * sync-bundled.mjs（Codex 獨立版）
 * 從 Release 同步「共用 skills」到 bundled/shared/skills/，並寫出 bundled/shared/version.json。
 *
 * 來源 repo 可為 GitHub 或公司內部 Gitea（--skills-repo）；resolveTag 會依 host 自動
 * 選用 GitHub（api.github.com）或 Gitea（{host}/api/v1）的 Releases API。
 *
 * Usage:
 *   node scripts/sync-bundled.mjs
 *   node scripts/sync-bundled.mjs --skills-version v1.2.0
 *   node scripts/sync-bundled.mjs --skills-repo https://gitea.company.com/dotnet-testing/dotnet-testing-agent-skills
 *   node scripts/sync-bundled.mjs --skills-path /path/to/skills
 */

import { execSync }                                    from 'node:child_process';
import { existsSync, mkdirSync, rmSync, readdirSync,
         writeFileSync, copyFileSync }                 from 'node:fs';
import { join, resolve }                               from 'node:path';
import { fileURLToPath }                               from 'node:url';
import { tmpdir }                                      from 'node:os';
import { randomBytes }                                 from 'node:crypto';

// ── Arg parsing ──────────────────────────────────────────────────────────────

const argv = process.argv.slice(2);
const getArg = (flag) => {
  const i = argv.indexOf(flag);
  return i !== -1 && i + 1 < argv.length ? argv[i + 1] : null;
};

const SKILLS_VERSION  = getArg('--skills-version')  ?? 'latest';
const SKILLS_REPO_URL = getArg('--skills-repo')     ?? 'https://github.com/kevintsengtw/dotnet-testing-agent-skills';
const SKILLS_PATH     = getArg('--skills-path')     ?? '';

// ── Paths ────────────────────────────────────────────────────────────────────

const __dirname  = fileURLToPath(new URL('.', import.meta.url));
const REPO_ROOT  = resolve(__dirname, '..');
const BUNDLED    = join(REPO_ROOT, 'bundled');
const TEMP_DIR   = join(tmpdir(), `dta-sync-${randomBytes(4).toString('hex')}`);

// ── Helpers ──────────────────────────────────────────────────────────────────

function step(msg) {
  console.log(`\n[SYNC] ${msg}`);
}

function gitCommit(repoPath) {
  try {
    return execSync('git rev-parse HEAD', { cwd: repoPath, stdio: ['pipe', 'pipe', 'pipe'] })
      .toString().trim();
  } catch {
    return '';
  }
}

/** 從 repo URL 解析 "owner/repo"，支援 GitHub 與 Gitea 等任意 host。 */
function ownerRepo(repoUrl) {
  const m = repoUrl.match(/^https?:\/\/[^/]+\/([^/]+\/[^/.]+)/);
  if (!m) throw new Error(`無法從 URL 解析 owner/repo：${repoUrl}`);
  return m[1];
}

/** 依 host 組出 Releases API 的 latest endpoint（GitHub / Gitea）。 */
function releaseApiUrl(repoUrl) {
  const or = ownerRepo(repoUrl);
  const hm = repoUrl.match(/^(https?):\/\/([^/]+)\//);
  if (!hm) throw new Error(`無法從 URL 解析 host：${repoUrl}`);
  const [, scheme, host] = hm;
  if (host === 'github.com' || host === 'www.github.com') {
    return `https://api.github.com/repos/${or}/releases/latest`;
  }
  return `${scheme}://${host}/api/v1/repos/${or}/releases/latest`;
}

async function resolveTag(repoUrl, version) {
  if (version !== 'latest') return version;
  const apiUrl = releaseApiUrl(repoUrl);
  console.log(`  Resolving latest release: ${apiUrl}`);
  const res = await fetch(apiUrl, { headers: { 'User-Agent': 'dta-sync-bundled' } });
  if (!res.ok) throw new Error(`Release API 失敗（${res.status}）：${apiUrl}`);
  const data = await res.json();
  if (!data.tag_name) throw new Error('API 回應缺少 tag_name');
  console.log(`  Latest release tag: ${data.tag_name}`);
  return data.tag_name;
}

function cloneAtTag(repoUrl, tag, name) {
  const clonePath = join(TEMP_DIR, name);
  console.log(`  Clone ${repoUrl} @ ${tag}`);
  execSync(`git clone --branch ${tag} --depth 1 ${repoUrl} ${clonePath}`, { stdio: 'inherit' });
  return clonePath;
}

function copyDir(src, dest) {
  if (!existsSync(src)) throw new Error(`來源目錄不存在：${src}`);
  if (existsSync(dest)) rmSync(dest, { recursive: true, force: true });
  mkdirSync(dest, { recursive: true });
  copyDirRecursive(src, dest);
  console.log(`  已複製：${src} -> ${dest}`);
}

function copyDirRecursive(src, dest) {
  for (const entry of readdirSync(src, { withFileTypes: true })) {
    const srcPath  = join(src,  entry.name);
    const destPath = join(dest, entry.name);
    if (entry.isDirectory()) {
      mkdirSync(destPath, { recursive: true });
      copyDirRecursive(srcPath, destPath);
    } else {
      copyFileSync(srcPath, destPath);
    }
  }
}

function countMdFiles(dir) {
  if (!existsSync(dir)) return 0;
  let count = 0;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      count += countMdFiles(join(dir, entry.name));
    } else if (entry.name.endsWith('.md')) {
      count++;
    }
  }
  return count;
}

// ── Main ─────────────────────────────────────────────────────────────────────

mkdirSync(TEMP_DIR, { recursive: true });

let skillsCommit = '', skillsTag = '', actualSkillsUrl = SKILLS_REPO_URL;

try {
  // ── Skills ──────────────────────────────────────────────────────────────
  step('Syncing shared Skills...');
  const skillsTarget = join(BUNDLED, 'shared', 'skills');

  if (SKILLS_PATH) {
    console.log(`  [Local] ${SKILLS_PATH}`);
    copyDir(join(SKILLS_PATH, 'skills'), skillsTarget);
    skillsCommit    = gitCommit(SKILLS_PATH);
    skillsTag       = 'local';
    actualSkillsUrl = SKILLS_PATH;
  } else {
    skillsTag = await resolveTag(SKILLS_REPO_URL, SKILLS_VERSION);
    const cloned = cloneAtTag(SKILLS_REPO_URL, skillsTag, 'skills');
    copyDir(join(cloned, 'skills'), skillsTarget);
    skillsCommit = gitCommit(cloned);
  }

  const skillsCount = countMdFiles(skillsTarget);
  console.log(`  Synced ${skillsCount} .md files (tag: ${skillsTag})`);

  // ── version.json ─────────────────────────────────────────────────────────
  step('Writing bundled/shared/version.json...');
  const versionData = {
    syncedAt: new Date().toISOString(),
    skills: {
      repo:    ownerRepo(actualSkillsUrl.startsWith('http') ? actualSkillsUrl : SKILLS_REPO_URL),
      repoUrl: actualSkillsUrl,
      version: skillsTag,
      commit:  skillsCommit,
      branch:  'main',
    },
  };

  mkdirSync(join(BUNDLED, 'shared'), { recursive: true });
  writeFileSync(join(BUNDLED, 'shared', 'version.json'), JSON.stringify(versionData, null, 2), 'utf-8');

  const short = (s) => s.substring(0, Math.min(7, s.length));
  console.log('');
  console.log('[SYNC] Done!');
  console.log(`  Shared skills: ${skillsCount} files  (tag: ${skillsTag}, commit: ${short(skillsCommit)})`);

} finally {
  // Cleanup temp dir
  if (existsSync(TEMP_DIR)) {
    rmSync(TEMP_DIR, { recursive: true, force: true });
  }
}
