#!/usr/bin/env node
/**
 * sync-bundled-codex.mjs
 * 從 GitHub 同步 Codex 模式專用的 agents、scripts、skills 與 config.toml 到 bundled/codex/ 目錄。
 *
 * 注意：共用的 29 個 dotnet-testing-agent-skills 由 sync-bundled.mjs 負責，
 * 存放於 bundled/shared/skills/。本腳本只同步 Codex orchestration 專用內容。
 *
 * Sources:
 *   - dotnet-testing-agent-orchestration-codex (.codex/skills/, .codex/agents/, .codex/scripts/, .codex/config.toml)
 *
 * 來源 repo 可為 GitHub 或公司內部 Gitea（--orch-repo）。
 *
 * Usage:
 *   node scripts/sync-bundled-codex.mjs
 *   node scripts/sync-bundled-codex.mjs --orch-repo https://gitea.company.com/dotnet-testing/dotnet-testing-agent-orchestration-codex
 *   node scripts/sync-bundled-codex.mjs --orch-path /path/to/codex-orch
 */

import { execSync }                                      from 'node:child_process';
import { existsSync, mkdirSync, rmSync, readdirSync,
         writeFileSync, copyFileSync }                   from 'node:fs';
import { join, resolve, dirname }                        from 'node:path';
import { fileURLToPath }                                 from 'node:url';
import { tmpdir }                                        from 'node:os';
import { randomBytes }                                   from 'node:crypto';

// ── Arg parsing ──────────────────────────────────────────────────────────────

const argv = process.argv.slice(2);
const getArg = (flag) => {
  const i = argv.indexOf(flag);
  return i !== -1 && i + 1 < argv.length ? argv[i + 1] : null;
};

const ORCH_REPO_URL = getArg('--orch-repo') ?? 'https://github.com/kevintsengtw/dotnet-testing-agent-orchestration-codex';
const ORCH_BRANCH   = 'main';
const ORCH_PATH     = getArg('--orch-path') ?? '';

// ── Paths ────────────────────────────────────────────────────────────────────

const __dirname  = fileURLToPath(new URL('.', import.meta.url));
const REPO_ROOT  = resolve(__dirname, '..');
const BUNDLED    = join(REPO_ROOT, 'bundled');
const CODEX_DIR  = join(BUNDLED, 'codex');
const TEMP_DIR   = join(tmpdir(), `dta-sync-codex-${randomBytes(4).toString('hex')}`);

// ── Helpers ──────────────────────────────────────────────────────────────────

function step(msg) {
  console.log(`\n[SYNC-CODEX] ${msg}`);
}

function gitCommit(repoPath) {
  try {
    return execSync('git rev-parse HEAD', { cwd: repoPath, stdio: ['pipe', 'pipe', 'pipe'] })
      .toString().trim();
  } catch {
    return '';
  }
}

function gitVersion(repoPath) {
  try {
    const desc = execSync('git describe --tags --always', { cwd: repoPath, stdio: ['pipe', 'pipe', 'pipe'] })
      .toString().trim();
    return desc || gitCommit(repoPath).substring(0, 7);
  } catch {
    const commit = gitCommit(repoPath);
    return commit ? commit.substring(0, 7) : '0.0.0';
  }
}

/** 從 repo URL 解析 "owner/repo"，支援 GitHub 與 Gitea 等任意 host。 */
function ownerRepo(repoUrl) {
  const m = repoUrl.match(/^https?:\/\/[^/]+\/([^/]+\/[^/.]+)/);
  if (!m) throw new Error(`無法從 URL 解析 owner/repo：${repoUrl}`);
  return m[1];
}

function cloneRepo(repoUrl, tagOrBranch, name) {
  const clonePath = join(TEMP_DIR, name);
  console.log(`  Clone ${repoUrl} @ ${tagOrBranch}`);
  try {
    execSync(`git clone --branch ${tagOrBranch} --depth 1 ${repoUrl} ${clonePath}`, { stdio: 'inherit' });
  } catch {
    console.log(`  Branch not found, cloning default branch...`);
    execSync(`git clone --depth 1 ${repoUrl} ${clonePath}`, { stdio: 'inherit' });
  }
  return clonePath;
}

function copyDir(src, dest) {
  if (!existsSync(src)) throw new Error(`來源目錄不存在：${src}`);
  if (existsSync(dest)) rmSync(dest, { recursive: true, force: true });
  mkdirSync(dest, { recursive: true });
  copyDirRecursive(src, dest);
  console.log(`  已複製：${src} -> ${dest}`);
}

function copyDirRecursive(src, dest) {
  for (const entry of readdirSync(src, { withFileTypes: true })) {
    if (entry.name === '.gitkeep') continue;
    const srcPath  = join(src,  entry.name);
    const destPath = join(dest, entry.name);
    if (entry.isDirectory()) {
      mkdirSync(destPath, { recursive: true });
      copyDirRecursive(srcPath, destPath);
    } else {
      copyFileSync(srcPath, destPath);
    }
  }
}

function copyFile(src, dest) {
  if (!existsSync(src)) throw new Error(`來源檔案不存在：${src}`);
  mkdirSync(dirname(dest), { recursive: true });
  copyFileSync(src, dest);
  console.log(`  已複製：${src} -> ${dest}`);
}

function countFiles(dir) {
  if (!existsSync(dir)) return 0;
  let count = 0;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) count += countFiles(join(dir, entry.name));
    else if (entry.name !== '.gitkeep') count++;
  }
  return count;
}

// ── Main ─────────────────────────────────────────────────────────────────────

mkdirSync(TEMP_DIR, { recursive: true });
mkdirSync(CODEX_DIR, { recursive: true });

// Verify shared skills exist (informational only)
const sharedSkillsDir = join(BUNDLED, 'shared', 'skills');
if (!existsSync(sharedSkillsDir)) {
  console.warn(`  [WARN] bundled/shared/skills/ not found. Run 'npm run sync-bundled' first to populate shared skills.`);
}

let orchCommit = '';

try {
  // ── Codex orchestration (.codex/skills/, agents/, scripts/, config.toml) ──
  step('Syncing Codex orchestration repo...');
  let orchClonePath = '';

  if (ORCH_PATH) {
    console.log(`  [Local] ${ORCH_PATH}`);
    orchClonePath = ORCH_PATH;
    orchCommit    = gitCommit(ORCH_PATH);
  } else {
    orchClonePath = cloneRepo(ORCH_REPO_URL, ORCH_BRANCH, 'codex-orch');
    orchCommit    = gitCommit(orchClonePath);
  }

  // Copy codex-specific skills (.codex/skills/ — orchestrator skills only)
  step('Syncing Codex orchestrator skills (.codex/skills/)...');
  const orchSkillsSrc = join(orchClonePath, '.codex', 'skills');
  const skillsTarget  = join(CODEX_DIR, 'skills');
  if (existsSync(orchSkillsSrc)) {
    copyDir(orchSkillsSrc, skillsTarget);
    console.log(`  Codex-specific skills synced: ${countFiles(skillsTarget)} files`);
  } else {
    console.log('  .codex/skills/ not found in orchestration repo, skipping');
  }

  // Copy agents (.toml)
  step('Syncing Codex agents (.codex/agents/)...');
  const agentsSrc    = join(orchClonePath, '.codex', 'agents');
  const agentsTarget = join(CODEX_DIR, 'agents');
  if (existsSync(agentsSrc)) {
    copyDir(agentsSrc, agentsTarget);
    console.log(`  Agents synced: ${countFiles(agentsTarget)} files`);
  } else {
    console.log('  .codex/agents/ not found, skipping');
  }

  // Copy scripts (token estimation engine)
  step('Syncing Codex scripts (.codex/scripts/)...');
  const scriptsSrc    = join(orchClonePath, '.codex', 'scripts');
  const scriptsTarget = join(CODEX_DIR, 'scripts');
  if (existsSync(scriptsSrc)) {
    copyDir(scriptsSrc, scriptsTarget);
    console.log(`  Scripts synced: ${countFiles(scriptsTarget)} files`);
  } else {
    console.log('  .codex/scripts/ not found, skipping');
  }

  // Copy config.toml (single file — platform configuration)
  step('Syncing Codex config (.codex/config.toml)...');
  const configSrc    = join(orchClonePath, '.codex', 'config.toml');
  const configTarget = join(CODEX_DIR, 'config.toml');
  if (existsSync(configSrc)) {
    copyFile(configSrc, configTarget);
  } else {
    console.log('  .codex/config.toml not found, skipping');
  }

  // ── version.json ─────────────────────────────────────────────────────────
  step('Writing bundled/codex/version.json...');
  const orchVersion = gitVersion(orchClonePath || ORCH_PATH);
  const versionData = {
    syncedAt: new Date().toISOString(),
    orchestration: {
      repo:    ownerRepo(ORCH_REPO_URL),
      repoUrl: ORCH_PATH || ORCH_REPO_URL,
      version: orchVersion,
      commit:  orchCommit,
      branch:  ORCH_BRANCH,
      variant: 'codex',
    },
  };

  writeFileSync(join(CODEX_DIR, 'version.json'), JSON.stringify(versionData, null, 2), 'utf-8');

  console.log('');
  console.log('[SYNC-CODEX] Done!');
  console.log(`  Skills (codex-specific) : ${countFiles(join(CODEX_DIR, 'skills'))} files`);
  console.log(`  Agents                  : ${countFiles(join(CODEX_DIR, 'agents'))} files`);
  console.log(`  Scripts                 : ${countFiles(join(CODEX_DIR, 'scripts'))} files`);
  console.log(`  Config                  : ${existsSync(join(CODEX_DIR, 'config.toml')) ? 'config.toml' : '(none)'}`);
  console.log('');
  console.log('  Note: shared skills (29) are in bundled/shared/skills/ (managed by sync-bundled).');

} finally {
  if (existsSync(TEMP_DIR)) {
    rmSync(TEMP_DIR, { recursive: true, force: true });
  }
}
