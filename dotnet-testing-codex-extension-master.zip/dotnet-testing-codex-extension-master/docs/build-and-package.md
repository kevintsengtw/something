# 打包 VSIX 指南

本文件說明如何從原始碼建置並打包出可安裝的 `.vsix`，供內部 Gitea Release 發佈。

## 前置需求

- **Node.js** >= 18
- 已安裝相依套件：
  ```bash
  npm install
  ```
- package.json 的 `repository.url` 必須是**可被 vsce 偵測的真實 repo URL**（GitHub / GitLab）。
  目前為 `https://github.com/kevintsengtw/dotnet-testing-codex-extension`。
  > ⚠️ 若改回佔位值（例如 `gitea.example.com`），vsce 無法解析 README 內的相對連結
  > （如 `docs/configuration.md`），打包會**中止**並報 `Couldn't detect the repository...`。

## 快速打包

```bash
npm run package
```

產物：`dotnet-testing-codex-agent-<version>.vsix`（`<version>` 取自 package.json 的 `version`）。

`npm run package` 會**自動**先執行 `vscode:prepublish`：

```
npm run check-types    # tsc --noEmit（型別檢查）
node esbuild.mjs --production   # 產出 dist/extension.js（production build）
```

所以**不需要**手動先跑 `npm run compile`。

## 完整流程（建議發版前）

```bash
# 1.（可選）更新 bundled 定義檔到最新來源
npm run sync-bundled          # 共用 skills → bundled/shared/
npm run sync-bundled-codex    # Codex orchestration → bundled/codex/

# 2. 依需要 bump 版本號（package.json 的 "version"）

# 3. 品質檢查
npm run check-types
npm run lint
npm run test                  # 單元測試（不需 VS Code 實例）

# 4. 打包
npm run package
```

> `sync-bundled*` 可加 `--skills-repo` / `--orch-repo` 指向內部 Gitea，或 `--skills-path` / `--orch-path`
> 走本地路徑。詳見 [configuration.md](configuration.md) 的「改變 init 內建來源」附錄。

## 版本號

- `.vsix` 檔名與擴充版本來自 **package.json 的 `version`**。
- 發新版前修改 `version`（遵循 SemVer），再打包。
- 注意：`bundled/*/version.json` 記錄的是 **Skills / Orchestration 定義檔**的版本，與擴充自身
  `version` 是兩回事，各自獨立。

## 產物與安裝

- 產物落在專案根目錄：`dotnet-testing-codex-agent-<version>.vsix`。
- `.vsix` 已被 `.gitignore` 排除，**不會**進 repo。
- 安裝：VS Code 執行「Extensions: Install from VSIX...」選取該檔；或命令列
  `code --install-extension dotnet-testing-codex-agent-<version>.vsix`。

## 打包內容確認（可選）

```bash
npx vsce ls --tree        # 列出將被包入的檔案
```

`.vsix` 內含：`dist/`（打包後的 extension.js）、`package.json`、`README.md`、`resources/`、
`bundled/`（shared + codex 的 skills / agents / scripts / config.toml / version.json）。
**不含** `src/`、`test/`、`node_modules/`（由 `.vscodeignore` 控制）。

## 常見錯誤

| 訊息 | 原因 | 解法 |
| --- | --- | --- |
| `Couldn't detect the repository where this extension is published` | package.json `repository.url` 非真實可偵測 repo，README 相對連結無法解析 | 將 `repository.url` 設為真實 GitHub/GitLab URL |
| `Bundled shared skills 目錄不存在` 類錯誤（執行期） | 打包前未同步 bundled | 先跑 `npm run sync-bundled` / `npm run sync-bundled-codex` |
| 型別錯誤導致打包中止 | `vscode:prepublish` 的 `check-types` 未過 | 先 `npm run check-types` 修正 |

## 發佈

本專案發佈方式為**內部 Gitea Release（.vsix）**，不走 VS Code Marketplace。
打包完成後將 `.vsix` 上傳至內部 Gitea 的對應 Release 即可。
