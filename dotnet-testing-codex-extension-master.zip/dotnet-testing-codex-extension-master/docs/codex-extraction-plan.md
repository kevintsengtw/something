# 抽離獨立 Codex 模式 Extension（內部 Gitea 來源）

## Context（為什麼要做）

目前 `dotnet-testing-vscode-extensions` 是一個**三合一** Extension（Copilot / Claude / Codex 共用同一份原始碼與 VSIX）。公司內部只需要 **Codex 模式**，且 skills 與 orchestration-codex 的來源要從公開 GitHub 改成**公司內部 Gitea**。

需求不只是輸出一份精簡 VSIX，而是要**連原始碼一起抽離成獨立專案**，讓內部 Codex 版本與現有多模式版本**完全切開、各自演進**。

已確認決策：
- **全新乾淨 repo**（只複製 Codex 需要的檔案，git 歷史重新開始）
- **來源改成可設定**（新增設定項，不再硬編碼；保留預設值作 fallback）
- **Gitea 匿名可讀**（免處理 token 認證，只需改 URL 與 API 格式）

關鍵技術事實（探索確認）：
- 內容下載走 `git clone` + **GitHub API 硬編碼**（`release-downloader.ts`、`codex-webview-provider.ts`），這是要改 Gitea 的主戰場。`git clone` 對 Gitea URL 本來就通用，真正要改的只有「解析 latest tag 的 API 呼叫」。
- Gitea 與 GitHub 的 Releases API **JSON 結構相容**（`tag_name`/`html_url`/`body`/`published_at`），parsing 不用改；差別只在 host 與路徑（Gitea 多 `/api/v1`）。
- Codex 的 skills 是**兩段疊加**：先鋪 `bundled/shared/skills/`（來自 `dotnet-testing-agent-skills`），再疊 `bundled/codex/skills/`。所以獨立版**必須連 shared skills 與 `sync-bundled.mjs` 的 shared 部分一起帶走**。
- `getBundledVersion()` 目前讀 `bundled/copilot/version.json` 取得 shared skills 版本 —— 這是跨模式借用，獨立版必須改指向自有來源。

---

## 執行策略：兩階段

### 階段 A — 在新資料夾建立乾淨獨立 repo

在 `dotnet-testing-vscode-extensions` **同層**建立新目錄（例：`dotnet-testing-codex-extension`），`git init`，只複製下列檔案。

**要複製的檔案（Codex 需要的最小集合）**

原始碼：
- `src/extension.ts`（複製後精簡，見階段 B）
- `src/constants.ts`（複製後精簡）
- `src/types.ts`（複製後精簡）
- `src/commands/codex-init.ts`、`src/commands/codex-doctor.ts`
- `src/services/codex-installer.ts`、`src/services/release-downloader.ts`
- `src/services/version-checker.ts`、`src/services/version-check-url.ts`（保留 VSIX 自身更新檢查）
- `src/views/codex-webview-provider.ts`、`src/views/codex-webview-html.ts`
- `src/views/about-webview-provider.ts`、`src/views/about-webview-html.ts`（版本資訊面板，重寫成 Codex-only）
- `src/utils/`：`logger.ts`、`shell.ts`、`file-deploy.ts`、`path-resolver.ts`、`toml-merge.ts`、`semver.ts`

腳本與打包設定：
- `esbuild.mjs`、`tsconfig.json`、`tsconfig.test.json`、`.eslintrc.json`、`.vscodeignore`
- `scripts/sync-bundled-codex.mjs`
- `scripts/sync-bundled.mjs`（**只保留 / 精簡成同步 shared skills 的部分**，供 `bundled/shared/skills/` 與 version.json）
- `package.json`（複製後大改，見階段 B）

Bundled 資源：
- `bundled/shared/skills/`（整包）
- `bundled/codex/`（整包）
- **新增** `bundled/shared/version.json`（取代對 `bundled/copilot/version.json` 的依賴，見階段 B 第 4 點）

其他：
- `resources/icon.png`、`resources/beaker.svg`（Activity Bar 容器圖示）、`resources/walkthrough-*.svg`（若保留 walkthrough）
- `README.md`、`CHANGELOG.md`、`CLAUDE.md`（全部重寫成 Codex-only 敘述）

**不要複製**：`bundled/copilot/`、`bundled/claude/`、所有 Copilot/Claude 的 `src/commands`、`src/services`、`src/views`、`resources/claude-agent.svg`、`scripts/sync-bundled-claude.mjs`、`src/state.ts`（Codex 未使用）、`test/` 中 Copilot/Claude 專屬測試。

### 階段 B — 精簡程式碼 + Gitea 來源可設定改造

---

## 改造細節

### 1. `package.json` 精簡與重新識別

- 頂層識別：改 `name`（例 `dotnet-testing-codex-agent`）、`displayName`、`publisher`、`description`、`repository`（指向新的內部 Gitea repo）、`version` 重設為 `0.1.0`。
- `contributes.commands`：只留 `dta.codex.init`、`dta.codex.doctor`、`dta.openExternalUrl`。刪除所有 `dta.init/doctor/status/rebuildIndex/checkIndex`、`dta.claude.*`。
- `contributes.views`：只留 `dta.codex.webview` 與 `dta.about`（版本資訊）。刪除 `dta.webview`、`dta.claude.webview`。保留 viewsContainer `dta-explorer`。
- **刪除 `contributes.mcpServerDefinitionProviders`**（Codex 不用 MCP/RAG）。
- `contributes.walkthroughs`：改寫成 Codex 導向（步驟改為 `dta.codex.init` / `dta.codex.doctor` / 開啟 Codex CLI），或直接刪除。
- `contributes.configuration`：只留 `dta.codex.skillsVersion`、`dta.giteaUrl`、`dta.giteaRepo`、`dta.checkUpdatesOnStartup`，**新增**（見第 3 點）：`dta.codex.skillsRepo`、`dta.codex.orchRepo`。刪除 `dta.npmRegistry`、`dta.ragDbPath`、`dta.shellExecutable`、`dta.mcpInstallMode`、`dta.skillsVersion`、`dta.orchVersion`、`dta.claude.skillsVersion`。
- `scripts`：刪 `sync-bundled-claude`；保留 `sync-bundled`（shared skills）與 `sync-bundled-codex`。

### 2. `src/extension.ts` 精簡

只保留 Codex + 共用骨架。刪除 Copilot 區塊（MCP provider 註冊 L161-218、`dta.init/doctor/...` 命令 L221-252、DtaWebviewProvider、reportProvider、npx 路徑解析 L148-159）與 Claude 區塊（L15/18/25-26/45-48/70/89-92/118/128-129/254-261）。

保留：Logger/Shell/PathResolver/ReleaseDownloader 建構、`CodexInstaller`、`CodexWebviewProvider`、`AboutWebviewProvider`（改 Codex-only）、Codex context keys 與兩個命令註冊、延遲版本檢查。

### 3. Gitea 來源可設定（核心變更）

**新增設定**（`package.json` configuration）：
- `dta.codex.skillsRepo`：string，預設 = 現值 `https://github.com/kevintsengtw/dotnet-testing-agent-skills`（或直接填內部 Gitea URL）
- `dta.codex.orchRepo`：string，預設 = 現值 `https://github.com/kevintsengtw/dotnet-testing-agent-orchestration-codex`

**`src/constants.ts`**：把 `SKILLS_GITHUB_REPO`、`CODEX_ORCH_GITHUB_REPO` 保留為「預設值常數」（例改名 `DEFAULT_SKILLS_REPO` / `DEFAULT_CODEX_ORCH_REPO`）。刪除 `ORCH_GITHUB_REPO`、`CLAUDE_ORCH_GITHUB_REPO`、`OFFLINE_MODEL_*`、Copilot/Claude 區塊、RAG/MCP 相關常數。`EXTENSION_GITHUB_REPO` 改成內部 Gitea 的擴充發佈 repo（或沿用 `dta.giteaUrl`/`dta.giteaRepo` 機制）。

**`src/services/codex-installer.ts`**：constructor 或各方法讀取設定決定 repoUrl：
```ts
private get skillsRepo(): string {
  return vscode.workspace.getConfiguration().get<string>('dta.codex.skillsRepo')?.trim()
    || DEFAULT_SKILLS_REPO;
}
private get orchRepo(): string { /* dta.codex.orchRepo || DEFAULT_CODEX_ORCH_REPO */ }
```
把所有 `SKILLS_GITHUB_REPO` / `CODEX_ORCH_GITHUB_REPO` 的引用（L75/83/197/199/204/206/228/230）換成 `this.skillsRepo` / `this.orchRepo`。
（附帶修掉現有 bug：`dta.codex.skillsVersion` 目前宣告但沒被讀取 —— 一併把 `resolveTag(..., 'latest')` 的 `'latest'` 改為讀設定值。）

### 4. `src/services/release-downloader.ts` — GitHub/Gitea 雙相容（關鍵）

`git clone`（L64-67）不動。改兩個地方讓它 host-aware：

- `extractOwnerRepo`（L27-31）：正則從只認 `github\.com` 改成通用 host：
  `repoUrl.match(/^https?:\/\/[^/]+\/([^/]+\/[^/.]+)/)`（抓 host 後第一段 owner/repo）。
- 新增 `buildReleaseApiUrl(repoUrl)`：解析 host，github.com → `https://api.github.com/repos/{ownerRepo}/releases/latest`；其他（Gitea）→ `https://{host}/api/v1/repos/{ownerRepo}/releases/latest`。
- `resolveTag`（L34-48）：把硬編碼的 `https://api.github.com/...`（L37）換成 `buildReleaseApiUrl(repoUrl)`。錯誤訊息「GitHub API」改成中性字眼。

因 Gitea 匿名可讀，**不需帶認證 header**。

### 5. `src/views/codex-webview-provider.ts` — 同步 host-aware

`fetchRelease`（L97-111）與 `fetchSkillsRelease`（L113-127）目前也是硬組 `github.com` 正則 + `api.github.com`。改為：讀設定拿 repoUrl（`this.orchRepo` / `this.skillsRepo`，來源同第 3 點），再用與 downloader 相同的 `buildReleaseApiUrl` 邏輯組 API URL。建議把 `buildReleaseApiUrl` 抽成共用 util（例 `src/utils/release-api.ts`），downloader 與 webview 共用，避免兩份邏輯分歧。

### 6. `getBundledVersion()` 跨模式借用解除

`codex-installer.ts` L43-53 目前讀 `bundled/copilot/version.json`。獨立版沒有 copilot 目錄 —— 改讀新的 `bundled/shared/version.json`（由精簡後的 `sync-bundled.mjs` 產出）。同步更新 `constants.ts` 的 `BUNDLED_COPILOT_VERSION_FILE` → `BUNDLED_SHARED_VERSION_FILE`（`path.join('shared','version.json')`）。

### 7. dev-time sync 腳本改 Gitea

`scripts/sync-bundled.mjs`（repo URL L31-32、GitHub API L67）與 `scripts/sync-bundled-codex.mjs`（`ORCH_REPO_URL` L33）：把來源改成內部 Gitea，並讓 API tag 解析走 Gitea `/api/v1`。兩腳本已支援 `--skills-path` / `--orch-path` 走本地路徑，可作過渡。並讓 `sync-bundled.mjs` 額外產出 `bundled/shared/version.json`（供第 6 點）。

### 8. `src/types.ts` 精簡

只留 `CodexManifest`、`InitStepResult`、`DiagnosticCheck`、`DiagnosticResult`、`ShellResult`、`VersionDrift`、`LatestRelease`。刪 `Manifest`、`ClaudeManifest`、`DeployResult`、`McpConfig`、`McpServerConfig`、`BundledVersion`、`RagInfo`、`IndexVerifyResult`。

### 9. `path-resolver.ts` 精簡

Codex 只用 `getWorkspacePath()`。移除 RAG/MCP 相關方法（`getDefaultDbPath`、`getMcpDbPathValue`、`toWindowsJsonPath`、`resolveRealPath`、`getUserDataPath`）與其常數依賴（`USER_DATA_DIR`、`WS_DB_PATH`）。

---

## 驗證

在新的獨立 repo 內：

1. **同步 bundled**：`npm run sync-bundled`（shared skills + `bundled/shared/version.json`）與 `npm run sync-bundled-codex`（先用 GitHub 或 `--orch-path` 本地驗證，再切 Gitea）。確認 `bundled/shared/skills/`、`bundled/codex/agents|scripts|skills`、`config.toml`、兩個 `version.json` 都存在。
2. **型別 + 打包**：`npm run check-types` 過、`npm run compile` 產出 `dist/extension.js` 無 Copilot/Claude 殘留 import。`npm run lint` 過。
3. **Gitea 來源實測**：在測試 workspace 設定 `dta.codex.skillsRepo` / `dta.codex.orchRepo` 指向內部 Gitea，執行 `dta.codex.init`，確認：
   - `resolveTag` 對 Gitea 回傳正確 tag（觀察 Output channel log）
   - `git clone` 從 Gitea 成功、`.codex/skills|agents|scripts|config.toml` 正確部署
   - `manifest-codex.json` 版本號正確
   - webview「查看最新 release」（fetchOrchRelease/fetchSkillsRelease）打 Gitea API 成功顯示
4. **doctor**：執行 `dta.codex.doctor`，6 項檢查（Node、`.codex/skills`、`.codex/agents`、`config.toml`、`.codex/scripts`、`codex --version`）全綠，一鍵自動修復可運作。
5. **VSIX 打包**：`npm run package` 產出 `.vsix`，安裝到乾淨 VS Code，確認只出現 Codex 面板與命令、無 Copilot/Claude/RAG 殘留，Activity Bar 圖示正常。
6. **離線 fallback**：斷網或設定不可達的 repo URL，`dta.codex.init` 應退回 bundled 部署並顯示警告。

---

## 風險與注意

- **shared skills 相依鏈**：忘記帶 `bundled/shared/skills/` 或 `sync-bundled.mjs` 會導致 `deploySkills` 直接丟錯。這是最容易漏的一環。
- **兩份 API 組 URL 邏輯**（downloader + webview）務必抽成共用 util，否則改 Gitea 時容易只改一半。
- **Windows 優先原則不變**：`child_process` 用 `cmd.exe`、路徑用 `path` module（沿用現有 `shell.ts`）。
- 現有多模式 repo **完全不動**，兩者從此獨立演進。
