# 設定指南：更換 Skills / Orchestration 來源 Repo

本文件說明如何調整 Extension 設定，把 **Agent Skills** 與 **Codex Orchestration** 的來源
從內建預設（GitHub）改為公司內部 Gitea，或釘選特定版本。

> 只討論來源 repo 相關的 Extension 設定（VS Code `settings.json` 的 `dta.codex.*`）。
> `.codex/config.toml` 平台設定的調整不在本文件範圍。

## 三個設定項

| Key | 型別 | 預設值 | 說明 |
| --- | --- | --- | --- |
| `dta.codex.skillsRepo` | string | GitHub 預設 | Agent Skills 來源 repo URL |
| `dta.codex.orchRepo` | string | GitHub 預設 | Codex Orchestration 來源 repo URL |
| `dta.codex.skillsVersion` | string | `latest` | Skills 下載部署的版本 tag |

預設值（`constants.ts`）：

- `skillsRepo` → `https://github.com/kevintsengtw/dotnet-testing-agent-skills`
- `orchRepo` → `https://github.com/kevintsengtw/dotnet-testing-agent-orchestration-codex`

留空則自動回退到上述 GitHub 預設值。

## ⚠️ 先搞懂：這些設定影響「線上更新」，不是 init

本 Extension 的部署策略是 **Bundle 初始化 + Online 背景更新**：

- **`dta.codex.init`（初始化）**：從 Extension 內建的 `bundled/` 直接部署，**完全不讀這三個設定**，
  也不連網。所以改了 `skillsRepo` / `orchRepo` **不會**改變 init 部署的內容。
- **線上更新 / 立即更新**：初始化完成後的背景版本檢查，以及使用者按下「立即更新」時，才會
  依這三個設定去對應 repo 的 Release 下載並覆蓋 `.codex/`。

換句話說：

| 你想達成的目標 | 該動的地方 |
| --- | --- |
| 讓「更新」抓公司內部 Gitea 的最新定義檔 | 設 `dta.codex.skillsRepo` / `dta.codex.orchRepo`（本文件） |
| 讓「init 一開始就用」內部來源的內容 | 用 `--skills-repo` / `--orch-repo` 重新 sync bundled 並重打包 `.vsix`（見文末） |

## 調整方式

### 方法 A：VS Code 設定 UI（推薦）

1. `Ctrl+,` 開啟設定。
2. 搜尋 `dta.codex`。
3. 在 `Skills Repo` / `Orch Repo` / `Skills Version` 欄位填入值。

三個設定皆為 window scope，可設在 **User**（全域）或 **Workspace**（`.vscode/settings.json`，僅此專案）。
建議放 Workspace，讓同一專案的成員共用相同來源。

### 方法 B：直接編輯 `settings.json`

指向公司內部 Gitea：

```jsonc
{
  "dta.codex.skillsRepo": "https://gitea.company.com/dotnet-testing/dotnet-testing-agent-skills",
  "dta.codex.orchRepo":   "https://gitea.company.com/dotnet-testing/dotnet-testing-agent-orchestration-codex"
}
```

留空或不設 → 使用 GitHub 預設值：

```jsonc
{
  "dta.codex.skillsRepo": "",
  "dta.codex.orchRepo":   ""
}
```

## GitHub / Gitea 雙相容說明

- 下載機制為 `git clone` ＋「解析 latest tag 的 Releases API」。API URL 依 host 自動選用：
  - GitHub → `https://api.github.com/repos/{owner}/{repo}/releases/latest`
  - Gitea → `{scheme}://{host}/api/v1/repos/{owner}/{repo}/releases/latest`
- 兩者 Releases API 的 JSON 結構相容，parsing 共用。
- 假設內部 Gitea repo **匿名可讀**，不帶認證 header。若日後需私有存取，需另行注入 token。

## 版本釘選：`dta.codex.skillsVersion`

- 預設 `latest`：更新時抓 Skills 的最新 release。
- 設成特定 tag（例如 `v2.4.1`）：`deploySkillsFromRelease` 下載部署時會釘選該版本。
- 注意：**版本「檢查」一律查 `latest`**（不受釘選影響），只有實際「下載部署」才套用此 tag。
- Orchestration（`orchRepo`）**一律取 `latest`**，沒有對應的釘選設定。

## 驗證

1. 改完設定後，若要立即套用最新來源，執行 Codex 面板的「立即更新」（或等背景檢查提示）。
2. 部署後可執行 **Codex 環境診斷**（`dta.codex.doctor`）確認 `.codex/` 內容正常。
3. 來源與版本記錄可查 workspace 的 `.dotnet-testing-agent/manifest-codex.json`。

## 附錄：改變「init 內建來源」

若要讓 init 一開始部署的內容就來自內部 Gitea，需在**打包階段**重新同步 bundled：

```bash
npm run sync-bundled -- --skills-repo https://gitea.company.com/dotnet-testing/dotnet-testing-agent-skills
npm run sync-bundled-codex -- --orch-repo https://gitea.company.com/dotnet-testing/dotnet-testing-agent-orchestration-codex
npm run package   # 重新產生 .vsix
```

（`--skills-path` / `--orch-path` 可改走本地路徑。）這條路徑決定 `.vsix` 內建、離線可用的基準內容；
執行期的 `dta.codex.*` 設定則只影響安裝後的線上更新。
