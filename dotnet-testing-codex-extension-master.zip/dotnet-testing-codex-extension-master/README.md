# dotnet-testing Codex Agent 工具包

> 一鍵設定 Codex CLI 輔助 .NET 測試開發環境的 VS Code Extension（Codex 模式專用）

本專案為 Codex 模式的獨立版本，由多模式版本 `dotnet-testing-vscode-extensions` 抽離而來，**只保留 Codex 模式**，並支援將 skills / orchestration-codex 的來源指向**公司內部 Gitea**。

## 功能

- **一鍵初始化**：`dta.codex.init` 部署 Skills、Orchestration Agents、平台設定與 token 估算 scripts 到 workspace 的 `.codex/`。
- **環境診斷**：`dta.codex.doctor` 檢查 Node.js、`.codex/` 各項內容與 Codex CLI，並可一鍵自動修復。
- **離線初始化 + 線上背景更新**：`init` 直接部署內建 bundled 定義檔（不需網路、快速可靠）；初始化完成後於背景檢查來源 Release，有新版時可一鍵「立即更新」拉取最新定義檔。
- **來源可設定**：透過設定將 skills / orchestration 來源改為公司內部 Gitea（GitHub / Gitea 雙相容，匿名讀取）。
- **側邊欄面板**：版本資訊 + Codex 模式面板（總覽 / Skills / Orchestration）。

## 安裝

從內部 Gitea Release 下載 `.vsix`，於 VS Code 執行「Extensions: Install from VSIX...」。

## 使用

1. 開啟 .NET 專案資料夾。
2. 執行命令 **初始化 Codex Agent 環境**（`dta.codex.init`）。
3. 於終端機啟動 Codex CLI，輸入測試需求。
4. 需要時執行 **Codex 環境診斷**（`dta.codex.doctor`）。

## 指向內部 Gitea

在 VS Code 設定中：

```jsonc
{
  "dta.codex.skillsRepo": "https://gitea.company.com/dotnet-testing/dotnet-testing-agent-skills",
  "dta.codex.orchRepo":   "https://gitea.company.com/dotnet-testing/dotnet-testing-agent-orchestration-codex"
}
```

留空則使用內建 GitHub 預設值。假設內部 Gitea repo 匿名可讀（免 token）。

## 設定項

| Key | 預設值 | 說明 |
| --- | --- | --- |
| `dta.codex.skillsRepo` | GitHub 預設 | Skills 來源 repo URL |
| `dta.codex.orchRepo` | GitHub 預設 | Codex Orchestration 來源 repo URL |
| `dta.codex.skillsVersion` | `latest` | Skills 部署版本 tag |
| `dta.giteaUrl` / `dta.giteaRepo` | `""` | Extension 自身版本檢查來源 |
| `dta.checkUpdatesOnStartup` | `true` | 啟動時檢查更新 |

更換 Skills / Orchestration 來源 repo（指向內部 Gitea、版本釘選）的完整說明見 [docs/configuration.md](docs/configuration.md)。

## 開發

見 `CLAUDE.md`。核心指令：

```bash
npm install
npm run sync-bundled        # 同步共用 skills → bundled/shared/
npm run sync-bundled-codex  # 同步 Codex orchestration → bundled/codex/
npm run compile             # 型別檢查 + 打包
npm run test                # 單元測試
npm run package             # 產生 .vsix
```

打包 `.vsix` 的完整步驟、前置條件與常見錯誤見 [docs/build-and-package.md](docs/build-and-package.md)。

## 授權

MIT
