# 國泰世華銀行外幣匯率即時抓取系統

[![.NET](https://img.shields.io/badge/.NET-9.0-blue.svg)](https://dotnet.microsoft.com/)
[![SQL Server](https://img.shields.io/badge/SQL%20Server-2019+-orange.svg)](https://www.microsoft.com/sql-server)
[![Redis](https://img.shields.io/badge/Redis-7.0+-red.svg)](https://redis.io/)

> 自動化抓取國泰世華銀行外幣匯率資料，提供 RESTful API 服務

## 📋 專案概述

### 🎯 專案目標

建立一個高可用性的自動化系統，定期抓取國泰世華銀行網站上的16種外幣即期匯率資料，並提供高效能的 WebAPI 服務供使用者查詢即時和歷史匯率資料。

### 📊 支援幣別 (16種外幣)

- 🇺🇸 美元 (USD) / 🇪🇺 歐元 (EUR) / 🇯🇵 日圓 (JPY) / 🇨🇳 人民幣 (CNY)
- 🇭🇰 港幣 (HKD) / 🇦🇺 澳大利亞幣 (AUD) / 🇳🇿 紐西蘭幣 (NZD) / 🇿🇦 南非幣 (ZAR)
- 🇨🇦 加拿大幣 (CAD) / 🇬🇧 英鎊 (GBP) / 🇨🇭 瑞士法郎 (CHF) / 🇸🇪 瑞典幣 (SEK)
- 🇸🇬 新加坡幣 (SGD) / 🇹🇭 泰國幣 (THB) / 🇩🇰 丹麥幣 (DKK) / 🇹🇷 土耳其里拉 (TRY)

### 🔗 資料來源

- **來源網站**: [國泰世華銀行外幣牌告](https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/)
- **更新頻率**: 工作日 08:30-16:30 不定時更新
- **抓取策略**: 每 5 分鐘自動抓取一次 (Cron: `0 */5 8-16 * * 1-5`)

---

## 🚀 Phase 1 已完成功能 ✅

### 🏗️ **基礎架構建置**
- ✅ **Clean Architecture 分層架構**
  - Domain Layer (領域層)
  - Application Layer (應用層) 
  - Infrastructure Layer (基礎設施層)
  - API Layer (介面層)
  - BackgroundServices Layer (背景服務層)

- ✅ **資料庫設計與實作**
  - SQL Server 資料庫建立
  - ExchangeRates 資料表設計 (主鍵: CurrencyCode + BoardDate)
  - Dapper ORM 資料存取實作
  - 資料庫初始化機制

### 🌐 **網頁抓取系統**
- ✅ **Web Scraping 核心功能**
  - HttpClientFactory 整合 (解決 DNS 和 Socket 問題)
  - HtmlAgilityPack 網頁解析
  - 16種外幣匯率資料提取
  - 容錯機制與重試策略

- ✅ **背景服務實作**
  - ExchangeRateScrapingService 定時抓取服務
  - Cron 表達式排程 (工作日 8-16 點，每 5 分鐘)
  - 可配置的啟動行為 (RunOnStartup 開發/生產環境區分)

### 📡 **RESTful API 服務**

- ✅ **API 端點實作**

  ```http
  GET  /api/exchangerates/latest          - 取得所有最新匯率
  GET  /api/exchangerates/latest/{code}   - 取得特定幣別最新匯率
  POST /api/exchangerates/scrape          - 手動觸發匯率抓取
  GET  /health                            - 健康檢查
  GET  /swagger                           - API 文件介面
  ```

- ✅ **API 配置優化**
  - Swagger UI 整合
  - Kestrel 自訂端口配置 (HTTP: 8080, HTTPS: 8443)
  - 結構化回應格式

### 🗄️ **資料處理機制**
- ✅ **匯率資料更新邏輯**
  - 智慧更新機制 (先刪除同幣別當日資料，再插入新資料)
  - 資料完整性保證
  - 歷史資料保留機制

- ✅ **時間處理統一化**
  - TimeProvider 統一時間管理
  - UTC/本地時間明確區分
  - 可測試的時間處理架構

### 📝 **日誌與監控**
- ✅ **Serilog 結構化日誌**
  - Console + File 雙重輸出
  - 環境別日誌級別配置
  - 詳細的操作追蹤日誌

### 🔧 **開發工具整合**
- ✅ **開發環境配置**
  - launchSettings.json 多環境設定
  - appsettings 環境別配置
  - 開發除錯友善設定

---

## 🎯 Phase 2 階段目標 (下個階段)

### 🚀 **多層級快取系統**

#### 📦 **快取架構設計**

```
┌─────────────────────────────────────────────────────────────┐
│                    API Request                              │
└─────────────────────┬───────────────────────────────────────┘
                      │
              ┌───────▼───────┐
              │ Level 1 Cache │ ◄── Redis (分散式快取)
              │ (Redis)       │
              └───────┬───────┘
                      │ Cache Miss
              ┌───────▼───────┐
              │ Level 2 Cache │ ◄── Memory Cache (本地快取)
              │ (In-Memory)   │
              └───────┬───────┘
                      │ Cache Miss
              ┌───────▼───────┐
              │ Database      │ ◄── SQL Server (最終資料源)
              │ (SQL Server)  │
              └───────────────┘
```

#### 🎯 **核心目標功能**

##### 1. **🔄 多層級快取讀取策略**
- ⭐ **優先讀取順序**: Redis Cache → Memory Cache → Database
- ⭐ **Fallback 機制**: Redis 連線異常時自動降級到 Memory Cache
- ⭐ **快取穿透防護**: 同一時間同一快取鍵只允許一個請求建立快取

##### 2. **📊 Redis 分散式快取實作**
- ⭐ **Redis 客戶端整合**: StackExchange.Redis
- ⭐ **快取資料結構**: JSON 序列化匯率資料
- ⭐ **TTL 策略**: 設定合適的過期時間
- ⭐ **快取鍵設計**: 結構化快取鍵命名規範

##### 3. **💾 Memory Cache 本地快取**
- ⭐ **IMemoryCache 整合**: ASP.NET Core 內建快取
- ⭐ **快取容量管理**: 設定記憶體使用上限
- ⭐ **LRU 策略**: 最近最少使用資料淘汰機制

##### 4. **🏥 Redis 健康監控服務**
```csharp
RedisHealthCheckBackgroundService
├── 每分鐘 Ping Redis 連線
├── 連線狀態追蹤 (Healthy/Unhealthy)
├── 故障自動切換到 Memory Cache
└── 復原時自動切回 Redis
```

##### 5. **🔄 快取同步更新機制**

```mermaid
flowchart TD
    A[Web Scraping 抓取匯率] --> B[資料驗證 & 處理]
    B --> C[寫入 Database]
    C --> D{Database 寫入成功?}
    
    D -->|失敗| E[記錄錯誤日誌]
    D -->|成功| F[觸發快取更新事件]
    
    F --> G[更新 Redis Cache]
    G --> H{Redis 更新成功?}
    
    H -->|失敗| I[Redis 連線異常<br/>標記為 Unhealthy]
    H -->|成功| J[更新 Memory Cache]
    
    I --> J
    J --> K[快取更新完成]
    
    K --> L[發送通知事件]
    L --> M[記錄更新日誌]
    
    style A fill:#e1f5fe
    style C fill:#f3e5f5
    style G fill:#fff3e0
    style J fill:#e8f5e8
    style K fill:#c8e6c9
```

**更新策略:**
- 🔄 **先寫後更新**: Database → Redis → Memory Cache
- 🛡️ **容錯機制**: Redis 失敗時仍會更新 Memory Cache
- 📝 **事件驅動**: 使用事件通知機制確保快取一致性
- 🔒 **原子操作**: 確保快取更新的完整性

##### 6. **🔐 快取一致性保證**
- ⭐ **分散式鎖機制**: 防止快取雪崩
- ⭐ **原子操作**: 確保快取與資料庫一致性
- ⭐ **版本控制**: 快取版本標記機制

#### 🛠️ **技術實作規劃**

##### 📦 **新增 NuGet 套件**
```xml
<PackageReference Include="StackExchange.Redis" Version="2.7.20" />
<PackageReference Include="Microsoft.Extensions.Caching.Memory" Version="9.0.0" />
<PackageReference Include="Microsoft.Extensions.Caching.StackExchangeRedis" Version="9.0.0" />
```

##### 🏗️ **新增服務類別**
- `IHybridCacheService` - 混合快取服務介面
- `HybridCacheService` - 多層級快取實作
- `RedisHealthCheckBackgroundService` - Redis 監控服務
- `CacheKeyManager` - 快取鍵管理器
- `CacheSettings` - 快取配置類別

##### ⚙️ **配置檔設定**
```json
{
  "CacheSettings": {
    "Redis": {
      "ConnectionString": "localhost:6379",
      "DefaultExpiration": "00:15:00",
      "EnableCompression": true
    },
    "Memory": {
      "SizeLimit": 100,
      "DefaultExpiration": "00:05:00"
    },
    "HealthCheck": {
      "Interval": "00:01:00",
      "Timeout": "00:00:05"
    }
  }
}
```

##### 🔧 **API 端點增強**
```
GET /api/cache/status           - 快取系統狀態
GET /api/cache/stats            - 快取統計資訊
DELETE /api/cache/clear         - 清除快取 (管理員功能)
GET /api/health/redis           - Redis 連線健康檢查
```

#### 📈 **效能與監控目標**
- ⚡ **API 回應時間**: < 100ms (快取命中)
- 🎯 **快取命中率**: > 90%
- 🔄 **Redis 可用性**: > 99.9%
- 📊 **記憶體使用率**: < 80%

#### 🧪 **測試策略**
- **單元測試**: 快取邏輯測試
- **整合測試**: Redis 連線測試
- **效能測試**: 快取效能基準測試
- **容錯測試**: Redis 故障模擬測試

---

## 🛠️ 技術棧

### 🏗️ **後端架構**
- **.NET 9.0** - 最新 LTS 框架
- **ASP.NET Core 9** - Web API 框架
- **C# 13** - 程式語言

### 🗄️ **資料儲存**
- **SQL Server 2019+** - 主要資料庫
- **Redis 7.0+** - 分散式快取 (Phase 2)
- **Memory Cache** - 本地快取 (Phase 2)

### 📦 **主要 NuGet 套件**
```xml
<!-- 資料存取 -->
<PackageReference Include="Dapper" Version="2.1.66" />
<PackageReference Include="Microsoft.Data.SqlClient" Version="5.1.2" />

<!-- 網頁抓取 -->
<PackageReference Include="HtmlAgilityPack" Version="1.11.54" />

<!-- 背景服務 -->
<PackageReference Include="Cronos" Version="0.8.4" />
<PackageReference Include="Sgbj.Cron" Version="2.0.1" />

<!-- 日誌系統 -->
<PackageReference Include="Serilog.AspNetCore" Version="9.0.0" />
<PackageReference Include="Serilog.Sinks.Console" Version="6.0.0" />
<PackageReference Include="Serilog.Sinks.File" Version="9.0.0" />

<!-- 時間處理 -->
<PackageReference Include="Microsoft.Bcl.TimeProvider" Version="8.0.1" />
```

---

## 🚀 快速開始

### 📋 **環境需求**
- .NET 9.0 SDK
- SQL Server 2019+ (或 LocalDB)
- Redis 7.0+ (Phase 2 需要)
- Visual Studio 2022 或 VS Code

### ⚙️ **設定步驟**

1. **複製專案**
```bash
git clone https://github.com/kevintsengtw/CathayBank_RealtimeExchangeRate.git
cd CathayBank_RealtimeExchangeRate
```

2. **資料庫設定**
```bash
# 更新 src/Api/appsettings.Development.json 中的連線字串
"ConnectionStrings": {
  "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=CathayBankExchangeRate;Trusted_Connection=true;"
}
```

3. **建置並執行**
```bash
cd src/Api
dotnet restore
dotnet build
dotnet run
```

4. **存取 API**
- Swagger UI: http://localhost:8080/swagger
- Health Check: http://localhost:8080/health
- Latest Rates: http://localhost:8080/api/exchangerates/latest

---

## 📚 API 文件

### 📡 **主要端點**

#### 取得所有最新匯率
```http
GET /api/exchangerates/latest
```

**回應範例:**
```json
{
  "success": true,
  "data": [
    {
      "currencyCode": "USD",
      "currencyName": "美元",
      "chineseName": "美元",
      "englishName": "US Dollar",
      "symbol": "$",
      "bankBuyRate": 29.8500,
      "bankSellRate": 29.9700,
      "boardDate": "20250811",
      "boardTime": "160000",
      "createdAt": "2025-08-11T08:00:00Z"
    }
  ],
  "timestamp": "2025-08-11T08:00:00Z"
}
```

#### 取得特定幣別最新匯率
```http
GET /api/exchangerates/latest/{currencyCode}
```

#### 手動觸發匯率抓取
```http
POST /api/exchangerates/scrape
```

---

## 🧪 測試

### 🔧 **執行測試**
```bash
# 執行所有測試
dotnet test

# 執行特定專案測試
dotnet test tests/Unit/
dotnet test tests/Integration/
```

### 📊 **測試涵蓋範圍**
- ✅ 單元測試 (Unit Tests)
- ✅ 整合測試 (Integration Tests)  
- ⏳ 效能測試 (Performance Tests) - Phase 2
- ⏳ 端對端測試 (E2E Tests) - Phase 2

---

## 📈 開發進度

### ✅ **Phase 1 - 基礎功能** (已完成)
- [x] 專案架構建立
- [x] 資料庫設計與實作
- [x] 網頁抓取服務
- [x] 背景定時服務
- [x] RESTful API 開發
- [x] 日誌系統整合
- [x] 基礎監控功能

### 🚧 **Phase 2 - 快取系統** (規劃中)
- [ ] Redis 分散式快取實作
- [ ] Memory Cache 本地快取
- [ ] 多層級快取策略
- [ ] Redis 健康監控服務
- [ ] 快取同步機制
- [ ] 效能監控與優化

### 📅 **Phase 3 - 進階功能** (未來規劃)
- [ ] 使用者認證與授權
- [ ] API 訪問限流
- [ ] 歷史資料分析功能
- [ ] 匯率變動通知機制
- [ ] 管理後台介面
- [ ] Docker 容器化部署

---

## 🤝 參與貢獻

歡迎提交 Issue 和 Pull Request！

### 🔧 **開發流程**
1. Fork 此專案
2. 建立功能分支 (`git checkout -b feature/amazing-feature`)
3. 提交變更 (`git commit -m 'Add amazing feature'`)
4. 推送分支 (`git push origin feature/amazing-feature`)
5. 建立 Pull Request

---

## 📄 授權條款

本專案採用 MIT 授權條款 - 詳見 [LICENSE](LICENSE) 檔案

---

## 👨‍💻 作者

**Kevin Tseng** - [kevintsengtw](https://github.com/kevintsengtw)

---

## 🙏 致謝

- 國泰世華銀行提供的公開匯率資料
- .NET 社群的優秀開源專案
- 所有參與測試和回饋的開發者

---

*最後更新：2025年8月11日*