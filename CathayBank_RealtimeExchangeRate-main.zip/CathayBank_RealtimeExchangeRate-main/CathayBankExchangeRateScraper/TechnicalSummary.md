# 技術摘要 - 國泰世華銀行外幣匯率抓取工具

## 快速開始

### 環境需求
- LINQPad 8
- .NET 8.0
- 網路連線

### 執行步驟
```powershell
# 1. 切換到專案目錄
cd "d:\Github\CathayBank_RealtimeExchangeRate"

# 2. 執行 LINQPad 腳本
LPRun8.exe QuickAnalysis.linq
```

## 核心技術

### 使用的 NuGet 套件
```xml
<NuGetReference>HtmlAgilityPack</NuGetReference>
<NuGetReference>Ardalis.SmartEnum</NuGetReference>
```

### SmartEnum 定義範例
```csharp
public sealed class Currency : SmartEnum<Currency>
{
    public static readonly Currency USD = new("USD", 1, "美元", "US Dollar", "$", 4);
    public static readonly Currency EUR = new("EUR", 2, "歐元", "Euro", "€", 4);
    // ... 其他貨幣
    
    public string Code => Name;
    public string ChineseName { get; }
    public string EnglishName { get; }
    public string Symbol { get; }
    public int DecimalPlaces { get; }
}
```

### HTML 解析關鍵程式碼
```csharp
// 尋找特定貨幣的匯率卡片
var rateCard = document.DocumentNode
    .SelectSingleNode($"//div[contains(@class, 'cubre-o-rateCard') and .//div[contains(text(), '{currency.Code}')]]");

// 提取匯率資料
var rateTable = rateCard.SelectSingleNode(".//table[contains(@class, 'cubre-m-rateTable')]");
var spotRateRow = rateTable.SelectSingleNode(".//tr[.//div[contains(text(), '即期匯率')]]");
```

## 支援的貨幣

| 代號 | 名稱 | 符號 | 小數位 |
|------|------|------|--------|
| USD | 美元 | $ | 4 |
| EUR | 歐元 | € | 4 |
| JPY | 日圓 | ¥ | 2 |
| CNY | 人民幣 | ¥ | 4 |
| HKD | 港幣 | HK$ | 4 |
| AUD | 澳大利亞幣 | A$ | 4 |
| NZD | 紐西蘭幣 | NZ$ | 4 |
| ZAR | 南非幣 | R | 4 |
| CAD | 加拿大幣 | C$ | 4 |
| GBP | 英鎊 | £ | 4 |
| CHF | 瑞士法郎 | CHF | 4 |
| SEK | 瑞典幣 | kr | 4 |
| SGD | 新加坡幣 | S$ | 4 |
| THB | 泰國幣 | ฿ | 4 |
| DKK | 丹麥幣 | kr | 4 |
| TRY | 土耳其里拉 | ₺ | 4 |

## 常見問題解決

### LPRun8.exe 找不到
```powershell
# 重新載入環境變數
$env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")
```

### NuGet 套件問題
- 確保網路連線正常
- 等待套件下載完成
- 必要時重新執行

### 匯率解析失敗
- 檢查網站是否正常
- 確認 HTML 結構未變更
- 檢查網路防火牆設定

## 輸出格式

### 控制台輸出
- 即時處理狀態
- 成功/失敗統計
- 匯率摘要表格
- SmartEnum 功能演示

### T-SQL 腳本
- 完整的 INSERT 語句
- 交易控制 (BEGIN/COMMIT)
- 資料表建立腳本
- 驗證查詢

## 架構演進

1. **Dictionary<string, string>** → 簡單但缺乏型別安全
2. **CurrencyInfo 類別** → 改善型別安全和可讀性  
3. **SmartEnum** → 最佳實務，強型別枚舉

## 效能指標

- **抓取成功率**: 16/16 (100%)
- **執行時間**: ~3-5 秒
- **網頁大小**: ~194KB
- **記憶體使用**: 低 (<50MB)

---

**專案位置**: `d:\Github\CathayBank_RealtimeExchangeRate\`  
**主要檔案**: `QuickAnalysis.linq`  
**文件**: `README.md`  
**更新日期**: 2025年8月2日
