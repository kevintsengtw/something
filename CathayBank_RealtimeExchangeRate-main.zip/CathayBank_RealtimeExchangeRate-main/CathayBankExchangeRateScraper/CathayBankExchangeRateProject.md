# 國泰世華銀行外幣匯率抓取工具

## 專案概述

本專案開發了一個自動化工具，用於抓取國泰世華銀行網站上的 16 種外幣即期匯率資料，並產生可直接執行的 T-SQL INSERT 腳本。專案從最初的簡單 Dictionary 結構演進到使用 SmartEnum 的強型別設計，展現了現代 .NET 開發的最佳實務。

## 技術架構

### 核心技術棧
- **.NET 8.0** - 主要開發平台
- **C# 12.0** - 程式語言與最新語法特性
- **HtmlAgilityPack 1.11.54** - HTML 解析與 DOM 操作
- **Ardalis.SmartEnum** - 強型別枚舉實作
- **LINQPad 8** - 開發與執行環境
- **HttpClient** - HTTP 請求處理

### 資料來源
- **目標網站**: https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/
- **資料格式**: HTML 網頁，使用 CSS 類別結構化匯率資訊
- **更新頻率**: 即時匯率資料

## 專案演進歷程

### 第一階段：基礎架構建立

#### 1. 初始版本 - Dictionary<string, string>
```csharp
// 原始簡單結構
private static readonly Dictionary<string, string> CurrencyMap = new()
{
    { "USD", "美元" },
    { "EUR", "歐元" },
    // ... 其他貨幣
};
```

**問題分析**：
- ❌ 型別安全性不足
- ❌ 缺乏編譯時期檢查
- ❌ 擴展性差，難以添加新屬性
- ❌ 語意不明確

#### 2. 改進版本 - 強型別 CurrencyInfo
```csharp
public class CurrencyInfo
{
    public string Code { get; init; } = string.Empty;
    public string ChineseName { get; init; } = string.Empty;
    public string EnglishName { get; init; } = string.Empty;
    public string Symbol { get; init; } = string.Empty;
    public int DecimalPlaces { get; init; } = 4;
}
```

**改進效果**：
- ✅ 提供型別安全性
- ✅ 支援更多貨幣屬性
- ✅ 更好的可讀性

### 第二階段：SmartEnum 重構

#### 3. 最終版本 - Ardalis.SmartEnum
```csharp
public sealed class Currency : SmartEnum<Currency>
{
    public static readonly Currency USD = new("USD", 1, "美元", "US Dollar", "$", 4);
    public static readonly Currency EUR = new("EUR", 2, "歐元", "Euro", "€", 4);
    // ... 其他貨幣定義

    public string Code => Name;
    public string ChineseName { get; }
    public string EnglishName { get; }
    public string Symbol { get; }
    public int DecimalPlaces { get; }
}
```

**SmartEnum 優勢**：
- ✅ 編譯時期型別安全
- ✅ 強型別枚舉語意
- ✅ 內建查詢與比較功能
- ✅ 豐富的屬性支援
- ✅ 避免魔術字串問題

## 網頁抓取技術細節

### HTML 結構分析

國泰世華銀行的匯率頁面使用以下 CSS 類別結構：

```html
<div class="cubre-o-rateCard">
    <!-- 貨幣名稱與代號 -->
    <div>USD</div>
    
    <!-- 匯率表格 -->
    <table class="cubre-m-rateTable">
        <tr>
            <td>即期匯率</td>
            <td>29.9600</td>  <!-- 銀行買進 -->
            <td>30.0800</td>  <!-- 銀行賣出 -->
        </tr>
    </table>
</div>
```

### 抓取演算法

#### 核心解析邏輯
```csharp
private ExchangeRateItem ExtractCurrencyRate(HtmlDocument document, Currency currency, DateTime boardDateTime)
{
    try
    {
        // 1. 尋找包含特定貨幣代號的 rateCard 區塊
        var rateCard = document.DocumentNode
            .SelectSingleNode($"//div[contains(@class, 'cubre-o-rateCard') and .//div[contains(text(), '{currency.Code}')]]");
        
        if (rateCard != null)
        {
            // 2. 在該區塊內尋找匯率表格
            var rateTable = rateCard.SelectSingleNode(".//table[contains(@class, 'cubre-m-rateTable')]");
            
            if (rateTable != null)
            {
                // 3. 定位即期匯率行
                var spotRateRow = rateTable.SelectSingleNode(".//tr[.//div[contains(text(), '即期匯率')]]");
                
                if (spotRateRow != null)
                {
                    var cells = spotRateRow.SelectNodes(".//td");
                    if (cells != null && cells.Count >= 3)
                    {
                        // 4. 提取買進與賣出匯率
                        var buyRateText = cells[1].InnerText?.Trim();
                        var sellRateText = cells[2].InnerText?.Trim();
                        
                        if (decimal.TryParse(buyRateText, out decimal buyRate) && 
                            decimal.TryParse(sellRateText, out decimal sellRate))
                        {
                            return new ExchangeRateItem
                            {
                                Currency = currency,
                                CurrencyCode = currency.Code,
                                CurrencyName = currency.ChineseName,
                                BankBuyRate = buyRate,
                                BankSellRate = sellRate,
                                BoardDateTime = boardDateTime,
                                CreatedAt = DateTime.UtcNow
                            };
                        }
                    }
                }
            }
        }
        
        return null;
    }
    catch (Exception ex)
    {
        Console.WriteLine($"  提取 {currency.Code} 時發生錯誤: {ex.Message}");
        return null;
    }
}
```

#### XPath 查詢策略

1. **貨幣卡片定位**: 使用 `contains(@class, 'cubre-o-rateCard')` 找到貨幣卡片
2. **文字內容匹配**: 透過 `contains(text(), '{currency.Code}')` 精確匹配貨幣代號
3. **層次化查詢**: 使用相對路徑 `.//*` 在特定卡片內搜尋
4. **容錯處理**: 每個步驟都有 null 檢查，確保程式穩定性

### HTTP 請求配置

```csharp
using var httpClient = new HttpClient();
httpClient.DefaultRequestHeaders.Add("User-Agent", 
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");

var response = await httpClient.GetAsync("https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/");
```

**重要配置說明**：
- **User-Agent**: 模擬真實瀏覽器請求，避免被網站封鎖
- **異步處理**: 使用 `async/await` 確保不阻塞執行緒
- **資源管理**: 透過 `using` 語句自動釋放 HttpClient 資源

## LINQPad 8 開發環境

### 環境配置

#### 1. LINQPad 8 安裝
- **下載來源**: https://www.linqpad.net/
- **版本需求**: LINQPad 8.0 或更新版本
- **授權**: 免費版本已足夠基本使用

#### 2. 命令列工具設置
LINQPad 8 提供 `LPRun8.exe` 命令列執行器：

```powershell
# 環境變數設置 (通常安裝後自動配置)
$env:PATH += ";C:\Program Files\LINQPad8\"

# 驗證安裝
LPRun8.exe -help
```

### LINQPad 專案結構

#### Query 設定檔頭
```csharp
<Query Kind="Program">
  <NuGetReference>HtmlAgilityPack</NuGetReference>
  <NuGetReference>Ardalis.SmartEnum</NuGetReference>
  <Namespace>HtmlAgilityPack</Namespace>
  <Namespace>System.Net.Http</Namespace>
  <Namespace>System.Text.RegularExpressions</Namespace>
  <Namespace>System.Threading.Tasks</Namespace>
  <Namespace>System.IO</Namespace>
  <Namespace>System.Linq</Namespace>
  <Namespace>System.Text</Namespace>
  <Namespace>Ardalis.SmartEnum</Namespace>
</Query>
```

**設定說明**：
- `Query Kind="Program"`: 啟用完整程式模式，支援 `Main()` 方法
- `NuGetReference`: 自動下載並引用 NuGet 套件
- `Namespace`: 匯入命名空間，避免完整型別名稱

### 命令列執行

#### 基本執行命令
```powershell
# 執行 .linq 檔案
LPRun8.exe "QuickAnalysis.linq"

# 在特定工作目錄執行
cd "d:\Github\CathayBank_RealtimeExchangeRate"
LPRun8.exe QuickAnalysis.linq
```

#### 進階執行選項
```powershell
# 輸出到檔案
LPRun8.exe QuickAnalysis.linq > output.txt

# 僅顯示最後幾行
LPRun8.exe QuickAnalysis.linq | Select-Object -Last 50

# 背景執行
Start-Process LPRun8.exe -ArgumentList "QuickAnalysis.linq" -WindowStyle Hidden
```

### 環境變數問題處理

#### VS Code 終端機問題
VS Code 內建終端機可能無法自動載入新的環境變數：

```powershell
# 手動重新載入環境變數
$env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")

# 驗證 LINQPad 路徑
$env:PATH -split ";" | Where-Object { $_ -like "*LINQPad*" }
```

**解決方案**：
1. 重新啟動 VS Code
2. 手動重新載入環境變數
3. 使用完整路徑執行 LPRun8.exe

## 資料結構設計

### ExchangeRateItem 類別

```csharp
public class ExchangeRateItem
{
    public Currency Currency { get; set; } = Currency.USD;  // SmartEnum 參考
    public string CurrencyCode { get; set; } = string.Empty;
    public string CurrencyName { get; set; } = string.Empty;
    public decimal BankBuyRate { get; set; }
    public decimal BankSellRate { get; set; }
    public DateTime BoardDateTime { get; set; }
    public DateTime CreatedAt { get; set; }
    
    // 便利屬性：透過 SmartEnum 取得格式化的匯率
    public string FormattedBuyRate => $"{Currency.Symbol}{BankBuyRate:F4}";
    public string FormattedSellRate => $"{Currency.Symbol}{BankSellRate:F4}";
}
```

### 支援的貨幣清單

| 代號 | 中文名稱 | 英文名稱 | 符號 | 小數位數 |
|------|----------|----------|------|----------|
| USD | 美元 | US Dollar | $ | 4 |
| EUR | 歐元 | Euro | € | 4 |
| JPY | 日圓 | Japanese Yen | ¥ | 2 |
| CNY | 人民幣 | Chinese Yuan | ¥ | 4 |
| HKD | 港幣 | Hong Kong Dollar | HK$ | 4 |
| AUD | 澳大利亞幣 | Australian Dollar | A$ | 4 |
| NZD | 紐西蘭幣 | New Zealand Dollar | NZ$ | 4 |
| ZAR | 南非幣 | South African Rand | R | 4 |
| CAD | 加拿大幣 | Canadian Dollar | C$ | 4 |
| GBP | 英鎊 | British Pound | £ | 4 |
| CHF | 瑞士法郎 | Swiss Franc | CHF | 4 |
| SEK | 瑞典幣 | Swedish Krona | kr | 4 |
| SGD | 新加坡幣 | Singapore Dollar | S$ | 4 |
| THB | 泰國幣 | Thai Baht | ฿ | 4 |
| DKK | 丹麥幣 | Danish Krone | kr | 4 |
| TRY | 土耳其里拉 | Turkish Lira | ₺ | 4 |

## T-SQL 腳本產生

### 資料庫表格結構

```sql
CREATE TABLE ExchangeRates (
    Id                BIGINT IDENTITY(1,1) PRIMARY KEY,
    CurrencyCode      NVARCHAR(3) NOT NULL,
    CurrencyName      NVARCHAR(50) NOT NULL,
    BankBuyRate       DECIMAL(18,6) NOT NULL,
    BankSellRate      DECIMAL(18,6) NOT NULL,
    BoardDate         DATE NOT NULL,
    BoardTime         TIME NOT NULL,
    BoardDateTime     DATETIME2 NOT NULL,
    CreatedAt         DATETIME2 DEFAULT GETUTCDATE(),
    UpdatedAt         DATETIME2 DEFAULT GETUTCDATE(),
    CONSTRAINT UQ_ExchangeRates_Unique UNIQUE (CurrencyCode, BoardDateTime)
);
```

### 腳本產生邏輯

```csharp
private string GenerateTSqlScript(List<ExchangeRateItem> exchangeRates)
{
    var sb = new StringBuilder();
    
    // 1. 腳本標頭資訊
    sb.AppendLine("-- ===== 國泰世華銀行外幣匯率資料 INSERT 腳本 =====");
    sb.AppendLine($"-- 產生時間: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
    sb.AppendLine($"-- 資料筆數: {exchangeRates.Count}");
    
    // 2. 資料表建立腳本 (註解形式)
    sb.AppendLine("-- 如果資料表不存在，請先執行以下建立腳本:");
    sb.AppendLine("/* CREATE TABLE ... */");
    
    // 3. 交易控制
    sb.AppendLine("BEGIN TRANSACTION;");
    
    // 4. 批次 INSERT 語句
    sb.AppendLine("INSERT INTO ExchangeRates (...) VALUES");
    
    for (int i = 0; i < exchangeRates.Count; i++)
    {
        var rate = exchangeRates[i];
        var comma = i < exchangeRates.Count - 1 ? "," : ";";
        
        sb.AppendLine($"    ('{rate.CurrencyCode}', N'{rate.CurrencyName}', " +
                     $"{rate.BankBuyRate:F6}, {rate.BankSellRate:F6}, ...){comma}");
    }
    
    // 5. 提交交易與驗證查詢
    sb.AppendLine("COMMIT TRANSACTION;");
    sb.AppendLine("SELECT ... FROM ExchangeRates WHERE ...");
    
    return sb.ToString();
}
```

## 執行結果範例

### 控制台輸出
```
=== 國泰世華銀行外幣匯率抓取工具 ===
執行時間: 2025年08月02日 23:15:01

正在下載網頁...
網頁長度: 194706 字元

=== 開始抓取各幣別匯率 ===

正在處理: USD (美元)
  找到 USD 的 rateCard 區塊
✓ 成功抓取 USD - 買進: 29.9600, 賣出: 30.0800

正在處理: EUR (歐元)
  找到 EUR 的 rateCard 區塊
✓ 成功抓取 EUR - 買進: 34.3500, 賣出: 34.8500

... (其他貨幣)

=== 抓取完成 ===
成功抓取 16/16 種外幣匯率

=== SmartEnum 功能演示 ===
範例貨幣: Australian Dollar (澳大利亞幣)
格式化匯率: 買進 A$19.2200, 賣出 A$19.4800
小數位數設定: 4 位
從代號 'USD' 找到: 美元 ($)
所有支援的貨幣數量: 16
```

### 匯率資料表格
```
┌──────┬────────────┬──────────┬──────────┬─────────────────────┐
│ 代號 │ 幣別名稱   │ 銀行買進 │ 銀行賣出 │ 牌告時間            │
├──────┼────────────┼──────────┼──────────┼─────────────────────┤
│ USD  │ 美元         │  29.9600 │  30.0800 │ 2025-08-02 23:15:01 │
│ EUR  │ 歐元         │  34.3500 │  34.8500 │ 2025-08-02 23:15:01 │
│ JPY  │ 日圓         │   0.2005 │   0.2055 │ 2025-08-02 23:15:01 │
└──────┴────────────┴──────────┴──────────┴─────────────────────┘
```

## 最佳實務與建議

### 程式碼品質

#### 1. 錯誤處理
```csharp
try
{
    // 主要邏輯
}
catch (Exception ex)
{
    Console.WriteLine($"執行失敗: {ex.Message}");
    Console.WriteLine($"詳細錯誤: {ex}");
}
```

#### 2. 資源管理
```csharp
using var httpClient = new HttpClient();  // 自動釋放資源
```

#### 3. 異步程式設計
```csharp
async Task Main()  // 支援異步操作
{
    var response = await httpClient.GetAsync(url);  // 非阻塞請求
}
```

### 效能考量

#### 1. HTTP 請求最佳化
- 重複使用 HttpClient 實例
- 設置適當的 User-Agent
- 考慮加入請求間隔避免過度負載

#### 2. 記憶體使用
- 使用 StringBuilder 建構大型字串
- 及時釋放大型 HTML 文件記憶體
- 考慮串流處理大量資料

#### 3. 錯誤復原
- 實作重試機制處理網路問題
- 記錄詳細錯誤資訊便於除錯
- 提供部分失敗的處理策略

### 安全性考量

#### 1. 輸入驗證
```csharp
if (decimal.TryParse(buyRateText, out decimal buyRate))  // 安全的數值轉換
```

#### 2. SQL 注入防護
- 使用參數化查詢
- 驗證和淨化使用者輸入
- 避免直接字串拼接 SQL

#### 3. 網路安全
- 驗證 SSL 憑證
- 設置請求逾時
- 避免敏感資訊洩露

## 未來擴展規劃

### 短期改進

1. **設定檔支援**: 將貨幣清單與設定外部化
2. **排程執行**: 整合 Windows 工作排程器
3. **資料庫整合**: 直接寫入資料庫而非產生腳本
4. **錯誤通知**: 加入 Email 或 Teams 通知機制

### 中期發展

1. **Web API**: 開發 RESTful API 提供匯率查詢
2. **快取機制**: 實作 Redis 快取減少重複請求
3. **監控儀表板**: 建立即時監控與警示系統
4. **多資料來源**: 整合其他銀行匯率比較

### 長期願景

1. **微服務架構**: 拆分為獨立的微服務
2. **雲端部署**: 遷移至 Azure 或 AWS
3. **機器學習**: 加入匯率預測功能
4. **行動應用**: 開發配套的行動 App

## 故障排除

### 常見問題

#### 1. LPRun8.exe 找不到
```powershell
# 檢查環境變數
$env:PATH -split ";" | Where-Object { $_ -like "*LINQPad*" }

# 手動設置路徑
$env:PATH += ";C:\Program Files\LINQPad8\"
```

#### 2. NuGet 套件下載失敗
- 檢查網路連線
- 確認 NuGet 套件名稱正確
- 嘗試清除 NuGet 快取

#### 3. 網頁結構變更
- 檢查目標網站是否更新
- 使用瀏覽器開發者工具檢查新的 CSS 選擇器
- 更新 XPath 查詢語句

#### 4. 匯率解析失敗
- 驗證數值格式是否變更
- 檢查千分位符號處理
- 確認小數點符號 (. vs ,)

### 除錯技巧

#### 1. 啟用詳細記錄
```csharp
Console.WriteLine($"HTML 長度: {htmlContent.Length}");
Console.WriteLine($"找到的卡片數量: {rateCards.Count}");
```

#### 2. 輸出中間結果
```csharp
// 輸出原始 HTML 片段便於分析
Console.WriteLine($"Rate card HTML: {rateCard.InnerHtml}");
```

#### 3. 使用 LINQPad 互動模式
- 利用 LINQPad 的即時執行功能
- 分步驟測試每個解析階段
- 使用 `.Dump()` 方法檢視物件內容

## 授權與聲明

### 開源授權
本專案採用 MIT 授權條款，允許自由使用、修改和分發。

### 免責聲明
- 本工具僅供學習和研究目的
- 使用者應遵守目標網站的使用條款
- 匯率資料僅供參考，實際交易請以銀行公告為準
- 開發者不對資料準確性或使用後果承擔責任

### 版權聲明
- 匯率資料版權歸國泰世華銀行所有
- 請合理使用，避免對目標網站造成過度負載
- 商業使用前請先取得相關授權

---

## 結語

本專案展示了現代 .NET 開發中的多項最佳實務，從簡單的字典結構演進到使用 SmartEnum 的強型別設計，體現了軟體工程中重構與持續改進的重要性。透過 LINQPad 8 的強大功能，我們能夠快速開發、測試和部署實用的工具程式。

希望這份文件能幫助其他開發者理解網頁抓取、資料處理和現代 C# 開發技術的應用。如有任何問題或建議，歡迎提出討論。

**最後更新**: 2025年8月2日  
**版本**: 1.0.0  
**作者**: GitHub Copilot & 開發團隊
