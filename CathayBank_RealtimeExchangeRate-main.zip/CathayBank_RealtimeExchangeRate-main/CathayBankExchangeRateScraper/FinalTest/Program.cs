using HtmlAgilityPack;
using System.Text;
using Ardalis.SmartEnum;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace FinalTest;

// 使用 SmartEnum 定義貨幣類型
public sealed class Currency : SmartEnum<Currency>
{
    // 16種外幣定義
    public static readonly Currency USD = new("USD", 1, "美元", "US Dollar", "$", 4);
    public static readonly Currency EUR = new("EUR", 2, "歐元", "Euro", "€", 4);
    public static readonly Currency JPY = new("JPY", 3, "日圓", "Japanese Yen", "¥", 2);
    public static readonly Currency CNY = new("CNY", 4, "人民幣", "Chinese Yuan", "¥", 4);
    public static readonly Currency HKD = new("HKD", 5, "港幣", "Hong Kong Dollar", "HK$", 4);
    public static readonly Currency AUD = new("AUD", 6, "澳大利亞幣", "Australian Dollar", "A$", 4);
    public static readonly Currency NZD = new("NZD", 7, "紐西蘭幣", "New Zealand Dollar", "NZ$", 4);
    public static readonly Currency ZAR = new("ZAR", 8, "南非幣", "South African Rand", "R", 4);
    public static readonly Currency CAD = new("CAD", 9, "加拿大幣", "Canadian Dollar", "C$", 4);
    public static readonly Currency GBP = new("GBP", 10, "英鎊", "British Pound", "£", 4);
    public static readonly Currency CHF = new("CHF", 11, "瑞士法郎", "Swiss Franc", "CHF", 4);
    public static readonly Currency SEK = new("SEK", 12, "瑞典幣", "Swedish Krona", "kr", 4);
    public static readonly Currency SGD = new("SGD", 13, "新加坡幣", "Singapore Dollar", "S$", 4);
    public static readonly Currency THB = new("THB", 14, "泰國幣", "Thai Baht", "฿", 4);
    public static readonly Currency DKK = new("DKK", 15, "丹麥幣", "Danish Krone", "kr", 4);
    public static readonly Currency TRY = new("TRY", 16, "土耳其里拉", "Turkish Lira", "₺", 4);

    // 屬性
    public string Code => Name;  // SmartEnum.Name 就是我們的貨幣代號
    public string ChineseName { get; }
    public string EnglishName { get; }
    public string Symbol { get; }
    public int DecimalPlaces { get; }

    // 私有建構函式
    private Currency(string name, int value, string chineseName, string englishName, string symbol, int decimalPlaces) 
        : base(name, value)
    {
        ChineseName = chineseName;
        EnglishName = englishName;
        Symbol = symbol;
        DecimalPlaces = decimalPlaces;
    }

    // 便利方法：從字串取得 Currency
    public static Currency? FromCode(string code)
    {
        return TryFromName(code, out var currency) ? currency : null;
    }
}

// 匯率抓取服務介面
public interface IExchangeRateService
{
    Task<List<ExchangeRateItem>> GetExchangeRatesAsync();
}

// 匯率抓取服務實作
public class ExchangeRateService : IExchangeRateService
{
    private readonly HttpClient _httpClient;
    private readonly TimeProvider _timeProvider;
    private const string CATHAY_BANK_URL = "https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/";

    public ExchangeRateService(HttpClient httpClient, TimeProvider timeProvider)
    {
        _httpClient = httpClient;
        _timeProvider = timeProvider;
    }

    public async Task<List<ExchangeRateItem>> GetExchangeRatesAsync()
    {
        try
        {
            Console.WriteLine("開始下載國泰世華銀行匯率網頁");
            
            var response = await _httpClient.GetAsync(CATHAY_BANK_URL);
            response.EnsureSuccessStatusCode();
            
            var htmlContent = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"網頁下載完成，內容長度: {htmlContent.Length} 字元");
            
            var document = new HtmlDocument();
            document.LoadHtml(htmlContent);
            
            var exchangeRates = new List<ExchangeRateItem>();
            var boardDateTime = _timeProvider.GetLocalNow().DateTime; // 使用 TimeProvider 取得本地時間
            
            Console.WriteLine($"開始抓取 {Currency.List.Count()} 種外幣匯率");
            
            foreach (var currency in Currency.List)
            {
                Console.WriteLine($"正在處理: {currency.Code} ({currency.ChineseName})");
                
                var rate = ExtractCurrencyRate(document, currency, boardDateTime);
                if (rate != null)
                {
                    exchangeRates.Add(rate);
                    Console.WriteLine($"✓ 成功抓取 {currency.Code} - 買進: {rate.BankBuyRate:F4}, 賣出: {rate.BankSellRate:F4}");
                }
                else
                {
                    Console.WriteLine($"✗ 無法抓取 {currency.Code}");
                }
            }
            
            Console.WriteLine($"抓取完成，成功: {exchangeRates.Count}/{Currency.List.Count()}");
            
            return exchangeRates;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"抓取匯率時發生錯誤: {ex.Message}");
            throw;
        }
    }

    private ExchangeRateItem? ExtractCurrencyRate(HtmlDocument document, Currency currency, DateTime boardDateTime)
    {
        try
        {
            // 尋找包含貨幣代號的 rateCard 區塊
            var rateCard = document.DocumentNode
                .SelectSingleNode($"//div[contains(@class, 'cubre-o-rateCard') and .//div[contains(text(), '{currency.Code}')]]");
            
            if (rateCard != null)
            {
                // 在這個區塊內尋找匯率表格
                var rateTable = rateCard.SelectSingleNode(".//table[contains(@class, 'cubre-m-rateTable')]");
                if (rateTable != null)
                {
                    // 尋找即期匯率行
                    var spotRateRow = rateTable.SelectSingleNode(".//tr[.//div[contains(text(), '即期匯率')]]");
                    if (spotRateRow != null)
                    {
                        var cells = spotRateRow.SelectNodes(".//td");
                        if (cells != null && cells.Count >= 3)
                        {
                            var buyRateText = cells[1].InnerText?.Trim();
                            var sellRateText = cells[2].InnerText?.Trim();
                            
                            if (decimal.TryParse(buyRateText, out decimal buyRate) && 
                                decimal.TryParse(sellRateText, out decimal sellRate))
                            {
                                return new ExchangeRateItem
                                {
                                    Currency = currency,
                                    CurrencyCode = currency.Code,
                                    CurrencyName = currency.ChineseName,
                                    BankBuyRate = buyRate,
                                    BankSellRate = sellRate,
                                    BoardDateTime = boardDateTime,
                                    CreatedAt = _timeProvider.GetUtcNow().DateTime // 使用 TimeProvider 取得 UTC 時間
                                };
                            }
                        }
                    }
                }
            }
            
            return null;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"提取 {currency.Code} 匯率時發生錯誤: {ex.Message}");
            return null;
        }
    }
}

// T-SQL 腳本產生服務
public interface ISqlScriptService
{
    string GenerateTSqlScript(List<ExchangeRateItem> exchangeRates);
}

public class SqlScriptService : ISqlScriptService
{
    private readonly TimeProvider _timeProvider;

    public SqlScriptService(TimeProvider timeProvider)
    {
        _timeProvider = timeProvider;
    }

    public string GenerateTSqlScript(List<ExchangeRateItem> exchangeRates)
    {
        Console.WriteLine($"開始產生 T-SQL 腳本，資料筆數: {exchangeRates.Count}");
        
        var sb = new StringBuilder();
        
        sb.AppendLine("-- ===== 國泰世華銀行外幣匯率資料 INSERT 腳本 =====");
        sb.AppendLine($"-- 產生時間: {_timeProvider.GetLocalNow():yyyy-MM-dd HH:mm:ss}"); // 使用 TimeProvider
        sb.AppendLine($"-- 資料筆數: {exchangeRates.Count}");
        sb.AppendLine();
        
        sb.AppendLine("-- 如果資料表不存在，請先執行以下建立腳本:");
        sb.AppendLine("/*");
        sb.AppendLine("CREATE TABLE ExchangeRates (");
        sb.AppendLine("    Id                BIGINT IDENTITY(1,1) PRIMARY KEY,");
        sb.AppendLine("    CurrencyCode      NVARCHAR(3) NOT NULL,");
        sb.AppendLine("    CurrencyName      NVARCHAR(50) NOT NULL,");
        sb.AppendLine("    BankBuyRate       DECIMAL(18,6) NOT NULL,");
        sb.AppendLine("    BankSellRate      DECIMAL(18,6) NOT NULL,");
        sb.AppendLine("    BoardDate         DATE NOT NULL,");
        sb.AppendLine("    BoardTime         TIME NOT NULL,");
        sb.AppendLine("    BoardDateTime     DATETIME2 NOT NULL,");
        sb.AppendLine("    CreatedAt         DATETIME2 DEFAULT GETUTCDATE(),");
        sb.AppendLine("    UpdatedAt         DATETIME2 DEFAULT GETUTCDATE(),");
        sb.AppendLine("    CONSTRAINT UQ_ExchangeRates_Unique UNIQUE (CurrencyCode, BoardDateTime)");
        sb.AppendLine(");");
        sb.AppendLine("*/");
        sb.AppendLine();
        
        if (!exchangeRates.Any())
        {
            sb.AppendLine("-- 無資料可插入");
            return sb.ToString();
        }
        
        sb.AppendLine("BEGIN TRANSACTION;");
        sb.AppendLine();
        
        sb.AppendLine("INSERT INTO ExchangeRates (");
        sb.AppendLine("    CurrencyCode, CurrencyName, BankBuyRate, BankSellRate,");
        sb.AppendLine("    BoardDate, BoardTime, BoardDateTime, CreatedAt, UpdatedAt");
        sb.AppendLine(") VALUES");
        
        for (int i = 0; i < exchangeRates.Count; i++)
        {
            var rate = exchangeRates[i];
            var comma = i < exchangeRates.Count - 1 ? "," : ";";
            
            sb.AppendLine($"    ('{rate.CurrencyCode}', N'{rate.CurrencyName}', {rate.BankBuyRate:F6}, {rate.BankSellRate:F6},");
            sb.AppendLine($"     '{rate.BoardDateTime:yyyy-MM-dd}', '{rate.BoardDateTime:HH:mm:ss}', '{rate.BoardDateTime:yyyy-MM-dd HH:mm:ss}',");
            sb.AppendLine($"     '{rate.CreatedAt:yyyy-MM-dd HH:mm:ss}', '{rate.CreatedAt:yyyy-MM-dd HH:mm:ss}'){comma}");
            
            if (i < exchangeRates.Count - 1)
            {
                sb.AppendLine();
            }
        }
        
        sb.AppendLine();
        sb.AppendLine("COMMIT TRANSACTION;");
        sb.AppendLine();
        
        // 添加驗證查詢
        sb.AppendLine("-- 驗證插入結果");
        sb.AppendLine("SELECT ");
        sb.AppendLine("    CurrencyCode, CurrencyName, BankBuyRate, BankSellRate,");
        sb.AppendLine("    BoardDateTime, CreatedAt");
        sb.AppendLine("FROM ExchangeRates");
        sb.AppendLine($"WHERE CreatedAt >= '{exchangeRates.First().CreatedAt:yyyy-MM-dd HH:mm:ss}'");
        sb.AppendLine("ORDER BY CurrencyCode;");
        
        Console.WriteLine("T-SQL 腳本產生完成");
        
        return sb.ToString();
    }
}

// 主程式類別
public class Program
{
    public static async Task Main(string[] args)
    {
        // 建立 Host 並設定 DI 容器
        var host = Host.CreateDefaultBuilder(args)
            .ConfigureServices((context, services) =>
            {
                // 註冊 HttpClient 使用 HttpClientFactory (最佳實務)
                services.AddHttpClient<IExchangeRateService, ExchangeRateService>(client =>
                {
                    client.Timeout = TimeSpan.FromSeconds(30);
                    client.DefaultRequestHeaders.Add("User-Agent", 
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
                    client.DefaultRequestHeaders.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
                    client.DefaultRequestHeaders.Add("Accept-Language", "zh-TW,zh;q=0.9,en;q=0.8");
                    client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                });
                
                // 註冊自定義服務
                services.AddScoped<ISqlScriptService, SqlScriptService>();
                
                // 註冊時間提供者 (企業級架構 - 可測試性和時間一致性)
                services.AddSingleton<TimeProvider>(TimeProvider.System);
            })
            .Build();

        try
        {
            Console.WriteLine("=== 國泰世華銀行外幣匯率抓取工具 (Console + HttpClientFactory 版本) ===");
            
            // 取得時間提供者服務 (使用 DI 模式)
            var timeProvider = host.Services.GetRequiredService<TimeProvider>();
            Console.WriteLine($"執行時間: {timeProvider.GetLocalNow():yyyy年MM月dd日 HH:mm:ss}");
            Console.WriteLine();
            
            // 取得服務實例
            var exchangeRateService = host.Services.GetRequiredService<IExchangeRateService>();
            var sqlScriptService = host.Services.GetRequiredService<ISqlScriptService>();
            
            Console.WriteLine("開始執行匯率抓取作業");
            
            // 抓取匯率資料
            var exchangeRates = await exchangeRateService.GetExchangeRatesAsync();
            
            Console.WriteLine("\n=== 抓取完成 ===");
            Console.WriteLine($"成功抓取 {exchangeRates.Count}/16 種外幣匯率");
            
            if (exchangeRates.Any())
            {
                // 顯示結果摘要
                Console.WriteLine("\n=== 抓取結果摘要 ===");
                foreach (var rate in exchangeRates.OrderBy(r => r.CurrencyCode))
                {
                    Console.WriteLine($"{rate.CurrencyCode} ({rate.CurrencyName}): " +
                                    $"買進 {rate.FormattedBuyRate}, 賣出 {rate.FormattedSellRate}");
                }
                
                // 展示 SmartEnum 功能
                DisplaySmartEnumDemo(exchangeRates);
                
                // 產生 T-SQL 腳本
                Console.WriteLine("\n=== T-SQL INSERT 腳本 ===");
                var sqlScript = sqlScriptService.GenerateTSqlScript(exchangeRates);
                Console.WriteLine(sqlScript);
            }
            else
            {
                Console.WriteLine("未能抓取到任何匯率資料");
            }
            
            Console.WriteLine("\n匯率抓取作業完成");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"執行失敗: {ex.Message}");
            Console.WriteLine($"詳細錯誤: {ex}");
        }
    }

    // 展示 SmartEnum 功能的輔助方法
    private static void DisplaySmartEnumDemo(List<ExchangeRateItem> exchangeRates)
    {
        Console.WriteLine("\n=== SmartEnum + HttpClientFactory 功能演示 ===");
        var sampleRate = exchangeRates.FirstOrDefault();
        if (sampleRate != null)
        {
            Console.WriteLine($"範例貨幣: {sampleRate.Currency.EnglishName} ({sampleRate.Currency.ChineseName})");
            Console.WriteLine($"格式化匯率: 買進 {sampleRate.FormattedBuyRate}, 賣出 {sampleRate.FormattedSellRate}");
            Console.WriteLine($"小數位數設定: {sampleRate.Currency.DecimalPlaces} 位");
            
            // 演示從代號查找貨幣
            var usdCurrency = Currency.FromCode("USD");
            if (usdCurrency != null)
            {
                Console.WriteLine($"從代號 'USD' 找到: {usdCurrency.ChineseName} ({usdCurrency.Symbol})");
            }
            
            Console.WriteLine($"所有支援的貨幣數量: {Currency.List.Count()}");
            Console.WriteLine("✅ 使用 HttpClientFactory 管理 HTTP 客戶端");
            Console.WriteLine("✅ 使用 SmartEnum 強型別貨幣定義");
            Console.WriteLine("✅ 使用 Microsoft.Extensions.Hosting 依賴注入");
        }
    }
}

public class ExchangeRateItem
{
    public Currency Currency { get; set; } = Currency.USD;  // SmartEnum 參考
    public string CurrencyCode { get; set; } = string.Empty;
    public string CurrencyName { get; set; } = string.Empty;
    public decimal BankBuyRate { get; set; }
    public decimal BankSellRate { get; set; }
    public DateTime BoardDateTime { get; set; }
    public DateTime CreatedAt { get; set; }
    
    // 便利屬性：透過 SmartEnum 取得格式化的匯率
    public string FormattedBuyRate => $"{Currency.Symbol}{BankBuyRate:F4}";
    public string FormattedSellRate => $"{Currency.Symbol}{BankSellRate:F4}";
}
