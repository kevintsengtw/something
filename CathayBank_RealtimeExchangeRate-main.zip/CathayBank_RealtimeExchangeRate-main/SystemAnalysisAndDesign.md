# 國泰世華銀行外幣匯率即時抓取系統 - 系統分析與設計

## 文件版本記錄

| 版本 | 日期       | 更新內容                                 | 更新者 |
| ---- | ---------- | ---------------------------------------- | ------ |
| v1.0 | 2025/08/01 | 初始版本：基礎功能設計與 Dictionary 實作 | Kevin  |

---

## 專案概述

### 專案名稱
國泰世華銀行外幣匯率即時抓取系統 (CathayBank Realtime Exchange Rate System)

### 專案目標
建立一個自動化系統，定期抓取國泰世華銀行網站上的16種外幣即期匯率資料，並提供WebAPI服務供使用者查詢。

### 資料來源
- 網址：https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/
- 更新頻率：工作日上午08:30到下午16:30，不定時更新
- 抓取頻率：每5分鐘抓取一次

---

## 實作過程與架構演進

### 開發歷程記錄

#### 階段 1: 基礎功能實作 (初期版本)
- 使用 `Dictionary<string, string>` 儲存貨幣資訊
- 簡單的 HttpClient 網頁抓取
- 基本的匯率解析功能

---

## 需求分析

### 功能性需求

#### 1. 資料抓取需求
- **抓取對象**：16種外幣即期匯率
  - 美元 (USD)、歐元 (EUR)、日圓 (JPY)、人民幣 (CNY)
  - 港幣 (HKD)、澳大利亞幣 (AUD)、紐西蘭幣 (NZD)、南非幣 (ZAR)
  - 加拿大幣 (CAD)、英鎊 (GBP)、瑞士法郎 (CHF)、瑞典幣 (SEK)
  - 新加坡幣 (SGD)、泰國幣 (THB)、丹麥幣 (DKK)、土耳其里拉 (TRY)

- **抓取資料項目**：
  - 幣別名稱 (Currency Name)
  - 幣別代號 (Currency Code)
  - 銀行買進價格 (Bank Buy Rate)
  - 銀行賣出價格 (Bank Sell Rate)
  - 資料日期 (Board Date)
  - 資料時間 (Board Time)

- **抓取週期**：
  - 時間範圍：週一至週五 08:30-16:30
  - 抓取頻率：每5分鐘執行一次
  - 使用 Cron 表達式：`0 */5 8-16 * * 1-5`

#### 2. 資料儲存需求
- 將抓取的匯率資料存儲到 MS SQL Server
- 支援歷史資料查詢
- 資料去重複處理

#### 3. API服務需求
- 提供 RESTful WebAPI
- 支援即時匯率查詢
- 支援歷史匯率查詢
- 支援特定幣別查詢

#### 4. 快取需求
- 使用 Redis 做分散式快取
- 使用 Memory Cache 做本地快取

### 非功能性需求

#### 1. 性能需求
- 網頁抓取響應時間 < 30秒
- API 查詢響應時間 < 2秒
- 支援併發查詢 > 100 requests/second

#### 2. 可靠性需求
- 系統可用性 > 99%
- 資料完整性保證
- 網路異常重試機制

#### 3. 安全性需求
- API 訪問限流
- 錯誤處理與日誌記錄
- 防止重複抓取同一資料

---

## 系統架構設計

### 1. 整體架構

```mermaid
graph TB
    %% 外部層
    User[外部使用者]
    CathayBank[國泰銀行網站]
    Admin[管理者介面]
    
    %% 應用程式層
    subgraph WebAPI ["ASP.NET Core 9 WebAPI"]
        Controllers[Controllers]
        Services[Services]
        BackgroundSvc[Background Services]
        Middleware[Middleware]
        
        subgraph Cache ["HybridCache Layer"]
            MemCache[Memory Cache]
            RedisCache[Redis Cache]
        end
        
        BusinessLogic[Business Logic Layer]
        DataAccess[Data Access Layer]
    end
    
    %% 資料層
    Database[(SQL Server Database)]
    Redis[(Redis Cache)]
    Logs[Log Files & Monitoring]
    
    %% 連接關係
    User -->|HTTP Requests| Controllers
    CathayBank -->|Web Scraping| BackgroundSvc
    Admin -->|Management| Controllers
    
    Controllers --> Services
    Services --> BusinessLogic
    BackgroundSvc --> BusinessLogic
    BusinessLogic --> DataAccess
    
    DataAccess --> Cache
    Cache --> Database
    Cache --> Redis
    
    Services --> Logs
    BackgroundSvc --> Logs
    
    %% 樣式設定
    classDef external fill:#e1f5fe
    classDef webapp fill:#f3e5f5
    classDef data fill:#e8f5e8
    
    class User,CathayBank,Admin external
    class Controllers,Services,BackgroundSvc,Middleware,BusinessLogic,DataAccess webapp
    class Database,Redis,Logs data
```

### 2. 應用程式架構

#### Layer 架構

```mermaid
graph TB
    subgraph Layers ["Clean Architecture Layers"]
        Presentation[Presentation Layer<br/>Controllers, DTOs]
        Application[Application Layer<br/>Services, Validators]
        Domain[Domain Layer<br/>Entities, Value Objects]
        Infrastructure[Infrastructure Layer<br/>Repositories, External APIs]
    end
    
    %% 依賴關係
    Presentation --> Application
    Application --> Domain
    Infrastructure --> Domain
    
    %% 樣式
    classDef layer fill:#f9f9f9,stroke:#333,stroke-width:2px
    class Presentation,Application,Domain,Infrastructure layer
```

### 3. HTTP 客戶端架構設計

#### HttpClientFactory vs AddSingleton<HttpClient> 技術分析

**為什麼不能使用 `services.AddSingleton<HttpClient>()`？**

使用 `AddSingleton<HttpClient>()` 會導致嚴重的技術問題：

##### 1. DNS 解析問題
```csharp
// ❌ 錯誤做法 - DNS 快取問題
services.AddSingleton<HttpClient>(provider =>
{
    return new HttpClient(); // DNS 記錄永不更新
});
```

**問題描述：**
- HttpClient 單例會快取 DNS 解析結果
- 當目標伺服器 IP 變更時，應用程式仍使用舊 IP
- 導致網路請求失敗，需要重啟應用程式才能解決

**實際影響：**
- 服務中斷：無法連接到更新後的伺服器
- 維運困難：需要手動重啟應用程式
- 穩定性差：DNS 變更導致服務不可用

##### 2. Socket 耗盡問題
```csharp
// ❌ 錯誤做法 - Socket 資源洩漏
services.AddSingleton<HttpClient>(provider =>
{
    var client = new HttpClient();
    // 單例永不釋放，底層 Socket 連線累積
    return client;
});
```

**問題描述：**
- HttpClient 單例持有底層 HttpClientHandler
- 長時間運行導致 TCP 連線累積
- 最終觸發 SocketException: "無法指定更多的通訊端"

**實際影響：**
- 效能下降：可用 Socket 數量減少
- 系統崩潰：達到 Socket 上限時應用程式失效
- 資源浪費：無效連線佔用系統資源

##### 3. 設定管理複雜化
```csharp
// ❌ 錯誤做法 - 設定分散難以管理
services.AddSingleton<HttpClient>(provider =>
{
    var client = new HttpClient();
    client.Timeout = TimeSpan.FromSeconds(30);
    client.DefaultRequestHeaders.Add("User-Agent", "...");
    // 設定散布在多處，難以維護
    return client;
});
```

**問題描述：**
- HTTP 客戶端設定分散在各個服務中
- 難以統一管理 Timeout、Headers 等設定
- 測試時無法輕易模擬不同的 HTTP 行為

#### HttpClientFactory 正確實作方式

##### 1. 必要套件相依性
```xml
<!-- LINQPad 環境 -->
<NuGetReference Version="8.0.0">Microsoft.Extensions.Http</NuGetReference>
<NuGetReference>Microsoft.Extensions.DependencyInjection</NuGetReference>

<!-- ASP.NET Core 專案 -->
<PackageReference Include="Microsoft.Extensions.Http" Version="8.0.0" />
```

**套件說明：**
- `Microsoft.Extensions.Http`：提供 HttpClientFactory 功能
- `Microsoft.Extensions.DependencyInjection`：依賴注入容器
- 版本 8.0.0：確保與 .NET 8 的相容性

##### 2. 型別化客戶端註冊 (推薦方式)
```csharp
// ✅ 正確做法 - 型別化客戶端
services.AddHttpClient<IExchangeRateService, ExchangeRateService>(client =>
{
    // 集中化設定管理
    client.Timeout = TimeSpan.FromSeconds(30);
    client.DefaultRequestHeaders.Add("User-Agent", 
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
    client.DefaultRequestHeaders.Add("Accept", 
        "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
    client.DefaultRequestHeaders.Add("Accept-Language", "zh-TW,zh;q=0.9,en;q=0.8");
    client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
});
```

##### 3. 其他註冊方式選項

**基本客戶端註冊：**
```csharp
// 基本 HttpClient 註冊
services.AddHttpClient();

// 使用方式
public class SomeService
{
    private readonly IHttpClientFactory _httpClientFactory;
    
    public SomeService(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
    }
    
    public async Task DoSomethingAsync()
    {
        var client = _httpClientFactory.CreateClient();
        // 使用 client
    }
}
```

**命名客戶端註冊：**
```csharp
// 命名 HttpClient 註冊
services.AddHttpClient("CathayBank", client =>
{
    client.BaseAddress = new Uri("https://www.cathaybk.com.tw");
    client.Timeout = TimeSpan.FromSeconds(30);
});

// 使用方式
var client = _httpClientFactory.CreateClient("CathayBank");
```

#### HttpClientFactory 技術優勢詳解

| 技術面向        | AddSingleton<HttpClient> | HttpClientFactory             |
| --------------- | ------------------------ | ----------------------------- |
| **DNS 解析**    | ❌ 永久快取，不會更新    | ✅ 定期更新 DNS 記錄          |
| **Socket 管理** | ❌ 可能導致 Socket 耗盡  | ✅ 自動池化和回收             |
| **記憶體管理**  | ❌ 永不釋放資源          | ✅ 定時釋放 HttpClientHandler |
| **設定管理**    | ❌ 分散在各服務中        | ✅ 集中化設定                 |
| **生命週期**    | ❌ 單例，難以控制        | ✅ 自動管理生命週期           |
| **測試性**      | ❌ 難以模擬              | ✅ 支援測試替身               |
| **效能**        | ❌ 長期執行效能下降      | ✅ 最佳化連線重用             |
| **監控**        | ❌ 難以追蹤連線狀態      | ✅ 內建遙測和日誌             |

#### 實際部署考量

**生產環境最佳實務：**
```csharp
services.AddHttpClient<IExchangeRateService, ExchangeRateService>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(30);
    // 生產環境設定
})
.ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler()
{
    // 連線池設定
    MaxConnectionsPerServer = 10,
    // SSL 設定
    ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
})
.AddPolicyHandler(GetRetryPolicy())  // 重試政策
.AddPolicyHandler(GetCircuitBreakerPolicy());  // 斷路器政策
```

**監控和診斷：**
```csharp
services.AddHttpClient<IExchangeRateService, ExchangeRateService>()
    .AddLogger()  // 自動日誌記錄
    .AddMetrics(); // 效能指標收集
```

**LINQPad 相容性解決：**
- **問題根因**：LINQPad 環境的套件解析機制與標準 .NET 專案不同
- **解決方案**：明確指定 Microsoft.Extensions.Http 版本為 8.0.0
- **版本鎖定原因**：避免套件相依性衝突，確保執行穩定性

---

## 領域模型設計

### 1. SmartEnum 貨幣類型設計

#### SmartEnum 架構概述
使用 `Ardalis.SmartEnum` 實作強型別貨幣定義，取代傳統的 `Dictionary<string, string>` 或 `enum` 方式。

**核心優勢：**
- **強型別安全**：編譯時期檢查，避免執行時期錯誤
- **豐富元數據**：每個貨幣包含完整的屬性資訊
- **不可變性**：唯讀靜態定義，確保資料一致性
- **查詢便利性**：提供多種查詢方法

#### Currency SmartEnum 實作
```csharp
public sealed class Currency : SmartEnum<Currency>
{
    // 16種外幣靜態定義
    public static readonly Currency USD = new("USD", 1, "美元", "US Dollar", "$", 4);
    public static readonly Currency EUR = new("EUR", 2, "歐元", "Euro", "€", 4);
    public static readonly Currency JPY = new("JPY", 3, "日圓", "Japanese Yen", "¥", 2);
    public static readonly Currency CNY = new("CNY", 4, "人民幣", "Chinese Yuan", "¥", 4);
    // ... 其他12種外幣
    
    // 屬性定義
    public string Code => Name;  // SmartEnum.Name 即為貨幣代號
    public string ChineseName { get; }
    public string EnglishName { get; }
    public string Symbol { get; }
    public int DecimalPlaces { get; }
    
    // 私有建構函式確保唯一性
    private Currency(string name, int value, string chineseName, 
                     string englishName, string symbol, int decimalPlaces) 
        : base(name, value)
    {
        ChineseName = chineseName;
        EnglishName = englishName;
        Symbol = symbol;
        DecimalPlaces = decimalPlaces;
    }
    
    // 便利查詢方法
    public static Currency? FromCode(string code)
    {
        return TryFromName(code, out var currency) ? currency : null;
    }
}
```

#### SmartEnum 使用範例
```csharp
// 型別安全的貨幣操作
Currency usd = Currency.USD;
string symbol = usd.Symbol;  // "$"
string name = usd.ChineseName;  // "美元"

// 從代號查詢
var euro = Currency.FromCode("EUR");

// 列舉所有貨幣
var allCurrencies = Currency.List;  // 16種外幣

// 強型別比較
if (exchangeRate.Currency == Currency.USD)
{
    // 美元專用邏輯
}
```

#### 與 ExchangeRateItem 整合
```csharp
public class ExchangeRateItem
{
    public Currency Currency { get; set; } = Currency.USD;  // SmartEnum 參考
    public string CurrencyCode { get; set; } = string.Empty;
    public string CurrencyName { get; set; } = string.Empty;
    public decimal BankBuyRate { get; set; }
    public decimal BankSellRate { get; set; }
    
    // 透過 SmartEnum 取得格式化匯率
    public string FormattedBuyRate => $"{Currency.Symbol}{BankBuyRate:F4}";
    public string FormattedSellRate => $"{Currency.Symbol}{BankSellRate:F4}";
}
```

#### 與傳統方法的比較

| 項目         | Dictionary<string,string> | Enum        | SmartEnum   |
| ------------ | ------------------------- | ----------- | ----------- |
| **型別安全** | ❌ 字串型別               | ✅ 強型別   | ✅ 強型別   |
| **豐富屬性** | ❌ 僅鍵值對               | ❌ 僅數值   | ✅ 多屬性   |
| **查詢方便** | ❌ 字典查詢               | ❌ 需轉換   | ✅ 內建方法 |
| **不可變性** | ❌ 可修改                 | ✅ 不可變   | ✅ 不可變   |
| **可擴充性** | ❌ 結構鬆散               | ❌ 難以擴充 | ✅ 易於擴充 |

---

## 時間處理設計原則

### 1. TimeProvider 使用策略

本系統統一使用 `Microsoft.Bcl.TimeProvider` 的 `TimeProvider.System` 來處理所有時間相關操作，避免直接使用 `DateTime.Now` 或 `DateTime.UtcNow`。

#### 核心原則
- **一致性**：所有服務統一使用 TimeProvider 獲取時間
- **可測試性**：透過依賴注入，測試時可以使用模擬的 TimeProvider
- **時區處理**：明確區分 UTC 時間和本地時間的使用場景

#### 時間獲取方法
```csharp
// 獲取 UTC 時間 (用於資料庫儲存、日誌記錄)
var utcNow = _timeProvider.GetUtcNow().DateTime;

// 獲取本地時間 (用於顯示給使用者、本地業務邏輯)
var localNow = _timeProvider.GetLocalNow().DateTime;

// 獲取 DateTimeOffset (保留時區資訊)
var nowOffset = _timeProvider.GetUtcNow();
```

#### 依賴注入配置
```csharp
// Program.cs
builder.Services.AddSingleton(TimeProvider.System);

// 測試環境可使用
builder.Services.AddSingleton<TimeProvider>(new FakeTimeProvider());
```

### 2. 時間使用場景

#### UTC 時間使用場景
- 資料庫記錄的 CreatedAt、UpdatedAt 欄位
- 日誌時間戳記
- API 回應中的 Timestamp
- 系統內部處理時間

#### 本地時間使用場景
- 網站抓取的牌告時間解析
- 錯誤處理的備用時間
- 定時任務的時區計算

---

## 資料庫設計

### 1. 資料表結構

#### ExchangeRates 表 (主要匯率資料表)
```sql
CREATE TABLE ExchangeRates (
    Id                BIGINT IDENTITY(1,1) PRIMARY KEY,
    CurrencyCode      NVARCHAR(3) NOT NULL,           -- 幣別代號 (USD, EUR, etc.)
    CurrencyName      NVARCHAR(50) NOT NULL,          -- 幣別名稱 (美元, 歐元, etc.)
    BankBuyRate       DECIMAL(18,6) NOT NULL,         -- 銀行買進匯率
    BankSellRate      DECIMAL(18,6) NOT NULL,         -- 銀行賣出匯率
    BoardDate         DATE NOT NULL,                  -- 資料日期
    BoardTime         TIME NOT NULL,                  -- 資料時間
    BoardDateTime     DATETIME2 NOT NULL,             -- 完整的牌告時間
    CreatedAt         DATETIME2 DEFAULT GETUTCDATE(), -- 資料建立時間
    UpdatedAt         DATETIME2 DEFAULT GETUTCDATE(), -- 資料更新時間
    
    -- 建立複合索引，避免重複資料
    CONSTRAINT UQ_ExchangeRates_Unique UNIQUE (CurrencyCode, BoardDateTime),
    
    -- 建立索引提升查詢效能
    INDEX IX_ExchangeRates_CurrencyCode NONCLUSTERED (CurrencyCode),
    INDEX IX_ExchangeRates_BoardDateTime NONCLUSTERED (BoardDateTime DESC),
    INDEX IX_ExchangeRates_CreatedAt NONCLUSTERED (CreatedAt DESC)
);
```

#### 時間欄位設計說明
- `BoardDateTime`: 銀行牌告的實際時間，使用台灣本地時間儲存
- `CreatedAt`/`UpdatedAt`: 系統記錄時間，使用 UTC 時間，配合 `GETUTCDATE()` 
- 應用程式層使用 TimeProvider 確保時間來源的一致性和可測試性
- 資料庫層的 `GETUTCDATE()` 作為備用，但主要時間設定由應用程式負責

#### Currencies 表 (幣別主檔)
```sql
CREATE TABLE Currencies (
    CurrencyCode      NVARCHAR(3) PRIMARY KEY,         -- 幣別代號
    CurrencyName      NVARCHAR(50) NOT NULL,           -- 幣別名稱
    CurrencySymbol    NVARCHAR(10),                    -- 幣別符號 ($, €, etc.)
    IsActive          BIT DEFAULT 1,                   -- 是否啟用
    DisplayOrder      INT,                             -- 顯示順序
    CreatedAt         DATETIME2 DEFAULT GETUTCDATE(),
    UpdatedAt         DATETIME2 DEFAULT GETUTCDATE()
);
```

#### ScrapingLogs 表 (抓取日誌表)
```sql
CREATE TABLE ScrapingLogs (
    Id                BIGINT IDENTITY(1,1) PRIMARY KEY,
    ScrapingStartTime DATETIME2 NOT NULL,              -- 抓取開始時間
    ScrapingEndTime   DATETIME2,                       -- 抓取結束時間
    Status            NVARCHAR(20) NOT NULL,           -- SUCCESS, FAILED, PARTIAL
    RecordsProcessed  INT DEFAULT 0,                   -- 處理的記錄數
    ErrorMessage      NVARCHAR(MAX),                   -- 錯誤訊息
    CreatedAt         DATETIME2 DEFAULT GETUTCDATE(),
    
    INDEX IX_ScrapingLogs_CreatedAt NONCLUSTERED (CreatedAt DESC)
);
```

### 2. 初始資料

#### 幣別主檔初始資料
```sql
INSERT INTO Currencies (CurrencyCode, CurrencyName, CurrencySymbol, DisplayOrder) VALUES
('USD', '美元', '$', 1),
('EUR', '歐元', '€', 2),
('JPY', '日圓', '¥', 3),
('CNY', '人民幣', '¥', 4),
('HKD', '港幣', 'HK$', 5),
('AUD', '澳大利亞幣', 'A$', 6),
('NZD', '紐西蘭幣', 'NZ$', 7),
('ZAR', '南非幣', 'R', 8),
('CAD', '加拿大幣', 'C$', 9),
('GBP', '英鎊', '£', 10),
('CHF', '瑞士法郎', 'CHF', 11),
('SEK', '瑞典幣', 'kr', 12),
('SGD', '新加坡幣', 'S$', 13),
('THB', '泰國幣', '฿', 14),
('DKK', '丹麥幣', 'kr', 15),
('TRY', '土耳其里拉', '₺', 16);
```

---

## 核心功能模組設計

### 1. 背景服務模組 (Background Service)

#### ExchangeRateScrapingService
```csharp
public class ExchangeRateScrapingService : BackgroundService
{
    private readonly ILogger<ExchangeRateScrapingService> _logger;
    private readonly IServiceProvider _serviceProvider;
    private readonly TimeProvider _timeProvider;
    private readonly CronTimer _cronTimer;

    // Cron: 每5分鐘執行，僅在工作日 08:30-16:30
    private const string CronExpression = "0 */5 8-16 * * 1-5";

    public ExchangeRateScrapingService(
        ILogger<ExchangeRateScrapingService> logger,
        IServiceProvider serviceProvider,
        TimeProvider timeProvider)
    {
        _logger = logger;
        _serviceProvider = serviceProvider;
        _timeProvider = timeProvider;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _cronTimer = new CronTimer(CronExpression, TimeZoneInfo.Local);
        
        while (!stoppingToken.IsCancellationRequested)
        {
            await _cronTimer.WaitForNextTickAsync(stoppingToken);
            await ProcessExchangeRateScrapingAsync(stoppingToken);
        }
    }
}
```

### 2. 網頁抓取模組

#### 使用的技術與套件
- **HttpClientFactory**: 管理 HttpClient 實例，避免 Socket 耗盡問題
- **HtmlAgilityPack**: HTML 解析與 DOM 操作
- **Polly**: 重試策略與故障處理
- **System.Text.Json**: JSON 序列化與反序列化
- **Microsoft.Extensions.Configuration**: 設定檔管理
- **Microsoft.Bcl.TimeProvider**: 時間提供者抽象，用於可測試的時間處理

#### 相關 NuGet 套件
```xml
<PackageReference Include="HtmlAgilityPack" Version="1.11.54" />
<PackageReference Include="Polly" Version="7.2.4" />
<PackageReference Include="Polly.Extensions.Http" Version="3.0.0" />
<PackageReference Include="System.Text.Json" Version="8.0.0" />
<PackageReference Include="Microsoft.Bcl.TimeProvider" Version="8.0.1" />
```

#### WebScrapingService 介面與實作
```csharp
public interface IWebScrapingService
{
    Task<ExchangeRateData> ScrapeExchangeRatesAsync(CancellationToken cancellationToken = default);
    Task<bool> ValidateWebsiteStructureAsync(CancellationToken cancellationToken = default);
    Task<string> GetBoardTimeAsync(CancellationToken cancellationToken = default);
}

public class WebScrapingService : IWebScrapingService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<WebScrapingService> _logger;
    private readonly IConfiguration _configuration;
    private readonly ScrapingSettings _settings;
    private readonly TimeProvider _timeProvider;

    private const string TargetUrl = "https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/";

    public WebScrapingService(
        IHttpClientFactory httpClientFactory,
        ILogger<WebScrapingService> logger,
        IConfiguration configuration,
        IOptions<ScrapingSettings> settings,
        TimeProvider timeProvider)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
        _configuration = configuration;
        _settings = settings.Value;
        _timeProvider = timeProvider;
    }

    public async Task<ExchangeRateData> ScrapeExchangeRatesAsync(CancellationToken cancellationToken = default)
    {
        var scrapeId = Guid.NewGuid();
        using var scope = _logger.BeginScope(new Dictionary<string, object>
        {
            ["ScrapeId"] = scrapeId,
            ["TargetUrl"] = TargetUrl
        });

        try
        {
            _logger.LogInformation("開始抓取匯率資料");

            // 使用 HttpClientFactory 建立 HttpClient 實例
            using var httpClient = _httpClientFactory.CreateClient("CathayBankScraper");

            // 1. 發送 HTTP 請求並取得 HTML 內容
            var htmlContent = await FetchWebPageWithRetryAsync(httpClient, TargetUrl, cancellationToken);
            
            // 2. 解析 HTML 文件
            var document = new HtmlDocument();
            document.LoadHtml(htmlContent);
            
            // 3. 驗證網站結構
            if (!ValidateHtmlStructure(document))
            {
                throw new WebScrapingException("網站結構已變更，需要更新解析邏輯");
            }
            
            // 4. 提取資料時間
            var boardDateTime = ExtractBoardDateTime(document);
            
            // 5. 提取16種外幣匯率資料
            var exchangeRates = ExtractExchangeRates(document);
            
            // 6. 驗證資料完整性
            ValidateExtractedData(exchangeRates);
            
            var result = new ExchangeRateData
            {
                BoardDateTime = boardDateTime,
                ExchangeRates = exchangeRates,
                ScrapeDateTime = _timeProvider.GetUtcNow().DateTime,
                ScrapeId = scrapeId
            };

            _logger.LogInformation("成功抓取 {Count} 種外幣匯率資料", exchangeRates.Count);
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "抓取匯率資料失敗");
            throw;
        }
    }

    /// <summary>
    /// 使用 Polly 重試策略發送 HTTP 請求
    /// </summary>
    private async Task<string> FetchWebPageWithRetryAsync(HttpClient httpClient, string url, CancellationToken cancellationToken)
    {
        var retryPolicy = Policy
            .Handle<HttpRequestException>()
            .Or<TaskCanceledException>()
            .Or<SocketException>()
            .WaitAndRetryAsync(
                retryCount: _settings.RetryCount,
                sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                onRetry: (outcome, timespan, retryCount, context) =>
                {
                    _logger.LogWarning("第 {RetryCount} 次重試 URL: {Url}，延遲 {Delay}ms", 
                        retryCount, url, timespan.TotalMilliseconds);
                });

        return await retryPolicy.ExecuteAsync(async () =>
        {
            using var response = await httpClient.GetAsync(url, cancellationToken);
            response.EnsureSuccessStatusCode();
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken);
            
            if (string.IsNullOrWhiteSpace(content))
            {
                throw new WebScrapingException("網頁內容為空");
            }
            
            return content;
        });
    }

    /// <summary>
    /// 驗證 HTML 結構是否符合預期
    /// </summary>
    private bool ValidateHtmlStructure(HtmlDocument document)
    {
        try
        {
            // 檢查關鍵元素是否存在
            var boardTimeElement = document.DocumentNode
                .SelectSingleNode("//div[contains(text(), '資料時間 Board time')]");
            
            var currencyElements = document.DocumentNode
                .SelectNodes("//div[contains(@class, 'currency') or contains(text(), 'USD') or contains(text(), 'EUR')]");
            
            return boardTimeElement != null && currencyElements?.Count > 0;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "HTML 結構驗證失敗");
            return false;
        }
    }

    /// <summary>
    /// 提取資料時間戳記
    /// </summary>
    private DateTime ExtractBoardDateTime(HtmlDocument document)
    {
        try
        {
            // 查找包含 "資料時間 Board time" 的元素
            var boardTimeNode = document.DocumentNode
                .SelectSingleNode("//text()[contains(., '資料時間 Board time')]")
                ?.ParentNode;

            if (boardTimeNode == null)
            {
                // 備用解析方式
                boardTimeNode = document.DocumentNode
                    .SelectSingleNode("//*[contains(text(), '資料時間')]");
            }

            if (boardTimeNode != null)
            {
                var timeText = boardTimeNode.InnerText;
                
                // 使用正規表達式提取時間
                // 格式: "資料時間 Board time： 2025年08月01日 13:07:49"
                var timeMatch = Regex.Match(timeText, @"(\d{4})年(\d{2})月(\d{2})日\s+(\d{2}):(\d{2}):(\d{2})");
                
                if (timeMatch.Success)
                {
                    var year = int.Parse(timeMatch.Groups[1].Value);
                    var month = int.Parse(timeMatch.Groups[2].Value);
                    var day = int.Parse(timeMatch.Groups[3].Value);
                    var hour = int.Parse(timeMatch.Groups[4].Value);
                    var minute = int.Parse(timeMatch.Groups[5].Value);
                    var second = int.Parse(timeMatch.Groups[6].Value);
                    
                    return new DateTime(year, month, day, hour, minute, second);
                }
            }
            
            _logger.LogWarning("無法解析資料時間，使用當前時間");
            return _timeProvider.GetLocalNow().DateTime;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "提取資料時間失敗");
            return _timeProvider.GetLocalNow().DateTime;
        }
    }

    /// <summary>
    /// 提取16種外幣匯率資料
    /// </summary>
    private List<ExchangeRateItem> ExtractExchangeRates(HtmlDocument document)
    {
        var exchangeRates = new List<ExchangeRateItem>();
        
        // 定義16種外幣代號
        var currencyCodes = new[]
        {
            "USD", "EUR", "JPY", "CNY", "HKD", "AUD", "NZD", "ZAR",
            "CAD", "GBP", "CHF", "SEK", "SGD", "THB", "DKK", "TRY"
        };

        foreach (var currencyCode in currencyCodes)
        {
            try
            {
                var rateItem = ExtractSingleCurrencyRate(document, currencyCode);
                if (rateItem != null)
                {
                    exchangeRates.Add(rateItem);
                }
                else
                {
                    _logger.LogWarning("無法提取 {CurrencyCode} 的匯率資料", currencyCode);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "提取 {CurrencyCode} 匯率資料時發生錯誤", currencyCode);
            }
        }

        return exchangeRates;
    }

    /// <summary>
    /// 提取單一幣別的匯率資料
    /// </summary>
    private ExchangeRateItem ExtractSingleCurrencyRate(HtmlDocument document, string currencyCode)
    {
        try
        {
            // 方法1: 尋找包含幣別代號的元素
            var currencyNode = document.DocumentNode
                .SelectSingleNode($"//text()[contains(., '{currencyCode}')]")
                ?.ParentNode;

            if (currencyNode == null)
            {
                // 方法2: 使用 XPath 查找包含幣別的區塊
                currencyNode = document.DocumentNode
                    .SelectSingleNode($"//*[contains(@class, 'currency') and contains(., '{currencyCode}')]");
            }

            if (currencyNode == null) return null;

            // 提取幣別名稱 (例如: "美元USD" -> "美元")
            var fullText = currencyNode.InnerText.Trim();
            var currencyName = ExtractCurrencyName(fullText, currencyCode);

            // 查找父級或兄弟元素中的匯率資料
            var rateContainer = currencyNode.ParentNode ?? currencyNode;
            
            // 提取買進和賣出匯率
            var buyRate = ExtractRate(rateContainer, "buy", "買進");
            var sellRate = ExtractRate(rateContainer, "sell", "賣出");

            if (buyRate.HasValue && sellRate.HasValue)
            {
                return new ExchangeRateItem
                {
                    CurrencyCode = currencyCode,
                    CurrencyName = currencyName,
                    BankBuyRate = buyRate.Value,
                    BankSellRate = sellRate.Value
                };
            }

            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "解析 {CurrencyCode} 匯率失敗", currencyCode);
            return null;
        }
    }

    /// <summary>
    /// 提取幣別名稱
    /// </summary>
    private string ExtractCurrencyName(string fullText, string currencyCode)
    {
        // 從 "美元USD" 提取 "美元"
        var index = fullText.IndexOf(currencyCode);
        if (index > 0)
        {
            return fullText.Substring(0, index).Trim();
        }
        
        // 備用: 使用預定義的對應表
        return GetCurrencyNameFromCode(currencyCode);
    }

    /// <summary>
    /// 提取匯率數值
    /// </summary>
    private decimal? ExtractRate(HtmlNode container, string rateType, string chineseName)
    {
        try
        {
            // 方法1: 查找包含中文名稱的元素
            var rateNode = container.SelectSingleNode($".//*[contains(text(), '{chineseName}')]");
            
            if (rateNode == null)
            {
                // 方法2: 查找包含英文標識的元素
                rateNode = container.SelectSingleNode($".//*[contains(@class, '{rateType}')]");
            }
            
            if (rateNode == null)
            {
                // 方法3: 查找所有數字，按位置推斷
                var numberNodes = container.SelectNodes(".//text()[normalize-space()]")
                    ?.Where(n => Regex.IsMatch(n.InnerText, @"\d+\.\d+"))
                    .ToList();
                
                if (numberNodes?.Count >= 2)
                {
                    // 假設第一個是買進，第二個是賣出
                    var targetNode = rateType == "buy" ? numberNodes[0] : numberNodes[1];
                    return ParseDecimal(targetNode.InnerText);
                }
            }
            else
            {
                // 在找到的節點附近查找數字
                var numberText = FindNearbyNumber(rateNode);
                return ParseDecimal(numberText);
            }

            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "提取 {RateType} 匯率失敗", rateType);
            return null;
        }
    }

    /// <summary>
    /// 在節點附近查找數字
    /// </summary>
    private string FindNearbyNumber(HtmlNode node)
    {
        // 查找當前節點的文字
        var match = Regex.Match(node.InnerText, @"\d+\.\d+");
        if (match.Success) return match.Value;

        // 查找父節點
        if (node.ParentNode != null)
        {
            match = Regex.Match(node.ParentNode.InnerText, @"\d+\.\d+");
            if (match.Success) return match.Value;
        }

        // 查找兄弟節點
        if (node.NextSibling != null)
        {
            match = Regex.Match(node.NextSibling.InnerText, @"\d+\.\d+");
            if (match.Success) return match.Value;
        }

        return null;
    }

    /// <summary>
    /// 解析十進位數字
    /// </summary>
    private decimal? ParseDecimal(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        
        // 清理數值字串
        var cleanValue = Regex.Replace(value, @"[^\d\.]", "");
        
        if (decimal.TryParse(cleanValue, out var result))
        {
            return result;
        }
        
        return null;
    }

    /// <summary>
    /// 驗證提取的資料
    /// </summary>
    private void ValidateExtractedData(List<ExchangeRateItem> exchangeRates)
    {
        if (exchangeRates.Count < 10)
        {
            throw new WebScrapingException($"提取的匯率資料不足，僅有 {exchangeRates.Count} 種幣別");
        }

        var invalidRates = exchangeRates.Where(r => 
            r.BankBuyRate <= 0 || r.BankSellRate <= 0 || 
            r.BankBuyRate > r.BankSellRate).ToList();

        if (invalidRates.Any())
        {
            var invalidCurrencies = string.Join(", ", invalidRates.Select(r => r.CurrencyCode));
            _logger.LogWarning("發現無效的匯率資料: {InvalidCurrencies}", invalidCurrencies);
        }
    }

    /// <summary>
    /// 根據幣別代號取得幣別名稱
    /// </summary>
    private string GetCurrencyNameFromCode(string currencyCode)
    {
        var currencyNames = new Dictionary<string, string>
        {
            {"USD", "美元"}, {"EUR", "歐元"}, {"JPY", "日圓"}, {"CNY", "人民幣"},
            {"HKD", "港幣"}, {"AUD", "澳大利亞幣"}, {"NZD", "紐西蘭幣"}, {"ZAR", "南非幣"},
            {"CAD", "加拿大幣"}, {"GBP", "英鎊"}, {"CHF", "瑞士法郎"}, {"SEK", "瑞典幣"},
            {"SGD", "新加坡幣"}, {"THB", "泰國幣"}, {"DKK", "丹麥幣"}, {"TRY", "土耳其里拉"}
        };

        return currencyNames.TryGetValue(currencyCode, out var name) ? name : currencyCode;
    }

    /// <summary>
    /// 驗證網站結構
    /// </summary>
    public async Task<bool> ValidateWebsiteStructureAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            using var httpClient = _httpClientFactory.CreateClient("CathayBankScraper");
            var htmlContent = await FetchWebPageWithRetryAsync(httpClient, TargetUrl, cancellationToken);
            var document = new HtmlDocument();
            document.LoadHtml(htmlContent);
            
            return ValidateHtmlStructure(document);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "網站結構驗證失敗");
            return false;
        }
    }

    /// <summary>
    /// 取得資料時間
    /// </summary>
    public async Task<string> GetBoardTimeAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            using var httpClient = _httpClientFactory.CreateClient("CathayBankScraper");
            var htmlContent = await FetchWebPageWithRetryAsync(httpClient, TargetUrl, cancellationToken);
            var document = new HtmlDocument();
            document.LoadHtml(htmlContent);
            
            var boardDateTime = ExtractBoardDateTime(document);
            return boardDateTime.ToString("yyyy年MM月dd日 HH:mm:ss");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "取得資料時間失敗");
            return _timeProvider.GetLocalNow().DateTime.ToString("yyyy年MM月dd日 HH:mm:ss");
        }
    }
}
```

#### 資料傳輸物件 (DTOs)
```csharp
public class ExchangeRateData
{
    public DateTime BoardDateTime { get; set; }
    public DateTime ScrapeDateTime { get; set; }
    public Guid ScrapeId { get; set; }
    public List<ExchangeRateItem> ExchangeRates { get; set; } = new();
}

public class ExchangeRateItem
{
    public string CurrencyCode { get; set; }
    public string CurrencyName { get; set; }
    public decimal BankBuyRate { get; set; }
    public decimal BankSellRate { get; set; }
}

public class ScrapingSettings
{
    public string TargetUrl { get; set; }
    public int TimeoutSeconds { get; set; } = 30;
    public int RetryCount { get; set; } = 3;
    public int RetryDelaySeconds { get; set; } = 5;
    public string UserAgent { get; set; } = "CathayBank Exchange Rate Bot 1.0";
}
```

#### 自定義例外處理
```csharp
public class WebScrapingException : Exception
{
    public WebScrapingException(string message) : base(message) { }
    public WebScrapingException(string message, Exception innerException) : base(message, innerException) { }
}
```

### 3. 資料服務模組

#### ExchangeRateService
```csharp
public interface IExchangeRateService
{
    Task<List<ExchangeRateDto>> GetLatestRatesAsync(CancellationToken cancellationToken = default);
    Task<List<ExchangeRateDto>> GetRatesByCurrencyAsync(string currencyCode, DateTime? fromDate = null, DateTime? toDate = null, CancellationToken cancellationToken = default);
    Task<ExchangeRateDto> GetLatestRateByCurrencyAsync(string currencyCode, CancellationToken cancellationToken = default);
    Task SaveExchangeRatesAsync(ExchangeRateData data, CancellationToken cancellationToken = default);
}
```

### 4. 快取服務模組

#### HybridCacheService
```csharp
public interface IHybridCacheService
{
    Task<T> GetAsync<T>(string key, CancellationToken cancellationToken = default);
    Task SetAsync<T>(string key, T value, TimeSpan? expiry = null, CancellationToken cancellationToken = default);
    Task RemoveAsync(string key, CancellationToken cancellationToken = default);
    Task RemoveByPatternAsync(string pattern, CancellationToken cancellationToken = default);
}
```

---

## API 設計

### 1. Controller 設計

#### ExchangeRatesController
```csharp
[ApiController]
[Route("api/[controller]")]
public class ExchangeRatesController : ControllerBase
{
    /// <summary>
    /// 取得最新匯率資料
    /// </summary>
    [HttpGet("latest")]
    public async Task<ActionResult<ApiResponse<List<ExchangeRateDto>>>> GetLatestRates()

    /// <summary>
    /// 取得特定幣別的最新匯率
    /// </summary>
    [HttpGet("latest/{currencyCode}")]
    public async Task<ActionResult<ApiResponse<ExchangeRateDto>>> GetLatestRateByCurrency(string currencyCode)

    /// <summary>
    /// 取得特定幣別的歷史匯率
    /// </summary>
    [HttpGet("{currencyCode}/history")]
    public async Task<ActionResult<ApiResponse<List<ExchangeRateDto>>>> GetHistoryRates(
        string currencyCode,
        [FromQuery] DateTime? fromDate = null,
        [FromQuery] DateTime? toDate = null,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 100)

    /// <summary>
    /// 取得支援的幣別清單
    /// </summary>
    [HttpGet("currencies")]
    public async Task<ActionResult<ApiResponse<List<CurrencyDto>>>> GetSupportedCurrencies()
}
```

### 2. DTO 設計

#### ExchangeRateDto
```csharp
public class ExchangeRateDto
{
    public string CurrencyCode { get; set; }
    public string CurrencyName { get; set; }
    public string CurrencySymbol { get; set; }
    public decimal BankBuyRate { get; set; }
    public decimal BankSellRate { get; set; }
    public DateTime BoardDateTime { get; set; }
    public string FormattedBoardTime => BoardDateTime.ToString("yyyy年MM月dd日 HH:mm:ss");
}
```

#### ApiResponse
```csharp
public class ApiResponse<T>
{
    public bool Success { get; set; }
    public T Data { get; set; }
    public string Message { get; set; }
    public DateTime Timestamp { get; set; } = TimeProvider.System.GetUtcNow().DateTime;
}
```

---

## 技術實作細節

### 1. 專案結構
```
CathayBank.RealtimeExchangeRate/
├── src/
│   ├── CathayBank.RealtimeExchangeRate.Api/
│   │   ├── Controllers/
│   │   ├── Program.cs
│   │   ├── appsettings.json
│   │   └── appsettings.Development.json
│   ├── CathayBank.RealtimeExchangeRate.Application/
│   │   ├── Services/
│   │   ├── DTOs/
│   │   ├── Interfaces/
│   │   └── Validators/
│   ├── CathayBank.RealtimeExchangeRate.Domain/
│   │   ├── Entities/
│   │   ├── ValueObjects/
│   │   └── Interfaces/
│   ├── CathayBank.RealtimeExchangeRate.Infrastructure/
│   │   ├── Data/
│   │   ├── Services/
│   │   ├── Configurations/
│   │   └── Extensions/
│   └── CathayBank.RealtimeExchangeRate.BackgroundServices/
│       ├── Services/
│       └── Configurations/
├── tests/
│   ├── Unit/
│   └── Integration/
├── docs/
└── scripts/
```

### 2. 設定檔配置

#### appsettings.json - 網頁抓取設定
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=CathayBankExchangeRate;Trusted_Connection=true;MultipleActiveResultSets=true",
    "Redis": "localhost:6379"
  },
  "ScrapingSettings": {
    "TargetUrl": "https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/",
    "CronExpression": "0 */5 8-16 * * 1-5",
    "TimeoutSeconds": 30,
    "RetryCount": 3,
    "RetryDelaySeconds": 5,
    "UserAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "MaxConcurrentRequests": 1,
    "RequestDelayMs": 1000,
    "EnableStructureValidation": true,
    "FallbackParsingEnabled": true
  },
  "CacheSettings": {
    "DefaultExpiry": "00:05:00",
    "LatestRatesKey": "exchange_rates:latest",
    "CurrencyRateKeyPattern": "exchange_rates:currency:{0}",
    "ScrapingStatusKey": "scraping:status"
  },
  "ApiSettings": {
    "RateLimitPerMinute": 100,
    "DefaultPageSize": 20,
    "MaxPageSize": 100
  }
}
```

### 3. 網頁抓取技術細節

#### 使用的技術棧
```
網頁抓取層級架構：
├── HTTP 通訊層
│   ├── HttpClientFactory - HTTP 客戶端管理
│   ├── Polly - 重試與熔斷策略
│   └── 自定義 Headers - 模擬真實瀏覽器
├── HTML 解析層
│   ├── HtmlAgilityPack - DOM 解析與操作
│   ├── XPath 查詢 - 精確元素定位
│   └── Regex - 文字模式匹配
├── 資料提取層
│   ├── 結構化解析 - 主要解析邏輯
│   ├── 容錯解析 - 備用解析策略
│   └── 資料驗證 - 完整性檢查
└── 錯誤處理層
    ├── 網路異常處理
    ├── 結構變更偵測
    └── 日誌記錄與警報
```

#### HTML 解析策略詳解

##### 主要解析策略
```csharp
/// <summary>
/// 多重解析策略，提高抓取成功率
/// </summary>
public class HtmlParsingStrategy
{
    // 策略 1: CSS 選擇器 (最精確)
    private readonly string[] _currencySelectors = {
        ".currency-item[data-currency='{0}']",
        "[data-testid='currency-{0}']",
        ".exchange-rate[data-code='{0}']"
    };
    
    // 策略 2: XPath 查詢 (靈活性高)
    private readonly string[] _xpathQueries = {
        "//div[contains(@class, 'currency') and contains(text(), '{0}')]",
        "//span[text()='{0}']/ancestor::div[contains(@class, 'rate')]",
        "//*[contains(text(), '{0}')]/following-sibling::*[contains(@class, 'rate')]"
    };
    
    // 策略 3: 文字模式匹配 (最後手段)
    private readonly string[] _textPatterns = {
        @"{0}[\s\S]*?買進[\s\S]*?(\d+\.\d+)[\s\S]*?賣出[\s\S]*?(\d+\.\d+)",
        @"{0}.*?(\d+\.\d+).*?(\d+\.\d+)",
        @"(\d+\.\d+).*?(\d+\.\d+).*?{0}"
    };
}
```

##### 自適應解析邏輯
```csharp
/// <summary>
/// 自適應解析器 - 當網站結構變更時自動切換策略
/// </summary>
public class AdaptiveParser
{
    public ExchangeRateItem ParseCurrency(HtmlDocument document, string currencyCode)
    {
        // 嘗試策略 1: 結構化解析
        var result = TryStructuredParsing(document, currencyCode);
        if (result != null) return result;
        
        // 嘗試策略 2: 模糊匹配
        result = TryFuzzyMatching(document, currencyCode);
        if (result != null) return result;
        
        // 嘗試策略 3: 正規表達式
        result = TryRegexParsing(document, currencyCode);
        if (result != null) return result;
        
        // 所有策略失敗，記錄並返回 null
        _logger.LogWarning("所有解析策略對 {CurrencyCode} 都失敗了", currencyCode);
        return null;
    }
    
    private ExchangeRateItem TryStructuredParsing(HtmlDocument document, string currencyCode)
    {
        try
        {
            // 查找貨幣容器
            var currencyContainer = document.DocumentNode
                .SelectSingleNode($"//div[contains(@class, 'currency-item') and .//text()[contains(., '{currencyCode}')]]");
            
            if (currencyContainer == null) return null;
            
            // 提取買進價格
            var buyPriceNode = currencyContainer
                .SelectSingleNode(".//span[contains(@class, 'buy-rate')] | .//td[contains(@class, 'buy')] | .//*[contains(text(), '買進')]/following-sibling::*");
            
            // 提取賣出價格
            var sellPriceNode = currencyContainer
                .SelectSingleNode(".//span[contains(@class, 'sell-rate')] | .//td[contains(@class, 'sell')] | .//*[contains(text(), '賣出')]/following-sibling::*");
            
            var buyRate = ExtractDecimalFromNode(buyPriceNode);
            var sellRate = ExtractDecimalFromNode(sellPriceNode);
            
            if (buyRate.HasValue && sellRate.HasValue)
            {
                return new ExchangeRateItem
                {
                    CurrencyCode = currencyCode,
                    CurrencyName = GetCurrencyNameFromCode(currencyCode),
                    BankBuyRate = buyRate.Value,
                    BankSellRate = sellRate.Value
                };
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "結構化解析失敗 for {CurrencyCode}", currencyCode);
        }
        
        return null;
    }
    
    private ExchangeRateItem TryFuzzyMatching(HtmlDocument document, string currencyCode)
    {
        try
        {
            // 使用模糊匹配查找包含貨幣代碼的所有節點
            var allNodes = document.DocumentNode.SelectNodes("//text()[normalize-space()]")
                ?.Where(n => n.InnerText.Contains(currencyCode))
                .Select(n => n.ParentNode)
                .ToList();
            
            if (allNodes?.Any() == true)
            {
                foreach (var node in allNodes)
                {
                    var rates = ExtractRatesFromContext(node);
                    if (rates.buyRate.HasValue && rates.sellRate.HasValue)
                    {
                        return new ExchangeRateItem
                        {
                            CurrencyCode = currencyCode,
                            CurrencyName = GetCurrencyNameFromCode(currencyCode),
                            BankBuyRate = rates.buyRate.Value,
                            BankSellRate = rates.sellRate.Value
                        };
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "模糊匹配失敗 for {CurrencyCode}", currencyCode);
        }
        
        return null;
    }
    
    private (decimal? buyRate, decimal? sellRate) ExtractRatesFromContext(HtmlNode node)
    {
        // 在節點上下文中查找數字
        var contextText = GetContextText(node);
        var numbers = Regex.Matches(contextText, @"\d+\.\d+")
            .Cast<Match>()
            .Select(m => decimal.Parse(m.Value))
            .Where(d => d > 0 && d < 1000) // 合理的匯率範圍
            .ToList();
        
        if (numbers.Count >= 2)
        {
            // 假設第一個較小的是買進，第二個較大的是賣出
            var sorted = numbers.OrderBy(n => n).ToList();
            return (sorted[0], sorted[1]);
        }
        
        return (null, null);
    }
    
    private string GetContextText(HtmlNode node)
    {
        var context = new StringBuilder();
        
        // 收集父節點文字
        context.Append(node.ParentNode?.InnerText ?? "");
        
        // 收集兄弟節點文字
        var siblings = node.ParentNode?.ChildNodes?.Where(n => n.NodeType == HtmlNodeType.Element);
        if (siblings != null)
        {
            foreach (var sibling in siblings)
            {
                context.Append(" " + sibling.InnerText);
            }
        }
        
        return context.ToString();
    }
}
```

#### 網站結構變更偵測
```csharp
/// <summary>
/// 網站結構變更監控器
/// </summary>
public class WebsiteStructureMonitor
{
    private readonly ILogger<WebsiteStructureMonitor> _logger;
    private readonly IMemoryCache _cache;
    private const string StructureHashKey = "website_structure_hash";
    
    public async Task<bool> DetectStructureChangeAsync(HtmlDocument document)
    {
        // 計算當前結構的雜湊值
        var currentHash = CalculateStructureHash(document);
        
        // 取得快取的雜湊值
        var cachedHash = _cache.Get<string>(StructureHashKey);
        
        if (cachedHash == null)
        {
            // 第一次執行，儲存雜湊值
            _cache.Set(StructureHashKey, currentHash, TimeSpan.FromHours(24));
            return false;
        }
        
        if (currentHash != cachedHash)
        {
            _logger.LogWarning("偵測到網站結構變更。舊雜湊: {OldHash}, 新雜湊: {NewHash}", 
                cachedHash, currentHash);
            
            // 更新快取
            _cache.Set(StructureHashKey, currentHash, TimeSpan.FromHours(24));
            
            // 觸發警報
            await TriggerStructureChangeAlert(cachedHash, currentHash);
            
            return true;
        }
        
        return false;
    }
    
    private string CalculateStructureHash(HtmlDocument document)
    {
        // 提取關鍵結構元素
        var keyElements = new[]
        {
            document.DocumentNode.SelectNodes("//div[contains(@class, 'currency')]")?.Count ?? 0,
            document.DocumentNode.SelectNodes("//table")?.Count ?? 0,
            document.DocumentNode.SelectNodes("//*[contains(text(), '資料時間')]")?.Count ?? 0,
            document.DocumentNode.SelectNodes("//*[contains(text(), '買進')]")?.Count ?? 0,
            document.DocumentNode.SelectNodes("//*[contains(text(), '賣出')]")?.Count ?? 0
        };
        
        var structureData = string.Join(",", keyElements);
        
        // 計算 SHA256 雜湊
        using var sha256 = SHA256.Create();
        var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(structureData));
        return Convert.ToBase64String(hashBytes);
    }
}
```

#### 效能優化策略
```csharp
/// <summary>
/// 抓取效能優化器
/// </summary>
public class ScrapingPerformanceOptimizer
{
    // 1. 請求池管理
    private readonly SemaphoreSlim _requestSemaphore;
    
    // 2. 回應快取
    private readonly IMemoryCache _responseCache;
    
    // 3. HttpClientFactory
    private readonly IHttpClientFactory _httpClientFactory;
    
    public ScrapingPerformanceOptimizer(IHttpClientFactory httpClientFactory, IMemoryCache cache)
    {
        _httpClientFactory = httpClientFactory;
        _responseCache = cache;
        _requestSemaphore = new SemaphoreSlim(1, 1); // 限制併發請求數
    }
    
    public async Task<string> FetchWithOptimizationAsync(string url, CancellationToken cancellationToken)
    {
        // 檢查快取
        var cacheKey = $"html_content_{url.GetHashCode()}";
        if (_responseCache.TryGetValue(cacheKey, out string cachedContent))
        {
            return cachedContent;
        }
        
        // 限制併發
        await _requestSemaphore.WaitAsync(cancellationToken);
        
        try
        {
            using var httpClient = _httpClientFactory.CreateClient("CathayBankScraper");
            var response = await httpClient.GetAsync(url, cancellationToken);
            var content = await response.Content.ReadAsStringAsync(cancellationToken);
            
            // 快取回應 (短時間)
            _responseCache.Set(cacheKey, content, TimeSpan.FromMinutes(1));
            
            return content;
        }
        finally
        {
            _requestSemaphore.Release();
        }
    }
}
```

### 3. 依賴注入配置

#### Program.cs - HttpClientFactory 配置
```csharp
var builder = WebApplication.CreateBuilder(args);

// 註冊資料庫服務
builder.Services.AddDbContext<ExchangeRateDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// 註冊快取服務
builder.Services.AddStackExchangeRedisCache(options =>
    options.Configuration = builder.Configuration.GetConnectionString("Redis"));
builder.Services.AddMemoryCache();
builder.Services.AddHybridCache();

// 註冊時間提供者
builder.Services.AddSingleton(TimeProvider.System);

// 註冊設定類別
builder.Services.Configure<ScrapingSettings>(
    builder.Configuration.GetSection("ScrapingSettings"));

// 註冊業務服務
builder.Services.AddScoped<IExchangeRateService, ExchangeRateService>();
builder.Services.AddScoped<IWebScrapingService, WebScrapingService>();
builder.Services.AddScoped<IHybridCacheService, HybridCacheService>();

// 使用 HttpClientFactory 註冊具名 HttpClient
builder.Services.AddHttpClient("CathayBankScraper", client =>
{
    var scrapingSettings = builder.Configuration.GetSection("ScrapingSettings").Get<ScrapingSettings>();
    
    client.Timeout = TimeSpan.FromSeconds(scrapingSettings.TimeoutSeconds);
    client.DefaultRequestHeaders.Add("User-Agent", scrapingSettings.UserAgent);
    client.DefaultRequestHeaders.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
    client.DefaultRequestHeaders.Add("Accept-Language", "zh-TW,zh;q=0.8,en-US;q=0.5,en;q=0.3");
    client.DefaultRequestHeaders.Add("Accept-Encoding", "gzip, deflate, br");
    client.DefaultRequestHeaders.Add("DNT", "1");
    client.DefaultRequestHeaders.Add("Connection", "keep-alive");
    client.DefaultRequestHeaders.Add("Upgrade-Insecure-Requests", "1");
})
.AddPolicyHandler(GetRetryPolicy())           // 加入重試策略
.AddPolicyHandler(GetCircuitBreakerPolicy()); // 加入熔斷器策略

// 註冊背景服務
builder.Services.AddHostedService<ExchangeRateScrapingService>();

// 註冊健康檢查
builder.Services.AddHealthChecks()
    .AddCheck<ExchangeRateHealthCheck>("exchange_rate_health")
    .AddDbContextCheck<ExchangeRateDbContext>("database_health")
    .AddRedis(builder.Configuration.GetConnectionString("Redis"), "redis_health");

var app = builder.Build();

// Polly 重試策略
static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
{
    return HttpPolicyExtensions
        .HandleTransientHttpError() // 處理 HttpRequestException 和 5XX, 408 狀態碼
        .OrResult(msg => !msg.IsSuccessStatusCode)
        .WaitAndRetryAsync(
            retryCount: 3,
            sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
            onRetry: (outcome, timespan, retryCount, context) =>
            {
                Console.WriteLine($"Retry {retryCount} after {timespan} seconds");
            });
}

// 熔斷器策略
static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerPolicy()
{
    return HttpPolicyExtensions
        .HandleTransientHttpError()
        .CircuitBreakerAsync(
            handledEventsAllowedBeforeBreaking: 3,
            durationOfBreak: TimeSpan.FromSeconds(30),
            onBreak: (result, timespan) =>
            {
                Console.WriteLine($"Circuit breaker opened for {timespan}");
            },
            onReset: () =>
            {
                Console.WriteLine("Circuit breaker reset");
            });
}
```

#### appsettings.json - 網頁抓取設定
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=CathayBankExchangeRate;Trusted_Connection=true;MultipleActiveResultSets=true",
    "Redis": "localhost:6379"
  },
  "ScrapingSettings": {
    "TargetUrl": "https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/",
    "CronExpression": "0 */5 8-16 * * 1-5",
    "TimeoutSeconds": 30,
    "RetryCount": 3,
    "RetryDelaySeconds": 5,
    "UserAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "MaxConcurrentRequests": 1,
    "RequestDelayMs": 1000,
    "EnableStructureValidation": true,
    "FallbackParsingEnabled": true
  },
  "CacheSettings": {
    "DefaultExpiry": "00:05:00",
    "LatestRatesKey": "exchange_rates:latest",
    "CurrencyRateKeyPattern": "exchange_rates:currency:{0}",
    "ScrapingStatusKey": "scraping:status"
  }
}
```

---

## 流程圖與循序圖

### 1. 匯率資料抓取流程圖

```mermaid
flowchart TD
    A[系統啟動] --> B[註冊背景服務]
    B --> C[CronTimer 等待觸發]
    C --> D{"符合執行時間?<br/>工作日 08:30-16:30"}
    D -->|否| C
    D -->|是| E[開始抓取程序]
    
    E --> F[建立 HTTP 請求]
    F --> G[發送請求到國泰銀行網站]
    G --> H{"請求是否成功?"}
    H -->|否| I["重試機制<br/>最多3次"]
    I --> J{"重試次數用完?"}
    J -->|否| G
    J -->|是| K[記錄錯誤日誌]
    K --> L[等待下次執行]
    
    H -->|是| M[解析 HTML 內容]
    M --> N[提取16種外幣資料]
    N --> O[解析資料時間戳記]
    O --> P[驗證資料完整性]
    P --> Q{"資料驗證通過?"}
    Q -->|否| R[記錄警告日誌]
    R --> L
    
    Q -->|是| S[檢查重複資料]
    S --> T{"資料已存在?"}
    T -->|是| U[略過儲存]
    U --> L
    
    T -->|否| V[開始資料庫交易]
    V --> W[儲存匯率資料]
    W --> X[更新快取]
    X --> Y[提交交易]
    Y --> Z[記錄成功日誌]
    Z --> L
    
    L --> AA[等待5分鐘]
    AA --> C
    
    style E fill:#e1f5fe
    style X fill:#f3e5f5
    style W fill:#e8f5e8
```

### 2. API 查詢處理流程圖

```mermaid
flowchart TD
    A[客戶端發送 API 請求] --> B["API Gateway / Load Balancer"]
    B --> C[ExchangeRatesController]
    C --> D[驗證請求參數]
    D --> E{"參數驗證通過?"}
    E -->|否| F["返回 400 Bad Request"]
    
    E -->|是| G[檢查 Memory Cache]
    G --> H{"Memory Cache 命中?"}
    H -->|是| I[返回快取資料]
    
    H -->|否| J[檢查 Redis Cache]
    J --> K{"Redis Cache 命中?"}
    K -->|是| L[更新 Memory Cache]
    L --> M[返回快取資料]
    
    K -->|否| N[查詢資料庫]
    N --> O[執行 SQL 查詢]
    O --> P{"查詢成功?"}
    P -->|否| Q[記錄錯誤日誌]
    Q --> R["返回 500 Server Error"]
    
    P -->|是| S[格式化回應資料]
    S --> T[更新 Redis Cache]
    T --> U[更新 Memory Cache]
    U --> V[返回 API 回應]
    
    I --> W[記錄存取日誌]
    M --> W
    V --> W
    W --> X[結束請求]
    
    style G fill:#e1f5fe
    style J fill:#f3e5f5
    style N fill:#fff3e0
    style T fill:#f3e5f5
    style U fill:#e1f5fe
```

### 3. 資料抓取與儲存循序圖

```mermaid
sequenceDiagram
    participant CT as CronTimer
    participant BS as BackgroundService
    participant WS as WebScrapingService
    participant HC as HttpClient
    participant CB as 國泰銀行網站
    participant ES as ExchangeRateService
    participant DB as SQL Server
    participant RC as Redis Cache
    participant MC as Memory Cache
    participant LOG as Logger

    Note over CT,LOG: 每5分鐘執行一次 (工作日 08:30-16:30)
    
    CT->>BS: 觸發定時任務
    BS->>LOG: 記錄開始日誌
    BS->>WS: ScrapeExchangeRatesAsync()
    
    WS->>HC: CreateRequest(URL)
    HC->>CB: HTTP GET Request
    CB-->>HC: HTML Response
    HC-->>WS: HTML Content
    
    WS->>WS: ParseHTML()
    WS->>WS: ExtractExchangeRates()
    WS->>WS: ParseBoardTime()
    WS-->>BS: ExchangeRateData
    
    BS->>ES: SaveExchangeRatesAsync(data)
    ES->>DB: BeginTransaction()
    
    loop 遍歷16種外幣
        ES->>DB: CheckDuplicate(currencyCode, boardDateTime)
        alt 資料不存在
            ES->>DB: InsertExchangeRate(rate)
        else 資料已存在
            ES->>LOG: 記錄重複資料警告
        end
    end
    
    ES->>DB: CommitTransaction()
    DB-->>ES: Transaction Success
    
    ES->>RC: InvalidateCache("latest_rates")
    ES->>MC: InvalidateCache("latest_rates")
    ES->>RC: SetCache("latest_rates", newData, 5min)
    ES->>MC: SetCache("latest_rates", newData, 5min)
    
    ES-->>BS: SaveResult
    BS->>LOG: 記錄成功日誌
    
    Note over CT,LOG: 等待下次執行
```

### 4. API 查詢處理循序圖

```mermaid
sequenceDiagram
    participant CLIENT as 客戶端
    participant API as ExchangeRatesController
    participant ES as ExchangeRateService
    participant MC as Memory Cache
    participant RC as Redis Cache
    participant DB as SQL Server
    participant LOG as Logger

    CLIENT->>API: GET /api/exchangerates/latest
    API->>API: ValidateRequest()
    
    alt 參數驗證失敗
        API-->>CLIENT: 400 Bad Request
    else 參數驗證成功
        API->>ES: GetLatestRatesAsync()
        
        ES->>MC: GetAsync("latest_rates")
        alt Memory Cache 命中
            MC-->>ES: CachedData
            ES-->>API: ExchangeRateDto[]
            API->>LOG: 記錄 Memory Cache 命中
        else Memory Cache 未命中
            ES->>RC: GetAsync("latest_rates")
            alt Redis Cache 命中
                RC-->>ES: CachedData
                ES->>MC: SetAsync("latest_rates", data, 5min)
                ES-->>API: ExchangeRateDto[]
                API->>LOG: 記錄 Redis Cache 命中
            else Redis Cache 未命中
                ES->>DB: SELECT * FROM ExchangeRates WHERE ...
                DB-->>ES: RawData
                ES->>ES: MapToDto(rawData)
                ES->>RC: SetAsync("latest_rates", data, 15min)
                ES->>MC: SetAsync("latest_rates", data, 5min)
                ES-->>API: ExchangeRateDto[]
                API->>LOG: 記錄資料庫查詢
            end
        end
        
        API->>API: FormatResponse(data)
        API-->>CLIENT: 200 OK + JSON Response
    end
```

### 5. 特定幣別歷史查詢循序圖

```mermaid
sequenceDiagram
    participant CLIENT as 客戶端
    participant API as ExchangeRatesController
    participant ES as ExchangeRateService
    participant MC as Memory Cache
    participant RC as Redis Cache
    participant DB as SQL Server

    CLIENT->>API: GET /api/exchangerates/USD/history?fromDate=2025-07-01&toDate=2025-08-01
    API->>API: ValidateParameters(USD, dates)
    
    alt 參數無效
        API-->>CLIENT: 400 Bad Request
    else 參數有效
        API->>ES: GetRatesByCurrencyAsync("USD", fromDate, toDate)
        
        ES->>ES: GenerateCacheKey("USD", "2025-07-01", "2025-08-01")
        Note right of ES: Cache Key: "rates:USD:2025-07-01:2025-08-01"
        
        ES->>MC: GetAsync(cacheKey)
        alt Memory Cache 命中
            MC-->>ES: CachedHistoryData
        else Memory Cache 未命中
            ES->>RC: GetAsync(cacheKey)
            alt Redis Cache 命中
                RC-->>ES: CachedHistoryData
                ES->>MC: SetAsync(cacheKey, data, 10min)
            else Redis Cache 未命中
                ES->>DB: SELECT * FROM ExchangeRates WHERE CurrencyCode='USD' AND BoardDateTime BETWEEN ...
                DB-->>ES: HistoryData
                ES->>RC: SetAsync(cacheKey, data, 30min)
                ES->>MC: SetAsync(cacheKey, data, 10min)
            end
        end
        
        ES->>ES: ApplyPagination(data, page, pageSize)
        ES-->>API: PagedExchangeRateDto[]
        API-->>CLIENT: 200 OK + Paged JSON Response
    end
```

### 6. 快取失效處理流程圖

```mermaid
flowchart TD
    A[新匯率資料儲存成功] --> B[識別影響的快取鍵]
    B --> C[清除 Memory Cache]
    C --> D[清除 Redis Cache]
    D --> E[更新最新資料快取]
    
    E --> F{"是否為熱門幣別?"}
    F -->|是| G[預熱相關快取]
    F -->|否| H[等待被動載入]
    
    G --> I[載入該幣別最新資料]
    I --> J[載入該幣別近期歷史]
    J --> K[更新快取]
    
    H --> L[快取處理完成]
    K --> L
    
    style C fill:#ffebee
    style D fill:#ffebee
    style E fill:#e8f5e8
    style G fill:#f3e5f5
    
    classDef clearCache fill:#ffebee
    classDef updateCache fill:#e8f5e8
    classDef preloadCache fill:#f3e5f5
```

---

## 快取策略

### 1. 快取層級設計
```
Level 1: Memory Cache (本地快取)
├── 最新匯率資料 (5分鐘過期)
├── 幣別主檔 (1小時過期)
└── 熱門查詢結果 (10分鐘過期)

Level 2: Redis Cache (分散式快取)
├── 歷史匯率資料 (30分鐘過期)
├── 查詢結果快取 (15分鐘過期)
└── 系統配置資料 (1天過期)
```

### 2. 快取鍵設計
```csharp
public static class CacheKeys
{
    public const string LatestRates = "exchange_rates:latest";
    public const string Currencies = "currencies:all";
    public const string CurrencyRate = "exchange_rates:currency:{0}"; // {0} = CurrencyCode
    public const string HistoryRates = "exchange_rates:history:{0}:{1}:{2}"; // {0} = CurrencyCode, {1} = FromDate, {2} = ToDate
    public const string ScrapingStatus = "scraping:status";
}
```

### 3. 快取失效策略
- **主動失效**：每次抓取新資料後，清除相關快取
- **被動失效**：設定 TTL 自動過期
- **標籤失效**：使用標籤群組管理相關快取

### 4. 快取處理詳細流程

#### HybridCache 讀取流程圖
```mermaid
flowchart TD
    A[應用程式請求資料] --> B[檢查 Memory Cache]
    B --> C{"Memory Cache 命中?"}
    C -->|是| D[返回 Memory Cache 資料]
    C -->|否| E[檢查 Redis Cache]
    E --> F{"Redis Cache 命中?"}
    F -->|是| G[返回 Redis 資料]
    G --> H[更新 Memory Cache]
    H --> I[返回資料給應用程式]
    F -->|否| J["查詢資料來源<br/>資料庫"]
    J --> K[更新 Redis Cache]
    K --> L[更新 Memory Cache]
    L --> M[返回資料給應用程式]
    
    D --> N[記錄快取命中統計]
    I --> O[記錄快取命中統計]
    M --> P[記錄快取未命中統計]
    
    style B fill:#e1f5fe
    style E fill:#f3e5f5
    style J fill:#fff3e0
```

#### 快取更新策略流程圖
```mermaid
flowchart TD
    A[資料異動事件] --> B{"異動類型?"}
    B -->|新增匯率| C[寫入資料庫]
    B -->|更新匯率| D[更新資料庫]
    B -->|刪除匯率| E[刪除資料庫記錄]
    
    C --> F[清除相關快取]
    D --> F
    E --> F
    
    F --> G["清除 Memory Cache<br/>latest_rates"]
    G --> H["清除 Memory Cache<br/>currency specific"]
    H --> I["清除 Redis Cache<br/>latest_rates"]
    I --> J["清除 Redis Cache<br/>currency specific"]
    J --> K["清除 Redis Cache<br/>history patterns"]
    
    K --> L[預熱最新資料]
    L --> M[載入最新16種外幣]
    M --> N["更新 Redis Cache<br/>15分鐘TTL"]
    N --> O["更新 Memory Cache<br/>5分鐘TTL"]
    O --> P[快取更新完成]
    
    style F fill:#ffcdd2
    style L fill:#c8e6c9
```

#### 快取鍵命名規範流程
```mermaid
flowchart TD
    A[確定快取需求] --> B{"資料類型?"}
    
    B -->|最新匯率| C["exchange_rates:latest"]
    B -->|特定幣別最新| D["exchange_rates:currency:code"]
    B -->|歷史資料| E["exchange_rates:history:code:from:to"]
    B -->|幣別清單| F["currencies:all"]
    B -->|系統狀態| G["system:scraping_status"]
    
    C --> H["設定 TTL: 5分鐘"]
    D --> I["設定 TTL: 5分鐘"]
    E --> J["設定 TTL: 30分鐘"]
    F --> K["設定 TTL: 1小時"]
    G --> L["設定 TTL: 1分鐘"]
    
    H --> M["加入標籤: latest"]
    I --> N["加入標籤: currency"]
    J --> O["加入標籤: history"]
    K --> P["加入標籤: static"]
    L --> Q["加入標籤: system"]
    
    M --> R[存入 HybridCache]
    N --> R
    O --> R
    P --> R
    Q --> R
```

---

## 錯誤處理與日誌

### 1. 錯誤處理策略

#### 網路錯誤處理
```csharp
public class WebScrapingService
{
    private async Task<string> FetchWebPageWithRetryAsync(string url, CancellationToken cancellationToken)
    {
        var retryPolicy = Policy
            .Handle<HttpRequestException>()
            .Or<TaskCanceledException>()
            .WaitAndRetryAsync(
                retryCount: 3,
                sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                onRetry: (outcome, timespan, retryCount, context) =>
                {
                    _logger.LogWarning("Retry {RetryCount} for URL {Url} after {Delay}ms", 
                        retryCount, url, timespan.TotalMilliseconds);
                });

        return await retryPolicy.ExecuteAsync(async () =>
        {
            var response = await _httpClient.GetAsync(url, cancellationToken);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync(cancellationToken);
        });
    }
}
```

### 2. 日誌記錄

#### 結構化日誌
```csharp
public class ExchangeRateScrapingService
{
    private readonly ILogger<ExchangeRateScrapingService> _logger;
    private readonly IWebScrapingService _webScrapingService;
    private readonly IExchangeRateService _exchangeRateService;
    private readonly TimeProvider _timeProvider;

    public ExchangeRateScrapingService(
        ILogger<ExchangeRateScrapingService> logger,
        IWebScrapingService webScrapingService,
        IExchangeRateService exchangeRateService,
        TimeProvider timeProvider)
    {
        _logger = logger;
        _webScrapingService = webScrapingService;
        _exchangeRateService = exchangeRateService;
        _timeProvider = timeProvider;
    }

    public async Task ProcessExchangeRateScrapingAsync(CancellationToken cancellationToken)
    {
        var scrapingId = Guid.NewGuid();
        using var scope = _logger.BeginScope(new Dictionary<string, object>
        {
            ["ScrapingId"] = scrapingId,
            ["ScrapingStartTime"] = _timeProvider.GetUtcNow().DateTime
        });

        try
        {
            _logger.LogInformation("Starting exchange rate scraping process");
            
            var data = await _webScrapingService.ScrapeExchangeRatesAsync(cancellationToken);
            await _exchangeRateService.SaveExchangeRatesAsync(data, cancellationToken);
            
            _logger.LogInformation("Exchange rate scraping completed successfully. {RecordCount} records processed",
                data.ExchangeRates.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Exchange rate scraping failed");
            // 記錄到資料庫
            await RecordScrapingErrorAsync(scrapingId, ex.Message);
        }
    }
}
```

### 3. 錯誤處理流程圖

#### 網頁抓取錯誤處理流程
```mermaid
flowchart TD
    A[開始網頁抓取] --> B[發送 HTTP 請求]
    B --> C{請求成功?}
    C -->|是| D[解析 HTML 內容]
    C -->|否| E{"是否為網路錯誤?"}
    
    E -->|是| F[執行重試策略]
    E -->|否| G[記錄HTTP錯誤]
    
    F --> H{"重試次數 < 3?"}
    H -->|是| I[等待指數退避時間]
    I --> J[重新發送請求]
    J --> C
    H -->|否| K[重試失敗]
    
    G --> L[記錄詳細錯誤資訊]
    K --> L
    L --> M[更新抓取狀態為失敗]
    M --> N[觸發警報機制]
    
    D --> O{"HTML 解析成功?"}
    O -->|否| P[記錄解析錯誤]
    P --> Q[檢查網站結構變更]
    Q --> R[發送結構變更警報]
    R --> S[使用備用解析器]
    S --> T{"備用解析成功?"}
    T -->|否| L
    T -->|是| U[記錄備用解析使用]
    
    O -->|是| V[驗證資料完整性]
    U --> V
    V --> W{"資料驗證通過?"}
    W -->|否| X[記錄資料驗證錯誤]
    X --> Y[部分資料保存]
    W -->|是| Z[正常儲存流程]
    
    style E fill:#fff3e0
    style F fill:#e1f5fe
    style L fill:#ffcdd2
    style S fill:#f3e5f5
    style Z fill:#c8e6c9
```

#### API 錯誤處理流程
```mermaid
flowchart TD
    A[API 請求進入] --> B[參數驗證]
    B --> C{"參數有效?"}
    C -->|否| D[返回 400 Bad Request]
    D --> E[記錄參數錯誤]
    
    C -->|是| F[執行業務邏輯]
    F --> G{"快取服務可用?"}
    G -->|否| H[降級到資料庫查詢]
    G -->|是| I[正常快取流程]
    
    I --> J{"快取查詢成功?"}
    J -->|否| K[記錄快取錯誤]
    K --> H
    J -->|是| L[返回快取資料]
    
    H --> M{"資料庫連線正常?"}
    M -->|否| N[返回 503 Service Unavailable]
    N --> O[記錄資料庫錯誤]
    O --> P[觸發資料庫警報]
    
    M -->|是| Q[執行資料庫查詢]
    Q --> R{"查詢成功?"}
    R -->|否| S[返回 500 Internal Server Error]
    S --> T[記錄查詢錯誤]
    R -->|是| U[返回查詢結果]
    
    L --> V[記錄成功存取]
    U --> V
    V --> W[更新 API 統計]
    
    E --> X[更新錯誤統計]
    T --> X
    P --> X
    X --> Y[結束請求處理]
    W --> Y
    
    style D fill:#ffcdd2
    style N fill:#ffcdd2
    style S fill:#ffcdd2
    style H fill:#fff3e0
    style L fill:#c8e6c9
    style U fill:#c8e6c9
```

#### 資料庫交易錯誤處理循序圖
```mermaid
sequenceDiagram
    participant ES as ExchangeRateService
    participant DB as Database
    participant LOG as Logger
    participant ALERT as AlertSystem

    ES->>DB: BeginTransaction
    DB-->>ES: OK

    ES->>DB: InsertData
    alt Success
        DB-->>ES: Success
        ES->>LOG: LogSuccess
        ES->>DB: Commit
        DB-->>ES: Committed
    else Error
        DB-->>ES: Error
        ES->>LOG: LogError
        ES->>ALERT: SendAlert
        ES->>DB: Rollback
        DB-->>ES: RolledBack
    end
```

---

## 性能優化

### 1. 資料庫優化
- **索引策略**：針對查詢頻繁的欄位建立索引
- **分區策略**：按月份分區歷史資料
- **連線池**：設定適當的連線池大小

### 2. 快取優化
- **預熱快取**：系統啟動時預先載入熱門資料
- **快取壓縮**：對大型快取物件進行壓縮
- **快取監控**：監控快取命中率

### 3. API 優化
- **分頁查詢**：避免大量資料傳輸
- **壓縮回應**：啟用 Gzip 壓縮
- **並行處理**：使用 async/await 模式

---

## 系統運行監控流程

### 1. 即時監控流程圖

```mermaid
flowchart TD
    A[系統運行中] --> B[健康檢查服務]
    B --> C[檢查資料庫連線]
    C --> D[檢查 Redis 連線]
    D --> E[檢查最後抓取時間]
    E --> F[檢查 API 響應時間]
    F --> G[檢查記憶體使用率]
    G --> H[檢查 CPU 使用率]
    
    H --> I{"所有檢查通過?"}
    I -->|是| J[系統狀態: 健康]
    I -->|否| K[系統狀態: 異常]
    
    J --> L[更新監控儀表板]
    K --> M[觸發警報機制]
    
    M --> N[發送警報通知]
    N --> O[記錄異常日誌]
    O --> P[執行自動修復]
    
    P --> Q{"修復成功?"}
    Q -->|是| R[更新狀態為恢復]
    Q -->|否| S[升級警報等級]
    
    L --> T[等待下次檢查]
    R --> T
    S --> T
    T --> U[30秒後]
    U --> B
    
    style J fill:#c8e6c9
    style K fill:#ffcdd2
    style M fill:#fff3e0
    style P fill:#e1f5fe
```

### 2. 抓取任務監控循序圖

```mermaid
sequenceDiagram
    participant MON as MonitorService
    participant BS as BackgroundService
    participant DB as Database
    participant ALERT as AlertSystem
    participant ADMIN as Administrator

    Note over MON,ADMIN: 每分鐘檢查一次抓取狀態
    
    loop 每分鐘監控
        MON->>DB: 查詢最後抓取記錄
        DB-->>MON: ScrapingLogs 資料
        
        MON->>MON: 計算時間差距
        alt 超過10分鐘未抓取工作時間內
            MON->>ALERT: 觸發延遲警報
            ALERT->>ADMIN: 發送警報通知
            
            MON->>BS: 檢查服務狀態
            BS-->>MON: 服務運行狀態
            
            alt 服務異常
                MON->>ALERT: 觸發服務異常警報
                ALERT->>ADMIN: 發送緊急通知
            end
        end
        
        alt 連續失敗大於3次
            MON->>ALERT: 觸發連續失敗警報
            ALERT->>ADMIN: 發送警報通知
            MON->>MON: 建議人工介入
        end
    end
```

### 3. API 性能監控流程圖

```mermaid
flowchart TD
    A[API 請求開始] --> B[記錄請求開始時間]
    B --> C[處理 API 邏輯]
    C --> D[記錄請求結束時間]
    D --> E[計算響應時間]
    E --> F[記錄快取命中狀態]
    F --> G[更新性能指標]
    
    G --> H{"響應時間 > 2秒?"}
    H -->|否| I[正常性能]
    H -->|是| J[性能警告]
    
    J --> K[檢查資料庫查詢時間]
    K --> L[檢查快取服務狀態]
    L --> M[檢查網路延遲]
    M --> N[生成性能報告]
    
    I --> O[更新儀表板]
    N --> O
    O --> P[記錄到監控日誌]
    
    P --> Q{"需要優化?"}
    Q -->|是| R[建議優化措施]
    Q -->|否| S[繼續監控]
    
    style I fill:#c8e6c9
    style J fill:#fff3e0
    style R fill:#e1f5fe
```

---

## 監控與維護

### 1. 健康檢查
```csharp
public class ExchangeRateHealthCheck : IHealthCheck
{
    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            // 檢查資料庫連線
            // 檢查 Redis 連線
            // 檢查最後一次抓取時間
            // 檢查 API 響應時間
            
            return HealthCheckResult.Healthy("All systems operational");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy("System health check failed", ex);
        }
    }
}
```

### 2. 效能監控
- **響應時間監控**：記錄 API 響應時間
- **抓取成功率**：監控資料抓取成功率
- **快取命中率**：監控快取效能
- **資料庫性能**：監控查詢執行時間

### 3. 警報機制
- **抓取失敗警報**：連續失敗時發送警報
- **資料延遲警報**：資料更新延遲時警報
- **系統異常警報**：CPU、記憶體使用率過高時警報

---

## 安全性考量

### 1. API 安全
- **訪問限流**：防止 API 濫用
- **輸入驗證**：驗證所有輸入參數
- **錯誤資訊保護**：避免洩露敏感資訊

### 2. 資料安全
- **連線字串加密**：加密敏感配置資訊
- **SQL 注入防護**：使用參數化查詢
- **資料傳輸加密**：使用 HTTPS

### 3. 系統安全
- **最小權限原則**：服務帳號使用最小必要權限
- **定期安全更新**：保持套件和系統更新
- **安全掃描**：定期進行安全漏洞掃描

---

## 部署架構

### 1. 開發環境
```
Developer Machine
├── Visual Studio 2022
├── SQL Server LocalDB
├── Redis (Docker)
└── .NET 9 SDK
```

### 2. 測試環境
```
Test Server
├── IIS Express / Kestrel
├── SQL Server Express
├── Redis Standalone
└── Application Insights
```

### 3. 生產環境
```
Production Environment
├── Load Balancer
├── Web Server Cluster (2+ instances)
├── SQL Server Cluster
├── Redis Cluster
├── Monitoring & Logging
└── Backup & Disaster Recovery
```

---

## 開發時程規劃

### Phase 1: 基礎架構建立 (Week 1-2)
- [ ] 專案結構建立
- [ ] 資料庫設計與建立
- [ ] 基礎 API 框架
- [ ] 依賴注入配置

### Phase 2: 核心功能開發 (Week 3-4)
- [ ] 網頁抓取服務開發
- [ ] 背景服務實作
- [ ] 資料存取層開發
- [ ] 單元測試撰寫

### Phase 3: API 服務開發 (Week 5-6)
- [ ] Controller 實作
- [ ] DTO 設計
- [ ] 快取服務整合
- [ ] API 文件撰寫

### Phase 4: 優化與測試 (Week 7-8)
- [ ] 性能優化
- [ ] 整合測試
- [ ] 錯誤處理完善
- [ ] 監控系統建立

### Phase 5: 部署與上線 (Week 9-10)
- [ ] 部署環境準備
- [ ] 生產環境測試
- [ ] 使用者驗收測試
- [ ] 正式上線

---

## 風險評估與應對

### 1. 技術風險
| 風險項目 | 影響程度 | 發生機率 | 應對策略 |
|---------|---------|---------|---------|
| 網站結構變更 | 高 | 中 | 實作彈性解析器，建立監控機制 |
| 網路連線不穩 | 中 | 高 | 實作重試機制，增加錯誤處理 |
| 資料庫性能 | 中 | 低 | 建立索引優化，實作快取策略 |
| Redis 服務中斷 | 低 | 低 | 降級到記憶體快取，實作容錯機制 |

### 2. 業務風險
| 風險項目 | 影響程度 | 發生機率 | 應對策略 |
|---------|---------|---------|---------|
| 資料準確性問題 | 高 | 低 | 實作資料驗證，建立人工審核機制 |
| 服務中斷 | 高 | 低 | 建立高可用架構，實作監控警報 |
| 法規合規性 | 中 | 低 | 確保符合資料使用規範，建立使用條款 |

---

## 測試策略

### 1. TimeProvider 測試實作

由於系統統一使用 TimeProvider，所有時間相關的功能都具備良好的可測試性。

#### 單元測試範例
```csharp
[Test]
public async Task ScrapeExchangeRatesAsync_ShouldSetCorrectScrapeDateTime()
{
    // Arrange
    var fixedTime = new DateTime(2025, 8, 2, 10, 30, 0, DateTimeKind.Utc);
    var fakeTimeProvider = new FakeTimeProvider(fixedTime);
    
    var mockHttpClientFactory = new Mock<IHttpClientFactory>();
    var mockLogger = new Mock<ILogger<WebScrapingService>>();
    var mockConfiguration = new Mock<IConfiguration>();
    var mockSettings = new Mock<IOptions<ScrapingSettings>>();
    
    var service = new WebScrapingService(
        mockHttpClientFactory.Object,
        mockLogger.Object,
        mockConfiguration.Object,
        mockSettings.Object,
        fakeTimeProvider);

    // Act
    var result = await service.ScrapeExchangeRatesAsync();

    // Assert
    Assert.AreEqual(fixedTime, result.ScrapeDateTime);
}

[Test]
public async Task ProcessExchangeRateScrapingAsync_ShouldLogCorrectStartTime()
{
    // Arrange
    var fixedTime = new DateTime(2025, 8, 2, 14, 15, 30, DateTimeKind.Utc);
    var fakeTimeProvider = new FakeTimeProvider(fixedTime);
    
    var mockLogger = new Mock<ILogger<ExchangeRateScrapingService>>();
    var mockServiceProvider = new Mock<IServiceProvider>();
    
    var service = new ExchangeRateScrapingService(
        mockLogger.Object,
        mockServiceProvider.Object,
        fakeTimeProvider);

    // Act
    await service.ProcessExchangeRateScrapingAsync(CancellationToken.None);

    // Assert
    mockLogger.Verify(
        x => x.BeginScope(It.Is<Dictionary<string, object>>(d => 
            d.ContainsKey("ScrapingStartTime") && 
            (DateTime)d["ScrapingStartTime"] == fixedTime)),
        Times.Once);
}
```

#### 整合測試設定
```csharp
public class WebApplicationFactory<T> : Microsoft.AspNetCore.Mvc.Testing.WebApplicationFactory<T> where T : class
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.ConfigureTestServices(services =>
        {
            // 替換 TimeProvider 為測試用的固定時間
            services.RemoveAll<TimeProvider>();
            services.AddSingleton<TimeProvider>(new FakeTimeProvider(
                new DateTime(2025, 8, 2, 12, 0, 0, DateTimeKind.Utc)));
        });
    }
}
```

### 2. 測試涵蓋範圍

#### 單元測試
- [ ] WebScrapingService 時間處理測試
- [ ] ExchangeRateScrapingService 排程測試
- [ ] API Controller 時間戳記測試
- [ ] 時區轉換邏輯測試

#### 整合測試
- [ ] 端到端抓取流程測試
- [ ] 資料庫時間儲存測試
- [ ] API 回應時間格式測試
- [ ] 快取過期時間測試

---

## 總結

本系統設計採用現代化的 ASP.NET Core 9 架構，結合高效的背景服務、多層級快取策略和完善的監控機制，能夠穩定可靠地提供國泰世華銀行外幣匯率即時抓取與查詢服務。

### 主要特色：
1. **高可靠性**：多重錯誤處理和重試機制
2. **高性能**：HybridCache 和資料庫優化
3. **易維護**：清晰的分層架構和完整的日誌記錄
4. **可擴展**：微服務架構設計，支援水平擴展
5. **安全性**：完善的安全防護機制
6. **可測試性**：使用 TimeProvider 統一時間處理，提供優異的測試支援

系統建置完成後，將能提供穩定、高效的外幣匯率資訊服務，滿足使用者對即時和歷史匯率資料的查詢需求。

---

*本文件版本：1.0*  
*最後更新：2025年8月1日*  
*作者：GitHub Copilot*
