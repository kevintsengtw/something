using CathayBank.RealtimeExchangeRate.Application.Interfaces;
using CathayBank.RealtimeExchangeRate.BackgroundServices.Configurations;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Cronos;
using Sgbj.Cron;

namespace CathayBank.RealtimeExchangeRate.BackgroundServices.Services;

/// <summary>
/// 匯率抓取背景服務
/// 使用 CronTimer 定時抓取國泰世華銀行匯率資料
/// </summary>
public class ExchangeRateScrapingService : BackgroundService
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<ExchangeRateScrapingService> _logger;
    private readonly ScrapingConfiguration _configuration;
    private readonly TimeProvider _timeProvider;

    public ExchangeRateScrapingService(
        IServiceProvider serviceProvider,
        ILogger<ExchangeRateScrapingService> logger,
        IOptions<ScrapingConfiguration> configuration,
        TimeProvider timeProvider)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
        _configuration = configuration.Value;
        _timeProvider = timeProvider;

        _logger.LogInformation("匯率抓取服務已初始化");
        _logger.LogInformation("Cron 表達式: {CronExpression}", _configuration.CronExpression);
        _logger.LogInformation("時區: {TimeZone}", _configuration.TimeZone);
        _logger.LogInformation("服務狀態: {Status}", _configuration.Enabled ? "啟用" : "停用");
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("匯率抓取背景服務開始執行");

        if (!_configuration.Enabled)
        {
            _logger.LogWarning("匯率抓取服務已停用，服務將不會執行");
            return;
        }

        try
        {
            // 如果設定為啟動時立即執行
            if (_configuration.RunOnStartup)
            {
                _logger.LogInformation("執行啟動時立即抓取");
                await ExecuteScrapingWithRetryAsync(stoppingToken);
            }

            // 取得時區資訊
            var timeZone = TimeZoneInfo.FindSystemTimeZoneById(_configuration.TimeZone);

            // 解析 Cron 表達式（支援秒）
            var cronExpression = CronExpression.Parse(_configuration.CronExpression, CronFormat.IncludeSeconds);
            
            // 建立 CronTimer
            using var cronTimer = new CronTimer(cronExpression, timeZone);

            _logger.LogInformation("開始等待 Cron 排程執行...");

            // 使用 WaitForNextTickAsync 等待 Cron 觸發
            while (await cronTimer.WaitForNextTickAsync(stoppingToken) && !stoppingToken.IsCancellationRequested)
            {
                var currentTime = _timeProvider.GetLocalNow();
                _logger.LogInformation("Cron 觸發執行 - {CurrentTime}", currentTime.ToString("yyyy-MM-dd HH:mm:ss"));
                
                await ExecuteScrapingWithRetryAsync(stoppingToken);
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("匯率抓取服務收到停止訊號");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "匯率抓取服務執行時發生未預期的錯誤");
            throw;
        }
        finally
        {
            _logger.LogInformation("匯率抓取背景服務已停止");
        }
    }

    /// <summary>
    /// 執行抓取作業並包含重試機制
    /// </summary>
    private async Task ExecuteScrapingWithRetryAsync(CancellationToken cancellationToken)
    {
        var currentTime = _timeProvider.GetLocalNow();
        _logger.LogInformation("開始執行匯率抓取作業 - {CurrentTime}", currentTime.ToString("yyyy-MM-dd HH:mm:ss"));

        var retryCount = 0;
        var maxRetries = _configuration.RetryCount;

        while (retryCount <= maxRetries && !cancellationToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _serviceProvider.CreateScope();
                var exchangeRateService = scope.ServiceProvider.GetRequiredService<IExchangeRateService>();

                var results = await exchangeRateService.ScrapeAndSaveExchangeRatesAsync(cancellationToken);
                var resultCount = results.Count();

                _logger.LogInformation("匯率抓取作業完成 - 成功處理 {Count} 筆資料", resultCount);

                if (resultCount > 0)
                {
                    _logger.LogInformation("新增的匯率資料:");
                    foreach (var rate in results.Take(5)) // 只顯示前5筆避免日誌過長
                    {
                        _logger.LogInformation("  {CurrencyCode}: 買進 {BuyRate}, 賣出 {SellRate}", 
                            rate.CurrencyCode, rate.FormattedBuyRate, rate.FormattedSellRate);
                    }
                    
                    if (resultCount > 5)
                    {
                        _logger.LogInformation("  ... 及其他 {Count} 筆資料", resultCount - 5);
                    }
                }

                // 成功執行，跳出重試迴圈
                break;
            }
            catch (Exception ex)
            {
                retryCount++;
                
                if (retryCount <= maxRetries)
                {
                    var retryDelay = TimeSpan.FromMinutes(_configuration.RetryIntervalMinutes);
                    _logger.LogWarning(ex, "匯率抓取失敗 (第 {RetryCount}/{MaxRetries} 次重試)，{Delay} 後重試", 
                        retryCount, maxRetries, retryDelay);
                    
                    await Task.Delay(retryDelay, cancellationToken);
                }
                else
                {
                    _logger.LogError(ex, "匯率抓取失敗，已達最大重試次數 ({MaxRetries})，放棄執行", maxRetries);
                }
            }
        }
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("正在停止匯率抓取背景服務...");
        
        await base.StopAsync(cancellationToken);
        _logger.LogInformation("匯率抓取背景服務已停止");
    }
}
