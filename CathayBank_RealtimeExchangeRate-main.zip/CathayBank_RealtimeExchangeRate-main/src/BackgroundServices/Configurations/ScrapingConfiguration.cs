namespace CathayBank.RealtimeExchangeRate.BackgroundServices.Configurations;

/// <summary>
/// 抓取服務配置
/// </summary>
public class ScrapingConfiguration
{
    public const string SectionName = "ScrapingSettings";

    /// <summary>
    /// Cron 表達式 - 預設每5分鐘在工作時間抓取一次
    /// 格式：秒 分 時 日 月 星期
    /// "0 */5 8-16 * * 1-5" = 週一到週五，早上8點到下午4點，每5分鐘執行一次
    /// </summary>
    public string CronExpression { get; set; } = "0 */5 8-16 * * 1-5";

    /// <summary>
    /// 時區設定 - 預設為台北時間
    /// </summary>
    public string TimeZone { get; set; } = "Asia/Taipei";

    /// <summary>
    /// 是否啟用定時抓取
    /// </summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// 啟動時是否立即執行一次
    /// </summary>
    public bool RunOnStartup { get; set; } = true;

    /// <summary>
    /// 抓取失敗時的重試次數
    /// </summary>
    public int RetryCount { get; set; } = 3;

    /// <summary>
    /// 重試間隔（分鐘）
    /// </summary>
    public int RetryIntervalMinutes { get; set; } = 1;

    /// <summary>
    /// 連線逾時時間（秒）
    /// </summary>
    public int TimeoutSeconds { get; set; } = 30;
}
