using CathayBank.RealtimeExchangeRate.BackgroundServices.Configurations;
using CathayBank.RealtimeExchangeRate.BackgroundServices.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CathayBank.RealtimeExchangeRate.BackgroundServices.Extensions;

public static class ServiceExtensions
{
    public static IServiceCollection AddBackgroundServices(this IServiceCollection services, IConfiguration configuration)
    {
        // 註冊組態設定
        services.Configure<ScrapingConfiguration>(configuration.GetSection(ScrapingConfiguration.SectionName));
        
        // 註冊 TimeProvider
        services.AddSingleton(TimeProvider.System);
        
        // 註冊背景服務
        services.AddHostedService<ExchangeRateScrapingService>();
        
        return services;
    }
}
