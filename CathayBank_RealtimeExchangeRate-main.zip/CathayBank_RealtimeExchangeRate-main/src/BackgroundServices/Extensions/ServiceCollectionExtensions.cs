using CathayBank.RealtimeExchangeRate.BackgroundServices.Configurations;
using CathayBank.RealtimeExchangeRate.BackgroundServices.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CathayBank.RealtimeExchangeRate.BackgroundServices.Extensions;

/// <summary>
/// 背景服務的依賴注入擴充方法
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// 註冊背景服務及其相關依賴項
    /// </summary>
    /// <param name="services">服務集合</param>
    /// <param name="configuration">組態物件</param>
    /// <returns>服務集合</returns>
    public static IServiceCollection AddBackgroundServices(this IServiceCollection services, IConfiguration configuration)
    {
        // 註冊組態設定
        services.Configure<ScrapingConfiguration>(configuration.GetSection(ScrapingConfiguration.SectionName));

        // 註冊 TimeProvider (在 .NET 9 中可用)
        services.AddSingleton(TimeProvider.System);

        // 註冊背景服務
        services.AddHostedService<ExchangeRateScrapingService>();

        return services;
    }
}
