using CathayBank.RealtimeExchangeRate.Domain.ValueObjects;

namespace CathayBank.RealtimeExchangeRate.Domain.Entities;

/// <summary>
/// 匯率實體
/// </summary>
public class ExchangeRate
{
    public string CurrencyCode { get; set; } = string.Empty;
    public string CurrencyName { get; set; } = string.Empty;
    public decimal BankBuyRate { get; set; }
    public decimal BankSellRate { get; set; }
    public string BoardDate { get; set; } = string.Empty; // yyyyMMdd 格式，如：20250811
    public string BoardTime { get; set; } = string.Empty; // HHmmss 格式，如：143000
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    // Navigation properties
    public Currency Currency => Currency.FromCode(CurrencyCode) ?? Currency.USD;

    /// <summary>
    /// 格式化的買進匯率
    /// </summary>
    public string FormattedBuyRate => Currency.FormatRate(BankBuyRate);

    /// <summary>
    /// 格式化的賣出匯率
    /// </summary>
    public string FormattedSellRate => Currency.FormatRate(BankSellRate);

    /// <summary>
    /// 格式化的牌告時間
    /// </summary>
    public string FormattedBoardTime 
    {
        get
        {
            if (DateTime.TryParseExact($"{BoardDate}{BoardTime}", "yyyyMMddHHmmss", null, 
                System.Globalization.DateTimeStyles.None, out var dateTime))
            {
                return dateTime.ToString("yyyy年MM月dd日 HH:mm:ss");
            }
            return $"{BoardDate} {BoardTime}";
        }
    }
}
