using Ardalis.SmartEnum;

namespace CathayBank.RealtimeExchangeRate.Domain.ValueObjects;

/// <summary>
/// 貨幣值對象 - 使用 SmartEnum 實現強型別貨幣定義
/// </summary>
public sealed class Currency : SmartEnum<Currency>
{
    // 16種外幣定義
    public static readonly Currency USD = new("USD", 1, "美元", "US Dollar", "$", 4);
    public static readonly Currency EUR = new("EUR", 2, "歐元", "Euro", "€", 4);
    public static readonly Currency JPY = new("JPY", 3, "日圓", "Japanese Yen", "¥", 2);
    public static readonly Currency CNY = new("CNY", 4, "人民幣", "Chinese Yuan", "¥", 4);
    public static readonly Currency HKD = new("HKD", 5, "港幣", "Hong Kong Dollar", "HK$", 4);
    public static readonly Currency AUD = new("AUD", 6, "澳大利亞幣", "Australian Dollar", "A$", 4);
    public static readonly Currency NZD = new("NZD", 7, "紐西蘭幣", "New Zealand Dollar", "NZ$", 4);
    public static readonly Currency ZAR = new("ZAR", 8, "南非幣", "South African Rand", "R", 4);
    public static readonly Currency CAD = new("CAD", 9, "加拿大幣", "Canadian Dollar", "C$", 4);
    public static readonly Currency GBP = new("GBP", 10, "英鎊", "British Pound", "£", 4);
    public static readonly Currency CHF = new("CHF", 11, "瑞士法郎", "Swiss Franc", "CHF", 4);
    public static readonly Currency SEK = new("SEK", 12, "瑞典幣", "Swedish Krona", "kr", 4);
    public static readonly Currency SGD = new("SGD", 13, "新加坡幣", "Singapore Dollar", "S$", 4);
    public static readonly Currency THB = new("THB", 14, "泰國幣", "Thai Baht", "฿", 4);
    public static readonly Currency DKK = new("DKK", 15, "丹麥幣", "Danish Krone", "kr", 4);
    public static readonly Currency TRY = new("TRY", 16, "土耳其里拉", "Turkish Lira", "₺", 4);

    // 屬性
    public string Code => Name;  // SmartEnum.Name 就是我們的貨幣代號
    public string ChineseName { get; }
    public string EnglishName { get; }
    public string Symbol { get; }
    public int DecimalPlaces { get; }

    // 私有建構函式
    private Currency(string name, int value, string chineseName, string englishName, string symbol, int decimalPlaces) 
        : base(name, value)
    {
        ChineseName = chineseName;
        EnglishName = englishName;
        Symbol = symbol;
        DecimalPlaces = decimalPlaces;
    }

    /// <summary>
    /// 從字串代號取得 Currency
    /// </summary>
    public static Currency? FromCode(string code)
    {
        return TryFromName(code, out var currency) ? currency : null;
    }

    /// <summary>
    /// 格式化匯率顯示
    /// </summary>
    public string FormatRate(decimal rate)
    {
        return $"{Symbol}{rate.ToString($"F{DecimalPlaces}")}";
    }
}
