using CathayBank.RealtimeExchangeRate.Domain.Entities;

namespace CathayBank.RealtimeExchangeRate.Domain.Interfaces;

/// <summary>
/// 匯率儲存庫介面
/// </summary>
public interface IExchangeRateRepository
{
    /// <summary>
    /// 新增匯率資料
    /// </summary>
    Task<ExchangeRate> AddAsync(ExchangeRate exchangeRate, CancellationToken cancellationToken = default);

    /// <summary>
    /// 批量新增匯率資料
    /// </summary>
    Task<IEnumerable<ExchangeRate>> AddRangeAsync(IEnumerable<ExchangeRate> exchangeRates, CancellationToken cancellationToken = default);

    /// <summary>
    /// 取得最新的匯率資料
    /// </summary>
    Task<IEnumerable<ExchangeRate>> GetLatestRatesAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// 取得特定幣別的最新匯率
    /// </summary>
    Task<ExchangeRate?> GetLatestRateByCurrencyAsync(string currencyCode, CancellationToken cancellationToken = default);

    /// <summary>
    /// 檢查是否已存在相同的匯率資料（避免重複）
    /// </summary>
    Task<bool> ExistsAsync(string currencyCode, DateTime boardDateTime, CancellationToken cancellationToken = default);

    /// <summary>
    /// 刪除特定幣別和時間的匯率資料
    /// </summary>
    Task<bool> DeleteAsync(string currencyCode, DateTime boardDateTime, CancellationToken cancellationToken = default);
}
