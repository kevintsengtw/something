using CathayBank.RealtimeExchangeRate.Domain.ValueObjects;

namespace CathayBank.RealtimeExchangeRate.Application.DTOs;

/// <summary>
/// 匯率資料傳輸物件
/// </summary>
public class ExchangeRateDto
{
    public string CurrencyCode { get; set; } = string.Empty;
    public string CurrencyName { get; set; } = string.Empty;
    public string ChineseName { get; set; } = string.Empty;
    public string EnglishName { get; set; } = string.Empty;
    public string Symbol { get; set; } = string.Empty;
    public decimal BankBuyRate { get; set; }
    public decimal BankSellRate { get; set; }
    public string BoardDate { get; set; } = string.Empty; // yyyyMMdd 格式
    public string BoardTime { get; set; } = string.Empty; // HHmmss 格式
    public DateTime CreatedAt { get; set; }

    /// <summary>
    /// 格式化的買進匯率
    /// </summary>
    public string FormattedBuyRate 
    {
        get
        {
            var currency = Currency.FromCode(CurrencyCode);
            return currency?.FormatRate(BankBuyRate) ?? $"{BankBuyRate:F4}";
        }
    }

    /// <summary>
    /// 格式化的賣出匯率
    /// </summary>
    public string FormattedSellRate 
    {
        get
        {
            var currency = Currency.FromCode(CurrencyCode);
            return currency?.FormatRate(BankSellRate) ?? $"{BankSellRate:F4}";
        }
    }

    /// <summary>
    /// 格式化的牌告時間
    /// </summary>
    public string FormattedBoardTime 
    {
        get
        {
            if (DateTime.TryParseExact($"{BoardDate}{BoardTime}", "yyyyMMddHHmmss", null, 
                System.Globalization.DateTimeStyles.None, out var dateTime))
            {
                return dateTime.ToString("yyyy年MM月dd日 HH:mm:ss");
            }
            return $"{BoardDate} {BoardTime}";
        }
    }
}
