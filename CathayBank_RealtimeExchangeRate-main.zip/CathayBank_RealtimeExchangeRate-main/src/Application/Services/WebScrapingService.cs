using CathayBank.RealtimeExchangeRate.Application.DTOs;
using CathayBank.RealtimeExchangeRate.Application.Interfaces;
using CathayBank.RealtimeExchangeRate.Domain.ValueObjects;
using HtmlAgilityPack;
using Microsoft.Extensions.Logging;

namespace CathayBank.RealtimeExchangeRate.Application.Services;

/// <summary>
/// 網頁抓取服務實作
/// </summary>
public class WebScrapingService : IWebScrapingService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<WebScrapingService> _logger;
    private readonly TimeProvider _timeProvider;
    private const string CATHAY_BANK_URL = "https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/";

    public WebScrapingService(
        HttpClient httpClient,
        ILogger<WebScrapingService> logger,
        TimeProvider timeProvider)
    {
        _httpClient = httpClient;
        _logger = logger;
        _timeProvider = timeProvider;
    }

    public async Task<IEnumerable<ExchangeRateDto>> ScrapeExchangeRatesAsync(CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("開始抓取國泰世華銀行匯率資料");

        try
        {
            var response = await _httpClient.GetAsync(CATHAY_BANK_URL, cancellationToken);
            response.EnsureSuccessStatusCode();

            var htmlContent = await response.Content.ReadAsStringAsync(cancellationToken);
            _logger.LogDebug("網頁下載完成，內容長度: {Length} 字元", htmlContent.Length);

            var document = new HtmlDocument();
            document.LoadHtml(htmlContent);

            var exchangeRates = new List<ExchangeRateDto>();
            var boardDateTime = _timeProvider.GetLocalNow().DateTime; // 使用 TimeProvider 取得本地時間

            _logger.LogInformation("開始解析 {Count} 種外幣匯率", Currency.List.Count());

            foreach (var currency in Currency.List)
            {
                _logger.LogDebug("正在處理: {CurrencyCode} ({ChineseName})", currency.Code, currency.ChineseName);

                var rate = ExtractCurrencyRate(document, currency, boardDateTime);
                if (rate != null)
                {
                    exchangeRates.Add(rate);
                    _logger.LogDebug("✓ 成功抓取 {CurrencyCode} - 買進: {BuyRate:F4}, 賣出: {SellRate:F4}",
                        currency.Code, rate.BankBuyRate, rate.BankSellRate);
                }
                else
                {
                    _logger.LogWarning("✗ 無法抓取 {CurrencyCode}", currency.Code);
                }
            }

            _logger.LogInformation("抓取完成，成功: {SuccessCount}/{TotalCount}", exchangeRates.Count, Currency.List.Count());

            return exchangeRates;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "抓取匯率資料時發生錯誤");
            throw;
        }
    }

    public async Task<bool> IsWebsiteAvailableAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var response = await _httpClient.GetAsync(CATHAY_BANK_URL, cancellationToken);
            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "檢查網站可用性時發生錯誤");
            return false;
        }
    }

    private ExchangeRateDto? ExtractCurrencyRate(HtmlDocument document, Currency currency, DateTime boardDateTime)
    {
        try
        {
            // 尋找包含貨幣代號的 rateCard 區塊
            var rateCard = document.DocumentNode
                .SelectSingleNode($"//div[contains(@class, 'cubre-o-rateCard') and .//div[contains(text(), '{currency.Code}')]]");

            if (rateCard != null)
            {
                // 在這個區塊內尋找匯率表格
                var rateTable = rateCard.SelectSingleNode(".//table[contains(@class, 'cubre-m-rateTable')]");
                if (rateTable != null)
                {
                    // 尋找即期匯率行
                    var spotRateRow = rateTable.SelectSingleNode(".//tr[.//div[contains(text(), '即期匯率')]]");
                    if (spotRateRow != null)
                    {
                        var cells = spotRateRow.SelectNodes(".//td");
                        if (cells != null && cells.Count >= 3)
                        {
                            var buyRateText = cells[1].InnerText?.Trim();
                            var sellRateText = cells[2].InnerText?.Trim();

                            if (decimal.TryParse(buyRateText, out decimal buyRate) &&
                                decimal.TryParse(sellRateText, out decimal sellRate))
                            {
                                return new ExchangeRateDto
                                {
                                    CurrencyCode = currency.Code,
                                    CurrencyName = currency.ChineseName,
                                    ChineseName = currency.ChineseName,
                                    EnglishName = currency.EnglishName,
                                    Symbol = currency.Symbol,
                                    BankBuyRate = buyRate,
                                    BankSellRate = sellRate,
                                    BoardDate = boardDateTime.ToString("yyyyMMdd"),
                                    BoardTime = boardDateTime.ToString("HHmmss"),
                                    CreatedAt = _timeProvider.GetUtcNow().DateTime
                                };
                            }
                        }
                    }
                }
            }

            return null;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "提取 {CurrencyCode} 匯率時發生錯誤", currency.Code);
            return null;
        }
    }
}
