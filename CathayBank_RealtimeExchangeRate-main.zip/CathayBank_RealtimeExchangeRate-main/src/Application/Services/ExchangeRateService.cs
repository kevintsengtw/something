using CathayBank.RealtimeExchangeRate.Application.DTOs;
using CathayBank.RealtimeExchangeRate.Application.Interfaces;
using CathayBank.RealtimeExchangeRate.Domain.Entities;
using CathayBank.RealtimeExchangeRate.Domain.Interfaces;
using CathayBank.RealtimeExchangeRate.Domain.ValueObjects;
using Microsoft.Extensions.Logging;

namespace CathayBank.RealtimeExchangeRate.Application.Services;

/// <summary>
/// 匯率服務實作
/// </summary>
public class ExchangeRateService : IExchangeRateService
{
    private readonly IExchangeRateRepository _repository;
    private readonly IWebScrapingService _webScrapingService;
    private readonly ILogger<ExchangeRateService> _logger;
    private readonly TimeProvider _timeProvider;

    public ExchangeRateService(
        IExchangeRateRepository repository,
        IWebScrapingService webScrapingService,
        ILogger<ExchangeRateService> logger,
        TimeProvider timeProvider)
    {
        _repository = repository;
        _webScrapingService = webScrapingService;
        _logger = logger;
        _timeProvider = timeProvider;
    }

    public async Task<IEnumerable<ExchangeRateDto>> GetLatestRatesAsync(CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("取得最新匯率資料");

        var exchangeRates = await _repository.GetLatestRatesAsync(cancellationToken);
        
        return exchangeRates.Select(MapToDto);
    }

    public async Task<ExchangeRateDto?> GetLatestRateByCurrencyAsync(string currencyCode, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("取得 {CurrencyCode} 的最新匯率", currencyCode);

        var exchangeRate = await _repository.GetLatestRateByCurrencyAsync(currencyCode, cancellationToken);
        
        return exchangeRate == null ? null : MapToDto(exchangeRate);
    }

    public async Task<IEnumerable<ExchangeRateDto>> SaveExchangeRatesAsync(IEnumerable<ExchangeRateDto> exchangeRates, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("儲存 {Count} 筆匯率資料", exchangeRates.Count());

        var entities = new List<ExchangeRate>();
        var now = _timeProvider.GetUtcNow().DateTime;

        foreach (var dto in exchangeRates)
        {
            // 檢查是否已存在相同貨幣當天的資料
            var existingDateTime = DateTime.ParseExact($"{dto.BoardDate}{dto.BoardTime}", "yyyyMMddHHmmss", null);
            
            if (await _repository.ExistsAsync(dto.CurrencyCode, existingDateTime, cancellationToken))
            {
                _logger.LogDebug("匯率資料已存在，將更新: {CurrencyCode} {BoardDate}", 
                    dto.CurrencyCode, dto.BoardDate);
                
                // 刪除舊的匯率資料（同一天的資料）
                await _repository.DeleteAsync(dto.CurrencyCode, existingDateTime, cancellationToken);
                _logger.LogDebug("已刪除舊的匯率資料: {CurrencyCode} {BoardDate}", 
                    dto.CurrencyCode, dto.BoardDate);
            }

            var entity = new ExchangeRate
            {
                CurrencyCode = dto.CurrencyCode,
                CurrencyName = dto.CurrencyName,
                BankBuyRate = dto.BankBuyRate,
                BankSellRate = dto.BankSellRate,
                BoardDate = dto.BoardDate,
                BoardTime = dto.BoardTime,
                CreatedAt = now,
                UpdatedAt = now
            };

            entities.Add(entity);
        }

        if (entities.Any())
        {
            var savedEntities = await _repository.AddRangeAsync(entities, cancellationToken);
            
            _logger.LogInformation("成功儲存 {Count} 筆匯率資料（包含更新的資料）", entities.Count);
            
            return savedEntities.Select(MapToDto);
        }

        _logger.LogInformation("沒有匯率資料需要儲存");
        return Enumerable.Empty<ExchangeRateDto>();
    }

    public async Task<IEnumerable<ExchangeRateDto>> ScrapeAndSaveExchangeRatesAsync(CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("開始抓取並儲存匯率資料");

        try
        {
            // 抓取匯率資料
            var scrapedRates = await _webScrapingService.ScrapeExchangeRatesAsync(cancellationToken);
            
            if (!scrapedRates.Any())
            {
                _logger.LogWarning("未抓取到任何匯率資料");
                return Enumerable.Empty<ExchangeRateDto>();
            }

            // 儲存匯率資料
            var savedRates = await SaveExchangeRatesAsync(scrapedRates, cancellationToken);

            _logger.LogInformation("抓取並儲存匯率資料完成，成功處理 {Count} 筆資料", savedRates.Count());
            
            return savedRates;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "抓取並儲存匯率資料時發生錯誤");
            throw;
        }
    }

    private static ExchangeRateDto MapToDto(ExchangeRate entity)
    {
        var currency = Currency.FromCode(entity.CurrencyCode) ?? Currency.USD;
        
        return new ExchangeRateDto
        {
            CurrencyCode = entity.CurrencyCode,
            CurrencyName = entity.CurrencyName,
            ChineseName = currency.ChineseName,
            EnglishName = currency.EnglishName,
            Symbol = currency.Symbol,
            BankBuyRate = entity.BankBuyRate,
            BankSellRate = entity.BankSellRate,
            BoardDate = entity.BoardDate,
            BoardTime = entity.BoardTime,
            CreatedAt = entity.CreatedAt
        };
    }
}
