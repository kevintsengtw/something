using CathayBank.RealtimeExchangeRate.Application.DTOs;

namespace CathayBank.RealtimeExchangeRate.Application.Interfaces;

/// <summary>
/// 匯率服務介面
/// </summary>
public interface IExchangeRateService
{
    /// <summary>
    /// 取得最新匯率資料
    /// </summary>
    Task<IEnumerable<ExchangeRateDto>> GetLatestRatesAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// 取得特定幣別的最新匯率
    /// </summary>
    Task<ExchangeRateDto?> GetLatestRateByCurrencyAsync(string currencyCode, CancellationToken cancellationToken = default);

    /// <summary>
    /// 儲存匯率資料
    /// </summary>
    Task<IEnumerable<ExchangeRateDto>> SaveExchangeRatesAsync(IEnumerable<ExchangeRateDto> exchangeRates, CancellationToken cancellationToken = default);

    /// <summary>
    /// 抓取並儲存最新匯率資料
    /// </summary>
    Task<IEnumerable<ExchangeRateDto>> ScrapeAndSaveExchangeRatesAsync(CancellationToken cancellationToken = default);
}
