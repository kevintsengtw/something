using CathayBank.RealtimeExchangeRate.Application.DTOs;

namespace CathayBank.RealtimeExchangeRate.Application.Interfaces;

/// <summary>
/// 網頁抓取服務介面
/// </summary>
public interface IWebScrapingService
{
    /// <summary>
    /// 抓取國泰世華銀行匯率資料
    /// </summary>
    Task<IEnumerable<ExchangeRateDto>> ScrapeExchangeRatesAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// 檢查網站是否可用
    /// </summary>
    Task<bool> IsWebsiteAvailableAsync(CancellationToken cancellationToken = default);
}
