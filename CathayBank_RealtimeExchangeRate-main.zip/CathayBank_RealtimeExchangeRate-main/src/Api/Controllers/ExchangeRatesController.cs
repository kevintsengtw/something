using CathayBank.RealtimeExchangeRate.Application.DTOs;
using CathayBank.RealtimeExchangeRate.Application.Interfaces;
using CathayBank.RealtimeExchangeRate.Domain.ValueObjects;
using Microsoft.AspNetCore.Mvc;

namespace CathayBank.RealtimeExchangeRate.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ExchangeRatesController : ControllerBase
{
    private readonly IExchangeRateService _exchangeRateService;
    private readonly ILogger<ExchangeRatesController> _logger;

    public ExchangeRatesController(
        IExchangeRateService exchangeRateService,
        ILogger<ExchangeRatesController> logger)
    {
        _exchangeRateService = exchangeRateService;
        _logger = logger;
    }

    /// <summary>
    /// 取得最新的外幣匯率
    /// </summary>
    [HttpGet("latest")]
    public async Task<IActionResult> GetLatestRates(CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("API: 取得最新匯率請求");
            
            var rates = await _exchangeRateService.GetLatestRatesAsync(cancellationToken);
            
            _logger.LogInformation("API: 成功回傳 {Count} 筆最新匯率", rates.Count());
            
            return Ok(new
            {
                Success = true,
                Message = "成功取得最新匯率",
                Data = rates,
                Timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "API: 取得最新匯率時發生錯誤");
            
            return StatusCode(500, new
            {
                Success = false,
                Message = "取得匯率資料時發生錯誤",
                Error = ex.Message,
                Timestamp = DateTime.UtcNow
            });
        }
    }

    /// <summary>
    /// 取得特定幣別的最新匯率
    /// </summary>
    [HttpGet("latest/{currencyCode}")]
    public async Task<IActionResult> GetLatestRateByCurrency(string currencyCode, CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("API: 取得 {CurrencyCode} 最新匯率請求", currencyCode);
            
            var rate = await _exchangeRateService.GetLatestRateByCurrencyAsync(currencyCode.ToUpper(), cancellationToken);
            
            if (rate == null)
            {
                _logger.LogWarning("API: 找不到 {CurrencyCode} 的匯率資料", currencyCode);
                
                return NotFound(new
                {
                    Success = false,
                    Message = $"找不到 {currencyCode.ToUpper()} 的匯率資料",
                    Timestamp = DateTime.UtcNow
                });
            }

            _logger.LogInformation("API: 成功回傳 {CurrencyCode} 最新匯率", currencyCode);
            
            return Ok(new
            {
                Success = true,
                Message = $"成功取得 {currencyCode.ToUpper()} 最新匯率",
                Data = rate,
                Timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "API: 取得 {CurrencyCode} 匯率時發生錯誤", currencyCode);
            
            return StatusCode(500, new
            {
                Success = false,
                Message = "取得匯率資料時發生錯誤",
                Error = ex.Message,
                Timestamp = DateTime.UtcNow
            });
        }
    }

    /// <summary>
    /// 手動觸發匯率抓取
    /// </summary>
    [HttpPost("scrape")]
    public async Task<IActionResult> TriggerScraping(CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("API: 手動觸發匯率抓取請求");
            
            var rates = await _exchangeRateService.ScrapeAndSaveExchangeRatesAsync(cancellationToken);
            
            _logger.LogInformation("API: 手動匯率抓取完成，處理 {Count} 筆資料", rates.Count());
            
            return Ok(new
            {
                Success = true,
                Message = "手動匯率抓取完成",
                Data = rates,
                Count = rates.Count(),
                Timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "API: 手動匯率抓取時發生錯誤");
            
            return StatusCode(500, new
            {
                Success = false,
                Message = "手動匯率抓取時發生錯誤",
                Error = ex.Message,
                Timestamp = DateTime.UtcNow
            });
        }
    }

    /// <summary>
    /// 健康檢查
    /// </summary>
    [HttpGet("health")]
    public IActionResult HealthCheck()
    {
        return Ok(new
        {
            Status = "Healthy",
            Service = "CathayBank Exchange Rate API",
            Timestamp = DateTime.UtcNow
        });
    }
}
