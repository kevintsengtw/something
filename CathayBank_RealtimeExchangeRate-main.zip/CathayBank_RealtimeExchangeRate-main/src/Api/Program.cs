using CathayBank.RealtimeExchangeRate.BackgroundServices.Configurations;
using CathayBank.RealtimeExchangeRate.BackgroundServices.Services;
using CathayBank.RealtimeExchangeRate.Infrastructure.Extensions;
using Serilog;

// 設定 Serilog
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File("logs/log-.txt", rollingInterval: RollingInterval.Day)
    .CreateBootstrapLogger();

try
{
    Log.Information("啟動國泰世華銀行匯率 API");

    var builder = WebApplication.CreateBuilder(args);

    // 使用 Serilog 作為日誌提供者
    builder.Host.UseSerilog((context, configuration) =>
        configuration.ReadFrom.Configuration(context.Configuration)
                     .Enrich.FromLogContext());

    // 註冊 Infrastructure 層的服務（包含資料庫、HTTP 客戶端等）
    builder.Services.AddInfrastructure(builder.Configuration);

// 註冊抓取服務配置
builder.Services.Configure<ScrapingConfiguration>(
    builder.Configuration.GetSection(ScrapingConfiguration.SectionName));

// 註冊背景服務
builder.Services.AddHostedService<ExchangeRateScrapingService>();

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() 
    { 
        Title = "國泰世華銀行匯率 API", 
        Version = "v1",
        Description = "提供國泰世華銀行外幣匯率查詢服務"
    });
});

// 健康檢查
builder.Services.AddHealthChecks();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "國泰世華銀行匯率 API v1");
        c.RoutePrefix = "swagger"; // 讓 Swagger UI 成為根路徑
        c.DocumentTitle = "國泰世華銀行匯率 API";
    });
}
else
{
    // 在生產環境也啟用 Swagger（可選）
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "國泰世華銀行匯率 API v1");
        c.RoutePrefix = "swagger";
    });
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

// 健康檢查端點
app.MapHealthChecks("/health");

// 顯示啟動資訊
if (app.Environment.IsDevelopment())
{
    var logger = app.Services.GetRequiredService<ILogger<Program>>();
    
    logger.LogInformation("國泰世華銀行匯率 API 已啟動");
    logger.LogInformation("API 端點:");
    logger.LogInformation("  GET  /api/exchangerates/latest          - 取得所有最新匯率");
    logger.LogInformation("  GET  /api/exchangerates/latest/{{code}}   - 取得特定幣別最新匯率");
    logger.LogInformation("  POST /api/exchangerates/scrape          - 手動觸發匯率抓取");
    logger.LogInformation("  GET  /health                            - 健康檢查");
    logger.LogInformation("  Swagger UI: / 或 /swagger");
}

app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "應用程式啟動失敗");
}
finally
{
    Log.CloseAndFlush();
}
