using CathayBank.RealtimeExchangeRate.Application.Interfaces;
using CathayBank.RealtimeExchangeRate.Application.Services;
using CathayBank.RealtimeExchangeRate.Domain.Interfaces;
using CathayBank.RealtimeExchangeRate.Infrastructure.Data;
using CathayBank.RealtimeExchangeRate.Infrastructure.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Extensions;

/// <summary>
/// Infrastructure 層的依賴注入擴充方法
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// 註冊 Infrastructure 層的服務 (使用 Dapper)
    /// </summary>
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        // 註冊資料庫連線工廠
        services.AddSingleton<IDatabaseConnectionFactory, SqlServerConnectionFactory>();
        
        // 註冊資料庫初始化器
        services.AddScoped<IDatabaseInitializer, SqlServerDatabaseInitializer>();

        // 註冊儲存庫
        services.AddScoped<IExchangeRateRepository, ExchangeRateRepository>();
        services.AddScoped<IScrapingLogRepository, ScrapingLogRepository>();

        // 註冊 HttpClient 和網頁抓取服務
        services.AddHttpClient<IWebScrapingService, WebScrapingService>(client =>
        {
            client.Timeout = TimeSpan.FromSeconds(30);
            client.DefaultRequestHeaders.Add("User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
            client.DefaultRequestHeaders.Add("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
            client.DefaultRequestHeaders.Add("Accept-Language", "zh-TW,zh;q=0.9,en;q=0.8");
            client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
            client.DefaultRequestHeaders.Add("Upgrade-Insecure-Requests", "1");
        });

        // 註冊應用程式服務
        services.AddScoped<IExchangeRateService, ExchangeRateService>();

        // 註冊時間提供者
        services.AddSingleton<TimeProvider>(TimeProvider.System);

        return services;
    }
}
