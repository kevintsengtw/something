using System.Data;
using Dapper;
using Microsoft.Extensions.Logging;
using CathayBank.RealtimeExchangeRate.Domain.Interfaces;
using CathayBank.RealtimeExchangeRate.Domain.Entities;
using CathayBank.RealtimeExchangeRate.Infrastructure.Data;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Repositories;

/// <summary>
/// 匯率資料存取實作 (使用 Dapper)
/// </summary>
public class ExchangeRateRepository : IExchangeRateRepository
{
    private readonly IDatabaseConnectionFactory _connectionFactory;
    private readonly ILogger<ExchangeRateRepository> _logger;

    public ExchangeRateRepository(
        IDatabaseConnectionFactory connectionFactory,
        ILogger<ExchangeRateRepository> logger)
    {
        _connectionFactory = connectionFactory;
        _logger = logger;
    }

    public async Task<ExchangeRate> AddAsync(ExchangeRate exchangeRate, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        const string sql = """
            INSERT INTO ExchangeRates (CurrencyCode, CurrencyName, BankBuyRate, BankSellRate, BoardDate, BoardTime, CreatedAt, UpdatedAt)
            VALUES (@CurrencyCode, @CurrencyName, @BankBuyRate, @BankSellRate, @BoardDate, @BoardTime, @CreatedAt, @UpdatedAt)
            """;

        await connection.ExecuteAsync(sql, new
        {
            CurrencyCode = exchangeRate.CurrencyCode,
            CurrencyName = exchangeRate.CurrencyName,
            BankBuyRate = exchangeRate.BankBuyRate,
            BankSellRate = exchangeRate.BankSellRate,
            BoardDate = exchangeRate.BoardDate,
            BoardTime = exchangeRate.BoardTime,
            CreatedAt = exchangeRate.CreatedAt,
            UpdatedAt = exchangeRate.UpdatedAt
        });

        return exchangeRate;
    }

    public async Task<IEnumerable<ExchangeRate>> AddRangeAsync(IEnumerable<ExchangeRate> exchangeRates, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        connection.Open();
        
        using var transaction = connection.BeginTransaction();
        
        try
        {
            const string sql = """
                INSERT INTO ExchangeRates (CurrencyCode, CurrencyName, BankBuyRate, BankSellRate, BoardDate, BoardTime, CreatedAt, UpdatedAt)
                VALUES (@CurrencyCode, @CurrencyName, @BankBuyRate, @BankSellRate, @BoardDate, @BoardTime, @CreatedAt, @UpdatedAt)
                """;

            var exchangeRatesList = exchangeRates.ToList();
            
            foreach (var exchangeRate in exchangeRatesList)
            {
                // 除錯：記錄即將插入的資料
                _logger.LogDebug("準備插入匯率資料: {CurrencyCode}, BoardDate={BoardDate}, BoardTime={BoardTime}",
                    exchangeRate.CurrencyCode, exchangeRate.BoardDate, exchangeRate.BoardTime);

                await connection.ExecuteAsync(sql, new
                {
                    CurrencyCode = exchangeRate.CurrencyCode,
                    CurrencyName = exchangeRate.CurrencyName,
                    BankBuyRate = exchangeRate.BankBuyRate,
                    BankSellRate = exchangeRate.BankSellRate,
                    BoardDate = exchangeRate.BoardDate,
                    BoardTime = exchangeRate.BoardTime,
                    CreatedAt = exchangeRate.CreatedAt,
                    UpdatedAt = exchangeRate.UpdatedAt
                }, transaction);
            }
            
            transaction.Commit();
            
            _logger.LogInformation("批次新增 {Count} 筆匯率資料", exchangeRatesList.Count);
            
            return exchangeRatesList;
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    public async Task<IEnumerable<ExchangeRate>> GetLatestRatesAsync(CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        const string sql = """
            WITH LatestRates AS (
                SELECT CurrencyCode, CurrencyName, BankBuyRate, BankSellRate, BoardDate, BoardTime, CreatedAt, UpdatedAt,
                       ROW_NUMBER() OVER (PARTITION BY CurrencyCode ORDER BY BoardDate DESC, BoardTime DESC) as rn
                FROM ExchangeRates
            )
            SELECT CurrencyCode, CurrencyName, BankBuyRate, BankSellRate, BoardDate, BoardTime, CreatedAt, UpdatedAt
            FROM LatestRates 
            WHERE rn = 1
            ORDER BY CurrencyCode
            """;

        var results = await connection.QueryAsync<ExchangeRate>(sql);
        
        return results;
    }

    public async Task<ExchangeRate?> GetLatestRateByCurrencyAsync(string currencyCode, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        const string sql = """
            SELECT TOP 1 CurrencyCode, CurrencyName, BankBuyRate, BankSellRate, BoardDate, BoardTime, CreatedAt, UpdatedAt
            FROM ExchangeRates 
            WHERE CurrencyCode = @CurrencyCode
            ORDER BY BoardDate DESC, BoardTime DESC
            """;

        var result = await connection.QueryFirstOrDefaultAsync<ExchangeRate>(sql, new { CurrencyCode = currencyCode });
        
        return result;
    }

    public async Task<bool> ExistsAsync(string currencyCode, DateTime boardDateTime, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        var boardDate = boardDateTime.ToString("yyyyMMdd");
        
        const string sql = """
            SELECT COUNT(1) 
            FROM ExchangeRates 
            WHERE CurrencyCode = @CurrencyCode AND BoardDate = @BoardDate
            """;

        var count = await connection.QuerySingleAsync<int>(sql, new { CurrencyCode = currencyCode, BoardDate = boardDate });
        
        return count > 0;
    }

    public async Task<bool> DeleteAsync(string currencyCode, DateTime boardDateTime, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        var boardDate = boardDateTime.ToString("yyyyMMdd");
        
        const string sql = """
            DELETE FROM ExchangeRates 
            WHERE CurrencyCode = @CurrencyCode AND BoardDate = @BoardDate
            """;

        var affectedRows = await connection.ExecuteAsync(sql, new 
        { 
            CurrencyCode = currencyCode, 
            BoardDate = boardDate
        });
        
        return affectedRows > 0;
    }
}
