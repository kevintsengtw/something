using System.Data;
using Dapper;
using Microsoft.Extensions.Logging;
using CathayBank.RealtimeExchangeRate.Infrastructure.Data;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Repositories;

/// <summary>
/// 抓取日誌實體
/// </summary>
public class ScrapingLog
{
    public long Id { get; set; }
    public Guid ExecutionId { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime? EndTime { get; set; }
    public string Status { get; set; } = string.Empty; // Success, Failed, Running
    public int ProcessedCount { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>
/// 抓取日誌存取介面
/// </summary>
public interface IScrapingLogRepository
{
    /// <summary>
    /// 建立新的抓取日誌記錄
    /// </summary>
    Task<ScrapingLog> CreateLogAsync(Guid executionId, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// 更新抓取日誌狀態為成功
    /// </summary>
    Task UpdateLogSuccessAsync(Guid executionId, int processedCount, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// 更新抓取日誌狀態為失敗
    /// </summary>
    Task UpdateLogFailureAsync(Guid executionId, string errorMessage, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// 取得最近的抓取日誌
    /// </summary>
    Task<IEnumerable<ScrapingLog>> GetRecentLogsAsync(int count = 50, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// 取得特定執行 ID 的日誌
    /// </summary>
    Task<ScrapingLog?> GetLogByExecutionIdAsync(Guid executionId, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// 清理舊的日誌記錄
    /// </summary>
    Task CleanupOldLogsAsync(DateTime olderThan, CancellationToken cancellationToken = default);
}

/// <summary>
/// 抓取日誌存取實作 (使用 Dapper)
/// </summary>
public class ScrapingLogRepository : IScrapingLogRepository
{
    private readonly IDatabaseConnectionFactory _connectionFactory;
    private readonly ILogger<ScrapingLogRepository> _logger;

    public ScrapingLogRepository(
        IDatabaseConnectionFactory connectionFactory,
        ILogger<ScrapingLogRepository> logger)
    {
        _connectionFactory = connectionFactory;
        _logger = logger;
    }

    public async Task<ScrapingLog> CreateLogAsync(Guid executionId, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        const string sql = """
            INSERT INTO ScrapingLogs (ExecutionId, StartTime, Status, ProcessedCount, CreatedAt)
            OUTPUT INSERTED.Id
            VALUES (@ExecutionId, @StartTime, @Status, @ProcessedCount, @CreatedAt)
            """;

        var now = DateTime.UtcNow;
        var id = await connection.QuerySingleAsync<long>(sql, new
        {
            ExecutionId = executionId,
            StartTime = now,
            Status = "Running",
            ProcessedCount = 0,
            CreatedAt = now
        });

        _logger.LogDebug("建立抓取日誌記錄: ExecutionId={ExecutionId}, Id={Id}", executionId, id);

        return new ScrapingLog
        {
            Id = id,
            ExecutionId = executionId,
            StartTime = now,
            Status = "Running",
            ProcessedCount = 0,
            CreatedAt = now
        };
    }

    public async Task UpdateLogSuccessAsync(Guid executionId, int processedCount, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        const string sql = """
            UPDATE ScrapingLogs 
            SET EndTime = @EndTime, 
                Status = @Status, 
                ProcessedCount = @ProcessedCount
            WHERE ExecutionId = @ExecutionId
            """;

        var endTime = DateTime.UtcNow;
        var affectedRows = await connection.ExecuteAsync(sql, new
        {
            ExecutionId = executionId,
            EndTime = endTime,
            Status = "Success",
            ProcessedCount = processedCount
        });

        if (affectedRows > 0)
        {
            _logger.LogDebug("更新抓取日誌為成功: ExecutionId={ExecutionId}, ProcessedCount={ProcessedCount}", 
                executionId, processedCount);
        }
        else
        {
            _logger.LogWarning("找不到 ExecutionId={ExecutionId} 的日誌記錄", executionId);
        }
    }

    public async Task UpdateLogFailureAsync(Guid executionId, string errorMessage, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        const string sql = """
            UPDATE ScrapingLogs 
            SET EndTime = @EndTime, 
                Status = @Status, 
                ErrorMessage = @ErrorMessage
            WHERE ExecutionId = @ExecutionId
            """;

        var endTime = DateTime.UtcNow;
        var affectedRows = await connection.ExecuteAsync(sql, new
        {
            ExecutionId = executionId,
            EndTime = endTime,
            Status = "Failed",
            ErrorMessage = errorMessage
        });

        if (affectedRows > 0)
        {
            _logger.LogDebug("更新抓取日誌為失敗: ExecutionId={ExecutionId}, Error={ErrorMessage}", 
                executionId, errorMessage);
        }
        else
        {
            _logger.LogWarning("找不到 ExecutionId={ExecutionId} 的日誌記錄", executionId);
        }
    }

    public async Task<IEnumerable<ScrapingLog>> GetRecentLogsAsync(int count = 50, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        const string sql = """
            SELECT TOP (@Count) Id, ExecutionId, StartTime, EndTime, Status, ProcessedCount, ErrorMessage, CreatedAt
            FROM ScrapingLogs 
            ORDER BY StartTime DESC
            """;

        var results = await connection.QueryAsync<ScrapingLog>(sql, new { Count = count });
        
        return results;
    }

    public async Task<ScrapingLog?> GetLogByExecutionIdAsync(Guid executionId, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        const string sql = """
            SELECT Id, ExecutionId, StartTime, EndTime, Status, ProcessedCount, ErrorMessage, CreatedAt
            FROM ScrapingLogs 
            WHERE ExecutionId = @ExecutionId
            """;

        var result = await connection.QuerySingleOrDefaultAsync<ScrapingLog>(sql, new { ExecutionId = executionId });
        
        return result;
    }

    public async Task CleanupOldLogsAsync(DateTime olderThan, CancellationToken cancellationToken = default)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        const string sql = """
            DELETE FROM ScrapingLogs 
            WHERE CreatedAt < @OlderThan
            """;

        var deletedCount = await connection.ExecuteAsync(sql, new { OlderThan = olderThan });
        
        if (deletedCount > 0)
        {
            _logger.LogInformation("清理了 {Count} 筆舊的抓取日誌記錄 (早於 {OlderThan})", deletedCount, olderThan);
        }
    }
}
