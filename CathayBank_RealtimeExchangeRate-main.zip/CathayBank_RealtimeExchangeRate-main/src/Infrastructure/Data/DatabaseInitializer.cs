using System.Data;
using System.Text;
using Dapper;
using Microsoft.Extensions.Logging;
using CathayBank.RealtimeExchangeRate.Domain.ValueObjects;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Data;

/// <summary>
/// 資料庫初始化器介面
/// </summary>
public interface IDatabaseInitializer
{
    /// <summary>
    /// 初始化資料庫（建立資料庫、資料表、植入初始資料）
    /// </summary>
    /// <returns></returns>
    Task InitializeAsync();
    
    /// <summary>
    /// 檢查資料庫是否存在
    /// </summary>
    /// <returns></returns>
    Task<bool> DatabaseExistsAsync();
    
    /// <summary>
    /// 建立資料庫
    /// </summary>
    /// <returns></returns>
    Task CreateDatabaseAsync();
    
    /// <summary>
    /// 建立資料表
    /// </summary>
    /// <returns></returns>
    Task CreateTablesAsync();
    
    /// <summary>
    /// 植入初始資料
    /// </summary>
    /// <returns></returns>
    Task SeedDataAsync();
}

/// <summary>
/// SQL Server 資料庫初始化器實作
/// </summary>
public class SqlServerDatabaseInitializer : IDatabaseInitializer
{
    private readonly IDatabaseConnectionFactory _connectionFactory;
    private readonly ILogger<SqlServerDatabaseInitializer> _logger;

    public SqlServerDatabaseInitializer(
        IDatabaseConnectionFactory connectionFactory,
        ILogger<SqlServerDatabaseInitializer> logger)
    {
        _connectionFactory = connectionFactory;
        _logger = logger;
    }

    public async Task InitializeAsync()
    {
        _logger.LogInformation("開始初始化資料庫...");

        if (!await DatabaseExistsAsync())
        {
            _logger.LogInformation("資料庫不存在，正在建立資料庫...");
            await CreateDatabaseAsync();
        }

        _logger.LogInformation("正在建立資料表...");
        await CreateTablesAsync();

        _logger.LogInformation("正在植入初始資料...");
        await SeedDataAsync();

        _logger.LogInformation("資料庫初始化完成");
    }

    public async Task<bool> DatabaseExistsAsync()
    {
        var connectionString = _connectionFactory.GetConnectionString();
        var builder = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder(connectionString);
        var databaseName = builder.InitialCatalog;

        // 連線到 master 資料庫檢查目標資料庫是否存在
        builder.InitialCatalog = "master";
        var masterConnectionString = builder.ConnectionString;

        using var connection = new Microsoft.Data.SqlClient.SqlConnection(masterConnectionString);
        
        const string sql = """
            SELECT COUNT(1) 
            FROM sys.databases 
            WHERE name = @DatabaseName
            """;

        var count = await connection.QuerySingleAsync<int>(sql, new { DatabaseName = databaseName });
        return count > 0;
    }

    public async Task CreateDatabaseAsync()
    {
        var connectionString = _connectionFactory.GetConnectionString();
        var builder = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder(connectionString);
        var databaseName = builder.InitialCatalog;

        // 連線到 master 資料庫建立目標資料庫
        builder.InitialCatalog = "master";
        var masterConnectionString = builder.ConnectionString;

        using var connection = new Microsoft.Data.SqlClient.SqlConnection(masterConnectionString);
        
        var sql = $"CREATE DATABASE [{databaseName}]";
        
        await connection.ExecuteAsync(sql);
        _logger.LogInformation("資料庫 {DatabaseName} 建立成功", databaseName);
    }

    public async Task CreateTablesAsync()
    {
        using var connection = _connectionFactory.CreateConnection();
        
        // 建立匯率資料表 (先刪除舊表再重建以確保欄位類型正確)
        const string dropExchangeRatesTable = """
            IF EXISTS (SELECT * FROM sysobjects WHERE name='ExchangeRates' AND xtype='U')
            BEGIN
                DROP TABLE ExchangeRates;
            END
            """;

        const string createExchangeRatesTable = """
            CREATE TABLE ExchangeRates (
                CurrencyCode NVARCHAR(10) NOT NULL,
                CurrencyName NVARCHAR(50) NOT NULL,
                BankBuyRate DECIMAL(18,6) NOT NULL,
                BankSellRate DECIMAL(18,6) NOT NULL,
                BoardDate CHAR(8) NOT NULL,
                BoardTime CHAR(6) NOT NULL,
                CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
                UpdatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
                
                PRIMARY KEY (CurrencyCode, BoardDate),
                INDEX IX_ExchangeRates_BoardDate (BoardDate DESC),
                INDEX IX_ExchangeRates_CreatedAt (CreatedAt DESC)
            );
            """;

        // 建立抓取日誌資料表
        const string createScrapingLogsTable = """
            IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ScrapingLogs' AND xtype='U')
            BEGIN
                CREATE TABLE ScrapingLogs (
                    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
                    ExecutionId UNIQUEIDENTIFIER NOT NULL,
                    StartTime DATETIME2 NOT NULL,
                    EndTime DATETIME2 NULL,
                    Status NVARCHAR(20) NOT NULL, -- Success, Failed, Running
                    ProcessedCount INT NOT NULL DEFAULT 0,
                    ErrorMessage NVARCHAR(MAX) NULL,
                    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
                    
                    INDEX IX_ScrapingLogs_ExecutionId (ExecutionId),
                    INDEX IX_ScrapingLogs_StartTime (StartTime DESC),
                    INDEX IX_ScrapingLogs_Status (Status)
                );
            END
            """;

        await connection.ExecuteAsync(createExchangeRatesTable);
        await connection.ExecuteAsync(createScrapingLogsTable);
        
        _logger.LogInformation("資料表建立完成");
    }

    public async Task SeedDataAsync()
    {
        using var connection = _connectionFactory.CreateConnection();
        
        // 檢查是否已有初始資料
        const string checkDataSql = "SELECT COUNT(1) FROM ExchangeRates";
        var existingCount = await connection.QuerySingleAsync<int>(checkDataSql);
        
        if (existingCount > 0)
        {
            _logger.LogInformation("初始資料已存在，跳過資料植入");
            return;
        }

        // 植入 16 種貨幣的初始資料
        var currencies = Currency.List;
        var now = DateTime.UtcNow;
        var seedData = currencies.Select(currency => new
        {
            CurrencyCode = currency.Code,
            CurrencyName = currency.ChineseName,
            BankBuyRate = 0.0m,  // 初始匯率設為 0，等待爬蟲更新
            BankSellRate = 0.0m,
            BoardDate = now.Date,
            BoardTime = now.TimeOfDay,
            BoardDateTime = now,
            CreatedAt = now,
            UpdatedAt = now
        }).ToList();

        const string insertSql = """
            INSERT INTO ExchangeRates (CurrencyCode, CurrencyName, BankBuyRate, BankSellRate, BoardDate, BoardTime, BoardDateTime, CreatedAt, UpdatedAt)
            VALUES (@CurrencyCode, @CurrencyName, @BankBuyRate, @BankSellRate, @BoardDate, @BoardTime, @BoardDateTime, @CreatedAt, @UpdatedAt)
            """;

        await connection.ExecuteAsync(insertSql, seedData);
        
        _logger.LogInformation("初始資料植入完成，共 {Count} 筆貨幣資料", seedData.Count);
    }
}
