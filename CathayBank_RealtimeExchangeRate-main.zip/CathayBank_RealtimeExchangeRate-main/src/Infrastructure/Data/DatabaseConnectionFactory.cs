using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Data;

/// <summary>
/// 資料庫連線工廠介面
/// </summary>
public interface IDatabaseConnectionFactory
{
    /// <summary>
    /// 建立資料庫連線
    /// </summary>
    /// <returns>資料庫連線</returns>
    IDbConnection CreateConnection();
    
    /// <summary>
    /// 建立非同步資料庫連線
    /// </summary>
    /// <returns>非同步資料庫連線</returns>
    Task<IDbConnection> CreateConnectionAsync();
    
    /// <summary>
    /// 取得連線字串
    /// </summary>
    /// <returns>連線字串</returns>
    string GetConnectionString();
}

/// <summary>
/// SQL Server 資料庫連線工廠實作
/// </summary>
public class SqlServerConnectionFactory : IDatabaseConnectionFactory
{
    private readonly string _connectionString;

    public SqlServerConnectionFactory(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection") 
                          ?? throw new InvalidOperationException("資料庫連線字串 'DefaultConnection' 未設定");
    }

    public IDbConnection CreateConnection()
    {
        return new SqlConnection(_connectionString);
    }

    public async Task<IDbConnection> CreateConnectionAsync()
    {
        var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        return connection;
    }

    public string GetConnectionString()
    {
        return _connectionString;
    }
}
