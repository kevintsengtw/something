using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using CathayBank.RealtimeExchangeRate.Infrastructure.Extensions;
using CathayBank.RealtimeExchangeRate.Infrastructure.Data;
using CathayBank.RealtimeExchangeRate.Domain.Interfaces;
using CathayBank.RealtimeExchangeRate.Infrastructure.Repositories;

namespace CathayBank.RealtimeExchangeRate.DatabaseTest;

class Program
{
    static async Task Main(string[] args)
    {
        // 建立 Host
        var host = Host.CreateDefaultBuilder(args)
            .ConfigureAppConfiguration((context, config) =>
            {
                config.AddJsonFile("appsettings.json", optional: false);
                config.AddJsonFile($"appsettings.{context.HostingEnvironment.EnvironmentName}.json", optional: true);
            })
            .ConfigureServices((context, services) =>
            {
                // 註冊 Infrastructure 服務
                services.AddInfrastructure(context.Configuration);
            })
            .ConfigureLogging(logging =>
            {
                logging.ClearProviders();
                logging.AddConsole();
                logging.SetMinimumLevel(LogLevel.Information);
            })
            .Build();

        var logger = host.Services.GetRequiredService<ILogger<Program>>();
        
        try
        {
            logger.LogInformation("=== Phase 2 - 資料層測試開始 ===");

            // 1. 測試資料庫初始化
            logger.LogInformation("1. 測試資料庫初始化...");
            var dbInitializer = host.Services.GetRequiredService<IDatabaseInitializer>();
            await dbInitializer.InitializeAsync();
            logger.LogInformation("✓ 資料庫初始化完成");

            // 2. 測試 ExchangeRateRepository
            logger.LogInformation("2. 測試 ExchangeRateRepository...");
            var exchangeRateRepo = host.Services.GetRequiredService<IExchangeRateRepository>();
            
            // 測試取得最新匯率
            var latestRates = await exchangeRateRepo.GetLatestRatesAsync();
            logger.LogInformation("✓ 取得最新匯率: {Count} 筆", latestRates.Count());

            // 測試取得特定貨幣的最新匯率
            var usdRate = await exchangeRateRepo.GetLatestRateByCurrencyAsync("USD");
            if (usdRate != null)
            {
                logger.LogInformation("✓ 取得 USD 最新匯率: {CurrencyName}", usdRate.CurrencyName);
            }

            // 3. 測試 ScrapingLogRepository
            logger.LogInformation("3. 測試 ScrapingLogRepository...");
            var scrapingLogRepo = host.Services.GetRequiredService<IScrapingLogRepository>();
            
            // 建立測試日誌
            var executionId = Guid.NewGuid();
            var log = await scrapingLogRepo.CreateLogAsync(executionId);
            logger.LogInformation("✓ 建立抓取日誌: ExecutionId={ExecutionId}", executionId);

            // 更新為成功狀態
            await scrapingLogRepo.UpdateLogSuccessAsync(executionId, 16);
            logger.LogInformation("✓ 更新日誌為成功狀態");

            // 取得最近的日誌
            var recentLogs = await scrapingLogRepo.GetRecentLogsAsync(5);
            logger.LogInformation("✓ 取得最近日誌: {Count} 筆", recentLogs.Count());

            // 4. 測試 16 種貨幣初始資料
            logger.LogInformation("4. 驗證 16 種貨幣初始資料...");
            foreach (var rate in latestRates.Take(5))
            {
                logger.LogInformation("  {CurrencyCode}: {CurrencyName}", rate.CurrencyCode, rate.CurrencyName);
            }
            if (latestRates.Count() > 5)
            {
                logger.LogInformation("  ... 及其他 {Count} 種貨幣", latestRates.Count() - 5);
            }

            logger.LogInformation("=== Phase 2 - 資料層測試完成 ===");
            logger.LogInformation("✅ 所有測試項目通過！");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "❌ 資料層測試失敗");
        }
    }
}
