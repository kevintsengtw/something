using CathayBank.RealtimeExchangeRate.Application.Interfaces;
using CathayBank.RealtimeExchangeRate.Application.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CathayBank.RealtimeExchangeRate.WebScrapingTest;

class Program
{
    static async Task Main(string[] args)
    {
        Console.WriteLine("=== 網頁抓取服務測試 ===");

        // 設定服務
        var services = new ServiceCollection();
        services.AddLogging(builder => builder.AddConsole().SetMinimumLevel(LogLevel.Debug));
        services.AddHttpClient<IWebScrapingService, WebScrapingService>();
        services.AddSingleton(TimeProvider.System);

        var serviceProvider = services.BuildServiceProvider();
        var webScrapingService = serviceProvider.GetRequiredService<IWebScrapingService>();

        try
        {
            // 1. 測試網站可用性
            Console.WriteLine("1. 檢查網站可用性...");
            var isAvailable = await webScrapingService.IsWebsiteAvailableAsync();
            Console.WriteLine($"✓ 網站可用性: {(isAvailable ? "正常" : "無法連接")}");

            if (!isAvailable)
            {
                Console.WriteLine("❌ 網站無法連接，停止測試");
                return;
            }

            // 2. 測試抓取匯率
            Console.WriteLine("\n2. 開始抓取匯率資料...");
            var exchangeRates = await webScrapingService.ScrapeExchangeRatesAsync();
            var ratesList = exchangeRates.ToList();

            Console.WriteLine($"✓ 成功抓取 {ratesList.Count} 筆匯率資料");

            // 顯示前幾筆資料
            if (ratesList.Any())
            {
                Console.WriteLine("\n前5筆匯率資料:");
                foreach (var rate in ratesList.Take(5))
                {
                    Console.WriteLine($"  {rate.CurrencyCode} ({rate.CurrencyName}):");
                    Console.WriteLine($"    買進: {rate.BankBuyRate:F4}");
                    Console.WriteLine($"    賣出: {rate.BankSellRate:F4}");
                    Console.WriteLine($"    時間: {rate.BoardDateTime:yyyy-MM-dd HH:mm:ss}");
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("❌ 沒有抓取到任何匯率資料");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ 測試過程中發生錯誤: {ex.Message}");
            Console.WriteLine($"詳細錯誤: {ex}");
        }

        Console.WriteLine("\n=== 測試完成 ===");
    }
}
