# 國泰世華銀行外幣匯率系統 - 詳細實作計畫

## 📋 專案現況分析

### 目前已完成項目
- ✅ **完整的抓取邏輯** (`CathayBankExchangeRateScraper/FinalTest/Program.cs`)
  - SmartEnum Currency 定義 (16種外幣)
  - HtmlAgilityPack 解析邏輯
  - HttpClientFactory 整合
  - TimeProvider 支援
  - T-SQL 腳本產生器

- ✅ **系統架構設計文件** 
  - `SystemAnalysisAndDesign.md` - 完整需求分析與資料庫設計
  - `SystemArchitectureImplementationPlan.md` - 架構藍圖與技術規格

- ⚠️ **未完成項目**
  - `src/` 目錄下的程式碼僅為功能空殼
  - 缺乏真實的抓取邏輯整合
  - 資料庫實作未完成
  - API 端點僅有基礎架構

- 資料庫
  - 資料庫連線：`Data Source=127.0.0.1,56789;User ID=sa;Password=1qaz2wsx3edc_;Pooling=False;Connect Timeout=30;Encrypt=True;Trust Server Certificate=True;Authentication=SqlPassword;Application Intent=ReadWrite;Command Timeout=30;Initial Catalog=Sample;`

- Redis
  - ConnectionString: `127.0.0.1:6379`
  - KeyPrefix: `ComFXLinker`

---

## 🎯 實作策略

### 核心理念
**充分利用現有的成熟抓取邏輯，將其整合到企業級架構中**

### 實作原則
1. **保留驗證過的邏輯** - 完整移植 `FinalTest/Program.cs` 中的核心功能
2. **遵循既定架構** - 按照 `SystemAnalysisAndDesign.md` 的設計規範
3. **漸進式整合** - 分階段完成，每階段都可驗證運行
4. **測試驅動** - 每個功能都有對應的測試

---

## 🚀 Phase 1: 核心抓取功能遷移 (Week 1)

### 1.1 Currency SmartEnum 整合

**目標文件**: `src/Domain/ValueObjects/Currency.cs`

```csharp
// 從 FinalTest/Program.cs 第9-51行完整移植
using Ardalis.SmartEnum;

namespace CathayBank.RealtimeExchangeRate.Domain.ValueObjects
{
    public sealed class Currency : SmartEnum<Currency>
    {
        // 16種外幣定義 (完整移植)
        public static readonly Currency USD = new("USD", 1, "美元", "US Dollar", "$", 4);
        public static readonly Currency EUR = new("EUR", 2, "歐元", "Euro", "€", 4);
        // ... (其他14種貨幣)
        
        public string Code => Name;
        public string ChineseName { get; }
        public string EnglishName { get; }
        public string Symbol { get; }
        public int DecimalPlaces { get; }
        
        private Currency(string name, int value, string chineseName, 
                        string englishName, string symbol, int decimalPlaces) 
            : base(name, value)
        {
            ChineseName = chineseName;
            EnglishName = englishName;
            Symbol = symbol;
            DecimalPlaces = decimalPlaces;
        }
        
        public static Currency? FromCode(string code) =>
            TryFromName(code, out var currency) ? currency : null;
    }
}
```

**預期檔案**: 
- `src/Domain/ValueObjects/Currency.cs`
- `src/Domain/Domain.csproj` (新增 Ardalis.SmartEnum 套件)

### 1.2 WebScrapingService 實作

**目標文件**: `src/Infrastructure/Services/WebScrapingService.cs`

```csharp
// 整合 FinalTest/Program.cs 第65-165行的抓取邏輯
using HtmlAgilityPack;
using CathayBank.RealtimeExchangeRate.Domain.ValueObjects;
using CathayBank.RealtimeExchangeRate.Domain.Entities;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Services
{
    public class WebScrapingService : IWebScrapingService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<WebScrapingService> _logger;
        private readonly TimeProvider _timeProvider;
        
        private const string CATHAY_BANK_URL = 
            "https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/";

        public async Task<List<ExchangeRate>> ScrapeExchangeRatesAsync(
            CancellationToken cancellationToken = default)
        {
            // 完整移植 FinalTest/Program.cs 的抓取邏輯
            // 包含錯誤處理、重試機制、日誌記錄
        }
        
        private ExchangeRate? ExtractCurrencyRate(HtmlDocument document, 
            Currency currency, DateTime boardDateTime)
        {
            // 移植 FinalTest/Program.cs 第105-135行的解析邏輯
        }
    }
}
```

**新增介面**: `src/Application/Interfaces/IWebScrapingService.cs`

### 1.3 BackgroundService 重構

**目標文件**: `src/BackgroundServices/ExchangeRateScrapingService.cs`

```csharp
public class ExchangeRateScrapingService : BackgroundService
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<ExchangeRateScrapingService> _logger;
    private readonly IConfiguration _configuration;
    private readonly TimeProvider _timeProvider;
    
    // 工作日 08:30-16:30 每5分鐘執行
    private const string CronExpression = "0 */5 8-16 * * 1-5";

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var cronTimer = new CronTimer(CronExpression, TimeZoneInfo.Local);
        
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await cronTimer.WaitForNextTickAsync(stoppingToken);
                await ProcessExchangeRateScrapingAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("背景服務已停止");
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "背景服務執行失敗");
                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
        }
    }

    private async Task ProcessExchangeRateScrapingAsync(CancellationToken stoppingToken)
    {
        using var scope = _serviceProvider.CreateScope();
        var webScrapingService = scope.ServiceProvider.GetRequiredService<IWebScrapingService>();
        var exchangeRateService = scope.ServiceProvider.GetRequiredService<IExchangeRateService>();
        
        _logger.LogInformation("開始抓取匯率資料");
        
        var rates = await webScrapingService.ScrapeExchangeRatesAsync(stoppingToken);
        
        if (rates.Any())
        {
            await exchangeRateService.SaveExchangeRatesAsync(rates, stoppingToken);
            _logger.LogInformation("成功抓取並儲存 {Count} 筆匯率資料", rates.Count);
        }
        else
        {
            _logger.LogWarning("未抓取到任何匯率資料");
        }
    }
}
```

**需要新增套件**:
- `Sgbj.Cron.CronTimer`
- `HtmlAgilityPack` - HTML 解析
- `Ardalis.SmartEnum` - SmartEnum 支援

---

## 🏗️ Phase 2: 資料層實作 (Week 2)

### 2.1 資料庫連線與初始化

**目標文件**: `src/Infrastructure/Data/DatabaseConnectionFactory.cs`

```csharp
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Data
{
    public interface IDatabaseConnectionFactory
    {
        IDbConnection CreateConnection();
        Task<IDbConnection> CreateConnectionAsync();
    }

    public class DatabaseConnectionFactory : IDatabaseConnectionFactory
    {
        private readonly string _connectionString;

        public DatabaseConnectionFactory(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection") 
                ?? throw new ArgumentNullException(nameof(configuration));
        }

        public IDbConnection CreateConnection()
        {
            return new SqlConnection(_connectionString);
        }

        public async Task<IDbConnection> CreateConnectionAsync()
        {
            var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();
            return connection;
        }
    }
}
```

**資料庫初始化腳本**: `src/Infrastructure/Data/DatabaseInitializer.cs`

```csharp
using Dapper;
using CathayBank.RealtimeExchangeRate.Domain.ValueObjects;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Data
{
    public interface IDatabaseInitializer
    {
        Task InitializeAsync();
        Task SeedDataAsync();
    }

    public class DatabaseInitializer : IDatabaseInitializer
    {
        private readonly IDatabaseConnectionFactory _connectionFactory;
        private readonly ILogger<DatabaseInitializer> _logger;

        public DatabaseInitializer(IDatabaseConnectionFactory connectionFactory,
                                 ILogger<DatabaseInitializer> logger)
        {
            _connectionFactory = connectionFactory;
            _logger = logger;
        }

        public async Task InitializeAsync()
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            
            // 建立資料表
            await CreateTablesAsync(connection);
            
            // 植入初始資料
            await SeedDataAsync();
            
            _logger.LogInformation("資料庫初始化完成");
        }

        private async Task CreateTablesAsync(IDbConnection connection)
        {
            // 建立 Currencies 資料表
            var createCurrenciesTable = @"
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Currencies' AND xtype='U')
                CREATE TABLE Currencies (
                    Code NVARCHAR(3) PRIMARY KEY,
                    ChineseName NVARCHAR(50) NOT NULL,
                    EnglishName NVARCHAR(100) NOT NULL,
                    Symbol NVARCHAR(5) NOT NULL,
                    DecimalPlaces INT NOT NULL,
                    SortOrder INT NOT NULL,
                    IsActive BIT DEFAULT 1,
                    CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
                    UpdatedAt DATETIME2 DEFAULT GETUTCDATE()
                );";

            // 建立 ExchangeRates 資料表
            var createExchangeRatesTable = @"
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ExchangeRates' AND xtype='U')
                CREATE TABLE ExchangeRates (
                    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
                    CurrencyCode NVARCHAR(3) NOT NULL,
                    BuyRate DECIMAL(18,6) NOT NULL,
                    SellRate DECIMAL(18,6) NOT NULL,
                    BoardDateTime DATETIME2 NOT NULL,
                    CreatedAt DATETIME2 DEFAULT GETUTCDATE(),
                    UpdatedAt DATETIME2 DEFAULT GETUTCDATE(),
                    CONSTRAINT FK_ExchangeRates_Currencies 
                        FOREIGN KEY (CurrencyCode) REFERENCES Currencies(Code),
                    CONSTRAINT UQ_ExchangeRates_Unique 
                        UNIQUE (CurrencyCode, BoardDateTime)
                );";

            // 建立 ScrapingLogs 資料表
            var createScrapingLogsTable = @"
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ScrapingLogs' AND xtype='U')
                CREATE TABLE ScrapingLogs (
                    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
                    ExecutionTime DATETIME2 NOT NULL,
                    Status NVARCHAR(20) NOT NULL,
                    SuccessCount INT DEFAULT 0,
                    FailureCount INT DEFAULT 0,
                    ErrorMessage NVARCHAR(MAX),
                    DurationMs INT,
                    CreatedAt DATETIME2 DEFAULT GETUTCDATE()
                );";

            await connection.ExecuteAsync(createCurrenciesTable);
            await connection.ExecuteAsync(createExchangeRatesTable);
            await connection.ExecuteAsync(createScrapingLogsTable);

            // 建立索引
            var createIndexes = @"
                IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ExchangeRates_CurrencyCode_BoardDateTime')
                CREATE INDEX IX_ExchangeRates_CurrencyCode_BoardDateTime 
                ON ExchangeRates (CurrencyCode, BoardDateTime DESC);

                IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ExchangeRates_CreatedAt')
                CREATE INDEX IX_ExchangeRates_CreatedAt 
                ON ExchangeRates (CreatedAt DESC);

                IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ScrapingLogs_ExecutionTime')
                CREATE INDEX IX_ScrapingLogs_ExecutionTime 
                ON ScrapingLogs (ExecutionTime DESC);";

            await connection.ExecuteAsync(createIndexes);
        }

        public async Task SeedDataAsync()
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            
            // 檢查是否已有資料
            var existingCount = await connection.QuerySingleAsync<int>(
                "SELECT COUNT(*) FROM Currencies");
            
            if (existingCount > 0)
            {
                _logger.LogInformation("貨幣資料已存在，跳過初始化");
                return;
            }

            // 植入 16 種貨幣資料
            var currencies = Currency.List.Select(c => new
            {
                Code = c.Code,
                ChineseName = c.ChineseName,
                EnglishName = c.EnglishName,
                Symbol = c.Symbol,
                DecimalPlaces = c.DecimalPlaces,
                SortOrder = c.Value,
                IsActive = true,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            });

            var insertSql = @"
                INSERT INTO Currencies (Code, ChineseName, EnglishName, Symbol, 
                                      DecimalPlaces, SortOrder, IsActive, CreatedAt, UpdatedAt)
                VALUES (@Code, @ChineseName, @EnglishName, @Symbol, 
                        @DecimalPlaces, @SortOrder, @IsActive, @CreatedAt, @UpdatedAt)";

            await connection.ExecuteAsync(insertSql, currencies);
            
            _logger.LogInformation("成功植入 {Count} 種貨幣資料", currencies.Count());
        }
    }
}
```

### 2.2 Repository 實作 (使用 Dapper)

**目標文件**: `src/Infrastructure/Repositories/ExchangeRateRepository.cs`

```csharp
using Dapper;
using CathayBank.RealtimeExchangeRate.Application.Interfaces;
using CathayBank.RealtimeExchangeRate.Domain.Entities;
using CathayBank.RealtimeExchangeRate.Infrastructure.Data;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Repositories
{
    public class ExchangeRateRepository : IExchangeRateRepository
    {
        private readonly IDatabaseConnectionFactory _connectionFactory;
        private readonly ILogger<ExchangeRateRepository> _logger;

        public ExchangeRateRepository(IDatabaseConnectionFactory connectionFactory,
                                    ILogger<ExchangeRateRepository> logger)
        {
            _connectionFactory = connectionFactory;
            _logger = logger;
        }

        public async Task SaveAsync(IEnumerable<ExchangeRate> exchangeRates, 
                                  CancellationToken cancellationToken = default)
        {
            var ratesToSave = exchangeRates.ToList();
            
            using var connection = await _connectionFactory.CreateConnectionAsync();
            using var transaction = connection.BeginTransaction();
            
            try
            {
                foreach (var rate in ratesToSave)
                {
                    // 使用 MERGE 語句進行 Upsert 操作
                    var mergeSql = @"
                        MERGE ExchangeRates AS target
                        USING (SELECT @CurrencyCode AS CurrencyCode, @BoardDateTime AS BoardDateTime) AS source
                        ON (target.CurrencyCode = source.CurrencyCode AND target.BoardDateTime = source.BoardDateTime)
                        WHEN MATCHED THEN
                            UPDATE SET 
                                BuyRate = @BuyRate,
                                SellRate = @SellRate,
                                UpdatedAt = @UpdatedAt
                        WHEN NOT MATCHED THEN
                            INSERT (CurrencyCode, BuyRate, SellRate, BoardDateTime, CreatedAt, UpdatedAt)
                            VALUES (@CurrencyCode, @BuyRate, @SellRate, @BoardDateTime, @CreatedAt, @UpdatedAt);";

                    await connection.ExecuteAsync(mergeSql, new
                    {
                        CurrencyCode = rate.CurrencyCode,
                        BuyRate = rate.BuyRate,
                        SellRate = rate.SellRate,
                        BoardDateTime = rate.BoardDateTime,
                        CreatedAt = rate.CreatedAt,
                        UpdatedAt = DateTime.UtcNow
                    }, transaction);
                }
                
                transaction.Commit();
                _logger.LogInformation("成功儲存 {Count} 筆匯率資料", ratesToSave.Count);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                _logger.LogError(ex, "儲存匯率資料失敗");
                throw;
            }
        }

        public async Task<IEnumerable<ExchangeRate>> GetLatestRatesAsync(
            CancellationToken cancellationToken = default)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            
            var sql = @"
                WITH LatestRates AS (
                    SELECT 
                        CurrencyCode,
                        BuyRate,
                        SellRate,
                        BoardDateTime,
                        CreatedAt,
                        UpdatedAt,
                        ROW_NUMBER() OVER (PARTITION BY CurrencyCode ORDER BY BoardDateTime DESC) as rn
                    FROM ExchangeRates
                )
                SELECT 
                    0 as Id,
                    CurrencyCode,
                    BuyRate,
                    SellRate,
                    BoardDateTime,
                    CreatedAt,
                    UpdatedAt
                FROM LatestRates 
                WHERE rn = 1
                ORDER BY CurrencyCode";

            var results = await connection.QueryAsync<ExchangeRate>(sql);
            return results;
        }

        public async Task<ExchangeRate?> GetLatestRateAsync(string currencyCode, 
                                                          CancellationToken cancellationToken = default)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            
            var sql = @"
                SELECT TOP 1 
                    0 as Id,
                    CurrencyCode,
                    BuyRate,
                    SellRate,
                    BoardDateTime,
                    CreatedAt,
                    UpdatedAt
                FROM ExchangeRates
                WHERE CurrencyCode = @CurrencyCode
                ORDER BY BoardDateTime DESC";

            var result = await connection.QueryFirstOrDefaultAsync<ExchangeRate>(sql, 
                new { CurrencyCode = currencyCode });
            
            return result;
        }

        public async Task<IEnumerable<ExchangeRate>> GetHistoryAsync(string currencyCode, 
                                                                   DateTime startDate, 
                                                                   DateTime endDate, 
                                                                   CancellationToken cancellationToken = default)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            
            var sql = @"
                SELECT 
                    0 as Id,
                    CurrencyCode,
                    BuyRate,
                    SellRate,
                    BoardDateTime,
                    CreatedAt,
                    UpdatedAt
                FROM ExchangeRates
                WHERE CurrencyCode = @CurrencyCode 
                    AND BoardDateTime >= @StartDate 
                    AND BoardDateTime < @EndDate
                ORDER BY BoardDateTime ASC";

            var results = await connection.QueryAsync<ExchangeRate>(sql, new
            {
                CurrencyCode = currencyCode,
                StartDate = startDate,
                EndDate = endDate
            });

            return results;
        }
    }
}
```

**ScrapingLog Repository**: `src/Infrastructure/Repositories/ScrapingLogRepository.cs`

```csharp
using Dapper;
using CathayBank.RealtimeExchangeRate.Application.Interfaces;
using CathayBank.RealtimeExchangeRate.Domain.Entities;
using CathayBank.RealtimeExchangeRate.Infrastructure.Data;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Repositories
{
    public class ScrapingLogRepository : IScrapingLogRepository
    {
        private readonly IDatabaseConnectionFactory _connectionFactory;
        private readonly ILogger<ScrapingLogRepository> _logger;

        public ScrapingLogRepository(IDatabaseConnectionFactory connectionFactory,
                                   ILogger<ScrapingLogRepository> logger)
        {
            _connectionFactory = connectionFactory;
            _logger = logger;
        }

        public async Task LogScrapingResultAsync(DateTime executionTime, 
                                               string status, 
                                               int successCount, 
                                               int failureCount, 
                                               string? errorMessage = null, 
                                               int durationMs = 0,
                                               CancellationToken cancellationToken = default)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            
            var sql = @"
                INSERT INTO ScrapingLogs (ExecutionTime, Status, SuccessCount, FailureCount, 
                                        ErrorMessage, DurationMs, CreatedAt)
                VALUES (@ExecutionTime, @Status, @SuccessCount, @FailureCount, 
                        @ErrorMessage, @DurationMs, @CreatedAt)";

            await connection.ExecuteAsync(sql, new
            {
                ExecutionTime = executionTime,
                Status = status,
                SuccessCount = successCount,
                FailureCount = failureCount,
                ErrorMessage = errorMessage,
                DurationMs = durationMs,
                CreatedAt = DateTime.UtcNow
            });
        }

        public async Task<IEnumerable<ScrapingLog>> GetRecentLogsAsync(int count = 100, 
                                                                     CancellationToken cancellationToken = default)
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            
            var sql = @"
                SELECT TOP (@Count)
                    Id,
                    ExecutionTime,
                    Status,
                    SuccessCount,
                    FailureCount,
                    ErrorMessage,
                    DurationMs,
                    CreatedAt
                FROM ScrapingLogs
                ORDER BY ExecutionTime DESC";

            var results = await connection.QueryAsync<ScrapingLog>(sql, new { Count = count });
            return results;
        }
    }
}
```
```

### 2.3 資料庫初始化整合

**目標**: 應用程式啟動時自動初始化資料庫

```csharp
// 在 Program.cs 中整合資料庫初始化
var app = builder.Build();

// 初始化資料庫
using (var scope = app.Services.CreateScope())
{
    var databaseInitializer = scope.ServiceProvider.GetRequiredService<IDatabaseInitializer>();
    await databaseInitializer.InitializeAsync();
}
```

---

## 🔧 Phase 3: 服務層完善 (Week 3)

### 3.1 ExchangeRateService 實作

**目標文件**: `src/Application/Services/ExchangeRateService.cs`

```csharp
using CathayBank.RealtimeExchangeRate.Application.DTOs;
using CathayBank.RealtimeExchangeRate.Application.Interfaces;
using CathayBank.RealtimeExchangeRate.Domain.Entities;

namespace CathayBank.RealtimeExchangeRate.Application.Services
{
    public class ExchangeRateService : IExchangeRateService
    {
        private readonly IExchangeRateRepository _repository;
        private readonly IHybridCacheService _cacheService;
        private readonly ILogger<ExchangeRateService> _logger;
        private readonly TimeProvider _timeProvider;

        public ExchangeRateService(IExchangeRateRepository repository,
                                 IHybridCacheService cacheService,
                                 ILogger<ExchangeRateService> logger,
                                 TimeProvider timeProvider)
        {
            _repository = repository;
            _cacheService = cacheService;
            _logger = logger;
            _timeProvider = timeProvider;
        }

        public async Task<IEnumerable<ExchangeRateDto>> GetLatestRatesAsync(
            CancellationToken cancellationToken = default)
        {
            const string cacheKey = "latest_rates";
            
            var cachedRates = await _cacheService.GetAsync<IEnumerable<ExchangeRateDto>>(cacheKey);
            if (cachedRates != null)
            {
                return cachedRates;
            }

            var rates = await _repository.GetLatestRatesAsync(cancellationToken);
            var dtos = rates.Select(MapToDto).ToList();

            await _cacheService.SetAsync(cacheKey, dtos, TimeSpan.FromMinutes(5));
            
            return dtos;
        }

        public async Task<ExchangeRateDto?> GetLatestRateAsync(string currencyCode, 
                                                             CancellationToken cancellationToken = default)
        {
            var cacheKey = $"latest_rate_{currencyCode}";
            
            var cachedRate = await _cacheService.GetAsync<ExchangeRateDto>(cacheKey);
            if (cachedRate != null)
            {
                return cachedRate;
            }

            var rate = await _repository.GetLatestRateAsync(currencyCode, cancellationToken);
            if (rate == null) return null;

            var dto = MapToDto(rate);
            await _cacheService.SetAsync(cacheKey, dto, TimeSpan.FromMinutes(5));
            
            return dto;
        }

        public async Task SaveExchangeRatesAsync(IEnumerable<ExchangeRate> exchangeRates, 
                                               CancellationToken cancellationToken = default)
        {
            await _repository.SaveAsync(exchangeRates, cancellationToken);
            
            // 清除相關快取
            await _cacheService.RemoveByPatternAsync("latest_rate*");
            
            _logger.LogInformation("已儲存匯率資料並清除快取");
        }

        private static ExchangeRateDto MapToDto(ExchangeRate exchangeRate)
        {
            var currency = Domain.ValueObjects.Currency.FromCode(exchangeRate.CurrencyCode);
            
            return new ExchangeRateDto
            {
                CurrencyCode = exchangeRate.CurrencyCode,
                CurrencyName = currency?.ChineseName ?? exchangeRate.CurrencyCode,
                BuyRate = exchangeRate.BuyRate,
                SellRate = exchangeRate.SellRate,
                BoardDateTime = exchangeRate.BoardDateTime,
                UpdatedAt = exchangeRate.UpdatedAt,
                FormattedBuyRate = currency != null ? 
                    $"{currency.Symbol}{exchangeRate.BuyRate:F4}" : 
                    exchangeRate.BuyRate.ToString("F4"),
                FormattedSellRate = currency != null ? 
                    $"{currency.Symbol}{exchangeRate.SellRate:F4}" : 
                    exchangeRate.SellRate.ToString("F4")
            };
        }
    }
}
```

### 3.2 HybridCache 實作

**目標文件**: `src/Infrastructure/Services/HybridCacheService.cs`

```csharp
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace CathayBank.RealtimeExchangeRate.Infrastructure.Services
{
    public class HybridCacheService : IHybridCacheService
    {
        private readonly IMemoryCache _memoryCache;
        private readonly IDistributedCache _distributedCache;
        private readonly ILogger<HybridCacheService> _logger;

        public async Task<T?> GetAsync<T>(string key) where T : class
        {
            // 先檢查記憶體快取
            if (_memoryCache.TryGetValue(key, out T? memoryCachedItem))
            {
                return memoryCachedItem;
            }

            // 檢查分散式快取 (Redis)
            var distributedCachedItem = await _distributedCache.GetStringAsync(key);
            if (distributedCachedItem != null)
            {
                var item = JsonSerializer.Deserialize<T>(distributedCachedItem);
                
                // 同步回記憶體快取
                _memoryCache.Set(key, item, TimeSpan.FromMinutes(5));
                
                return item;
            }

            return null;
        }

        public async Task SetAsync<T>(string key, T value, TimeSpan expiration)
        {
            // 設定記憶體快取
            _memoryCache.Set(key, value, expiration);

            // 設定分散式快取
            var serializedValue = JsonSerializer.Serialize(value);
            var options = new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = expiration
            };
            
            await _distributedCache.SetStringAsync(key, serializedValue, options);
        }

        public async Task RemoveAsync(string key)
        {
            _memoryCache.Remove(key);
            await _distributedCache.RemoveAsync(key);
        }

        public async Task RemoveByPatternAsync(string pattern)
        {
            // 這裡需要根據 Redis 提供者實作 pattern 清除
            // 暫時先記錄日誌
            _logger.LogInformation("清除快取模式: {Pattern}", pattern);
        }
    }
}
```

---

## 🌐 Phase 4: API 層實作 (Week 4)

### 4.1 Controller 完善

**目標文件**: `src/Api/Controllers/ExchangeRatesController.cs`

```csharp
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using CathayBank.RealtimeExchangeRate.Application.DTOs;
using CathayBank.RealtimeExchangeRate.Application.Interfaces;

namespace CathayBank.RealtimeExchangeRate.Api.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    [EnableRateLimiting("ApiPolicy")]
    public class ExchangeRatesController : ControllerBase
    {
        private readonly IExchangeRateService _exchangeRateService;
        private readonly ILogger<ExchangeRatesController> _logger;

        public ExchangeRatesController(IExchangeRateService exchangeRateService,
                                     ILogger<ExchangeRatesController> logger)
        {
            _exchangeRateService = exchangeRateService;
            _logger = logger;
        }

        /// <summary>
        /// 取得所有最新匯率
        /// </summary>
        /// <returns>16種外幣的最新匯率</returns>
        [HttpGet("latest")]
        [ProducesResponseType(typeof(ApiResponse<IEnumerable<ExchangeRateDto>>), 200)]
        public async Task<ActionResult<ApiResponse<IEnumerable<ExchangeRateDto>>>> GetLatestRates()
        {
            try
            {
                var rates = await _exchangeRateService.GetLatestRatesAsync();
                
                return Ok(new ApiResponse<IEnumerable<ExchangeRateDto>>
                {
                    Success = true,
                    Data = rates,
                    Message = "查詢成功",
                    Timestamp = DateTime.UtcNow
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "查詢最新匯率失敗");
                return StatusCode(500, new ApiResponse<IEnumerable<ExchangeRateDto>>
                {
                    Success = false,
                    Message = "內部伺服器錯誤",
                    Timestamp = DateTime.UtcNow
                });
            }
        }

        /// <summary>
        /// 取得特定幣別的最新匯率
        /// </summary>
        /// <param name="currencyCode">幣別代號 (如: USD, EUR)</param>
        /// <returns>指定幣別的最新匯率</returns>
        [HttpGet("latest/{currencyCode}")]
        [ProducesResponseType(typeof(ApiResponse<ExchangeRateDto>), 200)]
        [ProducesResponseType(typeof(ApiResponse<object>), 404)]
        public async Task<ActionResult<ApiResponse<ExchangeRateDto>>> GetLatestRate(
            [FromRoute] string currencyCode)
        {
            if (string.IsNullOrWhiteSpace(currencyCode) || currencyCode.Length != 3)
            {
                return BadRequest(new ApiResponse<object>
                {
                    Success = false,
                    Message = "幣別代號格式錯誤，應為3字元",
                    Timestamp = DateTime.UtcNow
                });
            }

            try
            {
                var rate = await _exchangeRateService.GetLatestRateAsync(currencyCode.ToUpper());
                
                if (rate == null)
                {
                    return NotFound(new ApiResponse<object>
                    {
                        Success = false,
                        Message = $"找不到 {currencyCode} 的匯率資料",
                        Timestamp = DateTime.UtcNow
                    });
                }

                return Ok(new ApiResponse<ExchangeRateDto>
                {
                    Success = true,
                    Data = rate,
                    Message = "查詢成功",
                    Timestamp = DateTime.UtcNow
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "查詢 {CurrencyCode} 匯率失敗", currencyCode);
                return StatusCode(500, new ApiResponse<object>
                {
                    Success = false,
                    Message = "內部伺服器錯誤",
                    Timestamp = DateTime.UtcNow
                });
            }
        }

        /// <summary>
        /// 取得特定幣別的歷史匯率
        /// </summary>
        /// <param name="currencyCode">幣別代號</param>
        /// <param name="startDate">開始日期</param>
        /// <param name="endDate">結束日期</param>
        /// <returns>指定幣別的歷史匯率</returns>
        [HttpGet("{currencyCode}/history")]
        [ProducesResponseType(typeof(ApiResponse<IEnumerable<ExchangeRateDto>>), 200)]
        public async Task<ActionResult<ApiResponse<IEnumerable<ExchangeRateDto>>>> GetHistoryRates(
            [FromRoute] string currencyCode,
            [FromQuery] DateTime? startDate = null,
            [FromQuery] DateTime? endDate = null)
        {
            // 預設查詢最近7天
            var start = startDate ?? DateTime.Today.AddDays(-7);
            var end = endDate ?? DateTime.Today.AddDays(1);

            if (end <= start)
            {
                return BadRequest(new ApiResponse<object>
                {
                    Success = false,
                    Message = "結束日期必須大於開始日期",
                    Timestamp = DateTime.UtcNow
                });
            }

            if ((end - start).TotalDays > 90)
            {
                return BadRequest(new ApiResponse<object>
                {
                    Success = false,
                    Message = "查詢期間不能超過90天",
                    Timestamp = DateTime.UtcNow
                });
            }

            try
            {
                var rates = await _exchangeRateService.GetHistoryAsync(currencyCode.ToUpper(), start, end);
                
                return Ok(new ApiResponse<IEnumerable<ExchangeRateDto>>
                {
                    Success = true,
                    Data = rates,
                    Message = "查詢成功",
                    Timestamp = DateTime.UtcNow
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "查詢 {CurrencyCode} 歷史匯率失敗", currencyCode);
                return StatusCode(500, new ApiResponse<object>
                {
                    Success = false,
                    Message = "內部伺服器錯誤",
                    Timestamp = DateTime.UtcNow
                });
            }
        }
    }
}
```

### 4.2 依賴注入配置 (使用 Dapper)

**目標文件**: `src/Api/Program.cs`

```csharp
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.OpenApi.Models;
using CathayBank.RealtimeExchangeRate.Infrastructure.Data;
using CathayBank.RealtimeExchangeRate.Application.Interfaces;
using CathayBank.RealtimeExchangeRate.Application.Services;
using CathayBank.RealtimeExchangeRate.Infrastructure.Services;
using CathayBank.RealtimeExchangeRate.Infrastructure.Repositories;
using CathayBank.RealtimeExchangeRate.BackgroundServices;

var builder = WebApplication.CreateBuilder(args);

// 資料庫連線工廠 (Dapper)
builder.Services.AddSingleton<IDatabaseConnectionFactory, DatabaseConnectionFactory>();
builder.Services.AddScoped<IDatabaseInitializer, DatabaseInitializer>();

// HTTP Client 設定
builder.Services.AddHttpClient<IWebScrapingService, WebScrapingService>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(30);
    client.DefaultRequestHeaders.Add("User-Agent", 
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
});

// 快取服務
builder.Services.AddMemoryCache();
builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = builder.Configuration.GetConnectionString("Redis");
});

// 時間提供者
builder.Services.AddSingleton<TimeProvider>(TimeProvider.System);

// 資料存取層 (Dapper Repository)
builder.Services.AddScoped<IExchangeRateRepository, ExchangeRateRepository>();
builder.Services.AddScoped<IScrapingLogRepository, ScrapingLogRepository>();

// 應用服務
builder.Services.AddScoped<IExchangeRateService, ExchangeRateService>();
builder.Services.AddScoped<IWebScrapingService, WebScrapingService>();
builder.Services.AddScoped<IHybridCacheService, HybridCacheService>();

// 背景服務
builder.Services.AddHostedService<ExchangeRateScrapingService>();

// API 限流
builder.Services.AddRateLimiter(options =>
{
    options.AddFixedWindowLimiter("ApiPolicy", limiterOptions =>
    {
        limiterOptions.PermitLimit = 100;
        limiterOptions.Window = TimeSpan.FromMinutes(1);
        limiterOptions.QueueProcessingOrder = System.Threading.RateLimiting.QueueProcessingOrder.OldestFirst;
        limiterOptions.QueueLimit = 10;
    });
});

// Swagger 文件
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo 
    { 
        Title = "國泰世華銀行匯率 API", 
        Version = "v1",
        Description = "提供16種外幣即期匯率查詢服務"
    });
    
    var xmlFile = $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    c.IncludeXmlComments(xmlPath);
});

builder.Services.AddControllers();

var app = builder.Build();

// 開發環境設定
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "匯率 API v1");
        c.RoutePrefix = string.Empty; // Swagger 作為首頁
    });
}

app.UseRateLimiter();
app.UseRouting();
app.MapControllers();

// 初始化資料庫 (取代 EF Migration)
using (var scope = app.Services.CreateScope())
{
    var databaseInitializer = scope.ServiceProvider.GetRequiredService<IDatabaseInitializer>();
    await databaseInitializer.InitializeAsync();
}

app.Run();
```

---

## 📦 Phase 5: 套件整合與設定 (Week 5)

### 5.1 必要套件清單

根據 `SystemAnalysisAndDesign.md` 第605-650行，需要安裝以下套件：

**Domain 專案**:
```xml
<PackageReference Include="Ardalis.SmartEnum" Version="8.0.0" />
```

**Infrastructure 專案 (使用 Dapper)**:
```xml
<PackageReference Include="Dapper" Version="2.1.35" />
<PackageReference Include="Microsoft.Data.SqlClient" Version="5.1.5" />
<PackageReference Include="HtmlAgilityPack" Version="1.11.65" />
<PackageReference Include="Microsoft.Extensions.Http" Version="9.0.0" />
<PackageReference Include="Microsoft.Extensions.Http.Polly" Version="9.0.0" />
<PackageReference Include="StackExchange.Redis" Version="2.8.16" />
```

**BackgroundServices 專案**:
```xml
<PackageReference Include="Cronos" Version="0.8.4" />
<PackageReference Include="Microsoft.Extensions.Hosting" Version="9.0.0" />
```

**Api 專案**:
```xml
<PackageReference Include="Microsoft.AspNetCore.RateLimiting" Version="9.0.0" />
<PackageReference Include="Swashbuckle.AspNetCore" Version="6.8.1" />
```

### 5.2 設定檔配置

**目標文件**: `src/Api/appsettings.json`

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=CathayBankExchangeRate;Trusted_Connection=true;MultipleActiveResultSets=true",
    "Redis": "localhost:6379"
  },
  "ExchangeRateSettings": {
    "ScrapingUrl": "https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/",
    "CronExpression": "0 */5 8-16 * * 1-5",
    "RequestTimeout": 30,
    "RetryCount": 3,
    "RetryDelay": "00:00:05"
  },
  "CacheSettings": {
    "DefaultExpiration": "00:05:00",
    "LatestRatesKey": "latest_rates",
    "LatestRateKeyTemplate": "latest_rate_{0}",
    "HistoryKeyTemplate": "history_{0}_{1}_{2}"
  },
  "RateLimiting": {
    "PermitLimit": 100,
    "WindowMinutes": 1,
    "QueueLimit": 10
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning",
      "CathayBank.RealtimeExchangeRate.BackgroundServices": "Information"
    }
  },
  "AllowedHosts": "*"
}
```

---

## 🧪 Phase 6: 測試與驗證 (Week 6)

### 6.1 單元測試結構

```
tests/
├── CathayBank.RealtimeExchangeRate.UnitTests/
│   ├── Domain/
│   │   └── ValueObjects/
│   │       └── CurrencyTests.cs
│   ├── Application/
│   │   └── Services/
│   │       └── ExchangeRateServiceTests.cs
│   ├── Infrastructure/
│   │   ├── Services/
│   │   │   └── WebScrapingServiceTests.cs
│   │   └── Repositories/
│   │       └── ExchangeRateRepositoryTests.cs
│   └── BackgroundServices/
│       └── ExchangeRateScrapingServiceTests.cs
└── CathayBank.RealtimeExchangeRate.IntegrationTests/
    ├── Api/
    │   └── Controllers/
    │       └── ExchangeRatesControllerTests.cs
    └── Infrastructure/
        ├── Repositories/
        │   ├── ExchangeRateRepositoryTests.cs (Dapper 整合測試)
        │   └── ScrapingLogRepositoryTests.cs
        └── Data/
            ├── DatabaseConnectionFactoryTests.cs
            └── DatabaseInitializerTests.cs
```

### 6.2 關鍵測試案例

**ExchangeRateRepository 測試 (Dapper)**:
```csharp
[Fact]
public async Task SaveAsync_ValidRates_SavesSuccessfully()
{
    // Arrange
    var mockConnectionFactory = CreateMockConnectionFactory();
    var repository = new ExchangeRateRepository(mockConnectionFactory, _logger);
    
    var exchangeRates = new List<ExchangeRate>
    {
        new ExchangeRate 
        { 
            CurrencyCode = "USD", 
            BuyRate = 31.50m, 
            SellRate = 32.00m, 
            BoardDateTime = DateTime.Now,
            CreatedAt = DateTime.UtcNow
        }
    };
    
    // Act
    await repository.SaveAsync(exchangeRates);
    
    // Assert
    // 驗證 SQL 執行和資料儲存
    Assert.True(true); // 實際測試會檢查資料庫狀態
}

[Fact]
public async Task GetLatestRatesAsync_HasData_ReturnsLatestRates()
{
    // Arrange
    var mockConnectionFactory = CreateMockConnectionFactory();
    var repository = new ExchangeRateRepository(mockConnectionFactory, _logger);
    
    // Act
    var result = await repository.GetLatestRatesAsync();
    
    // Assert
    Assert.NotNull(result);
    Assert.True(result.Any());
}
```

**Currency SmartEnum 測試**:
```csharp
[Theory]
[InlineData("USD", "美元")]
[InlineData("EUR", "歐元")]
[InlineData("JPY", "日圓")]
public void Currency_FromCode_ReturnsCorrectCurrency(string code, string expectedChineseName)
{
    // Act
    var currency = Currency.FromCode(code);
    
    // Assert
    Assert.NotNull(currency);
    Assert.Equal(expectedChineseName, currency.ChineseName);
}
```

---

## 📈 Phase 7: 效能優化與監控 (Week 7)

### 7.1 效能最佳化項目

1. **資料庫索引優化**
   - 在 `(CurrencyCode, BoardDateTime)` 建立複合索引
   - 在 `CreatedAt` 建立索引供日期範圍查詢

2. **快取策略**
   - 最新匯率快取 5 分鐘
   - 歷史資料快取 1 小時
   - 實作快取預熱機制

3. **HTTP Client 最佳化**
   - 啟用 Keep-Alive
   - 設定適當的 Timeout
   - 實作 Polly 重試策略

### 7.2 監控與日誌

**結構化日誌**:
```csharp
_logger.LogInformation(
    "匯率抓取完成 - 成功: {SuccessCount}, 失敗: {FailureCount}, 耗時: {ElapsedMs}ms",
    successCount, failureCount, stopwatch.ElapsedMilliseconds);
```

**健康檢查端點 (使用 Dapper)**:
```csharp
builder.Services.AddHealthChecks()
    .AddCheck<DatabaseHealthCheck>("database")
    .AddUrlGroup(new Uri("https://www.cathaybk.com.tw/"), "CathayBank")
    .AddRedis(builder.Configuration.GetConnectionString("Redis"));

// DatabaseHealthCheck 實作
public class DatabaseHealthCheck : IHealthCheck
{
    private readonly IDatabaseConnectionFactory _connectionFactory;
    
    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, 
                                                        CancellationToken cancellationToken = default)
    {
        try
        {
            using var connection = await _connectionFactory.CreateConnectionAsync();
            await connection.QuerySingleAsync<int>("SELECT 1");
            return HealthCheckResult.Healthy("資料庫連線正常");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy("資料庫連線失敗", ex);
        }
    }
}
```

---

## 🚀 Phase 8: 部署準備 (Week 8)

### 8.1 Docker 容器化

**Dockerfile**:
```dockerfile
FROM mcr.microsoft.com/dotnet/aspnet:9.0 AS base
WORKDIR /app
EXPOSE 80
EXPOSE 443

FROM mcr.microsoft.com/dotnet/sdk:9.0 AS build
WORKDIR /src
COPY ["src/Api/Api.csproj", "src/Api/"]
COPY ["src/Application/Application.csproj", "src/Application/"]
COPY ["src/Domain/Domain.csproj", "src/Domain/"]
COPY ["src/Infrastructure/Infrastructure.csproj", "src/Infrastructure/"]
COPY ["src/BackgroundServices/BackgroundServices.csproj", "src/BackgroundServices/"]

RUN dotnet restore "src/Api/Api.csproj"
COPY . .
WORKDIR "/src/src/Api"
RUN dotnet build "Api.csproj" -c Release -o /app/build

FROM build AS publish
RUN dotnet publish "Api.csproj" -c Release -o /app/publish

FROM base AS final
WORKDIR /app
COPY --from=publish /app/publish .
ENTRYPOINT ["dotnet", "CathayBank.RealtimeExchangeRate.Api.dll"]
```

### 8.2 部署腳本

**docker-compose.yml**:
```yaml
version: '3.8'
services:
  api:
    build: .
    ports:
      - "5000:80"
    environment:
      - ASPNETCORE_ENVIRONMENT=Production
      - ConnectionStrings__DefaultConnection=Server=sqlserver;Database=CathayBankExchangeRate;User Id=sa;Password=YourPassword123;
      - ConnectionStrings__Redis=redis:6379
    depends_on:
      - sqlserver
      - redis

  sqlserver:
    image: mcr.microsoft.com/mssql/server:2022-latest
    environment:
      SA_PASSWORD: "YourPassword123"
      ACCEPT_EULA: "Y"
    ports:
      - "1433:1433"
    volumes:
      - sqlserver_data:/var/opt/mssql

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

volumes:
  sqlserver_data:
  redis_data:
```

---

## ✅ 完成檢查清單

### Phase 1 - 核心抓取功能
- [ ] Currency SmartEnum 移植完成
- [ ] WebScrapingService 實作完成
- [ ] BackgroundService 重構完成
- [ ] HtmlAgilityPack 解析邏輯驗證

### Phase 2 - 資料層 (使用 Dapper)
- [ ] DatabaseConnectionFactory 實作完成
- [ ] DatabaseInitializer 實作完成
- [ ] ExchangeRateRepository (Dapper) 實作完成
- [ ] ScrapingLogRepository 實作完成
- [ ] 資料庫自動初始化驗證
- [ ] 16種貨幣初始資料植入

### Phase 3 - 服務層
- [ ] ExchangeRateService 實作完成
- [ ] HybridCacheService 實作完成
- [ ] 快取策略驗證

### Phase 4 - API 層
- [ ] Controller 完整實作
- [ ] 依賴注入配置完成
- [ ] Swagger 文件正常顯示
- [ ] API 限流測試通過

### Phase 5 - 套件與設定
- [ ] 所有必要套件安裝完成
- [ ] 設定檔配置正確
- [ ] 環境變數設定完成

### Phase 6 - 測試
- [ ] 單元測試覆蓋率 > 80%
- [ ] 整合測試通過
- [ ] 端到端測試完成

### Phase 7 - 優化與監控
- [ ] 效能最佳化完成
- [ ] 日誌系統實作
- [ ] 健康檢查端點驗證

### Phase 8 - 部署
- [ ] Docker 容器化完成
- [ ] 部署腳本測試通過
- [ ] 生產環境驗證

---

## 🎯 成功指標

### 功能指標
- 能夠成功抓取國泰世華銀行 16 種外幣匯率
- 背景服務按工作日排程正常運行
- API 端點回應時間 < 2 秒
- 資料準確性 100%

### 技術指標
- 單元測試覆蓋率 > 80%
- 系統可用性 > 99%
- 錯誤率 < 1%
- 快取命中率 > 90%

### 可維護性指標
- 程式碼符合 Clean Architecture 原則
- 完整的 API 文件
- 結構化日誌與監控
- 容器化部署就緒

---

## 📞 支援與維護

### 問題回報流程
1. 檢查系統日誌
2. 驗證網路連線與目標網站可用性
3. 檢查資料庫連線狀態
4. 重啟背景服務 (如需要)

### 定期維護項目
- 每週檢查抓取成功率
- 每月分析效能指標
- 季度檢查第三方依賴套件更新
- 年度進行安全性評估

---

## 🔄 持續改進計畫

### 短期改進 (3個月內)
- 實作 Grafana 監控儀表板
- 加入更多幣別支援
- 優化抓取演算法

### 中期改進 (6個月內)
- 實作即時通知機制
- 加入匯率變動預警功能
- 提供匯率趨勢分析 API

### 長期改進 (12個月內)
- 支援多家銀行匯率比較
- 實作機器學習匯率預測
- 提供行動應用程式 API

---

*本文件將隨著專案進展持續更新，確保實作計畫的準確性和完整性。*
