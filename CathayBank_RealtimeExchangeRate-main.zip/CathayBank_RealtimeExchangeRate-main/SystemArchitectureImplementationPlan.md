## 系統架構概述
- **核心需求**：每 5 分鐘在工作日 08:30–16:30 自動抓取國泰世華銀行 16 種即期匯率，並以 RESTful API 提供即時與歷史查詢
- **非功能需求**：抓取流程 <30 秒、API 回應 <2 秒、>99% 可用性與 API 限流等安全防護
- **整體架構**：ASP.NET Core 9 WebAPI，前端使用者與管理介面透過控制器、服務、背景服務與中介軟體互動；下層整合 HybridCache（Memory + Redis）、商務邏輯層與資料存取層，資料儲存於 SQL Server
- **分層設計**：採用整潔架構，區分 Presentation、Application、Domain、Infrastructure 四層

## 主要模組
| 模組                                   | 職責                                                                                 | 關鍵設計                                              |
| -------------------------------------- | ------------------------------------------------------------------------------------ | ----------------------------------------------------- |
| 背景服務 `ExchangeRateScrapingService` | 使用 Cron「0 */5 8-16 * * 1-5」排程抓取匯率                                          | 透過 `CronTimer` 與 `TimeProvider` 控制時間並記錄日誌 |
| 網頁抓取 `WebScrapingService`          | 透過 `HttpClientFactory` 抓取 HTML、`HtmlAgilityPack`/XPath 解析；Polly 提供重試策略 | 套件清單及多層次解析策略                              |
| 資料服務 `ExchangeRateService`         | 對外提供最新與歷史匯率查詢與儲存                                                     | 定義核心介面與 DTO                                    |
| 快取服務 `HybridCacheService`          | 抽象 Memory/Redis 操作，支援快取移除與 pattern 清除                                  | 介面定義                                              |
| API 控制器 `ExchangeRatesController`   | `/latest`、`/latest/{currency}`、`/{currency}/history` 等端點                        | 基礎路由與回傳格式設計                                |

## 資料儲存與配置
- **資料表**：
  - `ExchangeRates` 以 `CurrencyCode + BoardDateTime` 做唯一索引，保存買進/賣出匯率與時間戳記
  - `Currencies` 保存幣別主檔資料
  - `ScrapingLogs` 記錄抓取狀態與錯誤資訊
- **初始資料**：預載 16 種幣別與顯示順序
- **設定檔**：連線字串、抓取排程、重試次數、快取鍵模式與 API 限流等皆集中於 `appsettings.json`

## 系統設置與安全
- 專案結構分為 `Api`、`Application`、`Domain`、`Infrastructure`、`BackgroundServices` 等專案，並提供單元與整合測試目錄
- API 安全採限流與輸入驗證；資料傳輸使用 HTTPS 並採參數化查詢；服務帳號遵循最小權限

## 部署與環境
- **環境分層**：開發（VS2022/LocalDB/Redis Docker）、測試（IIS Express/SQL Express/Standalone Redis）、生產（負載平衡、Web 伺服器叢集、SQL/Redis 叢集與備援機制）

## 實作規劃與時程
1. **Phase 1 – 基礎架構 (Week 1-2)**  
   建立專案結構、資料庫與 DI ；完成基礎 API 框架
2. **Phase 2 – 核心功能 (Week 3-4)**  
   實作網頁抓取、背景服務、資料存取層與單元測試
3. **Phase 3 – API 服務 (Week 5-6)**  
   完成控制器與 DTO、整合快取服務、撰寫 API 文件
4. **Phase 4 – 優化與測試 (Week 7-8)**  
   性能調校、整合測試、錯誤處理與監控系統
5. **Phase 5 – 部署上線 (Week 9-10)**  
   準備環境、進行生產測試、UAT 與正式上線

## 測試與品質保證
- 使用 `TimeProvider` 提高時間相關邏輯的可測試性；提供單元測試與整合測試範例
- 測試涵蓋：網頁抓取、排程、API 回應時間格式與快取過期等
