# 18 — Workflows 基礎

> 本章介紹 Agent Framework 的 Workflow 系統——一個以「執行器（Executor）+ 邊（Edge）」為核心的有向圖執行引擎。你將學會如何用 `WorkflowBuilder` 建構線性流程，以及如何用 `AgentWorkflowBuilder` 快速組合常見的多代理模式（Sequential、Concurrent、Handoffs、GroupChat）。

---

## 為什麼需要 Workflow

單一代理適合完成一件事。但現實的企業任務往往需要多個步驟、多個角色的協作：

- **分析 → 撰寫 → 審閱**：三個代理依序完成報告生成
- **翻譯鏈**：英文 → 法文 → 西班牙文 → 回譯英文，驗證語意保留度
- **路由分流**：分流代理判斷問題類型，再派發給歷史專家或數學專家
- **平行調查**：三個專家同時分析同一文件的不同面向

Workflow 把這些協作邏輯從程式碼中抽離，以**圖結構**表達任務流程，讓每個節點（Executor）只需關心自己的業務邏輯。

---

## 核心概念

### Executor（執行器）

Workflow 的基本計算單元。每個 Executor 接收輸入、執行邏輯、回傳輸出：

```csharp
// 泛型 Executor：明確宣告輸入/輸出型別
class UppercaseExecutor() : Executor<string, string>("UppercaseExecutor")
{
    public override ValueTask<string> HandleAsync(
        string message,
        IWorkflowContext context,
        CancellationToken cancellationToken = default)
        => ValueTask.FromResult(message.ToUpperInvariant());
}
```

### WorkflowBuilder

連接多個 Executor 的有向圖建構器：

```csharp
WorkflowBuilder builder = new(firstExecutor);          // 指定起始節點
builder.AddEdge(executor1, executor2);                 // 連接兩個節點
builder.WithOutputFrom(lastExecutor);                  // 指定輸出節點
Workflow workflow = builder.Build();                   // 建構完成
```

### InProcessExecution

在當前程序中執行 Workflow，分為串流與非串流兩種模式：

```csharp
// 串流模式（推薦）：即時取得每個執行器的事件
await using StreamingRun run = await InProcessExecution.RunStreamingAsync(workflow, input);
await foreach (WorkflowEvent evt in run.WatchStreamAsync())
{
    // 逐步處理事件
}

// 非串流模式：等待整個 Workflow 完成後一次取得所有事件
await using Run run = await InProcessExecution.RunAsync(workflow, input);
foreach (WorkflowEvent evt in run.NewEvents)
{
    // 批次處理事件
}
```

### WorkflowEvent 事件類型

| 事件 | 觸發時機 | 用途 |
|------|----------|------|
| `ExecutorCompletedEvent` | 每個 Executor 完成時 | 取得中間結果 |
| `AgentResponseUpdateEvent` | AI 代理串流輸出時 | 即時顯示 AI 回應 |
| `WorkflowOutputEvent` | 整個 Workflow 完成時 | 取得最終輸出 |
| `SuperStepCompletedEvent` | 每個超步驟完成時 | 儲存 Checkpoint |

---

## 第一個 Workflow：文字處理管線

以下示範最基本的兩節點線性 Workflow：大寫轉換 → 反轉文字。

```csharp
using Microsoft.Agents.AI.Workflows;

// 1. 定義執行器
class UppercaseExecutor() : Executor<string, string>("UppercaseExecutor")
{
    public override ValueTask<string> HandleAsync(string message, IWorkflowContext context, CancellationToken cancellationToken = default)
        => ValueTask.FromResult(message.ToUpperInvariant());
}

class ReverseTextExecutor() : Executor<string, string>("ReverseTextExecutor")
{
    public override ValueTask<string> HandleAsync(string message, IWorkflowContext context, CancellationToken cancellationToken = default)
        => ValueTask.FromResult(string.Concat(message.Reverse()));
}

// 2. 建構 Workflow
UppercaseExecutor uppercase = new();
ReverseTextExecutor reverse = new();

WorkflowBuilder builder = new(uppercase);
builder.AddEdge(uppercase, reverse).WithOutputFrom(reverse);
Workflow workflow = builder.Build();

// 3. 執行（串流模式）
await using StreamingRun run = await InProcessExecution.RunStreamingAsync(workflow, "Hello, World!");
await foreach (WorkflowEvent evt in run.WatchStreamAsync())
{
    if (evt is ExecutorCompletedEvent completed)
    {
        Console.WriteLine($"{completed.ExecutorId}: {completed.Data}");
    }
}
// 輸出：
// UppercaseExecutor: HELLO, WORLD!
// ReverseTextExecutor: !DLROW ,OLLEH
```

---

## AI 代理作為 Executor

`ChatClientAgent` 是框架提供的內建 Executor，將 `IChatClient` 包裝成可接入 Workflow 的代理節點。

```csharp
using Azure.AI.OpenAI;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Extensions.AI;

var endpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
var deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-4o-mini";

IChatClient chatClient = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsIChatClient();

// 建立三個翻譯代理
ChatClientAgent frenchAgent  = new(chatClient, "你只回答法文。將輸入的文字翻譯成法文。");
ChatClientAgent spanishAgent = new(chatClient, "你只回答西班牙文。將輸入的文字翻譯成西班牙文。");
ChatClientAgent englishAgent = new(chatClient, "你只回答英文。將輸入的文字翻譯成英文。");

// 建構翻譯鏈
var workflow = new WorkflowBuilder(frenchAgent)
    .AddEdge(frenchAgent, spanishAgent)
    .AddEdge(spanishAgent, englishAgent)
    .Build();
```

### 重要：TurnToken

AI 代理作為 Workflow 節點時，需要接收 **`TurnToken`** 才會開始處理訊息。TurnToken 是一個特殊的觸發信號，用來告知代理這是一個完整的對話輪次：

```csharp
await using StreamingRun run = await InProcessExecution.RunStreamingAsync(
    workflow,
    new ChatMessage(ChatRole.User, "Hello World!"));

// ⚠️ 必須傳送 TurnToken，代理才會開始執行
await run.TrySendMessageAsync(new TurnToken(emitEvents: true));

await foreach (WorkflowEvent evt in run.WatchStreamAsync())
{
    if (evt is AgentResponseUpdateEvent e)
    {
        Console.WriteLine($"{e.ExecutorId}: {e.Update.Text}");
    }
    else if (evt is WorkflowOutputEvent output)
    {
        var messages = output.As<List<ChatMessage>>()!;
        Console.WriteLine($"\n最終輸出共 {messages.Count} 則訊息");
    }
}
```

> **純文字 Executor（非 AI 代理）不需要 TurnToken**。TurnToken 只用於 `ChatClientAgent` 包裝的 AI 代理節點。

---

## AgentWorkflowBuilder：快速組合常見模式

`AgentWorkflowBuilder` 提供四種預設的多代理協作模式，讓你不需要手動配置每一條邊。

### 模式一：Sequential（循序）

代理依序執行，每個代理的輸出作為下一個代理的輸入：

```csharp
// 翻譯鏈：英文 → 法文 → 西班牙文 → 英文
Workflow sequential = AgentWorkflowBuilder.BuildSequential(
    new[] { frenchAgent, spanishAgent, englishAgent });

await RunWorkflowAsync(sequential, [new(ChatRole.User, "Hello, world!")]);
```

適合場景：報告生成（分析 → 撰寫 → 校閱）、資料處理管線、逐步轉換任務。

### 模式二：Concurrent（並行）

所有代理同時接收相同輸入，各自回應：

```csharp
// 三個翻譯代理同時翻譯同一段文字
Workflow concurrent = AgentWorkflowBuilder.BuildConcurrent(
    new[] { frenchAgent, spanishAgent, englishAgent });

await RunWorkflowAsync(concurrent, [new(ChatRole.User, "Hello, world!")]);
```

適合場景：同一內容的多語言翻譯、多個分析師同時評估同一份文件、並行驗證。

### 模式三：Handoffs（移交路由）

一個路由代理根據使用者意圖，將對話移交給對應的專家代理：

```csharp
ChatClientAgent historyTutor = new(chatClient,
    "你是歷史專家。只回答歷史問題。",
    "history_tutor",
    "歷史問題專家代理");

ChatClientAgent mathTutor = new(chatClient,
    "你是數學專家。只回答數學問題。",
    "math_tutor",
    "數學問題專家代理");

ChatClientAgent triageAgent = new(chatClient,
    "你負責判斷問題類型。歷史問題移交給 history_tutor，數學問題移交給 math_tutor。必須移交，不自行回答。",
    "triage_agent",
    "問題分流代理");

Workflow handoffs = AgentWorkflowBuilder.CreateHandoffBuilderWith(triageAgent)
    .WithHandoffs(triageAgent, [mathTutor, historyTutor])          // 分流代理可移交給誰
    .WithHandoffs([mathTutor, historyTutor], triageAgent)          // 專家回答後回到分流代理
    .Build();

// 多輪對話
List<ChatMessage> messages = [];
while (true)
{
    Console.Write("Q: ");
    messages.Add(new(ChatRole.User, Console.ReadLine()!));
    var responses = await RunWorkflowAsync(handoffs, messages);
    messages.AddRange(responses);
}
```

適合場景：客服系統（路由到不同部門）、多專業顧問、技術支援分派。

### 模式四：GroupChat（群組對話）

多個代理在同一個對話中輪流發言，由 Group Chat Manager 控制輪次：

```csharp
using Microsoft.Agents.AI.Workflows;

Workflow groupChat = AgentWorkflowBuilder
    .CreateGroupChatBuilderWith(agents => new RoundRobinGroupChatManager(agents)
    {
        MaximumIterationCount = 5   // 最多 5 輪
    })
    .AddParticipants(new[] { frenchAgent, spanishAgent, englishAgent })
    .WithName("多語翻譯群聊")
    .WithDescription("三個翻譯代理輪流回應")
    .Build();
```

適合場景：腦力激盪、多角度辯論、逐輪精煉（寫作 → 批評 → 修訂）。

---

## 完整輔助函式：RunWorkflowAsync

以下是所有模式都可以複用的執行函式：

```csharp
static async Task<List<ChatMessage>> RunWorkflowAsync(
    Workflow workflow,
    List<ChatMessage> messages)
{
    string? lastExecutorId = null;

    await using StreamingRun run = await InProcessExecution.RunStreamingAsync(workflow, messages);
    await run.TrySendMessageAsync(new TurnToken(emitEvents: true));

    await foreach (WorkflowEvent evt in run.WatchStreamAsync())
    {
        switch (evt)
        {
            case AgentResponseUpdateEvent e:
                // 顯示串流輸出（代理識別碼改變時換行）
                if (e.ExecutorId != lastExecutorId)
                {
                    lastExecutorId = e.ExecutorId;
                    Console.WriteLine();
                    Console.WriteLine($"[{e.ExecutorId}]");
                }
                Console.Write(e.Update.Text);
                break;

            case WorkflowOutputEvent output:
                Console.WriteLine();
                return output.As<List<ChatMessage>>()!;
        }
    }

    return [];
}
```

---

## NuGet 套件

```bash
# Workflow 核心
dotnet add package Microsoft.Agents.AI.Workflows

# 宣告式 Workflow（下一章介紹）
dotnet add package Microsoft.Agents.AI.Workflows.Declarative

# AI 代理基礎
dotnet add package Microsoft.Agents.AI
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

---

## Workflow 模式選擇指南

```
需要依序處理任務？
├─ 是 → Sequential（A → B → C 的線性管線）
└─ 否 → 需要所有代理同時處理相同輸入？
         ├─ 是 → Concurrent（並行輸出）
         └─ 否 → 需要根據意圖路由到不同專家？
                  ├─ 是 → Handoffs（路由 + 移交）
                  └─ 否 → 需要多個代理輪流辯論/討論？
                           └─ 是 → GroupChat（群組對話）
```

---

> **返回目錄**：[README](README.md) | **上一章**：[17 — 多 LLM 提供者整合](./17-llm-providers.md) | **下一章**：[19 — Workflows 進階](./19-workflows-advanced.md)
