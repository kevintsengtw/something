# Microsoft Agent Framework C# 入門教學

> 以繁體中文撰寫的 Microsoft Agent Framework 入門教學系列，專為 C# / .NET 開發者設計。

---

## 關於本教學

Microsoft Agent Framework 是 Microsoft 最新的開源 AI 代理框架，統一了 Semantic Kernel 與 AutoGen 的核心能力，為企業級 AI 代理開發提供完整的建構、編排與部署支援。

本教學系列將官方英文資源整理為結構化的繁體中文學習路徑，讓 C# 開發者從零開始掌握 Agent Framework。教學內容以官方 [Agent-Framework-Samples/00.ForBeginners](https://github.com/microsoft/Agent-Framework-Samples/tree/main/00.ForBeginners) 範例為骨幹，每學一個概念就搭配對應的範例實作，邊學邊做。

### 目標讀者

- 具備 C# / .NET 開發經驗的工程師
- 對 AI 代理開發有興趣的開發者
- 正在評估或導入 Agent Framework 的技術團隊

### 範圍說明

本教學分為**入門篇**（01–10 章）與**進階篇**（11 章起），均僅涵蓋 Microsoft Agent Framework 核心框架。

以下主題規劃於後續持續補充：

- Microsoft 365 Agents SDK（通道與對話管理）
- Microsoft Foundry Agent Service（雲端託管平台）
- MCP / A2A 協定深度整合
- Graph-based Workflows 進階編排

---

## 教學目錄

### 第一部分：認識框架

| 章節 | 標題 | 說明 |
|------|------|------|
| 01 | [什麼是 Microsoft Agent Framework](./01-what-is-agent-framework.md) | 框架定位、設計哲學、版本狀態、與 SK/AutoGen 的關係 |
| 02 | [核心概念總覽](./02-core-concepts.md) | AIAgent、AgentSession、Tools、ChatClient、Middleware |

### 第二部分：環境建置與快速開始

| 章節 | 標題 | 說明 |
|------|------|------|
| 03 | [開發環境準備](./03-dev-environment.md) | .NET SDK、NuGet 套件、LLM 提供者設定、IDE 建議 |
| 04 | [建立你的第一個 Agent](./04-first-agent.md) | Basic Agent 範例、基本對話、串流回應 |

### 第三部分：工具與 Middleware

| 章節 | 標題 | 說明 |
|------|------|------|
| 05 | [工具（Tools）基礎](./05-tools-basics.md) | AIFunctionFactory、自訂工具、內建工具類型 |
| 06 | [Middleware 與 Context 基礎](./06-middleware-and-context.md) | 三層 Middleware、Context Providers |

### 第四部分：範例實作

| 章節 | 標題 | 對應官方範例 |
|------|------|-------------|
| 07 | [範例實作：Travel Agent](./07-example-travel-agent.md) | `00.ForBeginners/TravelAgent` |
| 08 | [範例實作：RAG Search](./08-example-rag-search.md) | `00.ForBeginners/RAGSearch` |
| 09 | [範例實作：Planning Pattern](./09-example-planning.md) | `00.ForBeginners/Planning` |
| 10 | [範例實作：Multi-Agent 初探](./10-example-multi-agent.md) | `00.ForBeginners/MultiAgent` |

### 進階篇第一部分：部署與工程實踐

| 章節 | 標題 | 說明 |
|------|------|------|
| 11 | [ASP.NET Core WebAPI 整合](./11-aspnetcore-webapi.md) | AG-UI 串流端點、Hosting Library DI 整合、自訂 REST API、健康檢查 |
| 12 | [測試策略：單元測試與整合測試](./12-testing-strategy.md) | 工具方法單元測試、Mock ChatClient、WebApplicationFactory 整合測試 |
| 13 | [Docker 部署](./13-docker-deployment.md) | 多階段 Dockerfile、docker-compose、Secret 管理、CI/CD |

### 進階篇第二部分：核心功能延伸

| 章節 | 標題 | 說明 |
|------|------|------|
| 14 | [Context Providers 深度](./14-context-providers.md) | AIContextProvider、記憶體管理、ProviderSessionState、Session 持久化 |
| 15 | [結構化輸出](./15-structured-output.md) | ForJsonSchema\<T\>、AgentRunOptions、AG-UI State Snapshots |
| 16 | [Human-in-the-Loop](./16-human-in-the-loop.md) | ApprovalRequiredAIFunction、FunctionApprovalRequestContent、非同步確認 |
| 17 | [多 LLM 提供者整合](./17-llm-providers.md) | Azure Foundry、Azure OpenAI、Anthropic、GitHub Models、Ollama、Gemini |

### 進階篇第三部分：編排與持久化

| 章節 | 標題 | 說明 |
|------|------|------|
| 18 | [Workflows 基礎](./18-workflows-basics.md) | WorkflowBuilder、Executor、AgentWorkflowBuilder、Sequential / Concurrent / Handoffs / GroupChat |
| 19 | [Workflows 進階](./19-workflows-advanced.md) | Shared States、Fan-Out/Fan-In、Checkpointing、Declarative Workflow（YAML） |
| 20 | [Durable Agents 概念與架構](./20-durable-agents-concepts.md) | Durable Entity 架構、vs 普通代理、Session TTL、DTS Emulator |
| 21 | [Durable Agents 實作](./21-durable-agents-implementation.md) | Azure Functions 端點、Console Host、多代理 Orchestration、HITL 持久化 |

### 進階篇第四部分：可觀測性與協定

| 章節 | 標題 | 說明 |
|------|------|------|
| 22 | [OpenTelemetry 可觀測性](./22-opentelemetry-observability.md) | Traces / Metrics / Logs、Aspire Dashboard、Application Insights、Workflow OTel |
| 23 | [A2A Protocol](./23-a2a-protocol.md) | Agent Card、AddA2AServer、跨框架代理整合、Continuation Token 輪詢 |
| 24 | [AG-UI Protocol 深度](./24-agui-protocol-deep-dive.md) | 前端/後端工具、Human-in-the-Loop、State Management、SSE 事件類型 |
| 25 | [MCP 整合](./25-mcp-integration.md) | Stdio / HTTP+OAuth / Foundry Hosted、Agent as MCP Server、Microsoft Learn MCP |

### 進階篇第五部分：ADR 延伸主題

| 章節 | 標題 | 說明 |
|------|------|------|
| 26 | [Long-Running Operations](./26-long-running-operations.md) | `IAsyncChatClient`、`AsyncRunResult`、非同步任務提交 / 輪詢 / 取消 |
| 27 | [Feature Collections](./27-feature-collections.md) | `AgentRunOptions.Features`、型別安全 per-run 服務覆寫、Decorator Stack 狀態傳遞 |
| 28 | [Agent Evaluation](./28-agent-evaluation.md) | `IAgentEvaluator`、LocalEvaluator / FunctionEvaluator / FoundryEvals、CI/CD 品質門檻 |

### 附錄

| 附錄 | 標題 | 說明 |
|------|------|------|
| A | [NuGet 套件參考表](./appendix-a-nuget-packages.md) | 所有相關套件的名稱、版本、用途 |
| B | [從 Semantic Kernel / AutoGen 遷移](./appendix-b-migration-guide.md) | 概念對照表與遷移指南 |
| C | [學習資源與社群連結](./appendix-c-resources.md) | GitHub、Discord、Reddit、影片、部落格 |
| D | [提案中的架構決策（Proposed ADRs）](./appendix-d-proposed-adrs.md) | ⚠️ Tools 統一抽象、AgentRunContext、Agent Skills、Provider Clients 重命名 |
| E | [SDK 入門範例解析（01-get-started）](./appendix-e-sdk-samples-get-started.md) | 六個漸進式入門範例：Hello Agent → 工具 → 多輪 → 記憶體 → 工作流程 → Azure Functions 部署 |
| F | [SDK 代理功能範例（02-agents）](./appendix-f-sdk-samples-agents.md) | 17 個代理功能子目錄：20 步驟系列、AG-UI、A2A、OTel、CodeAct、Foundry、MCP |
| G | [SDK 工作流程範例（03-workflows）](./appendix-g-sdk-samples-workflows.md) | 14 個工作流程子目錄：串流事件、並行、條件路由、Human-in-the-Loop、Handoff 編排 |
| H | [SDK 代理主機整合（04-hosting）](./appendix-h-sdk-samples-hosting.md) | DurableAgents（Azure Functions / Emulator）、DurableWorkflows、FoundryHostedAgents |
| I | [SDK 端對端整合範例（05-end-to-end）](./appendix-i-sdk-samples-end-to-end.md) | 9 個完整整合場景：A2A 多代理、AG-UI 網頁聊天、M365 Teams、ASP.NET 認證、評測 |

---

## 框架版本資訊

| 項目 | 版本 / 狀態 |
|------|-------------|
| Microsoft Agent Framework | **1.6.1（穩定版）** |
| .NET 版本套件 | `Microsoft.Agents.AI` 1.6.1 |
| .NET GA 發佈日期 | 2026 年 4 月 2 日（v1.0.0） |
| .NET 最新版本 | 2026 年 5 月 14 日（v1.6.1）|
| Python 版本 | 1.0.1 |
| 授權 | MIT License |

---

## 快速安裝

> 自 v1.0.0 GA 起，套件已不再是預覽版本，安裝時**不需要** `--prerelease` 旗標。最新穩定版本為 **v1.6.1（2026-05-14）**。⚠️ v1.6.1 含破壞性變更，升級前請參閱[附錄 A — NuGet 套件參考](./appendix-a-nuget-packages.md#v161-主要變更從-150-升級-含破壞性變更)。

```bash
# 核心抽象
dotnet add package Microsoft.Agents.AI

# OpenAI / Azure OpenAI 支援
dotnet add package Microsoft.Agents.AI.OpenAI

# Azure OpenAI 客戶端
dotnet add package Azure.AI.OpenAI

# Azure 身份驗證
dotnet add package Azure.Identity
```

進階套件（範例實作時視需要安裝）：

```bash
# 工作流程編排
dotnet add package Microsoft.Agents.AI.Workflows

# 宣告式工作流程
dotnet add package Microsoft.Agents.AI.Workflows.Declarative

# ASP.NET Core 託管
dotnet add package Microsoft.Agents.AI.Hosting

# Azure AI Foundry 整合（v1.0.0 起由 Microsoft.Agents.AI.AzureAI 改名）
dotnet add package Microsoft.Agents.AI.Foundry
```

---

## 參考資源

### 官方儲存庫

- [microsoft/agent-framework](https://github.com/microsoft/agent-framework) — 主儲存庫（Python + .NET 原始碼）
- [microsoft/Agent-Framework-Samples](https://github.com/microsoft/Agent-Framework-Samples) — 官方範例程式碼
- [webmaxru/awesome-microsoft-agent-framework](https://github.com/webmaxru/awesome-microsoft-agent-framework) — 社群資源彙整

### 官方文件

- [Microsoft Agent Framework Overview](https://learn.microsoft.com/en-us/agent-framework/overview/) — 架構概念與核心元件
- [Agent Framework Quick Start](https://learn.microsoft.com/en-us/agent-framework/tutorials/quick-start) — 官方快速入門
- [Agent Types](https://learn.microsoft.com/en-us/agent-framework/agents/) — 代理類型說明

### 部落格與公告

- [Microsoft Agent Framework Blog](https://devblogs.microsoft.com/agent-framework/) — 官方團隊部落格
- [Introducing Microsoft Agent Framework](https://devblogs.microsoft.com/foundry/introducing-microsoft-agent-framework-the-open-source-engine-for-agentic-ai-apps/) — 框架發佈公告
- [Agent Framework Reaches RC](https://devblogs.microsoft.com/foundry/microsoft-agent-framework-reaches-release-candidate/) — RC 里程碑公告
- [Semantic Kernel + AutoGen = Agent Framework](https://devblogs.microsoft.com/semantic-kernel/semantic-kernel-and-microsoft-agent-framework/) — SK 團隊觀點

### 教學與學習

- [AI Agents for Beginners - Agent Framework](https://microsoft.github.io/ai-agents-for-beginners/14-microsoft-agent-framework/) — Microsoft 官方初學者教程
- [Copilot Developer Camp Lab](https://microsoft.github.io/copilot-camp/pages/custom-engine/agents-sdk/02-agent-with-agents-sdk/) — 實作教學

### 社群

- [Azure AI Foundry Discord](https://discord.com/) — `#agent-framework` 頻道
- [Reddit r/MSAgentFramework](https://www.reddit.com/r/MSAgentFramework/) — 社群討論

### 相關研究報告

- [Microsoft Agent Framework 全面研究報告](./microsoft-agent-framework.md) — 本系列的前置研究（含 M365 Agents SDK 與 Foundry Agent Service）

---

## 專案結構

```
microsoft-agent-framework-tutorial/
├── README.md                             ← 本文件（專案說明與資源索引）
├── PLAN-beginner-tutorial.md              ← 入門篇製作計畫與進度追蹤
├── microsoft-agent-framework.md          ← 前置研究報告
│
├── 01-what-is-agent-framework.md         ← 第一部分：認識框架
├── 02-core-concepts.md
│
├── 03-dev-environment.md                 ← 第二部分：環境建置與快速開始
├── 04-first-agent.md
│
├── 05-tools-basics.md                    ← 第三部分：工具與 Middleware
├── 06-middleware-and-context.md
│
├── 07-example-travel-agent.md            ← 第四部分：範例實作
├── 08-example-rag-search.md
├── 09-example-planning.md
├── 10-example-multi-agent.md
│
├── 14-context-providers.md               ← 進階篇第二部分：核心功能延伸
├── 15-structured-output.md
├── 16-human-in-the-loop.md
├── 17-llm-providers.md
│
├── 18-workflows-basics.md                ← 進階篇第三部分：編排與持久化
├── 19-workflows-advanced.md
├── 20-durable-agents-concepts.md
├── 21-durable-agents-implementation.md
│
├── 22-opentelemetry-observability.md     ← 進階篇第四部分：可觀測性與協定
├── 23-a2a-protocol.md
├── 24-agui-protocol-deep-dive.md
├── 25-mcp-integration.md
│
├── 26-long-running-operations.md         ← 進階篇第五部分：ADR 延伸主題
├── 27-feature-collections.md
├── 28-agent-evaluation.md
│
├── appendix-a-nuget-packages.md          ← 附錄
├── appendix-b-migration-guide.md
├── appendix-c-resources.md
├── appendix-d-proposed-adrs.md
│
├── appendix-e-sdk-samples-get-started.md ← SDK 官方範例解析（dotnet/samples）
├── appendix-f-sdk-samples-agents.md
├── appendix-g-sdk-samples-workflows.md
├── appendix-h-sdk-samples-hosting.md
└── appendix-i-sdk-samples-end-to-end.md
```

---

## 授權

本教學內容以 [MIT License](https://opensource.org/licenses/MIT) 授權。
程式碼範例參考自 [Microsoft Agent Framework](https://github.com/microsoft/agent-framework)（MIT License）。
