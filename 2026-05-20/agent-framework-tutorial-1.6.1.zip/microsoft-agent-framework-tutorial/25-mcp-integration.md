# 25 — MCP 整合

> 本章說明如何將 **Model Context Protocol（MCP）** 伺服器的工具接入代理，以及如何讓你的代理本身成為一個 MCP 工具供其他代理呼叫。MCP 是 Anthropic 提出的開放標準，正快速成為 AI 工具生態的通用語言。

---

## 什麼是 MCP

**Model Context Protocol（MCP）** 是 Anthropic 於 2024 年底推出的開放協定，定義了 AI 模型與外部工具、資源、提示範本之間的通訊方式。它的目標是讓工具開發者只需實作一次 MCP 服務端（MCP Server），任何支援 MCP 的客戶端（Claude、GitHub Copilot、Agent Framework 等）都可以直接使用。

**三種 MCP 傳輸模式**：

| 傳輸模式 | 說明 | 適用場景 |
|----------|------|----------|
| **Stdio** | 透過標準輸入/輸出通訊 | 本地 CLI 工具（npm 套件、本地程式） |
| **HTTP + SSE** | 透過 HTTP 連線的 Server-Sent Events | 遠端 MCP 服務（含驗證） |
| **Hosted（Foundry）** | Azure AI Foundry 代管 | 企業環境、無需自行部署 |

---

## 模式一：Stdio MCP Server

Stdio 模式最常見，用於整合 GitHub、Filesystem、Slack 等由 npm 套件提供的工具：

### 1. 安裝套件

```bash
dotnet add package Microsoft.Agents.AI
dotnet add package ModelContextProtocol          # MCP .NET SDK
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

### 2. 整合 GitHub MCP Server

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using ModelContextProtocol.Client;

string endpoint      = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;
string deploymentName = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-4o-mini";

// 1. 建立 MCP Client（連接到 GitHub MCP Server）
await using var mcpClient = await McpClient.CreateAsync(
    new StdioClientTransport(new StdioClientTransportOptions
    {
        Name      = "GitHub MCP Server",
        Command   = "npx",
        Arguments = ["-y", "--verbose", "@modelcontextprotocol/server-github"],
        // GITHUB_PERSONAL_ACCESS_TOKEN 需設為環境變數
    }));

// 2. 取得所有可用工具
var mcpTools = await mcpClient.ListToolsAsync();
Console.WriteLine($"從 GitHub MCP Server 載入 {mcpTools.Count} 個工具");
// 例如：search_repositories、list_commits、get_file_contents、create_issue 等

// 3. 建立代理，注入 MCP 工具
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        instructions: "你只回答 GitHub 相關問題，可以查詢儲存庫、提交記錄和問題。",
        tools:        [.. mcpTools.Cast<AITool>()]);

// 4. 使用
string result = await agent.RunAsync(
    "microsoft/semantic-kernel 儲存庫最近四次提交的摘要是什麼？");
Console.WriteLine(result);
```

### 常用 Stdio MCP Server

```bash
# GitHub
npx @modelcontextprotocol/server-github

# 本地檔案系統
npx @modelcontextprotocol/server-filesystem /path/to/directory

# Brave Search
npx @modelcontextprotocol/server-brave-search

# PostgreSQL
npx @modelcontextprotocol/server-postgres postgresql://localhost/mydb

# Slack
npx @modelcontextprotocol/server-slack
```

---

## 模式二：HTTP + SSE MCP Server（含 OAuth 驗證）

遠端 MCP 服務（如企業內部 API、受保護的服務）使用 HTTP 傳輸，並透過 OAuth 2.0 進行驗證：

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;
using ModelContextProtocol.Client;

string serverUrl = "http://localhost:7071/";  // 受保護的 MCP 服務端

// 建立帶 OAuth 驗證的 MCP Client
var consoleLogger = LoggerFactory.Create(b => b.AddConsole());

var transport = new HttpClientTransport(new HttpClientTransportOptions
{
    Endpoint = new Uri(serverUrl),
    Name     = "受保護的天氣服務",
    OAuth    = new OAuthOptions
    {
        DynamicClientRegistration = new DynamicClientRegistrationOptions
        {
            ClientName = "MyAgentClient",
        },
        RedirectUri              = new Uri("http://localhost:1179/callback"),
        AuthorizationRedirectDelegate = HandleAuthorizationAsync,  // 自訂 OAuth 流程
    }
}, httpClient: new HttpClient(), loggerFactory: consoleLogger);

await using var mcpClient = await McpClient.CreateAsync(
    transport,
    loggerFactory: consoleLogger);

var mcpTools = await mcpClient.ListToolsAsync();

AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        instructions: "你是天氣查詢助理。",
        tools:        [.. mcpTools]);

Console.WriteLine(await agent.RunAsync("紐約現在有什麼天氣警報？"));

// ── OAuth 授權回呼處理 ─────────────────────────────────────────────
static async Task<string?> HandleAuthorizationAsync(
    Uri authorizationUrl, Uri redirectUri, CancellationToken ct)
{
    // 在瀏覽器開啟授權頁面
    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
    {
        FileName = authorizationUrl.ToString(),
        UseShellExecute = true
    });

    // 啟動本地 HTTP Listener 接收 callback
    using var listener = new System.Net.HttpListener();
    listener.Prefixes.Add(redirectUri.GetLeftPart(System.UriPartial.Authority) + "/");
    listener.Start();

    var context = await listener.GetContextAsync();
    var code    = System.Web.HttpUtility.ParseQueryString(
        context.Request.Url?.Query ?? "")["code"];

    // 回應瀏覽器
    const string html = "<html><body><h1>驗證完成，可關閉此視窗</h1></body></html>";
    var buffer = System.Text.Encoding.UTF8.GetBytes(html);
    context.Response.ContentLength64 = buffer.Length;
    await context.Response.OutputStream.WriteAsync(buffer, ct);
    context.Response.Close();

    return code;
}
```

---

## 模式三：Azure AI Foundry Hosted MCP

若你的代理使用 Azure AI Foundry，可以直接使用 Foundry 代管的 MCP 工具（如 Bing 搜尋），無需自行管理 MCP Server：

```csharp
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI;

string projectEndpoint = Environment.GetEnvironmentVariable("AZURE_AI_PROJECT_ENDPOINT")!;

// 透過 AIProjectClient 建立代理（Foundry 內建 MCP 工具）
AIProjectClient projectClient = new(new Uri(projectEndpoint), new DefaultAzureCredential());

// Foundry 代管的 MCP 工具（在 Foundry Portal 設定後即可使用）
AIAgent agent = projectClient.AsAIAgent(
    name:         "ResearchAgent",
    instructions: "你是研究助理，利用 Bing 搜尋功能提供最新資訊。");

string result = await agent.RunAsync(
    "2025 年 AI 代理框架的最新發展為何？");
Console.WriteLine(result);
```

---

## 模式四：讓代理成為 MCP Server（Agent as MCP Tool）

除了消費 MCP 工具外，你的代理本身也可以成為 MCP Server，供其他代理或 AI 工具（如 Claude Desktop、GitHub Copilot）呼叫。

這個模式對應 Azure Functions 範例中的 `07_AgentAsMcpTool`：

```csharp
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Hosting.MCP;

var builder = WebApplication.CreateBuilder(args);

// 建立代理
AIAgent travelAgent = chatClient.AsAIAgent(
    name:         "TravelPlannerAgent",
    instructions: "你是旅遊規劃專家，幫助使用者規劃行程。");

// 宣告為 MCP Server，定義此代理作為工具的描述
builder.Services.AddMCPServer(options =>
{
    options.ServerInfo = new McpServerInfo
    {
        Name    = "travel-planner-mcp",
        Version = "1.0.0",
    };
    options.Tools.Add(new McpTool
    {
        Name        = "plan_trip",
        Description = "規劃旅遊行程",
        InputSchema = JsonSchema.FromType<TripRequest>(),
    });
});

var app = builder.Build();

// 掛載 MCP 端點
app.MapMCPServer("/mcp", travelAgent);
await app.RunAsync();

record TripRequest(string Destination, int Days, decimal Budget);
```

Claude Desktop 設定範例（`~/Library/Application Support/Claude/claude_desktop_config.json`）：

```json
{
  "mcpServers": {
    "travel-planner": {
      "url": "http://localhost:5000/mcp",
      "transport": "http"
    }
  }
}
```

---

## MCP 工具與原生工具的比較

| 面向 | MCP 工具 | `AIFunctionFactory.Create()` |
|------|----------|-----------------------------|
| **跨框架重用** | ✅ 任何 MCP 客戶端都可用 | ❌ 僅限當前代理 |
| **動態探索** | ✅ `ListToolsAsync()` 自動列出 | ❌ 需手動維護清單 |
| **效能** | 🔶 有網路/序列化開銷 | ✅ 原生呼叫最快 |
| **型別安全** | 🔶 JSON Schema 驗證 | ✅ 強型別 C# 方法 |
| **在地工具** | ❌ 需要 MCP Server 程序 | ✅ 函式直接定義 |
| **工具數量** | ✅ 可載入數十個工具 | 🔶 建議控制在 20 以內 |

**實務建議**：
- 優先使用 `AIFunctionFactory.Create()` 定義業務工具（型別安全、效能好）
- 整合現有生態工具（GitHub、Filesystem、資料庫）時使用 MCP
- 需要跨框架共享工具時，讓代理成為 MCP Server

---

## 整合 Microsoft Learn MCP Server

Agent Framework 的官方文件提供了 Microsoft Learn MCP Server，可查詢 .NET / Azure 文件：

```json
// MCP Client 連線設定（Stdio 模式）
{
  "command": "npx",
  "args": ["-y", "@microsoft/learn-docs-mcp"]
}
```

在代理中整合：

```csharp
await using var mcpClient = await McpClient.CreateAsync(
    new StdioClientTransport(new()
    {
        Name      = "Microsoft Learn",
        Command   = "npx",
        Arguments = ["-y", "@microsoft/learn-docs-mcp"],
    }));

var mcpTools = await mcpClient.ListToolsAsync();
// 包含：microsoft_docs_search、microsoft_docs_fetch、microsoft_code_sample_search

AIAgent docAgent = chatClient.AsAIAgent(
    instructions:
        "你是 Microsoft 技術文件助理，利用 Microsoft Learn 工具回答問題。",
    tools: [.. mcpTools.Cast<AITool>()]);

Console.WriteLine(await docAgent.RunAsync(
    "如何在 Agent Framework 中使用 WorkflowBuilder？"));
```

---

> **返回目錄**：[README](README.md) | **上一章**：[24 — AG-UI Protocol 深度](./24-agui-protocol-deep-dive.md) | **下一章**：[26 — Long-Running Operations](./26-long-running-operations.md)
