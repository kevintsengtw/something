# 01 — 什麼是 Microsoft Agent Framework

> 本章將介紹 Microsoft Agent Framework 的背景、定位與設計哲學，幫助你理解為什麼 Microsoft 要推出這個框架，以及它與 Semantic Kernel、AutoGen 之間的關係。

---

## 為什麼需要 Microsoft Agent Framework

在 AI 代理（Agent）開發的浪潮中，Microsoft 其實早已擁有兩個各有所長的框架：

- **Semantic Kernel**：企業級的 AI 編排框架，強調型別安全、Session 狀態管理、遙測監控、豐富的模型與 Embedding 支援，廣泛應用於生產環境。
- **AutoGen**：研究導向的多代理框架，以簡潔的抽象設計著稱，擅長動態多代理編排與協作模式。

這兩個框架各有擁護者，但開發者經常面臨一個問題：**該選哪一個？**

Semantic Kernel 穩定可靠但在多代理場景較為笨重；AutoGen 靈活創新但缺乏企業級的安全網。開發者不斷向 Microsoft 反映：「為什麼不能兩者兼得 — 既有 AutoGen 的創新，又有 Semantic Kernel 的信任與穩定？」

**Microsoft Agent Framework 就是這個問題的答案。**

---

## 什麼是 Microsoft Agent Framework

Microsoft Agent Framework 是一個**開源框架**（MIT License），用於建構、編排和部署 AI 代理及多代理工作流程，同時支援 **C# / .NET** 和 **Python**。

它於 2025 年 10 月 1 日以公開預覽（Public Preview）的形式發佈，隨後在 2025 年 10 月 8 日正式宣佈 Semantic Kernel 與 AutoGen 的合併。經過數個 Release Candidate 版本的迭代，**.NET 版本於 2026 年 4 月 2 日正式發佈 v1.0.0（GA）**，成為生產環境就緒的穩定版本。

### 一句話定義

> Microsoft Agent Framework 是 Semantic Kernel 與 AutoGen 的統一繼承者，結合了 AutoGen 簡潔的代理抽象與 Semantic Kernel 的企業級功能，為開發者提供建構 AI 代理的完整工具鏈。

---

## 從 Semantic Kernel 與 AutoGen 各取了什麼

理解 Agent Framework 的最佳方式，就是看它分別從兩個前身繼承了什麼：

### 來自 Semantic Kernel 的企業級基因

- **型別安全（Type Safety）**：強型別的 API 設計，減少執行時期錯誤
- **Session 狀態管理**：完整的對話狀態持久化與管理
- **過濾器與中介軟體（Filters & Middleware）**：攔截與處理代理行為的管線機制
- **遙測（Telemetry）**：內建 OpenTelemetry 支援，分散式追蹤與監控
- **模型與 Embedding 支援**：廣泛的 LLM 提供者整合

### 來自 AutoGen 的多代理創新

- **簡潔的代理抽象**：用最少的程式碼建立功能完整的代理
- **動態多代理編排**：多個代理之間的靈活協作模式
- **研究導向的前瞻能力**：持續吸收最新的 AI 代理研究成果

### Agent Framework 的全新設計

在繼承的基礎上，Agent Framework 還引入了：

- **統一的程式設計模型**：.NET 和 Python 使用一致的 API 設計
- **Graph-based Workflows**：基於圖形的工作流程引擎，對執行路徑有明確的控制
- **強健的狀態管理**：支援長時間運行場景的檢查點與恢復
- **Human-in-the-Loop**：在工作流程中插入人工審核節點
- **開放協定支援**：原生支援 MCP、A2A、AG-UI 等開放標準

---

## 版本狀態與發展時程

| 時間 | 里程碑 |
|------|--------|
| 2025 年 10 月 1 日 | 公開預覽（Public Preview）發佈 |
| 2025 年 10 月 8 日 | 正式宣佈 Semantic Kernel + AutoGen 合併 |
| 2025 年 11 月 | Ignite 2025 展示 Foundry Agent Service 整合 |
| 2026 年 2 月 19 日 | Release Candidate（RC）發佈，API 表面鎖定 |
| 2026 年 3 月 | 多個 RC 版本迭代修正 |
| **2026 年 4 月 2 日** | **.NET v1.0.0 正式發佈（GA）** |
| 2026 年 4 月 10 日 | v1.1.0：Agent Skills（Class-Based / Inline / File-Based）正式 GA |
| 2026 年 4 月 21 日 | v1.2.0：Foundry Hosted Agents 支援、Handoff HITL Orchestration |
| 2026 年 4 月 24 日 | v1.3.0：A2A SDK 1.0.0-preview2、A2A 串流與 SSE 重連 |
| 2026 年 5 月 5 日 | v1.4.0：CodeAct（Hyperlight）GA、Declarative Workflow HttpRequestAction |
| 2026 年 5 月 8 日 | v1.5.0：Magentic Orchestration（實驗性）、AG-UI 推理事件串流 |
| **2026 年 5 月 14 日** | **v1.6.1：IChatMessageInjector、Shell Tool、A2A HITL input-request**（目前最新版） |

### 現有框架的維護狀態

- **Semantic Kernel v1.x**：進入維護模式，僅接受關鍵 Bug 修復與安全性更新
- **AutoGen**：進入維護模式
- **所有新功能開發**都集中在 Microsoft Agent Framework

如果你現在才開始學習 Microsoft 的 AI 代理開發工具，直接從 Agent Framework 開始是最好的選擇。

---

## 與其他框架的定位比較

為了幫助你理解 Agent Framework 在生態系中的位置，以下是它與相關工具的比較：

| 特性 | Microsoft Agent Framework | Semantic Kernel (v1) | AutoGen | LangChain |
|------|--------------------------|---------------------|---------|-----------|
| 定位 | 統一的企業級代理框架 | 企業級 AI 編排 | 研究導向多代理 | 通用 AI 應用框架 |
| 語言支援 | C#, Python | C#, Python, Java | Python | Python, JS |
| 多代理支援 | 原生支援 | 有限 | 核心功能 | 透過擴充 |
| Graph Workflows | 原生支援 | 無 | 有限 | 透過 LangGraph |
| 企業級功能 | 完整 | 完整 | 有限 | 有限 |
| 開放協定 | MCP, A2A, AG-UI | 無 | 無 | MCP |
| 維護狀態 | 積極開發中 | 維護模式 | 維護模式 | 積極開發中 |
| 授權 | MIT | MIT | MIT | MIT |

---

## 在 Microsoft 生態系中的位置

Microsoft Agent Framework 是代理開發的**核心框架層**，但它並不是 Microsoft 代理生態系的全部。完整的生態系由三個層次組成：

```mermaid
block-beta
    columns 1
    A["使用者介面 / 通道\n(Teams, Copilot, Web, Custom Apps)"]
    B["Microsoft 365 Agents SDK\n(通道管理、對話管理、身份驗證)"]
    C["Microsoft Agent Framework ⬅ 本教學\n(代理邏輯、AI 編排、多代理工作流程)"]
    D["Microsoft Foundry Agent Service\n(雲端託管、擴展、安全性、可觀測性)"]
    E["LLM 提供者\n(Azure OpenAI, OpenAI, Anthropic...)"]

    A --> B --> C --> D --> E

    style C fill:#4A90D9,color:#fff,stroke:#2C5F8A
```

**本入門教學的焦點是 Microsoft Agent Framework 這一層**，它負責代理的核心邏輯：如何建立代理、如何賦予代理工具、如何讓多個代理協作。至於通道管理（365 Agents SDK）和雲端託管（Foundry Agent Service），屬於進階主題，將在後續教學中介紹。

---

## 適合什麼場景

Microsoft Agent Framework 特別適合以下場景：

- **企業內部的 AI 助理**：需要整合內部工具與資料來源的對話式代理
- **客戶服務自動化**：多個專業代理協作處理客戶問題
- **任務自動化**：代理能透過工具呼叫完成實際操作（查詢資料庫、呼叫 API、處理文件等）
- **RAG 應用**：結合檢索增強生成，讓代理基於特定知識庫回答問題
- **多步驟規劃**：代理自主拆解複雜任務並逐步執行

---

## 學習路徑說明

本教學系列分為**入門篇**與**進階篇**，共 28 章加 4 篇附錄：

### 入門篇（第 01 ~ 10 章）

從零開始，逐步建立對 Agent Framework 的理解與實作能力：

1. 認識框架與核心概念（第 01 ~ 02 章）
2. 環境建置與第一個 Agent（第 03 ~ 04 章）
3. 工具與 Middleware（第 05 ~ 06 章）
4. 範例實作（第 07 ~ 10 章）

### 進階篇（第 11 ~ 28 章）

深入探索框架的進階能力：

1. 部署與工程實踐：ASP.NET Core 整合、測試策略、Docker 部署（第 11 ~ 13 章）
2. 核心功能延伸：Context Providers、結構化輸出、HITL、多 LLM 整合（第 14 ~ 17 章）
3. 編排與持久化：Workflows 基礎與進階、Durable Agents（第 18 ~ 21 章）
4. 可觀測性與協定：OpenTelemetry、A2A、AG-UI、MCP 整合（第 22 ~ 25 章）
5. ADR 延伸主題：Long-Running Operations、Feature Collections、Agent Evaluation（第 26 ~ 28 章）

---

## 參考資源

- [Microsoft Agent Framework GitHub](https://github.com/microsoft/agent-framework) — 主儲存庫（MIT License）
- [Microsoft Agent Framework Overview](https://learn.microsoft.com/en-us/agent-framework/overview/) — 官方概述文件
- [Introducing Microsoft Agent Framework](https://devblogs.microsoft.com/foundry/introducing-microsoft-agent-framework-the-open-source-engine-for-agentic-ai-apps/) — 框架發佈公告
- [Semantic Kernel and Microsoft Agent Framework](https://devblogs.microsoft.com/semantic-kernel/semantic-kernel-and-microsoft-agent-framework/) — SK 團隊觀點
- [Agent Framework Reaches RC](https://devblogs.microsoft.com/foundry/microsoft-agent-framework-reaches-release-candidate/) — RC 里程碑公告
- [AI Agents for Beginners](https://microsoft.github.io/ai-agents-for-beginners/14-microsoft-agent-framework/) — Microsoft 官方初學者教程

---

> **返回目錄**：[README](README.md) | **下一章**：[02 — 核心概念總覽](./02-core-concepts.md)
