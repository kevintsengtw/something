# 23 — A2A Protocol（代理間通訊）

> 本章介紹 Agent-to-Agent（A2A）協定——Google 主導、多廠商支援的開放標準，讓不同框架、不同語言、不同公司開發的 AI 代理可以互相呼叫。Agent Framework 的 `AddA2AServer()` 讓你的代理瞬間成為標準相容的 A2A 服務端；`agentCard.AsAIAgent()` 讓你消費任何 A2A 服務。

---

## 什麼是 A2A Protocol

**A2A（Agent-to-Agent）** 是由 Google 於 2025 年提出的開放協定，目標是解決 AI 代理的「互通性」問題：不同框架建立的代理應該可以像呼叫 REST API 一樣互相溝通，而不需要了解對方的內部實作。

核心概念：

**Agent Card**（代理卡片）：代理的自我描述文件，以 JSON 格式發佈在 `/.well-known/agent.json`，包含代理名稱、技能（Skills）列表、支援的輸入/輸出格式。任何 A2A 用戶端都可以自動探索代理的能力。

**Skill**（技能）：代理對外宣告的能力單元，每個 Skill 有名稱、描述、標籤、範例，以及支援的 MIME 類型。

**Task（任務）**：一次代理呼叫的完整生命週期，含輸入、輸出、狀態（Pending / Working / Completed / Failed）、`continuation_token`（長時間任務的分頁機制）。

---

## 架構圖

```
用戶端（Agent Framework / 其他框架）
    ↓
POST /a2a  ← A2A JSON-RPC 請求
    ↓
A2A Server（你的代理）
    ↓
GET /.well-known/agent.json  ← 代理自我描述（Agent Card）
```

---

## 設定 A2A 服務端

讓你的代理成為 A2A 服務端只需三個步驟：`AddA2AServer()`、設定技能、`MapA2AServer()`。

### 1. 安裝套件

```bash
dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.Hosting.A2A
dotnet add package Microsoft.Agents.AI.AspNetCore
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

### 2. 定義代理與技能（Program.cs）

```csharp
using Azure.AI.OpenAI;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.AspNetCore;
using Microsoft.Extensions.AI;

var builder = WebApplication.CreateBuilder(args);

string endpoint = builder.Configuration["AZURE_OPENAI_ENDPOINT"]!;
string deploymentName = builder.Configuration["AZURE_OPENAI_DEPLOYMENT_NAME"] ?? "gpt-4o-mini";

// 建立 AI 代理（你的業務邏輯在這裡）
AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        name: "TravelAgent",
        instructions:
            """
            你是旅遊規劃專家。幫助使用者規劃行程、查詢景點資訊，以及建議旅遊路線。
            回答時請使用繁體中文。
            """,
        tools: [AIFunctionFactory.Create(SearchFlightsAsync),
                AIFunctionFactory.Create(SearchHotelsAsync)]);

// 設定 A2A Server，宣告這個代理的對外技能
builder.Services.AddA2AServer(options =>
{
    options.AgentCard = new AgentCard
    {
        Name        = "TravelAgent",
        Description = "台灣旅遊規劃 AI 代理",
        Version     = "1.0.0",
        Skills      =
        [
            new AgentSkill
            {
                Id          = "plan-trip",
                Name        = "旅行規劃",
                Description = "根據目的地、日期、預算規劃完整旅遊行程",
                Tags        = ["travel", "planning", "itinerary"],
                Examples    = ["規劃五天四夜的京都之旅", "台北到花蓮的週末行程"],
                InputModes  = ["text/plain"],
                OutputModes = ["text/plain"],
            },
            new AgentSkill
            {
                Id          = "search-flights",
                Name        = "航班搜尋",
                Description = "搜尋特定日期與路線的可用航班",
                Tags        = ["flights", "booking"],
                Examples    = ["台北到東京明天的早班機", "最便宜的曼谷直飛"],
                InputModes  = ["text/plain"],
                OutputModes = ["text/plain"],
            }
        ]
    };
    options.AgentFactory = sp => agent;
});

var app = builder.Build();

// 掛載 A2A 端點：
//   GET  /.well-known/agent.json  ← Agent Card
//   POST /a2a                     ← JSON-RPC 請求
app.MapA2AServer("/a2a");

await app.RunAsync();

// ── 工具函式（模擬） ──────────────────────────────────────────────
[System.ComponentModel.Description("搜尋航班")]
static Task<string> SearchFlightsAsync(string origin, string destination, string date)
    => Task.FromResult($"找到 {origin} → {destination} 於 {date} 的 3 班航班");

[System.ComponentModel.Description("搜尋飯店")]
static Task<string> SearchHotelsAsync(string city, string checkIn, string checkOut)
    => Task.FromResult($"{city} 於 {checkIn}～{checkOut} 共有 12 間可用飯店");
```

### 3. 驗證 Agent Card

```bash
curl http://localhost:5000/.well-known/agent.json | jq .
```

回應示例：

```json
{
  "name": "TravelAgent",
  "description": "台灣旅遊規劃 AI 代理",
  "version": "1.0.0",
  "url": "http://localhost:5000/a2a",
  "skills": [
    {
      "id": "plan-trip",
      "name": "旅行規劃",
      "description": "根據目的地、日期、預算規劃完整旅遊行程",
      ...
    }
  ]
}
```

---

## 消費外部 A2A 代理

### 基本呼叫：AgentCard.AsAIAgent()

```csharp
using A2A;
using Microsoft.Agents.AI;

string a2aAgentHost = Environment.GetEnvironmentVariable("A2A_AGENT_HOST")!;

// 1. 透過 A2ACardResolver 取得遠端代理的 Agent Card
A2ACardResolver resolver = new(new Uri(a2aAgentHost));
AgentCard remoteCard = await resolver.GetAgentCardAsync();

// 2. 將 Agent Card 轉換為本地可用的 AIAgent Proxy
AIAgent remoteAgent = remoteCard.AsAIAgent();

// 3. 使用方式與本地代理完全相同
AgentSession session = await remoteAgent.CreateSessionAsync();
AgentResponse response = await remoteAgent.RunAsync(
    "規劃我從台北出發五天四夜的京都旅程，預算 5 萬台幣",
    session);

Console.WriteLine(response.Text);
```

### 長時間任務：Continuation Token 輪詢

A2A 設計了 `continuation_token` 機制來處理長時間執行的任務（例如需要數十秒的深度研究任務）：

```csharp
// 啟動任務
AgentResponse response = await remoteAgent.RunAsync(
    "撰寫一份量子計算在密碼學應用的完整研究報告，包含圖表說明。",
    session);

// 持續輪詢直到完成
while (response.ContinuationToken is { } token)
{
    Console.WriteLine($"任務進行中，等待 2 秒後繼續輪詢...");
    await Task.Delay(TimeSpan.FromSeconds(2));

    // 使用 continuation token 繼續查詢結果
    response = await remoteAgent.RunAsync(
        session,
        options: new AgentRunOptions { ContinuationToken = token });
}

Console.WriteLine("最終結果：");
Console.WriteLine(response.Text);
```

### SSE 串流重連（v1.3.0 新增）

v1.3.0 在 A2A SDK 1.0.0-preview2 中新增了 **SSE stream reconnection** 機制：串流中斷後，客戶端可使用 `continuation_token` 從中斷點繼續接收，而不需要重新發送整個請求。

這與上方的 Continuation Token 輪詢不同：
- **Continuation Token 輪詢**：任務仍在執行，你定期呼叫 `RunAsync` 查詢進度
- **SSE Stream Reconnection**：你原本處於串流接收狀態，連線中斷後用 token 恢復串流

```csharp
// A2AAgentHandler 在 v1.3.0 會依 context.StreamingResponse 自動路由：
//   true  → RunStreamingAsync（SSE 串流，支援重連）
//   false → RunAsync（非串流）
//
// 客戶端偵測到 SSE 連線中斷時，以最後收到的 continuation_token 重連：
AgentResponse response = await remoteAgent.RunAsync(session);

if (response.ContinuationToken is { } token)
{
    // 串流中斷，以 continuation_token 從中斷點恢復
    response = await remoteAgent.RunAsync(
        session,
        options: new AgentRunOptions { ContinuationToken = token });
}
```

官方範例：`Agent-Framework-Samples/02-agents/A2A/A2AAgent_StreamReconnection`

---

## 將外部代理技能當作工具

這是 A2A 最強大的應用之一：將遠端代理的每個技能包裝成本地工具，讓你的協調代理（Orchestrator Agent）可以按需呼叫遠端能力：

```csharp
using System.Text.RegularExpressions;
using A2A;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

string a2aAgentHost = "https://travel-agent.example.com";
string orchestratorEndpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")!;

// 取得遠端代理的技能清單
A2ACardResolver resolver = new(new Uri(a2aAgentHost));
AgentCard remoteCard = await resolver.GetAgentCardAsync();
AIAgent remoteAgent = remoteCard.AsAIAgent();

// 將遠端代理的每個技能轉換為 AIFunction 工具
IEnumerable<AIFunction> remoteSkillTools = CreateFunctionTools(remoteAgent, remoteCard);

// 建立本地協調代理，帶有遠端技能工具
AIAgent orchestrator = new AzureOpenAIClient(
        new Uri(orchestratorEndpoint), new DefaultAzureCredential())
    .GetChatClient("gpt-4o")
    .AsAIAgent(
        instructions: "你是旅遊助理，可以使用旅遊代理的技能幫助使用者規劃旅程。",
        tools: [.. remoteSkillTools]);

Console.WriteLine(await orchestrator.RunAsync(
    "幫我規劃從台北到香港的週末旅行，包含航班和飯店建議"));

// ── 工具轉換輔助函式 ──────────────────────────────────────────────
static IEnumerable<AIFunction> CreateFunctionTools(AIAgent agent, AgentCard card)
{
    foreach (var skill in card.Skills ?? [])
    {
        var options = new AIFunctionFactoryOptions
        {
            Name = SanitizeFunctionName(skill.Name),
            Description = $"""
                {{
                    "description": "{skill.Description}",
                    "tags": "[{string.Join(", ", skill.Tags ?? [])}]",
                    "examples": "[{string.Join(", ", skill.Examples ?? [])}]",
                    "inputModes": "[{string.Join(", ", skill.InputModes ?? [])}]",
                    "outputModes": "[{string.Join(", ", skill.OutputModes ?? [])}]"
                }}
                """,
        };

        yield return AIFunctionFactory.Create(
            async (string input, CancellationToken ct) =>
                (await agent.RunAsync(input, cancellationToken: ct)).Text,
            options);
    }

    static string SanitizeFunctionName(string name) =>
        Regex.Replace(name, "[^0-9A-Za-z]+", "_");
}
```

---

## 使用 A2A Hosting Library 簡化端點設定（第 11 章回顧）

第 11 章中提到的 Hosting Library 模式也支援 A2A：

```csharp
// 使用 Hosting Library（AddAIAgent + AddA2AServer + MapA2AServer）
var builder = WebApplication.CreateBuilder(args);

builder.AddAIAgent("travel-agent",
    instructions: "你是旅遊規劃代理。",
    chatClientServiceKey: "gpt-4o")
    .WithAITool<FlightSearchTool>()
    .WithInMemorySessionStore();

// v1.3.0：A2A 設定移至獨立的 AddA2AServer 呼叫（AIAgentExtensions 的 A2A 鏈式方法已移除）
builder.Services.AddA2AServer(options =>
{
    options.AgentCard = new AgentCard
    {
        Name   = "TravelAgent",
        Skills = [new AgentSkill { Name = "旅行規劃", Description = "..." }]
    };
    options.AgentFactory = sp =>
        sp.GetRequiredKeyedService<AIAgent>("travel-agent");
});

var app = builder.Build();
app.MapA2AServer("/a2a");
await app.RunAsync();
```

---

## A2A vs 其他整合方式

| 整合方式 | 適用場景 | 優點 | 限制 |
|----------|----------|------|------|
| **A2A Protocol** | 跨組織、跨框架代理整合 | 開放標準、自動探索技能 | 需要網路呼叫 |
| **直接 DI 注入** | 同一個服務的多代理協作 | 效能最佳（無網路） | 僅限同程序 |
| **MCP Tool** | 代理呼叫工具/資源 | 工具豐富的生態 | 不適合代理間對話 |
| **Workflow** | 預先定義的多代理管線 | 結構清晰、可追蹤 | 流程固定、不靈活 |

---

## v1.6.1 新增：Human-in-the-Loop 工作流程

> 🆕 **v1.6.1 新增**：A2A 協定新增 `input-request` 內容類型，讓多代理工作流程在執行期間可以暫停，等待人工確認後繼續。

在複雜的多代理工作流程中，代理有時需要在關鍵決策點取得人工輸入，而不是自動繼續執行（例如：批准大額退款、確認不可逆操作）。v1.6.1 的 A2A `input-request` 機制專為此設計。

### 工作流程說明

```
代理執行中
    ↓
需要人工確認（關鍵決策點）
    ↓
代理發送 input-request 訊息
    ↓
客戶端偵測並提示使用者
    ↓
使用者輸入 → send-input 繼續
    ↓
代理接收輸入並完成執行
```

### 客戶端處理範例

```csharp
using A2A;
using Microsoft.Agents.AI;

// 發送初始請求
AgentResponse response = await remoteAgent.RunAsync("請批准 NT$50,000 的退款申請", session);

// 輪詢處理 input-request（人工輸入請求）
while (response.RequiresInput)
{
    // 顯示代理的問題給人工審核者
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine($"\n[需要人工確認] {response.InputRequest?.Prompt}");
    Console.ResetColor();
    Console.Write("請輸入審批決定（approve/reject）：");
    string humanInput = Console.ReadLine()!;

    // 以人工輸入繼續執行代理工作流程
    response = await remoteAgent.RunAsync(
        humanInput, session,
        options: new AgentRunOptions { ContinuationToken = response.ContinuationToken });
}

Console.WriteLine($"\n最終結果：{response.Text}");
```

### 與 AG-UI Human-in-the-Loop（第 16 章）的差異

| 特性 | AG-UI HITL（ch16） | A2A input-request（本節） |
|------|-------------------|------------------------|
| 適用場景 | 單一代理內的人工審批 | 多代理工作流程跨代理暫停 |
| 觸發機制 | `ApprovalRequiredAIFunction` | A2A `input-request` 內容類型 |
| 通訊協定 | AG-UI SSE 事件 | A2A JSON-RPC |
| 適合架構 | 本地 / 同框架代理 | 跨框架跨組織代理 |

---

> **返回目錄**：[README](README.md) | **上一章**：[22 — OpenTelemetry 可觀測性](./22-opentelemetry-observability.md) | **下一章**：[24 — AG-UI Protocol 深度](./24-agui-protocol-deep-dive.md)
