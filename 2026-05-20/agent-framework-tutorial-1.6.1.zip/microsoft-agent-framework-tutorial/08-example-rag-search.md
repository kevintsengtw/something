# 08 — 範例實作：RAG Search

> 本章透過官方的 RAG Search 範例，展示如何讓代理基於特定文件回答問題，而非僅依靠 LLM 的訓練知識。
>
> 對應官方範例：[Agent-Framework-Samples/00.ForBeginners/05-agentic-rag](https://github.com/microsoft/Agent-Framework-Samples/tree/main/00.ForBeginners/05-agentic-rag/code_samples/dotnet-agent-framework-msfoundry-file-search)

---

## 什麼是 RAG

RAG（Retrieval-Augmented Generation，檢索增強生成）是一種讓 LLM 能夠**基於外部知識來回答問題**的技術模式。

### 為什麼需要 RAG

LLM 的知識有兩個重要限制：

1. **知識截止日期**：LLM 只知道訓練資料中的內容，不知道之後發生的事
2. **缺乏私有知識**：LLM 不知道你的公司文件、產品手冊、內部規章等

RAG 的解決方式是：在每次對話前，先從你的知識庫中**檢索**相關文件，再把這些文件當作上下文傳給 LLM，讓它**基於這些文件**來生成回應。

### RAG 的運作流程

```mermaid
flowchart TD
    A["使用者提問"] --> B["向量搜尋\n（從知識庫中檢索相關文件）"]
    B --> C["將相關文件片段\n注入 LLM 的上下文"]
    C --> D["LLM 基於文件\n生成回應"]
    D --> E["回傳給使用者"]

    style B fill:#D4EDDA,stroke:#28A745,color:#333
    style C fill:#FFF3CD,stroke:#FFC107,color:#333
    style D fill:#E8F0FE,stroke:#4A90D9,color:#333
```

---

## 範例情境

我們要建立一個**文件問答代理**，它只根據上傳的 Contoso Travel 公司文件來回答問題。如果文件中沒有相關資訊，代理必須誠實告知，而非自行推測。

### 知識文件

官方範例使用一份簡短的 Markdown 文件作為知識來源（`document.md`）：

```markdown
- Contoso Travel 提供前往全球異國目的地的豪華度假套餐。
- 我們的高級旅行服務包括個人化行程規劃和 24/7 禮賓支援。
- Contoso 的旅遊保險涵蓋醫療緊急事件、行程取消和行李遺失。
- 熱門目的地包括馬爾地夫、瑞士阿爾卑斯山和非洲 Safari。
- Contoso Travel 提供精品飯店和私人導覽的獨家體驗。
```

---

## 範例架構

```mermaid
flowchart TD
    Upload["上傳文件\n(document.md)"] --> VS["Vector Store\n(向量儲存)"]
    VS --> FST["HostedFileSearchTool\n(檔案搜尋工具)"]

    User["使用者提問"] --> Agent["RAG Agent"]
    Agent --> FST
    FST -->|"檢索相關段落"| Agent
    Agent -->|"基於文件生成回應"| LLM["LLM\n(gpt-4o-mini)"]
    LLM --> Response["回應使用者"]

    style VS fill:#FFF3CD,stroke:#FFC107,color:#333
    style FST fill:#D4EDDA,stroke:#28A745,color:#333
    style Agent fill:#4A90D9,color:#fff,stroke:#2C5F8A
```

---

## 前置需求

此範例使用 **Azure AI Foundry** 的託管檔案搜尋功能，你需要：

1. 一個 Azure 訂閱帳號
2. 已建立 Azure AI Foundry 專案
3. 已部署一個模型（例如 `gpt-4o-mini`）
4. 已安裝 Azure CLI 並完成登入（`az login`）

### 環境變數設定

```bash
$env:AZURE_AI_PROJECT_ENDPOINT = "https://<your-project>.services.ai.azure.com"
$env:AZURE_AI_MODEL_DEPLOYMENT_NAME = "gpt-4o-mini"
```

---

## 完整程式碼

### 專案建立

```bash
mkdir RAGSearch
cd RAGSearch
dotnet new console
dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.OpenAI
dotnet add package Microsoft.Agents.AI.Foundry
dotnet add package Microsoft.Extensions.AI
dotnet add package Microsoft.Extensions.AI.OpenAI
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.AI.Projects
dotnet add package Azure.Identity
dotnet add package OpenAI
```

### document.md（知識文件）

在專案目錄下建立 `document.md`：

```markdown
- Contoso Travel 提供前往全球異國目的地的豪華度假套餐。
- 我們的高級旅行服務包括個人化行程規劃和 24/7 禮賓支援。
- Contoso 的旅遊保險涵蓋醫療緊急事件、行程取消和行李遺失。
- 熱門目的地包括馬爾地夫、瑞士阿爾卑斯山和非洲 Safari。
- Contoso Travel 提供精品飯店和私人導覽的獨家體驗。
```

### Program.cs

```csharp
using System.ClientModel;
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using OpenAI;
using OpenAI.Files;
using OpenAI.VectorStores;

// ============================================================
// 1. 設定 Azure AI Foundry 連線
// ============================================================

var endpoint = Environment.GetEnvironmentVariable("AZURE_AI_PROJECT_ENDPOINT")
    ?? throw new InvalidOperationException("請設定 AZURE_AI_PROJECT_ENDPOINT 環境變數");
var deploymentName = Environment.GetEnvironmentVariable("AZURE_AI_MODEL_DEPLOYMENT_NAME")
    ?? "gpt-4o-mini";

// 建立 AI Project 客戶端（使用 Azure CLI 認證）
AIProjectClient aiProjectClient = new(
    new Uri(endpoint),
    new AzureCliCredential());

// 從 Foundry 取得 OpenAI 客戶端
OpenAIClient openAIClient = aiProjectClient.GetProjectOpenAIClient();

// ============================================================
// 2. 上傳知識文件並建立 Vector Store
// ============================================================

Console.WriteLine("正在上傳知識文件...");

// 上傳文件到 Foundry 服務
OpenAIFileClient fileClient = openAIClient.GetOpenAIFileClient();
ClientResult<OpenAIFile> uploadResult = await fileClient.UploadFileAsync(
    filePath: "document.md",
    purpose: FileUploadPurpose.Assistants);

Console.WriteLine($"文件已上傳，ID：{uploadResult.Value.Id}");

// 建立 Vector Store（自動將文件轉為向量嵌入）
#pragma warning disable OPENAI001
VectorStoreClient vectorStoreClient = openAIClient.GetVectorStoreClient();
ClientResult<VectorStore> vectorStoreResult = await vectorStoreClient.CreateVectorStoreAsync(
    options: new VectorStoreCreationOptions()
    {
        Name = "contoso-travel-knowledge-base",
        FileIds = { uploadResult.Value.Id }
    });
#pragma warning restore OPENAI001

Console.WriteLine($"Vector Store 已建立，ID：{vectorStoreResult.Value.Id}");

// ============================================================
// 3. 建立 RAG Agent
// ============================================================

// 建立 Hosted File Search 工具，連接到 Vector Store
var fileSearchTool = new HostedFileSearchTool()
{
    Inputs = [new HostedVectorStoreContent(vectorStoreResult.Value.Id)]
};

// 建立代理
AIAgent agent = await aiProjectClient.CreateAIAgentAsync(
    model: deploymentName,
    name: "ContosoRAGAgent",
    instructions: """
        你是一個專門回答 Contoso Travel 相關問題的 AI 助理。

        重要規則：
        - 僅使用從文件中檢索到的資訊來回答問題
        - 如果文件中沒有相關資訊，請明確告知：
          「很抱歉，上傳的文件中沒有包含足以回答該問題的資訊。」
        - 不要使用通用知識或推測
        - 回答時明確引用文件來源
        - 使用繁體中文回答
        """,
    tools: [fileSearchTool]);

// ============================================================
// 4. 建立 Session 並對話
// ============================================================

AgentSession session = await agent.CreateSessionAsync();

// 測試問題 1：文件中有答案的問題
Console.WriteLine("\n--- 問題 1 ---");
Console.WriteLine("問：Contoso 的旅遊保險涵蓋哪些項目？");
var response1 = await agent.RunAsync(
    "Contoso 的旅遊保險涵蓋哪些項目？", session);
Console.WriteLine($"答：{response1.Text}");

// 測試問題 2：文件中有答案的問題
Console.WriteLine("\n--- 問題 2 ---");
Console.WriteLine("問：Contoso Travel 有哪些熱門目的地？");
var response2 = await agent.RunAsync(
    "Contoso Travel 有哪些熱門目的地？", session);
Console.WriteLine($"答：{response2.Text}");

// 測試問題 3：文件中沒有答案的問題
Console.WriteLine("\n--- 問題 3 ---");
Console.WriteLine("問：Contoso 的機票退費政策是什麼？");
var response3 = await agent.RunAsync(
    "Contoso 的機票退費政策是什麼？", session);
Console.WriteLine($"答：{response3.Text}");
```

---

## 程式碼解析

### 步驟 1：上傳文件與建立 Vector Store

這是 RAG 的核心準備步驟。Azure AI Foundry 會自動將文件內容轉換為向量嵌入（Vector Embeddings），儲存在 Vector Store 中：

```csharp
// 上傳文件
ClientResult<OpenAIFile> uploadResult = await fileClient.UploadFileAsync(
    filePath: "document.md",
    purpose: FileUploadPurpose.Assistants);  // 指定用途為 Assistants

// 建立 Vector Store（自動向量化）
ClientResult<VectorStore> vectorStoreResult = await vectorStoreClient.CreateVectorStoreAsync(
    options: new VectorStoreCreationOptions()
    {
        Name = "contoso-travel-knowledge-base",
        FileIds = { uploadResult.Value.Id }  // 關聯上傳的文件
    });
```

你不需要自己處理文字切片、嵌入計算或向量資料庫 — Foundry 全部託管處理。

### 步驟 2：建立 HostedFileSearchTool

`HostedFileSearchTool` 是 Agent Framework 提供的內建工具，它連接到你剛建立的 Vector Store：

```csharp
var fileSearchTool = new HostedFileSearchTool()
{
    Inputs = [new HostedVectorStoreContent(vectorStoreResult.Value.Id)]
};
```

當代理收到問題時，它會自動呼叫這個工具，從 Vector Store 中檢索最相關的文件片段。

### 步驟 3：建立代理與 Session

注意這裡使用的是 `aiProjectClient.CreateAIAgentAsync()`（Foundry 託管方式），而非之前的 `chatClient.AsAIAgent()`（本地方式）。

> 💡 **v1.6.1 推薦**：若你使用 v1.6.1+ 且不需要 Foundry 託管的 Vector Store，可改用 `FoundryAgent` 直接建立模式（詳見[第 17 章](./17-llm-providers.md)），搭配 client-side `AIFunctionFactory` 工具，彈性更高。本範例因需要 `HostedFileSearchTool` 連接 Foundry Vector Store，仍使用 Foundry 託管方式。

```csharp
AIAgent agent = await aiProjectClient.CreateAIAgentAsync(
    model: deploymentName,
    name: "ContosoRAGAgent",
    instructions: "...",
    tools: [fileSearchTool]
);

// 建立 Session 管理對話狀態
AgentSession session = await agent.CreateSessionAsync();
```

`AgentSession` 管理對話的上下文與狀態，讓代理能夠在多輪對話中記住先前的問答內容。

### 步驟 4：Instructions 的重要性

RAG 場景中，Instructions 的設計特別重要。你需要明確告訴代理：

- **只能使用文件中的資訊**回答（避免 LLM 自行編造）
- **無法回答時必須明確告知**（避免幻覺）
- **引用文件來源**（增加可信度）

---

## 執行結果範例

```
正在上傳知識文件...
文件已上傳，ID：file-abc123
Vector Store 已建立，ID：vs-xyz789

--- 問題 1 ---
問：Contoso 的旅遊保險涵蓋哪些項目？
答：根據文件資料，Contoso 的旅遊保險涵蓋以下項目：
    1. 醫療緊急事件
    2. 行程取消
    3. 行李遺失

--- 問題 2 ---
問：Contoso Travel 有哪些熱門目的地？
答：根據文件資料，Contoso Travel 的熱門目的地包括：
    - 馬爾地夫
    - 瑞士阿爾卑斯山
    - 非洲 Safari

--- 問題 3 ---
問：Contoso 的機票退費政策是什麼？
答：很抱歉，上傳的文件中沒有包含關於機票退費政策的資訊。
    建議您直接聯繫 Contoso Travel 客服取得相關資訊。
```

注意問題 3 的回應 — 代理正確地判斷文件中沒有退費政策的資訊，並誠實告知使用者。

---

## RAG vs 直接對話的差異

| 方面 | 無 RAG | 有 RAG |
|------|--------|--------|
| 知識來源 | LLM 訓練資料 | 你指定的文件 |
| 即時性 | 有知識截止日期 | 可隨時更新文件 |
| 準確性 | 可能產生幻覺 | 基於實際文件，較不易幻覺 |
| 私有知識 | 無法存取 | 完全支援 |
| 可追溯性 | 無法驗證來源 | 可引用文件出處 |

---

## 不使用 Azure AI Foundry 的替代方案

如果你沒有 Azure 訂閱，仍然可以實現 RAG 效果。概念是一樣的，只是需要自己處理文件檢索的部分：

```csharp
// 簡化版 RAG：使用 Context Provider 手動注入文件內容
public class SimpleRAGProvider : AIContextProvider
{
    private readonly string _documentContent;

    public SimpleRAGProvider(string documentPath)
    {
        _documentContent = File.ReadAllText(documentPath);
    }

    protected override ValueTask<AIContext> ProvideAIContextAsync(
        InvokingContext context,
        CancellationToken cancellationToken = default)
    {
        var instructions = $"""
            以下是相關的參考文件內容，請僅基於這些內容回答問題：

            ---
            {_documentContent}
            ---
            """;

        return ValueTask.FromResult(new AIContext { Instructions = instructions });
    }
}
```

這種方式適合文件內容較短的情況。當文件量大時，你需要使用向量搜尋來只檢索最相關的片段，避免超出 LLM 的 Token 上限。

---

## 本章重點回顧

| 概念 | 說明 |
|------|------|
| RAG | 檢索增強生成，讓代理基於外部文件回答問題 |
| Vector Store | 將文件轉為向量嵌入，支援語意搜尋 |
| HostedFileSearchTool | Agent Framework 的內建檔案搜尋工具 |
| AgentSession | 託管代理的對話狀態管理 |
| Grounding Instructions | 指示代理只使用文件內容，避免幻覺 |

---

## v1.6.1 新增：AgentSessionFiles — 工作階段檔案管理

> 🆕 **v1.6.1 新增**：`AgentSessionFiles` 提供工作階段範圍（session-scoped）的原生檔案管理，讓你在對話中即時上傳並引用文件，適合動態的文件分析場景。

### 與 HostedFileSearchTool（本章）的差異

| 特性 | `AgentSessionFiles`（v1.6.1） | `HostedFileSearchTool`（本章） |
|------|------------------------------|-------------------------------|
| 範圍 | 工作階段（session）內有效 | 持久化 Vector Store（跨對話） |
| 上傳方式 | 即時動態上傳（對話中） | 預先建立索引（部署前） |
| 語意搜尋 | 否（直接引用文件） | 是（向量嵌入語意搜尋） |
| 適合場景 | 使用者即時上傳分析 | 大規模企業知識庫 RAG |

### 使用範例

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

// 建立代理與 Session
AIAgent agent = aiProjectClient.AsAIAgent(
    model: deploymentName,
    name: "DocumentAnalysisAgent",
    instructions: "分析使用者上傳的文件並回答問題。請僅根據文件內容作答。");

AgentSession session = await agent.CreateSessionAsync();

// 上傳文件到工作階段（Session 生命週期內有效）
var sessionFiles = session.Files;
await using var reportStream = File.OpenRead("q2-financial-report.pdf");

var fileRef = await sessionFiles.UploadAsync(
    "q2-financial-report.pdf",
    reportStream,
    contentType: "application/pdf");

// 在訊息中引用已上傳的檔案
var messageWithFile = new ChatMessage(ChatRole.User, "請摘要這份報告的 Q2 營收重點")
{
    Contents = [new FileReferenceContent(fileRef.Id)]
};

AgentResponse response = await agent.RunAsync([messageWithFile], session);
Console.WriteLine(response.Text);

// 同一個 session 後續的對話也可以繼續引用同一個 fileRef
var followUp = await agent.RunAsync(
    "這份報告的成本結構有什麼值得注意的趨勢？", session);
Console.WriteLine(followUp.Text);
```

> **適用場景建議**：
> - 使用者臨時上傳文件進行一次性分析 → 選擇 `AgentSessionFiles`
> - 企業內部知識庫、產品文件、FAQ 等持久化內容 → 選擇 `HostedFileSearchTool` + Vector Store

---

> **返回目錄**：[README](README.md) | **上一章**：[07 — 範例實作：Travel Agent](./07-example-travel-agent.md) | **下一章**：[09 — 範例實作：Planning Pattern](./09-example-planning.md)
