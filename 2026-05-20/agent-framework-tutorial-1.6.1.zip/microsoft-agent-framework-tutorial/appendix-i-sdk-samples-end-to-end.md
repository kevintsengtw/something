# 附錄 I — SDK 端對端整合範例（dotnet/samples/05-end-to-end）

> 來源：[microsoft/agent-framework — dotnet/samples/05-end-to-end](https://github.com/microsoft/agent-framework/tree/main/dotnet/samples/05-end-to-end)
> 版本基準：v1.6.1

`05-end-to-end` 包含 9 個完整的端對端整合場景，每個範例都是可運行的完整應用，展示代理框架如何與真實的客戶端（Web UI / CLI / M365）和協定（A2A / AG-UI）整合。

---

## 目錄總覽

| 子目錄 | 整合類型 | 說明 |
|--------|---------|------|
| `A2AClientServer/` | A2A 協定 | 三個 A2A 伺服器（Invoice / Policy / Logistics） + CLI 客戶端 |
| `AGUIClientServer/` | AG-UI 協定 | AG-UI 伺服器 + 客戶端（含 Dojo 示範伺服器） |
| `AGUIWebChat/` | AG-UI 協定 | 完整網頁聊天 UI（Vue.js + AG-UI） |
| `AgentWebChat/` | Web API | 代理後端 + 簡易網頁 Chat UI |
| `AgentWithPurview/` | Azure Purview | 代理整合 Azure 資料治理 / DLP |
| `AspNetAgentAuthorization/` | ASP.NET Core | 代理端點的認證與授權配置 |
| `DevUIAspireIntegration/` | .NET Aspire | Dev UI 與 Aspire Dashboard 分散式追蹤整合 |
| `Evaluation/` | 評測 | 端對端代理系統評測場景 |
| `M365Agent/` | Microsoft 365 | Teams / Copilot 整合 |

---

## A2AClientServer — 多代理 A2A 完整示範

> 對應教學：[第 23 章](./23-a2a-protocol.md)

這是最完整的 A2A 示範：三個扮演不同角色的代理以 A2A 協定互連，一個 CLI 客戶端透過 A2A 呼叫它們。

### 架構

```
A2AClient（CLI）
    ↕ A2A Protocol（HTTP / JSON-RPC）
    ├── A2AServer（:5000）— InvoiceAgent：處理發票相關查詢
    ├── A2AServer（:5001）— PolicyAgent：處理政策合規查詢
    └── A2AServer（:5002）— LogisticsAgent：處理物流相關查詢
```

### 啟動三個伺服器

```bash
# 設定 OpenAI API Key
$env:OPENAI_API_KEY="sk-..."

# 伺服器 1：Invoice 代理
cd A2AServer
dotnet run --urls "http://localhost:5000" --agentType "invoice"

# 伺服器 2：Policy 代理（另一個終端）
dotnet run --urls "http://localhost:5001" --agentType "policy"

# 伺服器 3：Logistics 代理（另一個終端）
dotnet run --urls "http://localhost:5002" --agentType "logistics"
```

### 啟動 A2A 客戶端

```bash
cd A2AClient
dotnet run --serverUrls "http://localhost:5000,http://localhost:5001,http://localhost:5002"
```

### 客戶端連線到多個 A2A 伺服器

```csharp
// A2AClient：從代理卡自動探索每個代理的能力
var agentCards = await Task.WhenAll(serverUrls.Select(
    url => A2ACardResolver.ResolveAsync(new Uri(url))));

// 將每個遠端代理的 Skill 轉為可呼叫的工具
var allTools = agentCards
    .SelectMany(card => card.Skills
        .Select(skill => A2AClientFunctionFactory.Create(skill, a2aClient)))
    .ToList();

// 本地 Orchestrator 代理：根據使用者問題決定呼叫哪個遠端代理
AIAgent orchestrator = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Instructions = "你是一個路由助理，請根據問題呼叫最合適的專業代理。",
    Tools = allTools,
});

// 使用者提問，Orchestrator 自動路由到正確的遠端代理
var session = await orchestrator.CreateSessionAsync();
Console.WriteLine(await orchestrator.RunAsync("我的第 INV-2024-001 號發票狀態如何？", session));
Console.WriteLine(await orchestrator.RunAsync("出貨包裹 PKG-789 現在在哪裡？", session));
```

### 使用 Azure AI Foundry 代理

除了標準 OpenAI 代理，此範例也支援 Foundry 代理：

```bash
# 在 Foundry 中預先建立三個代理，取得其 Agent ID
$env:AZURE_AI_PROJECT_ENDPOINT="https://your-project.services.ai.azure.com/api/projects/..."
$env:INVOICE_AGENT_ID="asst_xxx"
$env:POLICY_AGENT_ID="asst_yyy"
$env:LOGISTICS_AGENT_ID="asst_zzz"

dotnet run --agentType "invoice" --useFoundry
```

---

## AGUIClientServer — AG-UI 完整示範

> 對應教學：[第 24 章](./24-agui-protocol-deep-dive.md)

```
AGUIClientServer/
├── AGUIClient/      ← console / SDK 客戶端
├── AGUIServer/      ← 一般 AG-UI 伺服器
└── AGUIDojoServer/  ← 包含多種代理類型的示範伺服器
```

### AGUIServer — 建立 AG-UI 伺服器

```csharp
// ASP.NET Core + AG-UI 路由設定
var app = builder.Build();

// MapAGUI：將代理公開為 AG-UI SSE 端點
app.MapAGUI("/agent", agent);
// 客戶端可透過 GET http://localhost:8888/agent 建立 SSE 連線

app.Run("http://localhost:8888");
```

### AGUIClient — AG-UI 客戶端連線

```csharp
// AGUIChatClient 作為 AG-UI 客戶端
var aguiClient = new AGUIChatClient(new Uri("http://localhost:8888/agent"));

string threadId = Guid.NewGuid().ToString();  // 建立新對話 thread

// 串流接收 AG-UI 事件
await foreach (var update in aguiClient.RunStreamingAsync(threadId, "你好！"))
{
    switch (update.EventType)
    {
        case AGUIEventType.TextMessageContent:
            Console.Write(update.Text);        // 即時輸出文字
            break;
        case AGUIEventType.ToolCallStart:
            Console.WriteLine($"\n[呼叫工具: {update.ToolName}]");
            break;
        case AGUIEventType.ToolCallEnd:
            Console.WriteLine($"[工具完成: {update.Result}]");
            break;
        case AGUIEventType.ReasoningChunk:
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write(update.Text);        // 推理過程（灰色顯示）
            Console.ResetColor();
            break;
        case AGUIEventType.RunFinished:
            Console.WriteLine();
            break;
    }
}

// 繼續同一個對話 thread
await foreach (var update in aguiClient.RunStreamingAsync(threadId, "上面說了什麼？"))
    Console.Write(update.Text ?? "");
```

### AGUIDojoServer — 多場景示範伺服器

Dojo 伺服器包含多種代理場景，可用來測試不同類型的 AG-UI 互動（工具呼叫、推理串流、狀態更新等）。

---

## AGUIWebChat — AG-UI 網頁聊天 UI

**目的**：展示如何將 AG-UI 協定整合進完整的 Web 應用，讓終端使用者透過瀏覽器與代理互動。

### 架構

```
Browser（Vue.js）
    ↕ HTTP / SSE（AG-UI Protocol）
ASP.NET Core（AGUIWebChat Server）
    ↕ AsAIAgent()
Azure OpenAI / Foundry
```

### 後端（ASP.NET Core）

```csharp
// Program.cs
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddAIAgent("ChatAgent",
    instructions: "你是一個網頁聊天助理。",
    chatClientFactory: sp => sp.GetRequiredService<IChatClient>());

var app = builder.Build();
app.UseStaticFiles();
app.MapAGUI("/chat/agent", "ChatAgent");  // 公開 AG-UI 端點
app.Run();
```

### 前端（Vue.js）

前端使用 AG-UI JavaScript/TypeScript SDK（`@ag-ui/client`）連接到後端 SSE 端點，即時顯示代理回應、工具呼叫狀態。

---

## AspNetAgentAuthorization — 代理端點的認證授權

**目的**：展示如何在生產環境中為代理端點添加 JWT / Azure AD 認證保護。

```csharp
// 在 ASP.NET Core 中設定代理端點認證
var builder = WebApplication.CreateBuilder(args);

// 加入 Azure AD / Microsoft Entra ID 認證
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"));

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AgentUser", policy =>
        policy.RequireClaim("scp", "Agent.Run"));
});

var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();

// 為代理端點加入認證要求
app.MapAGUI("/secure-agent", agent)
   .RequireAuthorization("AgentUser");
```

**appsettings.json**：

```json
{
  "AzureAd": {
    "Instance": "https://login.microsoftonline.com/",
    "TenantId": "your-tenant-id",
    "ClientId": "your-client-id",
    "Audience": "api://your-client-id"
  }
}
```

---

## DevUIAspireIntegration — Dev UI + .NET Aspire

**目的**：在開發環境中，將代理的 Dev UI 視覺化工具與 .NET Aspire Dashboard 的分散式追蹤整合，在一個介面看到代理行為 + OTel Traces。

### 架構

```
Browser
    ├── Dev UI（:18181）     ← 代理對話視覺化
    └── Aspire Dashboard（:18888）← OTel 分散式追蹤
Agent Service（:5000）
    ├── Dev UI SSE 端點
    └── OTel → OTLP Exporter → Aspire Dashboard
```

```csharp
// 配置 Dev UI + Aspire Dashboard
builder.Services
    .AddAgentFramework(agent)
    .AddDevUI()  // 開啟 Dev UI
    .AddOpenTelemetry()
    .WithTracing(t => t
        .AddAgentFrameworkInstrumentation()
        .AddOtlpExporter(o =>
            o.Endpoint = new Uri("http://localhost:4317")));
```

---

## M365Agent — Microsoft 365 整合

**目的**：將代理整合進 Microsoft Teams / Microsoft Copilot，讓使用者可以在 M365 介面中與代理互動。

```csharp
// Teams Bot Adapter 設定
builder.Services
    .AddSingleton<IBotFrameworkHttpAdapter, AdapterWithErrorHandler>()
    .AddTransient<IBot, TeamsAgentBot>();

// TeamsAgentBot：橋接 Teams 訊息與 AI 代理
public class TeamsAgentBot : ActivityHandler
{
    private readonly AIAgent _agent;

    public TeamsAgentBot(AIAgent agent) => _agent = agent;

    protected override async Task OnMessageActivityAsync(
        ITurnContext<IMessageActivity> turnContext,
        CancellationToken cancellationToken)
    {
        // 從 Teams 活動取得使用者訊息
        var userMessage = turnContext.Activity.Text;

        // 以 Teams 使用者 ID 作為 session key（跨輪對話持久化）
        var sessionKey = turnContext.Activity.From.Id;
        var session = await GetOrCreateSessionAsync(sessionKey);

        // 呼叫代理並將回應回傳給 Teams
        var response = await _agent.RunAsync(userMessage, session);
        await turnContext.SendActivityAsync(MessageFactory.Text(response), cancellationToken);
    }
}
```

**部署到 Teams**：
1. 在 Azure 建立 Bot Registration
2. 在 Teams Developer Portal 建立 App Manifest
3. 設定 `MicrosoftAppId` 和 `MicrosoftAppPassword` 環境變數
4. 部署到 Azure App Service / Azure Functions

---

## Evaluation — 端對端代理評測

> 對應教學：[第 28 章](./28-agent-evaluation.md)

```csharp
// 建立評測資料集
var testCases = new[]
{
    new EvalTestCase
    {
        Input = "What is 2 + 2?",
        ExpectedOutput = "4",
        Tags = ["math", "simple"]
    },
    new EvalTestCase
    {
        Input = "What is the capital of France?",
        ExpectedOutput = "Paris",
        Tags = ["geography"]
    },
};

// 執行評測
var evaluator = new SemanticSimilarityEvaluator(embeddingClient);
var results = await AgentEvaluator.RunAsync(agent, testCases, evaluator);

// 輸出結果
foreach (var result in results)
    Console.WriteLine($"[{(result.Passed ? "✓" : "✗")}] {result.Input}: {result.Score:F2}");

Console.WriteLine($"\n整體通過率：{results.PassRate:P1}");
```

---

## 場景選擇指南

| 需求 | 推薦範例 |
|------|---------|
| 多個後端 AI 代理互相協作 | `A2AClientServer` |
| Web 應用整合 + SSE 串流 | `AGUIClientServer` / `AGUIWebChat` |
| 代理整合進 Teams | `M365Agent` |
| 生產環境認證保護 | `AspNetAgentAuthorization` |
| 開發期間視覺化 + OTel | `DevUIAspireIntegration` |
| 系統級評測 | `Evaluation` |

---

> **返回目錄**：[README](README.md) | **上一篇**：[附錄 H — SDK 代理主機整合](./appendix-h-sdk-samples-hosting.md)
