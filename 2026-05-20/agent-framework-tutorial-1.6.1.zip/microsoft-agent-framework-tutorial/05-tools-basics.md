# 05 — 工具（Tools）基礎

> 本章介紹如何賦予代理「做事」的能力。透過工具（Tools），代理不再只是聊天，還能查詢資料、呼叫 API、執行運算等實際操作。
>
> 對應官方範例：[Agent-Framework-Samples/00.ForBeginners/ToolUse](https://github.com/microsoft/Agent-Framework-Samples/tree/main/00.ForBeginners)

---

## 為什麼代理需要工具

一個沒有工具的代理，只能根據訓練資料回答問題。它無法：

- 查詢即時天氣
- 存取你的資料庫
- 呼叫第三方 API
- 執行計算或處理檔案

**工具讓代理從「只會說話」變成「能做事」。** 你可以把工具想像成代理的「手」— 它用 LLM 的「大腦」決定該做什麼，再用工具的「手」去執行。

---

## 工具呼叫的運作原理

當你為代理註冊工具後，整個流程如下：

```mermaid
sequenceDiagram
    participant User as 使用者
    participant Agent as AIAgent
    participant LLM as LLM
    participant Tool as 工具方法

    User->>Agent: 發送訊息
    Agent->>LLM: 傳送訊息 + 可用工具清單

    alt LLM 判斷需要呼叫工具
        LLM-->>Agent: 回傳工具呼叫請求（函式名稱 + 參數）
        Agent->>Tool: 執行工具方法
        Tool-->>Agent: 回傳執行結果
        Agent->>LLM: 傳送工具執行結果
        LLM-->>Agent: 根據結果生成最終回應
    else LLM 判斷不需要工具
        LLM-->>Agent: 直接回傳文字回應
    end

    Agent-->>User: 回傳代理回應
```

重要的是：**LLM 自行判斷是否需要呼叫工具、呼叫哪個工具、傳入什麼參數。** 開發者只需定義工具，不需要撰寫判斷邏輯。

---

## 使用 AIFunctionFactory 建立工具

`AIFunctionFactory` 是 Agent Framework 中將 C# 方法轉換為代理工具的核心類別，位於 `Microsoft.Extensions.AI` 命名空間。

### 最簡單的工具

```csharp
using Microsoft.Extensions.AI;
using System.ComponentModel;

// 定義一個工具方法
[Description("取得指定城市的目前天氣資訊")]
static string GetWeather(
    [Description("城市名稱，例如 '台北'")] string city)
{
    // 實際應用中，這裡會呼叫天氣 API
    return $"{city}：晴天，氣溫 28°C，濕度 65%";
}

// 將 C# 方法轉換為 AIFunction
AIFunction weatherTool = AIFunctionFactory.Create(GetWeather);
```

### Description 屬性的重要性

`[Description]` 屬性對於工具的正確運作**非常重要**。LLM 依賴這些描述來理解：

- **方法上的 `[Description]`**：告訴 LLM 這個工具「做什麼」
- **參數上的 `[Description]`**：告訴 LLM 每個參數「是什麼」

```csharp
// ❌ 缺乏描述 — LLM 可能誤解工具用途
static string GetWeather(string city) => $"天氣：{city}";

// ✅ 清晰的描述 — LLM 能準確判斷何時呼叫
[Description("取得指定城市的即時天氣資訊，包含溫度、濕度和天氣狀況")]
static string GetWeather(
    [Description("城市名稱，例如 '台北'、'東京'、'紐約'")] string city)
{
    return $"{city}：晴天，氣溫 28°C";
}
```

描述會被轉換為 JSON Schema，隨著每次 LLM 請求一起傳送。好的描述能大幅提高工具被正確呼叫的機率。

---

## 將工具註冊到代理

### 在建立時註冊（推薦）

最常見的方式是在建立代理時直接傳入工具：

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using OpenAI;
using System.ComponentModel;

// 定義工具
[Description("取得指定城市的天氣")]
static string GetWeather(
    [Description("城市名稱")] string city)
    => $"{city}：晴天，28°C";

[Description("取得目前的日期與時間")]
static string GetCurrentDateTime()
    => DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

// 建立代理並註冊工具
var agent = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o-mini")
    .AsAIAgent(
        name: "WeatherBot",
        instructions: "你是一個天氣查詢助理，請用繁體中文回答。",
        tools: [
            AIFunctionFactory.Create(GetWeather),
            AIFunctionFactory.Create(GetCurrentDateTime)
        ]
    );

// 代理會自動判斷是否需要呼叫工具
var response = await agent.RunAsync("台北現在幾度？");
Console.WriteLine(response.Text);
// 輸出範例：根據查詢結果，台北目前天氣晴朗，氣溫約 28°C。
```

### 在執行時動態註冊

有時你需要在不同的呼叫中提供不同的工具。可以使用 `ChatClientAgentRunOptions`：

```csharp
// 額外的工具，只在特定呼叫中使用
[Description("搜尋航班資訊")]
static string SearchFlights(
    [Description("出發城市")] string from,
    [Description("目的地城市")] string to,
    [Description("出發日期，格式 yyyy-MM-dd")] string date)
    => $"找到 {from} → {to} 的航班（{date}）：早上 08:00，票價 NT$8,500";

// 建立執行時期的 ChatOptions
var chatOptions = new ChatOptions
{
    Tools = [AIFunctionFactory.Create(SearchFlights)]
};

// 在特定呼叫中使用額外工具
var response = await agent.RunAsync(
    "幫我查從台北到東京明天的航班",
    options: new ChatClientAgentRunOptions(chatOptions)
);
```

Per-run 工具會與建構時的工具合併，讓代理在該次呼叫中可以使用所有工具。

---

## 支援的方法類型

`AIFunctionFactory.Create()` 支援多種 C# 方法形式，幾乎所有你熟悉的寫法都能使用。

### 靜態方法（Static Methods）

```csharp
[Description("計算兩數之和")]
static int Add(
    [Description("第一個數字")] int a,
    [Description("第二個數字")] int b)
    => a + b;

var tool = AIFunctionFactory.Create(Add);
```

### 實例方法（Instance Methods）

```csharp
public class WeatherService
{
    private readonly HttpClient _httpClient;

    public WeatherService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    [Description("取得天氣資訊")]
    public async Task<string> GetWeatherAsync(
        [Description("城市名稱")] string city)
    {
        // 使用 HttpClient 呼叫外部 API
        var result = await _httpClient.GetStringAsync($"https://api.weather.example/{city}");
        return result;
    }
}

// 建立實例並將實例方法轉為工具
var service = new WeatherService(new HttpClient());
var tool = AIFunctionFactory.Create(service.GetWeatherAsync);
```

### Lambda 運算式

```csharp
var tool = AIFunctionFactory.Create(
    [Description("取得隨機數字")]
    ([Description("最小值")] int min, [Description("最大值")] int max)
        => Random.Shared.Next(min, max)
);
```

### 區域函式（Local Functions）

```csharp
[Description("將攝氏轉換為華氏")]
static double CelsiusToFahrenheit(
    [Description("攝氏溫度")] double celsius)
    => celsius * 9.0 / 5.0 + 32.0;

var tool = AIFunctionFactory.Create(CelsiusToFahrenheit);
```

### 非同步方法（Async Methods）

非同步方法是實際應用中最常見的形式，因為工具通常需要進行 I/O 操作：

```csharp
[Description("從資料庫查詢客戶資訊")]
static async Task<string> GetCustomerInfoAsync(
    [Description("客戶 ID")] string customerId)
{
    // 模擬非同步資料庫查詢
    await Task.Delay(100);
    return $"客戶 {customerId}：王小明，VIP 會員，累積消費 NT$50,000";
}

// Task<T> 和 ValueTask<T> 都支援
[Description("檢查庫存")]
static async ValueTask<string> CheckInventoryAsync(
    [Description("產品編號")] string productId)
{
    await Task.Delay(50);
    return $"產品 {productId}：庫存 42 件";
}

var tools = new[]
{
    AIFunctionFactory.Create(GetCustomerInfoAsync),
    AIFunctionFactory.Create(CheckInventoryAsync)
};
```

---

## 參數型別支援

`AIFunctionFactory` 會自動將 C# 型別轉換為 JSON Schema，LLM 根據 Schema 來傳入正確的參數值。

### 常見的參數型別

```csharp
[Description("建立訂單")]
static string CreateOrder(
    [Description("客戶名稱")] string customerName,       // string
    [Description("訂單金額")] decimal amount,              // decimal/double/int
    [Description("是否為急件")] bool isUrgent,             // bool
    [Description("預計出貨日期")] DateTime shipDate)       // DateTime
{
    return $"訂單已建立：{customerName}，金額 {amount:C}，急件：{isUrgent}";
}
```

### 選擇性參數（Optional Parameters）

```csharp
[Description("搜尋產品")]
static string SearchProducts(
    [Description("搜尋關鍵字")] string keyword,
    [Description("價格上限（選填）")] decimal? maxPrice = null,
    [Description("排序方式：'price' 或 'name'，預設 'name'")] string sortBy = "name")
{
    var result = $"搜尋 '{keyword}'";
    if (maxPrice.HasValue)
        result += $"，價格上限 {maxPrice:C}";
    result += $"，排序：{sortBy}";
    return result;
}
```

### 列舉型別（Enum）

```csharp
public enum TicketPriority
{
    Low,
    Medium,
    High,
    Critical
}

[Description("建立支援工單")]
static string CreateTicket(
    [Description("工單標題")] string title,
    [Description("優先等級")] TicketPriority priority)
{
    return $"工單已建立：{title}（優先等級：{priority}）";
}
```

---

## 內建工具類型

除了自訂工具，Agent Framework 也支援 Azure AI Foundry 提供的內建工具。這些工具在雲端環境中執行，不需要你自行實作。

| 內建工具 | 功能 | 適用場景 |
|----------|------|----------|
| **Code Interpreter** | 在沙箱中執行 Python 程式碼 | 數據分析、數學計算、圖表生成 |
| **File Search** | 對上傳文件進行向量搜尋 | 文件問答、知識庫查詢 |
| **Bing Grounding** | 即時網路搜尋 | 取得最新資訊、事實查核 |

這些內建工具需要搭配 Azure AI Foundry 使用，詳細用法會在後續的範例實作章節中介紹。

---

## 工具呼叫的生命週期

了解工具呼叫的內部流程，有助於除錯和設計更好的工具：

```mermaid
flowchart TD
    A["使用者發送訊息"] --> B["Agent 組合請求"]
    B --> C["發送至 LLM\n（訊息 + 工具 JSON Schema）"]
    C --> D{LLM 回應}

    D -->|"需要呼叫工具"| E["解析工具呼叫\n（函式名稱 + 參數）"]
    D -->|"不需要工具"| H["回傳文字回應"]

    E --> F["執行 C# 方法"]
    F --> G["將結果加入對話"]
    G --> C

    style A fill:#E8F0FE,stroke:#4A90D9,color:#333
    style F fill:#D4EDDA,stroke:#28A745,color:#333
    style H fill:#FFF3CD,stroke:#FFC107,color:#333
```

關鍵重點：

- **迴圈機制**：如果 LLM 呼叫工具後還需要更多資訊，它可以在同一次請求中再次呼叫工具，形成多輪的工具呼叫迴圈
- **自動參數綁定**：框架會自動將 LLM 回傳的 JSON 參數綁定到 C# 方法的參數
- **結果回傳**：工具的回傳值（`string`、`int` 等）會被轉換為文字，加入對話脈絡中

---

## 完整範例：多工具的智慧助理

以下是一個整合多個工具的完整範例：

```csharp
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using OpenAI;
using System.ComponentModel;

var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY")
    ?? throw new InvalidOperationException("請設定 OPENAI_API_KEY 環境變數");

// ============================================================
// 定義工具
// ============================================================

[Description("取得指定城市的目前天氣資訊")]
static string GetWeather(
    [Description("城市名稱，例如 '台北'、'東京'")] string city)
{
    // 模擬天氣 API 回應
    var weatherData = new Dictionary<string, string>
    {
        ["台北"] = "多雲，28°C，濕度 75%",
        ["東京"] = "晴天，22°C，濕度 50%",
        ["紐約"] = "陰天，15°C，濕度 60%",
    };

    return weatherData.TryGetValue(city, out var weather)
        ? $"{city}：{weather}"
        : $"{city}：無法取得天氣資訊，請確認城市名稱";
}

[Description("取得目前的日期與時間")]
static string GetCurrentDateTime()
    => $"目前時間：{DateTime.Now:yyyy年MM月dd日 HH:mm}（台灣時間）";

[Description("計算兩個城市之間的飛行時間（預估）")]
static string GetFlightDuration(
    [Description("出發城市")] string from,
    [Description("目的地城市")] string to)
{
    var routes = new Dictionary<string, string>
    {
        ["台北-東京"] = "約 3 小時",
        ["台北-紐約"] = "約 15 小時（含轉機）",
        ["東京-紐約"] = "約 13 小時",
    };

    var key = $"{from}-{to}";
    var reverseKey = $"{to}-{from}";

    if (routes.TryGetValue(key, out var duration))
        return $"{from} → {to}：{duration}";
    if (routes.TryGetValue(reverseKey, out duration))
        return $"{from} → {to}：{duration}";

    return $"找不到 {from} 到 {to} 的航線資訊";
}

[Description("將新台幣金額轉換為其他幣別")]
static string ConvertCurrency(
    [Description("新台幣金額")] decimal amount,
    [Description("目標幣別代碼，例如 'JPY'、'USD'")] string targetCurrency)
{
    var rates = new Dictionary<string, decimal>
    {
        ["JPY"] = 4.5m,
        ["USD"] = 0.032m,
        ["EUR"] = 0.029m,
        ["KRW"] = 42.5m,
    };

    if (rates.TryGetValue(targetCurrency.ToUpper(), out var rate))
    {
        var converted = amount * rate;
        return $"NT${amount:N0} = {converted:N2} {targetCurrency.ToUpper()}";
    }

    return $"不支援的幣別：{targetCurrency}";
}

// ============================================================
// 建立代理
// ============================================================

var agent = new OpenAIClient(apiKey)
    .GetChatClient("gpt-4o-mini")
    .AsAIAgent(
        name: "TravelHelper",
        instructions: """
            你是一個旅行規劃助理，專門服務台灣的旅客。
            請用繁體中文回答所有問題。
            善用你的工具來提供準確的資訊。
            如果使用者的問題超出你工具的能力範圍，誠實告知。
            """,
        tools: [
            AIFunctionFactory.Create(GetWeather),
            AIFunctionFactory.Create(GetCurrentDateTime),
            AIFunctionFactory.Create(GetFlightDuration),
            AIFunctionFactory.Create(ConvertCurrency)
        ]
    );

// ============================================================
// 互動式對話
// ============================================================

var session = await agent.CreateSessionAsync();

Console.WriteLine("=== 旅行助理 ===");
Console.WriteLine("我可以幫你查天氣、航班時間、匯率等資訊。");
Console.WriteLine("輸入 'exit' 結束對話\n");

while (true)
{
    Console.Write("你：");
    var input = Console.ReadLine();

    if (string.IsNullOrWhiteSpace(input) || input.Equals("exit", StringComparison.OrdinalIgnoreCase))
        break;

    Console.Write("助理：");
    await foreach (var update in agent.RunStreamingAsync(input, session))
    {
        Console.Write(update.Text);
    }
    Console.WriteLine("\n");
}
```

### 對話示範

```
你：我想下週去東京，那邊天氣怎麼樣？
助理：根據查詢結果，東京目前天氣晴朗，氣溫約 22°C，濕度 50%，非常舒適！
      下週的天氣可能會有些變化，建議你出發前再查看一下最新的天氣預報。

你：從台北飛過去要多久？
助理：從台北飛到東京大約需要 3 小時。

你：我準備帶三萬塊台幣去，換成日幣大概多少？
助理：NT$30,000 大約可以換到 135,000 日幣。
      建議在出發前比較一下銀行和機場的匯率，選擇較優惠的方式兌換。

你：現在幾點了？
助理：目前時間是 2026年03月28日 15:30（台灣時間）。
```

注意代理如何自動判斷使用不同的工具來回答不同的問題，完全不需要你寫任何判斷邏輯。

---

## 工具設計的最佳實踐

### 命名與描述

- 方法名稱使用**動詞開頭**，清楚表達動作：`GetWeather`、`SearchFlights`、`CreateOrder`
- Description 要**具體且完整**，包含使用情境和範例值
- 參數 Description 要說明**格式與範圍**

### 職責單一

每個工具只做一件事：

```csharp
// ❌ 一個工具做太多事
[Description("取得天氣、航班和匯率")]
static string GetTravelInfo(string city, string date, decimal amount) { ... }

// ✅ 拆成獨立的工具
[Description("取得天氣")] static string GetWeather(string city) { ... }
[Description("搜尋航班")] static string SearchFlights(string from, string to) { ... }
[Description("換算匯率")] static string ConvertCurrency(decimal amount, string currency) { ... }
```

### 回傳有意義的資訊

工具的回傳值會被 LLM 用來生成回應，確保回傳值包含足夠的資訊：

```csharp
// ❌ 回傳值資訊不足
static string GetWeather(string city) => "28";

// ✅ 回傳結構化的資訊
static string GetWeather(string city)
    => $"{city}：晴天，氣溫 28°C，濕度 65%，紫外線指數中等";
```

### 錯誤處理

工具應該優雅地處理錯誤，回傳有意義的錯誤訊息而非拋出例外：

```csharp
[Description("查詢股票價格")]
static string GetStockPrice(
    [Description("股票代碼")] string symbol)
{
    try
    {
        // 查詢邏輯...
        return $"{symbol}：NT$150.50（+2.3%）";
    }
    catch (Exception ex)
    {
        // 回傳錯誤訊息，讓 LLM 能適當地回覆使用者
        return $"無法查詢 {symbol} 的股價：{ex.Message}";
    }
}
```

---

## 小結

本章你學會了：

- 工具呼叫的運作原理（LLM 自動判斷、框架自動執行）
- 使用 `AIFunctionFactory.Create()` 將 C# 方法轉換為工具
- `[Description]` 屬性對工具正確運作的重要性
- 支援的各種方法類型（靜態、實例、Lambda、非同步）
- 在建構時與執行時註冊工具的差異
- 內建工具類型簡介
- 工具設計的最佳實踐

下一章將介紹 Middleware 與 Context Providers，學習如何攔截代理行為並動態注入上下文資訊。

---

## 延伸閱讀：Agent Skills（v1.1.0 新增）

Agent Skills 是 v1.1.0 GA 的技能系統，將工具、資源與腳本打包為可攜式套件，讓代理透過漸進式揭露按需載入。支援三種定義方式：**類別式**（`AgentClassSkill<T>`）、**內聯式**（`AgentInlineSkill`）、**檔案式**（SKILL.md 目錄）。

完整說明請見 → **[第 29 章：Agent Skills 可攜式技能套件](./29-agent-skills.md)**

## 延伸閱讀：Dynamic Tool Expansion（v1.3.0 新模式）

🆕 v1.3.0 新增官方範例 `02-agents/DynamicToolExpansion`，示範**動態工具擴展**設計模式：代理在執行過程中透過一個工具呼叫，讓另一個工具動態加入可用工具清單。

適合場景：代理一開始只知道少數工具，執行期間根據脈絡決定是否「解鎖」更多工具（例如：使用者通過驗證後才暴露管理工具）。

```csharp
// 核心概念：工具本身回傳更多工具的描述
[Description("取得進階工具清單（需先完成身份驗證）")]
static IEnumerable<AIFunction> GetAdvancedTools(
    [Description("驗證 token")] string authToken)
{
    if (authToken != "valid-token")
        return [];

    // 驗證通過後，動態回傳額外工具
    return [
        AIFunctionFactory.Create(DeleteRecord),
        AIFunctionFactory.Create(ExportData)
    ];
}

// 代理建立時只有基本工具 + 工具擴展器
var agent = chatClient.AsAIAgent(
    instructions: "你是一個資料管理助理",
    tools: [
        AIFunctionFactory.Create(ReadData),          // 基本工具
        AIFunctionFactory.Create(GetAdvancedTools)   // 擴展器
    ]);
```

詳細實作可參考官方範例：`Agent-Framework-Samples/02-agents/DynamicToolExpansion`

## v1.6.1 新增：Shell Tool（本地 Shell 命令工具）

> 🆕 **v1.6.1 新增**：`ShellTool` 讓代理可以執行本地 shell 命令作為工具呼叫，適用於受控環境的系統自動化場景。

```csharp
using Microsoft.Agents.AI;

// 啟用 Shell Tool（允許代理執行 shell 命令）
AIAgent agent = chatClient.AsAIAgent(new ChatClientAgentOptions
{
    Name = "DevOpsAgent",
    Instructions = "你是一個 DevOps 助理，可以執行 shell 命令協助系統維護。",
    Tools = [new ShellTool()],
});

// 代理可以自行判斷並執行適當的命令
var response = await agent.RunAsync("檢查磁碟使用量並列出前 5 個最大的目錄");
Console.WriteLine(response.Text);
```

> ⚠️ **安全警告**：`ShellTool` 允許代理執行任意 shell 命令，存在**命令注入**的安全風險。請僅在以下情況啟用：
> - **受控環境**：Hyperlight 沙盒、Docker 容器等隔離環境
> - **受信任部署**：代理輸入來源完全受控、無法被外部使用者操控
> - **最小化暴露**：優先評估是否能以限定範圍的自訂工具替代
>
> 生產環境建議用有限範圍的自訂工具（如只暴露特定的讀取操作），而非通用的 `ShellTool`。

---

> **返回目錄**：[README](README.md) | **上一章**：[04 — 建立你的第一個 Agent](./04-first-agent.md) | **下一章**：[06 — Middleware 與 Context 基礎](./06-middleware-and-context.md)
