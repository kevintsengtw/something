# 24 — AG-UI Protocol 深度

> 本章深入 AG-UI（Agent User Interaction）協定的完整功能集。AG-UI 是 Agent Framework 推動的前後端互動標準，基於 **Server-Sent Events（SSE）** 的串流架構，支援後端工具呼叫、前端工具呈現、Human-in-the-Loop 確認流程、以及共享狀態同步（State Management）。掌握 AG-UI 讓你建立能與任何 AG-UI 相容前端（如 CopilotKit）無縫整合的代理服務。

---

## AG-UI 的核心定位

在 Agent Framework 的協定層中，AG-UI 專注於**代理與使用者介面的互動**：

```
前端應用（React / Vue / CopilotKit）
    ↕  AG-UI（SSE 串流）
後端 AIAgent（ASP.NET Core）
    ↕  A2A 或直接呼叫
其他代理 / 工具
```

AG-UI 解決了傳統 REST API 模式難以處理的幾個問題：
- **串流輸出**：代理的回應字元逐步傳到前端，使用者不需要等待完整回應
- **前端工具呼叫**：代理可以請求前端執行操作（如開啟對話框、收集使用者輸入）
- **雙向狀態同步**：代理與前端共享同一份狀態物件，任一方更新後另一方自動同步

---

## Step 1：基礎 AG-UI 伺服器

### 安裝套件

```bash
dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.Hosting.AGUI.AspNetCore
dotnet add package Azure.AI.OpenAI
dotnet add package Azure.Identity
```

### 最簡單的 AG-UI 服務端

```csharp
using Azure.AI.OpenAI;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Hosting.AGUI.AspNetCore;

WebApplicationBuilder builder = WebApplication.CreateBuilder(args);
builder.Services.AddHttpClient().AddLogging();
builder.Services.AddAGUI();    // ← 註冊 AG-UI 必要服務

WebApplication app = builder.Build();

string endpoint = builder.Configuration["AZURE_OPENAI_ENDPOINT"]!;
string deploymentName = builder.Configuration["AZURE_OPENAI_DEPLOYMENT_NAME"] ?? "gpt-4o-mini";

AIAgent agent = new AzureOpenAIClient(new Uri(endpoint), new DefaultAzureCredential())
    .GetChatClient(deploymentName)
    .AsAIAgent(
        name:         "AGUIAssistant",
        instructions: "你是一個友善的助理。");

// 掛載 AG-UI 端點（根路徑）
// POST / → 開始對話
// SSE 串流回應
app.MapAGUIAgent("/", agent);

await app.RunAsync();
```

前端連線方式（以 fetch 為例）：

```javascript
const response = await fetch('http://localhost:5000/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        messages: [{ role: 'user', content: '你好！' }],
        thread_id: 'my-session-123'
    })
});

const reader = response.body.getReader();
const decoder = new TextDecoder();
while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    console.log(decoder.decode(value));  // SSE 事件串流
}
```

---

## Step 2：後端工具（Backend Tools）

後端工具是代理可以呼叫的普通 `AIFunction`，執行結果完全在伺服器端完成，前端只看到最終的文字回應：

```csharp
using System.ComponentModel;
using Microsoft.Extensions.AI;

// 定義後端工具
[Description("搜尋指定城市的餐廳")]
static RestaurantSearchResult SearchRestaurants(
    [Description("搜尋條件")] RestaurantSearchRequest request)
{
    // 連結真實資料庫或外部 API
    return new RestaurantSearchResult
    {
        Location = request.Location,
        Results  =
        [
            new() { Name = "老王牛肉麵", Cuisine = "台灣", Rating = 4.8 },
            new() { Name = "翠苑日式料理", Cuisine = "日式", Rating = 4.6 },
        ]
    };
}

// 建立代理時加入工具
var jsonOptions = app.Services
    .GetRequiredService<IOptions<Microsoft.AspNetCore.Http.Json.JsonOptions>>()
    .Value;

AITool[] tools =
[
    AIFunctionFactory.Create(
        SearchRestaurants,
        serializerOptions: jsonOptions.SerializerOptions)  // ← 用 ASP.NET Core 設定的序列化器
];

AIAgent agent = chatClient.AsAIAgent(
    name:         "RestaurantAgent",
    instructions: "你是美食推薦助理，可以搜尋餐廳資訊。",
    tools:        tools);

app.MapAGUIAgent("/", agent);
```

> **重要**：AG-UI 端點使用的 JSON 序列化選項必須與 `builder.Services.ConfigureHttpJsonOptions()` 保持一致，否則自訂型別可能無法正確序列化。建議從 DI 取出已設定好的 `IOptions<JsonOptions>` 再傳入 `AIFunctionFactory.Create()`。

---

## Step 3：前端工具（Frontend Tools）

前端工具讓代理可以**委託前端執行操作**——代理決定何時觸發，但實際執行由前端 JavaScript 完成。典型用途：開啟地圖選取位置、顯示日曆選擇器、執行瀏覽器操作。

前端工具目前主要透過 **CopilotKit** 的 `useCopilotAction` 實作。

### 前端（React + CopilotKit）

```tsx
import { useCopilotAction } from '@copilotkit/react-core';

// 在前端定義「地圖標記」工具
useCopilotAction({
    name: 'mark_location_on_map',
    description: '在地圖上標記指定座標，並讓使用者確認位置',
    parameters: [
        { name: 'latitude',  type: 'number', description: '緯度' },
        { name: 'longitude', type: 'number', description: '經度' },
        { name: 'label',     type: 'string', description: '地點名稱' },
    ],
    handler: async ({ latitude, longitude, label }) => {
        // 在 React 元件中執行地圖操作
        mapRef.current?.flyTo({ center: [longitude, latitude], zoom: 15 });
        mapRef.current?.addMarker(latitude, longitude, label);
        return `已在地圖上標記：${label}`;
    }
});
```

### 後端：代理不需要特別設定

後端代理不需要知道前端工具的細節。CopilotKit 會在初始化時將前端工具的定義傳送給後端，代理的 LLM 就能在需要時呼叫它們。

---

## Step 4：Human-in-the-Loop（ApprovalRequiredAIFunction）

AG-UI 的 Human-in-the-Loop 讓代理在執行某些**高影響力操作**前暫停，等待使用者在 UI 上點擊確認或拒絕。

### 後端：宣告需要確認的工具

```csharp
using Microsoft.Extensions.AI;

// 定義需要人工確認的工具
[Description("核准費用申請單")]
static string ApproveExpenseReport(string expenseReportId)
    => $"費用申請單 {expenseReportId} 已核准";

// 用 ApprovalRequiredAIFunction 包裝
#pragma warning disable MEAI001
AITool approvalTool = new ApprovalRequiredAIFunction(
    AIFunctionFactory.Create(ApproveExpenseReport));
#pragma warning restore MEAI001

AIAgent baseAgent = chatClient.AsAIAgent(
    name:         "ExpenseAgent",
    instructions: "你是費用管理助理，負責審查和核准費用申請。",
    tools:        [approvalTool]);

// 包裝成 ServerFunctionApprovalAgent（處理 AG-UI 確認訊息的交互）
var agent = new ServerFunctionApprovalAgent(baseAgent, jsonOptions.SerializerOptions);

app.MapAGUIAgent("/", agent);
```

### 前端（CopilotKit）

CopilotKit 會自動偵測 `FunctionApprovalRequestContent` 事件，並在 UI 上呈現確認對話框：

```tsx
import { CopilotChat } from '@copilotkit/react-ui';

// CopilotChat 自動處理 Human-in-the-Loop 的 UI 呈現
// 當代理呼叫 ApprovalRequiredAIFunction 時，
// 前端會顯示「確認」/「拒絕」按鈕
<CopilotChat
    labels={{
        title: "費用審核助理",
        initial: "你好！我是費用審核助理。",
    }}
/>
```

### 呼叫流程

```
使用者：「請核准費用申請單 EXP-2024-001」
    ↓
代理決定呼叫 ApproveExpenseReport
    ↓
框架發送 FunctionApprovalRequestContent（SSE 事件）
    ↓
前端顯示確認對話框
    ↓
使用者點擊「確認」
    ↓
前端傳送 FunctionApprovalResponseContent（已批准）
    ↓
代理繼續執行 ApproveExpenseReport
    ↓
回應：「費用申請單 EXP-2024-001 已核准」
```

---

## Step 5：State Management（共享狀態同步）

AG-UI 的 State Management 讓代理與前端共享同一份狀態物件，並在代理生成 State Snapshot 時自動同步到前端。

### 典型應用：食譜助理

使用者輸入「給我一個義大利麵食譜」，代理除了回覆文字外，還更新一個結構化的食譜狀態物件，前端即時渲染成美觀的卡片。

### 後端：SharedStateAgent 中介層

```csharp
using System.Text.Json;
using Microsoft.Agents.AI;

// 共享狀態的型別定義
public record Recipe
{
    public string Title           { get; init; } = "";
    public string Cuisine         { get; init; } = "";
    public string[] Ingredients   { get; init; } = [];
    public string[] Steps         { get; init; } = [];
    public int PrepTimeMinutes    { get; init; }
    public int CookTimeMinutes    { get; init; }
    public string SkillLevel      { get; init; } = "beginner";
}

// 建立代理，指令中明確說明狀態格式
AIAgent baseAgent = chatClient.AsAIAgent(
    name: "RecipeAgent",
    instructions:
        """
        你是食譜助理。當使用者詢問食譜時，回應一個包含 recipe 物件的 AgentState JSON：
        - recipe.title: 食譜名稱
        - recipe.cuisine: 料理類型（如：義式、日式、台灣）
        - recipe.ingredients: 食材陣列（含份量）
        - recipe.steps: 烹飪步驟陣列
        - recipe.prep_time_minutes: 備料時間（分鐘）
        - recipe.cook_time_minutes: 烹飪時間（分鐘）
        - recipe.skill_level: 難度（beginner / intermediate / advanced）
        務必包含所有欄位。
        """);

// 包裝成 SharedStateAgent（處理狀態快照的產生與傳送）
var agent = new SharedStateAgent(baseAgent, jsonOptions.SerializerOptions);
app.MapAGUIAgent("/", agent);
```

### 前端（CopilotKit）：接收並渲染狀態

```tsx
import { useCoAgent } from '@copilotkit/react-core';

interface RecipeState {
    recipe?: {
        title:             string;
        cuisine:           string;
        ingredients:       string[];
        steps:             string[];
        prep_time_minutes: number;
        cook_time_minutes: number;
        skill_level:       string;
    }
}

function RecipeApp() {
    // 訂閱代理的共享狀態
    const { state } = useCoAgent<RecipeState>({ name: 'RecipeAgent' });

    return (
        <div>
            <CopilotChat />
            {state.recipe && (
                <RecipeCard
                    title={state.recipe.title}
                    ingredients={state.recipe.ingredients}
                    steps={state.recipe.steps}
                    prepTime={state.recipe.prep_time_minutes}
                />
            )}
        </div>
    );
}
```

### 狀態更新的 SSE 格式

代理每次更新狀態時，AG-UI 會透過 SSE 傳送 `STATE_SNAPSHOT` 事件：

```json
event: STATE_SNAPSHOT
data: {
  "snapshot": {
    "recipe": {
      "title": "奶油蘑菇義大利麵",
      "cuisine": "義式",
      "ingredients": ["義大利麵 200g", "蘑菇 200g", "鮮奶油 100ml"],
      "steps": ["煮義大利麵至彈牙", "炒蘑菇", "加入鮮奶油熬煮"],
      "prep_time_minutes": 10,
      "cook_time_minutes": 20,
      "skill_level": "beginner"
    }
  }
}
```

---

## v1.5.0 新增：Reasoning Events（推理過程串流）

> 🆕 **v1.5.0 新增**（[PR #4953](https://github.com/microsoft/agent-framework/pull/4953)）：AG-UI Protocol 新增推理事件串流，讓前端可以即時顯示代理的「思考過程」，提供更透明的使用體驗。

當代理使用支援推理的 LLM（如 Claude 思考模式、OpenAI o1/o3 系列）時，推理過程會作為獨立的 SSE 事件串流到前端，與最終回應分開呈現。

### 推理事件 SSE 格式

```json
event: REASONING_CHUNK
data: {
  "delta": "分析使用者的問題需求：首先考慮旅行預算...",
  "chunk_index": 0
}

event: REASONING_CHUNK
data: {
  "delta": "...其次評估可用的工具選項：天氣查詢、航班搜尋...",
  "chunk_index": 1
}

event: TEXT_MESSAGE_CHUNK
data: {
  "delta": "根據您的需求，我建議..."
}
```

推理事件（`REASONING_CHUNK`）在最終文字回應（`TEXT_MESSAGE_CHUNK`）之前傳送。前端可選擇是否向使用者顯示推理過程。

### 前端（CopilotKit）訂閱推理事件

```tsx
import { useCopilotChat } from '@copilotkit/react-core';

function ChatWithReasoning() {
    const [reasoningText, setReasoningText] = React.useState('');

    const { isLoading } = useCopilotChat({
        // 訂閱推理事件串流
        onReasoning: (chunk: string) => {
            setReasoningText(prev => prev + chunk);
        }
    });

    return (
        <div>
            {isLoading && reasoningText && (
                <details open>
                    <summary>查看推理過程</summary>
                    <pre style={{ fontSize: '0.8em', color: '#666' }}>
                        {reasoningText}
                    </pre>
                </details>
            )}
            <CopilotChat />
        </div>
    );
}
```

> **使用注意事項**：
> - 推理事件是**選擇性的**：LLM 不支援推理時不會產生此類事件，後端無需額外設定
> - 推理過程可能含有中間思考細節，請評估是否直接暴露給終端使用者
> - 框架自動偵測 LLM 回應中的推理內容並轉換為 `REASONING_CHUNK` 事件

---

## AG-UI SSE 事件類型總覽

| 事件 | 說明 | 觸發時機 |
|------|------|----------|
| `TEXT_MESSAGE_CHUNK` | 代理回應的文字片段 | LLM 串流輸出時 |
| `REASONING_CHUNK` | 代理的推理過程片段（v1.5.0） | LLM 推理串流時（支援推理的模型）|
| `TOOL_CALL_START` | 工具呼叫開始 | 代理決定呼叫工具時 |
| `TOOL_CALL_ARGS_CHUNK` | 工具呼叫參數片段 | 參數串流建立時 |
| `TOOL_CALL_END` | 工具呼叫完成 | 工具執行完畢時 |
| `STATE_SNAPSHOT` | 完整狀態快照 | 代理更新共享狀態時 |
| `STATE_DELTA` | 狀態差異更新 | 增量狀態變更時 |
| `MESSAGES_SNAPSHOT` | 完整對話歷史 | Session 初始化時 |
| `RUN_STARTED` | 開始新一輪對話 | 每次 POST 請求開始時 |
| `RUN_FINISHED` | 對話輪次結束 | 代理完成回應時 |
| `RUN_ERROR` | 執行錯誤 | 代理發生例外時 |

---

## AG-UI 各步驟功能對照

| Step | 功能 | 關鍵 API |
|------|------|----------|
| Step 1 | 基礎 SSE 串流 | `AddAGUI()` + `MapAGUIAgent()` |
| Step 2 | 後端工具呼叫 | `AIFunctionFactory.Create()` + `AsAIAgent(tools:)` |
| Step 3 | 前端工具委派 | CopilotKit `useCopilotAction` |
| Step 4 | Human-in-the-Loop | `ApprovalRequiredAIFunction` + `ServerFunctionApprovalAgent` |
| Step 5 | 狀態雙向同步 | `SharedStateAgent` + CopilotKit `useCoAgent` |

---

### 延伸閱讀：官方 ADR 參考

- [ADR 0010 — AG-UI Support](https://github.com/microsoft/agent-framework/blob/main/docs/decisions/0010-ag-ui-support.md)：內部事件轉換架構，`MapAGUIAgent` 伺服器端實作，`AGUIAgent` 客戶端消費，SSE 串流與生命週期事件設計

---

> **返回目錄**：[README](README.md) | **上一章**：[23 — A2A Protocol](./23-a2a-protocol.md) | **下一章**：[25 — MCP 整合](./25-mcp-integration.md)
