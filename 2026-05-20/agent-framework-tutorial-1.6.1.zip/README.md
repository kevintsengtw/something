# Microsoft Agent Framework 繁體中文教學專案

> 建立日期：2026-04-12
> 最後更新：2026-05-14
> 基準版本：Microsoft Agent Framework v1.6.1（2026-05-14）

---

## 專案概述

本專案是 Microsoft Agent Framework 的繁體中文教學資源，專為 C# / .NET 開發者設計。包含兩大子系統：一套完整的 29 章 + 5 附錄入門至進階教學，以及一套基於 Karpathy LLM Wiki 概念的知識管理系統，用來自動追蹤上游 API 變更並偵測教學內容偏移。

## 目錄結構

```
agent-framework-tutorial/
├── README.md                              ← 本檔案
├── microsoft-agent-framework-tutorial/    ← 教學本體（29 章 + 5 附錄）
├── agent-framework-kb/                    ← LLM Wiki 知識庫
├── microsoft-agent-framework.md           ← 框架研究報告（2026-03-27）
├── EVAL-llm-wiki-feasibility.md           ← LLM Wiki 可行性評估
├── GUIDE-llm-wiki-setup.md                ← LLM Wiki 建置指南
├── v1.1.0-update-summary.md               ← v1.1.0 版本更新摘要
├── v1.4.0-update-summary.md               ← v1.2.0–v1.4.0 版本更新摘要
├── v1.5.0-update-summary.md               ← v1.5.0 版本更新摘要
└── v1.6.1-update-summary.md               ← v1.6.1 版本更新摘要
```

## 子專案說明

### 教學本體 — `microsoft-agent-framework-tutorial/`

以繁體中文撰寫的結構化學習路徑，從零開始掌握 Agent Framework。教學內容以官方 Agent-Framework-Samples 範例為骨幹，邊學邊做。

涵蓋範圍：AIAgent、AgentSession、Tools、Middleware、Workflows、Durable Agents、A2A Protocol、AG-UI Protocol、MCP 整合、CodeAct、Docker 部署、測試策略等。

詳見 [教學 README](./microsoft-agent-framework-tutorial/README.md)。

### LLM Wiki 知識庫 — `agent-framework-kb/`

基於 Karpathy LLM Wiki 概念的知識管理系統。透過 Claude Code 自訂指令（7 個 slash commands），自動追蹤上游 API 變更、編譯結構化知識、偵測教學內容偏移。

三層架構：`raw/`（上游素材 40+ 份）→ `/compile` → `wiki/`（概念條目 38 個）→ `/drift-check` → 教學內容

詳見 [知識庫 README](./agent-framework-kb/README.md)。

## 版本追蹤

| 框架版本 | 發佈日期 | 教學更新日期 | 更新摘要 |
|---------|----------|------------|---------|
| v1.0.0 GA | 2026-04-02 | 2026-04-12 | 教學初版建立（28 章 + 4 附錄） |
| v1.1.0 | 2026-04-10 | 2026-04-16 | [v1.1.0 摘要](./v1.1.0-update-summary.md)：Skill as class、6 章補強 |
| v1.2.0 | 2026-04-21 | 2026-04-21 | 知識庫 sync + compile 完成，教學更新與 v1.3.0 合併 |
| v1.3.0 | 2026-04-24 | 2026-04-24 | A2A SDK 1.0、Foundry Toolbox、SSE 重連 |
| v1.4.0 | 2026-05-05 | 2026-05-06 | [v1.4.0 摘要](./v1.4.0-update-summary.md)：CodeAct GA、HttpRequestAction、FIDES |
| v1.5.0 | 2026-05-08 | 2026-05-08 | [v1.5.0 摘要](./v1.5.0-update-summary.md)：Magentic Orchestration（Experimental）、AG-UI Reasoning Events、ch29 新增 |
| v1.6.1 | 2026-05-14 | 2026-05-14 | [v1.6.1 摘要](./v1.6.1-update-summary.md)：OTel Breaking、Foundry Toolbox 移除、Shell Tool、IChatMessageInjector、AgentSessionFiles、A2A HITL |

## 日常維護流程

當 Microsoft Agent Framework 發佈新版本時，依照以下流程更新：

1. 在 `agent-framework-kb/` 中執行 `/sync-upstream` → `/compile` → `/drift-check`
2. 根據偏移報告修改 `microsoft-agent-framework-tutorial/` 中的教學檔案
3. 再次 `/drift-check` + `/lint` 驗證
4. 更新版本記錄（README、附錄 A、PLAN）

完整步驟見 [版本更新 Playbook](./agent-framework-kb/PLAYBOOK-version-update.md)。

## 前置需求

- [.NET 8.0 SDK](https://dotnet.microsoft.com/download)（或更新版本）
- LLM 提供者 API Key（OpenAI / Azure OpenAI / Anthropic 擇一）
- [Claude Code CLI](https://docs.claude.com/en/docs/claude-code-overview)（用於知識庫操作）

## 授權

本教學內容為個人學習與分享用途。Microsoft Agent Framework 本身採用 MIT License。

## 參考連結

- [microsoft/agent-framework](https://github.com/microsoft/agent-framework)（SDK 原始碼）
- [microsoft/Agent-Framework-Samples](https://github.com/microsoft/Agent-Framework-Samples)（官方範例）
- [Agent Framework Release Notes](https://github.com/microsoft/agent-framework/releases)
