# 第一階段：獨立環境準備

本流程以 `PHASE1-HANDOFF.md` 為需求依據，只處理本機環境準備。此檔為共用規則，`skills/kw-prepare-environment/SKILL.md` 為來源入口，產生的兩份入口保持相同。公司驗收對象是 Windows 的 VS Code Codex Extension 與 Codex Desktop。舊 phase1～phase7 的歷史能力不是本次準備清單。

## 首次讀取與範圍

公司交付完整工作資料夾，包含 `.agents/skills/kw-prepare-environment/SKILL.md`、`skills/`、本檔、程式及定版檔。先用客戶端現有的讀檔能力開啟 Skill；若客戶端未探索到入口，可請 Agent 直接讀取該檔。這一步不需要 Node、Python、Git 或額外安裝 Skill。不要要求非開發人員 clone 業務原始碼 repo，也不要把入口安裝到被分析 repo；此輪不使用會安裝舊十三份入口的 `scripts/install-project-skills.mjs`。

從對話與公司交付設定確認本次目的、客戶端、可寫的獨立本機工作區，以及本次要用的分享位置／傳輸方式。資訊不足時只詢問必要缺口，同時繼續可獨立進行的讀取檢查。使用者已授權環境準備時，不對同一範圍的讀取、建立本機設定及必要探測反覆詢問；這不擴張公司核准的工具或檔案分享權限。

依實際任務選擇工具，不把角色當成職稱：

| 本次用途 | 既有 doctor 角色 | 必要工具 |
| --- | --- | --- |
| 只準備共用執行環境 | core | 定版 Node |
| 使用他人交付的知識 | reader | 定版 Node 與隨工作資料夾提供的 reader；不需 CGR 或業務原始碼 |
| 後續要從程式建立圖譜的維護者 | builder | 定版 Node、CGR 及已核准 Git |

使用 Git 傳遞知識，或本次要操作 Git 文件版本時，才另外準備 Git。Python 不在本階段的必要工具中。Windows 本機磁碟檢查使用已有的 Windows PowerShell 5.1 或已有 PowerShell 7；不以安裝 PowerShell 7 解決缺口。其他歷史功能若仍有額外相依，列為該功能限制，不在這次環境準備中擴張安裝。

## Node 尚未可用時

1. 用讀檔能力讀取 `package.json`、`toolchain.lock.json` 及公司交付的工具說明。沿用其中精確版本（目前 Node 24.15.0、CGR 0.2.0），不追最新版、不改 lock 或 release manifest。檔案與歷史報告不能證明本機已可執行，也不能自行當成公司核准。
2. 使用客戶端已允許的終端／工具查詢目前環境。Windows 可用 `Get-Command node -CommandType Application`、`$PSVersionTable.PSVersion`；僅在本次需要 Git 時查詢 Git。先查已知的公司工具目錄及目前 PATH，不全面掃描磁碟。直接執行核准工具的絕對路徑與版本參數確認能啟動；路徑有空白時使用引數陣列或 PowerShell 呼叫運算子 `&`。不要把自然語言問題插入 shell 程式碼。
3. 缺少或版本不符時，優先使用公司已核准的固定版本使用者層級／可攜工具包。核對工具包來源、版本、平台與公司提供的校驗／簽章資訊後，才解開到另外的本機工具目錄；保留 notices。Node 的既有 lock 只檢查 runtime 版本，不提供安裝包的核准或完整性證明；缺乏可信工具包／校驗資訊時明列缺口，不能從不明網路位置下載替代。此 Skill 不提供未經公司確認的下載來源或安裝政策。
4. 使用選定 Node 的絕對路徑執行後續 CLI。`@node` 就是啟動 CLI 的那份 runtime，不能用 `local.tools.node.executable` 重導向；必要時僅對本次子程序補充已核准 Git 等工具所在目錄的 PATH，不修改全域／使用者 PATH、profile、registry 或公司設定。
5. 只執行目前客戶端與公司政策允許的動作。AppLocker、WDAC、Constrained Language、execution policy、網路或工作區權限阻擋時，保留錯誤與接續資訊；不使用管理員、Full Access、「Approval for me」、`ExecutionPolicy Bypass`、`Unblock-File`、變更政策，或換命令包裝方式繞過已被禁止的操作。不能執行核准工具就不能宣稱已準備完成。

## 建立本機設定

設定由 Agent 產生及讀回，放在被分析業務專案、交付程式資料夾、共享目錄及 frozen 套件之外的獨立本機工作區。先確認實際路徑與 junction／symlink，不在來源 repo 寫 `.kw`、`.agents`、`.gitignore` 或其他設定；不呼叫業務專案內的安裝／建置指令。

沿用已核准且符合本次用途的設定；有其他人修改時重新讀取，不覆蓋。需要調整時產生新的準備設定檔並使用明確 `--project`／`--local`，保留舊檔，不依賴舊版設定更新器的額外 PowerShell 相依。不改正式專案設定、toolchain selection、active reader 或分享發布版次。

最小 project 設定使用既有 `kw.project/1`：指定專案 ID、交付資料夾內 `toolchain.lock.json` 的絕對路徑、真實來源位置及 `target_platforms`；`required_tools.core`、`reader` 為 `["node"]`，`builder` 為 `["node", "code-graph"]`。只準備 reader 而沒有來源 checkout 時，保留交付設定的來源識別；可用交付資料夾作為單純環境檢查來源，但須明示它不是業務程式來源，勿虛構 repo、commit 或知識政策。沒有 Git 傳輸設定時，CLI 不會測遠端 Git；不能因此省略對實際預定傳輸方式的回報。

本機設定以 `schemas/local.schema.json` 為準，檔案沒有 format 欄位：

- `workflow_root`：已核對的交付資料夾。
- `workspace_dir`：已建立、可寫且與所有來源分開的本機工作區。
- `cache_dir`：獨立本機快取子目錄，位於來源與共享目錄之外。UNC／映射網路磁碟不得當運作中的快取；同步軟體管理的磁碟仍需公司實測。
- `sources`：需要時綁定實際可讀來源；reader 可無 checkout，跳過結果須揭露。
- `tools.code-graph`：只在 builder 需要時綁定已核准、與定版校驗相符的原生 CGR。沿用 `probeTool` 的版本、二進位校驗及能力檢查；此次不建圖、不啟動完整升級流程。
- `shares.<id>.root`、`access`、`read_probe`：分享位置、實際需要的 `read` 或 `read-write` 存取，以及一個已存在且獲准讀取的相對檔案路徑。使用可安全讀取的交付檔，不要求上傳公司文件。寫入探測只供已授權要寫分享的任務，不能為 reader 擴大要求。

Git 傳輸沿用新的 `project.scoped_sharing.transport: "git"` 設定；沒有新設定時才沿用既有 `project.knowledge.transport`。環境檢查依同一優先順序判定是否需要 Git，不把舊 Git 設定套到已改用網路磁碟的任務。也可在本次程序中另行檢查已核准 Git，不能為通過檢查自行發明 audience、policy、reviewer、到期日或公司規範。若尚未選分享位置／既有可讀檔，先完成本機部分並將分享列為未完成。

## 實際檢查與接續

Node 就緒後，Agent 使用選定 runtime 的絕對路徑執行：

```text
<node> <workflow-root>/bin/kw.mjs doctor --project <preparation-project.json> --local <preparation-local.json> --role <core|reader|builder> --report <new-report.json>
```

引數與絕對路徑由 Agent 填入；不要求使用者組命令。報告放在工作區的報告目錄，位於來源、快取與共享目錄之外。`doctor` 沿用 release／工具定版與能力檢查，另實測：

- 工作區與快取中專屬暫存檔的建立、UTF-8 寫入、讀回及刪除；不寫來源。來源保護包含 linked worktree 的外部 Git 管理／共用目錄，工作區、快取、分享寫入探測及報告都不能寫進其中。
- 分享目錄列出及指定既有檔案的實際開啟讀取；讀寫用途再測專屬暫存檔寫入、讀回與刪除。這不是所有檔案 ACL 或遠端 Git 權限的證明。
- builder 或已設定 Git 用途的 Git 啟動；純 reader／core 不預設要求 Git。
- 要探測 CGR 時，先確認系統暫存位置也在來源、Git 管理與分享目錄之外；設定不合先停止，不啟動原生工具後才發現暫存已寫進來源。
- Windows 本機磁碟分類，優先使用內建 Windows PowerShell，已有 PowerShell 7 僅為備用；腳本執行被政策阻擋時如實報告。

Git／Gitea 傳輸若需要確認遠端讀取，可在已有具體目標及讀取授權時以禁止互動提示的 `git ls-remote <approved-remote>` 檢查，保留結果而不記錄憑證；離線或登入受阻則列未完成，不以本機 clone 可讀替代遠端權限。公司未授權試寫時不 push 或產生遠端測試提交；寫入／分享能力如尚未驗證就明示。此次不發布知識。

同時讀取 JSON、實際程序 exit code、fail、warn 及 skip。exit 0 只表示已執行檢查通過，沒有 `workspace_dir`、沒有分享探測或 reader 來源缺失的 skip 不能當作完整環境已可用。release 不符時停止受影響工作，不以 `release:write` 修理部署資料夾。

產生一份新的接續紀錄並讀回（Node 缺失時由現有檔案工具寫文字即可）；若連工作區都不可寫，直接在對話提供完整紀錄，不宣稱已存檔。紀錄包含：目的／角色、客戶端與時間、交付位置、實際 runtime／工具路徑及版本、核准來源／校驗依據、設定與報告位置、通過／失敗／跳過／未測項目、殘留探測檔、已完成的必要準備、精確缺口與下一次重試步驟。中斷後重新讀設定與報告、重測受影響項目，不刪除未知暫存檔、不把歷史結果當成本次成功。

本輪完成只代表所列用途的環境觀察，不代表建圖、語意、文件同步或知識發布完成。公司仍須在兩個 Codex 客戶端各自實測：無 Node 的首次讀取、核准可攜包準備、無 Python／無 PowerShell 7、一般帳號及實際批准模式、中文含空白路徑、工作區和來源隔離、SMB／映射磁碟、Git 傳輸、拒絕執行／拒絕存取、清理失敗與中斷接續；紀錄實際客戶端，不自行替另一端宣稱通過。
