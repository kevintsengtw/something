# 原始碼建圖標準流程與 Agent Skill 驗證

日期：2026-10-22。已授權工作：將 Git 原始碼專案的固定 codebase 建圖流程整理為共用規則，更新既有 kw-build-graphs，產生同源 Codex／Claude 入口。

## 變更

- skills/kw-build-graphs/SKILL.md：明確區分只建原始碼、只驗證及文件／UA 模式；repo 路徑缺少才先問；完整建圖正常連續完成。
- workflows/codebase-graphs.md：固定來源、獨立設定、Windows 暫存與核准方式、JSON 讀法、同份命令 ParseInput、原生 argv 範本、建圖後精確 manifest hash 驗證、結果核對及失敗邊界。
- workflows/knowledge.md 與 README.md：指向新的 source-only 分支。
- .agents 與 .claude 的 kw-build-graphs：由既有同步腳本產生，與來源 bytes 相同。
- tests/codebase-workflow.test.mjs：執行維護文件中原樣抽取的 PowerShell 範例，不以比對文件措辭取代行為測試。

本次沒有修改 src/、工具選擇、lock、schema 或公司資料。已審查綁定變動，使用既有 maintainer release:write 更新本機 development binding：

kw-workflow:sha256:a3f504a818677cc88c69dd3b0dc8c6e61a265ba522930f80d1e7983d80ad9f67

這不是在公司部署資料夾修復不明 release mismatch 的指令。交付的規則包不包含該 manifest，不會替換公司工具。

## 最終驗證

本機：macOS arm64、Node 24.15.0、PowerShell 7.6.1。

- 新增固定範例測試：8 通過、0 失敗。涵蓋中文含空白 JSON 路徑、ParseInput 非空／合法變數／舊插值錯誤、建圖驗證順序與真正 hash、子程序 temp／父程序環境、建圖非零停止並保留 stdout、manifest hash 不符不提交驗證、驗證非零不重試、驗證身分／counts 不符拒絕完成。
- npm test：750 項、698 通過、0 失敗、52 跳過，exit 0。跳過項目不當成通過。
- npm run skills:check：exit 0。
- npm run release:check：exit 0。
- Skill frontmatter：以 Ruby YAML.safe_load 實際解析，核對 name／description、命名長度、未完成標記及三份入口相同。Skill Creator 的 quick_validate.py 因已安裝 Python 缺 PyYAML 無法啟動；已記錄限制並採上述格式檢查，未安裝額外套件。

第一次完整測試與最後一次 Skill 文字修訂重疊，3 個既有案例被 release guard 擋下。固定來源、重新綁定後已完整重跑，以上是最後結果；前次 log 保留在 .kw/codebase-skill-20261022/npm-test.log，最終 log 為同目錄 npm-test-final.log。

## 證據界線

PowerShell 控制流測試呼叫的是隔離 fixture CLI，不是公司業務來源或原生 Windows CGR。歷史六個 repo 的公司成功紀錄是流程設計依據，不是本版 Skill 的新執行結果，也不證明 Claude／兩種公司 Codex 客戶端皆已驗收。

未修正 CLI 重複探測、argv/PID 等診斷缺口，也未查明曾發生的單條 60000 ms probe_timeout 根因。未增加 timeout、解除 warning、變更 imported_unverified 或宣稱業務語意已核准。

## 交付

規則包包含 Skill、共用文件與人工導入說明，不包含執行工具、lock、schema、release manifest、binary 或公司來源。應放在獨立 Agent 規則目錄，不覆蓋公司 tool-node25-ps7 或任何業務 repo。
