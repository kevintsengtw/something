# Codebase Agent Skill

日期：2026-10-22。此包是 Agent Skill 與共用規則，使用既有 Knowledge-Workflow CLI 建立 Git 原始碼專案的固定 codebase 圖譜。

## 放置方式

人工解壓至公司獨立規則目錄，例如 D:\Projects\FX\_kw\agent-skills\，該目錄直接包含 .agents、.claude、skills、workflows 與本檔。不要放到業務 repo，也不要覆蓋 tool-node25-ps7、公司 lock、schema、release manifest 或既有圖譜。確認解壓時保留隱藏的 .agents／.claude 目錄。

這裡沒有 bin/kw.mjs、package.json、工具 binary 或 runtime；它不是新的執行工具根目錄。既有工具位置與獨立工作區由使用者或已確認的公司設定提供。版本依實際工具的 lock 精確核對；不要因規則包的參考文件版本文字，將公司已核准的 Node 25／PowerShell 7 組合改回本機開發組合。

## 使用

從規則目錄啟動 Codex CLI，可用 $kw-build-graphs；未探索到 Skill 時，可直接貼上 INVOKE.txt 的完整內容，明確讀取此包 Skill。取得 repo 路徑後，正常成功連續完成固定來源、獨立設定、命令檢查、建圖及驗證。

只驗證既有圖譜需明確 artifact／manifest SHA-256／project ID，該模式不重建。只建原始碼圖譜不要求 Markdown 或 UA。Windows 路徑與核准方式依共用規則，不呼叫 Codebase-Memory MCP、不自動下載或重試。

Claude 入口與 Codex 入口內容相同；附有入口不代表 Claude 或公司任一客戶端已通過驗收。其他模式需要的既有文件，依 Skill 指示從已確認工具根目錄讀取；不把歷史 phase 文件的安裝說明擴張到本次範圍。

## 驗證與限制

SHA256SUMS.txt 用於核對傳輸後檔案；它是雜湊清單，不是簽章或公司核准。VALIDATION.md 記錄本機測試與尚未驗證的部分。公司六個 repo 的個別成功觀察不是這份新版 Skill 的完整 Windows 驗收。

本包未修正 CLI 重複 probe、補齊原生程序 telemetry，或查明先前 60 秒逾時根因。這些限制在標準流程中如實保留。
