import { readFile, writeFile, appendFile, mkdir, lstat, realpath } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import path from 'node:path';
import os from 'node:os';
import { pathToFileURL } from 'node:url';

const EXPECTED_HASH = 'b001425933ead258a47d3567162479dce66b01742b6ea5c4d16fe65c8173de57';
const NOTICES_HASH = '45d1388047a476d618ba845091968fd5824f5eef6cfb29fb02750804c7e2faf5';
const ARGS = [['--version'], ['index', '--help'], ['verify-index', '--help']];
const LABELS = ['version', 'index-help', 'verify-index-help'];
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const readJson = async file => JSON.parse((await readFile(file, 'utf8')).replace(/^\uFEFF/, ''));
const need = (condition, message) => { if (!condition) throw Error(message); };

export function validateConfig(config) {
  const keys = ['workflow_root', 'cgr_executable', 'temp_root', 'report_root'];
  need(config && Object.keys(config).length === keys.length && keys.every(key => typeof config[key] === 'string'), 'Config must contain exactly workflow_root, cgr_executable, temp_root, report_root');
  for (const key of keys) {
    const value = config[key];
    need(path.win32.isAbsolute(value) && /^D:\\/i.test(value) && !value.includes('\0'), `${key}: absolute D: path required`);
    need(!value.includes('${') && !/[<>\r\n]/.test(value), `${key}: unresolved placeholder or invalid path`);
    const relative = path.win32.relative('D:\\Projects\\FX\\_kw', value);
    need(relative && !relative.startsWith('..') && !path.win32.isAbsolute(relative), `${key}: path must stay under D:\\Projects\\FX\\_kw`);
  }
  need(config.temp_root.toLowerCase() === 'd:\\projects\\fx\\_kw\\tmp', 'Use the existing dedicated _kw\\tmp root');
  const reports = path.win32.relative('D:\\Projects\\FX\\_kw\\work\\compat-check', config.report_root);
  need(!reports.startsWith('..') && !path.win32.isAbsolute(reports), 'Reports must stay under _kw\\work\\compat-check');
  need(path.win32.basename(config.cgr_executable) === 'code-graph-rag-windows-amd64.exe', 'Expected pinned native Windows CGR executable');
}

async function noLinks(file) {
  let current = path.parse(file).root;
  for (const part of file.slice(current.length).split(path.sep).filter(Boolean)) {
    current = path.join(current, part);
    try { need(!(await lstat(current)).isSymbolicLink(), `Symlink/junction rejected: ${current}`); }
    catch (error) { if (error.code === 'ENOENT') break; throw error; }
  }
}

// Uses the existing tool's process implementation. It does not create a new watchdog.
export async function runPlan({ executable, probes, cwd, env, reportDir, runProcess, observations = {}, notify = console.log, signal }) {
  await mkdir(reportDir, { recursive: false });
  const reportFile = path.join(reportDir, 'report.json');
  const eventsFile = path.join(reportDir, 'events.jsonl');
  const report = { format: 'kw.cgr-probe-diagnostic/1', status: 'not_started', started_at: new Date().toISOString(), observations, process_attempts: 0, probes: probes.map(probe => ({ ...probe, executable, cwd, status: 'not_executed', pid: null, pid_note: 'Existing runProcess does not expose PID' })) };
  const save = () => writeFile(reportFile, JSON.stringify(report, null, 2) + '\n', 'utf8');
  const event = async data => appendFile(eventsFile, JSON.stringify({ at: new Date().toISOString(), ...data }) + '\n', 'utf8');
  await save();
  notify(`REPORT ${reportFile}`);
  for (const row of report.probes) {
    row.status = 'started'; row.started_at = new Date().toISOString();
    report.status = 'running'; report.process_attempts++;
    await save();
    await event({ type: 'begin', label: row.label, executable, args: row.args, cwd, timeout_ms: row.timeout_ms });
    notify(`BEGIN ${row.label} ${JSON.stringify(row.args)} timeout=${row.timeout_ms}ms`);
    const started = performance.now();
    try {
      const output = await runProcess(executable, row.args, { cwd, env, timeout: row.timeout_ms, diagnostics: true, label: `CGR diagnostic ${row.label}`, signal });
      row.elapsed_ms = Math.round((performance.now() - started) * 100) / 100;
      row.ended_at = new Date().toISOString();
      row.tool_exit_code = 0;
      row.combined_output_file = path.join(reportDir, `${row.label}.output.log`);
      await writeFile(row.combined_output_file, output, 'utf8');
      need(new RegExp(row.expect).test(output), `${row.label}: output did not match the locked version/capability`);
      row.status = 'passed';
    } catch (error) {
      row.elapsed_ms ??= Math.round((performance.now() - started) * 100) / 100;
      row.ended_at ??= new Date().toISOString();
      row.status = 'failed'; row.tool_exit_code ??= null;
      row.error = { code: error.code ?? 'diagnostic_error', message: error.message, details: error.details ?? {} };
      report.status = 'failed'; report.ended_at = new Date().toISOString(); report.diagnostic_exit_code = 4;
      await event({ type: 'end', label: row.label, status: row.status, elapsed_ms: row.elapsed_ms, error: row.error });
      await save(); notify(`FAIL ${row.label}: ${row.error.message}`);
      return { report, reportFile, exitCode: 4 };
    }
    await event({ type: 'end', label: row.label, status: row.status, elapsed_ms: row.elapsed_ms });
    await save(); notify(`PASS ${row.label} ${row.elapsed_ms}ms`);
  }
  report.status = 'completed'; report.ended_at = new Date().toISOString(); report.diagnostic_exit_code = 0;
  await save();
  notify('COMPLETED: probes passed in this run; this does not resolve or explain the earlier timeout.');
  return { report, reportFile, exitCode: 0 };
}

export async function main(argv) {
  if (argv.length === 1 && argv[0] === '--help') {
    console.log('Usage: node diagnose-cgr.mjs --config <absolute-config.json>\nStandalone diagnostic only; no build, retry, policy change, or MCP calls.');
    return 0;
  }
  need(argv.length === 2 && argv[0] === '--config' && path.isAbsolute(argv[1]), 'Use --config with one absolute JSON file path');
  const config = await readJson(argv[1]);
  validateConfig(config);
  need(process.platform === 'win32' && process.arch === 'x64', 'This package targets Windows x64; no CGR was invoked');
  for (const file of Object.values(config)) await noLinks(file);
  const workflow = await realpath(config.workflow_root);
  need((await readJson(path.join(workflow, 'package.json'))).name === '@knowledge-workflow/cli', 'Unexpected workflow package');
  const lockFile = path.join(workflow, 'toolchain.lock.json');
  const lockBytes = await readFile(lockFile);
  const lock = JSON.parse(lockBytes.toString('utf8').replace(/^\uFEFF/, ''));
  const node = lock.tools.find(tool => tool.id === 'node');
  const cgr = lock.tools.find(tool => tool.id === 'code-graph');
  need(node?.version === process.versions.node, 'Host Node version differs from the company lock');
  need(cgr?.version === '0.2.0' && cgr.probe.timeout_ms === 60000, 'Expected existing CGR 0.2.0 / 60000ms binding; do not rewrite the lock');
  const declared = [cgr.probe.args, ...cgr.capability_probes.map(probe => probe.args)];
  need(JSON.stringify(declared) === JSON.stringify(ARGS), 'Unexpected locked probe arguments');
  need(cgr.integrity.files.some(file => file.path === '@executable' && file.platforms?.includes('win32-x64') && file.sha256 === EXPECTED_HASH), 'Windows executable digest differs from the pinned contract');
  need(digest(await readFile(config.cgr_executable)) === EXPECTED_HASH, 'CGR binary SHA-256 mismatch');
  need(digest(await readFile(path.join(path.dirname(config.cgr_executable), 'code-graph-rag-windows-amd64.THIRD_PARTY_NOTICES.txt'))) === NOTICES_HASH, 'CGR notices SHA-256 mismatch');
  await mkdir(config.temp_root, { recursive: true });
  await mkdir(config.report_root, { recursive: true });
  const runId = `${new Date().toISOString().replace(/[:.]/g, '-')}-${randomUUID()}`;
  const scratch = path.join(config.temp_root, `kw-cgr-diagnostic-${runId}`);
  await mkdir(scratch);
  // Only this Node process and its children receive these values.
  process.env.TEMP = scratch; process.env.TMP = scratch; process.env.TMPDIR = scratch;
  need(path.resolve(os.tmpdir()).toLowerCase() === scratch.toLowerCase(), 'Node os.tmpdir() does not match the dedicated D: directory');
  const { runProcess } = await import(pathToFileURL(path.join(workflow, 'src/process.mjs')).href);
  const { cgrEnvironment } = await import(pathToFileURL(path.join(workflow, 'src/tool-environment.mjs')).href);
  const pattern = cgr.probe.version_pattern;
  const match = new RegExp(pattern).exec('code-graph-rag version 0.2.0');
  need(match?.groups?.version === '0.2.0', 'Unexpected locked version expression');
  const probes = ARGS.map((args, index) => ({ label: LABELS[index], args, timeout_ms: 60000, expect: index === 0 ? 'code-graph-rag version 0\\.2\\.0(?:\\s|$)' : cgr.capability_probes[index - 1].expect }));
  const controller = new AbortController();
  const cancel = () => controller.abort();
  process.on('SIGINT', cancel); process.on('SIGTERM', cancel);
  try {
    const result = await runPlan({ executable: config.cgr_executable, probes, cwd: scratch, env: cgrEnvironment(scratch), reportDir: path.join(config.report_root, runId), runProcess, signal: controller.signal,
      observations: { node: process.version, node_executable: process.execPath, workflow_root: workflow, lock_file: lockFile, lock_sha256: digest(lockBytes), cgr_sha256: EXPECTED_HASH, temp: scratch, node_tmpdir: os.tmpdir(), temporary_directory_retained: true, output_note: 'runProcess returns combined stdout/stderr; error details may contain stderr_tail. Missing PID/nonzero exit code are not inferred.' } });
    return result.exitCode;
  } finally { process.off('SIGINT', cancel); process.off('SIGTERM', cancel); }
}

if (process.argv[1] && import.meta.url === pathToFileURL(await realpath(process.argv[1])).href) {
  try { process.exitCode = await main(process.argv.slice(2)); }
  catch (error) { console.error(JSON.stringify({ status: 'diagnostic_setup_failed', message: error.message, code: error.code ?? null, cgr_execution_not_confirmed: true })); process.exitCode = 4; }
}
