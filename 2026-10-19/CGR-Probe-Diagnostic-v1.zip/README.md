# CGR probe diagnostic v1

日期：2026-10-22。這是針對目前 CGR 探測逾時準備的獨立診斷附件，不修改 Knowledge-Workflow 程式、lock、release、公司政策或業務 repo，不建立圖譜，不呼叫任何 MCP。

## 本機已做的確認

- Node 24.15.0、macOS arm64、PowerShell 7.6.1。
- 10 項診斷測試通過，含實際子程序、失敗／逾時／取消停止、中文含空白路徑、父程序環境保持不變、保存既有紀錄、PowerShell 實際啟動與 exit code 傳遞。
- 對 RUN.txt 的完整 Windows 命令做 PowerShell parser 檢查，errors = 0。用本機路徑實際執行相同呼叫結構，成功與失敗的 exit code 均正確傳遞。
- 專案 npm test：742 項，690 通過、0 失敗、52 跳過。skills:check 與 release:check 通過。沒有重新產生 release binding。
- macOS 原生 CGR 額外試跑：--version 因沙箱 semaphore 權限拒絕而 exit 1；程式保存了該命令、耗時及原始 stderr_tail，沒有繼續執行後續探測。

**Windows CGR、公司 Node 25.8.1、PowerShell 7.6.7 與公司執行限制尚未在本機驗證。測試不是原逾時已解決的證明。**

## 傳入公司

人工將附件解開至：

`D:\Projects\FX\_kw\work\diagnostics\cgr-probe-v1\`

該目錄應直接包含 diagnose-cgr.mjs、cgr-probe.config.json、RUN.txt 等檔案，不多包一層資料夾。沒有包含任何 CGR binary，不需安裝套件或下載。

設定檔已使用本次已知的公司位置：

- 工具：`D:\Projects\FX\_kw\tool-node25-ps7`
- CGR：`D:\Projects\FX\_kw\incoming\cgr-0.2.0\code-graph-rag-windows-amd64.exe`
- 暫存：`D:\Projects\FX\_kw\tmp`
- 診斷結果：`D:\Projects\FX\_kw\work\compat-check\cgr-probe-diagnostic\<本次唯一 ID>\`

傳入後先核對 SHA256SUMS.txt 的檔案雜湊。設定若不符，停止並確認；不由 Agent 臨時改程式來通過。SHA256SUMS.txt 只協助核對人工傳輸，並不是簽章或公司核准證明。

## 執行方式

由公司 Codex CLI 使用既有單次命令核准方式，**逐字執行 RUN.txt 的固定命令**。不使用 Full Access、不改政策、不新增 wrapper，不讓 Agent 重新生成診斷程式。

PowerShell 僅呼叫既有 Node 與這個固定檔案。診斷邏輯沒有 PowerShell 字串插值、New-Item 或待展開的 runTag 模板。父程序、User、Machine 的環境不變；TEMP/TMP/TMPDIR 只設定在診斷 Node 程序及其子程序。

程式確認公司現有 lock 的 Node 版本、CGR 0.2.0、60000 ms、三條固定 probe 參數及 Windows executable pin；另核對既有 CGR binary 與 notices SHA-256。沒有放寬或更動 lock。

依序執行 `--version`、`index --help`、`verify-index --help`，每條僅一次、每條上限 60000 ms，任何失敗立即停止。沿用公司工具的 runProcess 與 cgrEnvironment，不新增 watchdog 或重試。

## 結果與限制

- 啟動後先輸出 REPORT 的完整位置。每條實際執行前輸出 BEGIN，結束後輸出 PASS 或 FAIL。
- report.json 保存計畫、實際程序呼叫嘗試數、命令、工作目錄、timeout、起訖、耗時與結果；events.jsonl 在呼叫前先寫 begin。
- 成功輸出保存於各自 output.log。既有 runProcess 合併 stdout/stderr，並只在錯誤 details 提供 stderr_tail；本程式不宣稱取得獨立完整 stdout/stderr。
- 既有 runProcess 不提供 PID／部分非零 exit code。本程式明列 null 並保留原始錯誤，不推算或虛構。診斷程序 exit code 與 native tool exit code 分開。
- 每次建立新的結果與暫存子目錄，保留證據，不刪除未知目錄，不終止其他程序。
- 三條都通過表示此次診斷通過，不表示原本建圖中的第二輪 probe 逾時已解決。結果應用於下一次工具修正判斷，不變成每個 repo 的額外例行檢查。
- 本附件不移除建圖中的重複 probe，不改建圖邏輯，不開始重建，也不更新公司共用文件。這些需以實際診斷結果接續處理。
