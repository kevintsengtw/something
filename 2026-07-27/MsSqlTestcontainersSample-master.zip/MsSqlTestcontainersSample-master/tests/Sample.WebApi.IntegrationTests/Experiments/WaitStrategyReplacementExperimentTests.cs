using System.Diagnostics;
using AwesomeAssertions;
using DotNet.Testcontainers.Builders;
using Microsoft.Data.SqlClient;
using Sample.WebApi.IntegrationTests.Testing;
using Testcontainers.MsSql;

namespace Sample.WebApi.IntegrationTests.Experiments;

/// <summary>
/// 實驗性測試：驗證 <c>WithWaitStrategy</c> 究竟是「追加」還是「整組取代」內建的等待策略。
///
/// 為什麼要實測：Testcontainers 4.13.0 的 ContainerConfiguration 對 WaitStrategies 呼叫的是
/// <c>BuildConfiguration.Combine&lt;IEnumerable&lt;WaitStrategy&gt;&gt;(old, new)</c>——
/// 明確指定泛型參數會選到「純量」多載（新值非 null 就取代舊值），
/// 而不是那個會把兩個集合串接起來的 IEnumerable 多載。
/// 讀原始碼推得出這個結論，但這種等級的宣稱不能只靠讀，要跑過。
///
/// 實驗設計（每種結果都有資訊量）：
/// 換上一個「立刻就會通過」的等待策略。
/// - 若 WithWaitStrategy 是<b>追加</b>：內建的 sqlcmd SELECT 1 檢查仍在，
///   StartAsync 會等到 SQL Server 真的能回應才返回 → 事後立刻連線會成功。
/// - 若 WithWaitStrategy 是<b>取代</b>：只剩「容器 running」與 <c>true</c> 兩個條件，
///   StartAsync 幾秒內就返回 → 事後立刻連線會失敗（SQL Server 還在開機）。
///
/// 預設不執行：測試以 <see cref="ExperimentFactAttribute"/> 標記，
/// 未設定 SAMPLE_TESTS_RUN_EXPERIMENTS 時一律 skip（命令列與 IDE 兩個入口都適用）。
/// </summary>
[Trait("Category", "Experiment")]
public class WaitStrategyReplacementExperimentTests
{
    private const string ImageName = "mcr.microsoft.com/mssql/server:2022-latest";

    [ExperimentFact]
    public async Task WithWaitStrategy_換上立即通過的策略_內建sqlcmd檢查應已被取代()
    {
        // arrange
        var container = new MsSqlBuilder(ImageName)
            .WithTmpfsMount("/var/opt/mssql/data")
            .WithTmpfsMount("/var/opt/mssql/log")
            .WithWaitStrategy(Wait.ForUnixContainer().UntilCommandIsCompleted("true"))
            .Build();

        await using var _ = container;

        // act
        var stopwatch = Stopwatch.StartNew();
        await container.StartAsync();
        stopwatch.Stop();

        var connectResult = await TryConnectAsync(container.GetConnectionString());

        Console.WriteLine(
            $"[experiment/custom] StartAsync={stopwatch.Elapsed.TotalSeconds:F1}s " +
            $"connect={connectResult ?? "OK"}");

        // assert：StartAsync 幾乎沒等，且此刻 SQL Server 還連不上
        //         → 內建的 sqlcmd SELECT 1 檢查確實被整組取代掉了
        stopwatch.Elapsed.Should().BeLessThan(
            TimeSpan.FromSeconds(10),
            "自訂策略若只是追加在內建策略之後，StartAsync 會被 sqlcmd 檢查擋住而等更久");

        connectResult.Should().NotBeNull(
            "SQL Server 尚未就緒，連線應該失敗——這證明就緒檢查沒有被執行");
    }

    [ExperimentFact]
    public async Task WithWaitStrategy_使用內建預設策略_啟動後應可立即連線()
    {
        // arrange：對照組，不動 wait strategy
        var container = new MsSqlBuilder(ImageName)
            .WithTmpfsMount("/var/opt/mssql/data")
            .WithTmpfsMount("/var/opt/mssql/log")
            .Build();

        await using var _ = container;

        // act
        var stopwatch = Stopwatch.StartNew();
        await container.StartAsync();
        stopwatch.Stop();

        var connectResult = await TryConnectAsync(container.GetConnectionString());

        Console.WriteLine(
            $"[experiment/default] StartAsync={stopwatch.Elapsed.TotalSeconds:F1}s " +
            $"connect={connectResult ?? "OK"}");

        // assert
        connectResult.Should().BeNull(
            "內建策略會等到 sqlcmd 能執行 SELECT 1，因此啟動後應該立刻連得上");
    }

    /// <summary>
    /// 嘗試連線並跑一個最廉價的查詢。成功回傳 null，失敗回傳例外訊息。
    /// </summary>
    private static async Task<string?> TryConnectAsync(string connectionString)
    {
        var builder = new SqlConnectionStringBuilder(connectionString)
        {
            ConnectTimeout = 3
        };

        try
        {
            await using var connection = new SqlConnection(builder.ConnectionString);
            await connection.OpenAsync();

            await using var command = connection.CreateCommand();
            command.CommandText = "SELECT 1;";
            command.CommandTimeout = 3;
            await command.ExecuteScalarAsync();

            return null;
        }
        catch (Exception ex)
        {
            return $"{ex.GetType().Name}: {ex.Message}";
        }
    }
}
