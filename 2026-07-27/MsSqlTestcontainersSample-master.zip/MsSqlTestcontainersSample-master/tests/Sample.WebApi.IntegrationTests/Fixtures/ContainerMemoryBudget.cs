using System.Globalization;
using Docker.DotNet.Models;
using Testcontainers.MsSql;

namespace Sample.WebApi.IntegrationTests.Fixtures;

/// <summary>
/// 容器的記憶體預算。
///
/// 這裡要設的是<b>兩層</b>不同的東西，常被混為一談：
///
/// ── 第一層：容器總量（cgroup） ──────────────────────────────────────────
/// Docker 分配給這個容器的記憶體上限，對應 <c>docker run --memory</c>。
/// 它要裝的不只 SQL Server 的 buffer pool，還有執行緒堆疊、query workspace，
/// <b>以及 tmpfs 的檔案內容</b>——tmpfs 的頁面算在容器的 memory cgroup 額度裡，
/// 這點很容易被忽略。SQL Server on Linux 的官方最低需求是 2 GB，
/// 這裡取 4 GB 是為了讓上述各項都有餘裕。
///
/// ── 第二層：SQL Server 行程本身 ─────────────────────────────────────────
/// <c>MSSQL_MEMORY_LIMIT_MB</c>（注意是三個底線；<c>mssql.conf</c> 裡的同名設定
/// 才是無底線的 <c>memorylimitmb</c>）。不設的話，SQL Server 會吃掉它「看得到」的
/// 實體記憶體的八成，而它看到的往往是整個 WSL2 VM，不是容器額度。
///
/// ── 為什麼兩層都要設 ────────────────────────────────────────────────────
/// 只設第二層：容器沒有上限，4 GB 只是被動滿足，SQL Server 可能排擠同機的其他容器。
/// 只設第一層：SQL Server 仍照著「看到的」記憶體去擴張，撞到 cgroup 上限會被 OOM kill，
/// 而那又是一次沒有錯誤訊息的間歇性死亡。
/// 官方建議也是如此：memorylimitmb 要低於主機記憶體與 cgroup 上限。
/// https://learn.microsoft.com/sql/linux/configure/performance-best-practices-sql-server-memory
///
/// ── 預算怎麼算 ──────────────────────────────────────────────────────────
/// 容器 4 GB ＝ SQL Server 本體 2 GB ＋ tmpfs 上限 2 × 1 GB（實測只用到 150 MB 與 236 KB）
/// ＋ 其餘行程與緩衝。兩個數字之間刻意留了缺口，tmpfs 膨脹或 SQL Server 短暫超用都不會撞牆。
/// 整合測試的資料量只有幾百 MB，2 GB 的 buffer pool 綽綽有餘。
/// </summary>
public static class ContainerMemoryBudget
{
    /// <summary>
    /// SQL Server 行程自己的記憶體上限（MB）。
    ///
    /// <b>不要往下調到 2048。</b>實測 2048 會讓 <c>CREATE DATABASE</c> 直接失敗，
    /// 錯誤是 <c>There is insufficient system memory in resource pool 'default' to run this query.</c>
    /// 2 GB 是 SQL Server on Linux 對<b>整台機器</b>的最低需求，不是這個設定的安全值——
    /// 這個上限涵蓋 buffer pool、SQLPAL、query workspace 等所有元件，
    /// 壓到 2 GB 之後 default resource pool 分不到足夠的額度，連建資料庫都跑不動。
    /// </summary>
    public const int SqlServerLimitMb = 2560;

    /// <summary>容器總量上限（bytes），對應 docker run --memory。</summary>
    public const long ContainerLimitBytes = 4L * 1024 * 1024 * 1024;

    /// <summary>
    /// 單一 tmpfs 掛載點的大小上限（bytes）。不設的話預設是可用記憶體的一半。
    /// 兩個掛載點合計最多 1 GB，加上 SQL Server 的 2.5 GB 仍在容器的 4 GB 之內。
    /// 實測用量是 data 側 150 MB、log 側 236 KB，這個上限只是保險。
    /// </summary>
    public const long TmpfsSizeLimitBytes = 512L * 1024 * 1024;

    /// <summary>
    /// 一次套用兩層上限與 tmpfs 的大小限制。
    /// 必須在 <c>WithTmpfsMount</c> 之後呼叫——size 選項是就地補進既有掛載點的。
    /// </summary>
    public static MsSqlBuilder WithMemoryBudget(this MsSqlBuilder builder)
    {
        return builder
            .WithEnvironment(
                "MSSQL_MEMORY_LIMIT_MB",
                SqlServerLimitMb.ToString(CultureInfo.InvariantCulture))
            .WithCreateParameterModifier(parameters =>
            {
                var hostConfig = parameters.HostConfig ??= new HostConfig();
                hostConfig.Memory = ContainerLimitBytes;

                // WithTmpfsMount 沒有可以指定大小的多載（只有 destination 與 AccessMode），
                // 所以 size 只能從這裡補。
                //
                // 陷阱：Testcontainers 把 tmpfs 掛載放進 HostConfig.Mounts（Type = "tmpfs"），
                // 而不是 HostConfig.Mounts 旁邊那個 HostConfig.Tmpfs 字典——後者始終是 null。
                // 對著 HostConfig.Tmpfs 設定不會有任何錯誤，只是完全不生效，
                // 而 docker inspect 看到的 Tmpfs 一樣是 null，很容易誤判成「設了但沒用」。
                // 這一段是實際 docker inspect 過才寫對的。
                if (hostConfig.Mounts is null)
                {
                    return;
                }

                foreach (var mount in hostConfig.Mounts)
                {
                    if ("tmpfs".Equals(mount.Type, StringComparison.OrdinalIgnoreCase))
                    {
                        mount.TmpfsOptions = new TmpfsOptions { SizeBytes = TmpfsSizeLimitBytes };
                    }
                }
            });
    }
}
