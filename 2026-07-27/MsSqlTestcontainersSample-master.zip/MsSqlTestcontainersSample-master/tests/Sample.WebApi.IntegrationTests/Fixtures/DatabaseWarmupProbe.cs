using System.Diagnostics;
using Dapper;
using Microsoft.Data.SqlClient;

namespace Sample.WebApi.IntegrationTests.Fixtures;

/// <summary>
/// 暖身探測的結果。
/// </summary>
public enum WarmupOutcome
{
    /// <summary>以組態旗標關閉，完全沒有執行。</summary>
    Disabled,

    /// <summary>探測成功且夠快，判定為「真就緒」。</summary>
    Ready,

    /// <summary>deadline 到期，直接放行（退回無暖身行為）。</summary>
    DeadlineReached
}

/// <summary>
/// 暖身探測的結果明細，供 log 與測試斷言使用。
/// </summary>
/// <param name="Outcome">結束原因。</param>
/// <param name="Attempts">實際執行過的探測次數。</param>
/// <param name="Elapsed">整體耗時（由單一 Stopwatch 量測）。</param>
/// <param name="LastProbeDuration">最後一次探測本身的耗時；一次都沒跑時為 null。</param>
/// <param name="ProbeDurations">每一次探測的耗時。診斷用——出問題時要看得到每一輪發生什麼事。</param>
public sealed record WarmupResult(
    WarmupOutcome Outcome,
    int Attempts,
    TimeSpan Elapsed,
    TimeSpan? LastProbeDuration,
    IReadOnlyList<TimeSpan> ProbeDurations)
{
    /// <summary>供測試失敗訊息使用的逐輪明細。</summary>
    public string Trace =>
        $"outcome={this.Outcome} attempts={this.Attempts} " +
        $"elapsed={this.Elapsed.TotalMilliseconds:F1}ms " +
        $"probes=[{string.Join(", ", this.ProbeDurations.Select(x => $"{x.TotalMilliseconds:F1}"))}]";
}

/// <summary>
/// 暖身探測的參數。
/// </summary>
public sealed class WarmupOptions
{
    /// <summary>整體唯一的 deadline，到期一律放行。</summary>
    public TimeSpan Deadline { get; init; } = TimeSpan.FromSeconds(90);

    /// <summary>探測耗時低於此門檻才算「真就緒」。</summary>
    public TimeSpan FastEnough { get; init; } = TimeSpan.FromSeconds(1.5);

    /// <summary>兩次探測之間的間隔。</summary>
    public TimeSpan RetryDelay { get; init; } = TimeSpan.FromMilliseconds(250);

    /// <summary>單次探測要執行幾筆小 INSERT（模擬 seed 的工作負載）。</summary>
    public int InsertCount { get; init; } = 50;
}

/// <summary>
/// 「真就緒」的 best-effort 暖身探測。
///
/// 為什麼需要它：Testcontainers 的 wait strategy 通過（sqlcmd 跑得動 SELECT 1）
/// 不等於資料庫扛得住 DDL 與大量寫入——系統資料庫重建、buffer pool 初始化都還在進行，
/// 這段「就緒落差」正是「第一個測試都還沒跑就逾時」的來源。
/// 本探測實際做一次「建暫存表 + 一批小 INSERT + 丟棄」，用耗時判斷 I/O 路徑是否已經穩定。
///
/// 設計上的鐵則（記取初版死循環的教訓）：
/// 1. 整體只有 <b>一個</b> deadline，由單一 Stopwatch 控制，連單次探測的 CancellationToken
///    也是從剩餘時間切出來的——探測本身不可能跑得比 deadline 久。
/// 2. 迴圈只有兩種結束方式：<b>成功且夠快</b> → Ready；<b>時間用完</b> → DeadlineReached。
///    「一直成功但一直不夠快」會落在後者，不會無限等待（初版就是漏了這條路徑）。
///    注意「時間用完」在程式碼裡有兩個判斷點——迴圈頂端與重試前——
///    兩處都以 <see cref="MinimumUsefulBudget"/> 為界，理由見該常數的說明。
/// 3. deadline 到期一律放行：不拋例外、不阻塞。最差結局等於「沒做暖身」，
///    也就是退回原始行為，而不是讓整個測試套件掛掉。
/// 4. 「會結束」不等於「不空轉」：剩餘時間小到 CancelAfter 與 Task.Delay 都退化成 no-op 時，
///    迴圈會在 deadline 邊界忙碌輪詢。這是實測抓到的缺陷，修法同樣是 MinimumUsefulBudget。
///
/// 這是 best-effort 的優化，不是正確性的前提條件。
/// </summary>
public static class DatabaseWarmupProbe
{
    /// <summary>
    /// 控制是否啟用暖身的環境變數。設為 false / 0 即關閉。
    /// 掛上 tmpfs 之後暖身的必要性已大幅下降，保留它是為了對照實驗，
    /// 以及給無法使用 tmpfs 的環境當作退階方案。
    /// </summary>
    public const string EnabledEnvironmentVariable = "SAMPLE_TESTS_WARMUP";

    /// <summary>
    /// 剩餘時間少於這個值就直接視同 deadline 到期。
    ///
    /// 為什麼需要這個下限：CancellationTokenSource.CancelAfter(TimeSpan) 與 Task.Delay(TimeSpan)
    /// 都會把時間<b>截斷成整數毫秒</b>。剩下不到 1 毫秒時，CancelAfter(0.4ms) 變成「立刻取消」、
    /// Task.Delay(0.4ms) 變成「立刻返回」，迴圈就會在 deadline 邊界上空轉——
    /// 實測在 thread pool 被佔滿時單次跑出 38 次探測，其中 37 次耗時 0.0ms。
    /// 雖然仍會在 deadline 結束、不算無限迴圈，但那是不折不扣的忙碌輪詢。
    ///
    /// 取 5 毫秒而非 1 毫秒，是為了讓計時器的粗糙度也有餘裕。
    /// 對 90 秒的 deadline 來說，提早 5 毫秒放行沒有任何實質差別。
    /// </summary>
    private static readonly TimeSpan MinimumUsefulBudget = TimeSpan.FromMilliseconds(5);

    /// <summary>
    /// 是否啟用暖身探測（預設啟用）。
    /// </summary>
    public static bool IsEnabled => ReadFlag(EnabledEnvironmentVariable, defaultValue: true);

    /// <summary>
    /// 對指定的連線字串執行暖身探測。未啟用時直接回傳 <see cref="WarmupOutcome.Disabled"/>。
    /// </summary>
    public static Task<WarmupResult> RunAsync(
        string connectionString,
        WarmupOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        if (!IsEnabled)
        {
            return Task.FromResult(
                new WarmupResult(WarmupOutcome.Disabled, 0, TimeSpan.Zero, null, Array.Empty<TimeSpan>()));
        }

        var actualOptions = options ?? new WarmupOptions();

        return RunAsync(
            ct => ProbeAsync(connectionString, actualOptions, ct),
            actualOptions,
            cancellationToken);
    }

    /// <summary>
    /// 暖身迴圈本體。探測動作以委派注入，讓這段控制流程能夠脫離資料庫單獨測試。
    /// </summary>
    /// <param name="probe">單次探測；成功即正常返回，失敗請拋例外。</param>
    /// <param name="options">參數。</param>
    /// <param name="cancellationToken">外部取消（與 deadline 無關，會往外拋）。</param>
    public static async Task<WarmupResult> RunAsync(
        Func<CancellationToken, Task> probe,
        WarmupOptions options,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        var attempts = 0;
        TimeSpan? lastProbeDuration = null;
        var probeDurations = new List<TimeSpan>();

        while (true)
        {
            // 出口二：deadline 到期（或剩餘時間已經小到做不了事），一律放行
            var remaining = options.Deadline - stopwatch.Elapsed;
            if (remaining < MinimumUsefulBudget)
            {
                return new WarmupResult(
                    WarmupOutcome.DeadlineReached, attempts, stopwatch.Elapsed, lastProbeDuration, probeDurations);
            }

            attempts++;
            var probeStarted = stopwatch.Elapsed;

            // 單次探測的取消時限直接從「剩餘時間」切出來，
            // 探測本身就不可能把整體耗時撐過 deadline
            using var probeCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            probeCts.CancelAfter(remaining);

            try
            {
                await probe(probeCts.Token);
                lastProbeDuration = stopwatch.Elapsed - probeStarted;
                probeDurations.Add(lastProbeDuration.Value);

                // 出口一：成功而且夠快 —— I/O 路徑已經穩定
                if (lastProbeDuration <= options.FastEnough)
                {
                    return new WarmupResult(
                        WarmupOutcome.Ready, attempts, stopwatch.Elapsed, lastProbeDuration, probeDurations);
                }

                // 成功但太慢 —— 繼續重試（初版就是漏了這條路徑而死循環）
            }
            catch when (!cancellationToken.IsCancellationRequested)
            {
                // 失敗（含 deadline 觸發的取消）—— 一樣繼續，由迴圈頂端的 deadline 檢查收尾
                lastProbeDuration = stopwatch.Elapsed - probeStarted;
                probeDurations.Add(lastProbeDuration.Value);
            }

            var beforeDelay = options.Deadline - stopwatch.Elapsed;
            if (beforeDelay < MinimumUsefulBudget)
            {
                return new WarmupResult(
                    WarmupOutcome.DeadlineReached, attempts, stopwatch.Elapsed, lastProbeDuration, probeDurations);
            }

            // 連睡覺都不准睡過 deadline
            var delay = options.RetryDelay < beforeDelay ? options.RetryDelay : beforeDelay;
            await Task.Delay(delay, cancellationToken);
        }
    }

    /// <summary>
    /// 單次探測：建暫存表、跑一批小 INSERT、丟棄。
    /// 刻意選這個工作負載，因為它同時踩到 DDL 與 log 寫入——
    /// 也就是 seed data 真正會遇到的路徑，而不是 SELECT 1 那種問心無愧的假就緒。
    /// </summary>
    private static async Task ProbeAsync(
        string connectionString, WarmupOptions options, CancellationToken cancellationToken)
    {
        var sql =
            $"""
             SET NOCOUNT ON;
             CREATE TABLE #Warmup (Id int NOT NULL, Payload nvarchar(64) NOT NULL);
             DECLARE @i int = 0;
             WHILE @i < {options.InsertCount}
             BEGIN
                 INSERT INTO #Warmup (Id, Payload) VALUES (@i, N'warmup');
                 SET @i += 1;
             END
             DROP TABLE #Warmup;
             """;

        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);

        await connection.ExecuteAsync(
            new CommandDefinition(sql, commandTimeout: 30, cancellationToken: cancellationToken));
    }

    private static bool ReadFlag(string name, bool defaultValue)
    {
        var value = Environment.GetEnvironmentVariable(name);

        if (string.IsNullOrWhiteSpace(value))
        {
            return defaultValue;
        }

        return value.Trim() switch
        {
            "0" => false,
            "1" => true,
            var text when text.Equals("false", StringComparison.OrdinalIgnoreCase) => false,
            var text when text.Equals("true", StringComparison.OrdinalIgnoreCase) => true,
            _ => defaultValue
        };
    }
}
