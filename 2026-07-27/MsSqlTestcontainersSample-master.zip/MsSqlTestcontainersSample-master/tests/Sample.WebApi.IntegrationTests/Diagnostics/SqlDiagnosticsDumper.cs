using System.Text.Json;
using System.Text.Json.Serialization;
using Dapper;
using Microsoft.Data.SqlClient;

namespace Sample.WebApi.IntegrationTests.Diagnostics;

/// <summary>
/// SQL Server 診斷快照工具（行車紀錄器）。
/// 針對「間歇性逾時、無法隨叫隨到重現、看到錯誤時容器已被回收」的困境而設計：
/// 把採證寫進測試程式碼自動執行，log 落在宿主機的 %TEMP%，容器事後關閉也不影響。
///
/// 使用方式：
/// 1. 即時快照 —— seed 或關鍵操作包上
///    catch (SqlException ex) when (ex.Number == -2) { await SqlDiagnosticsDumper.DumpOnTimeoutAsync(cs); throw; }
/// 2. 終場快照 —— Fixture.DisposeAsync 關容器前無條件呼叫 DumpFinalSnapshotAsync
///
/// ── 這個工具的盲點（實測確認，不要對它有錯誤期待） ──────────────────────────
/// command timeout 的機制是<b>用戶端主動取消查詢</b>，在伺服器端觸發 Attention event（error 3617）。
/// 等到 catch 區塊執行、採證連線接上去查 DMV 時，受害者的請求早已不在
/// sys.dm_exec_requests 裡了——該檢視只列出「當下正在執行」的請求。
/// 實測結果：逾時當下的 Requests 一筆使用者請求都沒有。
///
/// 所以「錄得到肇事者，錄不到受害者的最後一刻」。可用的證據在擋人的那一側：
///   - <see cref="LockSnapshot"/>（sys.dm_tran_locks）：誰還握著 X / IX 鎖
///   - <see cref="SessionSnapshot"/>（sys.dm_exec_sessions）：誰帶著未提交的交易在睡覺
/// 這兩段在受害者被取消之後依然留得住，實測都採得到。
///
/// ── 判讀 ──────────────────────────────────────────────────────────────
/// - Requests 空的，但 OpenTransactions 有 sleeping + 未提交交易、Locks 有 X 鎖
///   → 結論是鎖，受害者已被 attention 取消。<b>這是 catch 路徑採證的典型長相。</b>
/// - Requests 有 blocking_session_id != 0 且 LCK_M_* 等待 → 抓到現行犯。
///   但注意：<b>從 DumpOnTimeoutAsync 的 catch 路徑進來永遠看不到這個組合</b>（理由同上）。
///   要看到它，採證必須發生在受害者「仍在等待」的時候，例如：
///   終場快照剛好撞上另一條還在等鎖的 session、由獨立的觀察者定時採證、
///   或受害者的 command timeout 遠長於採證所需時間而由別的執行緒併發觸發。
/// - Requests 有 WRITELOG / PAGEIOLATCH_* 等待 → 宿主機 I/O 壓力（tmpfs 可解）。
///   同樣需要在請求仍在執行時採到。
/// - 連本工具都連不上 → server 整體資源耗盡（這本身就是證據，見 Error 欄位）
///
/// 註：SessionSnapshot.EventInfo 來自 sys.dm_exec_input_buffer，
/// 它給的是那條 session <b>最後一個輸入批次</b>，不見得就是持鎖的那一句。
/// </summary>
public static class SqlDiagnosticsDumper
{
    /// <summary>
    /// SqlException.Number == -2 代表逾時（command timeout）。
    /// 官方文件：Troubleshoot query time-out errors
    /// https://learn.microsoft.com/troubleshoot/sql/database-engine/performance/troubleshoot-query-timeouts
    /// 用戶端逾時會取消查詢，在伺服器端觸發 Attention event（error 3617）。
    /// </summary>
    public const int TimeoutErrorNumber = -2;

    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        WriteIndented = true,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    /// <summary>
    /// 只取使用者連線。
    /// 不要用 session_id &gt; 50 這個老偏方——實測 SQL Server 2022 on Linux 的內部背景工作
    /// （BRKR TASK、TASK MANAGER、XE TIMER 等）session_id 落在 51 以上，
    /// 用 50 當門檻會撈進四十幾筆雜訊，把真正的證據淹掉。
    /// </summary>
    private const string UserSessionsOnly = "s.is_user_process = 1";

    /// <summary>
    /// 逾時當下的即時快照。回傳 log 檔路徑。
    /// </summary>
    public static Task<string> DumpOnTimeoutAsync(string connectionString)
    {
        return DumpCoreAsync(connectionString, "timeout");
    }

    /// <summary>
    /// 關閉容器前的終場快照。回傳 log 檔路徑。
    /// </summary>
    public static Task<string> DumpFinalSnapshotAsync(string connectionString)
    {
        return DumpCoreAsync(connectionString, "final");
    }

    /// <summary>
    /// 以自訂的 reason 採證並寫檔。reason 會同時出現在檔名與 log 表頭，
    /// 事後比對時不會搞混哪份 log 是哪個情境。
    /// </summary>
    public static Task<string> DumpAsync(string connectionString, string reason)
    {
        return DumpCoreAsync(connectionString, reason);
    }

    /// <summary>
    /// 採證並回傳結果物件（不寫檔）。測試用這個做斷言，不必去比對 log 的字串。
    /// </summary>
    public static async Task<DiagnosticsSnapshot> CaptureAsync(string connectionString, string reason)
    {
        // 獨立的 Application Name = 獨立的 connection pool，
        // 主測試的 pool 出任何狀況都不影響採證連線
        var builder = new SqlConnectionStringBuilder(connectionString)
        {
            ApplicationName = "SqlDiagnosticsDumper",
            InitialCatalog = "master",
            ConnectTimeout = 5
        };

        try
        {
            await using var connection = new SqlConnection(builder.ConnectionString);
            await connection.OpenAsync();

            // 誰在等、被誰擋、等什麼（DMV 為記憶體內檢視，不受資料表鎖影響）
            var requests = await connection.QueryAsync<RequestSnapshot>(
                $"""
                 -- session_id / blocking_session_id 在 DMV 裡是 smallint，
                 -- 不轉型的話 Dapper 會找不到相符的 record 建構式
                 SELECT CAST(r.session_id AS int)          AS SessionId,
                        CAST(r.blocking_session_id AS int) AS BlockingSessionId,
                        r.wait_type             AS WaitType,
                        CAST(r.wait_time AS bigint) AS WaitTime,
                        r.wait_resource         AS WaitResource,
                        r.command               AS Command,
                        t.text                  AS SqlText
                 FROM sys.dm_exec_requests r
                 INNER JOIN sys.dm_exec_sessions s ON s.session_id = r.session_id
                 OUTER APPLY sys.dm_exec_sql_text(r.sql_handle) t
                 WHERE {UserSessionsOnly}
                   AND r.session_id <> @@SPID;
                 """);

            // 誰還握著鎖 —— 受害者被取消之後，證據留在這一段
            var locks = await connection.QueryAsync<LockSnapshot>(
                $"""
                 -- resource_description 是 nchar(256)，不 TRIM 的話 log 會被兩百多個空白撐爆；
                 -- OBJECT 類型的 resource_description 是空的，要自己把物件名稱解出來。
                 -- 一個 TABLOCKX 實測會產生十幾列一模一樣的 OBJECT 鎖，所以聚合成一列加計數。
                 SELECT CAST(l.request_session_id AS int) AS SessionId,
                        l.resource_type                   AS ResourceType,
                        CASE
                            WHEN l.resource_type = 'OBJECT'
                                THEN OBJECT_SCHEMA_NAME(l.resource_associated_entity_id, l.resource_database_id)
                                     + '.'
                                     + OBJECT_NAME(l.resource_associated_entity_id, l.resource_database_id)
                            ELSE NULLIF(RTRIM(LTRIM(l.resource_description)), '')
                        END                               AS Resource,
                        DB_NAME(l.resource_database_id)   AS DatabaseName,
                        l.request_mode                    AS RequestMode,
                        l.request_status                  AS RequestStatus,
                        COUNT(*)                          AS LockCount
                 FROM sys.dm_tran_locks l
                 INNER JOIN sys.dm_exec_sessions s ON s.session_id = l.request_session_id
                 WHERE {UserSessionsOnly}
                   AND l.request_session_id <> @@SPID
                   AND NOT (l.resource_type = 'DATABASE' AND l.request_mode = 'S')
                 GROUP BY l.request_session_id,
                          l.resource_type,
                          l.resource_associated_entity_id,
                          l.resource_database_id,
                          l.resource_description,
                          l.request_mode,
                          l.request_status
                 -- 等待中的鎖排最前面，那才是現行犯
                 ORDER BY CASE WHEN l.request_status = 'WAIT' THEN 0 ELSE 1 END,
                          l.request_session_id,
                          l.resource_type;
                 """);

            // 帶著未提交交易的 session（洩漏交易的鐵證）
            var openTransactions = await connection.QueryAsync<SessionSnapshot>(
                $"""
                 SELECT CAST(s.session_id AS int)  AS SessionId,
                        s.status                  AS Status,
                        s.open_transaction_count  AS OpenTransactionCount,
                        s.program_name            AS ProgramName,
                        s.last_request_end_time   AS LastRequestEndTime,
                        ib.event_info             AS EventInfo
                 FROM sys.dm_exec_sessions s
                 CROSS APPLY sys.dm_exec_input_buffer(s.session_id, NULL) ib
                 WHERE {UserSessionsOnly}
                   AND s.open_transaction_count > 0
                   AND s.session_id <> @@SPID;
                 """);

            return new DiagnosticsSnapshot(
                reason,
                DateTimeOffset.Now,
                requests.AsList(),
                locks.AsList(),
                openTransactions.AsList());
        }
        catch (Exception ex)
        {
            // 連採證都失敗 —— 這本身就是重要證據（server 全面癱瘓）。
            // 訊息刻意不寫死「無法連線」：這個 catch 什麼例外都收得到，
            // 包含 dumper 自己的 bug（實測踩過一次 Dapper 型別對不上），
            // 標成連線問題會把人帶去查錯方向。型別名稱要留著，它就是分辨的依據。
            return new DiagnosticsSnapshot(
                reason,
                DateTimeOffset.Now,
                Array.Empty<RequestSnapshot>(),
                Array.Empty<LockSnapshot>(),
                Array.Empty<SessionSnapshot>(),
                $"DUMPER 採證失敗: {ex.GetType().Name}: {ex.Message}");
        }
    }

    private static async Task<string> DumpCoreAsync(string connectionString, string reason)
    {
        var snapshot = await CaptureAsync(connectionString, reason);

        var path = Path.Combine(
            Path.GetTempPath(),
            $"sql-diagnostics-{reason}-{DateTime.Now:yyyyMMdd-HHmmss-fff}.log");

        await File.WriteAllTextAsync(path, Format(snapshot));

        return path;
    }

    /// <summary>
    /// 排版成人看得懂的 log。分段輸出，方便直接貼進 issue 或文章。
    /// </summary>
    public static string Format(DiagnosticsSnapshot snapshot)
    {
        var newLine = Environment.NewLine;

        var text =
            $"=== SQL 診斷快照 ==={newLine}" +
            $"reason     : {snapshot.Reason}{newLine}" +
            $"capturedAt : {snapshot.CapturedAt:yyyy-MM-dd HH:mm:ss.fff zzz}{newLine}";

        if (snapshot.Error is not null)
        {
            return text + newLine + snapshot.Error + newLine;
        }

        return text +
               $"{newLine}=== 使用者請求 sys.dm_exec_requests（{snapshot.Requests.Count} 筆）==={newLine}" +
               JsonSerializer.Serialize(snapshot.Requests, SerializerOptions) + newLine +
               $"{newLine}=== 鎖 sys.dm_tran_locks（{snapshot.Locks.Count} 筆）==={newLine}" +
               JsonSerializer.Serialize(snapshot.Locks, SerializerOptions) + newLine +
               $"{newLine}=== 未提交交易的 session sys.dm_exec_sessions（{snapshot.OpenTransactions.Count} 筆）==={newLine}" +
               JsonSerializer.Serialize(snapshot.OpenTransactions, SerializerOptions) + newLine;
    }
}
