namespace Sample.WebApi.IntegrationTests.Diagnostics;

/// <summary>
/// 正在執行的使用者請求（來自 sys.dm_exec_requests）。
/// 注意 dm_exec_requests 只列出<b>當下正在執行</b>的請求；
/// 被用戶端取消（command timeout）的請求會立刻消失，詳見 <see cref="SqlDiagnosticsDumper"/> 的說明。
/// </summary>
public sealed record RequestSnapshot(
    int SessionId,
    int BlockingSessionId,
    string? WaitType,
    long WaitTime,
    string? WaitResource,
    string? Command,
    string? SqlText);

/// <summary>
/// 鎖的持有與等待狀況（來自 sys.dm_tran_locks）。
/// 受害者被取消之後，證據會留在這裡——兇手還握著鎖。
/// </summary>
/// <param name="Resource">
/// OBJECT 類型顯示解析後的物件名稱；其餘類型顯示 resource_description（已去除尾端空白）。
/// </param>
/// <param name="LockCount">
/// 相同 (session, 資源, 模式, 狀態) 的鎖筆數。
/// 一個 TABLOCKX 實測會產生十幾列一模一樣的 OBJECT 鎖，聚合起來才看得到重點。
/// </param>
public sealed record LockSnapshot(
    int SessionId,
    string ResourceType,
    string? Resource,
    string? DatabaseName,
    string RequestMode,
    string RequestStatus,
    int LockCount);

/// <summary>
/// 帶著未提交交易的 session（來自 sys.dm_exec_sessions）。
/// sleeping + open_transaction_count &gt; 0 是洩漏交易的鐵證。
/// </summary>
public sealed record SessionSnapshot(
    int SessionId,
    string? Status,
    int OpenTransactionCount,
    string? ProgramName,
    DateTime? LastRequestEndTime,
    string? EventInfo);

/// <summary>
/// 一次採證的完整結果。
/// </summary>
public sealed record DiagnosticsSnapshot(
    string Reason,
    DateTimeOffset CapturedAt,
    IReadOnlyList<RequestSnapshot> Requests,
    IReadOnlyList<LockSnapshot> Locks,
    IReadOnlyList<SessionSnapshot> OpenTransactions,
    string? Error = null);
